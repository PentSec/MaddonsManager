-- -------------------------------------------------------------------------- --
-- AllYouCanEat deDE Localization                                             --
-- Please make sure to save this file as UTF-8. ¶                             --
-- -------------------------------------------------------------------------- --
if GetLocale() ~= "deDE" then return end
AllYouCanEat_Locales:CreateLocaleTable({

-- Interface Options
["Open GUI"] = "GUI öffnen",

-- GUI
["CharManager"] = "CharManager",
["Latest Update"] = "Letzte Aktualisierung",
["all"] = "alle",
["No."] = "Nr.",
["ItemID"] = "ItemID",
["Name"] = "Name",
["click & move"] = "klicken & bewegen",
["click & resize"] = "klicken & Größe ändern",
-- GUI - CharManager
["Options for:"] = "Optionen für:",
["Status:"] = "Status:",
["TOOLTIP"] = "TOOLTIP",
["SAVED"] = "GESPEICHERT",
["NOT SAVED"] = "NICHT GESPEICHERT",
["Save Data"] = "Daten speichern",
["Delete Data"] = "Daten löschen",
["Do you really want to delete the data from this character?"] = "Willst Du die Daten von diesem Charakter wirklich löschen?",
["Remove Character"] = "Charakter entfernen",
["Do you really want to remove this character?"] = "Willst Du diesen Charakter wirklich entfernen?",
["Only useful if a character was permanently deleted."] = "Nur nützlich, wenn ein Charakter für immer gelöscht wurde.",
["Saves the statistics data from this character to SavedVariable, so you can view it with other characters."] = "Speichert die Statistikdaten von diesem Charakter in SavedVariables, damit man diese mit anderen Charakteren sehen kann.",
["Show statistic data in GameTooltip"] = "Zeige Statistikdaten im GameTooltip.",

-- Tooltip
["consumed"] = "konsumiert",
["not consumed"] = "nicht konsumiert",
["Unsafe Item"] = "Unsicherer Gegenstand",
["You can try to start a new server query in %s seconds!"] = "Du kannst nochmal in %s Sekunden versuchen eine Serverabfrage zu starten.",
["You may be disconnected."] = "Dies kann zu einem Verbindungsabbruch führen.",
["Please wait 5 seconds for next server query."] = "Bitte 5 Sekunden warten für eine erneute Serverabfrage.",

-- Chatoutput
["Beverages"] = "Getränke",
["Foods"] = "Essen",
["Bandage"] = "Bandagen",
["Health Potions"] = "Heiltränke",
["Mana Potions"] = "Manatränke",
["Elixirs"] = "Elixiere",
["Flasks"] = "Fläschchen",

})