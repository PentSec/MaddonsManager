-- -------------------------------------------------------------------------- --
-- AllYouCanEat zhTW Localization By 楓之刃@米奈希爾                          --
-- Please make sure to save this file as UTF-8. ¶                             --
-- -------------------------------------------------------------------------- --
if GetLocale() ~= "zhTW" then return end
AllYouCanEat_Locales:CreateLocaleTable({

-- Interface Options
["Open GUI"] = "開啟 GUI",

-- GUI
["CharManager"] = "CharManager",
["Latest Update"] = "最後更新",
["all"] = "全部",
["No."] = "No.",
["ItemID"] = "ItemID",
["Name"] = "名稱",
["click & move"] = "點擊 & 移動",
--["click & resize"] = true,
-- GUI - CharManager
["Options for:"] = "選項:",
["Status:"] = "狀態:",
["TOOLTIP"] = "工具提示",
["SAVED"] = "已儲存",
["NOT SAVED"] = "未儲存",
["Save Data"] = "儲存數據",
["Delete Data"] = "刪除數據",
--["Do you really want to delete the data from this character?"] = true,
--["Remove Character"] = true,
--["Do you really want to remove this character?"] = true,
--["Only useful if a character was permanently deleted."] = true,
["Saves the statistics data from this character to SavedVariable, so you can view it with other characters."] = "儲存的統計數據到這個角色的SavedVariable，所以你可以查看它與其他的角色。",
["Show statistic data in GameTooltip"] = "統計數據顯示在遊戲信息提示",

-- Tooltip
["consumed"] = "已飲用",
["not consumed"] = "未飲用",
["Unsafe Item"] = "不安全的物品",
["You can try to start a new server query in %s seconds!"] = "你可以在%s秒嘗試啟動一個新的伺服器查詢！",
["You may be disconnected."] = "你可能會斷開連接。",
["Please wait 5 seconds for next server query."] = "下一個伺服器查詢，請耐心等待5秒。",

-- Chatoutput
["Beverages"] = "飲料",
["Foods"] = "食物",
["Bandage"] = "繃帶",
["Health Potions"] = "治療藥水",
["Mana Potions"] = "法力藥水",
["Elixirs"] = "藥劑",
["Flasks"] = "精鍊藥劑",

})