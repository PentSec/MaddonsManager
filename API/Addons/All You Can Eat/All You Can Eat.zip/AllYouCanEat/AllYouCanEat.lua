-- -------------------------------------------------------------------------- --
--           _    _ ___   __           ____            _____      _           --
--          / \  | | \ \ / /__  _   _ / ___|__ _ _ __ | ____|__ _| |_         --
--         / _ \ | | |\ V / _ \| | | | |   / _` | '_ \|  _| / _` | __|        --
--        / ___ \| | | | | (_) | |_| | |__| (_| | | | | |__| (_| | |_         --
--       /_/   \_\_|_| |_|\___/ \__,_|\____\__,_|_| |_|_____\__,_|\__|        --
--                                                                            --
-- -------------------------------------------------------------------------- --

-- -------------------------------------------------------------------------- --
-- AllYouCanEat by kunda                                                      --
-- -------------------------------------------------------------------------- --
--                                                                            --
-- AllYouCanEat is digging for details about the following statistics:        --
-- - 1774 = Different beverages consumed                                      --
-- - 1775 = Different foods eaten                                             --
-- - 1298 = Different bandage types used                                      --
-- - 1300 = Different health potions used                                     --
-- - 1302 = Different mana potions used                                       --
-- - 1304 = Different elixirs used                                            --
-- - 1306 = Different flasks consumed                                         --
--                                                                            --
-- With this AddOn it's easy to see which foods, beverages, elixirs, potions, --
-- bandages and flasks were consumed and which not.                           --
-- The default statistic interface does not show such details.                --
--                                                                            --
-- The result is shown in a movable & resizable frame (accessible via LDB,    --
-- InterfaceOptions, '/allyoucaneat' or '/ayce'). If the statistic data is    --
-- saved to SavedVariables (via 'CharManager' Button) it's possible to enable --
-- an option to see this information in the various Tooltips or with other    --
-- characters.                                                                --
--                                                                            --
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
-- !   It's impossible to consume everything because some items are class   ! --
-- !   dependent, profession dependent, faction dependent, quest rewards    ! --
-- !   (which you usually not get back if you finished the quest), some     ! --
-- !   items are only available via a TCG NPC and finally some items are    ! --
-- !   simply not available ingame.                                         ! --
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
-- !!!  YES, this AddOn is absolutely USELESS, unless it's fun for you to !!! --
-- !!!  do a drink & food hunt across the whole WoW world :)              !!! --
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
--                                                                            --
-- Notes:                                                                     --
-- -> The initial statistic scan at PLAYER_LOGIN is very CPU/Bandwidth heavy  --
--    (approximately 1700 GetAchievementCriteriaInfo() calls).                --
--    This scan can take up to 3 seconds!!!                                   --
-- -> The Tooltip server query code may be a bit annoying, but this is        --
--    necessary to avoid disconnects, because some itemIDs that are returned  --
--    from the server in the initial statistic scan are invalid respectively  --
--    currently not available ingame.                                         --
--    This means: A Tooltip server query (mouseover an item in the MainFrame) --
--    via GameTooltip:SetHyperlink() is restricted to one server query every  --
--    5 seconds, for the same itemID to 10 seconds. I never got a disconnect  --
--    with this 2 intervals. But just in case: A warning text is shown.       --
--                                                                            --
-- -------------------------------------------------------------------------- --

-- ---------------------------------------------------------------------------------------------------------------------
AllYouCanEat = CreateFrame("Frame")
AllYouCanEat_Options = {}      -- SavedVariable options table
AllYouCanEat_Data = {}         -- SavedVariable data table
local L = AllYouCanEat_Locales -- localization table

local _G = _G
local select = _G.select
local GetTime = _G.GetTime
local GetAchievementCriteriaInfo = _G.GetAchievementCriteriaInfo
local math_floor = _G.math.floor

local mult2 = 10^(2 or 0)      -- x.xx

local playerRealm              -- current realm name
local playerName               -- current player name
local playerGUID               -- current player GUID
local playerFaction            -- current player faction
local playerClass              -- current player class

local classcolors = RAID_CLASS_COLORS

local DATA = {}                -- main data table
local GUI_MainDataGUID         -- current shown GUID data
local GUI_Data = {}            -- data table
local GUI_Data_Count           -- data table count
local GUI_SortBy = 1           -- data table sort by: 1 = number | 2 = itemId | 3 = itemLink | 4 = ItemName
local GUI_SortOrder = 1        -- data table sort order
local GUI_Detail = 1           -- data table detail: 1 = all | 2 = consumed | 3 = not consumed
local GUI_Data_maxNum = 50     -- data table max rows
local GUI_Data_minNum = 5      -- data table min rows
local GUI_Data_curNum = 25     -- data table current rows
local SearchQuery
local SearchFrameIsShown

local GUI_Selection = 1774     -- default data
local GUI_scantime = ""        -- latest update

local GUI_CharListData = {}         -- character table
local GUI_CharListData_maxNum = 10  -- character table max rows

local StatisticID = {
	[1] = {id = 1774, name = L["Beverages"],      icon = "Interface\\Icons\\INV_Drink_15"},        -- 1774 = Different beverages consumed
	[2] = {id = 1775, name = L["Foods"],          icon = "Interface\\Icons\\INV_Misc_Food_08"},    -- 1775 = Different foods eaten
	[3] = {id = 1298, name = L["Bandage"],        icon = "Interface\\Icons\\INV_Misc_Bandage_14"}, -- 1298 = Different bandage types used
	[4] = {id = 1300, name = L["Health Potions"], icon = "Interface\\Icons\\INV_Potion_51"},       -- 1300 = Different health potions used
	[5] = {id = 1302, name = L["Mana Potions"],   icon = "Interface\\Icons\\INV_Potion_72"},       -- 1302 = Different mana potions used
	[6] = {id = 1304, name = L["Elixirs"],        icon = "Interface\\Icons\\INV_Potion_66"},       -- 1304 = Different elixirs used
	[7] = {id = 1306, name = L["Flasks"],         icon = "Interface\\Icons\\INV_Potion_90"}        -- 1306 = Different flasks consumed
}

local TooltipCodeIsNeeded
local ServerQueryTime = {}            -- checker for Tooltip server query in function AllYouCanEat:ShowTooltip() to avoid disconnects
local ServerQueryTimeLast = GetTime() -- checker for Tooltip server query in function AllYouCanEat:ShowTooltip() to avoid disconnects

local criteriaTimer = ServerQueryTimeLast
local UPDATE_itemID -- value for CRITERIA_UPDATE
local UPDATE_statID -- value for CRITERIA_UPDATE
local UPDATE_catID  -- value for CRITERIA_UPDATE

local months = {CalendarGetMonthNames()}

local size = {}

size.W_MainFrame = 350
size.W_MinMainFrame = 350
size.W_MaxMainFrame = 500
size.H_Headline = 28
size.H_Status = 20

size.H_SelectionCharList = 20
size.H_SelectionStat = 32+2+10+2+10 --56
size.H_SelectionSearchBox = 20
size.H_SelectionButtonAll = 20

size.H_SelectionAllNormal = 4 + size.H_SelectionCharList + 4 + size.H_SelectionStat + 4 + size.H_SelectionButtonAll-1
size.H_SelectionAllSearch = 4 + size.H_SelectionCharList + 4 + size.H_SelectionStat + 4 + size.H_SelectionSearchBox + 4 + size.H_SelectionButtonAll-1

size.H_DataCur = 3+(1*12)+2+(GUI_Data_curNum*12)+3 -- (GUI_Data_curNum 25) = 320
size.H_DataMin = 3+(1*12)+2+(GUI_Data_minNum*12)+3 -- (GUI_Data_minNum 5)  =  80
size.H_DataMax = 3+(1*12)+2+(GUI_Data_maxNum*12)+3 -- (GUI_Data_maxNum 50) = 620

size.H_MainframeNormal    = (size.H_Headline-1) + size.H_SelectionAllNormal + (size.H_DataCur-1) + (size.H_Status-1) -- 27 + 87 + 320 + 19 = 393
size.H_MainframeMinNormal = (size.H_Headline-1) + size.H_SelectionAllNormal + (size.H_DataMin-1) + (size.H_Status-1) -- 27 + 87 +  80 + 19 = 213
size.H_MainframeMaxNormal = (size.H_Headline-1) + size.H_SelectionAllNormal + (size.H_DataMax-1) + (size.H_Status-1) -- 27 + 87 + 620 + 19 = 753

size.H_MainframeSearch    = (size.H_Headline-1) + size.H_SelectionAllSearch + (size.H_DataCur-1) + (size.H_Status-1) -- 27 + 87 + 320 + 19 = 393
size.H_MainframeMinSearch = (size.H_Headline-1) + size.H_SelectionAllSearch + (size.H_DataMin-1) + (size.H_Status-1) -- 27 + 87 +  80 + 19 = 213
size.H_MainframeMaxSearch = (size.H_Headline-1) + size.H_SelectionAllSearch + (size.H_DataMax-1) + (size.H_Status-1) -- 27 + 87 + 620 + 19 = 753

size.H_charmanagerScrollFrame = 0

local Hooks = {}
function Hooks:SetAction(id)
	local _, item = self:GetItem()
	if not item then return end
	AllYouCanEat:AddNote(self, item)
end
function Hooks:SetAuctionItem()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetAuctionSellItem()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetBagItem()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetHyperlink()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetInboxItem()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetInventoryItem(unit, slot)
	if type(slot) ~= "number" or slot < 0 then return end
	AllYouCanEat:AddNote(self)
end
function Hooks:SetLootItem()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetLootRollItem()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetMerchantCostItem()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetMerchantItem()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetQuestItem()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetQuestLogItem()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetSendMailItem()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetTradePlayerItem()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetTradeSkillItem()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetTradeTargetItem()
	AllYouCanEat:AddNote(self)
end
function Hooks:SetGuildBankItem()
	AllYouCanEat:AddNote(self)
end

local function NOOP() end

local function InstallHooks(tooltip, hooks)
	for name, func in pairs(hooks) do
		hooksecurefunc(tooltip, name, func)
	end
end

local function yearmonthday()
	local YYYY    = date("%Y")
	local MM      = date("%m")
	local Mstring = months[tonumber(MM)]
	local DD      = date("%d")
	return YYYY.."-"..Mstring.."-"..DD
end

local function UpdateTime()
	local hour, minute = GetGameTime()
	if hour < 10 then
		hour = "0"..hour
	end
	if minute < 10 then
		minute = "0"..minute
	end
	GUI_scantime = hour..":"..minute
	
	if AllYouCanEat_Data.chars[playerRealm][playerGUID].savestats then
		AllYouCanEat_Data.chars[playerRealm][playerGUID].update = GUI_scantime.." | "..yearmonthday()
	else
		AllYouCanEat_Data.chars[playerRealm][playerGUID].update = nil
	end
end

local function SetTabButton(name, showIt)
	if showIt then
		_G[name.."Bottom"]:SetTexture(0, 0, 0, 1)
		_G[name.."Border"]:SetTexture(0.4, 0.4, 0.4, 1)
	else
		_G[name.."Bottom"]:SetTexture(0.4, 0.4, 0.4, 1)
		_G[name.."Border"]:SetTexture(0.4, 0.4, 0.4, 0.4)
	end
end

local function ClassHexColor(class)
	local hex = string.format("%.2x%.2x%.2x", classcolors[class].r*255, classcolors[class].g*255, classcolors[class].b*255)
	return hex or "cccccc"
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
function AllYouCanEat:InitOptions()
	SlashCmdList["ALLYOUCANEAT"] = function() AllYouCanEat:MainFrameToggle() end
	SLASH_ALLYOUCANEAT1 = "/allyoucaneat"
	SLASH_ALLYOUCANEAT2 = "/ayce"

	if AllYouCanEat_Options.version == nil then AllYouCanEat_Options.version = 1 end

	if AllYouCanEat_Options.SearchToggle   then SearchFrameIsShown = AllYouCanEat_Options.SearchToggle end
	if AllYouCanEat_Options.Data_SortBy    then GUI_SortBy         = AllYouCanEat_Options.Data_SortBy end
	if AllYouCanEat_Options.Data_SortOrder then GUI_SortOrder      = AllYouCanEat_Options.Data_SortOrder	end
	if AllYouCanEat_Options.Data_Detail    then GUI_Detail         = AllYouCanEat_Options.Data_Detail end
	if AllYouCanEat_Options.Data_Selection then GUI_Selection      = AllYouCanEat_Options.Data_Selection end
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
function AllYouCanEat:LDBcheck()
	if LibStub and LibStub:GetLibrary("CallbackHandler-1.0", true) and LibStub:GetLibrary("LibDataBroker-1.1", true) then
		LibStub:GetLibrary("LibDataBroker-1.1"):NewDataObject("AllYouCanEat", {
			type = "launcher",
			icon = "Interface\\Minimap\\Tracking\\Food",
			OnClick = function(self, button)
				AllYouCanEat:MainFrameToggle()
			end,
		})
	end
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
function AllYouCanEat:CreateInterfaceOptions()
	local options = CreateFrame("Frame", "AllYouCanEat_InterfaceOptions")
	options.name = "AllYouCanEat"

	local title = options:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 16, -16)
	title:SetText("AllYouCanEat")
	title:SetJustifyH("LEFT")
	title:SetJustifyV("TOP")

	CreateFrame("Button", "AllYouCanEat_InterfaceOptions_GUI", AllYouCanEat_InterfaceOptions, "UIPanelButtonTemplate")
	AllYouCanEat_InterfaceOptions_GUI:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -10)
	AllYouCanEat_InterfaceOptions_GUI:SetWidth(120)
	AllYouCanEat_InterfaceOptions_GUI:SetHeight(24)
	AllYouCanEat_InterfaceOptions_GUIText:SetText(L["Open GUI"])
	AllYouCanEat_InterfaceOptions_GUI:SetScript("OnClick", function(self)
		InterfaceOptionsFrame_Show() -- hide InterfaceOptionsFrame
		HideUIPanel(GameMenuFrame) -- hide GameMenuFrame
		AllYouCanEat:MainFrameToggle() -- show GUI
	end)

	InterfaceOptions_AddCategory(options)
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
function AllYouCanEat:InitialStatisticScan()
	--local timerStart = GetTime() -- timecheck

	for i = 1, #StatisticID do
		local statID = StatisticID[i].id
		local total = 0
		local totalcompleted = 0

		if not DATA[statID] then DATA[statID] = {} end

		for j = 1, 1000 do	
			local itemName, _, _, _, _, _, _, itemID, _, criteriaID = GetAchievementCriteriaInfo(statID, j)
			if not itemID then break end
			local _, _, isCompleted = GetAchievementCriteriaInfo(criteriaID)

			if not DATA[statID][itemID] then
				DATA[statID][itemID] = {}
				DATA[statID][itemID].itemlink   = 0
				DATA[statID][itemID].itemname   = itemName
				DATA[statID][itemID].criteriaID = criteriaID
				DATA[statID][itemID].completed  = isCompleted

				-- TEST CODE for future updates START
				--if not AllYouCanEat_Options.TESTDATA then AllYouCanEat_Options.TESTDATA = {} end
				--if not AllYouCanEat_Options.TESTDATA[statID] then AllYouCanEat_Options.TESTDATA[statID] = {} end
				--AllYouCanEat_Options.TESTDATA[statID][itemID] = itemName
				-- TEST CODE for future updates END

				total = total + 1

				if isCompleted then
					totalcompleted = totalcompleted + 1
				end
			end

		end

		DATA[statID].total = total
		DATA[statID].totalcompleted = totalcompleted
	end

	UpdateTime()
	--print("timecheck:", GetTime()-timerStart) --timecheck
end

function AllYouCanEat:SaveCharacterData()
	if not AllYouCanEat_Data.chars              then AllYouCanEat_Data.chars = {} end
	if not AllYouCanEat_Data.chars[playerRealm] then AllYouCanEat_Data.chars[playerRealm] = {}	end
	if not AllYouCanEat_Data.chars[playerRealm][playerGUID] then
		AllYouCanEat_Data.chars[playerRealm][playerGUID] = {}
		AllYouCanEat_Data.chars[playerRealm][playerGUID].name = playerName
		AllYouCanEat_Data.chars[playerRealm][playerGUID].class = playerClass
		AllYouCanEat_Data.chars[playerRealm][playerGUID].faction = playerFaction
		AllYouCanEat_Data.chars[playerRealm][playerGUID].savestats = false
		AllYouCanEat_Data.chars[playerRealm][playerGUID].tooltip = false
	else
		-- check if name, class or faction has changed
		if AllYouCanEat_Data.chars[playerRealm][playerGUID].name ~= playerName or
		   AllYouCanEat_Data.chars[playerRealm][playerGUID].class ~= playerClass or
		   AllYouCanEat_Data.chars[playerRealm][playerGUID].faction ~= playerFaction
		then
			AllYouCanEat_Data.chars[playerRealm][playerGUID].name = playerName
			AllYouCanEat_Data.chars[playerRealm][playerGUID].class = playerClass
			AllYouCanEat_Data.chars[playerRealm][playerGUID].faction = playerFaction
		end
	end
end

function AllYouCanEat:DeleteCharacterData(guid)
	AllYouCanEat_Data.chars[playerRealm][guid] = nil
end

function AllYouCanEat:SaveCharacterStatisticData()
	if not AllYouCanEat_Data.stats then AllYouCanEat_Data.stats = {} end

	for statID, data1 in pairs(DATA) do
		if not AllYouCanEat_Data.stats[statID] then AllYouCanEat_Data.stats[statID] = {} end
		for itemID, data2 in pairs(data1) do
			if itemID ~= "total" and itemID ~= "totalcompleted" then
				if not data2.completed then
					if not AllYouCanEat_Data.stats[statID][itemID] then AllYouCanEat_Data.stats[statID][itemID] = {} end
					AllYouCanEat_Data.stats[statID][itemID][playerGUID] = true
				end
			end
		end
	end

	AllYouCanEat_Data.chars[playerRealm][playerGUID].savestats = true
	AllYouCanEat_Data.chars[playerRealm][playerGUID].update = GUI_scantime.." | "..yearmonthday()
end

function AllYouCanEat:CheckSavedStatisticData()
	-- update saved character statistic data
	if AllYouCanEat_Data.chars[playerRealm][playerGUID].savestats then
		local savestats = AllYouCanEat_Data.chars[playerRealm][playerGUID].savestats
		local tooltip   = AllYouCanEat_Data.chars[playerRealm][playerGUID].tooltip
		AllYouCanEat:DeleteCharacterStatisticData(playerGUID)
		AllYouCanEat_Data.chars[playerRealm][playerGUID].savestats = savestats
		AllYouCanEat_Data.chars[playerRealm][playerGUID].tooltip   = tooltip
		AllYouCanEat:SaveCharacterStatisticData()
	end
end

function AllYouCanEat:DeleteCharacterStatisticData(guid)
	for statID, data1 in pairs(AllYouCanEat_Data.stats) do
		for itemID, data2 in pairs(data1) do
			if AllYouCanEat_Data.stats[statID][itemID][guid] then
				AllYouCanEat_Data.stats[statID][itemID][guid] = nil
			end

			local x = 0
			for k, v in pairs(AllYouCanEat_Data.stats[statID][itemID]) do
				x = x + 1
				break
			end
			if x == 0 then
				AllYouCanEat_Data.stats[statID][itemID] = nil
			end
		end

		local x = 0
		for k, v in pairs(AllYouCanEat_Data.stats[statID]) do
			x = x + 1
			break
		end
		if x == 0 then
			AllYouCanEat_Data.stats[statID] = nil
		end
	end

	local x = 0
	for k, v in pairs(AllYouCanEat_Data.stats) do
		x = x + 1
		break
	end
	if x == 0 then
		AllYouCanEat_Data.stats = nil
	end

	AllYouCanEat_Data.chars[playerRealm][guid].savestats = false
	AllYouCanEat_Data.chars[playerRealm][guid].tooltip = false
	AllYouCanEat_Data.chars[playerRealm][guid].update = nil
end

function AllYouCanEat:CheckIfTooltipCodeIsNeeded()
	local x = 0
	for playerguid, data in pairs(AllYouCanEat_Data.chars[playerRealm]) do
		if data.tooltip == true then
			x = x + 1
			break
		end
	end
	
	if x > 0 then
		TooltipCodeIsNeeded = true
	else
		TooltipCodeIsNeeded = false
	end
end

function AllYouCanEat:ConfirmPopup(message, what)
	if not StaticPopupDialogs["ALLYOUCANEAT_CONFIRM_DIALOG"] then
		StaticPopupDialogs["ALLYOUCANEAT_CONFIRM_DIALOG"] = {}
	end
	local t = StaticPopupDialogs["ALLYOUCANEAT_CONFIRM_DIALOG"]
	for k in pairs(t) do
		t[k] = nil
	end
	t.text = message
	t.button1 = ACCEPT or "Accept"
	t.button2 = CANCEL or "Cancel"
	t.OnAccept = function() AllYouCanEat:ChangeCharacterOption(what) end
	t.timeout = 0
	t.whileDead = 1
	t.hideOnEscape = 1
	StaticPopup_Show("ALLYOUCANEAT_CONFIRM_DIALOG")
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
function AllYouCanEat:TooltipInfoText(itemID, timeElapsed)
	GameTooltip:ClearLines()
	GameTooltip:AddLine("|TInterface\\DialogFrame\\UI-Dialog-Icon-AlertNew:24|t "..L["Unsafe Item"], 1, 0, 0)
	GameTooltip:AddLine(L["ItemID"]..": "..itemID)
	if timeElapsed then
		timeElapsed = math_floor((10 - timeElapsed) * mult2 + 0.5) / mult2
		GameTooltip:AddLine(string.format(L["You can try to start a new server query in %s seconds!"], "|cffffff7f"..timeElapsed.."|r"), 1, 1, 1, 1)
		GameTooltip:AddLine(L["You may be disconnected."], 1, 0.5, 0, 1)
	else
		GameTooltip:AddLine(L["Please wait 5 seconds for next server query."], 1, 1, 1, 1)
	end
end

function AllYouCanEat:ShowTooltip(itemID)
	local _, itemLink = GetItemInfo(itemID)

	GameTooltip:SetOwner(AllYouCanEat_DataFrame, "ANCHOR_BOTTOMRIGHT", 0, 20+(GUI_Data_curNum*12)) -- 3+(12)+2+(GUI_Data_curNum*12)+3 -- (382)

	if itemLink then
		ServerQueryTime[itemID] = nil
		GameTooltip:SetHyperlink(itemLink)
		GameTooltip:Show()
		if DATA[GUI_Selection][itemID].itemlink == 0 then
			DATA[GUI_Selection][itemID].itemlink = 1
			AllYouCanEat:UpdateData()
		end		
	else
		if ServerQueryTime[itemID] then
			local timeElapsed = GetTime() - ServerQueryTime[itemID]
			if timeElapsed > 10 then
				ServerQueryTime[itemID] = nil
			else
				AllYouCanEat:TooltipInfoText(itemID, timeElapsed)
				GameTooltip:Show()
				return
			end
		else
			ServerQueryTime[itemID] = GetTime()
		end

		local QueryIsSave
		if GetTime() - ServerQueryTimeLast > 5 then
			QueryIsSave = true
		end

		if QueryIsSave then
			ServerQueryTimeLast = GetTime()
			GameTooltip:SetHyperlink("item:"..itemID)
			AllYouCanEat:TooltipInfoText(itemID, 0)
		else
			AllYouCanEat:TooltipInfoText(itemID)
		end
		GameTooltip:Show()
	end
end

function AllYouCanEat:AddNote(tooltip, item)
	--local timerStart = GetTime() -- timecheck
	if not TooltipCodeIsNeeded then return end
	local item = item or select(2, tooltip:GetItem())
	if not item then return end
	local itemID = select(3, item:find("item:(%d+)"))
	if not itemID then return end

	itemID = tonumber(itemID)

	local hasID
	local chars = {}

	for i = 1, #StatisticID do
		local statID = StatisticID[i].id
		if DATA[statID][itemID] then
			hasID = true
			if AllYouCanEat_Data.stats and
			   AllYouCanEat_Data.stats[statID] and
			   AllYouCanEat_Data.stats[statID][itemID]
			then
				local x = 1
				for guid in pairs(AllYouCanEat_Data.stats[statID][itemID]) do
					if AllYouCanEat_Data.chars[playerRealm][guid] and
					   AllYouCanEat_Data.chars[playerRealm][guid].savestats and
					   AllYouCanEat_Data.chars[playerRealm][guid].tooltip
					then
						chars[x] = AllYouCanEat_Data.chars[playerRealm][guid].name
						x = x + 1
					end
				end
			end
		end
	end

	if not hasID then return end

	local upval = true

	for guid, data in pairs(AllYouCanEat_Data.chars[playerRealm]) do
		if data.savestats and data.tooltip then

			local notfinish
			for i = 1, #chars do
				if chars[i] == data.name then
					notfinish = true
				end				
			end

			if upval then
				tooltip:AddLine("AllYouCanEat:", 1, 0.5, 0)
				upval = false
			end

			if notfinish then
				tooltip:AddDoubleLine("|cff"..ClassHexColor(data.class)..data.name.."|r", L["not consumed"], 1, 1, 1,  1, 0, 0)
			else
				tooltip:AddDoubleLine("|cff"..ClassHexColor(data.class)..data.name.."|r", L["consumed"], 1, 1, 1,  0, 0.75, 0)
			end

		end
	end

	if tooltip:IsShown() then tooltip:Show() end
	--print("timecheck:", GetTime()-timerStart) --timecheck
end

function AllYouCanEat:LinkWrapper(itemID)
	local _, itemLink = GetItemInfo(itemID)
	if itemLink then
		if IsModifiedClick("CHATLINK") then
			if ChatEdit_InsertLink(itemLink) then
				return true
			end
		end
		if ChatEdit_InsertLink(itemLink) then
			return true
		end
		return false
	end
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
local function TemplateBorderTRBL(frame)
	local texture = frame:CreateTexture(nil, "BORDER")
	texture:SetPoint("TOPLEFT", 1, -1)
	texture:SetPoint("BOTTOMRIGHT", -1, 1)
	texture:SetTexture(0, 0, 0, 1)
	local textureBackground = frame:CreateTexture(nil, "BACKGROUND")
	textureBackground:SetPoint("TOPLEFT", 0, 0)
	textureBackground:SetPoint("BOTTOMRIGHT", 0, 0)
	textureBackground:SetTexture(0.4, 0.4, 0.4, 1)
end

local function TemplateHeadlineButton(button, text, cut)
	local name = button:GetName()
	local texture = button:CreateTexture(nil, "BORDER")
	texture:SetPoint("TOPLEFT", 1, -1)
	texture:SetPoint("BOTTOMRIGHT", -1, 1)
	texture:SetTexture(0, 0, 0, 1)

	local textureBorder = button:CreateTexture(name.."Border", "BACKGROUND")
	textureBorder:SetPoint("TOPLEFT", 0, 0)
	textureBorder:SetPoint("BOTTOMRIGHT", 0, 0)
	textureBorder:SetTexture(0.4, 0.4, 0.4, 1)

	if cut == 1 then
		local textureNormal = button:CreateTexture(nil, "ARTWORK")
		textureNormal:SetPoint("TOPLEFT", 3, -3)
		textureNormal:SetPoint("BOTTOMRIGHT", -3, 3)
		textureNormal:SetTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up")
		textureNormal:SetTexCoord(8/32, 22/32, 10/32, 22/32)
		button:SetNormalTexture(textureNormal)
		local texturePush = button:CreateTexture(nil, "ARTWORK")
		texturePush:SetPoint("TOPLEFT", 4, -4)
		texturePush:SetPoint("BOTTOMRIGHT", -4, 4)
		texturePush:SetTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up")
		texturePush:SetTexCoord(8/32, 22/32, 10/32, 22/32)
		button:SetPushedTexture(texturePush)
	elseif cut == 2 then
		local textureNormal = button:CreateTexture(name.."Background", "ARTWORK")
		textureNormal:SetPoint("TOPLEFT", 3, -3)
		textureNormal:SetPoint("BOTTOMRIGHT", -3, 3)
		textureNormal:SetTexture(1, 1, 1, 0)
		button:SetNormalTexture(textureNormal)
	elseif cut == 3 then
		local textureNormal = button:CreateTexture(nil, "ARTWORK")
		textureNormal:SetPoint("TOPLEFT", 3, -3)
		textureNormal:SetPoint("BOTTOMRIGHT", -3, 3)
		textureNormal:SetTexture("Interface\\Minimap\\Tracking\\None")
		textureNormal:SetTexCoord(3/32, 31/32, 1/32, 29/32)
		button:SetNormalTexture(textureNormal)
		local texturePush = button:CreateTexture(nil, "ARTWORK")
		texturePush:SetPoint("TOPLEFT", 4, -4)
		texturePush:SetPoint("BOTTOMRIGHT", -4, 4)
		texturePush:SetTexture("Interface\\Minimap\\Tracking\\None")
		texturePush:SetTexCoord(3/32, 31/32, 1/32, 29/32)
		button:SetPushedTexture(texturePush)

		local textureDisable = button:CreateTexture(nil, "ARTWORK")
		textureDisable:SetPoint("TOPLEFT", 3, -3)
		textureDisable:SetPoint("BOTTOMRIGHT", -3, 3)
		textureDisable:SetTexture("Interface\\Minimap\\Tracking\\None")
		textureDisable:SetTexCoord(3/32, 31/32, 1/32, 29/32)
		button:SetDisabledTexture(textureDisable)

		local shaderSupported = textureDisable:SetDesaturated(true)
		if not shaderSupported then
			textureDisable:SetVertexColor(0.5, 0.5, 0.5)
		end
	end

	local textureHighlight = button:CreateTexture(nil, "ARTWORK")
	textureHighlight:SetPoint("TOPLEFT", 3, -3)
	textureHighlight:SetPoint("BOTTOMRIGHT", -3, 3)
	textureHighlight:SetTexture(0.6, 0.6, 0.6, 0.2)
	button:SetHighlightTexture(textureHighlight)

	if text then
		local buttontext = button:CreateFontString(name.."Text", "OVERLAY", "GameFontWhiteSmall")
		buttontext:SetText(text)
		buttontext:SetWidth( buttontext:GetStringWidth()+10 )
		buttontext:SetHeight(12)
		buttontext:SetPoint("CENTER", button, "CENTER", 0, 0)
		buttontext:SetJustifyH("CENTER")
		buttontext:SetTextColor(1, 1, 1, 1)
	end
end

local function TemplateTabButton(button, text, detail)
	local name = button:GetName()
	local texture = button:CreateTexture(nil, "BORDER")
	texture:SetPoint("TOPLEFT", 1, -1)
	texture:SetPoint("BOTTOMRIGHT", -1, 1)
	texture:SetTexture(0, 0, 0, 1)

	local textureBorder = button:CreateTexture(name.."Border", "BACKGROUND")
	textureBorder:SetPoint("TOPLEFT", 0, 0)
	textureBorder:SetPoint("BOTTOMRIGHT", -1, 1)
	textureBorder:SetPoint("TOPRIGHT"    ,0, 0)
	textureBorder:SetPoint("BOTTOMLEFT" ,1, 1)
	textureBorder:SetTexture(0.4, 0.4, 0.4, 1)

	local textureBottom = button:CreateTexture(name.."Bottom", "ARTWORK")
	textureBottom:SetPoint("TOPLEFT", button, "BOTTOMLEFT" ,1, 2)
	textureBottom:SetPoint("BOTTOMLEFT"  ,1, 1)
	textureBottom:SetPoint("TOPRIGHT", button, "BOTTOMRIGHT" ,-1, 2)
	textureBottom:SetPoint("BOTTOMRIGHT" ,-1, 1)
	textureBottom:SetTexture(0.4, 0.4, 0.4, 1)

	local textureHighlight = button:CreateTexture(nil, "ARTWORK")
	textureHighlight:SetPoint("TOPLEFT", 3, -3)
	textureHighlight:SetPoint("BOTTOMRIGHT", -3, 3)
	textureHighlight:SetTexture(1, 1, 1, 0.2)
	button:SetHighlightTexture(textureHighlight)

	local buttontext = button:CreateFontString(name.."Text", "OVERLAY", "GameFontNormalSmall")
	buttontext:SetText(text)
	buttontext:SetWidth( buttontext:GetStringWidth()+10 )
	buttontext:SetHeight(12)
	buttontext:SetPoint("CENTER", button, "CENTER", 0, 0)
	buttontext:SetJustifyH("CENTER")

	if detail == 1 then
		buttontext:SetTextColor(1, 1, 1, 1)
	elseif detail == 2 then
		buttontext:SetTextColor(0, 0.75, 0, 1)
	elseif detail == 3 then
		buttontext:SetTextColor(1, 0, 0, 1)
	end
end

local function TemplateCheckButton(button)
	local textureNormal = button:CreateTexture(nil, "ARTWORK")
	textureNormal:SetPoint("TOPLEFT", 0, 0)
	textureNormal:SetPoint("BOTTOMRIGHT", 0, 0)
	textureNormal:SetPoint("CENTER", 0, 0)
	textureNormal:SetTexture("Interface\\Buttons\\UI-CheckBox-Up")
	textureNormal:SetTexCoord(4/32, 27/32, 5/32, 26/32)
	button:SetNormalTexture(textureNormal)

	local textureHighlight = button:CreateTexture(nil, "ARTWORK")
	textureHighlight:SetPoint("TOPLEFT", 1, -1)
	textureHighlight:SetPoint("BOTTOMRIGHT", -1, 1)
	textureHighlight:SetTexture(0.6, 0.6, 0.6, 0.2)
	button:SetHighlightTexture(textureHighlight)

	local texturePush = button:CreateTexture(nil, "ARTWORK")
	texturePush:SetPoint("TOPLEFT", 0, 0)
	texturePush:SetPoint("BOTTOMRIGHT", 0, 0)
	texturePush:SetTexture("Interface\\Buttons\\UI-CheckBox-Down")
	texturePush:SetTexCoord(4/32, 27/32, 5/32, 26/32)
	button:SetPushedTexture(texturePush)

	local textureChecked = button:CreateTexture(nil, "ARTWORK")
	textureChecked:SetWidth(16)
	textureChecked:SetHeight(16)
	textureChecked:SetPoint("CENTER", 0, 0)
	textureChecked:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
	button:SetCheckedTexture(textureChecked)
end

local function TemplateButtonTexture(button, pos)
	local textureNormal = button:CreateTexture(nil, "ARTWORK")
	textureNormal:SetWidth(16)
	textureNormal:SetHeight(16)
	textureNormal:SetPoint("LEFT", 0, 0)
	textureNormal:SetTexture("Interface\\Buttons\\UI-ScrollBar-Scroll"..pos.."Button-Up")
	textureNormal:SetTexCoord(6/32, 25/32, 7/32, 24/32)
	button:SetNormalTexture(textureNormal)

	local texturePush = button:CreateTexture(nil, "ARTWORK")
	texturePush:SetWidth(16)
	texturePush:SetHeight(16)
	texturePush:SetPoint("LEFT", 0, 0)
	texturePush:SetTexture("Interface\\Buttons\\UI-ScrollBar-Scroll"..pos.."Button-Down")
	texturePush:SetTexCoord(6/32, 25/32, 7/32, 24/32)
	button:SetPushedTexture(texturePush)

	local textureHighlight = button:CreateTexture(nil, "ARTWORK")
	textureHighlight:SetWidth(16)
	textureHighlight:SetHeight(16)
	textureHighlight:SetPoint("LEFT", 0, 0)
	textureHighlight:SetTexture("Interface\\Buttons\\UI-ScrollBar-Scroll"..pos.."Button-Highlight")
	textureHighlight:SetTexCoord(6/32, 25/32, 7/32, 24/32)
	button:SetHighlightTexture(textureHighlight)

	local textureDisable = button:CreateTexture(nil, "ARTWORK")
	textureDisable:SetWidth(16)
	textureDisable:SetHeight(16)
	textureDisable:SetPoint("LEFT", 0, 0)
	textureDisable:SetTexture("Interface\\Buttons\\UI-ScrollBar-Scroll"..pos.."Button-Disabled")
	textureDisable:SetTexCoord(6/32, 25/32, 7/32, 24/32)
	button:SetDisabledTexture(textureDisable)

	local shaderSupported = textureDisable:SetDesaturated(true)
	if not shaderSupported then
		textureDisable:SetVertexColor(0.5, 0.5, 0.5)
	end
end

local function TemplateScrollFrame(frame, child)
	local name = frame:GetName()

	frame.offset = 0
	frame:EnableMouseWheel(true)

	local scrollBar = CreateFrame("Slider", name.."ScrollBar", frame)
	scrollBar:SetWidth(16)
	scrollBar:SetHeight(0)
	scrollBar:SetPoint("TOPLEFT", frame, "TOPRIGHT", 2, -16)
	scrollBar:SetPoint("BOTTOMLEFT", frame, "BOTTOMRIGHT", 2, 16)
	scrollBar:SetMinMaxValues(0, 0)
	scrollBar:SetValue(0)
	scrollBar:SetOrientation("VERTICAL")
	scrollBar:EnableMouseWheel(true)
	scrollBar:SetScript("OnValueChanged", function(self, value)
		frame:SetVerticalScroll(value)
	end)
	scrollBar:SetScript("OnMouseWheel", function(self, delta)
		ScrollFrameTemplate_OnMouseWheel(frame, delta)
	end)

	local upButton = CreateFrame("Button",  name.."ScrollBarScrollUpButton", scrollBar)
	upButton:SetWidth(16)
	upButton:SetHeight(16)
	upButton:SetPoint("BOTTOM", scrollBar, "TOP", 0, 0)
	upButton:SetScript("OnClick", function()
		scrollBar:SetValue(scrollBar:GetValue() - (scrollBar:GetHeight() / 2))
		PlaySound("UChatScrollButton")
	end)
	TemplateButtonTexture(upButton, "Up")

	local downButton = CreateFrame("Button",  name.."ScrollBarScrollDownButton", scrollBar)
	downButton:SetWidth(16)
	downButton:SetHeight(16)
	downButton:SetPoint("TOP", scrollBar, "BOTTOM", 0, 0)
	downButton:SetScript("OnClick", function()
		scrollBar:SetValue(scrollBar:GetValue() + (scrollBar:GetHeight() / 2))
		PlaySound("UChatScrollButton")
	end)
	TemplateButtonTexture(downButton, "Down")

	local thumb = scrollBar:CreateTexture(name.."ScrollBarThumbTexture", "BORDER")
	thumb:SetWidth(14)
	thumb:SetHeight(16)
	thumb:SetTexture("Interface\\Buttons\\UI-ScrollBar-Knob")
	thumb:SetTexCoord(8/32, 23/32, 8/32, 23/32)
	scrollBar:SetThumbTexture(thumb)

	frame:SetScript("OnScrollRangeChanged", function(self, xrange, yrange)
		ScrollFrame_OnScrollRangeChanged(self, xrange, yrange)
	end)
	frame:SetScript("OnMouseWheel", function(self, delta)
		ScrollFrameTemplate_OnMouseWheel(self, delta)
	end)
	frame:SetScript("OnVerticalScroll", function(self, off)
		scrollBar:SetValue(off)
	end)

	if child then
		local childFrame = CreateFrame("Frame",  name.."ScrollChildFrame", frame)
		childFrame:SetPoint("TOPLEFT", name, "TOPLEFT", 0, 0)
		childFrame:SetPoint("BOTTOMLEFT", name, "BOTTOMLEFT", 0, 0)
		childFrame:SetHeight(1)
		childFrame:SetWidth(1)
	end
end

local function TemplateDropDownBox(button, text)
	local name = button:GetName()

	local textureNormal = button:CreateTexture(name.."ExpandButton", "ARTWORK")
	textureNormal:SetHeight(14/1.25)
	textureNormal:SetWidth(15/1.25)
	textureNormal:SetPoint("RIGHT", -4, 0)
	textureNormal:SetTexture("Interface\\Buttons\\UI-Panel-ExpandButton-Up")
	textureNormal:SetTexCoord(8/32, 23/32, 9/32, 23/32)
	button:SetNormalTexture(textureNormal)

	local textureHighlight = button:CreateTexture(nil, "ARTWORK")
	textureHighlight:SetPoint("TOPLEFT", 1, -1)
	textureHighlight:SetPoint("BOTTOMRIGHT", -1, 1)
	textureHighlight:SetTexture(0.6, 0.6, 0.6, 0.2)
	button:SetHighlightTexture(textureHighlight)

	local buttontext = button:CreateFontString(name.."Name", "OVERLAY", "GameFontWhiteSmall")
	buttontext:SetWidth(140)
	buttontext:SetHeight(20)
	buttontext:SetPoint("LEFT", button, "LEFT", 4, 0)
	buttontext:SetJustifyH("LEFT")
end

local function TemplateDataListSortButton(button, text, pos, width)
	local name = button:GetName()

	local textureBackground = button:CreateTexture(nil, "BACKGROUND")
	textureBackground:SetPoint("TOPLEFT", 0, 0)
	textureBackground:SetPoint("BOTTOMRIGHT", 0, 0)
	textureBackground:SetTexture(1, 1, 1, 0.1)

	local buttontext
	if text then
		if pos == "right" then
			buttontext = button:CreateFontString(name.."Text", "OVERLAY", "GameFontNormalSmall")
			buttontext:SetText(text)
			local fw = buttontext:GetStringWidth()
			if fw >= width then
				buttontext:SetWidth( width-10 )
			end
			buttontext:SetHeight(12)
			buttontext:SetPoint("RIGHT", button, "RIGHT", 0, 0)
			buttontext:SetJustifyH("RIGHT")
		else
			buttontext = button:CreateFontString(name.."Text", "OVERLAY", "GameFontNormalSmall")
			buttontext:SetText(text)
			local fw = buttontext:GetStringWidth()
			if fw >= width then
				buttontext:SetWidth( width-10 )
			end
			buttontext:SetHeight(12)
			buttontext:SetPoint("LEFT", button, "LEFT", 0, 0)
			buttontext:SetJustifyH("LEFT")
		end
	end

	local texture = button:CreateTexture(name.."Arrow", "BACKGROUND")
	texture:SetWidth(7)
	texture:SetHeight(8)
	texture:SetTexture("Interface\\Buttons\\UI-SortArrow")
	if text then
		if pos == "right" then
			texture:SetPoint("RIGHT", buttontext, "LEFT", -1, 0)
		else
			texture:SetPoint("LEFT", buttontext, "RIGHT", 1, 0)
		end
	else
		texture:SetPoint("CENTER", button, "CENTER", 0, 0)
	end

	local textureHighlight = button:CreateTexture(nil, "ARTWORK")
	textureHighlight:SetPoint("TOPLEFT", 0, 0)
	textureHighlight:SetPoint("BOTTOMRIGHT", 0, 0)
	textureHighlight:SetTexture(1, 1, 1, 0.2)
	button:SetHighlightTexture(textureHighlight)
end

local function TemplateDataList(button, isSort)
	local name = button:GetName()

	if isSort then
		local sort_number = CreateFrame("Button", name.."Button_Number", button)
		TemplateDataListSortButton(sort_number, L["No."], "right", 40)
		sort_number:SetWidth(40)
		sort_number:SetHeight(12)
		sort_number:SetPoint("LEFT", "AllYouCanEat_DataFrame_Sort", "LEFT", 0, 0)
		sort_number:SetScript("OnClick", function() AllYouCanEat:GUIsort(1) end)

		local sort_itemid = CreateFrame("Button", name.."Button_ItemId", button)
		TemplateDataListSortButton(sort_itemid, L["ItemID"], "right", 60)
		sort_itemid:SetWidth(60)
		sort_itemid:SetHeight(12)
		sort_itemid:SetPoint("LEFT", "AllYouCanEat_DataFrame_Sort", "LEFT", 40+2, 0)
		sort_itemid:SetScript("OnClick", function() AllYouCanEat:GUIsort(2) end)

		local sort_itemlink = CreateFrame("Button", name.."Button_ItemLink", button)
		TemplateDataListSortButton(sort_itemlink, nil, "left", 19)
		sort_itemlink:SetWidth(12)
		sort_itemlink:SetHeight(12)
		sort_itemlink:SetPoint("LEFT", "AllYouCanEat_DataFrame_Sort", "LEFT", 40+60+2+2, 0)
		sort_itemlink:SetScript("OnClick", function() AllYouCanEat:GUIsort(3) end)

		local sort_itemname = CreateFrame("Button", name.."Button_ItemName", button)
		TemplateDataListSortButton(sort_itemname, L["Name"], "left", 150)
		sort_itemname:SetWidth(208)
		sort_itemname:SetHeight(12)
		sort_itemname:SetPoint("LEFT", "AllYouCanEat_DataFrame_Sort", "LEFT", 40+60+12+2+2+2, 0)
		sort_itemname:SetScript("OnClick", function() AllYouCanEat:GUIsort(4) end)
	else
		local NumberButton = button:CreateFontString(name.."Number", "ARTWORK", "GameFontNormalSmall")
		NumberButton:SetWidth(40)
		NumberButton:SetHeight(12)
		NumberButton:SetPoint("LEFT", button, "LEFT", 0, 0)
		NumberButton:SetJustifyH("RIGHT")

		local ItemIdButton = button:CreateFontString(name.."ItemId", "ARTWORK", "GameFontWhiteSmall")
		ItemIdButton:SetWidth(60)
		ItemIdButton:SetHeight(12)
		ItemIdButton:SetPoint("LEFT", button, "LEFT", 40+2, 0)
		ItemIdButton:SetJustifyH("RIGHT")

		local ItemLinkButton = button:CreateTexture(name.."ItemLink", "ARTWORK")
		ItemLinkButton:SetWidth(12)--19
		ItemLinkButton:SetHeight(9/(19/12))--9
		ItemLinkButton:SetPoint("LEFT", button, "LEFT", 40+60+2+2, 0)
		ItemLinkButton:SetTexture("Interface\\TradeSkillFrame\\UI-TradeSkill-LinkButton")
		ItemLinkButton:SetAlpha(0.6)

		local ItemNameButton = button:CreateFontString(name.."ItemName", "ARTWORK", "GameFontNormalSmall")
		ItemNameButton:SetWidth(208)
		ItemNameButton:SetHeight(12)
		ItemNameButton:SetPoint("LEFT", button, "LEFT", 40+60+12+2+2+2, 0)
		ItemNameButton:SetJustifyH("LEFT")

		local textureHighlight = button:CreateTexture(nil, "ARTWORK")
		textureHighlight:SetPoint("TOPLEFT", button, "TOPLEFT", 0, 0)
		textureHighlight:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", 0, 0)
		textureHighlight:SetTexture(1, 1, 1, 0.2)
		button:SetHighlightTexture(textureHighlight)

		button:SetScript("OnEnter", function() ItemLinkButton:SetAlpha(1) AllYouCanEat:ShowTooltip(button.itemID) end)
		button:SetScript("OnLeave", function() ItemLinkButton:SetAlpha(0.6) GameTooltip:Hide() end)
		button:SetScript("OnClick", function() AllYouCanEat:LinkWrapper(button.itemID) end)
	end
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
local function SetFrameHeight(height)
	local hx = size.H_SelectionAllNormal
	if SearchFrameIsShown then
		hx = size.H_SelectionAllSearch
	end

	local hmf = height + size.H_Headline-1 + hx-1 + size.H_Status-1 -- height + 28-1 + 88-1 + 20-1
	AllYouCanEat_MainFrame:SetHeight(hmf)
	AllYouCanEat_MainFrame:SetClampRectInsets(0, 0, 0, hmf-size.H_Headline)

	AllYouCanEat_DataFrame:SetHeight(height)

	local hcm = height + hx-1 -- height + 28-1 + 88-1
	AllYouCanEat_CharManager:SetHeight(hcm)

	if (hcm-3-3) <= size.H_charmanagerScrollFrame then
		AllYouCanEat_CharManager_ScrollFrameScrollBarScrollUpButton:SetAlpha(1)
		AllYouCanEat_CharManager_ScrollFrameScrollBarScrollDownButton:SetAlpha(1)
		AllYouCanEat_CharManager_ScrollFrameScrollBarThumbTexture:SetAlpha(1)
	else
		AllYouCanEat_CharManager_ScrollFrameScrollBarScrollUpButton:SetAlpha(0.2)
		AllYouCanEat_CharManager_ScrollFrameScrollBarScrollDownButton:SetAlpha(0.2)
		AllYouCanEat_CharManager_ScrollFrameScrollBarThumbTexture:SetAlpha(0.2)
		AllYouCanEat_CharManager_ScrollFrameScrollBarScrollUpButton:Disable()
		AllYouCanEat_CharManager_ScrollFrameScrollBarScrollDownButton:Disable()
	end
end

local function SetFrameWidth(width)
	AllYouCanEat_MainFrame:SetWidth(width)
	AllYouCanEat_Headline:SetWidth(width)
	AllYouCanEat_Selection:SetWidth(width)
	_G["AllYouCanEat_Selection_"..StatisticID[1].id]:SetPoint("TOPLEFT", "AllYouCanEat_Selection", "TOPLEFT", (width-248)/2, -28) -- (width - ( (#StatisticID*32) + ((#StatisticID-1)*4) ) / 2)

	local w1 = ( width-(3*112)-(2*3) ) / 2
	AllYouCanEat_Selection_ButtonAll:SetPoint("BOTTOMLEFT", "AllYouCanEat_Selection", "BOTTOMLEFT", w1, -1)
	AllYouCanEat_Selection_ButtonComplete:SetPoint("BOTTOMLEFT", "AllYouCanEat_Selection", "BOTTOMLEFT", w1+115, -1) -- , w1+112+3, -1)
	AllYouCanEat_Selection_ButtonIncomplete:SetPoint("BOTTOMLEFT", "AllYouCanEat_Selection", "BOTTOMLEFT", w1+230, -1) -- , w1+112+3+112+3, -1)

	AllYouCanEat_DataFrame:SetWidth(width)
	AllYouCanEat_DataFrame_Sort:SetWidth(width)
	for i = 1, GUI_Data_maxNum do
		_G["AllYouCanEat_DataFrame_Button"..i]:SetWidth(width-24) -- width-3-3-2-16
		_G["AllYouCanEat_DataFrame_Button"..i.."ItemName"]:SetWidth(width-142) -- width-112-3-2-2-2-2-16-3
	end
	_G["AllYouCanEat_DataFrame_SortButton_ItemName"]:SetWidth(width-142) -- width-112-3-2-2-2-2-16-3
	AllYouCanEat_StatusFrame:SetWidth(width)
	AllYouCanEat_CharManager:SetWidth(width)
	AllYouCanEat_CharManager_Opt_RealmName:SetPoint("TOPLEFT", "AllYouCanEat_CharManager_ScrollFrameScrollChildFrame", "TOPLEFT", (width-24-320)/2, -10)
end

local function CalculateFrameSize(width, height)
	local height_data = 20+(GUI_Data_curNum*12) -- 3+(1*12)+2+(GUI_Data_curNum*12)+3
	
	local hx = size.H_SelectionAllNormal
	if SearchFrameIsShown then
		hx = size.H_SelectionAllSearch
	end
	
	local height = height - size.H_Headline+1 - hx+1 - size.H_Status+1
	if height < height_data then
		local diff = height_data - height
		local freq = math_floor(diff/12)
		if freq > 0 then
			GUI_Data_curNum = GUI_Data_curNum - freq
			AllYouCanEat:FillList()
			height = 20+(GUI_Data_curNum*12) -- 3+(1*12)+2+(GUI_Data_curNum*12)+3
		end
	else
		local diff = height - height_data
		local freq = math_floor(diff/12)
		if freq > 0 then
			GUI_Data_curNum = GUI_Data_curNum + freq
			AllYouCanEat:FillList()
			height = 20+(GUI_Data_curNum*12) -- 3+(1*12)+2+(GUI_Data_curNum*12)+3
		end
	end
	
	SetFrameHeight(height)
	SetFrameWidth(width)
end

local function ResizeCheck(frame)
	local width = math_floor(frame:GetWidth() + 0.5)
	local height = math_floor(frame:GetHeight() + 0.5)
	CalculateFrameSize(width, height)
end

local function ResizeEnd(frame)
	frame:SetScript("OnUpdate", nil)
	frame:StopMovingOrSizing()

	SetFrameHeight( 20+(GUI_Data_curNum*12) ) -- 3+(1*12)+2+(GUI_Data_curNum*12)+3
	SetFrameWidth( math_floor(frame:GetWidth() + 0.5) )

	AllYouCanEat:SaveMainFramePos()
end

local function ResizeStart(frame, point)
	frame:SetScript("OnUpdate", function() ResizeCheck(frame) end)
	frame:StartSizing(point)
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
function AllYouCanEat:CreateMainFrame()
	local mainframe = CreateFrame("Frame", "AllYouCanEat_MainFrame", UIParent)
	mainframe:EnableMouse(true)
	mainframe:SetMovable(true)
	mainframe:SetResizable(true)
	mainframe:SetMinResize(size.W_MinMainFrame, size.H_MainframeMinNormal) -- (minWidth, minHeight)
	mainframe:SetMaxResize(size.W_MaxMainFrame, size.H_MainframeMaxNormal) -- (maxWidth, maxHeight)
	mainframe:SetToplevel(true)
	mainframe:SetClampedToScreen(true)
	mainframe:SetClampRectInsets(0, 0, 0, size.H_MainframeNormal-size.H_Headline)
	mainframe:Hide()
	mainframe:SetWidth(size.W_MainFrame)
	mainframe:SetHeight(size.H_MainframeNormal)
	mainframe:SetScript("OnShow", function() AllYouCanEat:MainFrameShow() end)
	mainframe:SetScript("OnHide", function() AllYouCanEat:MainFrameHide() end)

	local moverinfo = CreateFrame("Frame", "AllYouCanEat_MoverInfoTop", mainframe)
	moverinfo:SetWidth(150)
	moverinfo:SetHeight(14)
	moverinfo:SetPoint("BOTTOM", AllYouCanEat_MainFrame, "TOP", 0, 0)
	moverinfo:EnableMouse(true)
	moverinfo:Hide()
	local texture = moverinfo:CreateTexture(nil, "BACKGROUND")
	texture:SetAllPoints(moverinfo)
	texture:SetTexture(0, 0, 0, 0.5)
	local text = moverinfo:CreateFontString("AllYouCanEat_MoverInfoTopText", "ARTWORK", "GameFontWhiteSmall")
	text:SetPoint("CENTER", moverinfo, "CENTER", 0, 0)
	text:SetJustifyH("CENTER")
	text:SetTextColor(0.4, 0.4, 0.4, 1)

	-- Headline Frame START
	local headline = CreateFrame("Frame", "AllYouCanEat_Headline", mainframe)
	TemplateBorderTRBL(headline)
	headline:SetWidth(size.W_MainFrame)
	headline:SetHeight(size.H_Headline)
	headline:SetPoint("TOPLEFT", AllYouCanEat_MainFrame, "TOPLEFT", 0, 0)
	headline:EnableMouse(true)

	local title = headline:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	title:SetPoint("LEFT", headline, "LEFT", 4, 0)
	title:SetJustifyH("RIGHT")
	title:SetText("AllYouCanEat")

	local headlineButtonX = CreateFrame("Button", "AllYouCanEat_Headline_ButtonX", headline)
	TemplateHeadlineButton(headlineButtonX, nil, 1)
	headlineButtonX:SetWidth(20)
	headlineButtonX:SetHeight(20)
	headlineButtonX:SetPoint("RIGHT", AllYouCanEat_Headline, "RIGHT", -4, 0)
	headlineButtonX:SetScript("OnClick", function() AllYouCanEat:MainFrameToggle() end)

	local headlineButtonCharManager = CreateFrame("Button", "AllYouCanEat_Headline_CharManager", headline)
	TemplateHeadlineButton(headlineButtonCharManager, L["CharManager"], 2)
	headlineButtonCharManager:SetWidth( AllYouCanEat_Headline_CharManagerText:GetWidth() + 10 )
	headlineButtonCharManager:SetHeight(20)
	headlineButtonCharManager:SetPoint("RIGHT", AllYouCanEat_Headline_ButtonX, "LEFT", -4, 0)
	headlineButtonCharManager:SetScript("OnClick", function() AllYouCanEat:CharManagerToggle() end)

	local headlineButtonSearch = CreateFrame("Button", "AllYouCanEat_Headline_ButtonSearch", headline)
	TemplateHeadlineButton(headlineButtonSearch, nil, 3)
	headlineButtonSearch:SetWidth(20)
	headlineButtonSearch:SetHeight(20)
	headlineButtonSearch:SetPoint("RIGHT", headlineButtonCharManager, "LEFT", -4, 0)
	headlineButtonSearch:SetScript("OnClick", function() AllYouCanEat:SearchToggle() end)

	local headlineButtonMover = CreateFrame("Button", "AllYouCanEat_Headline_ButtonMover", headline)
	headlineButtonMover:SetWidth(22)
	headlineButtonMover:SetHeight(size.H_Headline)
	headlineButtonMover:SetPoint("LEFT", headline, "LEFT", 0, 0)
	headlineButtonMover:SetPoint("RIGHT", headlineButtonSearch, "LEFT", 0, 0)
	local textureMover = headlineButtonMover:CreateTexture(nil, "BACKGROUND")
	textureMover:SetWidth(1)
	textureMover:SetHeight(1)
	textureMover:SetPoint("LEFT", title, "RIGHT", 0, 0)
	textureMover:SetPoint("TOPRIGHT", headlineButtonMover, "TOPRIGHT", 0, 0)
	textureMover:SetPoint("BOTTOMRIGHT", headlineButtonMover, "BOTTOMRIGHT", 0, 0)
	textureMover:SetTexture(1, 1, 1, 0)
	headlineButtonMover:SetScript("OnEnter", function() AllYouCanEat:MoverInfo("MOVE", "TOP") end)
	headlineButtonMover:SetScript("OnLeave", function() AllYouCanEat:MoverInfo() end)
	headlineButtonMover:SetScript("OnMouseDown", function() AllYouCanEat_MainFrame:StartMoving() end)
	headlineButtonMover:SetScript("OnMouseUp", function() AllYouCanEat_MainFrame:StopMovingOrSizing() AllYouCanEat:SaveMainFramePos() end)
	-- Headline Frame END

	-- Selection Frame START
	local selection = CreateFrame("Frame", "AllYouCanEat_Selection", mainframe)
	TemplateBorderTRBL(selection)
	selection:SetWidth(size.W_MainFrame)
	selection:SetHeight(size.H_SelectionAllNormal)
	selection:SetPoint("TOPLEFT", AllYouCanEat_Headline, "BOTTOMLEFT", 0, 1)
	selection:EnableMouse(true)

	local currentchardata = CreateFrame("Button", "AllYouCanEat_Selection_CharCurrent", selection)
	TemplateDropDownBox(currentchardata)
	TemplateBorderTRBL(currentchardata)
	currentchardata:SetWidth(140)
	currentchardata:SetHeight(20)
	currentchardata:SetPoint("TOP", "AllYouCanEat_Selection", "TOP", 0, -4)
	currentchardata:SetScript("OnClick", function() AllYouCanEat:ToggleCharList() end)

	local selcharlist = CreateFrame("Frame", "AllYouCanEat_Selection_CharList", selection)
	TemplateBorderTRBL(selcharlist)
	selcharlist:SetToplevel(true)
	selcharlist:SetWidth(140)
	selcharlist:SetHeight(GUI_CharListData_maxNum*12+8)
	selcharlist:SetPoint("TOPLEFT", AllYouCanEat_Selection_CharCurrent, "BOTTOMLEFT", 0, 1)
	selcharlist:Hide()

	for i = 1, GUI_CharListData_maxNum do
		local button = CreateFrame("Button", "AllYouCanEat_Selection_CharList_Button"..i, selcharlist)
		button:SetWidth(140)
		button:SetHeight(12)
		if i == 1 then
			button:SetPoint("TOPLEFT", "AllYouCanEat_Selection_CharList", "TOPLEFT", 4, -4)
		else
			button:SetPoint("TOPLEFT", "AllYouCanEat_Selection_CharList_Button"..(i-1), "BOTTOMLEFT", 0, 0)
		end

		local name = button:CreateFontString("AllYouCanEat_Selection_CharList_Button"..i.."Name", "ARTWORK", "GameFontWhiteSmall")
		name:SetWidth(140)
		name:SetHeight(12)
		name:SetPoint("LEFT", button, "LEFT", 0, 0)
		name:SetJustifyH("LEFT")

		local texture = button:CreateTexture("AllYouCanEat_Selection_CharList_Button"..i.."Background", "ARTWORK")
		texture:SetPoint("TOPLEFT", button, "TOPLEFT", 0, 0)
		texture:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -8, 0)
		texture:SetTexture(1, 1, 1, 0)

		local textureHighlight = button:CreateTexture(nil, "ARTWORK")
		textureHighlight:SetPoint("TOPLEFT", button, "TOPLEFT", 0, 0)
		textureHighlight:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -8, 0)
		textureHighlight:SetTexture(1, 1, 1, 0.2)
		button:SetHighlightTexture(textureHighlight)
		
		button:SetScript("OnClick", function(self) AllYouCanEat:SelectNewMainFrameData(self.guid) end)
	end

	AllYouCanEat:UpdateCharSelection()

	for i = 1, #StatisticID do
		local iconbutton = CreateFrame("Button", "AllYouCanEat_Selection_"..StatisticID[i].id, selection)
		iconbutton:SetWidth(32)
		iconbutton:SetHeight(32)
		if i == 1 then
			iconbutton:SetPoint("TOPLEFT", "AllYouCanEat_Selection", "TOPLEFT", 51, -28)
		else
			iconbutton:SetPoint("LEFT", "AllYouCanEat_Selection_"..StatisticID[i-1].id, "RIGHT", 4, 0)
		end
		local icon = iconbutton:CreateTexture("AllYouCanEat_Selection_Icon_"..StatisticID[i].id, "BACKGROUND")
		icon:SetWidth(32)
		icon:SetHeight(32)
		icon:SetAllPoints(iconbutton)
		icon:SetTexture(StatisticID[i].icon)
		local iconborder = iconbutton:CreateTexture("AllYouCanEat_Selection_IconBorder_"..StatisticID[i].id, "ARTWORK")
		iconborder:SetWidth(64)
		iconborder:SetHeight(64)
		iconborder:SetPoint("TOPLEFT", -14, 14)
		iconborder:SetPoint("BOTTOMRIGHT", 14, -14)
		iconborder:SetTexture("Interface\\Buttons\\CheckButtonGlow")
		
		iconbutton:SetScript("OnClick", function()
			if GUI_Selection == StatisticID[i].id then return end
			AllYouCanEat_Options.Data_Selection = StatisticID[i].id
			GUI_Selection = StatisticID[i].id
			AllYouCanEat:UpdateSelectionButtons()
			AllYouCanEat:UpdateData()
		end)

		iconbutton:SetScript("OnEnter", function()
			_G["AllYouCanEat_Selection_Icon_"..StatisticID[i].id]:SetAlpha(1)
		end)

		iconbutton:SetScript("OnLeave", function()
			if GUI_Selection == StatisticID[i].id then return end
			_G["AllYouCanEat_Selection_Icon_"..StatisticID[i].id]:SetAlpha(0.7)
		end)

		local text1 = iconbutton:CreateFontString("AllYouCanEat_Selection_TextCompleted_"..StatisticID[i].id, "ARTWORK", "GameFontWhiteSmall")
		text1:SetPoint("TOP", icon, "BOTTOM", 0, -2)
		text1:SetJustifyH("CENTER")
		--text1:SetTextColor(0, 0.75, 0, 1)
		local text2 = iconbutton:CreateFontString("AllYouCanEat_Selection_TextTotal_"..StatisticID[i].id, "ARTWORK", "GameFontWhiteSmall")
		text2:SetPoint("TOP", text1, "BOTTOM", 0, -2)
		text2:SetJustifyH("CENTER")
		text2:SetTextColor(0.6, 0.6, 0.6, 1)
	end

	AllYouCanEat:UpdateSelectionButtons()

	-- search box START
	local searchBox = CreateFrame("EditBox", "AllYouCanEat_Selection_Search", selection, "InputBoxTemplate")
	searchBox:SetWidth(120)
	searchBox:SetHeight(20)
	searchBox:SetPoint("TOP", selection, "TOP", 0, -88)
	searchBox:SetAutoFocus(false)
	searchBox:Hide()

	AllYouCanEat_Selection_SearchLeft:SetPoint("LEFT", -5, 0)
	AllYouCanEat_Selection_SearchRight:SetPoint("RIGHT", 5, 0)

	searchBox:SetScript("OnShow",         function(self) self:SetAutoFocus(false) end)
	searchBox:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
	searchBox:SetScript("OnTextChanged",  function(self) AllYouCanEat:Search() end)

	local searchBoxIcon = searchBox:CreateTexture(nil, "BACKGROUND")
	searchBoxIcon:SetWidth(18)
	searchBoxIcon:SetHeight(18)
	searchBoxIcon:SetPoint("RIGHT", searchBox, "LEFT", -10 ,0)
	searchBoxIcon:SetTexture("Interface\\Minimap\\Tracking\\None")
	searchBoxIcon:SetTexCoord(3/32, 31/32, 1/32, 29/32)

	local searchclear = CreateFrame("CheckButton", "AllYouCanEat_Selection_SearchClear", searchBox, "UIPanelButtonTemplate2")
	AllYouCanEat_Selection_SearchClearText:SetText("<")
	searchclear:SetWidth(18)
	searchclear:SetHeight(18)
	searchclear:SetPoint("LEFT", searchBox, "RIGHT", 10, 0)
	searchclear:SetScript("OnClick", function() AllYouCanEat:SearchClear() end)
	-- search box END

	local ButtonAll = CreateFrame("Button", "AllYouCanEat_Selection_ButtonAll", selection)
	TemplateTabButton(ButtonAll, L["all"], 1)
	ButtonAll:SetWidth(112)
	ButtonAll:SetHeight(20)
	ButtonAll:SetPoint("BOTTOMLEFT", selection, "BOTTOMLEFT", 4, -1)
	ButtonAll:SetScript("OnClick", function()
		if GUI_Detail == 1 then return end
		AllYouCanEat_Options.Data_Detail = 1
		GUI_Detail = 1
		AllYouCanEat:UpdateData()
	end)

	local ButtonComplete = CreateFrame("Button", "AllYouCanEat_Selection_ButtonComplete", selection)
	TemplateTabButton(ButtonComplete, L["consumed"], 2)
	ButtonComplete:SetWidth(112)
	ButtonComplete:SetHeight(20)
	ButtonComplete:SetPoint("BOTTOMLEFT", selection, "BOTTOMLEFT", 119, -1)
	ButtonComplete:SetScript("OnClick", function()
		if GUI_Detail == 2 then return end
		AllYouCanEat_Options.Data_Detail = 2
		GUI_Detail = 2
		AllYouCanEat:UpdateData()
	end)

	local ButtonIncomplete = CreateFrame("Button", "AllYouCanEat_Selection_ButtonIncomplete", selection)
	TemplateTabButton(ButtonIncomplete, L["not consumed"], 3)
	ButtonIncomplete:SetWidth(112)
	ButtonIncomplete:SetHeight(20)
	ButtonIncomplete:SetPoint("BOTTOMLEFT", selection, "BOTTOMLEFT", 234, -1)
	ButtonIncomplete:SetScript("OnClick", function()
		if GUI_Detail == 3 then return end
		AllYouCanEat_Options.Data_Detail = 3
		GUI_Detail = 3
		AllYouCanEat:UpdateData()
	end)
	-- Selection Frame END

	-- Data Frame START
	local data = CreateFrame("Frame", "AllYouCanEat_DataFrame", mainframe)
	TemplateBorderTRBL(data)
	data:SetWidth(size.W_MainFrame)
	data:SetHeight( 20+(GUI_Data_curNum*12) ) -- 3+(12)+2+(GUI_Data_curNum*12)+3
	data:SetPoint("TOPLEFT", AllYouCanEat_Selection, "BOTTOMLEFT", 0, 1)
	data:EnableMouse(true)
	data:EnableMouseWheel(true)
	data:SetScript("OnMouseWheel", NOOP)

	local datasort = CreateFrame("Frame", "AllYouCanEat_DataFrame_Sort", data)
	datasort:SetWidth(size.W_MainFrame)
	datasort:SetHeight(12)
	datasort:SetPoint("TOPLEFT", data, "TOPLEFT", 3, -3)
	TemplateDataList(datasort, true)

	local dataScrollFrame = CreateFrame("ScrollFrame", "AllYouCanEat_DataFrame_ScrollFrame", data)
	TemplateScrollFrame(dataScrollFrame)
	dataScrollFrame:SetPoint("TOPLEFT", data, "TOPLEFT", 3, -17) -- 3, -(12+2+3)
	dataScrollFrame:SetPoint("BOTTOMRIGHT", data, "BOTTOMRIGHT", -21, 3) -- -(16+3+2), 3
	dataScrollFrame:SetScript("OnVerticalScroll", function() AllYouCanEat:OnVerticalScroll() end)

	for i = 1, GUI_Data_maxNum do
		local button = CreateFrame("Button", "AllYouCanEat_DataFrame_Button"..i, data)
		TemplateDataList(button)
		button:SetWidth(size.W_MainFrame-3-3-16-2)
		button:SetHeight(12)
		if i == 1 then
			button:SetPoint("TOPLEFT", "AllYouCanEat_DataFrame", "TOPLEFT", 3, -17) -- 3, -(12+2+3)
		else
			button:SetPoint("TOPLEFT", "AllYouCanEat_DataFrame_Button"..(i-1), "BOTTOMLEFT", 0, 0)
		end
	end
	-- Data Frame END

	-- Status Frame START
	local status = CreateFrame("Frame", "AllYouCanEat_StatusFrame", mainframe)
	TemplateBorderTRBL(status)
	status:SetWidth(size.W_MainFrame)
	status:SetHeight(size.H_Status)
	status:SetPoint("TOPLEFT", AllYouCanEat_DataFrame, "BOTTOMLEFT", 0, 1)
	status:EnableMouse(true)
	status:SetScript("OnEnter", function() AllYouCanEat:MoverInfo("MOVE", "BOTTOM") end)
	status:SetScript("OnLeave", function() AllYouCanEat:MoverInfo() end)
	status:SetScript("OnMouseDown", function() AllYouCanEat_MainFrame:StartMoving() end)
	status:SetScript("OnMouseUp", function() AllYouCanEat_MainFrame:StopMovingOrSizing() AllYouCanEat:SaveMainFramePos() end)

	local title = status:CreateFontString("AllYouCanEat_StatusFrameText", "ARTWORK", "GameFontWhiteSmall")
	title:SetHeight(20)
	title:SetPoint("CENTER", status)
	title:SetJustifyH("CENTER")

	local resizeBL = CreateFrame("Button", nil, status)
	resizeBL:SetPoint("BOTTOMLEFT", status, "BOTTOMLEFT", 0, 0)
	resizeBL:SetWidth(20)
	resizeBL:SetHeight(20)

	local resizeBLtexture = resizeBL:CreateTexture(nil, "ARTWORK")
	resizeBLtexture:SetPoint("TOPLEFT", 2, -2)
	resizeBLtexture:SetPoint("BOTTOMRIGHT", -2, 2)
	resizeBLtexture:SetAlpha(0.6)
	resizeBLtexture:SetTexture("Interface\\Minimap\\Rotating-MinimapGroupArrow")
	resizeBLtexture:SetTexCoord(0.78125,0.484375 , 0.515625,0.21875 , 0.515625,0.75 , 0.25,0.484375) -- magic

	resizeBL:SetScript("OnMouseDown", function()
		resizeBLtexture:SetPoint("TOPLEFT", 3, -3)
		resizeBLtexture:SetPoint("BOTTOMRIGHT", -3, 3)
		ResizeStart(mainframe, "BOTTOMLEFT")
	end)
	resizeBL:SetScript("OnMouseUp", function()
		resizeBLtexture:SetPoint("TOPLEFT", 2, -2)
		resizeBLtexture:SetPoint("BOTTOMRIGHT", -2, 2)
		ResizeEnd(mainframe)
	end)
	resizeBL:SetScript("OnEnter", function()
		AllYouCanEat:MoverInfo("RESIZE", "BOTTOM")
		resizeBLtexture:SetAlpha(1)
	end)
	resizeBL:SetScript("OnLeave", function()
		AllYouCanEat:MoverInfo()
		resizeBLtexture:SetAlpha(0.6)
	end)

	local resizeBR = CreateFrame("Button", nil, status)
	resizeBR:SetPoint("BOTTOMRIGHT", status, "BOTTOMRIGHT", 0, 0)
	resizeBR:SetWidth(20)
	resizeBR:SetHeight(20)

	local resizeBRtexture = resizeBR:CreateTexture(nil, "ARTWORK")
	resizeBRtexture:SetPoint("TOPLEFT", 2, -2)
	resizeBRtexture:SetPoint("BOTTOMRIGHT", -2, 2)
	resizeBRtexture:SetAlpha(0.6)
	resizeBRtexture:SetTexture("Interface\\Minimap\\Rotating-MinimapGroupArrow")
	resizeBRtexture:SetTexCoord(0.515625,0.75 , 0.78125,0.484375 , 0.25,0.484375 , 0.515625,0.21875) -- magic

	resizeBR:SetScript("OnMouseDown", function()
		resizeBRtexture:SetPoint("TOPLEFT", 3, -3)
		resizeBRtexture:SetPoint("BOTTOMRIGHT", -3, 3)
		ResizeStart(mainframe, "BOTTOMRIGHT")
	end)
	resizeBR:SetScript("OnMouseUp", function()
		resizeBRtexture:SetPoint("TOPLEFT", 2, -2)
		resizeBRtexture:SetPoint("BOTTOMRIGHT", -2, 2)
		ResizeEnd(mainframe)
	end)
	resizeBR:SetScript("OnEnter", function()
		AllYouCanEat:MoverInfo("RESIZE", "BOTTOM")
		resizeBRtexture:SetAlpha(1)
	end)
	resizeBR:SetScript("OnLeave", function()
		AllYouCanEat:MoverInfo()
		resizeBRtexture:SetAlpha(0.6)
	end)

	local moverinfo = CreateFrame("Frame", "AllYouCanEat_MoverInfoBottom", mainframe)
	moverinfo:SetWidth(150)
	moverinfo:SetHeight(14)
	moverinfo:SetPoint("TOP", AllYouCanEat_StatusFrame, "BOTTOM", 0, 0)
	moverinfo:EnableMouse(true)
	moverinfo:Hide()
	local texture = moverinfo:CreateTexture(nil, "BACKGROUND")
	texture:SetAllPoints(moverinfo)
	texture:SetTexture(0, 0, 0, 0.5)
	local text = moverinfo:CreateFontString("AllYouCanEat_MoverInfoBottomText", "ARTWORK", "GameFontWhiteSmall")
	text:SetPoint("CENTER", moverinfo, "CENTER", 0, 0)
	text:SetJustifyH("CENTER")
	text:SetTextColor(0.4, 0.4, 0.4, 1)
	-- Status Frame END

	-- CharManager START
	local charmanager = CreateFrame("Frame", "AllYouCanEat_CharManager", mainframe)
	TemplateBorderTRBL(charmanager)
	charmanager:SetWidth(size.W_MainFrame)
	charmanager:SetHeight(size.H_SelectionAllNormal + (20+(GUI_Data_curNum*12)) - 1) -- 3+(12)+2+(GUI_Data_curNum*12)+3
	charmanager:SetPoint("TOPLEFT", AllYouCanEat_Headline, "BOTTOMLEFT", 0, 1)
	charmanager:EnableMouse(true)
	charmanager:EnableMouseWheel(true)
	charmanager:SetScript("OnMouseWheel", NOOP)
	charmanager:Hide()

	local charmanagerScrollFrame = CreateFrame("ScrollFrame", "AllYouCanEat_CharManager_ScrollFrame", charmanager)
	TemplateScrollFrame(charmanagerScrollFrame, true)
	charmanagerScrollFrame:SetPoint("TOPLEFT", charmanager, "TOPLEFT", 3, -3) -- 3, -(12+2+3)
	charmanagerScrollFrame:SetPoint("BOTTOMRIGHT", charmanager, "BOTTOMRIGHT", -21, 3) -- -(16+3+2), 3
	charmanagerScrollFrame:SetScript("OnVerticalScroll", function()
		AllYouCanEat_CharManager_ScrollFrameScrollBar:SetValue(arg1)
		AllYouCanEat_CharManager_ScrollFrame.offset = math_floor((arg1 / 12) + 0.5)
		AllYouCanEat_CharManager_ScrollFrameScrollChildFrame:SetPoint("TOPLEFT", 0, arg1)

		local a1 = math_floor((size.H_charmanagerScrollFrame-arg1) + 0.5) + 16
		local a2 = math_floor(AllYouCanEat_CharManager:GetHeight() + 0.5)

		if arg1 == 0 then
			AllYouCanEat_CharManager_ScrollFrameScrollBarScrollUpButton:Disable()
		else
			AllYouCanEat_CharManager_ScrollFrameScrollBarScrollUpButton:Enable()
		end
		if a1 == a2 then
			AllYouCanEat_CharManager_ScrollFrameScrollBarScrollDownButton:Disable()
		else
			AllYouCanEat_CharManager_ScrollFrameScrollBarScrollDownButton:Enable()
		end
	end)
	charmanagerScrollFrame:SetScrollChild(AllYouCanEat_CharManager_ScrollFrameScrollChildFrame)

	local realmname = AllYouCanEat_CharManager_ScrollFrameScrollChildFrame:CreateFontString("AllYouCanEat_CharManager_Opt_RealmName", "ARTWORK", "GameFontNormal")
	realmname:SetWidth(320)
	realmname:SetHeight(12)
	realmname:SetPoint("TOPLEFT", AllYouCanEat_CharManager_ScrollFrameScrollChildFrame, "TOPLEFT", 3, -10)
	realmname:SetJustifyH("LEFT")

	local charlist = CreateFrame("Frame", "AllYouCanEat_CharManager_CharList", AllYouCanEat_CharManager_ScrollFrameScrollChildFrame)
	TemplateBorderTRBL(charlist)
	charlist:SetWidth(320)
	charlist:SetHeight(GUI_CharListData_maxNum*12+8)
	charlist:SetPoint("TOPLEFT", AllYouCanEat_CharManager_Opt_RealmName, "BOTTOMLEFT", 0, -10)

	for i = 1, GUI_CharListData_maxNum do
		local button = CreateFrame("Button", "AllYouCanEat_CharManager_CharList_Button"..i, charlist)
		button:SetWidth(320)
		button:SetHeight(12)
		if i == 1 then
			button:SetPoint("TOPLEFT", "AllYouCanEat_CharManager_CharList", "TOPLEFT", 4, -4)
		else
			button:SetPoint("TOPLEFT", "AllYouCanEat_CharManager_CharList_Button"..(i-1), "BOTTOMLEFT", 0, 0)
		end

		local name = button:CreateFontString("AllYouCanEat_CharManager_CharList_Button"..i.."Name", "ARTWORK", "GameFontWhiteSmall")
		name:SetWidth(100)
		name:SetHeight(12)
		name:SetPoint("LEFT", button, "LEFT", 0, 0)
		name:SetJustifyH("LEFT")

		local name = button:CreateFontString("AllYouCanEat_CharManager_CharList_Button"..i.."SaveStats", "ARTWORK", "GameFontWhiteSmall")
		name:SetWidth(110)
		name:SetHeight(12)
		name:SetPoint("LEFT", button, "LEFT", 100, 0)
		name:SetJustifyH("CENTER")

		local name = button:CreateFontString("AllYouCanEat_CharManager_CharList_Button"..i.."Tooltip", "ARTWORK", "GameFontWhiteSmall")
		name:SetWidth(110-8)
		name:SetHeight(12)
		name:SetPoint("LEFT", button, "LEFT", 210, 0)
		name:SetJustifyH("CENTER")

		local texture = button:CreateTexture("AllYouCanEat_CharManager_CharList_Button"..i.."Background", "ARTWORK")
		texture:SetPoint("TOPLEFT", button, "TOPLEFT", 0, 0)
		texture:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -8, 0)
		texture:SetTexture(1, 1, 1, 0)

		local textureHighlight = button:CreateTexture(nil, "ARTWORK")
		textureHighlight:SetPoint("TOPLEFT", button, "TOPLEFT", 0, 0)
		textureHighlight:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -8, 0)
		textureHighlight:SetTexture(1, 1, 1, 0.2)
		button:SetHighlightTexture(textureHighlight)

		button:SetScript("OnClick", function(self) AllYouCanEat:SetupCharacterOptions(self.guid) end)
	end

	local charname = AllYouCanEat_CharManager_ScrollFrameScrollChildFrame:CreateFontString("AllYouCanEat_CharManager_Opt_CharName", "ARTWORK", "GameFontNormal")
	charname:SetWidth(320)
	charname:SetHeight(12)
	charname:SetPoint("TOPLEFT", AllYouCanEat_CharManager_CharList, "BOTTOMLEFT", 0, -20)
	charname:SetJustifyH("LEFT")

	local savestatus = AllYouCanEat_CharManager_ScrollFrameScrollChildFrame:CreateFontString("AllYouCanEat_CharManager_Opt_SaveStatus_Text", "ARTWORK", "GameFontWhiteSmall")
	savestatus:SetPoint("TOPLEFT", AllYouCanEat_CharManager_Opt_CharName, "BOTTOMLEFT", 0, -10)
	savestatus:SetNonSpaceWrap(true)
	savestatus:SetJustifyH("LEFT")

	CreateFrame("CheckButton", "AllYouCanEat_CharManager_Opt_SaveStats", AllYouCanEat_CharManager_ScrollFrameScrollChildFrame, "UIPanelButtonTemplate2")
	AllYouCanEat_CharManager_Opt_SaveStatsText:SetText(L["Save Data"])
	AllYouCanEat_CharManager_Opt_SaveStats:SetWidth(155)
	AllYouCanEat_CharManager_Opt_SaveStats:SetHeight(24)
	AllYouCanEat_CharManager_Opt_SaveStats:SetPoint("TOPLEFT", AllYouCanEat_CharManager_Opt_SaveStatus_Text, "BOTTOMLEFT", 0, -5)
	AllYouCanEat_CharManager_Opt_SaveStats:SetScript("OnClick", function()
		AllYouCanEat:ChangeCharacterOption("savestats")
	end)

	CreateFrame("CheckButton", "AllYouCanEat_CharManager_Opt_DeleteStats", AllYouCanEat_CharManager_ScrollFrameScrollChildFrame, "UIPanelButtonTemplate2")
	AllYouCanEat_CharManager_Opt_DeleteStatsText:SetText(L["Delete Data"])
	AllYouCanEat_CharManager_Opt_DeleteStats:SetWidth(155)
	AllYouCanEat_CharManager_Opt_DeleteStats:SetHeight(24)
	AllYouCanEat_CharManager_Opt_DeleteStats:SetPoint("TOPLEFT", AllYouCanEat_CharManager_Opt_SaveStats, "TOPRIGHT", 10, 0)
	AllYouCanEat_CharManager_Opt_DeleteStats:SetScript("OnClick", function()
		AllYouCanEat:ConfirmPopup(L["Do you really want to delete the data from this character?"], "deletestats")
	end)

	local text = AllYouCanEat_CharManager_Opt_SaveStats:CreateFontString("AllYouCanEat_CharManager_Opt_SaveStats_Text", "ARTWORK", "GameFontWhiteSmall")
	text:SetPoint("TOPLEFT", AllYouCanEat_CharManager_Opt_SaveStats, "BOTTOMLEFT", 0, -5)
	text:SetWidth(320)
	text:SetNonSpaceWrap(true)
	text:SetJustifyH("LEFT")
	text:SetText(L["Saves the statistics data from this character to SavedVariable, so you can view it with other characters."])

	CreateFrame("CheckButton", "AllYouCanEat_CharManager_Opt_ShowInTooltip", AllYouCanEat_CharManager_ScrollFrameScrollChildFrame, "UICheckButtonTemplate")
	TemplateCheckButton(AllYouCanEat_CharManager_Opt_ShowInTooltip)
	AllYouCanEat_CharManager_Opt_ShowInTooltipText:SetText(L["Show statistic data in GameTooltip"])
	AllYouCanEat_CharManager_Opt_ShowInTooltipText:SetPoint("LEFT", AllYouCanEat_CharManager_Opt_ShowInTooltip, "RIGHT", 4, 0)
	AllYouCanEat_CharManager_Opt_ShowInTooltip:SetWidth(14)
	AllYouCanEat_CharManager_Opt_ShowInTooltip:SetHeight(14)
	AllYouCanEat_CharManager_Opt_ShowInTooltip:SetPoint("TOPLEFT", AllYouCanEat_CharManager_Opt_SaveStats_Text, "BOTTOMLEFT", 0, -20)
	AllYouCanEat_CharManager_Opt_ShowInTooltip:SetScript("OnClick", function()
		AllYouCanEat:ChangeCharacterOption("tooltip")
	end)

	CreateFrame("CheckButton", "AllYouCanEat_CharManager_Opt_RemoveChar", AllYouCanEat_CharManager_ScrollFrameScrollChildFrame, "UIPanelButtonTemplate2")
	AllYouCanEat_CharManager_Opt_RemoveCharText:SetText(L["Remove Character"])
	AllYouCanEat_CharManager_Opt_RemoveChar:SetWidth(180)
	AllYouCanEat_CharManager_Opt_RemoveChar:SetHeight(24)
	AllYouCanEat_CharManager_Opt_RemoveChar:SetPoint("TOPLEFT", AllYouCanEat_CharManager_Opt_ShowInTooltip, "BOTTOMLEFT", 0, -20)
	AllYouCanEat_CharManager_Opt_RemoveChar:SetScript("OnClick", function()
		AllYouCanEat:ConfirmPopup(L["Do you really want to remove this character?"], "removechar")
	end)

	local text = AllYouCanEat_CharManager_Opt_RemoveChar:CreateFontString("AllYouCanEat_CharManager_Opt_RemoveChar_Text", "ARTWORK", "GameFontWhiteSmall")
	text:SetPoint("TOPLEFT", AllYouCanEat_CharManager_Opt_RemoveChar, "BOTTOMLEFT", 0, -5)
	text:SetWidth(320)
	text:SetNonSpaceWrap(true)
	text:SetJustifyH("LEFT")
	text:SetText("("..L["Only useful if a character was permanently deleted."]..")")
	-- CharManager END

	--local h = 10 + 12 + 10 + (GUI_CharListData_maxNum*12+8) + 20 + 12 + 10 + 12 + 5 + 24 + 5 + AllYouCanEat_CharManager_Opt_SaveStats_Text:GetStringHeight() + 20 + 14 + 20 + 24 + 5 + AllYouCanEat_CharManager_Opt_RemoveChar_Text:GetHeight()
	local h = 10 + 12 + 10 + (GUI_CharListData_maxNum*12+8) + 20 + 12 + 10 + 12 + 5 + 24 + 5 +  30  + 20 + 14 + 20 + 24 + 5 +  20

	size.H_charmanagerScrollFrame = math_floor(h + 0.5)

	charmanagerScrollFrame:SetHeight(size.H_charmanagerScrollFrame)
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
function AllYouCanEat:ChangeCharacterOption(what)
	local guid = AllYouCanEat_CharManager_Opt_CharName.guid

	if what == "savestats" then
		AllYouCanEat:SaveCharacterStatisticData()
	elseif what == "deletestats" then
		AllYouCanEat:DeleteCharacterStatisticData(guid)
	elseif what == "removechar" then
		AllYouCanEat:DeleteCharacterStatisticData(guid)
		AllYouCanEat:DeleteCharacterData(guid)
		guid = playerGUID
	elseif what == "tooltip" then
		for playerrealm in pairs(AllYouCanEat_Data.chars) do
			for playerguid, data in pairs(AllYouCanEat_Data.chars[playerrealm]) do
				if playerguid == guid then
					data.tooltip = not data.tooltip
					break
				end
			end
		end
		AllYouCanEat:CheckIfTooltipCodeIsNeeded()
	end
	AllYouCanEat:SetupCharacterOptions(guid)
end

function AllYouCanEat:SetupCharacterOptions(guid)
	local name = ""
	local class = "PRIEST"
	local tooltip = false
	local savestats = false

	for playerrealm in pairs(AllYouCanEat_Data.chars) do
		for playerguid, data in pairs(AllYouCanEat_Data.chars[playerrealm]) do
			if playerguid == guid then
				name = data.name
				class = data.class
				if data.tooltip then
					tooltip = true
				end
				if data.savestats then
					savestats = true
				end
				break
			end
		end
	end

	-- realmname START
	AllYouCanEat_CharManager_Opt_RealmName:SetText(playerRealm)
	-- realmname END

	-- charname START
	AllYouCanEat_CharManager_Opt_CharName:SetText(L["Options for:"].." |cff"..ClassHexColor(class)..name.."|r")
	AllYouCanEat_CharManager_Opt_CharName.guid = guid
	-- charname END

	-- save status START
	if savestats then
		AllYouCanEat_CharManager_Opt_SaveStatus_Text:SetText(L["Status:"].." "..L["SAVED"])
		AllYouCanEat_CharManager_Opt_SaveStatus_Text:SetTextColor(0, 0.75, 0, 1)
	else
		AllYouCanEat_CharManager_Opt_SaveStatus_Text:SetText(L["Status:"].." "..L["NOT SAVED"])
		AllYouCanEat_CharManager_Opt_SaveStatus_Text:SetTextColor(1, 0, 0, 1)
	end
	-- save status END

	-- save/delete button START
	if playerGUID == guid then
		if savestats then
			AllYouCanEat_CharManager_Opt_SaveStats:Disable()
			AllYouCanEat_CharManager_Opt_DeleteStats:Enable()
		else
			AllYouCanEat_CharManager_Opt_SaveStats:Enable()
			AllYouCanEat_CharManager_Opt_DeleteStats:Disable()
		end
		AllYouCanEat_CharManager_Opt_SaveStats_Text:SetTextColor(1, 1, 1, 1)
	else
		if savestats then
			AllYouCanEat_CharManager_Opt_SaveStats:Disable()
			AllYouCanEat_CharManager_Opt_DeleteStats:Enable()
		else
			AllYouCanEat_CharManager_Opt_SaveStats:Disable()
			AllYouCanEat_CharManager_Opt_DeleteStats:Disable()
		end
		AllYouCanEat_CharManager_Opt_SaveStats_Text:SetTextColor(0.3, 0.3, 0.3, 1)
	end
	-- save/delete button END

	-- tooltip START
	if savestats then
		AllYouCanEat_CharManager_Opt_ShowInTooltip:Enable()
		AllYouCanEat_CharManager_Opt_ShowInTooltipText:SetTextColor(1, 1, 1, 1)
	else
		AllYouCanEat_CharManager_Opt_ShowInTooltip:Disable()
		AllYouCanEat_CharManager_Opt_ShowInTooltipText:SetTextColor(0.3, 0.3, 0.3, 1)
	end
	AllYouCanEat_CharManager_Opt_ShowInTooltip:SetChecked(tooltip)
	-- tooltip END
	
	-- remove char START
	if playerGUID == guid then
		AllYouCanEat_CharManager_Opt_RemoveChar:Disable()
		AllYouCanEat_CharManager_Opt_RemoveChar_Text:SetTextColor(0.3, 0.3, 0.3, 1)
	else
		AllYouCanEat_CharManager_Opt_RemoveChar:Enable()
		AllYouCanEat_CharManager_Opt_RemoveChar_Text:SetTextColor(1, 1, 1, 1)
	end
	-- remove char END
	AllYouCanEat:UpdateData_CharList()
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
function AllYouCanEat:UpdateData_CharList()
	table.wipe(GUI_CharListData)

	local x = 1
	for k, v in pairs(AllYouCanEat_Data.chars[playerRealm]) do
		GUI_CharListData[x] = {}
		GUI_CharListData[x].name = v.name
		GUI_CharListData[x].class = v.class
		if v.savestats then
			GUI_CharListData[x].savestats = "|cff00bf00"..L["SAVED"].."|r"
		else
			GUI_CharListData[x].savestats = "|cffff0000"..L["NOT SAVED"].."|r"
		end
		if v.tooltip then
			GUI_CharListData[x].tooltip = L["TOOLTIP"]
		end
		GUI_CharListData[x].guid = k
		x = x + 1
	end

	table.sort(GUI_CharListData, function(a, b)
		if a.name < b.name then
			return true
		end
	end)

	for i = 1, GUI_CharListData_maxNum do
		_G["AllYouCanEat_CharManager_CharList_Button"..i]:Hide()
	end

	for i = 1, #GUI_CharListData do
		if GUI_CharListData[i].guid == AllYouCanEat_CharManager_Opt_CharName.guid then
			_G["AllYouCanEat_CharManager_CharList_Button"..i.."Background"]:SetTexture(1, 1, 1, 0.1)
		else
			_G["AllYouCanEat_CharManager_CharList_Button"..i.."Background"]:SetTexture(1, 1, 1, 0)
		end

		_G["AllYouCanEat_CharManager_CharList_Button"..i.."Name"]:SetText("|cff"..ClassHexColor(GUI_CharListData[i].class)..GUI_CharListData[i].name.."|r")
		_G["AllYouCanEat_CharManager_CharList_Button"..i.."SaveStats"]:SetText(GUI_CharListData[i].savestats)
		_G["AllYouCanEat_CharManager_CharList_Button"..i.."Tooltip"]:SetText(GUI_CharListData[i].tooltip)
		_G["AllYouCanEat_CharManager_CharList_Button"..i]:Show()
		_G["AllYouCanEat_CharManager_CharList_Button"..i].guid = GUI_CharListData[i].guid
	end
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
function AllYouCanEat:ToggleCharList()
	if AllYouCanEat_Selection_CharList:IsShown() then
		AllYouCanEat_Selection_CharList:Hide()
		AllYouCanEat_Selection_CharCurrentExpandButton:SetTexture("Interface\\Buttons\\UI-Panel-ExpandButton-Up")
	else
		AllYouCanEat_Selection_CharList:Show()
		AllYouCanEat_Selection_CharCurrentExpandButton:SetTexture("Interface\\Buttons\\UI-Panel-CollapseButton-Up")
	end
end

function AllYouCanEat:UpdateCharSelection()
	local temp = {}

	local x = 1
	for k, v in pairs(AllYouCanEat_Data.chars[playerRealm]) do
		temp[x] = {}
		temp[x].name = v.name
		temp[x].class = v.class
		temp[x].savestats = v.savestats
		temp[x].guid = k
		x = x + 1
	end

	table.sort(temp, function(a, b)
		if a.name < b.name then
			return true
		end
	end)

	for i = 1, GUI_CharListData_maxNum do
		_G["AllYouCanEat_Selection_CharList_Button"..i]:Hide()
	end

	local currName
	for i = 1, #temp do
		if temp[i].guid == GUI_MainDataGUID then
			_G["AllYouCanEat_Selection_CharList_Button"..i.."Background"]:SetTexture(1, 1, 1, 0.1)
			currName = "|cff"..ClassHexColor(temp[i].class)..temp[i].name.."|r"
		else
			_G["AllYouCanEat_Selection_CharList_Button"..i.."Background"]:SetTexture(1, 1, 1, 0)
		end

		_G["AllYouCanEat_Selection_CharList_Button"..i.."Name"]:SetText("|cff"..ClassHexColor(temp[i].class)..temp[i].name.."|r")
		_G["AllYouCanEat_Selection_CharList_Button"..i]:Show()
		_G["AllYouCanEat_Selection_CharList_Button"..i].guid = temp[i].guid
		if not temp[i].savestats and temp[i].guid ~= playerGUID then
			_G["AllYouCanEat_Selection_CharList_Button"..i]:SetScript("OnClick", nil)
			_G["AllYouCanEat_Selection_CharList_Button"..i.."Name"]:SetText("|cff444444"..temp[i].name.."|r")
		end
	end

	AllYouCanEat_Selection_CharCurrentName:SetText(currName)
	AllYouCanEat_Selection_CharList:SetHeight(#temp*12+8)

	table.wipe(temp)
end

function AllYouCanEat:SelectNewMainFrameData(guid)
	GUI_MainDataGUID = guid
	AllYouCanEat:UpdateCharSelection()
	AllYouCanEat:ToggleCharList()
	AllYouCanEat:UpdateData()
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
function AllYouCanEat:InitializeFrame()
	AllYouCanEat:UpdateSortButtons()
	if SearchFrameIsShown then
		AllYouCanEat:SearchFrameShow()
	end
	if AllYouCanEat_Options.MainFrame_width then
		AllYouCanEat:UpdateData()
		CalculateFrameSize(AllYouCanEat_Options.MainFrame_width, AllYouCanEat_Options.MainFrame_height)
	end
end

function AllYouCanEat:MainFrameToggle()
	if AllYouCanEat_MainFrame:IsShown() then
		AllYouCanEat_MainFrame:Hide()
	else
		AllYouCanEat_MainFrame:Show()
		AllYouCanEat:CharManagerToggle(true)
	end
end

function AllYouCanEat:CharManagerToggle(force)
	if AllYouCanEat_CharManager:IsShown() or force then
		AllYouCanEat_CharManager:Hide()
		AllYouCanEat_Headline_CharManagerBackground:SetTexture(1, 1, 1, 0)
		AllYouCanEat_Selection:Show()
		AllYouCanEat_DataFrame:Show()
		AllYouCanEat:UpdateStatusText() -- status text update
		AllYouCanEat_StatusFrame:SetPoint("TOPLEFT", AllYouCanEat_DataFrame, "BOTTOMLEFT", 0, 1)
		AllYouCanEat_Headline_ButtonSearch:Enable()
		AllYouCanEat_Headline_ButtonSearchBorder:SetTexture(0.4, 0.4, 0.4, 1)
	else
		AllYouCanEat_CharManager:Show()
		AllYouCanEat:SetupCharacterOptions(playerGUID)
		AllYouCanEat_Headline_CharManagerBackground:SetTexture(0.6, 0.6, 0.6, 0.5)
		AllYouCanEat_Selection:Hide()
		AllYouCanEat_DataFrame:Hide()
		AllYouCanEat_StatusFrameText:SetText("") -- status text update
		AllYouCanEat_StatusFrame:SetPoint("TOPLEFT", AllYouCanEat_CharManager, "BOTTOMLEFT", 0, 1)
		AllYouCanEat_Headline_ButtonSearch:Disable()
		AllYouCanEat_Headline_ButtonSearchBorder:SetTexture(0.2, 0.2, 0.2, 1)
	end
end

function AllYouCanEat:MainFramePos()
	if AllYouCanEat_Options.MainFrame_relP then
		AllYouCanEat_MainFrame:ClearAllPoints()
		AllYouCanEat_MainFrame:SetPoint(AllYouCanEat_Options.MainFrame_relP, AllYouCanEat_Options.MainFrame_posX, AllYouCanEat_Options.MainFrame_posY)
	else
		AllYouCanEat_MainFrame:ClearAllPoints()
		AllYouCanEat_MainFrame:SetPoint("CENTER", 0, 100)
	end
end

function AllYouCanEat:MainFrameHide()
	PlaySound("igQuestListClose")
	AllYouCanEat_InterfaceOptions_GUI:Enable()
end

function AllYouCanEat:MainFrameShow()
	PlaySound("igQuestListOpen")
	AllYouCanEat_InterfaceOptions_GUI:Disable()
	AllYouCanEat:MainFramePos()
	AllYouCanEat:UpdateData()
end

function AllYouCanEat:SaveMainFramePos()
	local point, relativeTo, relativePoint, x, y = AllYouCanEat_MainFrame:GetPoint()
	AllYouCanEat_Options.MainFrame_posX = x
	AllYouCanEat_Options.MainFrame_posY = y
	AllYouCanEat_Options.MainFrame_relP = relativePoint
	AllYouCanEat_Options.MainFrame_width = math_floor(AllYouCanEat_MainFrame:GetWidth() + 0.5)
	AllYouCanEat_Options.MainFrame_height = math_floor(AllYouCanEat_MainFrame:GetHeight() + 0.5)
end

function AllYouCanEat:SearchToggle()
	if AllYouCanEat_Selection_Search:IsShown() then
		AllYouCanEat:SearchFrameHide()
		--AllYouCanEat_Headline_ButtonSearchBackground:SetTexture(1, 1, 1, 0)
		AllYouCanEat:UpdateData()
	else
		AllYouCanEat:SearchFrameShow()
		--AllYouCanEat_Headline_ButtonSearchBackground:SetTexture(0.6, 0.6, 0.6, 0.5)
	end
	ResizeEnd(AllYouCanEat_MainFrame)
end

function AllYouCanEat:SearchFrameHide()
	SearchQuery = nil
	AllYouCanEat_Selection_Search:SetText("")
	AllYouCanEat_Selection_Search:Hide()
	SearchFrameIsShown = false
	AllYouCanEat_Options.SearchToggle = false
	AllYouCanEat_Selection:SetHeight(size.H_SelectionAllNormal)
	AllYouCanEat_CharManager:SetHeight(size.H_SelectionAllNormal + (20+(GUI_Data_curNum*12)) - 1 + 20-1) -- 3+(12)+2+(GUI_Data_curNum*12)+3
	AllYouCanEat_MainFrame:SetMinResize(size.W_MinMainFrame, size.H_MainframeMinNormal)
	AllYouCanEat_MainFrame:SetMaxResize(size.W_MaxMainFrame, size.H_MainframeMaxNormal)
end

function AllYouCanEat:SearchFrameShow()
	AllYouCanEat_Selection_Search:Show()
	SearchFrameIsShown = true
	AllYouCanEat_Options.SearchToggle = true
	AllYouCanEat_Selection:SetHeight(size.H_SelectionAllSearch)
	AllYouCanEat_CharManager:SetHeight(size.H_SelectionAllSearch + (20+(GUI_Data_curNum*12)) - 1 + 20-1) -- 3+(12)+2+(GUI_Data_curNum*12)+3
	AllYouCanEat_MainFrame:SetMinResize(size.W_MinMainFrame, size.H_MainframeMinSearch)
	AllYouCanEat_MainFrame:SetMaxResize(size.W_MaxMainFrame, size.H_MainframeMaxSearch)
end

function AllYouCanEat:Search()
	SearchQuery = AllYouCanEat_Selection_Search:GetText()
	if SearchQuery == "" then
		SearchQuery = nil
	end
	AllYouCanEat:UpdateData()
end

function AllYouCanEat:SearchClear()
	AllYouCanEat_Selection_Search:SetText("")
	SearchQuery = nil 
end

function AllYouCanEat:MoverInfo(action, where)
	if not action then
		AllYouCanEat_MoverInfoTop:Hide()
		AllYouCanEat_MoverInfoBottom:Hide()
		return
	end

	if action == "MOVE" then
		AllYouCanEat_MoverInfoTopText:SetText(L["click & move"])
		AllYouCanEat_MoverInfoBottomText:SetText(L["click & move"])
	else
		AllYouCanEat_MoverInfoTopText:SetText(L["click & resize"])
		AllYouCanEat_MoverInfoBottomText:SetText(L["click & resize"])
	end

	if where == "TOP" then
		AllYouCanEat_MoverInfoTop:Show()
	else
		AllYouCanEat_MoverInfoBottom:Show()
	end
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
function AllYouCanEat:UpdateData()
	AllYouCanEat:CreateGUIdata()
	AllYouCanEat:FillList()
	AllYouCanEat:UpdateStatus()

	if GUI_Detail == 1 then
		SetTabButton("AllYouCanEat_Selection_ButtonAll", true)
		SetTabButton("AllYouCanEat_Selection_ButtonComplete", nil)
		SetTabButton("AllYouCanEat_Selection_ButtonIncomplete", nil)
	elseif GUI_Detail == 2 then
		SetTabButton("AllYouCanEat_Selection_ButtonAll", nil)
		SetTabButton("AllYouCanEat_Selection_ButtonComplete", true)
		SetTabButton("AllYouCanEat_Selection_ButtonIncomplete", nil)
	elseif GUI_Detail == 3 then
		SetTabButton("AllYouCanEat_Selection_ButtonAll", nil)
		SetTabButton("AllYouCanEat_Selection_ButtonComplete", nil)
		SetTabButton("AllYouCanEat_Selection_ButtonIncomplete", true)
	end
end

function AllYouCanEat:UpdateSelectionButtons()
	for i = 1, #StatisticID do
		if GUI_Selection == StatisticID[i].id then
			_G["AllYouCanEat_Selection_IconBorder_"..StatisticID[i].id]:Show()
			_G["AllYouCanEat_Selection_Icon_"..StatisticID[i].id]:SetAlpha(1)
		else
			_G["AllYouCanEat_Selection_IconBorder_"..StatisticID[i].id]:Hide()
			_G["AllYouCanEat_Selection_Icon_"..StatisticID[i].id]:SetAlpha(0.7)
		end
	end
end

function AllYouCanEat:UpdateStatusText()
	if GUI_MainDataGUID == playerGUID then
		AllYouCanEat_StatusFrameText:SetText(L["Latest Update"]..": "..GUI_scantime)
	else
		local updateTime
		if AllYouCanEat_Data.chars and
		   AllYouCanEat_Data.chars[playerRealm] and
		   AllYouCanEat_Data.chars[playerRealm][GUI_MainDataGUID] and
		   AllYouCanEat_Data.chars[playerRealm][GUI_MainDataGUID].update
		then
			updateTime = AllYouCanEat_Data.chars[playerRealm][GUI_MainDataGUID].update
		else
			updateTime = UNKNOWN
		end
		AllYouCanEat_StatusFrameText:SetText(L["Latest Update"]..": "..updateTime)
	end
end

function AllYouCanEat:UpdateStatus()
	if GUI_MainDataGUID == playerGUID then
		for i = 1, #StatisticID do
			_G["AllYouCanEat_Selection_TextCompleted_"..StatisticID[i].id]:SetText(DATA[StatisticID[i].id].totalcompleted)
			_G["AllYouCanEat_Selection_TextTotal_"..StatisticID[i].id]:SetText("("..DATA[StatisticID[i].id].total..")")
		end
	else
		for i = 1, #StatisticID do
			if not _G["AllYouCanEat_Selection_TextCompleted_"..StatisticID[i].id][GUI_MainDataGUID] then
				local x = 0
				for k, v in pairs(DATA[StatisticID[i].id]) do
					if k ~= "total" and k ~= "totalcompleted" then
					
						local comp
						if AllYouCanEat_Data.stats and
						   AllYouCanEat_Data.stats[StatisticID[i].id] and
						   AllYouCanEat_Data.stats[StatisticID[i].id][k] and
						   AllYouCanEat_Data.stats[StatisticID[i].id][k][GUI_MainDataGUID]
						then
							comp = false
						else
							comp = true
						end

						if comp then
							x = x + 1
						end

					end
				end
				_G["AllYouCanEat_Selection_TextCompleted_"..StatisticID[i].id][GUI_MainDataGUID] = x
			end
		end
		for i = 1, #StatisticID do
			_G["AllYouCanEat_Selection_TextCompleted_"..StatisticID[i].id]:SetText(_G["AllYouCanEat_Selection_TextCompleted_"..StatisticID[i].id][GUI_MainDataGUID])
			_G["AllYouCanEat_Selection_TextTotal_"..StatisticID[i].id]:SetText("("..DATA[StatisticID[i].id].total..")")
		end
	end
	AllYouCanEat:UpdateStatusText()
end

function AllYouCanEat:CreateGUIdata()
	table.wipe(GUI_Data)

	if GUI_MainDataGUID == playerGUID then

		if GUI_Detail == 1 then
			local x = 1
			for k, v in pairs(DATA[GUI_Selection]) do
				if k ~= "total" and k ~= "totalcompleted" then
					GUI_Data[x] = {}
					GUI_Data[x].itemnumber = x
					GUI_Data[x].itemid = k
					GUI_Data[x].itemlink = v.itemlink
					GUI_Data[x].itemname = v.itemname
					GUI_Data[x].completed = v.completed
					x = x + 1
				end
			end
		elseif GUI_Detail == 2 then
			local x = 1
			for k, v in pairs(DATA[GUI_Selection]) do
				if k ~= "total" and k ~= "totalcompleted" and v.completed then
					GUI_Data[x] = {}
					GUI_Data[x].itemnumber = x
					GUI_Data[x].itemid = k
					GUI_Data[x].itemlink = v.itemlink
					GUI_Data[x].itemname = v.itemname
					GUI_Data[x].completed = v.completed
					x = x + 1
				end
			end
		elseif GUI_Detail == 3 then
			local x = 1
			for k, v in pairs(DATA[GUI_Selection]) do
				if k ~= "total" and k ~= "totalcompleted" and not v.completed then
					GUI_Data[x] = {}
					GUI_Data[x].itemnumber = x
					GUI_Data[x].itemid = k
					GUI_Data[x].itemlink = v.itemlink
					GUI_Data[x].itemname = v.itemname
					GUI_Data[x].completed = v.completed
					x = x + 1
				end
			end
		end

	else

		if GUI_Detail == 1 then
			local x = 1
			for k, v in pairs(DATA[GUI_Selection]) do
				if k ~= "total" and k ~= "totalcompleted" then
					GUI_Data[x] = {}
					GUI_Data[x].itemnumber = x
					GUI_Data[x].itemid = k
					GUI_Data[x].itemlink = v.itemlink
					GUI_Data[x].itemname = v.itemname
					if AllYouCanEat_Data.stats and
					   AllYouCanEat_Data.stats[GUI_Selection] and
					   AllYouCanEat_Data.stats[GUI_Selection][k] and
					   AllYouCanEat_Data.stats[GUI_Selection][k][GUI_MainDataGUID]
					then
						GUI_Data[x].completed = false
					else
						GUI_Data[x].completed = true
					end
					x = x + 1
				end
			end
		elseif GUI_Detail == 2 then
			local x = 1
			for k, v in pairs(DATA[GUI_Selection]) do
				if k ~= "total" and k ~= "totalcompleted" then
					
					local comp
					if AllYouCanEat_Data.stats and
					   AllYouCanEat_Data.stats[GUI_Selection] and
					   AllYouCanEat_Data.stats[GUI_Selection][k] and
					   AllYouCanEat_Data.stats[GUI_Selection][k][GUI_MainDataGUID]
					then
						comp = false
					else
						comp = true
					end

					if comp then
						GUI_Data[x] = {}
						GUI_Data[x].itemnumber = x
						GUI_Data[x].itemid = k
						GUI_Data[x].itemlink = v.itemlink
						GUI_Data[x].itemname = v.itemname
						GUI_Data[x].completed = comp
						x = x + 1
					end

				end
			end
		elseif GUI_Detail == 3 then
			local x = 1
			for k, v in pairs(DATA[GUI_Selection]) do
				if k ~= "total" and k ~= "totalcompleted" then
					
					local comp
					if AllYouCanEat_Data.stats and
					   AllYouCanEat_Data.stats[GUI_Selection] and
					   AllYouCanEat_Data.stats[GUI_Selection][k] and
					   AllYouCanEat_Data.stats[GUI_Selection][k][GUI_MainDataGUID]
					then
						comp = false
					else
						comp = true
					end

					if not comp then
						GUI_Data[x] = {}
						GUI_Data[x].itemnumber = x
						GUI_Data[x].itemid = k
						GUI_Data[x].itemlink = v.itemlink
						GUI_Data[x].itemname = v.itemname
						GUI_Data[x].completed = comp
						x = x + 1
					end

				end
			end
		end

	end

	GUI_Data_Count = #GUI_Data

	local sortfunc
	if GUI_SortBy == 1 then -- 1 = number
		if GUI_SortOrder == 1 then
			sortfunc = function(a, b)
				if a.itemnumber < b.itemnumber then
					return true
				end
			end
		else
			sortfunc = function(a, b)
				if a.itemnumber > b.itemnumber then
					return true
				end
			end
		end
	elseif GUI_SortBy == 2 then -- 2 = itemid
		if GUI_SortOrder == 1 then
			sortfunc = function(a, b)
				if a.itemid < b.itemid then
					return true
				end
			end
		else
			sortfunc = function(a, b)
				if a.itemid > b.itemid then
					return true
				end
			end
		end
	elseif GUI_SortBy == 3 then -- 3 = itemlink
		if GUI_SortOrder == 1 then
			sortfunc = function(a, b)
				if a.itemlink < b.itemlink then
					return true
				end
			end
		else
			sortfunc = function(a, b)
				if a.itemlink > b.itemlink then
					return true
				end
			end
		end
	elseif GUI_SortBy == 4 then -- 4 = itemname
		if GUI_SortOrder == 1 then
			sortfunc = function(a, b)
				if a.itemname < b.itemname then
					return true
				end
			end
		else
			sortfunc = function(a, b)
				if a.itemname > b.itemname then
					return true
				end
			end
		end
	end

	table.sort(GUI_Data, sortfunc)

	-- search START
	if SearchQuery then
		local newtemp = {}
		local x = 1
		local lowerSearchQuery = string.lower(SearchQuery)
		for i = 1, GUI_Data_Count do
			if string.find(string.lower(GUI_Data[i].itemname), lowerSearchQuery, 1, true) then
				newtemp[x] = {}
				newtemp[x].itemnumber = GUI_Data[i].itemnumber
				newtemp[x].itemid     = GUI_Data[i].itemid
				newtemp[x].itemlink   = GUI_Data[i].itemlink
				newtemp[x].itemname   = GUI_Data[i].itemname
				newtemp[x].completed  = GUI_Data[i].completed
				x = x + 1
			end
		end

		table.wipe(GUI_Data)
		for i = 1, #newtemp do
			GUI_Data[i] = newtemp[i]
		end
		table.wipe(newtemp)
		GUI_Data_Count = #GUI_Data
	end
	-- search END
end

function AllYouCanEat:GUIsort(sortBy)
	if GUI_SortBy == sortBy then
		if GUI_SortOrder == 1 then
			GUI_SortOrder = 0
		else
			GUI_SortOrder = 1
		end
	else
		GUI_SortOrder = 1
	end
	GUI_SortBy = sortBy

	AllYouCanEat_Options.Data_SortBy = GUI_SortBy
	AllYouCanEat_Options.Data_SortOrder = GUI_SortOrder

	AllYouCanEat:UpdateSortButtons()
	AllYouCanEat:CreateGUIdata()
	AllYouCanEat:FillList()
end

function AllYouCanEat:UpdateSortButtons()
	local arrow
	for i = 1, 4 do
		if i == 1 then     -- 1 = Number
			arrow = "AllYouCanEat_DataFrame_SortButton_NumberArrow"
		elseif i == 2 then -- 2 = ItemId
			arrow = "AllYouCanEat_DataFrame_SortButton_ItemIdArrow"
		elseif i == 3 then -- 3 = ItemLink
			arrow = "AllYouCanEat_DataFrame_SortButton_ItemLinkArrow"
		elseif i == 4 then -- 4 = ItemName
			arrow = "AllYouCanEat_DataFrame_SortButton_ItemNameArrow"
		end
		if GUI_SortBy == i then
			if GUI_SortOrder == 1 then _G[arrow]:SetTexCoord(0, 0.5625, 0, 1) end
			if GUI_SortOrder == 0 then _G[arrow]:SetTexCoord(0.5625, 0, 1, 0) end
		else
			_G[arrow]:SetTexCoord(0, 0, 0, 0)
		end
	end
end

function AllYouCanEat:OnVerticalScroll()
	AllYouCanEat_DataFrame_ScrollFrameScrollBar:SetValue(arg1)
	AllYouCanEat_DataFrame_ScrollFrame.offset = math_floor((arg1 / 12) + 0.5)
	AllYouCanEat:FillList()
end

function AllYouCanEat:FillList()
	local frameName = "AllYouCanEat_DataFrame_ScrollFrame"
	local frame = _G[frameName]
	local scrollBar = _G[frameName.."ScrollBar"]
	local scrollUpButton = _G[frameName.."ScrollBarScrollUpButton"]
	local scrollDownButton = _G[frameName.."ScrollBarScrollDownButton"]
	local scrollFrameHeight = 0
	local numToDisplay = GUI_Data_curNum
	local valueStep = 12

	if GUI_Data_Count < numToDisplay then
		numToDisplay = GUI_Data_Count
	end

	if GUI_Data_Count > 0 then
		scrollFrameHeight = (GUI_Data_Count - numToDisplay) * valueStep
		if scrollFrameHeight < 0 then
			scrollFrameHeight = 0
		end
	end
	scrollBar:SetMinMaxValues(0, scrollFrameHeight)
	scrollBar:SetValueStep(valueStep)

	if scrollBar:GetValue() == 0 then
		scrollUpButton:Disable()
	else
		scrollUpButton:Enable()
	end
	if ((scrollBar:GetValue() - scrollFrameHeight) == 0) then
		scrollDownButton:Disable()
	else
		scrollDownButton:Enable()
	end

	if GUI_Data_Count <= GUI_Data_curNum then
		frame:SetAlpha(0.2)
		scrollUpButton:Disable()
		scrollDownButton:Disable()
	else
		frame:SetAlpha(1)
	end

	for i=1, GUI_Data_maxNum do
		_G["AllYouCanEat_DataFrame_Button"..i]:Hide()
	end

	local j = 1
	local sliderPos = AllYouCanEat_DataFrame_ScrollFrame.offset
	for i=sliderPos+1, sliderPos+numToDisplay do
		if sliderPos < GUI_Data_Count then
			_G["AllYouCanEat_DataFrame_Button"..j.."Number"]:SetText(GUI_Data[i].itemnumber)
			_G["AllYouCanEat_DataFrame_Button"..j.."ItemId"]:SetText(GUI_Data[i].itemid)
			_G["AllYouCanEat_DataFrame_Button"..j.."ItemName"]:SetText(GUI_Data[i].itemname)

			if GUI_Data[i].completed then
				_G["AllYouCanEat_DataFrame_Button"..j.."ItemName"]:SetTextColor(0, 0.75, 0, 1)
			else
				_G["AllYouCanEat_DataFrame_Button"..j.."ItemName"]:SetTextColor(1, 0, 0, 1)
			end

			if GUI_Data[i].itemlink == 1 then
				_G["AllYouCanEat_DataFrame_Button"..j.."ItemLink"]:SetTexCoord(0.125, 0.71875, 0.125, 0.375) -- (4/32, 23/32, 4/32, 12/32)
			else
				_G["AllYouCanEat_DataFrame_Button"..j.."ItemLink"]:SetTexCoord(0, 0, 0, 0)
			end

			_G["AllYouCanEat_DataFrame_Button"..j]:Show()
			_G["AllYouCanEat_DataFrame_Button"..j].itemID = GUI_Data[i].itemid
			j = j + 1
		end
	end
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
local function AllYouCanEat_Hook_UseContainerItem(bag, slot)
	--local timerStart = GetTime() -- timecheck
	if bag  and type(bag) ~= "number" then return end
	if slot and type(slot) ~= "number" then return end
	if bag == BANK_CONTAINER then return end

	local itemID = GetContainerItemID(bag, slot)

	if not itemID then return end

	for i = 1, #StatisticID do
		local statID = StatisticID[i].id
		if DATA[statID][itemID] and not DATA[statID][itemID].completed then
			UPDATE_itemID = itemID
			UPDATE_statID = statID
			UPDATE_catID  = i
			criteriaTimer = GetTime()
			return
		end
	end
	--print("timecheck:", GetTime()-timerStart) --timecheck
end
-- ---------------------------------------------------------------------------------------------------------------------

-- ---------------------------------------------------------------------------------------------------------------------
local function OnEvent(self, event)
	if event == "CRITERIA_UPDATE" then
		if not UPDATE_itemID then return end -- <- !!! muy importante, amigo !!!

		local _, _, isCompleted = GetAchievementCriteriaInfo(DATA[UPDATE_statID][UPDATE_itemID].criteriaID)

		if isCompleted then
			DATA[UPDATE_statID][UPDATE_itemID].completed = true
			DATA[UPDATE_statID].totalcompleted = DATA[UPDATE_statID].totalcompleted + 1

			if AllYouCanEat_Data.stats and
			   AllYouCanEat_Data.stats[UPDATE_statID] and
			   AllYouCanEat_Data.stats[UPDATE_statID][UPDATE_itemID] and
			   AllYouCanEat_Data.stats[UPDATE_statID][UPDATE_itemID][playerGUID]
			then
				AllYouCanEat_Data.stats[UPDATE_statID][UPDATE_itemID][playerGUID] = nil
				local x = 0
				for k, v in pairs(AllYouCanEat_Data.stats[UPDATE_statID][UPDATE_itemID]) do
					x = x + 1
					break
				end
				if x == 0 then
					AllYouCanEat_Data.stats[UPDATE_statID][UPDATE_itemID] = nil
				end
			end

			local _, itemLink = GetItemInfo(UPDATE_itemID)
			if itemLink then
				print("|cffffff7fAllYouCanEat:|r", "|cffff9900"..NEW.."|r", itemLink, "- |cffcccccc("..StatisticID[UPDATE_catID].name.." | "..L["ItemID"]..": "..UPDATE_itemID..")|r")
			else
				print("|cffffff7fAllYouCanEat:|r", "|cffff9900"..NEW.."|r", DATA[UPDATE_statID][UPDATE_itemID].itemname, "- |cffcccccc("..StatisticID[UPDATE_catID].name.." | "..L["ItemID"]..": "..UPDATE_itemID..")|r")
			end

			-- if UPDATE_itemID exists more than one time START
			for i = 1, #StatisticID do
				local statID = StatisticID[i].id
				if DATA[statID][UPDATE_itemID] and not DATA[statID][UPDATE_itemID].completed then

					DATA[statID][UPDATE_itemID].completed = true
					DATA[statID].totalcompleted = DATA[statID].totalcompleted + 1

					if AllYouCanEat_Data.stats and
					   AllYouCanEat_Data.stats[statID] and
					   AllYouCanEat_Data.stats[statID][UPDATE_itemID] and
					   AllYouCanEat_Data.stats[statID][UPDATE_itemID][playerGUID]
					then
						AllYouCanEat_Data.stats[statID][UPDATE_itemID][playerGUID] = nil
						local x = 0
						for k, v in pairs(AllYouCanEat_Data.stats[statID][UPDATE_itemID]) do
							x = x + 1
							break
						end
						if x == 0 then
							AllYouCanEat_Data.stats[statID][UPDATE_itemID] = nil
						end
					end

					if itemLink then
						print("|cffffff7fAllYouCanEat:|r", "|cffff9900"..NEW.."|r", itemLink, "- |cffcccccc("..StatisticID[i].name.." | "..L["ItemID"]..": "..UPDATE_itemID..")|r")
					else
						print("|cffffff7fAllYouCanEat:|r", "|cffff9900"..NEW.."|r", DATA[statID][UPDATE_itemID].itemname, "- |cffcccccc("..StatisticID[i].name.." | "..L["ItemID"]..": "..UPDATE_itemID..")|r")
					end

				end
			end
			-- if UPDATE_itemID exists more than one time END

			UpdateTime()
			if AllYouCanEat_MainFrame:IsShown() then
				AllYouCanEat:UpdateData()
			end

			UPDATE_itemID = nil

		else
			-- the duration between a successful item click (with itemID from initial stats scan) and any CRITERIA_UPDATE action is set to 5 seconds
			if GetTime() - criteriaTimer > 5 then
				UPDATE_itemID = nil
			end
		end
	elseif event == "PLAYER_LOGIN" then
		playerRealm   = GetCVar("realmName")
		playerName    = UnitName("player")
		playerGUID    = UnitGUID("player")
		playerFaction = UnitFactionGroup("player")
		playerClass   = select(2, UnitClass("player"))

		GUI_MainDataGUID = playerGUID

		AllYouCanEat:SaveCharacterData()
		AllYouCanEat:InitialStatisticScan()
		AllYouCanEat:CheckSavedStatisticData()
		AllYouCanEat:InitOptions()
		AllYouCanEat:CreateInterfaceOptions()
		AllYouCanEat:LDBcheck()
		AllYouCanEat:CreateMainFrame()
		AllYouCanEat:InitializeFrame()
		table.insert(UISpecialFrames, "AllYouCanEat_MainFrame")

		AllYouCanEat:CheckIfTooltipCodeIsNeeded()

		InstallHooks(_G.GameTooltip, Hooks)
		InstallHooks(_G.ItemRefTooltip, Hooks)

		hooksecurefunc("UseContainerItem", AllYouCanEat_Hook_UseContainerItem)

		AllYouCanEat:UnregisterEvent("PLAYER_LOGIN")
	end
end
-- ---------------------------------------------------------------------------------------------------------------------

AllYouCanEat:RegisterEvent("CRITERIA_UPDATE")
AllYouCanEat:RegisterEvent("PLAYER_LOGIN")
AllYouCanEat:SetScript("OnEvent", OnEvent)