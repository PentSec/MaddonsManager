-- -------------------------------------------------------------------------- --
-- AllYouCanEat DEFAULT (english) Localization                                --
-- Please make sure to save this file as UTF-8. ¶                             --
-- -------------------------------------------------------------------------- --

AllYouCanEat_Locales = {

-- Interface Options
["Open GUI"] = true,

-- GUI
["CharManager"] = true,
["Latest Update"] = true,
["all"] = true,
["No."] = true,
["ItemID"] = true,
["Name"] = true,
["click & move"] = true,
["click & resize"] = true,
-- GUI - CharManager
["Options for:"] = true,
["Status:"] = true,
["TOOLTIP"] = true,
["SAVED"] = true,
["NOT SAVED"] = true,
["Save Data"] = true,
["Delete Data"] = true,
["Do you really want to delete the data from this character?"] = true,
["Remove Character"] = true,
["Do you really want to remove this character?"] = true,
["Only useful if a character was permanently deleted."] = true,
["Saves the statistics data from this character to SavedVariable, so you can view it with other characters."] = true,
["Show statistic data in GameTooltip"] = true,

-- Tooltip
["consumed"] = true,
["not consumed"] = true,
["Unsafe Item"] = true,
["You can try to start a new server query in %s seconds!"] = true,
["You may be disconnected."] = true,
["Please wait 5 seconds for next server query."] = true,

-- Chatoutput
["Beverages"] = true,
["Foods"] = true,
["Bandage"] = true,
["Health Potions"] = true,
["Mana Potions"] = true,
["Elixirs"] = true,
["Flasks"] = true,

}

function AllYouCanEat_Locales:CreateLocaleTable(t)
	for k,v in pairs(t) do
		self[k] = (v == true and k) or v
	end
end

AllYouCanEat_Locales:CreateLocaleTable(AllYouCanEat_Locales)