-- -------------------------------------------------------------------------- --
-- AllYouCanEat zhCN Localization By 楓之刃@米奈希爾                          --
-- Please make sure to save this file as UTF-8. ¶                             --
-- -------------------------------------------------------------------------- --
if GetLocale() ~= "zhCN" then return end
AllYouCanEat_Locales:CreateLocaleTable({

-- Interface Options
["Open GUI"] = "开启 GUI",

-- GUI
["CharManager"] = "CharManager",
["Latest Update"] = "最后更新",
["all"] = "全部",
["No."] = "No.",
["ItemID"] = "ItemID",
["Name"] = "名称",
["click & move"] = "点击 & 移动",
--["click & resize"] = true,
-- GUI - CharManager
["Options for:"] = "选项:",
["Status:"] = "状态:",
["TOOLTIP"] = "工具提示",
["SAVED"] = "已储存",
["NOT SAVED"] = "未储存",
["Save Data"] = "储存数据",
["Delete Data"] = "删除数据",
--["Do you really want to delete the data from this character?"] = true,
--["Remove Character"] = true,
--["Do you really want to remove this character?"] = true,
--["Only useful if a character was permanently deleted."] = true,
["Saves the statistics data from this character to SavedVariable, so you can view it with other characters."] = "储存的统计数据到这个角色的SavedVariable，所以你可以查看它与其它的角色。",
["Show statistic data in GameTooltip"] = "统计数据显示在游戏信息提示",

-- Tooltip
["consumed"] = "已饮用",
["not consumed"] = "未饮用",
["Unsafe Item"] = "不安全的物品",
["You can try to start a new server query in %s seconds!"] = "你可以在%s秒尝试启动一个新的服务器查询！",
["You may be disconnected."] = "你可能会断开连接。",
["Please wait 5 seconds for next server query."] = "下一个服务器查询，请耐心等待5秒。",

-- Chatoutput
["Beverages"] = "饮料",
["Foods"] = "食物",
["Bandage"] = "绷带",
["Health Potions"] = "治疗药水",
["Mana Potions"] = "法力药水",
["Elixirs"] = "药剂",
["Flasks"] = "合剂",

})