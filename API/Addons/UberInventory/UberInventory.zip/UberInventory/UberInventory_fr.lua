--[[ =================================================================
    Description:
        All strings (French) used by UberInventory.
    ================================================================= --]]

-- Strings used within UberInventory
if (GetLocale()=="frFR") then

end;
