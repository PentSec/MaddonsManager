--[[ =================================================================
    Description:
        All strings (Chinese) used by UberInventory.
    ================================================================= --]]

-- Strings used within UberInventory
if (GetLocale()=="zhCN") then

end;
