--[[ =================================================================
    Description:
        All strings (Korean) used by UberInventory.
    ================================================================= --]]

-- Strings used within UberInventory
if (GetLocale()=="koKR") then

end;
