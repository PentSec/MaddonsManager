--[[ =================================================================
    Description:
        All strings (German) used by UberInventory.
    ================================================================= --]]

-- Strings used within UberInventory
if (GetLocale()=="deDE") then

end;
