--[[
    =================================================================
    Description:
        All strings (Spanish) used by UberInventory.
    ================================================================= --]]

-- Strings used within UberInventory
if (GetLocale()=="esES") then

end;
