
function Skinner:Omnibus()

	self:keepFontStrings(OmnibusEditScrollFrame)
	self:skinScrollBar(OmnibusEditScrollFrame)
	self:applySkin(OmnibusFrame)

end
