if not Skinner:isAddonEnabled("AuctionFilterPlus") then return end

function Skinner:AuctionFilterPlus()

	self:addSkinFrame{obj=afp_FlyoutFrame, kfs=true}

end
