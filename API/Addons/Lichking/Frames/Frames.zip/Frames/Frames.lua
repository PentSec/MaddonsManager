local frame = CreateFrame("FRAME")
frame:RegisterEvent("GROUP_ROSTER_UPDATE")
frame:RegisterEvent("PLAYER_TARGET_CHANGED")
frame:RegisterEvent("PLAYER_FOCUS_CHANGED")
frame:RegisterEvent("UNIT_FACTION")

local function eventHandler(self, event, ...)
        
	TargetFrameNameBackground:SetVertexColor(0, 0, 0, 0.0)
	TargetFrameNameBackground:SetHeight(18)
	FocusFrameNameBackground:SetVertexColor(0, 0, 0, 0.0)
	FocusFrameNameBackground:SetHeight(18)
       
end

frame:SetScript("OnEvent", eventHandler)
PlayerFrameTexture:SetTexture("Interface\\AddOns\\Frames\\TargetingFrame\\UI-TargetingFrame")
function TargetFrame_CheckClassification (self, forceNormalTexture)
    local classification = UnitClassification(self.unit);
    self.nameBackground:Show();
    self.manabar:Show();
    self.manabar.TextString:Show();
    self.threatIndicator:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Flash");
 
    if ( forceNormalTexture ) then
        self.borderTexture:SetTexture("Interface\\AddOns\\Frames\\TargetingFrame\\UI-TargetingFrame");
    elseif ( classification == "minus" ) then
        self.borderTexture:SetTexture("Interface\\AddOns\\Frames\\TargetingFrame\\UI-TargetingFrame-Minus");
        self.nameBackground:Hide();
        self.manabar:Hide();
        self.manabar.TextString:Hide();
        forceNormalTexture = true;
    elseif ( classification == "worldboss" or classification == "elite" ) then
        self.borderTexture:SetTexture("Interface\\AddOns\\Frames\\TargetingFrame\\UI-TargetingFrame");
    elseif ( classification == "rareelite" ) then
        self.borderTexture:SetTexture("Interface\\AddOns\\Frames\\TargetingFrame\\UI-TargetingFrame");
    elseif ( classification == "rare" ) then
        self.borderTexture:SetTexture("Interface\\AddOns\\Frames\\TargetingFrame\\UI-TargetingFrame");
    else
        self.borderTexture:SetTexture("Interface\\AddOns\\Frames\\TargetingFrame\\UI-TargetingFrame");
        forceNormalTexture = true;
    end
end


--castbar

--Hideshit
PlayerName:ClearAllPoints()
PlayerName:SetPoint("CENTER", PlayerFrame, "CENTER", 50, 35)
PlayerName.SetPoint = function() end
PetHitIndicator:SetText(nil)
PetHitIndicator.SetText = function() end
PlayerHitIndicator:SetText(nil)
PlayerHitIndicator.SetText = function() end
PlayerPVPIcon:SetAlpha(0)
FocusFrameToT:SetAlpha(0)
TargetFrameTextureFramePVPIcon:SetAlpha(0)
FocusFrameTextureFramePVPIcon:SetAlpha(0)

hooksecurefunc(PlayerPVPTimerText, "SetFormattedText", function(self)
     self.timeLeft = nil
     self:Hide()
end)

local noop = function() return end

for _, objname in ipairs({
	"PlayerAttackGlow",
	"PetAttackModeTexture",
	"PlayerRestGlow",
	"PlayerRestIcon",
	"PlayerStatusGlow",
	"PlayerStatusTexture",
	"MonkHarmonyBar",
	"PlayerAttackBackground",
	"PlayerFrameGroupIndicator",	
	"PlayerFrameFlash",
	"TargetFrameFlash",
	"PlayerFrameRoleIcon",
	
}) do
	local obj = _G[objname]
	if obj then
		obj:Hide()
		obj.Show = noop
	end
end

TargetFrameToT:ClearAllPoints()
TargetFrameToT:SetPoint("CENTER", TargetFrame, "CENTER", 60, -52)

--Names
TargetFrame.name:ClearAllPoints()
TargetFrame.name:SetPoint("CENTER", TargetFrame, "CENTER", -50, 35)
TargetFrame.name.SetPoint = function() end
FocusFrame.name:ClearAllPoints()
FocusFrame.name:SetPoint("CENTER", FocusFrame, "CENTER", -45, 35)
FocusFrame.name.SetPoint = function() end

--bars
PlayerFrameHealthBar:SetHeight(27)
PlayerFrameHealthBar:ClearAllPoints()
PlayerFrameHealthBar:SetPoint("CENTER", PlayerFrame, "CENTER", 50, 14)
PlayerFrameHealthBar.SetPoint = function() end


TargetFrameHealthBar:SetHeight(27)
TargetFrameHealthBar:ClearAllPoints()
TargetFrameHealthBar:SetPoint("CENTER", TargetFrame, "CENTER", -50, 14)
TargetFrameHealthBar.SetPoint = function() end

FocusFrameHealthBar:SetHeight(27)
FocusFrameHealthBar:ClearAllPoints()
FocusFrameHealthBar:SetPoint("CENTER", FocusFrame, "CENTER", -50, 14)
FocusFrameHealthBar.SetPoint = function() end


PlayerFrameManaBar:ClearAllPoints()
PlayerFrameManaBar:SetPoint("CENTER", PlayerFrame, "CENTER", 51, -7)
PlayerFrameManaBar.SetPoint = function() end


TargetFrameManaBar:ClearAllPoints()
TargetFrameManaBar:SetPoint("CENTER", TargetFrame, "CENTER", -51, -7)
TargetFrameManaBar.SetPoint = function() end


FocusFrameManaBar:ClearAllPoints()
FocusFrameManaBar:SetPoint("CENTER", FocusFrame, "CENTER", -51, -7)
FocusFrameManaBar.SetPoint = function() end







--Size
PlayerFrameHealthBar.TextString:SetFont(STANDARD_TEXT_FONT,10,"OUTLINE")
TargetFrameHealthBar.TextString:SetFont(STANDARD_TEXT_FONT,10,"OUTLINE")
FocusFrameHealthBar.TextString:SetFont(STANDARD_TEXT_FONT,10,"OUTLINE")
TargetFrameManaBar.TextString:SetFont(STANDARD_TEXT_FONT,10,"OUTLINE")
PlayerFrameManaBar.TextString:SetFont(STANDARD_TEXT_FONT,10,"OUTLINE")
FocusFrameManaBar.TextString:SetFont(STANDARD_TEXT_FONT,10,"OUTLINE")


TargetFrameHealthBar.TextString:ClearAllPoints()
TargetFrameHealthBar.TextString:SetPoint("CENTER", TargetFrame, "CENTER", -53, 12)
TargetFrameHealthBar.TextString.SetPoint = function() end


PlayerFrameHealthBar.TextString:ClearAllPoints()
PlayerFrameHealthBar.TextString:SetPoint("CENTER", PlayerFrame, "CENTER", 53, 12)
PlayerFrameHealthBar.TextString.SetPoint = function() end


FocusFrameHealthBar.TextString:ClearAllPoints()
FocusFrameHealthBar.TextString:SetPoint("CENTER", FocusFrame, "CENTER", -53, 12)
FocusFrameHealthBar.TextString.SetPoint = function() end

PlayerFrameManaBar.TextString:ClearAllPoints()
PlayerFrameManaBar.TextString:SetPoint("CENTER", PlayerFrame, "CENTER", 53, -7)
PlayerFrameManaBar.TextString.SetPoint = function() end

TargetFrameManaBar.TextString:ClearAllPoints()
TargetFrameManaBar.TextString:SetPoint("CENTER", TargetFrame, "CENTER", -50, -7)
TargetFrameManaBar.TextString.SetPoint = function() end

FocusFrameManaBar.TextString:ClearAllPoints()
FocusFrameManaBar.TextString:SetPoint("CENTER", FocusFrame, "CENTER", -50, -7)
FocusFrameManaBar.TextString.SetPoint = function() end


PlayerFrame:SetScale(1.1)
TargetFrame:SetScale(1.1)
FocusFrame:SetScale(1.1)




