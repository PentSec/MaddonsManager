-- Roles:
--		Unknown = 1,
--		Tank = 2,
--		PureMelee = 3,
--		MeleeMana = 4,
--		Caster = 5,

--	Buffs:
--	None = 1, -- can't provide
--	ProfessionStats = 2, -- Leatherworking Kings
--	Basic = 3, -- class inherent (shaman/warrior)
--	BasicLong = 4, -- class inherent (paladin): wisdom, might, kings, sanctuary
--	MinorTalented = 5, -- partial talent investment, warrior (1,2 /5), shaman (1/3)
--	PartialTalentedLong = 6, -- partial talent investment, paladin (1/2)
--	MajorTalented = 7, -- partial talent investment, warrior (3,4 /5), shaman (2/3)
--	FullTalented = 7, -- 3/3 shaman totems, 5/5 warrior shouts
--	FullTalentedLong = 8, -- 2/2 paladin wisdom, 2/2 Paladin might


BuffBroker.TestCases = {}

BuffBroker.TestCases.MockPlayers =
	{
		PaladinHealer =
		{
			Name = "PaladinHealer",
			GUID = "PaladinHealer_GUID",
			Class = "PALADIN",
			Role = BBConstants.base.Roles.Caster,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.BasicLong,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.BasicLong,
				["MP5"] = BBConstants.base.Buffs.BasicLong,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["BLESSINGS"] = BBConstants.base.BuffSlots["BLESSINGS_BASIC"],
			},
		},
			
		PaladinHealer_MP5 =
		{
			Name = "PaladinHealer_MP5",
			GUID = "PaladinHealer_MP5_GUID",
			Class = "PALADIN",
			Role = BBConstants.base.Roles.Caster,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.BasicLong,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.BasicLong,
				["MP5"] = BBConstants.base.Buffs.FullTalentedLong,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["BLESSINGS"] = BBConstants.base.BuffSlots["BLESSINGS_BASIC"],
			},
		},
		
		PaladinHealer_AP =
		{
			Name = "PaladinHealer_AP",
			GUID = "PaladinHealer_AP_GUID",
			Class = "PALADIN",
			Role = BBConstants.base.Roles.Caster,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.FullTalentedLong,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.BasicLong,
				["MP5"] = BBConstants.base.Buffs.BasicLong,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["BLESSINGS"] = BBConstants.base.BuffSlots["BLESSINGS_BASIC"],
			},
		},
		
		PaladinHealer_MP5_AP =
		{
			Name = "PaladinHealer_MP5_AP",
			GUID = "PaladinHealer_MP5_AP_GUID",
			Class = "PALADIN",
			Role = BBConstants.base.Roles.Caster,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.FullTalentedLong,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.BasicLong,
				["MP5"] = BBConstants.base.Buffs.FullTalentedLong,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["BLESSINGS"] = BBConstants.base.BuffSlots["BLESSINGS_BASIC"],
			},
		},
		
		PaladinMelee =
		{
			Name = "PaladinMelee",
			GUID = "PaladinMelee_GUID",
			Class = "PALADIN",
			Role = BBConstants.base.Roles.MeleeMana,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.BasicLong,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.BasicLong,
				["MP5"] = BBConstants.base.Buffs.BasicLong,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["BLESSINGS"] = BBConstants.base.BuffSlots["BLESSINGS_BASIC"],
			},
		},
		
		PaladinMelee_AP =
		{
			Name = "PaladinMelee_AP",
			GUID = "PaladinMelee_AP_GUID",
			Class = "PALADIN",
			Role = BBConstants.base.Roles.MeleeMana,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.FullTalentedLong,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.BasicLong,
				["MP5"] = BBConstants.base.Buffs.BasicLong,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["BLESSINGS"] = BBConstants.base.BuffSlots["BLESSINGS_BASIC"],
			},
		},
		
		PaladinTank =
		{
			Name = "PaladinTank",
			GUID = "PaladinTank_GUID",
			Class = "PALADIN",
			Role = BBConstants.base.Roles.Tank,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.BasicLong,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.BasicLong,
				["MP5"] = BBConstants.base.Buffs.BasicLong,
				["TANK"] = BBConstants.base.Buffs.FullTalentedLong,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["BLESSINGS"] = BBConstants.base.BuffSlots["BLESSINGS"],
			},
		},
		
		PaladinTank_AP =
		{
			Name = "PaladinTank_AP",
			GUID = "PaladinTank_AP_GUID",
			Class = "PALADIN",
			Role = BBConstants.base.Roles.Tank,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.FullTalentedLong,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.BasicLong,
				["MP5"] = BBConstants.base.Buffs.BasicLong,
				["TANK"] = BBConstants.base.Buffs.FullTalentedLong,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["BLESSINGS"] = BBConstants.base.BuffSlots["BLESSINGS"],
			},
		},
		
		PureMelee =
		{
			Name = "PureMelee",
			GUID = "PureMelee_GUID",
			Class = "DRUID",
			Role = BBConstants.base.Roles.PureMelee,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.None,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.None,
				["MP5"] = BBConstants.base.Buffs.None,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {},
		},
		
		PureMeleeAlt =
		{
			Name = "PureMeleeAlt",
			GUID = "PureMeleeAlt_GUID",
			Class = "DEATHKNIGHT",
			Role = BBConstants.base.Roles.PureMelee,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.None,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.None,
				["MP5"] = BBConstants.base.Buffs.None,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {},
		},
		
		ShadowPriest =
		{
			Name = "ShadowPriest",
			GUID = "ShadowPriest_GUID",
			Class = "PRIEST",
			Role = BBConstants.base.Roles.Caster,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["FORTITUDE"] = BBConstants.base.Buffs.Basic,
				["SPIRIT"] = BBConstants.base.Buffs.Basic,
				["PRIEST_PROTECTION"] = BBConstants.base.Buffs.Basic,
				["PRIEST_INNER"] = BBConstants.base.Buffs.Basic,
				["EMBRACE"] = BBConstants.base.Buffs.Basic,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["BLESSINGS"] = BBConstants.base.BuffSlots["BLESSINGS_BASIC"],
			},
		},
		
		Hunter =
		{
			Name = "Hunter",
			GUID = "Hunter_GUID",
			Class = "HUNTER",
			Role = BBConstants.base.Roles.MeleeMana,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
			},
			ActiveBuffs = {},
			BuffSlots = {},
		},
		
		DeathKnight =
		{
			Name = "DeathKnight",
			GUID = "DeathKnight_GUID",
			Class = "DEATHKNIGHT",
			Role = BBConstants.base.Roles.PureMelee,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["HORNS"] = BBConstants.base.BuffSlots["HORNS"],
			},
			ActiveBuffs = {},
			BuffSlots = {},
		},
		
		Caster =
		{
			Name = "Caster",
			GUID = "Caster_GUID",
			Class = "WARLOCK",
			Role = BBConstants.base.Roles.Caster,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.None,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.None,
				["MP5"] = BBConstants.base.Buffs.None,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {},
		},
		
		Healer =
		{
			Name = "Healer",
			GUID = "Healer_GUID",
			Class = "PRIEST",
			Role = BBConstants.base.Roles.Caster,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.None,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.None,
				["MP5"] = BBConstants.base.Buffs.None,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {},
		},
		
		Owl =
		{
			Name = "Owl",
			GUID = "Owl_GUID",
			Class = "DRUID",
			Role = BBConstants.base.Roles.Caster,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["THORNS"] = BBConstants.base.Buffs.FullTalented,
				["WILD"] = BBConstants.base.Buffs.FullTalented,
			},
			ActiveBuffs = {},
			BuffSlots = {},
		},
		
		Tree =
		{
			Name = "Tree",
			GUID = "Tree_GUID",
			Class = "DRUID",
			Role = BBConstants.base.Roles.Healer,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["THORNS"] = BBConstants.base.Buffs.Basic,
				["WILD"] = BBConstants.base.Buffs.FullTalented,
			},
			ActiveBuffs = {},
			BuffSlots = {},
		},
		
		MeleeMana = 
		{
			Name = "MeleeMana",
			GUID = "MeleeMana_GUID",
			Class = "HUNTER",
			Role = BBConstants.base.Roles.MeleeMana,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.None,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.None,
				["MP5"] = BBConstants.base.Buffs.None,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {},
		},
		
		MeleeManaFar = 
		{
			Name = "MeleeManaFar",
			GUID = "MeleeManaFar_GUID",
			Class = "HUNTER",
			Role = BBConstants.base.Roles.MeleeMana,
			Inspected = true,
			Level = 80,
			Near = nil,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.None,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.None,
				["MP5"] = BBConstants.base.Buffs.None,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {},
		},
		
		Warrior = 
		{
			Name = "Warrior",
			GUID = "Warrior_GUID",
			Class = "WARRIOR",
			Role = BBConstants.base.Roles.PureMelee,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.Basic,
				["HP"] = BBConstants.base.Buffs.Basic,
				["STATS"] = BBConstants.base.Buffs.None,
				["MP5"] = BBConstants.base.Buffs.None,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["SHOUTS"] = BBConstants.base.BuffSlots["SHOUTS"],
			},
		},

		Warrior_AP = 
		{
			Name = "Warrior_AP",
			GUID = "Warrior_AP_GUID",
			Class = "WARRIOR",
			Role = BBConstants.base.Roles.PureMelee,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.FullTalented,
				["HP"] = BBConstants.base.Buffs.FullTalented,
				["STATS"] = BBConstants.base.Buffs.None,
				["MP5"] = BBConstants.base.Buffs.None,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["SHOUTS"] = BBConstants.base.BuffSlots["SHOUTS"],
			},
		},

		ShamanCaster = 
		{
			Name = "ShamanCaster",
			GUID = "ShamanCaster_GUID",
			Class = "SHAMAN",
			Role = BBConstants.base.Roles.Caster,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.None,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.None,
				["MP5"] = BBConstants.base.Buffs.Basic,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["WATER_TOTEMS"] = BBConstants.base.BuffSlots["WATER_TOTEMS"],
			},
		},

		ShamanMelee = 
		{
			Name = "ShamanMelee",
			GUID = "ShamanMelee_GUID",
			Class = "SHAMAN",
			Role = BBConstants.base.Roles.MeleeMana,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.None,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.None,
				["MP5"] = BBConstants.base.Buffs.Basic,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["WATER_TOTEMS"] = BBConstants.base.BuffSlots["WATER_TOTEMS"],
			},
		},

		ShamanCaster_MP5 = 
		{
			Name = "ShamanCaster_MP5",
			GUID = "ShamanCaster_MP5_GUID",
			Class = "SHAMAN",
			Role = BBConstants.base.Roles.Caster,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.None,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.None,
				["MP5"] = BBConstants.base.Buffs.FullTalented,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["WATER_TOTEMS"] = BBConstants.base.BuffSlots["WATER_TOTEMS"],
			},
		},

		ShamanHealer_MP5 = 
		{
			Name = "ShamanHealer_MP5",
			GUID = "ShamanHealer_MP5_GUID",
			Class = "SHAMAN",
			Role = BBConstants.base.Roles.Healer,
			Inspected = true,
			Level = 80,
			Near = true,
			LOS = true,
			CastableBuffs = {
				["AP"] = BBConstants.base.Buffs.None,
				["HP"] = BBConstants.base.Buffs.None,
				["STATS"] = BBConstants.base.Buffs.None,
				["MP5"] = BBConstants.base.Buffs.FullTalented,
				["TANK"] = BBConstants.base.Buffs.None,
			},
			ActiveBuffs = {},
			BuffSlots = {
				["WATER_TOTEMS"] = BBConstants.base.BuffSlots["WATER_TOTEMS"],
			},
		},

	}
	
BuffBroker.TestCases.Groups =
{
	SoloPally =
	{
		{
			Test = "Paladin, untalented (melee)",
			Others = "none",
			Raid = "solo",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID] = BuffBroker.TestCases.MockPlayers.PaladinMelee,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19742}, --wisdom
			},
		},
		
		{
			Test = "Paladin, untalented (healer)",
			Others = "none",
			Raid = "solo",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=19742}, --wisdom
			},
		},
		
		{
			Test = "Paladin, tank",
			Others = "none",
			Raid = "solo",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=1},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=25899}, --g sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=25782}, --g might

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=20911}, --sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, imp might (melee)",
			Others = "none",
			Raid = "solo",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinMelee_AP,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=19742}, --wisdom
			},
		},
		
		{
			Test = "Paladin, imp might (healer)",
			Others = "none",
			Raid = "solo",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer_AP,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=19742}, --wisdom
			},
		},
		
		{
			Test = "Paladin, imp might (tank)",
			Others = "none",
			Raid = "solo",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank_AP,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25899}, --g sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25782}, --g might

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20911}, --sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, imp wisdom",
			Others = "none",
			Raid = "solo",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=19742}, --wisdom
			},
		},
		
		{
			Test = "Paladin, imp wisdom/might",
			Others = "none",
			Raid = "solo",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=19742}, --wisdom
			},
		},
	},

	PartyPally =
	{
		{
			Test = "Paladin, untalented (melee)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID] = BuffBroker.TestCases.MockPlayers.PaladinMelee,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25782}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25898}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25894}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
			},
		},
		
		{
			Test = "Paladin, untalented (healer)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			-- match player name/buff
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=25898}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=25894}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
			},
		},
		
		{
			Test = "Paladin, tank",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=1},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=25899}, --sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=25898}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=25782}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=20911}, --sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
			},
		},
		
		{
			Test = "Paladin, imp might (melee)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinMelee_AP,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=25782}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=25898}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=25894}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
			},
		},
		
		{
			Test = "Paladin, imp might (healer)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer_AP,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=25898}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=25894}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
			},
		},
		
		{
			Test = "Paladin, imp might (tank)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank_AP,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25899}, --sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25898}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25782}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20911}, --sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
			},
		},
		
		{
			Test = "Paladin, imp wisdom",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=25898}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=25894}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
			},
		},
		
		{
			Test = "Paladin, imp wisdom/might",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=25898}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=25894}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
			},
		},

	},


	PartyPallyWarrior =
	{
		{
			Test = "Paladin, untalented (melee)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID] = BuffBroker.TestCases.MockPlayers.PaladinMelee,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior.GUID] = BuffBroker.TestCases.MockPlayers.Warrior,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.Basic,Players = {BuffBroker.TestCases.MockPlayers.Warrior.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, untalented (healer)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior.GUID] = BuffBroker.TestCases.MockPlayers.Warrior,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.Basic,Players = {BuffBroker.TestCases.MockPlayers.Warrior.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, tank",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior.GUID] = BuffBroker.TestCases.MockPlayers.Warrior,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.Basic,Players = {BuffBroker.TestCases.MockPlayers.Warrior.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=1},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=25899}, --g sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=20911}, --sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, imp might (melee)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinMelee_AP,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior.GUID] = BuffBroker.TestCases.MockPlayers.Warrior,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.Basic,Players = {BuffBroker.TestCases.MockPlayers.Warrior.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, imp might (healer)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer_AP,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior.GUID] = BuffBroker.TestCases.MockPlayers.Warrior,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.Basic,Players = {BuffBroker.TestCases.MockPlayers.Warrior.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, imp might (tank)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank_AP,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior.GUID] = BuffBroker.TestCases.MockPlayers.Warrior,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.Basic,Players = {BuffBroker.TestCases.MockPlayers.Warrior.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25899}, --g sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20911}, --sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, imp wisdom",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior.GUID] = BuffBroker.TestCases.MockPlayers.Warrior,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.Basic,Players = {BuffBroker.TestCases.MockPlayers.Warrior.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, imp wisdom/might",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior.GUID] = BuffBroker.TestCases.MockPlayers.Warrior,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.Basic,Players = {BuffBroker.TestCases.MockPlayers.Warrior.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=19740}, --might
			},
		},

	},

	PartyPallyWarriorAP =
	{
		{
			Test = "Paladin, untalented (melee)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID] = BuffBroker.TestCases.MockPlayers.PaladinMelee,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID] = BuffBroker.TestCases.MockPlayers.Warrior_AP,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25782}, --g might

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, untalented (healer)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID] = BuffBroker.TestCases.MockPlayers.Warrior_AP,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25782}, --g might

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, tank",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID] = BuffBroker.TestCases.MockPlayers.Warrior_AP,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank.GUID,},TotalCount=1},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=25899}, --g sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25782}, --g might

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=20911}, --sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.PaladinTank.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, imp might (melee)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinMelee_AP,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID] = BuffBroker.TestCases.MockPlayers.Warrior_AP,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, imp might (healer)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer_AP,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID] = BuffBroker.TestCases.MockPlayers.Warrior_AP,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_AP.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, imp might (tank)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank_AP,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID] = BuffBroker.TestCases.MockPlayers.Warrior_AP,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25899}, --g sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20911}, --sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, imp wisdom",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID] = BuffBroker.TestCases.MockPlayers.Warrior_AP,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25782}, --g might

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=19740}, --might
			},
		},
		
		{
			Test = "Paladin, imp wisdom/might",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID] = BuffBroker.TestCases.MockPlayers.Warrior_AP,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer_MP5_AP.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=19740}, --might
			},
		},
	},
	
	PartyPallyPally =
	{
		{
			Test = "Paladin, untalented (melee), partial wisdom/AP active",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID] = BuffBroker.TestCases.MockPlayers.PaladinMelee,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID},TotalCount=2},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID},TotalCount=2},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			ActiveBuffs = {
				{Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="AP", spellid=19740}, --might
				{Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="MP5", spellid=19742}, --wisdom
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
			},
		},
		
		{
			Test = "Paladin, untalented (melee), full wisdom/might active",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID] = BuffBroker.TestCases.MockPlayers.PaladinMelee,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID},TotalCount=2},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID},TotalCount=2},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			ActiveBuffs = {
				{Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="AP", spellid=19740}, --might
				{Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="AP", spellid=19740}, --might
				{Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="MP5", spellid=19742}, --wisdom
				{Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="AP", spellid=19740}, --might
				{Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="MP5", spellid=19742}, --wisdom
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
			},
		},
		
		{
			Test = "Paladin, tank (talented AP), full wisdom/might active",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank_AP,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinMelee_AP,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID},TotalCount=2},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID},TotalCount=2},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
			},
			ActiveBuffs = {
				{Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, Type="AP", spellid=19740}, --might
				{Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, Type="AP", spellid=19740}, --might
				{Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, Type="MP5", spellid=19742}, --wisdom
				{Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, Type="AP", spellid=19740}, --might
				{Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, Type="MP5", spellid=19742}, --wisdom
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25899}, --g sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee_AP.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20911}, --sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
			},
		},
		
		{
			Test = "Paladin, untalented (melee), full kings active",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID] = BuffBroker.TestCases.MockPlayers.PaladinMelee,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID},TotalCount=2},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID},TotalCount=2},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			ActiveBuffs = {
				{Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="STATS", spellid=20217}, --kings
				{Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="STATS", spellid=20217}, --kings
				{Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="STATS", spellid=20217}, --kings
				{Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="STATS", spellid=20217}, --kings
				{Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="STATS", spellid=20217}, --kings
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
			},
		},
		
		{
			Test = "Paladin, untalented (melee), partial kings active",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID] = BuffBroker.TestCases.MockPlayers.PaladinMelee,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID},TotalCount=2},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID},TotalCount=2},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			ActiveBuffs = {
				{Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="STATS", spellid=20217}, --kings
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
			},
		},
		
		{
			Test = "Paladin, untalented (melee), 1 far",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID] = BuffBroker.TestCases.MockPlayers.PaladinMelee,
				[BuffBroker.TestCases.MockPlayers.PureMelee.GUID] = BuffBroker.TestCases.MockPlayers.PureMelee,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.MeleeManaFar.GUID] = BuffBroker.TestCases.MockPlayers.MeleeManaFar,
				[BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID},TotalCount=2},
				["AP"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID,BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID},TotalCount=2},
				["TANK"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
			},
			ActiveBuffs = {
				{Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="STATS", spellid=20217}, --kings
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinMelee.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeManaFar.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeManaFar.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.MeleeManaFar.GUID, spellid=19742}, --wisdom
			},
		},
	},
	
	RealPartyTesting =
	{
		{
			Test = "Paladin, tank (AP)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank_AP,
				[BuffBroker.TestCases.MockPlayers.PureMeleeAlt.GUID] = BuffBroker.TestCases.MockPlayers.PureMeleeAlt,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.MeleeMana.GUID] = BuffBroker.TestCases.MockPlayers.MeleeMana,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
			},
			ActiveBuffs = {
				{Target=BuffBroker.TestCases.MockPlayers.PureMeleeAlt.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Type="AP", spellid=25782}, --g might
				{Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Type="AP", spellid=19740}, --might
				{Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Type="STATS", spellid=25898}, --g kings
				{Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Type="STATS", spellid=20217}, --kings
				{Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Type="TANK", spellid=20911}, --sanctuary
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMeleeAlt.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PureMeleeAlt.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.MeleeMana.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20911}, --sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=19740}, --might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, --wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, --kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, --wisdom
			},
		},

		{
			Test = "Paladin tank, 2 warriors",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank_AP,
				[BuffBroker.TestCases.MockPlayers.Warrior.GUID] = BuffBroker.TestCases.MockPlayers.Warrior,
				[BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID] = BuffBroker.TestCases.MockPlayers.Warrior_AP,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.Healer.GUID] = BuffBroker.TestCases.MockPlayers.Healer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID},TotalCount=1},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=3},
				["HP"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID,},TotalCount=2},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
			},
			ActiveBuffs = {
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25899}, --g sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=25782}, --g might

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20911}, -- sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Possible,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=19740}, -- might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Healer.GUID, spellid=19742}, -- wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, -- wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Possible,Target=BuffBroker.TestCases.MockPlayers.Warrior.GUID, spellid=19740}, -- might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Possible,Target=BuffBroker.TestCases.MockPlayers.Warrior_AP.GUID, spellid=19740}, -- might
			},
		},
		
		{
			Test = "Paladin, 2 druids (tree and owl)",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank_AP,
				[BuffBroker.TestCases.MockPlayers.Owl.GUID] = BuffBroker.TestCases.MockPlayers.Owl,
				[BuffBroker.TestCases.MockPlayers.Tree.GUID] = BuffBroker.TestCases.MockPlayers.Tree,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID},TotalCount=2},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID},TotalCount=2},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["WILD"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Tree.GUID,BuffBroker.TestCases.MockPlayers.Owl.GUID},TotalCount=2},
				["THORNS"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Owl.GUID,},TotalCount=2},
			},
			ActiveBuffs = {
				{Target=BuffBroker.TestCases.MockPlayers.Owl.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="STATS", spellid=25898}, --g kings
				{Target=BuffBroker.TestCases.MockPlayers.Tree.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="STATS", spellid=25898}, --g kings
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Owl.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25899}, --g sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=25782}, --g might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Owl.GUID, spellid=19742}, -- wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Tree.GUID, spellid=19742}, -- wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=19742}, -- wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20911}, -- sanctuary
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=19740}, -- might
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, -- wisdom
			},
		},
		{
			Test = "Paladin, 2 druids (tree and owl), expired buffs",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank_AP,
				[BuffBroker.TestCases.MockPlayers.Owl.GUID] = BuffBroker.TestCases.MockPlayers.Owl,
				[BuffBroker.TestCases.MockPlayers.Tree.GUID] = BuffBroker.TestCases.MockPlayers.Tree,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID},TotalCount=2},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID},TotalCount=2},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["WILD"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Tree.GUID,BuffBroker.TestCases.MockPlayers.Owl.GUID},TotalCount=2},
				["THORNS"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Owl.GUID,},TotalCount=2},
			},
			ActiveBuffs = {
				{Target=BuffBroker.TestCases.MockPlayers.Owl.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="STATS", spellid=25898}, --g kings
				{Target=BuffBroker.TestCases.MockPlayers.Tree.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="STATS", spellid=25898}, --g kings
				{Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Type="STATS", spellid=25898}, --g kings
				{Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Type="TANK", Expired = true, spellid=20911}, --sanctuary
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Owl.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Owl.GUID, spellid=19742}, -- wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Tree.GUID, spellid=19742}, -- wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=19742}, -- wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20911}, -- sanctuary
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=19740}, -- might
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, -- wisdom
			},
		},
		{
			Test = "Paladin, shaman, rogue, expired buffs",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank_AP,
				[BuffBroker.TestCases.MockPlayers.Owl.GUID] = BuffBroker.TestCases.MockPlayers.Owl,
				[BuffBroker.TestCases.MockPlayers.Tree.GUID] = BuffBroker.TestCases.MockPlayers.Tree,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID},TotalCount=2},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID},TotalCount=2},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["WILD"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Tree.GUID,BuffBroker.TestCases.MockPlayers.Owl.GUID},TotalCount=2},
				["THORNS"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Owl.GUID,},TotalCount=2},
			},
			ActiveBuffs = {
				{Target=BuffBroker.TestCases.MockPlayers.Owl.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="STATS", spellid=25898}, --g kings
				{Target=BuffBroker.TestCases.MockPlayers.Tree.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Type="STATS", spellid=25898}, --g kings
				{Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Type="STATS", spellid=25898}, --g kings
				{Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Type="TANK", Expired = true, spellid=20911}, --sanctuary
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Owl.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Owl.GUID, spellid=19742}, -- wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Tree.GUID, spellid=19742}, -- wisdom
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, spellid=19742}, -- wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20911}, -- sanctuary
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=19740}, -- might
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Likely,Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, spellid=19742}, -- wisdom
			},
		},
		{
			Test = "Paladin tank, op shaman, DK, priest, hunter, no overlapping totems",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank_AP,
				[BuffBroker.TestCases.MockPlayers.ShamanHealer_MP5.GUID] = BuffBroker.TestCases.MockPlayers.ShamanHealer_MP5,
				[BuffBroker.TestCases.MockPlayers.Hunter.GUID] = BuffBroker.TestCases.MockPlayers.Hunter,
				[BuffBroker.TestCases.MockPlayers.ShadowPriest.GUID] = BuffBroker.TestCases.MockPlayers.ShadowPriest,
				[BuffBroker.TestCases.MockPlayers.DeathKnight.GUID] = BuffBroker.TestCases.MockPlayers.DeathKnight,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.ShamanHealer_MP5.GUID,},TotalCount=2},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
			},
			ActiveBuffs = {
				{Target=BuffBroker.TestCases.MockPlayers.ShamanHealer_MP5.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Type="STATS", spellid=25898}, --g kings
				{Target=BuffBroker.TestCases.MockPlayers.DeathKnight.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Type="AP", spellid=25782}, --g might
				{Target=BuffBroker.TestCases.MockPlayers.Hunter.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Type="AP", spellid=25782}, --g might
				{Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Source=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Type="TANK", spellid=20911}, --sanctuary
			},
			Suggestions = {
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.ShadowPriest.GUID, spellid=25898}, --g kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.ShadowPriest.GUID, spellid=25894}, --g wisdom
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.ShamanHealer_MP5.GUID, spellid=25894}, --g wisdom

				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.DeathKnight.GUID, spellid=19740}, -- might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.DeathKnight.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Hunter.GUID, spellid=19740}, -- might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Hunter.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.Hunter.GUID, spellid=19742}, -- wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20911}, -- sanctuary
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, spellid=19740}, -- might
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.ShadowPriest.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.ShadowPriest.GUID, spellid=19742}, -- wisdom
				{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.ShamanHealer_MP5.GUID, spellid=20217}, -- kings
				{Confidence=BBConstants.base.Confidence.Optional,Target=BuffBroker.TestCases.MockPlayers.ShamanHealer_MP5.GUID, spellid=19742}, -- wisdom
			},
		},
		{
			Test = "Druid, Druid, wtf marks",
			Others = "none",
			Raid = "party",
			Players = {
				[BuffBroker.TestCases.MockPlayers.Owl.GUID] = BuffBroker.TestCases.MockPlayers.Owl,
				[BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID] = BuffBroker.TestCases.MockPlayers.PaladinTank_AP,
				[BuffBroker.TestCases.MockPlayers.Tree.GUID] = BuffBroker.TestCases.MockPlayers.Tree,
				[BuffBroker.TestCases.MockPlayers.Caster.GUID] = BuffBroker.TestCases.MockPlayers.Caster,
				[BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID] = BuffBroker.TestCases.MockPlayers.PaladinHealer,
			},
			PlayerGUID = BuffBroker.TestCases.MockPlayers.Owl.GUID,
			Results = {
				["MP5"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID},TotalCount=2},
				["AP"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=2},
				["HP"] = {Strength=BBConstants.base.Buffs.None,Players = {},TotalCount=0},
				["STATS"] = {Strength=BBConstants.base.Buffs.BasicLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID},TotalCount=2},
				["TANK"] = {Strength=BBConstants.base.Buffs.FullTalentedLong,Players = {BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID,},TotalCount=1},
				["WILD"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Tree.GUID,BuffBroker.TestCases.MockPlayers.Owl.GUID},TotalCount=2},
				["THORNS"] = {Strength=BBConstants.base.Buffs.FullTalented,Players = {BuffBroker.TestCases.MockPlayers.Owl.GUID,},TotalCount=2},
			},
			ActiveBuffs = {
				{Target=BuffBroker.TestCases.MockPlayers.Owl.GUID, Source=BuffBroker.TestCases.MockPlayers.Tree.GUID, Type="WILD", spellid=21849}, --gift of the wild
				{Target=BuffBroker.TestCases.MockPlayers.PaladinTank_AP.GUID, Source=BuffBroker.TestCases.MockPlayers.Tree.GUID, Type="WILD", spellid=21849}, --gift of the wild
				{Target=BuffBroker.TestCases.MockPlayers.Tree.GUID, Source=BuffBroker.TestCases.MockPlayers.Tree.GUID, Type="WILD", spellid=21849}, --gift of the wild
				{Target=BuffBroker.TestCases.MockPlayers.Caster.GUID, Source=BuffBroker.TestCases.MockPlayers.Tree.GUID, Type="WILD", spellid=21849}, --gift of the wild
				{Target=BuffBroker.TestCases.MockPlayers.PaladinHealer.GUID, Source=BuffBroker.TestCases.MockPlayers.Tree.GUID, Type="WILD", spellid=21849}, --gift of the wild
			},
			Suggestions = {
				--{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Owl.GUID, spellid=25894}, --g wisdom

				--{Confidence=BBConstants.base.Confidence.Certain,Target=BuffBroker.TestCases.MockPlayers.Owl.GUID, spellid=19742}, -- wisdom
			},
		},
	},
	
} -- Groups