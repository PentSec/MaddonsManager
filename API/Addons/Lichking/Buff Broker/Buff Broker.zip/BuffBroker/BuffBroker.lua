-- Global instance of the mod
-- *AceConsole included for :Print
BuffBroker = LibStub('AceAddon-3.0'):NewAddon('BuffBroker', 'AceConsole-3.0', 'AceEvent-3.0')

local AceConfig = LibStub('AceConfig-3.0')
local AceConfigDialog = LibStub('AceConfigDialog-3.0')
local AceDB = LibStub('AceDB-3.0')

-- load localization strings
local L = LibStub('AceLocale-3.0'):GetLocale('BuffBroker')

-- load global strings
_G["BINDING_HEADER_BUFFBROKER_HEADER"] = 'Buff Broker'
_G["BINDING_NAME_CLICK BuffBroker_CastSuggestionButton:LeftButton"] = 'Cast the Next Suggested Enhancement'

-- optional deps
local LBF = LibStub('LibButtonFacade', true)

local profileDB -- Initialized in :OnInitialize()


--[[ MUSINGS on components:

Player State object
-Variables:
--stores party/raid members:  name, GUID, class, role
--Stores relevant active buffs
--stores party
--stores coverage
--stores buffs party members can provide:  spellids, slot, potency, application (totem, raid-wide, etc)
-Activity:
--Monitors AURA_CHANGE events, to keep active buffs accurate/current
--Monitors players leaving/entering client bubble of awareness
--Monitors party members joining/leaving party
--Monitors party members changing spec
-Notifications to Parent:
--Aura changed on party member (activated/fell off); re-sort suggestions
--Aura expired on party member (based on timeout, could be "about to expire"); re-sort suggestions
--Party member left; remove suggestions
--Party member joined; add suggestions
--coverage changed; resort suggestions
--Party member changed spec;  remove suggestions, add suggestions

Suggestion list object
-Variables;
--stores all possible single-target suggestions
--stores all possible raid-wide suggestions
--stores all possible class-wide suggestions
-Activity:
--Monitors Aura changed on party member, from player state
--Monitors aura expired, from player state
--Monitors party join/leave, from player state
--Monitors spec change, from player state
-Notifications to Parent:
--Order Changed
--Suggestions changed

Button object
-Variables:
--combat state
--top-listed suggestion
-Activity:
--Monitors order/suggestion change, from suggestion list

]]

-- Debug options
BuffBroker.PrintDebug = false
BuffBroker.ActivityFrame = nil
BuffBroker.FailCodes = {}
BuffBroker.Textures = {}

BuffBroker.InCombat = nil
BuffBroker.InSanctuary = nil

BuffBroker.Idle = nil
BuffBroker.SeededSelf = nil
BuffBroker.IsMounted = nil

BuffBroker.TalentGroup = 1

BuffList = {}

-- tooltip
BuffList.TooltipPrime = L["Loading..."]
BuffList.TooltipDetail = L["Buff Broker is starting up"]
BuffList.TooltipMinor = ''
BuffList.tooltipFormatter = ''
BuffList.TooltipError = ''

-- current state
BuffList.InspectOutstanding = nil
BuffList.InspectBusy = nil
BuffList.InspectGUID = nil
BuffList.InspectPending = nil
BuffList.InspectComplete = nil
BuffList.InspectLastChecked = nil
BuffList.InspectIdleWait = 4
BuffList.InspectTimeout = 6
BuffList.BusyWarningTimeout = 120
BuffList.Suggestions = {}
BuffList.LastSuggested = nil

BuffList.AurasFirstChangedAt = nil
BuffList.AurasLastChangedAt = nil
BuffList.LastUpdateActivity = nil
BuffList.UpdateActivityRate = 0.25

BuffList.LastCheckedRange = nil
BuffList.RangeCheckDelay = 5


-- config

local function getProfileOption(info)
	local option = profileDB[info.arg]
	local buffSpec = tonumber(string.sub(info.arg, 1, 1))
	local buffName = string.sub(info.arg, 2, string.len(info.arg))
	
	-- if: is a spec-specific buff type
	-- if buffSpec and self.Constants.BuffSlots[buffName] then
	if buffSpec then
		option = profileDB.slots[buffSpec][buffName]
	end -- if: is a spec-specific buff type
	
	return option
end

local function setProfileOption(info, value)
	
	local buffSpec = tonumber(string.sub(info.arg, 1, 1))
	local buffName = string.sub(info.arg, 2, string.len(info.arg))
	
	-- if: is a spec-specific buff type
	if buffSpec and BuffBroker.Constants.BuffSlots[buffName] then
		-- buff enabled/disabled
		if value then
			profileDB.slots[buffSpec][buffName] = true
		else
			profileDB.slots[buffSpec][buffName] = false
		end
	else
		-- any other setting changed
		profileDB[info.arg] = value
	end
	
	-- if: UI settings changed, take effect now
	if info.arg == "scale" then
		BuffBroker.BuffButton:SetScale(value / 100)
		BuffBroker.MoveFrame:SetScale(value / 100)
	elseif info.arg == "lock" then
		if value == true then
			-- locking
			BuffBroker.MoveFrame:Hide()
		else
			-- unlocking
			
			if BuffBroker.BuffButton:IsVisible() then
				BuffBroker.MoveFrame:Show()
			end
		end
	elseif info.arg == "show" then
		if value == true then
			BuffBroker.ActivityFrame:Show()
			BuffBroker:FullProfile()
		else
			BuffBroker.ActivityFrame:Hide()
		end
	elseif info.arg == "healerLevel" then
		BuffBroker:CheckRoles()
	elseif info.arg == "hiddenWhileIdle" then
		-- hide while idle
		if value == true then
			if BuffBroker.Idle and BuffBroker.BuffButton:IsVisible() then
				BuffBroker.BuffButton:Hide()
				BuffBroker.MoveFrame:Hide()
			end
		
		-- else; show while idle
		else
			if BuffBroker.Idle and not BuffBroker.BuffButton:IsVisible() then
				BuffBroker.BuffButton:Show()
				if not profileDB.lock then
					BuffBroker.MoveFrame:Show()
				end
			end
		end
	elseif info.arg == "hiddenInSanctuary" and BuffBroker.InSanctuary then
		-- disable in sanctuary
		if value == true then
			BuffBroker:ClearButtonBuff()
		else
			BuffBroker:AssignNextSuggestion()
		end
	elseif info.arg == "consistent" or info.arg == "friendly" then
		BuffList.AurasFirstChangedAt = GetTime()
		BuffList.AurasLastChangedAt = GetTime()
	end
end

-- Slash commands (via AceConfig-3.0)
local options = {
	type = 'group',
	get = getProfileOption,
	set = setProfileOption,
	args = {
		general = {
			type = 'group',
			name = L["General Settings"],
			cmdInline = true,
			order = -1,
			args = {
				version = {
					type = 'description',
					name = '6.0.7',
					order = 1,
				},
				clientVersion = {
					type = 'description',
					name = 'Client Version',
					order = 2,
				},
				behavior  = {
					type = 'header',
					name = L["Behavior"],
					order = 3,
				},
				behavior_desc = {
					type = 'description',
					name = L["Change how Buff Broker handles group-wide buffs"]..'\n',
					order = 4,
				},
				refreshAtDuration = {
					type = 'range',
					order = 5,
					width = 'triple',
					name = L["Refresh Time"],
					desc = L["Refresh buffs with less than X seconds remaining (0 = when it expires)"],
					arg = 'refreshAtDuration',
					get = getProfileOption,
					set = setProfileOption,
					min = 0,
					max = 1800, -- set to level cap + 3
					step = 10,
				},
				raidBuffAttendThreshold = {
					type = 'range',
					order = 6,
					width = 'single',
					name = L["Attendance Threshold"],
					desc = L["minimum % of targets nearby, in order to cast a raid-wide spell"],
					arg = 'raidBuffAttendThreshold',
					get = getProfileOption,
					set = setProfileOption,
					min = 0,
					max = 100,
					step = 5,
				},
				raidBuffHeadCountThreshold = {
					type = 'range',
					order = 7,
					width = 'single',
					name = L["Head Count Threshold"],
					desc = L["minimum # of targets nearby, in order to cast a raid-wide spell"],
					arg = 'raidBuffHeadCountThreshold',
					get = getProfileOption,
					set = setProfileOption,
					min = 1,
					max = 40,
					step = 1,
				},
				--[[frugal = {
					type = 'toggle',
					order = 8,
					width = 'single',
					name = L["Frugal"],
					desc = L["don't use class/raid wide buffs when only one eligible target exists"],
					arg = 'frugal',
					get = getProfileOption,
					set = setProfileOption,
				},]]
				friendly = {
					type = 'toggle',
					order = 9,
					width = 'single',
					name = L["Friendly"],
					desc = L["don't apply buffs another raid member cast, even if theirs expires"],
					arg = 'friendly',
					get = getProfileOption,
					set = setProfileOption,
				},
				healerLevel = {
					type = 'range',
					order = 10,
					width = 'double',
					name = L["Healer Level"],
					desc = L["Prefer mana regeneration over stats, for healers under this level"],
					arg = 'healerLevel',
					get = getProfileOption,
					set = setProfileOption,
					min = 1,
					max = 81,
					step = 1,
				},
				consistent = {
					type = 'toggle',
					order = 11,
					width = 'single',
					name = L["Consistent"],
					desc = L["Keep the last-cast spell active as long as you're with a party, even if it's not the 'best' choice"],
					arg = 'consistent',
					get = getProfileOption,
					set = setProfileOption,
				},
				appearance  = {
					type = 'header',
					name = L["Appearance"],
					order = 20,
				},
				appearance_desc = {
					type = 'description',
					name = L["Change how Buff Broker looks, feels, and fits"]..'\n',
					order = 21,
				},
				scale = {
					type = 'range',
					order = 22,
					width = 'single',
					name = L["UI Scaling"],
					desc = L["change the size of the button"],
					arg = 'scale',
					get = getProfileOption,
					set = setProfileOption,
					min = 1,
					max = 100,
					step = 5,
				},
				lock = {
					type = 'toggle',
					order = 23,
					width = 'single',
					name = L["Lock UI"],
					desc = L["Disable the UI Move Bar"],
					arg = 'lock',
					get = getProfileOption,
					set = setProfileOption,
				},
				toggle = {
					type = 'toggle',
					order = 24,
					width = 'single',
					name = L["Visible"],
					desc = L["Show/Hide the main button (scanning disabled while hidden)"],
					arg = 'show',
					get = getProfileOption,
					set = setProfileOption,
				},
				hiddenWhileIdle = {
					type = 'toggle',
					order = 25,
					width = 'single',
					name = L["Hidden while Idle"],
					desc = L["Hide the main button when no action required (background scanning still active)"],
					arg = 'hiddenWhileIdle',
					get = getProfileOption,
					set = setProfileOption,
				},
				hiddenInSanctuary = {
					type = 'toggle',
					order = 25,
					width = 'single',
					name = L["Idle in Sanctuary"],
					desc = L["Disable Suggestions while in a Sanctuary zone (Cities and Special Hubs)"],
					arg = 'hiddenInSanctuary',
					get = getProfileOption,
					set = setProfileOption,
				},
				tooltipAnchor = {
					type = 'select',
					order = 26,
					width = 'single',
					name = L["Tooltip Position"],
					desc = L["Position of the Tooltip, relative to the buff button"],
					values = {
						["ANCHOR_TOPLEFT"] = L["TOPLEFT"],
						["ANCHOR_TOP"] = L["TOP"],
						["ANCHOR_TOPRIGHT"] = L["TOPRIGHT"],
						["ANCHOR_RIGHT"] = L["RIGHT"],
						["ANCHOR_BOTTOMRIGHT"] = L["BOTTOMRIGHT"],
						["ANCHOR_BOTTOM"] = L["BOTTOM"],
						["ANCHOR_BOTTOMLEFT"] = L["BOTTOMLEFT"],
						["ANCHOR_LEFT"] = L["LEFT"],
						},
					arg = 'tooltipAnchor',
					get = getProfileOption,
					set = setProfileOption,
				},
				
				support  = {
					type = 'header',
					name = L["Support"],
					order = 70,
				},
				support_desc = {
					type = 'description',
					name = L["Test, fix, or reset Buff Broker"]..'\n',
					order = 71,
				},
				testBuffs = {
					order = 72,
					name = L["Test: Buff Providers"],
					desc = L["perform unit tests against sample party compositions"],
					type = 'execute',
					func = function() BuffBroker:TestBestBuffs() end,
					dialogHidden = true,
				},
				testSuggestions = {
					order = 73,
					name = L["Test: Suggestions"],
					desc = L["perform unit tests for suggestions against sample parties"],
					type = 'execute',
					func = function() BuffBroker:TestSuggestions() end,
					dialogHidden = true,
				},
				scanActive = {
					order = 74,
					name = 'scanActive',
					desc = L["Perform a full scan of the buffs active on your current group"],
					type = 'execute',
					func = function() BuffBroker:ScanActiveAll() end,
					dialogHidden = true,
				},
				ScanAvailable = {
					order = 75,
					name = 'scanAvailable',
					desc = L["Perform a full scan of the buffs available to your current group"],
					type = 'execute',
					func = function() BuffBroker:ScanAvailable() end,
					dialogHidden = true,
				},
				suggest = {
					order = 77,
					name = 'suggest',
					desc = L["return suggestions for number of party members"],
					type = 'execute',
					func = function() BuffBroker:Suggest() end,
					dialogHidden = true,
				},
				dumpSuggestions = {
					order = 78,
					name = L["Output Suggestions"],
					desc = L["print suggestions (sorted) to the chat window; includes relevant sort criteria"],
					type = 'execute',
					func = function()
						GameTooltip:Hide()
						BuffBroker:DumpSuggestions() end,
				},
				reset = {
					order = 79,
					name = L["Reset"],
					desc = L["Clear cached data and restart the addon"],
					type = 'execute',
					func = function() BuffBroker:Reset() end,
				},
				standby = {
					type = 'toggle',
					order = 80,
					width = 'double',
					name = L["Enabled"],
					desc = L["Suspend/resume this addon"],
					get = function() return BuffBroker:IsEnabled() end,
					set = function()
						if BuffBroker:IsEnabled() then
							BuffBroker:Disable()
						else
							BuffBroker:Enable()
						end
					end,
					dialogHidden = true,
				},
				show = {
					order = 81,
					name = L["Show"],
					desc = L["Shows the main window"],
					type = 'execute',
					func = function() BuffBroker.ActivityFrame:Show() end,
					dialogHidden = true,
				},
				hide = {
					order = 82,
					name = L["Hide"],
					desc = L["Hides the main window"],
					type = 'execute',
					func = function() BuffBroker.ActivityFrame:Hide() end,
					dialogHidden = true,
				},
				
				buffSlots  = {
					type = 'header',
					name = L["Buff Selection"],
					order = 30,
				},
				buffSlots_desc = {
					type = 'description',
					name = L["Pick which Buffs to parse, analyze, and suggest"]..'\n',
					order = 31,
				},
				--[[
				MAGE_ARMOR = { -- <- auto-generated entries should look like this
					type = 'toggle',
					order = 32,
					width = 'single',
					name = L["MAGE_ARMOR"],
					desc = L["MAGE_ARMOR_DESC"],
					arg = 'MAGE_ARMOR',
					get = getProfileOption,
					set = setProfileOption,
				},]]
				
				buffSlotsDualSpec = {
					type = 'header',
					name = L["Buff Selection - Dual Spec"],
					order = 50,
					dialogHidden = true,
				},
				buffSlotsDualSpec_desc = {
					type = 'description',
					name = L["Pick which Buffs to parse, analyze, and suggest for your offspec"]..'\n',
					order = 51,
					dialogHidden = true,
				},
				--[[
				MAGE_ARMOR = { -- <- auto-generated entries should look like this
					type = 'toggle',
					order = 52,
					width = 'single',
					name = L["MAGE_ARMOR"],
					desc = L["MAGE_ARMOR_DESC"],
					arg = 'MAGE_ARMOR',
					get = getProfileOption,
					set = setProfileOption,
				},]]
			}, -- args
		}, -- General
	}, -- args
} -- .Options

--[[ Save Versions:
1.0 -> 1.1: "slots" sub-tree'd by spec:  slot{1={NAME=TRUE, ...}...}
]]

local defaults = {
	base = {
		profile = {
			saveVersion = 1.1,
			refreshAtDuration = 20,
			raidBuffAttendThreshold = 0,
			raidBuffHeadCountThreshold = 1,
			--frugal = false,
			friendly = false,
			consistent = true,
			healerLevel = 68,
			screenX = 0,
			screenY = -100,
			scale = 100,
			lock = false,
			show = true,
			tooltipAnchor = "ANCHOR_BOTTOM",
			skin = {
				ID = 'Blizzard',
				Backdrop = true,
				Gloss = 0,
				Zoom = false,
				Colors = {},
			},
			subskin = {
				ID = 'Blizzard',
				Backdrop = true,
				Gloss = 0,
				Zoom = false,
				Colors = {},
			},
			slots = {
				[1] = {},
				[2] = {},
			},
			activeSelfBuffs = {
				{}, -- talent group 1
				{}, -- talent group 2
			},
		},
	},
}

function BuffBroker:DumpSuggestions()
	
	
	--print("The " .. info.option.desc )
	local AceGUI = LibStub("AceGUI-3.0")
	local os, key, suggestion, player
	local kB, vB
	local name
	local f = AceGUI:Create("Frame")
	local editBox = AceGUI:Create("MultiLineEditBox")
	
	f:SetCallback("OnClose",function(widget) AceGUI:Release(widget) end)
	f:SetTitle("BuffBroker Suggestions")
	f:SetLayout("Fill")
	f:SetHeight(600)
	f:SetWidth(800)
	f:SetPoint("CENTER", 0, 0)
	-- editBox:DisableButton(true)
	f:AddChild(editBox)

	os = string.format('--BuffBroker Suggestions (%d)--\n', table.getn(BuffList.Suggestions))

	--print('--BuffBroker Suggestions ('..table.getn(BuffList.Suggestions)..')--')
	for key, suggestion in ipairs(BuffList.Suggestions) do
		os = os..'Cast '..GetSpellInfo(suggestion.spellid)
		
		if suggestion.TargetProfile then
			os = os.." on "..suggestion.TargetProfile.Name
		else
			os = os.." on <no target>"
		end
		
		os = os..' @ '..suggestion.Confidence..':'
		
		if suggestion.BetterActive then
			os = os..' Better Active;'
		end
			
		if suggestion.UnBuffedHeadCount then
			os = os..' #'..suggestion.UnBuffedHeadCount..';'
		end
		
		if suggestion.Attendance then
			os = os..' '..(suggestion.Attendance*100)..'%;'
		end
		
		os = os..'\n'
		--print(os)
	end
	
	os = os..string.format('--BuffBroker Players (%i)--\n', self.PlayerState:GetCount())
	--print('--BuffBroker Players ('..self.PlayerState:GetCount()..')--')

	for key, player in self.PlayerState:Iterator() do
		os = os..'['..key..'] '..player.Name..' the level '..player.Level..' '..player.Class..' ('..player.Role..'): '
		
		if player.Stale then
			os = os..' Stale;'
		end
		
		os = os..' Buffs: '
		for kB, vB in pairs(player.ActiveBuffs) do
			os = os..kB..' from '
			
			name = self.PlayerState:GetAttribute(vB.CasterGUID, "Name")
			
			if name == nil then
				name = '[Nobody]'
			end
			
			os = os..name
			
			if vB.Expires and vB.Expires ~= 0 then
				os = os..' expires in '..math.floor(vB.Expires - GetTime())..'s'
			else
				os = os..' never expires'
			end
			os = os..', '
		end
		os = os..'\n'
		--print(os)
	end

	os = os..'--BuffBroker Finished Report--'
	editBox:SetText(os)
end

function BuffBroker:Reset()
	BuffList.Suggestions = {}

	self.PlayerState:Reset()

	self.InCombat = InCombatLockdown()
	self.InSanctuary = UnitIsPVPSanctuary("player")
	self.Idle = nil
	self.TalentGroup = 1

	BuffList.InspectOutstanding = nil
	BuffList.InspectBusy = nil
	BuffList.InspectGUID = nil
	BuffList.InspectPending = nil
	BuffList.InspectComplete = nil
	BuffList.InspectLastChecked = nil
	BuffList.LastSuggested = nil

	BuffList.TooltipPrime = L["Loading..."]
	BuffList.TooltipDetail = L["Buff Broker is starting up"]
	BuffList.TooltipMinor = ''
	BuffList.tooltipFormatter = ''

	self.db.profile.screenY = 0
	self.db.profile.screenX = 0
	profileDB.screenY = 0
	profileDB.screenX = 0
	self.ActivityFrame:SetPoint('TOPLEFT', 0, 0)
	
	BuffList.AurasFirstChangedAt = nil
	BuffList.AurasLastChangedAt = nil

	BuffList.LastCheckedRange = nil
	BuffList.RangeCheckDelay = 5

	BuffBroker:ClearState()
end

function BuffBroker:Suggest()
	self.BuffButton:Click()
end

function BuffBroker:HasExpired(activeBuff, thePlayerGUID)
	local hasExpired = true
	local matchForm
	
	-- if: buff exists
	if activeBuff then
		-- if: known source
		if activeBuff.CasterGUID then
			-- if: friendly, and cast by a friend
			if profileDB.friendly
			and activeBuff.CasterGUID ~= thePlayerGUID then
				-- assume is active (ie: don't poach)
				hasExpired = false
			else
				-- calculate if ACTUALLY can expire, and if ready to re-buff
				hasExpired = (activeBuff.Expires and activeBuff.Expires ~= 0)
					and ((activeBuff.Expires - GetTime()) < profileDB.refreshAtDuration)
			end -- if: check if can't poach buffs

		else
			-- unknown source;  check for absolute expiration
			hasExpired = (activeBuff.Expires) and ((activeBuff.Expires - GetTime()) < 0)
		end
	end -- if: buff exists
	
	return hasExpired
end

-- Build the list of suggestions, using placeholder attributes
function BuffBroker:BuildSuggestList()
	local playerProfile
	local myName
	local mySlotName, ourCurrentSlot
	local currentSlotEntry
	local buffLabel
	local buffLabels
	local currentGUID
	local currentProfile
	local buffPriorities
	local currentName
	local suggestionConfidence
	local committedBuffers
	local key
	local currentActiveBuff
	local buffActive
	local theirSlotName
	local theirSlot
	local theirSlotNameEntry
	local theirSlotEntry
	local buffLookup
	local committedCount
	local caster_slot
	local activeBuffStrength
	local activeExpired
	local possibleSuggestion
	local sortedSuggestList = {}
	local wantsBuffCount
	local hasBuffCount
	local hasBetterFromMeCount
	local wantsBetterCount
	local headCount
	
	local inRangeCount
	local someProfile
	local i
	local currentSuggestion
	local activeSlotName
	local buffSlot
	local activeSuggestions = {}
	local spellName
	local groupsToScan
	local className
	local classValue
	local someTarget
	local someTargetProfile
	local currentGroupName
	local hasAwesomeGreaterBuff
	local currentTotem
	local currentTotemLabel
	local someSlotName
	local myGUID = self.PlayerState:MyGUID()
	local playerProfile = self.PlayerState:GetProfile(myGUID) 
	local mockLabelArray = {}
	
	MyDebugPrint("Rebuilding suggest list from scratch")
	
	-- if: I'm profiled/cached
	if self.PlayerState:IsInitialized(BuffList.InspectFucked) then
		myName = playerProfile.Name

		-- suggestion list will be empty if player can't do ANY best buffs :3

		-- for: each buffslot we could use
		for mySlotName, ourCurrentSlot in pairs(playerProfile.BuffSlots) do
			MyDebugPrint("suggesting for buffslot %s", mySlotName)
			
			-- for: each spell in our current buffslot
			for currentSlotID, currentSlotEntry in pairs(ourCurrentSlot) do
				buffLabels = self.Constants:SpellInfoFromID(currentSlotID)
				spellName = GetSpellInfo(currentSlotID)
				
				-- if: spell is an aura, and known by the player
				-- if buffLabels and spellName and IsSpellKnown(currentSlotID) then
				if buffLabels and spellName then

					-- if: old style single-type returned
					if type(buffLabels) == "string" then
						-- convert to new multi-benefit result
						mockLabelArray[1] = buffLabels
						buffLabels = mockLabelArray
					end -- if: old style single-type returned

					-- single-target buff
					if self.Constants.Scope.Individual == currentSlotEntry.Scope then

						-- for: each player/target
						for currentGUID, currentProfile in self.PlayerState:Iterator() do

							MyDebugPrint("generating single-target suggestion for %s on %s", tostring(spellName), currentProfile.Name)
							
							possibleSuggestion = {
								Scope = self.Constants.Scope.Individual,
								Confidence = self.Constants.Confidence.None,
								Target = currentGUID, -- placeholder
								spellid = currentSlotID,
								TargetProfile = currentProfile, -- placeholder
								Attendance = 1,
								UnBuffedHeadCount = 0,
								IsDominantRole = false,
								Class = currentProfile.Class,
								AwesomeActive = false,
								RoleCount = {
									[currentProfile.Role] = 1,
								},
								Mounted = currentSlotEntry.Mounted,
							}

							table.insert(sortedSuggestList, possibleSuggestion)
						end -- for: each player/target
						
					-- self-buff
					elseif self.Constants.Scope.Self == currentSlotEntry.Scope then
						--if BuffBroker:HasExpired(thePlayers[myGUID].ActiveBuffs[buffLabel], myGUID) and IsSpellKnown(currentSlotID) then
						
						MyDebugPrint("generating single-target suggestion for %s on self", tostring(spellName))

						possibleSuggestion = {
							Scope = self.Constants.Scope.Self,
							Confidence = self.Constants.Confidence.Certain,
							Target = myGUID,
							spellid = currentSlotID,
							TargetProfile = playerProfile,
							Attendance = 1,
							UnBuffedHeadCount = 1,
							IsDominantRole = true,
							Class = playerProfile.Class,
							RoleCount = {
								[playerProfile.Role] = 1,
							},
							Mounted = currentSlotEntry.Mounted,
						}

						table.insert(sortedSuggestList, possibleSuggestion)

					-- group-wide buff
					elseif currentSlotEntry.Scope == self.Constants.Scope.Class
						or self.Constants:IsRaidWide(currentSlotEntry.Scope) then
						
						groupsToScan = {}

						if self.Constants.Scope.Class == currentSlotEntry.Scope then
							for classKey, className in pairs(self.Constants.Classes) do
								groupsToScan[classKey] = className
							end
							
							groupsToScan.Raid = nil
						
						else
							groupsToScan.Raid = self.Constants.Classes.Raid
						end
						
						-- for: each group to scan
						for _, currentGroupName in pairs(groupsToScan) do
						
							MyDebugPrint("generating single-target suggestion for %s on %s", tostring(spellName), currentGroupName)
							
							possibleSuggestion = {
								Scope = currentSlotEntry.Scope,
								Confidence = self.Constants.Confidence.None,
								Target = nil, -- placeholder
								spellid = currentSlotID,
								TotemSlot = self.Constants.Totems[mySlotName],
								TargetProfile = nil, -- placeholder
								Attendance = 0,
								UnBuffedHeadCount = 0,
								IsDominantRole = false,
								RoleCount = {},
								Class = currentGroupName,
								Desirability = 0,
								Mounted = currentSlotEntry.Mounted,
							}
							
							-- RoleCount
							for _, someProfile in self.PlayerState:Iterator() do
								-- if: class-scope and class matches, or player-scope and matches, and raid-scope
								if (possibleSuggestion.Scope == self.Constants.Scope.Class and possibleSuggestion.TargetProfile.Class == someProfile.Class)
								or (possibleSuggestion.Scope == self.Constants.Scope.Player and possibleSuggestion.Target == someProfile.GUID)
								or (possibleSuggestion.Scope == self.Constants.Scope.Self and possibleSuggestion.Target == someProfile.GUID)
								or self.Constants:IsRaidWide(possibleSuggestion.Scope) then
									if not possibleSuggestion.RoleCount[someProfile.Role] then
										possibleSuggestion.RoleCount[someProfile.Role] = 1
									else
										possibleSuggestion.RoleCount[someProfile.Role] = possibleSuggestion.RoleCount[someProfile.Role] + 1
									end
								end -- if: class-scope and class matches, or raid-scope 
							end
							
							-- if: is a totem, and we know how to drop dis totem
							if possibleSuggestion.TotemSlot
							and self.Constants.DownRankLookup[buffLabel]
							and self.Constants.DownRankLookup[buffLabel][currentSlotID]
							and self.Constants.DownRankLookup[buffLabel][currentSlotID].totemspellid then
								-- suggest we cast the totem's id, not the aura's id
								possibleSuggestion.TotemSpell = self.Constants.DownRankLookup[buffLabel][currentSlotID].totemspellid
								
								currentTotem = self.Constants:CurrentTotemSpell(mySlotName)
								
								if currentTotem and possibleSuggestion.TotemSpell then

									-- get name of spellid (#'s could differ in older game client versions
									currentTotemName = GetSpellInfo(currentTotem)
									suggestedTotemName = GetSpellInfo(possibleSuggestion.TotemSpell)

									-- if: totem is already on the action bar
									if currentTotemName == suggestedTotemName then
										possibleSuggestion.AwesomeActive = true
									end -- if: totem is already on the action bar
								end
							end
							
							-- for: each member of this group (class/raid)
							for guid, profile in self.PlayerState:ClassIterator(currentGroupName) do
								
								-- assign A target, or A BETTER target
								if nil == possibleSuggestion.Target
								or (profile.Near and profile.LOS and not profile.Stale) then
									possibleSuggestion.Target = guid
									possibleSuggestion.TargetProfile = profile
								end
							end -- for: each member of this group

							-- if: any members of this group could be found in the party
							if possibleSuggestion.Target and possibleSuggestion.TargetProfile then
								-- add the
								table.insert(sortedSuggestList, possibleSuggestion)
							end -- if: any members of this group could be found in the party
							
						end -- for: each group
					end -- if: self/individual/group buff
				end -- if: aura, and known by the player
			end -- for: each spell in the current buffslot
		end -- for: each buffslot
	else
		MyDebugPrint("Player not yet profiled; waiting for startup...")
	end -- if: I'm profiled/cached
	
	return sortedSuggestList
end

-- Recalculate the different attributes of each suggestion,
-- then re-sort

function BuffBroker:UpdateSuggestList(suggestions, bestBuffs)
	local myName
	local mySlotName, ourCurrentSlot
	local currentSlotEntry
	local buffLabel
	local buffLabels
	local currentGUID
	local currentProfile
	local buffPriorities
	local currentName
	local suggestionConfidence
	local committedBuffers
	local key
	local currentActiveBuff
	local buffActive
	local theirSlotName
	local theirSlot
	local theirSlotNameEntry
	local theirSlotEntry
	local buffLookup
	local committedCount
	local caster_slot
	local activeBuffStrength
	local activeExpired
	local possibleSuggestion
	local sortedSuggestList = {}
	local wantsBuffCount
	local hasBuffCount
	local hasBetterFromMeCount
	local wantsBetterCount
	local headCount
	
	local inRangeCount
	local someProfile
	local i
	local currentSuggestion
	local activeSlotName
	local buffSlot
	local activeSuggestions = {}
	local spellName
	local groupsToScan
	local className
	local classValue
	local someTarget
	local someTargetProfile
	local currentGroupName
	local hasAwesomeGreaterBuff
	local currentTotem
	local currentTotemLabel
	local someSlotName
	local myGUID = self.PlayerState:MyGUID()
	local playerProfile = self.PlayerState:GetProfile(myGUID) 
	local mockLabelArray = {}

	-- if: initialized
	if playerProfile then
	
		-- for: each suggestion
		for i, currentSuggestion in ipairs(suggestions) do

			-- check all benefits from spell; use the best in each case
			buffLabels, currentSlotName = self.Constants:SpellInfoFromID(currentSuggestion.spellid)
			spellName = GetSpellInfo(currentSuggestion.spellid)
			currentSlotEntry = self.Constants.BuffSlots[currentSlotName][currentSuggestion.spellid]

			MyDebugPrint("Updating Suggestion: cast %s", spellName)

			-- if: spell is an aura, and known by the player
			if buffLabels and spellName then

				-- if: old style single-type returned
				if type(buffLabels) == "string" then
					print("bip")
					-- convert to new multi-benefit result
					mockLabelArray[1] = buffLabels
					buffLabels = mockLabelArray
				end -- if: old style single-type returned
			end
			
			if currentSuggestion.Scope == self.Constants.Scope.Individual then
				
				-- defaults
				currentSuggestion.Confidence = self.Constants.Confidence.None
				currentSuggestion.Attendance = 0
				currentSuggestion.UnbuffedHeadCount = 0
				currentSuggestion.AwesomeActive = true
				currentSuggestion.Desirability = self:BuildDesirability(currentSuggestion)
				currentSuggestion.LastCast = false
				
				-- for the remaining attributes, consider multiple potential benefits
				for _, buffLabel in ipairs(buffLabels) do

					-- helper variables
					buffLookup = bestBuffs[buffLabel]
					currentProfile = currentSuggestion.TargetProfile
					currentGUID = currentSuggestion.Target
					
					-- confidence
					-- if: player is the only one left to do the buff
					if 1 == (buffLookup.TotalCount - committedCount) then
						-- can provide best (as can others), all others committed
						suggestionConfidence = self.Constants.Confidence.Certain

					-- elseif: player can provide the best buff
					elseif listContains(buffLookup.Players, myGUID) then
						-- down to Likely, or Possible

						coverageBy = self.PlayerState:CheckCoverage(currentProfile.Class, buffLabel)

						-- if: slot coverage
						if self.Constants.BuffSlots[coverageBy] then
							-- can provide best, slot coverage
							suggestionConfidence = self.Constants.Confidence.Possible
						elseif self.PlayerState:GetProfile(coverageBy) and coverageBy ~= myGUID then
							-- THN:  WTF ARE WE DOING HERE
							-- can provide best, but player coverage already (not us)
							suggestionConfidence = self.Constants.Confidence.Unlikely
							
						elseif not coverageBy then
							-- can provide best (as can others), no coverage
							suggestionConfidence = self.Constants.Confidence.Likely
						end
						
					-- else: player cannot provide the best buff
					else
						-- down to Optional or Unlikely
						
						-- if: slot coverage
						if self.Constants.BuffSlots[coverageBy] then
							-- can't provide best, slot coverage
							suggestionConfidence = self.Constants.Confidence.Unlikely
						elseif self.PlayerState:GetAttribute(coverageBy) and coverageBy ~= myGUID then
							-- player coverage (not us)
							suggestionConfidence = self.Constants.Confidence.Unlikely
						elseif not coverageBy then
							-- can't provide best, no coverage
							suggestionConfidence = self.Constants.Confidence.Optional
						end

					end -- else: player cannot provide the best buff				
					
					-- use BEST confidence
					if suggestionConfidence > currentSuggestion.Confidence then
						currentSuggestion.Confidence = suggestionConfidence
					end
					
					-- Attendance
					if currentProfile.Near then
					
						currentSuggestion.Attendance = 1
						
						-- unbuffedHeadCount (greater)
						if BuffBroker:HasExpired(currentProfile.ActiveBuffs[buffLabel], myGUID) then
							currentSuggestion.UnBuffedHeadCount = 1
						end -- UnBuffedHeadCount
					end -- Attendance
					
					-- AwesomeActive (default "yes", "no" if any aren't better than the best)
					if BuffBroker:GetBuffStrength(
											currentGUID,
											buffLabel,
											myGUID) >= buffLookup.Strength then
						print('awesome not active')
						currentSuggestion.AwesomeActive = false
					else
						print('awesome active')
					end
					
				end -- for: each benefit of the spell

			elseif currentSuggestion.Scope == self.Constants.Scope.Self then
			
				-- determine desirability, compared to alternatives
				currentSuggestion.Desirability = self:BuildDesirability(currentSuggestion)
				currentSuggestion.LastCast = nil
				currentSuggestion.AwesomeActive = nil
				
				-- for: each benefit, see if we applied it last time through this spell
				for _, buffLabel in ipairs(buffLabels) do

					MyDebugPrint("checking last-cast status of self buff: "..buffLabel)

					-- Last Cast
					if profileDB.activeSelfBuffs[self.TalentGroup]
					and profileDB.activeSelfBuffs[self.TalentGroup][buffLabel]
					and currentSuggestion.spellid == profileDB.activeSelfBuffs[self.TalentGroup][buffLabel] then
						
						currentSuggestion.LastCast = true
						
						MyDebugPrint("Last cast: "..GetSpellInfo(currentSuggestion.spellid))

						MyDebugPrint("Comparing Forms (%s vs %s)", tostring(GetShapeshiftForm()), tostring(self.Constants:LookupForm(currentSuggestion.spellid)))

						currentSuggestion.AwesomeActive = (
								(GetShapeshiftForm()
								and (GetShapeshiftForm() == self.Constants:LookupForm(currentSuggestion.spellid)))
							or (
								playerProfile.ActiveBuffs
								and playerProfile.ActiveBuffs[buffLabel]
								and currentSuggestion.spellid == playerProfile.ActiveBuffs[buffLabel].Spellid
								and not BuffBroker:HasExpired(playerProfile.ActiveBuffs[buffLabel], myGUID)))

					end -- if: we cast this before
				end -- for: each benefit, see if we applied it last time through this spell
				
			elseif currentSuggestion.Scope == self.Constants.Scope.Class
				or self.Constants:IsRaidWide(currentSuggestion.Scope) then
				
				-- confidence

				-- if: i can provide the best version
				if bestBuffs[buffLabel] and listContains(bestBuffs[buffLabel].Players, myGUID) then

					-- if: i did this last time
					if coverageBy == myGUID then

						-- I should totally do it this time
						currentSuggestion.Confidence = self.Constants.Confidence.Certain
					-- else: someone ELSE did it last time!
					elseif self.PlayerState:GetProfile(coverageBy) then
						
						-- if: best-version active
						if listContains(bestBuffs[buffLabel].Players, coverageBy) then
							-- let them keep doing it
							currentSuggestion.Confidence = self.Constants.Confidence.Unlikely

						else
							-- some shitty version active
							currentSuggestion.Confidence = self.Constants.Confidence.Possible
						end

					-- else:  SOMEONE who knows the slot should, but hasn't
					elseif self.Constants.BuffSlots[coverageBy] then
						currentSuggestion.Confidence = self.Constants.Confidence.Likely
					end
				else
					
					-- if: i did this last time
					if coverageBy == myGUID then
						-- might as well keep doing it
						currentSuggestion.Confidence = self.Constants.Confidence.Possible
					elseif self.Constants.BuffSlots[coverageBy] then
						-- SOMEONE will provide this buff
						currentSuggestion.Confidence = self.Constants.Confidence.Unlikely
					else
						-- no coverage
						currentSuggestion.Confidence = self.Constants.Confidence.Optional
					end
				end				

				-- LOTS here, necessary to calculate attendance and such;
				-- requires we iterate through the class/raid, comparing
				-- the benefits of this suggestion vs what each member has/wants
				wantsBuffCount = 0
				wantsBetterCount = 0
				hasBuffCount = 0
				hasBetterFromMeCount = 0
				inRangeCount = 0
				hasAwesomeGreaterBuff = nil

				-- determine the type of group
				if currentSuggestion.Scope == self.Constants.Scope.Class then
					currentGroupName = currentSuggestion.TargetProfile.Class
				elseif self.Constants:IsRaidWide(currentSuggestion.Scope) then
					currentGroupName = self.Constants.Classes.Raid
				end
				
				-- for: each player in the current group
				for currentGUID, currentProfile in self.PlayerState:ClassIterator(currentGroupName) do
					MyDebugPrint("checking %s, a member of %s", currentProfile.Name, currentGroupName)

					-- for: each benefit provided by this suggestion
					for _, buffLabel in ipairs(buffLabels) do
				
						-- NOTE: This could provide counts higher than the party count,
						-- if multiple benefits are provided (which is awesome and fine, but weird)
						-- aka; blessing of might could indicate 6 people who want the buff in a 5-player party
						-- (tank (AP), hybrid melee (AP & MP5), caster (MP5), caster (MP5), healer (MP5))
						buffLookup = bestBuffs[buffLabel]

						-- helper variables
						buffLabelPriority = BuffBroker:GetBuffDepth(currentProfile.Role, currentSuggestion.spellid)

						-- if: they want this buff, and can receive the buff (high enough level, not immune to spells)
						if self.Constants.BuffPriorities[currentProfile.Role]
						and self.Constants.BuffPriorities[currentProfile.Role][buffLabel]
						and not (currentProfile.Level < currentSlotEntry.MinLevel)
						and not currentProfile.Obscured then
							MyDebugPrint("Wants "..tostring(BuffLabel))

							wantsBuffCount = wantsBuffCount + 1
							wantsBuff = true

							-- if: they're in range
							if currentProfile.Near then
								inRangeCount = inRangeCount + 1
								
								-- if: they're visible
								if currentProfile.LOS then
									
									-- determine active buff's strength from player lookup
									activeBuffStrength = BuffBroker:GetBuffStrength(
										currentGUID,
										buffLabel,
										myGUID)
									
									-- use them as the ideal spell target
									-- note: this could be us, or it might not...
									-- if we have an awesome better buff from someone, we might not BE
									-- the best target.  Which is REALLY DUMB
									someTarget = currentGUID
									someTargetProfile = currentProfile
								end -- if: they're visible too
							end

						else
							wantsBuff = false
						end

						-- for: each buff they want
						for currentLabel, currentLabelPriority in pairs(self.Constants.BuffPriorities[currentProfile.Role]) do
							
							-- if: desire current label more than suggested label
							if currentLabelPriority > buffLabelPriority then
							
								-- if: is from me
								if currentProfile.ActiveBuffs[currentLabel] and currentProfile.ActiveBuffs[currentLabel].CasterGUID == myGUID then
									_, someSlotName, ActiveScope = self.Constants:SpellInfoFromID(currentProfile.ActiveBuffs[currentLabel].Spellid)
																		
									-- if: from the same slot as we're scoping out
									if someSlotName == currentSlotName
									or string.match(someSlotName, currentSlotName)
									or string.match(currentSlotName, someSlotName) then

										-- DEBUG
										if someSlotName ~= currentSlotName
										and (string.match(someSlotName, currentSlotName)
										or string.match(currentSlotName, someSlotName) ) then
											BuffBroker:SetFailCode("Buff Broker scoping "..currentSlotName..", found an active buff from "..someSlotName..";  false hit?  Please report this to the author, and help make this a more stable addon!")
										end

										-- if: scope of buff is group-wide
										if ActiveScope == self.Constants.Scope.Class
										or self.Constants:IsRaidWide(ActiveScope) then
											hasAwesomeGreaterBuff = true
										end
										
										if wantsBuff then

											-- if: expired
											if BuffBroker:HasExpired(currentProfile.ActiveBuffs[currentLabel], myGUID) then
												-- they want this better buff from me!
												wantsBetterCount = wantsBetterCount + 1
											
											-- else: not expired
											else
												-- has better active from me;  note count, and advance to next player
												hasBetterFromMeCount = hasBetterFromMeCount + 1
											end -- if: expired
											
											-- advance to next benefit
											break
										end
									end -- if: from the same slot as we're scoping out
								end -- if: from me
							elseif currentLabelPriority == buffLabelPriority then
								-- if: they have the buff we're scoping, from anyone
								if not BuffBroker:HasExpired(currentProfile.ActiveBuffs[currentLabel], myGUID) then

									_, ActiveSlot, ActiveScope = self.Constants:SpellInfoFromID(currentProfile.ActiveBuffs[currentLabel].Spellid)
									
									-- if: slots match
									if wantsBuff then

										-- is already active;  note count, and advance to next benefit
										hasBuffCount = hasBuffCount + 1
										break
									end -- if: slots match
								end -- if: they have the buff we're scoping, from anyone
							end -- matching how bad they want this benefit vs other benefits
						end -- for: each buff they want
					end -- for: each benefit provided by this suggestion
				end -- for: each player
				
				-- attendance
				currentSuggestion.Attendance = inRangeCount / wantsBuffCount

				-- unbuffedHeadCount
				currentSuggestion.UnBuffedHeadCount = inRangeCount - hasBuffCount

				if someTarget and someTargetProfile then
					-- target
					currentSuggestion.Target = someTarget

					-- targetProfile
					currentSuggestion.TargetProfile = someTargetProfile

					-- IsDominantRole
					currentSuggestion.IsDominantRole = self.PlayerState:GroupDominantRole(someTargetProfile.Class) == someTargetProfile.Role

				end

				-- Desirability
				currentSuggestion.Desirability = self:BuildDesirability(currentSuggestion)

				-- LastCast
				currentSuggestion.LastCast = profileDB.consistent
					and (currentSuggestion.spellid == self.PlayerState:GetLastCast(currentGroupName, currentSlotName))

				-- AwesomeActive
				currentSuggestion.AwesomeActive = nil
				
				-- for wotlk support, where single-cast blessings could conflict with raid-wide blessings
				if currentSlotEntry.Scope == self.Constants.Scope.Class then
					currentSuggestion.AwesomeActive = (hasBetterFromMeCount > 0) or hasAwesomeGreaterBuff
					print(GetSpellInfo(currentSlotID).." awesome active: better# "..tostring(hasBetterFromMeCount))
				end

				-- if: is a totem
				if currentSuggestion.TotemSpell then
					-- check if coincides with currently selected totem on action bar
					currentTotem = self.Constants:CurrentTotemSpell(currentSlotName)
				
					if currentTotem then

						-- get name of spellid (#'s could differ in older game client versions
						currentTotemName = GetSpellInfo(currentTotem)
						suggestedTotemName = GetSpellInfo(currentSuggestion.TotemSpell)

						-- if: totem is already on the action bar
						if currentTotemName == suggestedTotemName then
							currentSuggestion.AwesomeActive = true
						end -- if: totem is already on the action bar
					end
				end
			end
		end -- for: each suggestion
	end -- if: initialized
end

function BuffBroker:ResortSuggestions(suggestList)
	local myGUID = UnitGUID('player')
	local activeSuggestions = {}
	local buffLabels
	local activeSlotName
	local mockLabelArray = {}
	local theirSlotName, buffSlot
	local buffActive, formActive
	local currentGroupName
	local groupsToScan
	local classesToScan
	local raidToScan
	local coverageBy
	
	-- if: more than 1 suggestion
	if 1 < table.getn(suggestList) then
		MyDebugPrint("Sorting %d suggestions", table.getn(suggestList))

		-- TODO: build complex "priority" field, based on the EXACT
		-- sorting priority we're using in the OrderSuggestions function
		-- aka if the "priority" is a number, the most important criteria is the highest digit, etc
		
		-- sort suggestions
		table.sort(suggestList, OrderSuggestions)
	end -- if: more than 1 suggestion
	
	-- for: each suggestion
	for i, currentSuggestion in ipairs(suggestList) do
		-- record which I've already buffed, and note better suggestions as better
		buffLabels = self.Constants:SpellInfoFromID(currentSuggestion.spellid)
		activeSlotName = nil
		currentSuggestion.BetterActive = currentSuggestion.AwesomeActive
		
		-- if: old style single-type returned
		if type(buffLabels) == "string" then
			-- convert to new multi-benefit result
			mockLabelArray[1] = buffLabels
			buffLabels = mockLabelArray
		end -- if: old style single-type returned

		for _, buffLabel in ipairs(buffLabels) do
		
			-- for: each buffslot of the player
			for theirSlotName, buffSlot in pairs(self.PlayerState:GetAttribute(myGUID, 'BuffSlots')) do
				-- if: spell in the slot
				if buffSlot[currentSuggestion.spellid] then
					-- use it
					activeSlotName = theirSlotName
					break
				end
			end -- for: each buffslot of the player

			MyDebugPrint("cast %d on %s...", currentSuggestion.spellid, currentSuggestion.Target)
			
			 -- if: one or many target
			if currentSuggestion.Scope == self.Constants.Scope.Individual or currentSuggestion.Scope == self.Constants.Scope.Self then

				-- calculate if is still active
				buffActive = not BuffBroker:HasExpired(self.PlayerState:GetAttribute(currentSuggestion.Target, 'ActiveBuffs')[buffLabel], myGUID)
				formActive = GetShapeshiftForm() and GetShapeshiftForm() == self.Constants:LookupForm(currentSuggestion.spellid)

				-- if: I already cast this buff, and it's still active
				if formActive or (buffActive 
				and (self.PlayerState:GetAttribute(currentSuggestion.Target, 'ActiveBuffs')[buffLabel])
				and self.PlayerState:GetAttribute(currentSuggestion.Target, 'ActiveBuffs')[buffLabel].CasterGUID == myGUID) then
					MyDebugPrint("%d is already active from slot %s", currentSuggestion.spellid, activeSlotName)
					activeSuggestions[currentSuggestion.Target..activeSlotName..currentSuggestion.Scope] = currentSuggestion.spellid
					currentSuggestion.BetterActive = true
				else
					-- if: better version is active
					if activeSuggestions[currentSuggestion.Target..activeSlotName..currentSuggestion.Scope] then
						MyDebugPrint("better is already active from slot %s", activeSlotName)
						currentSuggestion.BetterActive = (currentSuggestion.spellid ~= activeSuggestions[currentSuggestion.Class..activeSlotName..currentSuggestion.Scope])
					else
						MyDebugPrint("nothing active from us from slot %s", activeSlotName)
						--currentSuggestion.BetterActive = false
					end -- if/else: better version is active
				end -- if/else: I already cast this buff, and it's still active

			elseif currentSuggestion.Scope == self.Constants.Scope.Class
			or self.Constants:IsRaidWide(currentSuggestion.Scope) then

				if currentSuggestion.Scope == self.Constants.Scope.Class then
					currentGroupName = currentSuggestion.TargetProfile.Class
				elseif self.Constants:IsRaidWide(currentSuggestion.Scope) then
					currentGroupName = self.Constants.Classes.Raid
				end
				
				if self.Constants.Scope.Class == currentSuggestion.Scope then

					if not classesToScan then
						classesToScan = {}
						for k, v in pairs(self.Constants.Classes) do
							classesToScan[k] = v
						end
						classesToScan.Raid = nil
					end
					
					groupsToScan = classesToScan
				elseif self.Constants:IsRaidWide(currentSuggestion.Scope) then
					if not raidToScan then
						raidToScan = {Raid = self.Constants.Classes.Raid}
					end
					
					groupsToScan = raidToScan
				end
				
				coverageBy = self.PlayerState:CheckCoverage(currentGroupName, buffLabel)
				-- if: i've called dibs on this slot already
				if coverageBy == myGUID then
					-- for raid-wide buffs:  NEVER claim active is best!  let the thresholds figure that out later :)
					activeSuggestions[currentSuggestion.Class..activeSlotName..currentSuggestion.Scope] = currentSuggestion.spellid
					--currentSuggestion.BetterActive = false
					MyDebugPrint("active spell is one I'm covering from our slot %s on %s", tostring(activeSlotName), tostring(currentGroupName))
				else
					-- if: better version is active
					if activeSuggestions[currentSuggestion.Class..activeSlotName..currentSuggestion.Scope] then
						MyDebugPrint("better is already active from our slot %s on %s", activeSlotName, currentGroupName)
						currentSuggestion.BetterActive = (currentSuggestion.spellid ~= activeSuggestions[currentSuggestion.Class..activeSlotName..currentSuggestion.Scope])
					else
						if currentSuggestion.BetterActive then
							activeSuggestions[currentSuggestion.Class..activeSlotName..currentSuggestion.Scope] = currentSuggestion.spellid
						end
					end -- if/else: better version is active
				end -- if/else: I already cast this buff, and it's still active
				-- end -- if: is a totem slot
				--end -- for: each group to scan
			end -- if: one or many target
		end -- for each: benefit provided by this suggestion
	end
end

function BuffBroker:SlotContainsLabel(theSlot, theLabel)
	local containsLabel = nil
	
	for spellID in pairs(theSlot) do
		if self.PlayerState:MatchByLabel(theLabel, self.Constants:SpellInfoFromID(spellID)) then
			containsLabel = true
			break
		end
	end
	
	return containsLabel
end

function BuffBroker:GetHighestSpellID(spellid)
	local name
	local highestSpellID = spellid
	local spellLink
	local markStart
	local markEnd
	local subLink
	local numberedLink
	
	name = GetSpellInfo(spellid)
	
	-- if: can get a name
	if name then
		-- get a weirdly formatted link to the spell
		spellLink = GetSpellLink(name)
		
		if spellLink then
			-- parse out the spellid text
			markStart, markEnd = string.find(spellLink, '\:[^\|]*')
			
			-- if: link contains a spellid (it should!)
			if markStart and markEnd then
				-- cut out the ID, as a #
				subLink = string.sub(spellLink, markStart + 1, markEnd)
				highestSpellID = tonumber(subLink)
			end -- if: link contains a spellid (it should!)
		end
	end -- if: can get a name
	
	return highestSpellID
end

-- TODO:  This severely breaks encapsulation on the PlayerState object;  need to make some "get active buff" functions
function BuffBroker:GetBuffStrength(targetGUID, buffLabel, myGUID)
	local activeBuffStrength
	local staleData
	local activeBuff

	-- if: buff is active on provided player data
	if self.PlayerState:GetAttribute(targetGUID, 'ActiveBuffs') and self.PlayerState:GetAttribute(targetGUID, 'ActiveBuffs')[buffLabel] then
		activeBuff = self.PlayerState:GetAttribute(targetGUID, 'ActiveBuffs')[buffLabel]
		
		-- if: buff strength is ambiguous
		if activeBuff and activeBuff.StrengthStale then
			activeBuffStrength, staleData = BuffBroker:GetPlayerBuffStrength(activeBuff.CasterGUID, buffLabel)
			
			if (not staleData) and (activeBuffStrength > self.Constants.Buffs.None) then
				activeBuff.Strength = activeBuffStrength
				activeBuff.StrengthStale = nil
			end
		else
			activeBuffStrength = activeBuff.Strength
		end -- if: buff strength is ambiguous

	else
		activeBuffStrength = self.Constants.Buffs.None
	end -- if: buff is active on provided player data

	return activeBuffStrength
end

function BuffBroker:GetPlayerBuffStrength(casterGUID, buffLabel)
	-- activeBuff: caster, spellid, expiration
	local buffStrength = self.Constants.Buffs.None
	local staleData
	local casterProfile

	if casterGUID then
		-- lookup Caster index
		casterProfile = self.PlayerState:GetProfile(casterGUID)
		
		-- if: have caster data
		if casterProfile then

			if casterProfile.CastableBuffs[buffLabel] then
				buffStrength = casterProfile.CastableBuffs[buffLabel]
				staleData = casterProfile.Stale
			end
		end -- if: have caster data
	end
	
	return buffStrength, staleData
end

function BuffBroker:ScanActiveAll()
	local targetGUID
	local aurasChanged
	
	-- for: each cached player
	for targetGUID, _ in self.PlayerState:Iterator() do

		if self:ScanActive(targetGUID) then
			aurasChanged = true
		end
	end -- for: each cached player
	
	return aurasChanged
end

function BuffBroker:ScanActive(GUIDToScan)
	local playerProfile
	local targetProfile
	local auraName = 'placeholder'
	local casterGUID
	local iBuff = 1
	local Nowish = GetTime()
	local buffLabels
	local buffLabel
	local buffSlot
	local expires, caster, spellid, duration
	local someLabel
	local activeChanged
	local anyChanged
	local scope
	local hasOldExpired
	local oldExpires
	local buffStillActive = {}
	local obscured = nil
	local buffSlotsByPlayer = {}
	local mockLabelArray = {}
	
	playerProfile = self.PlayerState:GetProfileByName('player')
	targetProfile = self.PlayerState:GetProfile(GUIDToScan)

	-- if: target profiled
	if targetProfile then
		-- scan potential raid-buffs

		-- while: haven't run out of auras
		while auraName and not (iBuff > self.Constants.MaxBuffSlots) do
			activeChanged = nil
			casterGUID = nil
			
			-- profile group buffs
			auraName, _, _, _, _, duration, expires, caster, _, _, spellid = UnitAura(targetProfile.Name, iBuff, 'HELPFUL')
			-- expires and duration will be 0, for buffs that never expire
			
			-- if: valid, cast by a player we're interested in
			if auraName then
				-- if: applied by a pet
				if caster and string.match(caster, 'pet', string.len(caster) - 2) then
					if caster == 'pet' then
						caster = 'player'
					else
						-- pretend the owner did it
						caster = string.sub(caster, 1, string.len(caster) - 3)
					end

				end -- if: applied by a pet
				
				-- if: cast by someone we're watching
				if self.PlayerState:GetProfileByName(caster) then
					casterGUID = UnitGUID(caster)
				end
				
				buffLabels, buffSlot, scope = self.Constants:SpellInfoFromID(spellid)
				
				-- if: is a buff we're monitoring
				if buffLabels then
				
					-- if: old style single-type returned
					if type(buffLabels) == "string" then
						-- convert to new multi-benefit result
						mockLabelArray[1] = buffLabels
						buffLabels = mockLabelArray
					end -- if: old style single-type returned
				
					for _, buffLabel in ipairs(buffLabels) do
						-- still active!
						buffStillActive[buffLabel] = true

						--print("bb debug... "..tostring(caster).."'s "..auraName.." duration: "..tostring(expires))

						-- if: tracking the caster's activity
						if casterGUID then
							-- create temp array as required
							if not buffSlotsByPlayer[casterGUID] then buffSlotsByPlayer[casterGUID] = {} end
							
							-- note that the caster/slot combo is active (we'll prune cached buffs later, if they are expired & from an active combo, aka mutually exclusive)
							buffSlotsByPlayer[casterGUID][buffSlot] = true
						end -- if: tracking the caster's activity

						MyDebugPrint("%s is label type %s", auraName, buffLabel)

						activeChanged = self.PlayerState:UpdateBuff(GUIDToScan, casterGUID, spellid, expires)
						
						--[[
						-- if: new cast, never been profiled
						if not targetProfile.ActiveBuffs[buffLabel] then
							targetProfile.ActiveBuffs[buffLabel] = {
								CasterGUID = casterGUID,
								Spellid = spellid,
								Expires = expires,
								Strength = self.PlayerState:GetPlayerBuffStrength(casterGUID, buffLabel),
								activeChanged = true,
							}

							if self.PlayerState:GetProfile(casterGUID) then
								targetProfile.ActiveBuffs[buffLabel].StrengthStale = self.PlayerState:GetAttribute(casterGUID, 'Stale')
							end

							activeChanged = true

						-- else: already cached, check for updates
						else
							-- record if old state is "expired", and insert new expiration (for comparator)
							hasOldExpired = BuffBroker:HasExpired(targetProfile.ActiveBuffs[buffLabel], self.PlayerState:MyGUID())
							oldExpires = targetProfile.ActiveBuffs[buffLabel].Expires
							targetProfile.ActiveBuffs[buffLabel].Expires = expires

							if casterGUID ~= targetProfile.ActiveBuffs[buffLabel].CasterGUID
							or spellid ~= targetProfile.ActiveBuffs[buffLabel].Spellid
							or hasOldExpired ~= BuffBroker:HasExpired(targetProfile.ActiveBuffs[buffLabel], self.PlayerState:MyGUID()) then
								-- genuine new state!  finish updating aura info
								targetProfile.ActiveBuffs[buffLabel].Spellid = spellid
								targetProfile.ActiveBuffs[buffLabel].CasterGUID = casterGUID

								activeChanged = true
							else
								-- revert aura info to prior state
								targetProfile.ActiveBuffs[buffLabel].Expires = oldExpires
							end
						end
						]]
						
						-- if: aura's we're interested in have changed
						if activeChanged then
							-- note the coverage
							if scope == self.Constants.Scope.Class then
								if self.PlayerState:SetCoverage(targetProfile.Class, buffLabel, casterGUID, buffSlot, spellid) then
									self:CoverageChanged()
								end
							elseif self.Constants:IsRaidWide(scope) then
							
								if self.PlayerState:SetCoverage(self.Constants.Classes.Raid, buffLabel, casterGUID, buffSlot, spellid) then
									self:CoverageChanged()
								end
							end
							
							if GUIDToScan == self.PlayerState:MyGUID() and scope == self.Constants.Scope.Self then
								profileDB.activeSelfBuffs[self.TalentGroup][buffLabel] = spellid
							end
						end

						-- check for form changes
						if self.Constants:LookupForm(spellid) and (GetShapeshiftForm() ~= self.Constants:LookupForm(spellid)) then
							MyDebugPrint("form change updated active self buff "..buffLabel)
							profileDB.activeSelfBuffs[self.TalentGroup][buffLabel] = spellid
						end

					end -- for: each benefit this buff provides
				end -- if: is a buff we're monitoring

				if spellid == 69378 then -- Forgotten Kings
					targetProfile.ActiveBuffs[L["STATS"]] = {CasterGUID = casterGUID, Spellid = spellid, Expires = expires}

					-- If caster's in the raid
					if self.PlayerState:GetProfile(casterGUID) then
					
						-- note that they can do this buff!
						self.PlayerState:AddBuffSlot(casterGUID, L["PROFESSION_STATS"], self.Constants.BuffSlots[L["PROFESSION_STATS"]])
					end -- If caster's in the raid
				end -- Forgotten Kings

				-- if: stance/form changing (ignore casters)
				if self.Constants.Forms[spellid]
				and self.PlayerState:GetAttribute(GUIDToScan, 'Role') ~= self.Constants.Roles.Caster 
				and self.PlayerState:GetAttribute(GUIDToScan, 'Role') ~= self.Constants.Roles.Healer then

					-- changed to/from tank spec
					if self.Constants.Forms[spellid] == self.Constants.Roles.Tank
					and self.PlayerState:GetAttribute(GUIDToScan, 'Role') ~= self.Constants.Roles.Tank then

						-- is becoming a tank (DK, Warrior, Bear, Tankadin)
						self.PlayerState:PromoteTankRole(GUIDToScan)
						activeChanged = true

					elseif self.Constants.Forms[spellid] == self.Constants.Roles.PureMelee 
					and self.PlayerState:GetAttribute(GUIDToScan, 'Role') == self.Constants.Roles.Tank then

						-- is becoming a PureMelee (DK, Warrior, Cat)
						self.PlayerState:DemoteTankRole(GUIDToScan)
						activeChanged = true
					end

				end -- if: stance/form changing (ignore casters)
				
				-- if: phase-shifted imp, etc
				if BuffBroker:IsObscured(spellid) then
					obscured = true
				end -- if: phase-shifted imp
			end -- if: valid, cast by a player we're interested in
		
			if activeChanged then
				anyChanged = true
			end
			
			iBuff = iBuff + 1
		end -- while: haven't run out of auras

		if iBuff > self.Constants.MaxBuffSlots then MyDebugPrint("searched past end of spell IDs;  maybe all buff slots are used?") end

		-- for: each active buff
		for someLabel, someActiveBuff in pairs(targetProfile.ActiveBuffs) do
			-- elseif: buff is no longer listed as an aura
			if not buffStillActive[someLabel] then
				-- mark as expired

				-- if: caster not in the party
				if nil == self.PlayerState:GetProfile(someActiveBuff.CasterGUID) then
					-- we can't count on them re-activating their buff
					targetProfile.ActiveBuffs[someLabel] = nil
				else
				
					-- caster is in the party
					
					_, buffSlot = self.Constants:SpellInfoFromID(someActiveBuff.Spellid)

					-- if: impossible for the buff to be re-applied
					if buffSlotsByPlayer[someActiveBuff.CasterGUID]
					and buffSlotsByPlayer[someActiveBuff.CasterGUID][buffSlot] then

						-- buff fell off from a mutually-exclusive buff getting cast
						targetProfile.ActiveBuffs[someLabel] = nil
					else
					
						-- buff fell off, but can/should be re-applied
						targetProfile.ActiveBuffs[someLabel].Expires = GetTime() - 1
						targetProfile.ActiveBuffs[someLabel].Strength = self.Constants.Buffs.None
					end
				end
				
				anyChanged = true

			end -- if/elsif: buffs are expired or orphaned
		end -- for: each active buff

		if self.PlayerState:GetAttribute(GUIDToScan, 'Obscured') ~= obscured then

			-- obscured state changed
			self.PlayerState:SetAttribute(GUIDToScan, 'Obscured', obscured)
			activeChanged = true
		end
	end -- if: target profiled

	return anyChanged
end

function BuffBroker:IsObscured(spellid)
	return (spellid == 4511) -- phase shifted imp
end

function BuffBroker:ScanAvailable()

	self:RefreshPlayers()
	self:ScanActiveAll()
end

function BuffBroker:RefreshPlayers()
	local rosterChanged = nil
	
	if not BuffList.InspectPending then
		BuffList.InspectComplete = nil
		BuffList.InspectGUID = nil
		
		rosterChanged = self.PlayerState:RefreshPlayers()
		
		-- if: players left/joined/respec'd
		if rosterChanged then
			-- remove auras the (now absent) dudes cast; account for new dudes
			if self:ScanActiveAll() then

				-- update suggestions
				self:RegenerateSuggestionDependencies()
				self:AssignNextSuggestion()
			end
		end
	end
end

function BuffBroker:PossibleSuggestionsChanged()
	-- player swapped spec, learned a new ability, etc
	self.SuggestionsStale = true
end

function BuffBroker:CoverageChanged()
	-- someone decided to change what group-wide buff they're applying
	self.CoverageStale = true
end

function BuffBroker:ProvidersChanged()
	-- what someone can provided just changed (party/raid join/leave, spec change)
	self.ProvidersStale = true
end

function BuffBroker:RolesChanged()
	-- party/raid composition changed, or someone swapped specs
	self.RolesStale = true
end

function BuffBroker:SetNextUpdate(time)
	self.NextUpdate = time
end

function BuffBroker:RegenerateSuggestionDependencies()

	MyDebugPrint("Regenerating Suggestion List & Dependencies")
	if self.PlayerState:GetCount() > 0 and self.PlayerState:MyGUID() then
		
		if self.ProvidersStale then
			BuffList.ProfiledBuffProviders = self:ProfileBest()
			self.ProvidersStale = nil
		end
		
		if self.RolesStale then
			self.PlayerState:UpdateRoleCount()
			self.RolesStale = nil
		end
		
		if self.CoverageStale then
			self.PlayerState:UpdateCoverage()
			self.CoverageStale = nil
		end
		
		self:UpdateRangeCheck()
		
		if not BuffList.Suggestions or self.SuggestionsStale then
			BuffList.Suggestions = self:BuildSuggestList()
			self.SuggestionsStale = nil
		end
		
		self:UpdateSuggestList(BuffList.Suggestions, BuffList.ProfiledBuffProviders)
		self:ResortSuggestions(BuffList.Suggestions)
		BuffList.LastSuggested = nil
	else
		MyDebugPrint("Regeneration skipped.  Count: %d, Me: %s", self.PlayerState:GetCount(), self.PlayerState:MyGUID())
		
	end
end

function BuffBroker:ProfileUnit(toProfile)
	
	return self.PlayerState:ProfileUnit(toProfile)

end

function BuffBroker:CopySlot(slotToCopy)
	local newBuffSlot = {}
	local tempSlotData
	
	for slotID, slotData in pairs(slotToCopy) do
		tempSlotData = {
			Score = slotData.Score,
			Target = slotData.Target,
			Scope = slotData.Scope,
		
		}
		
		newBuffSlot[slotID] = tempSlotData
	end
	
	return newBuffSlot
end

function BuffBroker:NextInspect()
	local staleGUID
	local firstGUID
	local startCount = 0
	local maxCount = self.PlayerState:GetPlayerCount()
	
	if not BuffList.InspectPending then
		firstGUID = self.PlayerState:NextStalePlayer()
		staleGUID = firstGUID
		
		-- while: we haven't run out of targets to inspect, and we can't un-stale the current target
		while (not (startCount > maxCount)) and staleGUID and (not self:ShouldInspect(staleGUID)) do
			staleGUID = self.PlayerState:NextStalePlayer()
			
			-- if: we've checked everyone
			if staleGUID == firstGUID then
				staleGUID = nil
				break
			end
			
			startCount = startCount + 1
		end
	end
	
	-- if: found someone we can (and should) inspect
	if nil ~= staleGUID and self:ShouldInspect(staleGUID) then
		MyDebugPrint("Next Inspect: decided to check stale player #%s", tostring(staleGUID))
		ClearInspectPlayer()
		BuffList.InspectPending = GetTime()
		BuffList.InspectGUID = staleGUID
		NotifyInspect(self.PlayerState:GetAttribute(staleGUID, 'Name'))
	else
		BuffList.InspectLastChecked = GetTime()
		BuffList.InspectComplete = true
		BuffList.InspectPending = nil
		BuffList.InspectGUID = nil
	end
end

--[[
function BuffBroker:NextInspect()
	local iNumChecks = 0
	local iInspectIndex
	local staleGUID, iterPlayer
	local nextPlayer, iterNext
	local iTooFar = 0
	
	if BuffList.InspectTarget and not BuffList.InspectPending then
		MyDebugPrint("Next Inspect: have inspectTarget & not pending")
		-- Prune not-stale entries
		iterPlayer, staleGUID = next(BuffList.StalePlayers, nil)
		
		-- while: not at end of stale list
		while iterPlayer and not (iTooFar > self.Constants.MaxPlayers) do
			iterNext, nextPlayer = next(BuffList.StalePlayers, iterPlayer)
			
			-- if: player not cached, already inspected, or a pet
			if nil == self.PlayerState:GetProfile(staleGUID)
			or nil == self.PlayerState:GetAttribute(staleGUID, 'Stale')
			or self.Constants.Types.Player ~= self.PlayerState:GetAttribute(staleGUID, 'Type')  then
				table.remove(BuffList.StalePlayers, iterPlayer)
				
				if iterPlayer < BuffList.InspectTarget then
					BuffList.InspectTarget = BuffList.InspectTarget - 1
				end
				
				if BuffList.InspectTarget < 1 or BuffList.InspectTarget > table.getn(BuffList.StalePlayers) then
					BuffList.InspectTarget = 1
				end
			end -- if: player not cached, or already inspected
			
			iterPlayer = iterNext
			staleGUID = nextPlayer
			iTooFar = iTooFar + 1
		end -- while: not at end of stale list

		MyDebugPrint("Next Inspect: decided to check stale player #%d", BuffList.InspectTarget)
		
		-- while: targets left to check, and next target hasn't been inspected
		while iNumChecks < table.getn(BuffList.StalePlayers) and not self:ShouldInspect(BuffList.StalePlayers[BuffList.InspectTarget]) do

			BuffList.InspectTarget = BuffList.InspectTarget - 1
					
			-- if: start of list
			if BuffList.InspectTarget == 0 then
				BuffList.InspectTarget = table.getn(BuffList.StalePlayers)
			end -- if: end of list
			
			iNumChecks = iNumChecks + 1
		end -- while: targets left to check, and next target hasn't been inspected
	end
	
	-- if - found someone to inspect
	if iNumChecks < table.getn(BuffList.StalePlayers) then
		-- Set inspect target
		inspectGUID = BuffList.StalePlayers[BuffList.InspectTarget]

		-- Request inspect data for this target
		if not UnitIsVisible(self.PlayerState:GetAttribute(inspectGUID, 'Name')) then
			--BuffBroker:SetFailCode("inspect hickup;  target isn't visible to game client")
		else
			MyDebugPrint("Next Inspect: inspecting "..self.PlayerState:GetAttribute(inspectGUID, 'Name'))
			ClearInspectPlayer()
			BuffList.InspectPending = GetTime()
			NotifyInspect(self.PlayerState:GetAttribute(inspectGUID, 'Name'))
			
		end
	else
		MyDebugPrint("Next Inspect: out of inspect targets, or something")
		-- done inspecting, or can't inspect further
		BuffList.InspectLastChecked = GetTime()
		BuffList.InspectComplete = true
		BuffList.InspectPending = nil
		BuffList.InspectTarget = nil

		self:FullProfile()
	end -- if - found someone to inspect
	
end
]]

function BuffBroker:FullProfile()
	local myGUID = UnitGUID('player')
	MyDebugPrint("Performing full profile (active, roles, bestbuffs, suggestions)")
	
	-- re-populates player's active buffs
	-- re-populates player's buffslots
	self:RefreshPlayers()

	if self:ScanActiveAll() then
		self:RegenerateSuggestionDependencies()
		
		-- update the buff button
		self:AssignNextSuggestion()
	end
end

function BuffBroker:AssignNextSuggestion()
	local suggestOffset
	local iterCurrent, iterStart, iterNext
	local currentSuggestion, nextSuggestion
	local targetProfile
	local spellName
	local currentTotem
	local spellSlot
	local currentCastSpellName
	local lastCastSpellName
	local myProfile = self.PlayerState:GetProfile(self.PlayerState:MyGUID())
	
	if 0 < table.getn(BuffList.Suggestions) then
		iterStart = 1	
		
		--[[if BuffList.LastSuggested then
			iterStart = BuffList.LastSuggested
		else
			iterStart = 1
		end]]

		MyDebugPrint("Filtering for next suggestion...")

		for iterCurrent = iterStart, table.getn(BuffList.Suggestions) do
			currentSuggestion = BuffList.Suggestions[iterCurrent]
			spellName = GetSpellInfo(currentSuggestion.spellid)
			_, spellSlot, _ = self.Constants:SpellInfoFromID(currentSuggestion.spellid)
			
			-- if: high-confidence buff, which we're allowed to cast, on a valid target
			if currentSuggestion.Confidence >= self.Constants.Confidence.Unlikely
			and profileDB.slots[self.TalentGroup][spellSlot] == true then
				
				-- if: raid or class buff
				if currentSuggestion.Scope == self.Constants.Scope.Class
				or self.Constants:IsRaidWide(currentSuggestion.Scope) then

					-- if: raid-wide buff passes thresholds (known, sufficient attendance/headcount, none better active from us)
					if (IsSpellKnown(currentSuggestion.spellid) or currentSuggestion.TotemSlot or IsHelpfulSpell(spellName))
					and not (currentSuggestion.Attendance < (profileDB.raidBuffAttendThreshold / 100))
					and not (currentSuggestion.UnBuffedHeadCount < profileDB.raidBuffHeadCountThreshold)
					and not (profileDB.frugal and ( currentSuggestion.UnBuffedHeadCount == 1))
					and (currentSuggestion.UnBuffedHeadCount > 0)
					and not currentSuggestion.BetterActive
					and ((not IsMounted()) == (not currentSuggestion.Mounted)) then

						-- use this suggestion next
						iterNext = iterCurrent
						break
					end -- if: raid-wide buff passes thresholds
				-- elseif: self of single buff
				elseif currentSuggestion.Scope == self.Constants.Scope.Individual
				or currentSuggestion.Scope == self.Constants.Scope.Self then
				
					-- if: can cast, target exists, is in range, is targetable, is inspected, and better is not active
					if IsSpellKnown(currentSuggestion.spellid)
					and currentSuggestion.TargetProfile
					and currentSuggestion.TargetProfile.Near
					and not currentSuggestion.TargetProfile.Obscured
					and ((not currentSuggestion.TargetProfile.Stale) or BuffList.InspectFucked)
					and not currentSuggestion.BetterActive
					and ((not IsMounted()) == (not currentSuggestion.Mounted)) then
						
						MyDebugPrint("we should cast "..GetSpellInfo(currentSuggestion.spellid).." next")
						iterNext = iterCurrent
						break
					else
						MyDebugPrint("skipping/ignoring "..GetSpellInfo(currentSuggestion.spellid))
					end
				
				end -- if/elseif: match scope
			end -- if: high-confidence buff, which we're allowed to cast, on a valid target
		end
		
		suggestOffset = iterNext
	end
	
	if suggestOffset then

		-- if - TargetProfile is not in LOS
		if not BuffList.Suggestions[suggestOffset].TargetProfile.LOS then
			
			-- for: each player
			for _, someProfile in self.PlayerState:Iterator() do
				-- reset LOS info
				someProfile.LOS = true
			end -- for: each player
		end -- if - TargetProfile is not in LOS
	
		MyDebugPrint("Assigning next clickable suggestion on: %s", self.PlayerState:GetAttribute(BuffList.Suggestions[suggestOffset].Target, 'Name'))
		
		self:AssignButtonBuff(BuffList.Suggestions[suggestOffset])
		BuffList.LastSuggested = suggestOffset
	else
		MyDebugPrint("No valid suggestions (out of %d).  Resetting button to Dizzy.", table.getn(BuffList.Suggestions))

		BuffList.TooltipPrime = L["Idle"]
		BuffList.TooltipDetail = L["Nothing to suggest"]
		--BuffList.TooltipFormatter = L["%d/%d players profiled"]
		--BuffList.TooltipMinor = BuffList.TooltipFormatter:format('??', self.PlayerState:GetPlayerCount())
		BuffList.TooltipMinor = ""
		
		BuffBroker:ClearButtonBuff()
	end
end

function BuffBroker:ClearButtonBuff()

	-- if: not locked down (THN:  Remove restriction once secure template stuff is understood/working
	if not InCombatLockdown() then
		self.Idle = true
		if profileDB.hiddenWhileIdle and self.BuffButton:IsVisible() then
			self.BuffButton:Hide()
			self.MoveFrame:Hide()
		end
		
		
		self.BuffTexture:SetTexture('Interface\\Icons\\Spell_Holy_Dizzy.blp')
		self.BuffButton:SetAttribute('type', 'spell')
		self.BuffButton:SetAttribute('unit', '')
		self.BuffButton:SetAttribute('spell', '')
		BuffList.LastSuggested = nil

		BuffBroker:ShowTip()
	end -- if: not locked down
end

function BuffBroker:AssignButtonBuff(suggestedBuff)
	local spellName
	local spellTexture
	local targetName
	local bestSpellid = suggestedBuff.spellid
	local tooCheapForBestVersion
	local localizedClass
	local highestSpellID
	
	-- if: not locked down (THN:  Remove restriction once secure template stuff is understood/working
	if not InCombatLockdown() and
	not (self.InSanctuary and profileDB.hiddenInSanctuary) then

		--MyDebugPrint("assigning %d", suggestedBuff.spellid)
		if suggestedBuff and BuffBroker:ShouldProfile() then

			self.Idle = false
			-- if: no longer idle, but still hidden
			if profileDB.hiddenWhileIdle and not self.BuffButton:IsVisible() then
				self.BuffButton:Show()
				if not profileDB.lock then
					self.MoveFrame:Show()
				end
			end

			if suggestedBuff.TargetProfile and suggestedBuff.TargetProfile.Near then
				targetName = self.PlayerState:GetAttribute(suggestedBuff.Target, 'Name')
				spellName, _, spellTexture = GetSpellInfo(bestSpellid)
				localizedClass = UnitClass(suggestedBuff.TargetProfile.Name)
				
				if suggestedBuff.TotemSlot and suggestedBuff.TotemSpell then
					highestSpellID = BuffBroker:GetHighestSpellID(suggestedBuff.TotemSpell)
					
					-- assign totem to desired slot
					self.BuffTexture:SetTexture(spellTexture)
					self.BuffButton:SetAttribute('type', 'multispell')
					self.BuffButton:SetAttribute('unit', targetName)
					self.BuffButton:SetAttribute('spell', highestSpellID)
					self.BuffButton:SetAttribute('action', suggestedBuff.TotemSlot)

					BuffList.TooltipPrime = spellName
					BuffList.TooltipDetail = L["Add to Call of Elements totem bar"]
					BuffList.TooltipMinor = L["Best totem for this group"]

				else
					self.BuffTexture:SetTexture(spellTexture)
					self.BuffButton:SetAttribute('type', 'spell')
					self.BuffButton:SetAttribute('unit', targetName)
					self.BuffButton:SetAttribute('spell', spellName)
				
					BuffList.TooltipPrime = spellName
					BuffList.TooltipFormatter = L["Cast on %s the %s"]
					BuffList.TooltipDetail = BuffList.TooltipFormatter:format(suggestedBuff.TargetProfile.Name, L[suggestedBuff.TargetProfile.Role])

					if suggestedBuff.Scope == self.Constants.Scope.Class then
						BuffList.TooltipFormatter = L["%d%% of %s nearby"]
						BuffList.TooltipMinor = BuffList.TooltipFormatter:format(suggestedBuff.Attendance * 100, localizedClass)
					elseif self.Constants:IsRaidWide(suggestedBuff.Scope) then
						
						BuffList.TooltipFormatter = L["%d%% of targets nearby"]
						BuffList.TooltipMinor = BuffList.TooltipFormatter:format(suggestedBuff.Attendance * 100)
					elseif suggestedBuff.Scope == self.Constants.Scope.Self then
						BuffList.TooltipMinor = L["Refresh this last-used self buff"]
					else
						BuffList.TooltipMinor = ''
					end
				end
				
				BuffBroker:ShowTip()
			end
		end
	end -- if: not locked down
end

function BuffBroker:TestSuggestions()
	local testName, testArray, i, iCurrentSuggestion
	local MatchingResults
	local searchDepth
	local expectedSuggestion, expectedFound
	local failedConfigurations
	local profiledBestBuffs
	local testSuggestList
	local testClasses = {}
	local testCoverage
	
	-- for: each test group
	for testName,testArray in pairs(self.TestCases.Groups) do
		failedConfigurations = 0
		
		-- for: each party configuration
		for i = 1,table.getn(testArray) do
			MatchingResults = true
			
			-- update role count
			testClasses = self.PlayerState:UpdateRoleCount()
			
			-- update near/far count
			self:UpdateRangeCheck(true)
			
			-- update coverage
			self.PlayerState:UpdateCoverage()
			
			-- clear old buffs
			for _, currentPlayer in pairs(testArray[i].Players) do
				currentPlayer.ActiveBuffs = {}
			end
			
			-- update existing buffs
			if testArray[i].ActiveBuffs then
				for _, currentBuff in pairs(testArray[i].ActiveBuffs) do
					testArray[i].Players[currentBuff.Target].ActiveBuffs[currentBuff.Type] = {
						CasterGUID = currentBuff.Source,
						Spellid = currentBuff.spellid,
						Expires = GetTime() + profileDB.refreshAtDuration + 60,
						Strength = testArray[i].Players[currentBuff.Source].CastableBuffs[currentBuff.Type],
						LOS = true,
					}
						
					if currentBuff.Expired then
						testArray[i].Players[currentBuff.Target].ActiveBuffs[currentBuff.Type].Expires = GetTime() - 1
					end
				end
			end
			
			-- Process data from testArray
			profiledBestBuffs = self:ProfileBest(testArray[i].Players) -- run the profile
			-- IDEAL:  test configuration should swap out BuffList with entire replica!
			testSuggestList = self:BuildSuggestList(testArray[i].Players, testClasses, testCoverage, profiledBestBuffs, testArray[i].PlayerGUID) -- generate suggestions

			-- make sure the sample matches are in the top of the generated list
			searchDepth = table.getn(testArray[i].Suggestions)
			if table.getn(testSuggestList) and table.getn(testSuggestList) < searchDepth then
				searchDepth = table.getn(testSuggestList)
			end
			
			if table.getn(testArray[i].Suggestions) ~= table.getn(testSuggestList) then
				print("Test "..testName.." on "..testArray[i].Test..": Expected "..table.getn(testArray[i].Suggestions)..", got "..table.getn(testSuggestList).." :[")
			end

			-- for: each expected suggestion from testArray
			for iCurrentSuggestion=1, searchDepth do
				
				expectedFound = self:CompareSuggestions(testArray[i].Suggestions[iCurrentSuggestion], testSuggestList[iCurrentSuggestion])

				if not expectedFound then
					print("Suggestion #"..iCurrentSuggestion..", expected <"..testArray[i].Suggestions[iCurrentSuggestion].spellid.." on "..testArray[i].Suggestions[iCurrentSuggestion].Target.." @ "..testArray[i].Suggestions[iCurrentSuggestion].Confidence..">")
					print("Suggestion #"..iCurrentSuggestion..", instead found  <"..testSuggestList[iCurrentSuggestion].spellid.." on "..testSuggestList[iCurrentSuggestion].Target.." @ "..testSuggestList[iCurrentSuggestion].Confidence..">")
					MatchingResults = false
					break
				end
			end -- for: each expected suggestion from testArray

			if not MatchingResults then
				print("Test: "..testName.." on "..testArray[i].Test.." failed")
				failedConfigurations = failedConfigurations + 1

				print("-----Suggestions for failed test-----")
				for iCurrentSuggestion=1, searchDepth do
					os = "Cast ["..GetSpellInfo(testSuggestList[iCurrentSuggestion].spellid).." on <"..testSuggestList[iCurrentSuggestion].Target..">, C: "..testSuggestList[iCurrentSuggestion].Confidence
					os = os.." -actual, vs, expected- Cast ["..GetSpellInfo(testArray[i].Suggestions[iCurrentSuggestion].spellid).." on <"..testArray[i].Suggestions[iCurrentSuggestion].Target..">, Confidence: "..testArray[i].Suggestions[iCurrentSuggestion].Confidence
					print(os)
					
					if testSuggestList[iCurrentSuggestion].BetterActive then print ("oh shit, but better is active (actual)!") end
					
					if testSuggestList[iCurrentSuggestion].Attendance then
						--print("actual attend (%, #): "..testSuggestList[iCurrentSuggestion].Attendance..", "..testSuggestList[iCurrentSuggestion].UnBuffedHeadCount)
					end
					if testArray[i].Suggestions[iCurrentSuggestion].Attendance then
						--print("expected attend: "..testArray[i].Suggestions[iCurrentSuggestion].Attendance)
					end
				end
				MyDebugPrint("-----")
			end
			
		end -- for: each party configuration

		if failedConfigurations == 0 then
			print("Test cleared: "..testName)
		end
	end
end

function BuffBroker:CompareSuggestions(left, right)
	local Match
	if left and right then
		Match = (left.Confidence == right.Confidence)
			and (left.Target == right.Target)
			and (left.spellid == right.spellid)
	end
	
	return Match
end

function BuffBroker:TestBestBuffs()
	local testName, testArray, i
	local MatchingResults
	local failedConfigurations
	local profiledBestBuffs
	
	-- for: each test group
	for testName,testArray in pairs(self.TestCases.Groups) do

		failedConfigurations = 0

		-- for: each party configuration
		for i = 1,table.getn(testArray) do
			MatchingResults = true
			
			profiledBestBuffs = self:ProfileBest(testArray[i].Players) -- run the profile

			-- Compare results:
			
			for labelName, _ in pairs(self.Constants.DownRankLookup) do
				if testArray[i].Results[labelName] and not self:CompareBuffList(profiledBestBuffs[labelName], testArray[i].Results[labelName]) then
					MatchingResults = false
					print("---Test "..testName.." on "..testArray[i].Test..": Mis-match in "..labelName.." results")
				end
			end
			
			if not MatchingResults then
				print("Test: "..testName.." on "..testArray[i].Test.." failed")
				failedConfigurations = failedConfigurations + 1
			end
		end -- for: each party configuration
		if failedConfigurations == 0 then
			print("Test cleared: "..testName)
		end
	end
end

function BuffBroker:CompareBuffList(FirstList, OtherList)
	local Match
	
	Match = FirstList.Strength == OtherList.Strength
		and FirstList.TotalCount == OtherList.TotalCount
		and table.getn(FirstList.Players) == table.getn(OtherList.Players)
	
	if Match then
		for i=1,table.getn(FirstList.Players) do
			Match = Match and (FirstList.Players[i] == OtherList.Players[i])
		end
	else
		MyDebugPrint("Couldn't match Strength (%d vs %d), total (%d vs %d), or player list size", FirstList.Strength, OtherList.Strength, FirstList.TotalCount, OtherList.TotalCount)
	end
	
	
	return Match
end

function BuffBroker:ProfileBest()
	--local bestStats, bestAP, bestHP, bestTank, bestMP5 = {}, {}, {}, {}, {}
	local bestBuffsByType = {}
	
	for labelName, _ in pairs(self.Constants.DownRankLookup) do
		bestBuffsByType[labelName] = {Strength = self.Constants.Buffs.None, TotalCount = 0, Players = {} }
	end
	
	-- for: each Player
	for currentGUID, currentProfile in self.PlayerState:Iterator() do

		-- update best buffs with this player's info
		
		for labelName, _ in pairs(self.Constants.DownRankLookup) do
			bestBuffsByType[labelName] = self:CompareBuffability(currentGUID, currentProfile.CastableBuffs[labelName], bestBuffsByType[labelName])
		end
		
		-- TODO:
		-- for: each BUFFSLOT!  Paladin with king drums should result in TotalCount += 2
	end
		
	return bestBuffsByType
end

function BuffBroker:CompareBuffability(PlayerGUID, PlayerStrength, CurrentBestBuff)
	if PlayerStrength and (PlayerStrength > self.Constants.Buffs.None) then
		-- Player can do some (potentially shitty) version of this buff
		CurrentBestBuff.TotalCount = CurrentBestBuff.TotalCount + 1
		-- if: player's buff is same as best seen
		if PlayerStrength == CurrentBestBuff.Strength then
			-- add player to eligibility list
			table.insert(CurrentBestBuff.Players, PlayerGUID)
		elseif PlayerStrength > CurrentBestBuff.Strength then
			-- add player as only member of new better eligibility list
			CurrentBestBuff.Strength = PlayerStrength
			CurrentBestBuff.Players = {PlayerGUID}
		end
	end
	
	return CurrentBestBuff
end

function BuffBroker:ShouldInspect(targetGUID)
	local inspect = false
	local targetProfile = self.PlayerState:GetProfile(targetGUID)
	
	if targetProfile then
		-- should inspect if: not yet inspected, and able to inspect (range, non-NPC, non-flagged pvp hostile)
		inspect = targetProfile.Stale and targetProfile.Name ~= L["Unknown"] and CanInspect(targetProfile.Name) and UnitIsVisible(targetProfile.Name) and targetProfile.Near and (not self.InCombat)
	end
	
	return inspect
end

function BuffBroker:CheckRoles()
	local targetName
	local targetProfile
	local changed
	
	for targetName, targetProfile in self.PlayerState:Iterator() do
		if targetProfile.Level < profileDB.healerLevel then
			if targetProfile.Role == self.Constants.Roles.Caster then
				-- was a caster, but too low level to be a caster
				targetProfile.Role = self.Constants.Roles.Healer
				changed = true
			end
		else
			-- 
			if targetProfile.Role == self.Constants.Roles.Healer then
				-- was a healer; high enough level to be a caster though
				targetProfile.Role = self.Constants.Roles.Caster
				changed = true
			end
		end
	end
	
	if changed then
		self.PlayerState:UpdateRoleCount()
	end
end

function BuffBroker:InspectAvailable()
	local talentName, rank, maxrank
	local maxTree
	local inspectGUID = BuffList.InspectGUID
	local inspectProfile = self.PlayerState:GetProfile(inspectGUID)
	local initialRole
	
	BuffList.InspectOutstanding = nil
	
	if inspectProfile and (not BuffList.InspectBusy) and BuffList.InspectPending then
		initialRole = inspectProfile.Role
		MyDebugPrint("Inspect Available for %s", tostring(inspectGUID))
		
		-- check roles and improved buffs
		if inspectProfile.Class == self.Constants.Classes.Paladin then

			-- determine role, based on deepest talent tree investment
			inspectProfile.Role = BuffBroker:RoleFromTalents(
				self.Constants.Roles.Caster,
				self.Constants.Roles.Tank,
				self.Constants.Roles.MeleeMana_Low,
				self.Constants.Roles.MeleeMana_Low)

			-- if - low level caster
			if inspectProfile.Level < profileDB.healerLevel and inspectProfile.Role == self.Constants.Roles.Caster then
				-- will prefer mana
				inspectProfile.Role = self.Constants.Roles.Healer
			end -- if: low level caster

			-- can generate own mana as retribution? (judgements of the wise)
			talentName, _, _, _, rank, maxrank = GetTalentInfo(3, 18, true, false, self.Constants:GetActiveSpec()) -- Improved Blessing of Might
			if rank == maxrank then
				inspectProfile.Role = self.Constants.Roles.MeleeMana
			end

			
			-- can generate own mana as protection? (divine plea)
			talentName, _, _, _, rank, maxrank = GetTalentInfo(2, 23, true, false, self.Constants:GetActiveSpec()) -- Improved Blessing of Might
			if rank == maxrank and inspectProfile.Level > 70 then
				inspectProfile.Role = self.Constants.Roles.MeleeMana
			end

			inspectProfile.OldRole = inspectProfile.Role

			-- can buff AP?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(3, 5, true, false, self.Constants:GetActiveSpec()) -- Improved Blessing of Might
			if rank == maxrank then
				inspectProfile.CastableBuffs["AP"] = self.Constants.Buffs.FullTalentedLong
			elseif rank > 0 then
				inspectProfile.CastableBuffs["AP"] = self.Constants.Buffs.PartialTalentedLong
			end

			-- can buff Sanctuary for Tank role?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(2, 12, true, false, self.Constants:GetActiveSpec()) -- Blessing of Sanctuary
			if rank == maxrank then
				inspectProfile.CastableBuffs["TANK"] = self.Constants.Buffs.FullTalentedLong

				inspectProfile.BuffSlots["BLESSINGS"] = self.Constants.BuffSlots["BLESSINGS"]
			end

			-- can buff Mana?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(1, 10, true, false, self.Constants:GetActiveSpec()) -- Improved Blessing of Wisdom
			if rank == maxrank then
				inspectProfile.CastableBuffs["MP5"] = self.Constants.Buffs.FullTalentedLong
			elseif rank > 0 then
				inspectProfile.CastableBuffs["MP5"] = self.Constants.Buffs.PartialTalentedLong
			end

		elseif inspectProfile.Class == self.Constants.Classes.Shaman then
			-- determine role, based on deepest talent tree investment
			inspectProfile.Role = BuffBroker:RoleFromTalents(
				self.Constants.Roles.Healer,
				self.Constants.Roles.MeleeMana_Low,
				self.Constants.Roles.Healer,
				self.Constants.Roles.MeleeMana_Low)

			-- can regenerate own mana as enhancement?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(2, 24, true, false, self.Constants:GetActiveSpec()) -- Restorative Totems
			if rank == maxrank then
				inspectProfile.Role = self.Constants.Roles.MeleeMana
			end

			-- doesn't care about regeneration as enhancement?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(2, 26, true, false, self.Constants:GetActiveSpec()) -- Restorative Totems
			if rank == maxrank then
				inspectProfile.Role = self.Constants.Roles.MeleeMana
			end

			-- can regenerate own mana as elemental?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(1, 25, true, false, self.Constants:GetActiveSpec()) -- Restorative Totems
			if rank == maxrank then
				inspectProfile.Role = self.Constants.Roles.Caster
			end
			
			-- can buff Mana?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(3, 10, true, false, self.Constants:GetActiveSpec()) -- Restorative Totems
			if rank == maxrank then
				inspectProfile.CastableBuffs["MP5"] = self.Constants.Buffs.FullTalented
			elseif rank < (1.0 * maxrank / 2) then
				inspectProfile.CastableBuffs["MP5"] = self.Constants.Buffs.MinorTalented
			elseif rank > (1.0 * maxrank / 2) then
				inspectProfile.CastableBuffs["MP5"] = self.Constants.Buffs.MajorTalented
			end

			-- knows totem of wrath?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(1, 22, true, false, self.Constants:GetActiveSpec()) -- Blessing of Sanctuary
			if rank == maxrank then
				inspectProfile.CastableBuffs["FLAT_SPELL_CRIT"] = self.Constants.Buffs.Basic

				inspectProfile.BuffSlots["FIRE_TOTEMS"] = self.Constants.BuffSlots["FIRE_TOTEMS"]
			end

			-- knows improved strength of earth?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(2, 1, true, false, self.Constants:GetActiveSpec()) -- Blessing of Sanctuary
			if rank == maxrank then
				inspectProfile.CastableBuffs["STRENGTH_AGILITY"] = self.Constants.Buffs.FullTalented
			elseif rank < (1.0 * maxrank / 2) then
				inspectProfile.CastableBuffs["STRENGTH_AGILITY"] = self.Constants.Buffs.MinorTalented
			elseif rank > (1.0 * maxrank / 2) then
				inspectProfile.CastableBuffs["STRENGTH_AGILITY"] = self.Constants.Buffs.MajorTalented
			end

			-- knows improved stoneskin?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(2, 4, true, false, self.Constants:GetActiveSpec()) -- Blessing of Sanctuary
			if rank == maxrank then
				inspectProfile.CastableBuffs["ARMOR"] = self.Constants.Buffs.FullTalented
			elseif rank == (1.0 * maxrank / 2) then
				inspectProfile.CastableBuffs["ARMOR"] = self.Constants.Buffs.PartialTalented
			end

			-- knows improved windfury?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(2, 4, true, false, self.Constants:GetActiveSpec()) -- Blessing of Sanctuary
			if rank == maxrank then
				inspectProfile.CastableBuffs["MELEE_HASTE"] = self.Constants.Buffs.FullTalented
			elseif rank == (1.0 * maxrank / 2) then
				inspectProfile.CastableBuffs["MELEE_HASTE"] = self.Constants.Buffs.PartialTalented
			end

		elseif inspectProfile.Class == self.Constants.Classes.Deathknight then
			inspectProfile.OldRole = self.Constants.Roles.PureMelee

			-- knows icy talons?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(2, 16, true, false, self.Constants:GetActiveSpec()) -- Blessing of Sanctuary
			if rank == maxrank then
				inspectProfile.CastableBuffs["MELEE_HASTE"] = self.Constants.Buffs.FullTalented
				
				inspectProfile.BuffSlots["ICY_TALONS"] = self.Constants.BuffSlots["ICY_TALONS"]
			end

		elseif inspectProfile.Class == self.Constants.Classes.Warrior then
			inspectProfile.Role = BuffBroker:RoleFromTalents(
				self.Constants.Roles.PureMelee,
				self.Constants.Roles.PureMelee,
				self.Constants.Roles.Tank,
				self.Constants.Roles.PureMelee)
				
			inspectProfile.OldRole = self.Constants.Roles.PureMelee

			talentName, _, _, _, rank, maxrank = GetTalentInfo(2, 9, true, false, self.Constants:GetActiveSpec()) -- Improved Shouts
			if rank == maxrank then
				inspectProfile.CastableBuffs["AP"] = self.Constants.Buffs.FullTalented
				inspectProfile.CastableBuffs["HP"] = self.Constants.Buffs.FullTalented
			elseif rank < (1.0 * maxrank / 2) then
				inspectProfile.CastableBuffs["AP"] = self.Constants.Buffs.MinorTalented
				inspectProfile.CastableBuffs["HP"] = self.Constants.Buffs.MinorTalented
			elseif rank > (1.0 * maxrank / 2) then
				inspectProfile.CastableBuffs["AP"] = self.Constants.Buffs.MajorTalented
				inspectProfile.CastableBuffs["HP"] = self.Constants.Buffs.MajorTalented
			end

		elseif inspectProfile.Class == self.Constants.Classes.Druid then
			-- determine role, based on deepest talent tree investment
			inspectProfile.Role = BuffBroker:RoleFromTalents(
				self.Constants.Roles.Caster,
				self.Constants.Roles.PureMelee,
				self.Constants.Roles.Caster,
				self.Constants.Roles.PureMelee)

			inspectProfile.OldRole = inspectProfile.Role

			-- if: low level caster
			if inspectProfile.Level < profileDB.healerLevel and inspectProfile.Role == self.Constants.Roles.Caster then
				-- will prefer mana
				inspectProfile.Role = self.Constants.Roles.Healer
			end -- if: low level caster

			-- can buff MotW?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(3, 1, true, false, self.Constants:GetActiveSpec()) -- Improved Mark/Gift of the Wild
			if rank == maxrank then
				inspectProfile.CastableBuffs["WILD"] = self.Constants.Buffs.FullTalented
			elseif rank > 0 then
				inspectProfile.CastableBuffs["WILD"] = self.Constants.Buffs.PartialTalented
			end

		elseif inspectProfile.Class == self.Constants.Classes.Priest then
			if inspectProfile.Level < profileDB.healerLevel then
				inspectProfile.Role = self.Constants.Roles.Healer
			else
				inspectProfile.Role = self.Constants.Roles.Caster
			end
			
			-- can buff Fortitude?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(1, 5, true, false, self.Constants:GetActiveSpec()) -- Improved Fortitude
			if rank == maxrank then
				inspectProfile.CastableBuffs["STAMINA"] = self.Constants.Buffs.FullTalented
			elseif rank > 0 then
				inspectProfile.CastableBuffs["STAMINA"] = self.Constants.Buffs.PartialTalented
			end

			-- knows vampiric embrace?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(3, 14, true, false, self.Constants:GetActiveSpec()) -- vampiric embrace
			if rank == maxrank then
				inspectProfile.CastableBuffs["EMBRACE"] = self.Constants.Buffs.Basic

				inspectProfile.BuffSlots["EMBRACE"] = self.Constants.BuffSlots["EMBRACE"]
			end
			
		end

		ClearInspectPlayer()
		inspectProfile.Stale = false
		BuffList.InspectPending = nil
		BuffList.InspectGUID = nil

		if self:ScanActive(inspectGUID) or initialRole ~= inspectProfile.Role or inspectGUID == self.PlayerState:MyGUID() then
			self:CoverageChanged()
			self:ProvidersChanged()
			self:RolesChanged()
			self:PossibleSuggestionsChanged()
			
			BuffList.AurasFirstChangedAt = GetTime()
			BuffList.AurasLastChangedAt = GetTime()
		end
	end
end

function BuffBroker:CataclysmInspectAvailable(inspectGUID)
	local talentName, rank, maxrank
	local maxTree
	local inspectProfile = self.PlayerState:GetProfile(inspectGUID)
	local initialRole
	
	BuffList.InspectOutstanding = nil

	if inspectProfile then
		initialRole = inspectProfile.Role
		MyDebugPrint("Inspect Available for %s", tostring(inspectGUID))
		
		-- check roles and improved buffs
		if inspectProfile.Class == self.Constants.Classes.Paladin then

			-- determine role, based on deepest talent tree investment
			inspectProfile.Role = BuffBroker:RoleFromTalents(
				self.Constants.Roles.Healer,
				self.Constants.Roles.Tank,
				self.Constants.Roles.MeleeMana,
				self.Constants.Roles.MeleeMana)

			inspectProfile.OldRole = inspectProfile.Role

		elseif inspectProfile.Class == self.Constants.Classes.Shaman then
			-- determine role, based on deepest talent tree investment
			inspectProfile.Role = BuffBroker:RoleFromTalents(
				self.Constants.Roles.Caster,
				self.Constants.Roles.MeleeMana,
				self.Constants.Roles.Healer,
				self.Constants.Roles.MeleeMana)

			-- Elemental Oath
			talentName, _, _, _, rank, maxrank = GetTalentInfo(1, 11, true, false, self.Constants:GetActiveSpec())
			if rank == maxrank then
				inspectProfile.CastableBuffs["FLAT_CRIT"] = self.Constants.Buffs.FullTalented
				inspectProfile.BuffSlots["OATHS"] = self.Constants.BuffSlots["OATHS"]
			elseif rank > 0 then
				inspectProfile.CastableBuffs["FLAT_CRIT"] = self.Constants.Buffs.PartialTalented
				inspectProfile.BuffSlots["OATHS"] = self.Constants.BuffSlots["OATHS"]
			end

			-- Totemic Wrath
			talentName, _, _, _, rank, maxrank = GetTalentInfo(1, 16, true, false, self.Constants:GetActiveSpec())
			if rank == maxrank then
				inspectProfile.CastableBuffs["SPELL_POWER"] = self.Constants.Buffs.FullTalented
				inspectProfile.BuffSlots["WRATHFUL"] = self.Constants.BuffSlots["WRATHFUL"]
			end

		elseif inspectProfile.Class == self.Constants.Classes.Deathknight then
			inspectProfile.OldRole = self.Constants.Roles.PureMelee

			-- Improved Icy Talons
			talentName, _, _, _, rank, maxrank = GetTalentInfo(2, 13, true, false, self.Constants:GetActiveSpec())
			if rank == maxrank then
				inspectProfile.CastableBuffs["MELEE_HASTE"] = self.Constants.Buffs.FullTalented
				inspectProfile.BuffSlots["ICY_TALONS"] = self.Constants.BuffSlots["ICY_TALONS"]
			end

			-- Abomination's Might
			talentName, _, _, _, rank, maxrank = GetTalentInfo(3, 1, true, false, self.Constants:GetActiveSpec())
			if rank == maxrank then
				inspectProfile.CastableBuffs["AP"] = self.Constants.Buffs.FullTalented
				inspectProfile.BuffSlots["ABOMINATIONS"] = self.Constants.BuffSlots["ABOMINATIONS"]
			elseif rank > 0 then
				inspectProfile.CastableBuffs["AP"] = self.Constants.Buffs.PartialTalented
				inspectProfile.BuffSlots["ABOMINATIONS"] = self.Constants.BuffSlots["ABOMINATIONS"]
			end

		elseif inspectProfile.Class == self.Constants.Classes.Warrior then
			inspectProfile.Role = BuffBroker:RoleFromTalents(
				self.Constants.Roles.PureMelee,
				self.Constants.Roles.PureMelee,
				self.Constants.Roles.Tank,
				self.Constants.Roles.PureMelee)
				
			inspectProfile.OldRole = self.Constants.Roles.PureMelee

			-- Rampage
			talentName, _, _, _, rank, maxrank = GetTalentInfo(2, 13, true, false, self.Constants:GetActiveSpec())
			if rank == maxrank then
				inspectProfile.CastableBuffs["FLAT_CRIT"] = self.Constants.Buffs.FullTalented
				inspectProfile.BuffSlots["RAMPAGE"] = self.Constants.BuffSlots["RAMPAGE"]
			end

		elseif inspectProfile.Class == self.Constants.Classes.Warlock then

			-- Demonic Pact
			talentName, _, _, _, rank, maxrank = GetTalentInfo(2, 18, true, false, self.Constants:GetActiveSpec())
			if rank == maxrank then
				inspectProfile.CastableBuffs["SPELL_POWER"] = self.Constants.Buffs.FullTalented
				inspectProfile.BuffSlots["PACT"] = self.Constants.BuffSlots["PACT"]
			end

		elseif inspectProfile.Class == self.Constants.Classes.Rogue then

			-- Honor among Thieves
			talentName, _, _, _, rank, maxrank = GetTalentInfo(3, 11, true, false, self.Constants:GetActiveSpec())
			if rank > 0 then
				inspectProfile.CastableBuffs["FLAT_CRIT"] = self.Constants.Buffs.FullTalented
				inspectProfile.BuffSlots["THIEVES"] = self.Constants.BuffSlots["THIEVES"]
			end

		elseif inspectProfile.Class == self.Constants.Classes.Hunter then

			-- Trueshot Aura
			talentName, _, _, _, rank, maxrank = GetTalentInfo(2, 11, true, false, self.Constants:GetActiveSpec())
			if rank == maxrank then
				inspectProfile.CastableBuffs["AP"] = self.Constants.Buffs.FullTalented
				inspectProfile.BuffSlots["TRUESHOT"] = self.Constants.BuffSlots["TRUESHOT"]
			end

			-- Hunting Party
			talentName, _, _, _, rank, maxrank = GetTalentInfo(3, 17, true, false, self.Constants:GetActiveSpec())
			if rank == maxrank then
				inspectProfile.CastableBuffs["MELEE_HASTE"] = self.Constants.Buffs.FullTalented
				inspectProfile.BuffSlots["HUNTING"] = self.Constants.BuffSlots["HUNTING"]
			end

		elseif inspectProfile.Class == self.Constants.Classes.Druid then
			-- determine role, based on deepest talent tree investment
			inspectProfile.Role = BuffBroker:RoleFromTalents(
				self.Constants.Roles.Caster,
				self.Constants.Roles.PureMelee,
				self.Constants.Roles.Caster,
				self.Constants.Roles.PureMelee)

			inspectProfile.OldRole = self.Constants.Roles.PureMelee

			-- Moonkin Aura
			talentName, _, _, _, rank, maxrank = GetTalentInfo(1, 9, true, false, self.Constants:GetActiveSpec())
			if rank == maxrank then
				inspectProfile.CastableBuffs["SPELL_HASTE"] = self.Constants.Buffs.FullTalented
				inspectProfile.BuffSlots["MOONKIN_AURA"] = self.Constants.BuffSlots["MOONKIN_AURA"]

			end

			-- Leader of the Pack
			talentName, _, _, _, rank, maxrank = GetTalentInfo(2, 12, true, false, self.Constants:GetActiveSpec())
			if rank == maxrank then
				inspectProfile.CastableBuffs["FLAT_CRIT"] = self.Constants.Buffs.FullTalented
				inspectProfile.BuffSlots["PACK"] = self.Constants.BuffSlots["PACK"]
			end

		elseif inspectProfile.Class == self.Constants.Classes.Priest then
			
			-- Shadow Form
			talentName, _, _, _, rank, maxrank = GetTalentInfo(1, 8, true, false, self.Constants:GetActiveSpec())
			if rank == maxrank then
				inspectProfile.CastableBuffs["SPELL_HASTE"] = self.Constants.Buffs.FullTalented
				inspectProfile.BuffSlots["PRIEST_FORM"] = self.Constants.BuffSlots["PRIEST_FORM"]
				--inspectProfile.BuffSlots["QUICKENING"] = self.Constants.BuffSlots["QUICKENING"]
			end

			-- knows vampiric embrace?
			talentName, _, _, _, rank, maxrank = GetTalentInfo(3, 14, true, false, self.Constants:GetActiveSpec()) -- vampiric embrace
			if rank == maxrank then
				inspectProfile.CastableBuffs["EMBRACE"] = self.Constants.Buffs.Basic
				inspectProfile.BuffSlots["EMBRACE"] = self.Constants.BuffSlots["EMBRACE"]
			end
			
		end

		-- if: we requested this data
		if not BuffList.InspectBusy then
			-- indicate we're done with it
			ClearInspectPlayer()
		end
		
		inspectProfile.Stale = false
		BuffList.InspectPending = nil
		BuffList.InspectGUID = nil

		-- TODO: Only flag providers if the inspect unveiled some new castable buff
		-- aka if they weren't profiled before, etc etc
		self:ProvidersChanged()

		if initialRole ~= inspectProfile.Role then
			self:RolesChanged()
			BuffList.AurasFirstChangedAt = GetTime()
			BuffList.AurasLastChangedAt = GetTime()
		end
		
		if self:ScanActive(inspectGUID) or inspectGUID == self.PlayerState:MyGUID() then
			self:PossibleSuggestionsChanged()
			
			-- TODO: change this to an "AurasChanged()" function, since
			-- it's done so much everywhere
			BuffList.AurasFirstChangedAt = GetTime()
			BuffList.AurasLastChangedAt = GetTime()
		end
	end
end

function BuffBroker:DraenorInspectAvailable(inspectGUID)
	local inspectProfile = self.PlayerState:GetProfile(inspectGUID)
	local initialRole
	local talentIndex
	
	BuffList.InspectOutstanding = nil

	if inspectProfile then
		initialRole = inspectProfile.Role
		MyDebugPrint("Inspect Available for %s", tostring(inspectGUID))
		
		-- check roles
		talentIndex = GetInspectSpecialization(inspectProfile.Name)

		self.PlayerState:SetRole(inspectGUID, talentIndex)

		-- if: we requested this data
		if not BuffList.InspectBusy then
			-- indicate we're done with it
			ClearInspectPlayer()
		end
		
		inspectProfile.Stale = false
		BuffList.InspectPending = nil
		BuffList.InspectGUID = nil

		-- TODO: Only flag providers if the inspect unveiled some new castable buff
		-- aka if they weren't profiled before, etc etc
		self:ProvidersChanged()

		if initialRole ~= inspectProfile.Role then
			self:RolesChanged()
			BuffList.AurasFirstChangedAt = GetTime()
			BuffList.AurasLastChangedAt = GetTime()
		end
		
		if self:ScanActive(inspectGUID) or inspectGUID == self.PlayerState:MyGUID() then
			self:PossibleSuggestionsChanged()
			
			-- queue up a refresh of lists
			BuffList.AurasFirstChangedAt = GetTime()
			BuffList.AurasLastChangedAt = GetTime()
		end
	end
end

function BuffBroker:RoleFromTalents(Role1, Role2, Role3, DefaultRole)

	return self.Constants:RoleFromTalents(Role1, Role2, Role3, DefaultRole)
end

function BuffBroker:ClearState()
	self.TalentGroup = self.Constants:GetActiveSpec()
	if not self.TalentGroup then
		self.TalentGroup = 'nil'
	end
	
	self.InCombat = InCombatLockdown()
	self.IsMounted = IsMounted()
	
	self.Constants.SpecSpells.Primary = GetSpellInfo(63645)
	self.Constants.SpecSpells.Secondary = GetSpellInfo(63644)
	
	-- make initial (interactive) frame & buttons
	hooksecurefunc('NotifyInspect', BuffBroker_NotifyInspect)
	hooksecurefunc('ClearInspectPlayer', BuffBroker_ClearInspectPlayer)

	-- Seed data structures
	self.PlayerState:UpdateRoleCount()

	-- Do other cool stuff
	BuffList.InspectLastChecked = GetTime()
	BuffList.LastCheckedRange = GetTime()
		
end

function BuffBroker:OnInitialize()
	local playerClass
	local slotOrder = options.args.general.args.buffSlots.order
	local constructedDefaults = {}
	local clientVersion = select(4, GetBuildInfo())

	-- Get client-specific constants
	self.Constants = BBConstants:new(clientVersion)

	-- Get client-specific player state/parser
	self.PlayerState = BBPlayerState:new(clientVersion, self.Constants)
	
	-- initialization goes here
	BuffBroker:ClearState()

	_, playerClass = UnitClass('player')
	
	constructedDefaults.profile = {}
	for k, v in pairs(defaults.base.profile) do constructedDefaults.profile[k] = v end
	--for k, v in pairs(defaults[playerClass].profile) do constructedDefaults.profile[k] = v end
	for k, v in pairs(self.Constants.classDefaults[playerClass].profile) do
		constructedDefaults.profile[k] = v
	end
	options.args.general.args.clientVersion.name = tostring(clientVersion)

	self.db = AceDB:New('BuffBrokerDB', constructedDefaults)
	self.db.RegisterCallback(self, 'OnProfileChanged', 'RefreshConfig')
	self.db.RegisterCallback(self, 'OnProfileCopied', 'RefreshConfig')
	self.db.RegisterCallback(self, 'OnProfileReset', 'RefreshConfig')

	profileDB = self.db.profile
	options.args.profile = LibStub('AceDBOptions-3.0'):GetOptionsTable(self.db)

	BuffBroker:UpdateSaveFile()

	-- register slash commands, for console interaction
	AceConfig:RegisterOptionsTable('BuffBroker', options, {'BuffBroker', 'bb'})

	-- Setup Blizzard option frames
	self.OptionsFrames = {}
	self.OptionsFrames.General = AceConfigDialog:AddToBlizOptions('BuffBroker', nil, nil, 'general')

	self:MakeMainFrame()	
end

function BuffBroker:UpdateSaveFile()

	if not profileDB.currentVersion then
		-- SUPER old; don't even bother
		print(L["Buff Broker: Save format changed! please check your settings in the Interface -> AddOns menu"])
	-- elseif profileDB.currentVersion == 1.0 then
		--[[ update to latest version, from this:
		base = {
			profile = {
				saveVersion = 1.0,
				refreshAtDuration = 20,
				raidBuffAttendThreshold = 0,
				raidBuffHeadCountThreshold = 1,
				frugal = false,
				friendly = false,
				healerLevel = 68,
				screenX = 0,
				screenY = -100,
				scale = 100,
				lock = false,
				show = true,
				tooltipAnchor = "ANCHOR_BOTTOM",
				skin = {
					ID = 'Blizzard',
					Backdrop = true,
					Gloss = 0,
					Zoom = false,
					Colors = {},
				},
				subskin = {
					ID = 'Blizzard',
					Backdrop = true,
					Gloss = 0,
					Zoom = false,
					Colors = {},
				},
				slots = {
					[1] = {},
					[2] = {},
				},
				activeSelfBuffs = {
					{}, -- talent group 1
					{}, -- talent group 2
				},
			},
		},
		[self.Constants.Classes.Warrior] = ...
		]]
	
	elseif profileDB.currentVersion == 1.0 then
		-- 4.0.1, inspection isn't working;  turn on the new 'consistent' option
		print(L["Buff Broker: Warning - Inspection is flaky (at best) in the 4.0.1 build of warcraft.  Suggestions may not be perfect.  In the meantime, a new feature has been added & enabled, which respects manually cast spells as 'best'"])
		profileDB.consistent = true
		profileDB.frugal = nil
	end	
	
	profileDB.currentVersion = profileDB.saveVersion
end

function BuffBroker:SkinChanged(SkinID, Gloss, Backdrop, Group, Button, Colors)
	
	if not Group then
		profileDB.skin.ID = SkinID
		profileDB.skin.Gloss = Gloss
		profileDB.skin.Backdrop = Backdrop
		profileDB.skin.Colors = Colors
	elseif Group == "MainBar" then
		profileDB.subskin.ID = SkinID
		profileDB.subskin.Gloss = Gloss
		profileDB.subskin.Backdrop = Backdrop
		profileDB.subskin.Colors = Colors
	end
end

function BuffBroker_ClearInspectPlayer()
	BuffList.InspectOutstanding = nil

	-- if: player/someone was using the inspect feature
	if BuffList.InspectBusy then
		MyDebugPrint("BuffBroker: Poached NotifyInspect;  inspectPlayer is free again")
		-- they must be done now
		BuffList.InspectBusy = nil
	else
		BuffList.InspectPending = nil
	end -- if: player/someone was using the inspect feature
end

function BuffBroker_NotifyInspect(unitName)
	local inspectGUID
	
	MyDebugPrint("someone asked for inspect data on "..tostring(unitName))
	BuffList.InspectOutstanding = GetTime()

	if BuffList.InspectGUID and unitName then
		
		if BuffList.InspectGUID ~= UnitGUID(unitName) then
			MyDebugPrint("BuffBroker: Poached NotifyInspect;  someone else requested %s", unitName)
			BuffList.InspectPending = nil
			BuffList.InspectBusy = GetTime()
			BuffList.InspectGUID = nil
		end
	else
		BuffList.InspectBusy = GetTime()
	end
end

function BuffBroker:OnUpdate(elapsed)
	local now = GetTime()
	
	if not tonumber(self.TalentGroup) then
		self.TalentGroup = self.Constants:GetActiveSpec()
	end
	
	-- if: 1/2 second from first change, or 1/10th second since last change
	if (BuffList.AurasFirstChangedAt and ((now - BuffList.AurasFirstChangedAt) > 0.5) )
	or (BuffList.AurasLastChangedAt and ((now - BuffList.AurasLastChangedAt) > 0.1) ) then
		BuffList.AurasFirstChangedAt = nil
		BuffList.AurasLastChangedAt = nil

		BuffBroker:RegenerateSuggestionDependencies()
		BuffBroker:AssignNextSuggestion()
	end -- if: auras finished changing

	-- if: time to check internal state
	if not BuffList.LastUpdateActivity or ((now - BuffList.LastUpdateActivity) > BuffList.UpdateActivityRate) then
		BuffList.LastUpdateActivity = now
		
		-- if: mounted state changed
		if (not self.IsMounted) ~= (not IsMounted()) then
			self.IsMounted = IsMounted()
			self:ResortSuggestions(BuffList.Suggestions)
			BuffBroker:AssignNextSuggestion()
		end

		-- if: left or entered a sanctuary (non-pvp) zone
		if (not self.InSanctuary) ~= (not UnitIsPVPSanctuary("player")) then
			self.InSanctuary = UnitIsPVPSanctuary("player")

			-- if: we're in a sanctuary
			if self.InSanctuary then
				-- if: don't suggest when in a sanctuary
				if profileDB.hiddenInSanctuary then
					-- we just entered a sanctuary; clear suggestions
					self:ClearButtonBuff()
				end
			elseif profileDB.hiddenInSanctuary then
				-- we just left a sanctuary; update the button
				self:AssignNextSuggestion()
			end
		end

		-- if: haven't profiled the player, or the party
		if nil == self.PlayerState:MyGUID()
		or nil == self.PlayerState:GetProfile(self.PlayerState:MyGUID()) then
			-- do so now (pro-tip:  Should find a trigger so this doesn't slow down load?)
			BuffBroker:RefreshPlayers()
			self:ScanActiveAll() 
		end -- if: haven't profiled the party yet
		
		-- seed last-seen self buffs on self
		if (not BuffBroker.SeededSelf) and profileDB.activeSelfBuffs and (self.PlayerState:IsInitialized(BuffList.InspectFucked)) then
			for labelName, spellID in pairs(profileDB.activeSelfBuffs[self.TalentGroup]) do
				if GetSpellInfo(spellID) then
					self.PlayerState:UpdateBuff(myGUID, myGUID, spellID, now - 1)
				else
					profileDB.activeSelfBuffs[self.TalentGroup][labelName] = nil
				end
			end
			
			BuffBroker.SeededSelf = true;
		end
			
		-- elseif: X seconds since last party check	
		if  ((now - BuffList.InspectLastChecked) > BuffList.InspectIdleWait)  then
			--print("waited "..BuffList.InspectIdleWait.." seconds, trying inspect again")
			-- update stale player list (add & prune)
			-- self.PlayerState:CheckStalePlayers()

			-- if: inspect temporarily unavailable
			if not CanInspect("player") then
				if not BuffList.InspectFucked then
					BuffList.InspectFucked = true
					MyDebugPrint("inspect hooped")
				end
			
				BuffList.TooltipError = L["*Inspection is Unavailable*"]
				--BuffList.TooltipFormatter = L["%d/%d players profiled"]
				--BuffList.TooltipMinor = BuffList.TooltipFormatter:format('??', self.PlayerState:GetPlayerCount())
			elseif BuffList.InspectFucked then
				MyDebugPrint("inspect better")
				BuffList.InspectFucked = nil
				BuffList.TooltipError = ''
			end

			-- if: not occupied
			if not BuffList.InspectPending then
				-- MyDebugPrint("Next Inspect, not pending, stale players to check")
				BuffBroker:NextInspect()

			-- if: Inspect target has moved out of range (while a request was pending)
			elseif BuffList.InspectPending
			and BuffList.InspectGUID
			and (nil == self.PlayerState:GetAttribute(BuffList.InspectGUID, 'Near')) then
				
				MyDebugPrint("Next Inspect, not pending, inspect target out of range ("..tostring(self.PlayerState:GetAttribute(BuffList.InspectGUID, 'Near'))..")")
				BuffBroker:NextInspect()
			end -- if: if: Inspect target has moved out of range (while a request was pending)

			BuffList.InspectLastChecked = now
		end
		
		-- if: inspect timed out
		if BuffList.InspectOutstanding and ((now - BuffList.InspectOutstanding) > BuffList.InspectTimeout) then
			if not BuffList.InspectBusy then
				ClearInspectPlayer()
				--BuffBroker:SetFailCode("BuffBroker: abandoning inspect request after "..BuffList.InspectTimeout.." seconds.  This is odd...")
			--else
				--BuffBroker:SetFailCode("BuffBroker: something has locked the inspect API for "..BuffList.InspectTimeout.." seconds now :3")
			end
			
			-- reset all inspection parameters
			BuffList.InspectBusy = false
			BuffList.InspectLastChecked = now
			BuffList.InspectComplete = true
			BuffList.InspectPending = nil
			BuffList.InspectGUID = nil
			BuffList.InspectOutstanding = nil
		end -- if: inspect timed out

		-- if: something else keeping us busy
		if BuffList.InspectBusy and ((now - BuffList.InspectBusy) > BuffList.BusyWarningTimeout) then -- BuffList.BusyWarningTimeout) then
			--BuffBroker:SetFailCode("BuffBroker: something has been hogging the inspect API for "..BuffList.BusyWarningTimeout.." seconds now :3")
			--BuffBroker:SetFailCode("BuffBroker: If you don't have the inspect window out, please check for addons (incorrectly) using ClearInspectPlayer() and NotifyInspect().  Posting this message & a list of your active addons would really help the BuffBroker author, if you have time!")
			BuffList.InspectBusy = nil
		end
		
		-- if: time to check range of players
		if ((now - BuffList.LastCheckedRange) > BuffList.RangeCheckDelay) and BuffBroker:ShouldProfile() then
			if self.PlayerState:GetPlayerCount() < 1 or not self.PlayerState:MyGUID() then
				BuffBroker:FullProfile()

			-- THN TODO DEBUG GOD DAMNIT: Workaround, for inspection lockup bug in bizzard API
			elseif self.PlayerState:IsInitialized(BuffList.InspectFucked) then
				-- TODO:  Trigger this ONLY when ANY buff needs to be refreshed
				-- TIP:  Watch the expiration time of oldest aura goes by
				-- ALTERNATE:  Scan for expired auras before doing refresh/regenerate/assign
				BuffBroker:RefreshPlayers()
				BuffBroker:RegenerateSuggestionDependencies()
				BuffBroker:AssignNextSuggestion()
			end
			
			BuffList.LastCheckedRange = now
		end -- if: time to check range of players
	end -- if: time to check internal state
end

function BuffBroker:ShouldProfile()

	local shouldProfile = not self.InCombat -- Not in combat
	and (profileDB.show or self.ActivityFrame:IsVisible() ) -- not (hidden & disabled while hidden)
	and not UnitIsDeadOrGhost('player') -- alive
	and not UnitControllingVehicle('player') -- not controlling a vehicle
	and not UnitUsingVehicle('player')
	-- add: in mounted?
	
	
	return shouldProfile
end

function BuffBroker:OnEvent(event, ...)
	local targetName
	local targetGUID
	local changedActionSlot
	local targetName
	local spellName
	local newPetID, petType, lastPetID
	local myGUID = self.PlayerState:MyGUID()

	if event == 'UNIT_AURA' then
		-- update aura data for affected unit
		targetGUID = UnitGUID(select(1, ...))

		-- if: unit is of interest to us
		if targetGUID and self.PlayerState:GetProfile(targetGUID) then
			-- if: during aura scan, anything relevant changed
			if BuffBroker:ScanActive(targetGUID) then
				BuffList.AurasLastChangedAt = GetTime()
				
				if not BuffList.AurasFirstChangedAt then
					BuffList.AurasFirstChangedAt = BuffList.AurasLastChangedAt
				end
			end -- if: during aura scan, anything relevant changed
		end -- if: unit is of interest to us

	elseif event == 'INSPECT_TALENT_READY' then
		-- wotlk
		MyDebugPrint("inspect data ready")
		BuffBroker:InspectAvailable()
	elseif event == 'INSPECT_READY' then
		-- cataclysm
		MyDebugPrint("inspect data ready for %s", tostring(select(1, ...)))
		-- BuffBroker:CataclysmInspectAvailable(select(1, ...))
		BuffBroker:DraenorInspectAvailable(select(1, ...))
	elseif event == 'PARTY_MEMBERS_CHANGED' then
		-- refresh buffer list
		MyDebugPrint("BB: party members changed")
		
		-- if: leaving or joining a party
		if 1 == self.PlayerState:GetPlayerCount() or 1 == GetNumPartyMembers() then
			self.PlayerState:ResetLastCast()
		end
		
		BuffBroker:RefreshPlayers()
	elseif event == 'RAID_ROSTER_UPDATE' then
		-- refresh buffer list
		MyDebugPrint("BB: raid roster updated")
		-- if: leaving or joining a raid
		if 1 == self.PlayerState:GetPlayerCount() or 1 == GetNumRaidMembers() then
			self.PlayerState:ResetLastCast()
		end
		
		BuffBroker:RefreshPlayers()
	elseif event == 'ACTIVE_TALENT_GROUP_CHANGED' then
		self.TalentGroup = self.Constants:GetActiveSpec()
		
		-- re-seed last-seen self buffs on self
		if myGUID then
			for labelName, spellID in pairs(profileDB.activeSelfBuffs[self.TalentGroup]) do
				if spellID and GetSpellInfo(spellID) then
					self.PlayerState:UpdateBuff(myGUID, myGUID, spellID, GetTime() - 1)
				else
					profileDB.activeSelfBuffs[self.TalentGroup][labelName] = nil
				end
			end
		end

	elseif event == 'UNIT_LEVEL' then
		targetGUID = UnitGUID(select(1, ...))
		
		if self.PlayerState:GetProfile(targetGUID)
		and nil == self.PlayerState:GetAttribute(targetGUID, 'Stale')
		and self.PlayerState:GetAttribute(targetGUID, 'Type') == self.Constants.Types.Player then
			self.PlayerState:SetAttribute(targetGUID, 'Stale', true)
			BuffBroker:FullProfile()
		end
	elseif event == 'LEARNED_SPELL_IN_TAB' then
		if self.PlayerState:GetProfile(self.PlayerState:MyGUID()) and not self.PlayerState:GetAttribute(self.PlayerState:MyGUID(), 'Stale') then
			self.PlayerState:SetAttribute(self.PlayerState:MyGUID(), 'Stale', true)
			self:PossibleSuggestionsChanged()
			BuffBroker:FullProfile()
		end
	elseif event == 'PLAYER_DEAD' then
		BuffList.TooltipPrime = L["Dead"]
		BuffList.TooltipDetail = L["Suggestions Disabled while dead"]
		BuffList.TooltipMinor = ''
		
		BuffBroker:ClearButtonBuff()
	elseif event == 'ACTIONBAR_SLOT_CHANGED' then
		changedActionSlot = select(1, ...)
		
		if listContains(self.Constants.Totems, changedActionSlot) then
			self:RegenerateSuggestionDependencies()
			self:AssignNextSuggestion()
		end
	elseif event == 'PLAYER_REGEN_DISABLED' then
		self.InCombat = true
		BuffList.TooltipPrime = L["Combat"]
		BuffList.TooltipDetail = L["Suggestions Disabled while in combat"]
		BuffList.TooltipMinor = ''
		
		self:ClearButtonBuff()
	elseif event == 'PLAYER_REGEN_ENABLED' then
		self.InCombat = nil
		self:FullProfile()
	elseif event == 'PLAYER_ENTERED_VEHICLE' or event == 'PLAYER_ENTERING_VEHICLE' then
		BuffList.TooltipPrime = L["Vehicle"]
		BuffList.TooltipDetail = L["Suggestions Disabled while in a vehicle"]
		BuffList.TooltipMinor = ''
		
		self:ClearButtonBuff()
	elseif event == 'PLAYER_EXITED_VEHICLE' or event == 'PLAYER_EXITING_VEHICLE' then
		self:FullProfile()
	elseif event == 'COMBAT_LOG_EVENT_UNFILTERED' then
		if BuffBroker:ShouldProfile() then
			self:ParseSpellCast(...)
		end
		--- spell cast by raid member, on raid member
		--- spell is a buff we want to monitor
	elseif event == 'UNIT_SPELLCAST_SUCCEEDED' then
		-- Spec change! 63645 spec 1, 63644 spec 2
		targetName, spellName = select(1, ...)
		
		if self.PlayerState:GetProfile(UnitGUID(targetName))
		and (spellName == self.Constants.SpecSpells.Secondary or spellName == self.Constants.SpecSpells.Secondary) then
			if UnitGUID(targetName) ~= self.PlayerState:MyGUID() then
				-- update their talent spec
				self.PlayerState:SetAttribute(UnitGUID(targetName), 'Stale', true)
				self:FullProfile()
			end
		end
	elseif event == 'PLAYER_ALIVE' then
		self:FullProfile()
	elseif event == 'PLAYER_LOGIN' then
		self:FullProfile()
	elseif event == 'UNIT_PET' then
		targetName = select(1, ...)
		
		if targetName then
			
			-- if: active pet changed
			if self.PlayerState:PetChanged(targetName) then
			
				-- if: aura data changed as a result
				if self:ScanActiveAll() then
					-- this change was significant enough to impact suggestions!
					BuffList.AurasFirstChangedAt = GetTime()
					BuffList.AurasLastChangedAt = GetTime()
				end -- if: aura data changed as a result
			end -- if: active pet changed
		end
		
	end
end

function BuffBroker:ParseSpellCast(timestamp, event, hidecaster, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, ...)
	local aurasChanged = false
	local playersToWipe = {}
	local buffLabel
	local lastTargetGUID
	local spellid
	local failReason
	local lastSpell


	-- if: cast by player
	if sourceGUID == self.PlayerState:MyGUID() then
		
		-- if: cast by me (successfully), on someone we're watching
		if event == 'SPELL_CAST_SUCCEEDED' and self.PlayerState:GetProfile(destGUID) then
			-- they must be in range & visible if we managed to buff 'em
			self.PlayerState:SetAttribute(destGUID, 'LOS', true)
		end
		
		-- if: player's spell failed
		if event == 'SPELL_CAST_FAILED' then
			spellid, _, _, failReason = select(1, ...)
			buffLabel = self.Constants:SpellInfoFromID(spellid)
			lastTargetGUID = nil
			
			-- TODO:  Cache target GUID in pre-click and post-click of action, to ensure we're not triggering from
			-- actions of user, or some other addon
			
			
			-- if: target not in LOS
			if failReason == SPELL_FAILED_LINE_OF_SIGHT -- "Target not in line of sight" <- can't buff, even if nearby;  close enough to get the buff
			or failReason == SPELL_FAILED_OUT_OF_RANGE then -- "Target not in range" <- can't buff, even if 'nearby';  too far for casting, close enough to get the buff
				if self.BuffButton:GetAttribute('unit') then
					lastTargetGUID = UnitGUID(self.BuffButton:GetAttribute('unit'))
				end
				if self.BuffButton:GetAttribute('spell') then
					lastSpell = UnitGUID(self.BuffButton:GetAttribute('spell'))
				end
				
				if self.PlayerState:GetProfile(lastTargetGUID) then
					-- mark player as out of LOS
					self.PlayerState:SetAttribute(lastTargetGUID, 'LOS', nil)
					-- re-sort suggestions for this player to end of list
					BuffBroker:RegenerateSuggestionDependencies()
					self:AssignNextSuggestion()
				end

			-- elseif: can't over-write more powerful spell
			elseif failReason == SPELL_FAILED_AURA_BOUNCED then -- "A more powerful spell is already active" <- got a buff from someone outside the party
				-- occurs when an unknown source buffed the party (ie: lesser talented blessings, thorns, etc)
				-- set ActiveBuffs[label].Strength to ONE NOTCH higher than what we can do
				if self.BuffButton:GetAttribute('unit') then
					lastTargetGUID = UnitGUID(self.BuffButton:GetAttribute('unit'))
				end
				if self.BuffButton:GetAttribute('spell') then
					lastSpell = UnitGUID(self.BuffButton:GetAttribute('spell'))
				end

				-- if: known target, and buff known/cached, and we can do the same buff
				if self.PlayerState:GetProfile(lastTargetGUID)
				and buffLabel and self.PlayerState:GetAttribute(lastTargetGUID, 'ActiveBuffs')[buffLabel]
				and self.PlayerState:GetAttribute(self.PlayerState:MyGUID(), 'CastableBuffs')[buffLabel]
				and self.PlayerState:GetAttribute(lastTargetGUID, 'ActiveBuffs')[buffLabel].Caster ~= self.PlayerState:MyGUID() then
					-- update strength to better than what we can do
					self.PlayerState:GetAttribute(lastTargetGUID, 'ActiveBuffs')[buffLabel].Strength = self.Constants.Buffs.Awesome
					self.PlayerState:GetAttribute(lastTargetGUID, 'ActiveBuffs')[buffLabel].StrengthStale = nil
					

					-- re-do suggestions
					BuffBroker:RegenerateSuggestionDependencies()
					self:AssignNextSuggestion()
				end
			end
			
		end -- if: player's spell failed
	end -- if: cast by player
end

function BuffBroker:MarkMove()
	self.MoveStartX = self.ActivityFrame:GetLeft()
	self.MoveStartY = self.ActivityFrame:GetTop()

	self.ActivityFrame:StartMoving()
end

function BuffBroker:StopMove()
	local offsetX, offsetY
	
	-- if - already moving
	if self.MoveStartX and self.MoveStartY then
		-- adjust frame position based on move distance
		offsetX = self.ActivityFrame:GetLeft() - self.MoveStartX
		offsetY = self.ActivityFrame:GetTop() - self.MoveStartY
		self.ActivityFrame:StopMovingOrSizing()
		
		profileDB.screenX = profileDB.screenX + offsetX
		profileDB.screenY = profileDB.screenY + offsetY
		
		-- clear/save start-of-move indicators
		self.MoveStartX = nil
		self.MoveStartY = nil
	end
end

function BuffBroker:MakeMainFrame()

	local f, t
	-- create 'Frame'
	f = CreateFrame('Frame', nil, UIParent, "SecureActionButtonTemplate")
	f:SetPoint('TOPLEFT', profileDB.screenX, profileDB.screenY)
	f:SetHeight(80)
	f:SetWidth(64)
	f:SetMovable(true)
	f:RegisterEvent('UNIT_AURA')
	f:RegisterEvent('INSPECT_TALENT_READY') -- wotlk
	f:RegisterEvent('INSPECT_READY') -- cataclysm
	f:RegisterEvent('PARTY_CONVERTED_TO_RAID')
	f:RegisterEvent('PARTY_MEMBERS_CHANGED')
	f:RegisterEvent('PARTY_MEMBERS_ENABLE')
	f:RegisterEvent('RAID_ROSTER_UPDATE')
	f:RegisterEvent('COMBAT_LOG_EVENT_UNFILTERED')
	f:RegisterEvent('UNIT_SPELLCAST_SUCCEEDED')
	f:RegisterEvent('ACTIVE_TALENT_GROUP_CHANGED')
	f:RegisterEvent('LEARNED_SPELL_IN_TAB')
	f:RegisterEvent('PLAYER_DEAD')
	f:RegisterEvent('UNIT_LEVEL')
	f:RegisterEvent('PLAYER_REGEN_ENABLED')
	f:RegisterEvent('PLAYER_REGEN_DISABLED')
	f:RegisterEvent('PLAYER_ENTERED_VEHICLE')
	f:RegisterEvent('PLAYER_ENTERING_VEHICLE')
	f:RegisterEvent('ACTIONBAR_SLOT_CHANGED')
	f:RegisterEvent('UNIT_PET')
	f:RegisterEvent('UNIT_ENTERED_VEHICLE')
	f:RegisterEvent('UNIT_EXITED_VEHICLE')
	f:RegisterEvent('UNIT_ENTERING_VEHICLE')
	f:RegisterEvent('UNIT_EXITING_VEHICLE')
	f:RegisterEvent('PLAYER_LOGIN')
	f:SetScript('OnEvent', function(_, event, ...) self:OnEvent(event, ...) end)
	f:SetScript('OnUpdate', function(_, elapsed) self:OnUpdate(elapsed) end)
	self.ActivityFrame = f
	if profileDB.show then
		self.ActivityFrame:Show()
	else
		self.ActivityFrame:Hide()
	end
	
	-- make move handle
	f = CreateFrame('Frame', nil, self.ActivityFrame)
	f:SetMovable(true)
	f:SetPoint('TOPLEFT', self.ActivityFrame, 'TOPLEFT')
	f:SetHeight(16)
	f:SetWidth(64)
	f:SetScale(profileDB.scale / 100)
	f:EnableMouse(true)
	f:RegisterForDrag('LeftButton')
	f:SetScript('OnMouseDown', function() BuffBroker:MarkMove() end)
	f:SetScript('OnMouseUp', function() BuffBroker:StopMove() end)
	f:SetScript('OnHide', function() BuffBroker:StopMove() end)
	f:SetFrameStrata('LOW')
	self.MoveFrame = f
	if profileDB.lock then
		self.MoveFrame:Hide()
	else
		self.MoveFrame:Show()
	end

	fs = self.MoveFrame:CreateFontString()
	fs:SetAllPoints(self.MoveFrame)
	fs:SetFontObject(GameFontNormalSmall)
	fs:SetJustifyH('CENTER')
	fs:SetJustifyV('MIDDLE')
	fs:SetText('BuffBroker')
	self.MoveFrame.FontString = fs

	-- make buttan
	f = CreateFrame('Button', 'BuffBroker_CastSuggestionButton', self.ActivityFrame, 'SecureActionButtonTemplate')
	f:SetNormalTexture('Interface\\Icons\\Spell_Holy_Dizzy.blp')
	t = f:GetNormalTexture()
	f:RegisterForClicks('LeftButtonDown', 'RightButtonDown')
	--f:RegisterForClicks('AnyUp')
	f:SetHeight(64)
	f:SetWidth(64)
	f:SetScale(profileDB.scale / 100)
	f:SetPoint('TOPLEFT', self.MoveFrame, 'BOTTOMLEFT')
	f:SetScript('OnEnter', function() self.ShowingTooltip = true BuffBroker:ShowTip() end)
	f:SetScript('OnLeave', function() self.ShowingTooltip = false BuffBroker:FadeTip() end)
	--f:SetScript'OnClick',function(this) BuffBroker:UpdateButtonSpell() end)
	f:SetScript('PreClick',function(this) BuffBroker:PreClick() end)
	f:SetScript('PostClick',function(this, button, down) BuffBroker:PostClick(button, down) end)
	self.BuffButton = f
	self.BuffTexture = t
	
	t = self.MoveFrame:CreateTexture(nil, 'BACKGROUND')
	t:SetTexture('Interface\\Tooltips\\ChatBubble-Background.blp')
	t:SetPoint('TOPLEFT', self.ActivityFrame, 'TOPLEFT')
	t:SetPoint('BOTTOMRIGHT', self.BuffButton, 'BOTTOMRIGHT')
	self.MoveFrame.texture = t

	self.BuffButton:Raise()
	self.ActivityFrame:Show()

end

function BuffBroker:PreClick()

	-- todo:  SetOverrideBindingClick() has to be invoked for us to intercept MWUP and MWDOWN,
	-- assuming we're registered for clicks 'AnyUp'
	-- That function has to be called on each PLAYER_ENTERING_WORLD event...maybe for
	-- zone changes when they enter an instance too?
	
	-- todo:  capture who the current target is, for checking combat spell failure events
	-- todo:  clear spell target/id on right-click
end

function BuffBroker:PostClick(button, down)
	
	-- todo:  open context menu on right-click
	-- todo:  restore spell target/id on right-click
end

function BuffBroker:ShowTip()
	if self.ShowingTooltip then
		GameTooltip:SetOwner(self.BuffButton, profileDB.tooltipAnchor)
		GameTooltip:SetText(BuffList.TooltipPrime, 1, .82, 0, 1)
		GameTooltip:AddLine(BuffList.TooltipDetail, 1, 1, 1, 1)
		GameTooltip:AddLine(BuffList.TooltipMinor, .7, .7, .7, 1)
		
		if BuffList.TooltipError and BuffList.TooltipError ~= '' then
			GameTooltip:AddLine(BuffList.TooltipError, .7, .7, .7, 1)
		end

		GameTooltip:Show()
	end
end

function BuffBroker:FadeTip()
	GameTooltip:FadeOut()
end

function BuffBroker:OnEnable()
	local playerClass
	_, playerClass = UnitClass('player')

	-- activate
	-- set up skinning framework
	if LBF then
		-- Group registration delayed until OnEnable, to ensure it shows up in the ButtonFacade UI
		LBF:RegisterSkinCallback("BuffBroker", self.SkinChanged, self)
		LBF:Group("BuffBroker"):Skin(
			profileDB.skin.ID,
			profileDB.skin.Gloss,
			profileDB.skin.Backdrop,
			profileDB.skin.Colors)

		LBF:Group("BuffBroker", "MainBar"):Skin(
			profileDB.subskin.ID,
			profileDB.subskin.Gloss,
			profileDB.subskin.Backdrop,
			profileDB.subskin.Colors)

		LBF:Group("BuffBroker", "MainBar"):AddButton(self.BuffButton, {Button = self.BuffButton, Icon = self.BuffTexture,} )
	
	end

	-- Seed primary spec possibilities
	slotOrder = options.args.general.args.buffSlots.order + 2
	-- for: each class-appropriate buffslot
	-- for slotName, slotEnabled in pairs(defaults[playerClass].profile.slots[1]) do
	for slotName, slotEnabled in pairs(self.Constants.classDefaults[playerClass].profile.slots[1]) do
		options.args.general.args["1"..slotName] = {
			type = 'toggle',
			order = slotOrder,
			width = 'single',
			name = L[slotName],
			desc = L[slotName.."_DESC"],
			arg = "1"..slotName,
			get = getProfileOption,
			set = setProfileOption,
		}

		slotOrder = slotOrder + 1
	end

	if self.Constants:GetNumSpecs() > 1 then
		options.args.general.args.buffSlotsDualSpec.dialogHidden = false
		options.args.general.args.buffSlotsDualSpec_desc.dialogHidden = false
	
		-- Seed offspec possibilities
		slotOrder = options.args.general.args.buffSlotsDualSpec.order + 2
		-- for: each class-appropriate buffslot
		-- for slotName, slotEnabled in pairs(defaults[playerClass].profile.slots[2]) do
		for slotName, slotEnabled in pairs(self.Constants.classDefaults[playerClass].profile.slots[2]) do
			options.args.general.args["2"..slotName] = {
				type = 'toggle',
				order = slotOrder,
				width = 'single',
				name = L[slotName],
				desc = L[slotName.."_DESC"],
				arg = "2"..slotName,
				get = getProfileOption,
				set = setProfileOption,
			}

			slotOrder = slotOrder + 1
		end
	end
end

function BuffBroker:OnDisable()
	-- deactivate
end

function MyDebugPrint(formatText, ...)
	if BuffBroker.PrintDebug then
		print(formatText:format(...))
	end
end

function listContains(theList, thisValue)
	local found
	local i
	
	if theList then
		-- for: each pair in table
		for key, value in pairs(theList) do
			-- if: match
			if value == thisValue then
				found = true
				break
			end -- if: match
		end
	end
	
	return found
end

function BuffBroker:IsGreaterPallyBuff(spellid)
	local found
	
	for _, GreaterSpellid in pairs(BuffList.GreaterLookup["BLESSINGS"]) do
		if spellid == GreaterSpellid then
			found = true
			break
		end
	end
	
	return found
end

function BuffBroker:GetGreaterPallyBuff(spellid)
	local greaterVersion = BuffList.GreaterLookup["BLESSINGS"][spellid]
	
	if not greaterVersion then
		greaterVersion = spellid
	end
	
	return greaterVersion
end

function BuffBroker:UpdateRangeCheck(ignoreLive)
	local targetGUID, targetProfile, className
	local totalNear = 0
	
	--[[
	for _, className in pairs(self.Constants.Classes) do
		theClasses[className].Near = 0
	end
	]]

	for targetGUID, targetProfile in self.PlayerState:Iterator() do
		if not ignoreLive then
			targetProfile.Near =
				( (UnitInRange(targetProfile.Name) or targetGUID == self.PlayerState.PlayerGUID)
				and not UnitInVehicle(targetProfile.Name)
				and not UnitIsDeadOrGhost(targetProfile.Name)
				and UnitIsConnected(targetProfile.Name))

			MyDebugPrint(targetProfile.Name.." in range: "..tostring(targetProfile.Near))
			--[[
			if (UnitInRange(targetProfile.Name) and not UnitInVehicle(targetProfile.Name) and not UnitIsDeadOrGhost(targetProfile.Name) and UnitIsConnected(targetProfile.Name)) then
				targetProfile.Near = true
				--theClasses[targetProfile.Class].Near = theClasses[targetProfile.Class].Near + 1
				--totalNear = totalNear + 1
			else
				targetProfile.Near = false
				--self:ScanActive(targetGUID)
			end ]]
		end
	end

	-- theClasses[self.Constants.Classes.Raid].Near = totalNear
	self.PlayerState:UpdateClassState()
end

function BuffBroker:GetBuffDepth(Role, Spellid)
	local actualDepth = 0
	local buffLabel
	local iDepth, currentLabel
	local mockLabelArray = {}

	-- determine label of spell
	buffLabels = self.Constants:SpellInfoFromID(Spellid)
	
	-- if: old style single-type returned
	if type(buffLabels) == "string" then
		-- convert to new multi-benefit result
		mockLabelArray[1] = buffLabels
		buffLabels = mockLabelArray
	end -- if: old style single-type returned

	for _, buffLabel in ipairs(buffLabels) do
		if self.Constants.BuffPriorities[Role][buffLabel]
		and self.Constants.BuffPriorities[Role][buffLabel] > actualDepth then
			actualDepth = self.Constants.BuffPriorities[Role][buffLabel]
		end
	end
	
	return actualDepth
end

function BuffBroker:BuildDesirability(possibleSuggestion)
	local runningPriority = 0
	local runningHeadCount = 0
	local currentPriority
	local possiblePriority
	local betterCount
	local targetBuffLabel = nil
	local targetBuffSlot = nil
	local roleCount

	targetBuffLabel, targetBuffSlot = self.Constants:SpellInfoFromID(possibleSuggestion.spellid)

	-- for - each role
	for role, roleCount in pairs(possibleSuggestion.RoleCount) do
	
		-- reset the current spellid's priority & count
		betterCount = 0
		possiblePriority = self:GetBuffDepth(role, possibleSuggestion.spellid)
		
		-- for - each spell in current buffslot
		for currentSlotID, currentSlotData in pairs(self.Constants.BuffSlots[targetBuffSlot]) do
			
			-- get depth
			currentPriority = self:GetBuffDepth(role, currentSlotID)
			
			-- if - depth is better/higher than possibleSuggestion's (aka more desirable)
			if currentPriority >= possiblePriority then

				-- print(possibleSuggestion.TargetProfile.Name.." prefers "..GetSpellInfo(currentSlotID).." over "..GetSpellInfo(possibleSuggestion.spellid))
				-- that's one more buff we know that's more desirable than this one
				betterCount = betterCount + 1
			end
		end

		-- cache running seen total: add "seen" x role count
		-- cache running headcount: add role count
		runningPriority = runningPriority + (betterCount * roleCount)
		runningHeadCount = runningHeadCount + roleCount
					
	end
	
	-- print("desirability of "..GetSpellInfo(possibleSuggestion.spellid).." on "..possibleSuggestion.TargetProfile.Name..": "..tostring(runningPriority).."/"..tostring(runningHeadCount))
	-- divide running total by total count
	return (runningPriority / runningHeadCount)
end

--[[
function compareRaidPreference(left, right)
	local leftRaidPreference, rightRaidPreference = 0, 0
	local leftDepth, rightDepth = 0, 0

	-- for: each role
	for roleName, _ in pairs(self.Constants.BuffPriorities) do
		-- if: have any of that role in the raid
		if left.RoleCount[roleName] and right.RoleCount[roleName] then
			leftDepth = BuffBroker:GetBuffDepth(roleName, left.spellid)
			rightDepth = BuffBroker:GetBuffDepth(roleName, right.spellid)
			
			if leftDepth and rightDepth then
				if leftDepth > rightDepth then
					-- roleName prefers left.spellid over right.spellid
					leftRaidPreference = leftRaidPreference + left.RoleCount[roleName]
				elseif leftDepth < rightDepth then
					-- roleName prefers right.spellid over left.spellid
					rightRaidPreference = rightRaidPreference + right.RoleCount[roleName]
				else
					-- roleName doesn't prefer either left.spellid or right.spellid
				end
			elseif leftDepth and not rightDepth then
				-- roleName doesn't care about right.spellid
				leftRaidPreference = leftRaidPreference + left.RoleCount[roleName]
			elseif not leftDepth and rightDepth then
				-- roleName doesn't care about left.spellid
				rightRaidPreference = rightRaidPreference + right.RoleCount[roleName]
			else
				-- roleName doesn't care about left.spellid or right.spellid
			end
		elseif left.RoleCount[roleName] ~= right.RoleCount[roleName] then
			print(L["BuffBroker:  Internal error, suggestions contain different role counts"])
		end -- if: have any of that role in the raid
	end
	
	return leftRaidPreference, rightRaidPreference
end

]]

function OrderSuggestions(left, right)
	local buffLabel, suggestedLabel
	local leftFirst = false
	local leftPriority, rightPriority
	local leftRaidPreference, rightRaidPreference = 0, 0
	local leftDepth, rightDepth = 0, 0
	local groupScope
	local self = BuffBroker
	local isRaidWide = self.Constants:IsRaidWide(left.Scope)
	local leftMounted, rightMounted

	-- left/right:  {Confidence=self.Constants.Confidence.#, Target='name', TargetProfile=BuffList.Player[name], spellid=#, Attendance=#, IsDominantRole=bool}

	-- if: compare container validity
	if left and not right then
		leftFirst = true
	elseif not left and not right then
		leftFirst = true
		BuffBroker:SetFailCode("Buff Broker hit a snag sorting suggestions (nothing to sort).  Please notify the author!")
		
	elseif left and right then
	
		-- if: compare target validity
		if left.TargetProfile and not right.TargetProfile then
			leftFirst = true
		elseif (not left.TargetProfile and not right.TargetProfile) then
			-- Note:  we should NEVER get suggestions for targets which aren't in the cache!
			leftFirst = true

			BuffBroker:SetFailCode("Buff Broker hit a snag sorting suggestions (no target data).  Please notify the author!")
			if left.spellid > right.spellid then
				leftFirst = true
			elseif left.spellid == right.spellid then
				--BuffBroker:SetFailCode("Buff Broker hit a snag sorting suggestions (identical spells, no target data).  Please notify the author!")
			end
		elseif left.TargetProfile and right.TargetProfile then

			-- if: comparing line of sight
			if left.TargetProfile.LOS and not right.TargetProfile.LOS then
				leftFirst = true
			elseif left.TargetProfile.LOS == right.TargetProfile.LOS then

				-- if: comparing scope
				if left.Scope > right.Scope then
					leftFirst = true
				elseif left.Scope == right.Scope then
					
					-- match mounted state
					-- TODO:  Should calculate this OUTSIDE the sort function,
					-- to allow state-independent unit tests
					-- This is exactly why "near" isn't checked in this function...
					leftMounted = ((not IsMounted()) == (not left.Mounted))
					rightMounted = ((not IsMounted()) == (not right.Mounted))
					if leftMounted and (not rightMounted) then
						leftFirst = true
					elseif leftMounted == rightMounted then
					
						-- prioritize "last cast", if we're configured to respect that
						if left.LastCast and (not right.LastCast) then
							leftFirst = true
						elseif (not left.LastCast) and (not right.LastCast) then
					
							-- order by class (note: raid buffs SHOULD target the player, always!)
							if left.Class < right.Class then
								leftFirst = true
							elseif left.Class == right.Class then
								
								-- same scope; check preference (raid only)
								if isRaidWide or (left.Scope == self.Constants.Scope.Class) then
								
									leftRaidPreference = left.Desirability
									rightRaidPreference = right.Desirability
								end
								
								-- if: comparing raid preference
								if leftRaidPreference < rightRaidPreference then
									leftFirst = true
								elseif leftRaidPreference == rightRaidPreference then
							
									if left.Attendance > right.Attendance then
										leftFirst = true
									elseif left.Attendance == right.Attendance then
										-- same attendance; check class

										-- if: compare presence as dominant role
										if left.IsDominantRole and not right.IsDominantRole then
											-- left more dominant than right
											leftFirst = true
										elseif left.IsDominantRole == right.IsDominantRole then

											-- if: compare targets (players)
											if left.TargetProfile.Name < right.TargetProfile.Name then
												leftFirst = true
											elseif left.TargetProfile.Name == right.TargetProfile.Name then
												
												-- same target

												-- if: compare confidences
												if left.Confidence > right.Confidence then
													leftFirst = true
												elseif left.Confidence == right.Confidence then

													-- Determine how important this buff is (1 is very important)
													leftPriority = BuffBroker:GetBuffDepth(left.TargetProfile.Role, left.spellid)
													rightPriority = BuffBroker:GetBuffDepth(right.TargetProfile.Role, right.spellid)
													
													-- if: compare relevance of buff
													if leftPriority and not rightPriority then
														leftFirst = true
													elseif (leftPriority and rightPriority) and (leftPriority > rightPriority) then
														leftFirst = true
													elseif leftPriority == rightPriority then
															-- No two suggestions would have the same target, confidence, and priority... would they?
															-- might wind up here if comparing class buff vs profession buff, so put in SOME kind of reproducible comparator
															if left.spellid > right.spellid then
																leftFirst = true
															elseif left.spellid == right.spellid then
																--BuffBroker:SetFailCode("Buff Broker hit a snag sorting suggestions (identical spells).  Please notify the author!")
															end
													end -- if: compare relevance of buff for both
												end -- if: compare confidences
											end -- if: compare targets(players)
										end -- if: compare presence as dominant role
									end -- if: comparing attendance
								end -- if: comparing preference (raid only)
							end -- if: comparing class
						end -- if: comparing last cast
					end -- if: compare matching mount state
				end -- if: comparing scope
			end -- if: comparing line of sight
		end -- if: compare target validity
	end -- if: compare container validity
	--[[
	osL = 'Left: Attend: '..(left.Attendance * 100)..'%, C: '..left.TargetProfile.Class..', D: '
	if left.IsDominantRole then osL = osL..'T' else osL = osL..'F' end
	osL = osL..', N: '..left.TargetProfile.Name..', Conf: '..left.Confidence..', P: '
	if leftPriority then osL = osL..leftPriority end
	
	
	osR = 'Right: Attend: '..(right.Attendance * 100)..'%, C: '..right.TargetProfile.Class..', D: '
	if right.IsDominantRole then osR = osR..'T' else osR = osR..'F' end
	osR = osR..', N: '..right.TargetProfile.Name..', Conf: '..right.Confidence..', P: '
	if rightPriority then osR = osR..rightPriority end

	if leftFirst then print(osL..' ><before><'..osR) else print(osR..' ><before>< '..osL) end
	--	]]
	
	return leftFirst
end

function BuffBroker:RefreshConfig(event, database, newProfileKey)
	-- this is called every time our profile changes (after the change)
	profileDB = database.profile
	clearCache()
end

function BuffBroker:SetFailCode(failureMessage)
	if not self.FailCodes[failureMessage] then
		print(failureMessage)
		self.FailCodes[failureMessage] = true
	end
end