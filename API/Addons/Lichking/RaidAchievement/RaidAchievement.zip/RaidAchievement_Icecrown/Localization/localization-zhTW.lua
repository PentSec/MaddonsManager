﻿if GetLocale() == "zhTW" then

function icralocaleboss()

icracouncilboss1			= "瓦拉納爾王子"
icracouncilboss2			= "泰爾達朗王子"
icracouncilboss3			= "凱雷希斯王子"
icravalitriayell1			= "我打開了一道傳送門通往夢境。你們的救贖就在其中，英雄們……"
icravalitriayell2			= "我重生了!伊瑟拉賦予我讓那些邪惡生物安眠的力量!"

end


function icralocaleui()

icratitle				= "    冰冠城塞"
raiccof					= "的"
raiccused				= "使用"



end


end