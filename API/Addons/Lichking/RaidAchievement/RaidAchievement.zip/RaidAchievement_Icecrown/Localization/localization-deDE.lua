﻿if GetLocale() == "deDE" then

function icralocaleboss()

icracouncilboss1			= "Prinz Valanar"
icracouncilboss2			= "Prinz Taldaram"
icracouncilboss3			= "Prinz Keleseth"
icravalitriayell1			= "Ich habe ein Portal in den Traum ge\195\182ffnet. Darin liegt Eure Erl\195\182sung, Helden..."
icravalitriayell2			= "ICH BIN GEHEILT! Ysera, erlaubt mir diese \195\188blen Kreaturen zu beseitigen!"

end



function icralocale()


end



function icralocaleui()

icratitle				= "    Eiskronenzitadelle"
raiccof					= "von"
raiccused				= "betraten"



end


end