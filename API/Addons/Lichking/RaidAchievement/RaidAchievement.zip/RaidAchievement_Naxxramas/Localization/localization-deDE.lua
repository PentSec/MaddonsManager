﻿if GetLocale() == "deDE" then

function nxralocaleboss()

nxraloatheb				= "Loatheb"
nxraspore				= "Spore"
nxraanubrekan				= "Anub'Rekhan"
nxrameksna				= "Maexxna"
nxrafaerlin				= "Gro\195\159witwe Faerlina"
nxrakeladd				= "Unaufhaltsame Monstrosit\195\164t"
nxraonyxiab				= "Onyxia"
nxraonyemote				= "takes in a deep breath"

end




function nxralocale()



end



function nxralocaleui()

nxratitle				= "    Naxxramas + andere Minischlachtz\195\188ge WotLk"



end


end