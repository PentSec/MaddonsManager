﻿if GetLocale() == "ruRU" then 

function psealocaleuldaboss()

pseaauriayaadd				= "Часовой святилища"
pseamimironadd				= "Бомбот"
pseahodiradds				={"Тор Серое Облако",
					  "Кар Серое Облако",
					  "Эйви Ночное Перо",
					  "Элли Ночное Перо",
					  "Духостранница Тара",
					  "Духостранница Йона",
					  "Повелитель стихий Мафуун",
					  "Повелитель стихий Авуун",
					  "Амира Прядильщица Пламени",
					  "Виша Прядильщица Пламени",
					  "Мисси Огняш",
					  "Зисси Огняш",
					  "Боевая жрица Элиза",
					  "Боевая жрица Джина",
					  "Полевой врач Пенни",
					  "Полевой врач Джесси"}

end



function psealocaleulduar()

pseaulduarkolf1				= "Адд убит!"
pseaulduarkolf2				= "не будет выполнено, если убьете босса!"
pseamimifailloc1			= "Бомбот!"
pseamimifailloc2			= "Ракетный залп!"
pseamimifailloc3			= "Мина!"
pseamimifailloc5			= "часть провалена!"
pseatrebulda2				= "Остался последний адд! ПОТОМ убейте босса!"

end



function psealocaleulduarui()

pseaulduartitle				= "    Ульдуар"



end




end