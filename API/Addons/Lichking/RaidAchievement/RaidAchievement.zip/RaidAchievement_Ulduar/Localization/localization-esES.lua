﻿if GetLocale() == "esES" then

function psealocaleuldaboss()

pseaauriayaadd				= "Centinela del sagrario"
pseamimironadd				= "Robot bum"
pseahodiradds				={"Tor Nubegris",
					  "Kar Nubegris",
					  "Eivi Pluma de la Noche",
					  "Ellie Pluma de la Noche",
					  "Caminaespíritus Tara",
					  "Caminaespíritus Yona",
					  "Elementalista Mahfuun",
					  "Elementalista Avuun",
					  "Amira Tejellamas",
					  "Veesha Tejellamas",
					  "Missy Puños en Llamas",
					  "Sissy Puños en Llamas",
					  "Sacerdotisa de batalla Eliza",
					  "Sacerdotisa de batalla Gina",
					  "Médico de campo Penny",
					  "Médico de campo Jessi"}

end



end