﻿if GetLocale() == "zhTW" then

function psealocaleuldaboss()

pseaauriayaadd				= "聖所哨兵"
pseamimironadd				= "炸彈機器人"
pseahodiradds				={"拓爾·灰雲",
					  "卡爾·灰雲",
					  "艾薇·夜羽",
					  "艾里·夜羽",
					  "靈行者塔菈",
					  "靈行者悠娜",
					  "元素師瑪弗恩",
					  "元素師艾弗恩",
					  "阿米菈·炎織者",
					  "薇莎·炎織者",
					  "蜜西·焰袖",
					  "西希·焰袖",
					  "戰鬥牧師伊莉莎",
					  "戰鬥牧師吉娜",
					  "戰地醫護兵佩尼",
					  "戰地醫護兵傑西"}

end



function psealocaleulduar()

pseaulduarkolf1 = "小怪已被擊殺!" 
pseaulduarkolf2 = "成就將因首領被擊殺而無法達成!" 
pseamimifailloc1 = "炸彈機器人!" 
pseamimifailloc2 = "火箭攻擊!" 
pseamimifailloc3 = "環罩地雷!" 
pseamimifailloc5 = "部分失敗!" 
pseatrebulda2 = "殺掉最後一個小怪就可以殺了首領!"

end



function psealocaleulduarui()

pseaulduartitle = "奧杜亞" 


end


end