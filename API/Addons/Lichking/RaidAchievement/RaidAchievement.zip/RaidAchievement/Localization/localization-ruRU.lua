﻿if GetLocale() == "ruRU" then

function psealocalezone()
pseaheroicslist				= "Ан'кахет: Старое Королевство,Крепость Драк'Тарон,Гундрак,Чертоги Молний,Чертоги Камня,Нексус,Вершина Утгард,Аметистовая крепость,Испытание чемпиона,Кузня Душ,Яма Сарона,Залы Отражений"
pseaheroicslist2			= "Азжол-Неруб"
pseazoneulduar				= "Ульдуар"
pseazonenax				= "Наксрамас"
pseazonesart				= "Обсидиановое святилище"
pseazoneonya				= "Логово Ониксии"
pseazoneic				= "Цитадель Ледяной Короны"

end


function psealocale()


pseachatlist1				= "рейд"
pseachatlist2				= "объявление рейду"
pseachatlist3				= "офицер"
pseachatlist4				= "группа"
pseachatlist5				= "гильдия"
pseachatlist6				= "сказать"
pseachatlist7				= "крикнуть"
pseachatlist8				= "только себе"
pseaaddonmy				= "Аддон"
pseaaddonon2				= "включен"
pseaaddonoff				= "отключен"
pseamoduleload				= "Загружен модуль"
pseamodulenotload			= "Не удалось загрузить модуль"
pseaaddonon				= "Включить аддон"
pseaaddonok				= "OK"
pseatreb2				= "требования выполнены! Теперь убейте босса!"
pseatreb4				= "провалено!"
ranewversfound				= "|cff00ff00ВНИМАНИЕ!|r В Вашей группе/гильдии обнаружена более новая версия аддона |cff00ff00'RaidAchievement'|r, рекомендуется скачать обновление с curse.com или wowinterface.com"


end



function psealocaleui()

psealeftmenu1				= "Аддон"
psealeftmenu3				= "Наксрамас"
psealeftmenu31				= "Наксрамас + остальные мини рейды WotLK"
psealeftmenu4				= "Wotlk Подземелья"
psealeftmenu5				= "Ульдуар"
psealeftmenu6				= "Цитадель"
pseareports				= "- канал для отправки сообщений"
PSFeaserver				= "ru-Гордунни"
pseauinomodule1				= "    Ошибка! Модуль не установлен!"
pseauinomodule2				= "Произошла ошибка! Выбранный Вами модуль не установлен!"
pseauierror				= "    Ошибка!"
pseauierroraddonoff			= "Ошибка! Аддон отключен - данный модуль не доступен!"
pseapsaddonanet				= "Ошибка! Аддон PhoenixStyle не установлен"
pseapsaddonanet2			= "Вы можете скачать его с сайтов curse.com или wowinterface.com"
pseaenableall				= "Включить все"
pseadisableall				= "Отключить все"
pseachangeall				= "Переключить"
pseawebsite				= "www.blacklotus.ru & www.phoenix-wow.ru"
pseashownames				= "Отображать причину провала достижений (имена, и тп)"
pseashowveren				= "Отображать сообщ. при обнаружении более новой версии аддона в гильдии/группе"
psealeftmenu11				= "Многократный анонс"
pseamanyachtitle			= "    Многократная проверка достижений"
ramanyachtitinfo			= "При провале достижения - его повторная проверка блокируется до конца боя. Данный модуль отменяет эту блокировку. Обнуление происходит через "
ramanyachtitinfo2			= "после сообщ. о провале. Установите количество обнулений на один бой и включите модуль, для того чтобы видеть сколько раз за бой вы провалите достижение. Данный модуль отключится при выходе из игры."
psbuttonon				= "Включить"
psbuttonoff				= "Отключить"
psmoduletxton				= "модуль включен"
psmoduletxtoff				= "модуль отключен"
pssec					= "сек."
ramanyachtitinfoq			= "Сброс блокировки отслеживания достижений будет происходить "
ramanyachtitinfoq2			= "раз за бой. Изменить:"
ramodulnotblock				= "проверка не блокируется"
psoldvertxt				= "(устаревшая)"


end





end