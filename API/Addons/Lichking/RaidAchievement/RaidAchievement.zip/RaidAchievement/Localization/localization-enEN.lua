﻿

function psealocalezone()
pseaheroicslist				= "Ahn'kahet: The Old Kingdom,Drak'Tharon Keep,Gundrak,Halls of Lightning,Halls of Stone,The Nexus,Utgarde Pinnacle,The Violet Hold,Trial of the Champion,The Forge of Souls,Pit of Saron,Halls of Reflection"
pseaheroicslist2			= "Azjol-Nerub"
pseazoneulduar				= "Ulduar"
pseazonenax				= "Naxxramas"
pseazonesart				= "The Obsidian Sanctum"
pseazoneonya				= "Onyxia's Lair"
pseazoneic				= "Icecrown Citadel"

end


function psealocale()


pseachatlist1				= "raid"
pseachatlist2				= "raid warning"
pseachatlist3				= "officer"
pseachatlist4				= "party"
pseachatlist5				= "guild"
pseachatlist6				= "say"
pseachatlist7				= "yell"
pseachatlist8				= "self only"
pseaaddonmy				= "AddOn"
pseaaddonon2				= "ON"
pseaaddonoff				= "OFF"
pseamoduleload				= "Loaded module:"
pseamodulenotload			= "Error while loading module:"
pseaaddonon				= "enable addon"
pseaaddonok				= "OK"
pseatreb2				= "requests are completed! Kill boss now!"
pseatreb4				= "failed!"
ranewversfound				= "|cff00ff00Attention!|r New version of |cff00ff00'RaidAchievement'|r addon was found in your party/guild, it's recommended to update it from curse.com or wowinterface.com"


end



function psealocaleui()

psealeftmenu1				= "AddOn"
psealeftmenu3				= "Naxxramas"
psealeftmenu31				= "Naxxramas + other mini WotLK raids"
psealeftmenu4				= "Wotlk Heroics"
psealeftmenu5				= "Ulduar"
psealeftmenu6				= "Icecrown"
pseareports				= "- chat channel to announce warnings"
PSFeaserver				= "ru-Gordunni"
pseauinomodule1				= "    Error! Module is not installed!"
pseauinomodule2				= "Error! Module that you choose is not installed!"
pseauierror				= "    Error!"
pseauierroraddonoff			= "Error! Addon is disabled - this module is not loaded!"
pseapsaddonanet				= "Error! Addon PhoenixStyle is not installed"
pseapsaddonanet2			= "You can download it on curse.com or wowinterface.com"
pseaenableall				= "Enable all"
pseadisableall				= "Disable all"
pseachangeall				= "Switch"
pseawebsite				= "www.blacklotus.ru"
pseashownames				= "show the reason (name, etc) of achievement's fail"
pseashowveren				= "Show msg when a new version of the addon was found in your guild/party"
psealeftmenu11				= "Track after fail"
pseamanyachtitle			= "    Continue tracking achivements after its fail"
ramanyachtitinfo			= "When achievement is failed - it tracking is blocking for the current fight. This module rezet this block. Rezet occurs in "
ramanyachtitinfo2			= "after 'fail message'. Set how much rezets for the fight do you want and click 'start' module. This module is autodisabled after logout."
psbuttonon				= "Start"
psbuttonoff				= "STOP"
psmoduletxton				= "module is enabled"
psmoduletxtoff				= "module is disabled"
pssec					= "sec."
ramanyachtitinfoq			= "Rezet will occurs "
ramanyachtitinfoq2			= "times for the fight. Change:"
ramodulnotblock				= "track wouldn't block"
psoldvertxt				= "(old version)"


end





