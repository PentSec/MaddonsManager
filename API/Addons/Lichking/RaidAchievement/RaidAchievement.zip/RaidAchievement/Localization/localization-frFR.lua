﻿if GetLocale() == "frFR" then

function psealocalezone()
pseaheroicslist				= "Ahn'kahet : l'Ancien royaume,Donjon de Drak'Tharon,Gundrak,Les salles de Foudre,Les salles de Pierre,Le Nexus,Cime d'Utgarde,Le fort Pourpre,L'épreuve du champion,La Forge des âmes,Fosse de Saron,Salles des Reflets"
pseaheroicslist2			= "Azjol-Nérub"
pseazoneulduar				= "Ulduar"
pseazonenax				= "Naxxramas"
pseazonesart				= "Le sanctum Obsidien"
pseazoneonya				= "Repaire d'Onyxia"
pseazoneic				= "Citadelle de la Couronne de glace"

end



end