﻿if GetLocale() == "koKR" then

function psealocalezone()
pseaheroicslist				= "안카헤트: 고대 왕국,드락타론 성채,군드락,번개의 전당,돌의 전당,마력의 탑,우트가드 첨탑,보랏빛 요새,용사의 시험장,영혼의 제련소,사론의 구덩이,투영의 전당"
pseaheroicslist2			= "아졸네룹"
pseazoneulduar				= "울두아르"
pseazonenax				= "낙스라마스"
pseazonesart				= "흑요석 성소"
pseazoneonya				= "오닉시아의 둥지"
pseazoneic				= "얼음왕관 성채"

end



end