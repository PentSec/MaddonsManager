﻿if GetLocale() == "esES" then

function psealocalezone()
pseaheroicslist				= "Ahn'kahlet: El antiguo Reino,Fortaleza de Drak'Tharon,Gundrak,Cámaras de Relampagos,Cámaras de Piedra,El Nexo,Pináculo de Utgarde,El Bastión Violeta,Prueba del Campeón,La Forja de Almas,Foso de Saron,Cámaras de Reflexión"
pseaheroicslist2			= "Azjol-Nerub"
pseazoneulduar				= "Ulduar"
pseazonenax				= "Naxxramas"
pseazonesart				= "El Sagrario Obsidiana"
pseazoneonya				= "Guarida de Onyxia"
pseazoneic				= "Ciudadela de la Corona de Hielo"

end



end