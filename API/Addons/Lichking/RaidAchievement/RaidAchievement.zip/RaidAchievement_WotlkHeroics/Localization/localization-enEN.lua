﻿

function whralocaleboss()

whraanka1				= "Ahn'kahar Guardian"
whraanka2				= "Twilight Volunteer"
whradeathkn				= "The Black Knight"
whrabrann				= "Brann Bronzebeard"
whrabrannemo				= "you want to play hardball"
whrabrannemo2				= "safes deactivated. Beginning memory purge and"
whragundemo				= "gonna spill your guts"
whravioletadd				= "Void Sentry"
whradred				= "King Dred"
whralit					= "Sjonnir The Ironshaper"
whradredadd1				= "Drakkari Scytheclaw"
whradredadd2				= "Drakkari Gutripper"
whralitadd				= "Iron Sludge"
whranexadd1				= "Chaotic Rift"
whrabronjaadd				= "Corrupted Soul Fragment"
whrabronjahm				= "Bronjahm"


end



function whralocale()

whraaddkilled1				= "Add was killed!"
whraaddkilled2				= "will not be complete if you kill boss now!"

end



function whralocaleui()

whratitle				= "    Wotlk Heroics"



end