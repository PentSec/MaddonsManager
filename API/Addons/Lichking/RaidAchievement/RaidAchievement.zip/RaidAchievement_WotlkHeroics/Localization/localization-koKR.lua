﻿if GetLocale() == "esES" then

function whralocaleboss()

whraanka1				= "안카하르 수호자"
whraanka2				= "황혼의 지원병"
whradeathkn				= "흑기사"
whrabrann				= "브란 브론즈비어드"
whrabrannemo				= "you want to play hardball"
whrabrannemo2				= "safes deactivated. Beginning memory purge and"
whragundemo				= "gonna spill your guts"
whravioletadd				= "Void Sentry"
whradred				= "랩터왕 서슬발톱"
whralit					= "무쇠구체자 쇼니르"
whradredadd1				= "드라카리 갈퀴발톱 랩터"
whradredadd2				= "드라카리 학살자"
whralitadd				= "Iron Sludge"
whranexadd1				= "혼돈의 균열"
whrabronjaadd				= "Corrupted Soul Fragment"
whrabronjahm				= "브론잠"


end



end