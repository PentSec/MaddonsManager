﻿if GetLocale() == "deDE" then

function whralocaleboss()

whraanka1				= "W\195\164chter der Ahn'kahar"
whraanka2				= "Freiwilliger des Schattenhammers"
whradeathkn				= "Der Schwarze Ritter"
whrabrann				= "Brann Bronzebart"
whrabrannemo				= "you want to play hardball"
whrabrannemo2				= "safes deactivated. Beginning memory purge and"
whragundemo				= "gonna spill your guts"
whravioletadd				= "Leerenwache"
whradred				= "K\195\182nig Dred"
whralit					= "Sjonnir der Eisenformer"
whradredadd1				= "Sichelkla\195\188 der Drakkari"
whradredadd2				= "Magenfetzer der Drakkari"
whralitadd				= "Eisenschlacke"
whranexadd1				= "Chaotischer Riss"
whrabronjaadd				= "Korrumpiertes Seelenfragment"
whrabronjahm				= "Bronjahm"


end



function whralocale()

whraaddkilled1				= "Mob ist vernichtet!"
whraaddkilled2				= "Es wird nicht erf\195\188llt, wenn der Boss vernichtet wird!"

end



function whralocaleui()

whratitle				= "    Wotlk Instanzen"



end



end