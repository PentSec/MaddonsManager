﻿if GetLocale() == "frFR" then

function whralocaleboss()

whraanka1				= "Gardien ahn'kahar"
whraanka2				= "Volontaire du crépuscule"
whradeathkn				= "Le Chevalier noir"
whrabrann				= "Brann Barbe-de-bronze"
whrabrannemo				= "you want to play hardball"
whrabrannemo2				= "safes deactivated. Beginning memory purge and"
whragundemo				= "gonna spill your guts"
whravioletadd				= "Factionnaire du Vide"
whradred				= "Roi Dred"
whralit					= "Sjonnir le Sculptefer"
whradredadd1				= "Faucheur drakkari"
whradredadd2				= "Arrache-tripes drakkari"
whralitadd				= "Vase de fer"
whranexadd1				= "Faille chaotique"
whrabronjaadd				= "Fragment d'âme corrompue"
whrabronjahm				= "Bronjahm"


end



end