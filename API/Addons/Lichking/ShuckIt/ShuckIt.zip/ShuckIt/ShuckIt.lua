﻿-- ShuckIt.lua
-- $Id: ShuckIt.lua 32 2010-07-20 11:29:52Z LaoTseu $

-- The ShuckIt idea came from the Shucks module from Cork (http://www.wowinterface.com/downloads/info10629) by Tekkub.
-- The basic framework for this addon is based on Tekkub's AddonTemplate (http://github.com/tekkub/addontemplate/tree/master)
-- The code to find the openable items is based on Ammo's work in 
-- CrowBar (http://www.wowace.com/addons/crow-bar/) and is used with his permission.


ShuckIt = ShuckIt or {}
ShuckIt.revision = ShuckIt.revision or {} 
ShuckIt.revision.main	= ("$Revision: 32 $"):match("(%d+)")
ShuckIt.version      	= GetAddOnMetadata("ShuckIt", "Version"):match("([^ ]+)")
ShuckIt.revision.toc  	= GetAddOnMetadata("ShuckIt", "Version"):match("%$Revision:%s(%d+)")

----------------------
--      Locals      --
----------------------

local L = ShuckIt.localized
--local defaults, defaultsPC, db, dbpc = {}, {}
local UPDATEPERIOD, elapsed = 0.5, 0
local TOOLTIPPERIOD, tooltip_elapsed = 0.2, 0
local need_scan, need_chat_update, busy, delay_scan = nil, nil, nil, nil

local item_to_shuck, icon, shuck_count = nil, nil, 0
-- I'm creating three tables because I don't want to deal with recycling sub-table
-- The ideal data type would have been a table of triplets { itemID, bag, slot }
local shuck_table = {}
local shuck_table_bag = {}
local shuck_table_slot = {}
local shuck_bag, shuck_slot = 1, 1
local default_icon = "Interface\\Icons\\INV_Misc_Shell_03"

local secureframe

local lqt = LibStub("LibQTip-1.0")
local ldb = LibStub:GetLibrary("LibDataBroker-1.1")
local dataobj = ldb:NewDataObject("ShuckIt", 
											 {
												type = "data source", 
											  	text = "",
											  	icon = default_icon
})


------------------------------
--      Util Functions      --
------------------------------

local default_channel = nil
local function setDefaultChanelForPrint()
	default_channel = nil
	for i=1, NUM_CHAT_WINDOWS do
		local name = GetChatWindowInfo(i)
		if name and strlower(name) == 'output' then
			default_channel = i
		end
	end
end

local function Print(message, ...) 
	if default_channel then
		_G["ChatFrame"..default_channel]:AddMessage(format("|cff00dbba"..L["ShuckIt"].."|r: "..message, ...));
	else
		SELECTED_CHAT_FRAME:AddMessage(format("|cff00dbba"..L["ShuckIt"].."|r: "..message, ...))
	end
end

local debugf = tekDebug and tekDebug:GetFrame("ShuckIt")
local function Debug(...) if debugf then debugf:AddMessage(string.join(", ", ...)) end end

------------------------------
--      Core Functions     --
------------------------------

CreateFrame("GameTooltip", "ShuckItTooltip")
ShuckItTooltip:SetOwner(WorldFrame, "ANCHOR_NONE")

ShuckItTooltip:AddFontStrings(
    ShuckItTooltip:CreateFontString( "$parentTextLeft1", nil, "GameTooltipText" ),
    ShuckItTooltip:CreateFontString( "$parentTextRight1", nil, "GameTooltipText" )
)

local cache = {}
local do_not_cache = {}
SunkIt_cache = cache
SunkIt_dnc = do_not_cache
local function IsOpenable(bag, slot, itemLink)
	--local _,_,itemID = string.find(itemLink, "^[|]c%x+[|]H[^:]+[:]([^:]+)[:].*[|]h%[.+%]")
	--local found,_,itemID = string.find(itemLink, "item[:](%d+)[:]")

	--assert(found,"No itemID: " .. gsub(itemLink, "\124", "\124\124"))
	
	if not bag or not slot then return false end
	if not itemLink then itemLink = GetContainerItemLink(bag, slot) end
	if not itemLink then return false end -- Bag slot empty
	
	local debug = false
	local name = GetItemInfo(itemLink)
	
	if name and name == "Reinforced Junkbox" then
		debug = true
	end
	
	if cache[itemLink] ~= nil then return cache[itemLink] end
	
	ShuckItTooltip:ClearLines()
	if not ShuckItTooltip:IsOwned(WorldFrame) then ShuckItTooltip:SetOwner(WorldFrame, "ANCHOR_NONE") end
 	ShuckItTooltip:SetBagItem(bag,slot)
	
	for i=1,ShuckItTooltip:NumLines() do
	   -- local mytext = getglobal("ShuckItTooltipTextLeft" .. i)
	   local mytext = _G["ShuckItTooltipTextLeft" .. i]
	   local text = mytext:GetText()
	   
	   if debug then
	   	Print("text = [%s]",text)
	   end

		if (text == ITEM_OPENABLE) then
			if not do_not_cache[itemLink] then cache[itemLink] = true end
			return true
		elseif text == LOCKED then
			-- Do not cache the result for locked items, they may become unlocked
			do_not_cache[itemLink] = true
			return false
		end
	end
	
	cache[itemLink] = false
	return false

end

local cache_clam = {}
local function IsAClam(bag, slot, itemLink)
	if not bag or not slot then return false end
	if not itemLink then itemLink = GetContainerItemLink(bag, slot) end
	if not itemLink then return false end -- Bag slot empty

	if cache_clam[itemLink] ~= nil then return cache_clam[itemLink] end
	
	ShuckItTooltip:ClearLines()
	if not ShuckItTooltip:IsOwned(WorldFrame) then ShuckItTooltip:SetOwner(WorldFrame, "ANCHOR_NONE") end
 	ShuckItTooltip:SetBagItem(bag,slot)

	for i=1,ShuckItTooltip:NumLines() do
	   --local mytext = getglobal("ShuckItTooltipTextLeft" .. i)
	   local mytext = _G["ShuckItTooltipTextLeft" .. i]
	   local text = mytext:GetText()

		if (text == L["Use: Open the clam!"]) then
			cache_clam[itemLink] = true
			return true
		end
	end
	
	cache_clam[itemLink] = false
	return false

end

local function ScanBags()

	item_to_shuck, shuck_bag, shuck_slot = nil, nil, nil
	shuck_count = 0
	for k in pairs(shuck_table) do shuck_table[k] = nil end
	for k in pairs(shuck_table_bag) do shuck_table_bag[k] = nil end
	for k in pairs(shuck_table_slot) do shuck_table_slot[k] = nil end

	local newIcon = nil
	for bag = 0, 4, 1 do
		for slot = 1, GetContainerNumSlots(bag), 1 do

			local itemLink = GetContainerItemLink(bag, slot)
			if itemLink and (IsOpenable(bag, slot, itemLink) or IsAClam(bag, slot, itemLink)) then
				local _,_,itemID = string.find(itemLink, "item[:](%d+)[:]")
				shuck_table[itemID] = (shuck_table[itemID] or 0) + tonumber(select(2,GetContainerItemInfo(bag, slot)) or 1)
				-- we keep the bag and slot for the first item we find
				shuck_table_bag[itemID] = shuck_table_bag[itemID] or bag
				shuck_table_slot[itemID] = shuck_table_slot[itemID] or slot
				if not item_to_shuck then
					item_to_shuck = GetItemInfo(itemLink)
					shuck_bag, shuck_slot = bag, slot
					newIcon = GetContainerItemInfo(bag, slot)
				end
			elseif itemLink and not GetItemInfo(itemLink) then
				-- This is a workaround for a intermitend situation when opening
				-- multiple items of the same kind in a row sometimes result in
				-- the item information being screewed up.
				-- If this happen, we delay de scan until the information is realiable
				delay_scan = true
				return
			end

		end
	end
	
	for k in pairs (shuck_table) do
		shuck_count = shuck_count + shuck_table[k]
	end
	icon = newIcon or default_icon
	need_scan = nil
end

local function myOnClick(self, button, down) 
	if not InCombatLockdown() and not IsStealthed() and not busy and IsOpenable(shuck_bag, shuck_slot) then
		UseContainerItem(shuck_bag, shuck_slot)
		return true
	elseif not InCombatLockdown() and not IsStealthed() and not busy and IsAClam(shuck_bag, shuck_slot) then
		Print(L["Cannot open Clams by clicking on the LDB display. Use %s instead."],"|cffffd700/click ShuckItFrame|r")
	else
		return false
	end
end

-----------------------------
--      Event Handler      --
-----------------------------

local f = CreateFrame("frame")
f:SetScript("OnEvent", function(self, event, ...) if self[event] then return self[event](self, event, ...) end end)
f:RegisterEvent("ADDON_LOADED")


function f:ADDON_LOADED(event, addon)
	if addon ~= "ShuckIt" then return end

	--AddonTemplateDB, AddonTemplateDBPC = setmetatable(AddonTemplateDB or {}, {__index = defaults}), setmetatable(AddonTemplateDBPC or {}, {__index = defaultsPC})
	--db, dbpc = AddonTemplateDB, AddonTemplateDBPC

	-- Do anything you need to do after addon has loaded

	--LibStub("tekKonfig-AboutPanel").new("ShuckIt", "ShuckIt") -- Remove first arg if no parent config panel

	self:UnregisterEvent("ADDON_LOADED")
	self.ADDON_LOADED = nil

	if IsLoggedIn() then self:PLAYER_LOGIN() else self:RegisterEvent("PLAYER_LOGIN") end
end


function f:PLAYER_LOGIN()
	self:RegisterEvent("PLAYER_LOGOUT")

	-- Register events
	self:RegisterEvent("BAG_UPDATE")
	self:RegisterEvent("UNIT_SPELLCAST_SENT")
	self:RegisterEvent("UNIT_SPELLCAST_FAILED")
	self:RegisterEvent("UNIT_SPELLCAST_STOP")
	self:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
	self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
	self:RegisterEvent("UPDATE_CHAT_WINDOWS")

	-- Start the OnUpdate 
	self:SetScript("OnUpdate", function(self, elap)
		elapsed = elapsed + elap
		tooltip_elapsed = tooltip_elapsed + elap
		
		-- Tooltip management
		if tooltip_elapsed >= TOOLTIPPERIOD then
			tooltip_elapsed = 0
			if not (ShuckIt.tooltip and ShuckIt.tooltip:IsMouseOver()) and 
				not (ShuckIt.tooltip_anchor and ShuckIt.tooltip_anchor:IsMouseOver()) then
				ShuckIt.tooltip = lqt:Release(ShuckIt.tooltip)
				ShuckIt.tooltip_anchor = nil
			end
		end
		
		if delay_scan then 
			-- Workaround for when good item information is not available and we
			-- need to wait a bit
			elapsed = UPDATEPERIOD/2
			need_scan = true
			delay_scan = nil
			return
		end
		
		if not (need_scan or need_chat_update) or busy or elapsed < UPDATEPERIOD or InCombatLockdown() then return end

		elapsed = 0
		
		-- Print window if needed
		if need_chat_update then
			setDefaultChanelForPrint()
			need_chat_update = nil
		end

		-- Find object to Shuck
		ScanBags()
		
		-- Adjust the display
		if shuck_count > 0 then
			dataobj.text = string.format(L["%s - %d"], item_to_shuck, shuck_count)
		else
			dataobj.text = ""
		end
		dataobj.icon = icon
		
		-- Update the Tooltip
		if ShuckIt.tooltip then ShuckIt:DrawTooltip() end
	end)
	
	-- Set the OnClick function for the data broker
	dataobj.OnClick = myOnClick
	
	-- Find the revision number
	if ShuckIt.revision then
		ShuckIt.rev = 0
		for _, rev in pairs(ShuckIt.revision) do
			local revision = tonumber(rev)
			if revision and revision > ShuckIt.rev then ShuckIt.rev = revision end
		end
	else
		assert(false,"No ShuckIt.revision")
	end

	-- Find the default channel
	setDefaultChanelForPrint()
	
	need_scan = true

	self:UnregisterEvent("PLAYER_LOGIN")
	self.PLAYER_LOGIN = nil
end


function f:PLAYER_LOGOUT()
	--for i,v in pairs(defaults) do if db[i] == v then db[i] = nil end end
	--for i,v in pairs(defaultsPC) do if dbpc[i] == v then dbpc[i] = nil end end

	-- Do anything you need to do as the player logs out
end

function f:BAG_UPDATE(bagID)
	elapsed = 0 -- Let's wait a bit
	need_scan = true
end

function f:UNIT_SPELLCAST_SENT(event, unit, spell, rank, target)
	busy = true
end

function f:UNIT_SPELLCAST_FAILED(event, unit, spell, rank)
	busy = nil
end

function f:UNIT_SPELLCAST_STOP(event, unit, spell, rank)
	busy = nil
end

function f:UNIT_SPELLCAST_INTERRUPTED(event, unit, spell, rank)
	busy = nil
end

local lock_picking_spell = GetSpellInfo(1804)
function f:UNIT_SPELLCAST_SUCCEEDED(event, unit, spell, rank)
	busy = nil
	if unit == "player" and spell == lock_picking_spell then
		-- A something just got unlocked, it can be opened
		elapsed = -UPDATEPERIOD -- Let's wait a bit
		need_scan = true
		--Print("Something was unlocked")
	end
end

function f:UPDATE_CHAT_WINDOWS()
	need_chat_update = true
end


-----------------------------
--      Slash Handler      --
-----------------------------

SLASH_ADDONTEMPLATE1 = "/shuckit"
SlashCmdList.ADDONTEMPLATE = function(msg)
	Print(L["Use %s to open the next item"],"|cffffd700/click ShuckItFrame|r")
end

------------------------------
--   Secure Cell Provider   --
------------------------------

local cellPrototype = {}
setmetatable(cellPrototype, { __index = function(table,index)
	local button = CreateFrame("Button", "ShuckItMeta"..index, UIParent, "SecureActionButtonTemplate") 
	rawset( table, index, button )
	return button
end})

local highlight = CreateFrame("Frame", "ShuckItHightlight", UIParent)
highlight:SetFrameStrata("TOOLTIP")
highlight:SetAlpha(1)
highlight:Hide()

highlight._texture = highlight:CreateTexture(nil, "OVERLAY")
highlight._texture:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
highlight._texture:SetBlendMode("ADD")
highlight._texture:SetAllPoints(highlight)

function cellPrototype:InitializeCell()
	self:SetScript("PreClick", function(frame)
		if InCombatLockdown() or IsStealthed() or busy or 
				(not IsOpenable(shuck_bag, shuck_slot) and not IsAClam(shuck_bag, shuck_slot)) then 
			Print(L["Nothing to do or in combat"])
			return 
		end
		frame:SetAttribute( "type1", "macro" )
		frame:SetAttribute( "macrotext1", "/use "..self.bag.." "..self.slot)
	end)
	
	self:SetScript("PostClick", function(frame)
		if InCombatLockdown() then return end
		frame:SetAttribute( "type1", ATTRIBUTE_NOOP )
		frame:SetAttribute( "macrotext1", nil)
	end)
	
	self:SetScript("OnEnter", function(frame, ...)
		highlight:SetParent(frame)
		highlight:SetAllPoints(frame)
		highlight:Show()
	end)

	self:SetScript("OnLeave", function(frame, ...)
		highlight:Hide()
		highlight:ClearAllPoints()
		highlight:SetParent(nil)
	end)

end


function cellPrototype:SetupCell(tooltip, value, justification, font, itemLink, bag, slot, lPad, rPad, maxWidth, minWidth)
	-- ShuckIt part
	self.itemLink 	= itemLink
	self.bag 		= bag
	self.slot 		= slot
	
	-- Qtip part
	local fs = self.fontString
	fs:SetFontObject(font or tooltip:GetFont())
	fs:SetJustifyH(justification)
	fs:SetText(tostring(value))

	l_pad = l_pad or 0
	r_pad = r_pad or 0

	local width = fs:GetStringWidth() + l_pad + r_pad

	fs:SetPoint("TOPLEFT", self, "TOPLEFT", l_pad, 0)
	fs:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", -r_pad, 0)

	if max_width and min_width and (max_width < min_width) then
		error("maximum width cannot be lower than minimum width: "..tostring(max_width).." < "..tostring(min_width), 2)
	end
	if min_width and width < min_width then	width = min_width end
	if max_width and max_width < width then	width = max_width end

	fs:SetWidth(width)
	fs:Show()

	return width, fs:GetHeight()
end

function cellPrototype:CleanupCell()
	self.itemLink 	= nil
	self.bag 		= nil
	self.slot 		= nil
	
	self:SetScript("PreClick", nil)
	self:SetScript("PostClick", nil)
	self:SetScript("OnEnter", nil)
	self:SetScript("OnLeave", nil)
	self:Hide()
end

ShuckItProvider = {
	heap = {},
	cellPrototype = cellPrototype,
	cellMetatable = { __index = cellPrototype }
}

function ShuckItProvider:AcquireCell(tooltip)
	geterrorhandler()(format("AcquireCell: %d",#self.heap))
	--local cell = table.remove(self.heap)
	self.cell = table.remove(self.heap)
	if not self.cell then
		local cell_name = "ShuckItSecureButtonHeap"..tostring(#self.heap)
		self.cell = setmetatable(CreateFrame("Button", cell_name, UIParent, "SecureActionButtonTemplate"), self.cellMetatable)
		self.cell:InitializeCell()
	end
	return self.cell
end

function ShuckItProvider:ReleaseCell(cell)
	cell:CleanupCell()
	table.insert(self.heap, cell)
end

function ShuckItProvider:GetCellPrototype()
	return self.cellPrototype, self.cellMetatable
end

-----------------------------
--        LDB Stuff        --
-----------------------------

-- Sort function
local function sort_by_item_name (a,b)
	local name_a = GetItemInfo(a)
	local name_b = GetItemInfo(b)
	return name_a < name_b
end


local index = {}
function ShuckIt:DrawTooltip(anchor)
	self.tooltip_anchor = anchor or self.tooltip_anchor
	
	if not self.tooltip then
		self.tooltip = lqt:Acquire("ShuckItTooltip", 1, "LEFT")
	end
	local tooltip = self.tooltip

	tooltip:Clear()
	tooltip:SmartAnchorTo(self.tooltip_anchor)
	tooltip:SetScale(1)
	
	local line, column = tooltip:AddHeader()
	tooltip:SetCell(line, 1, format("|cffffd700%s v%s (r%d)|r", L["ShuckIt"], ShuckIt.version, ShuckIt.rev), "CENTER", 1)
	
	-- clean index
	for key in pairs(index) do index[key] = nil end
	
	-- Sort by item name
	for key in pairs(shuck_table) do tinsert(index,key) end
	sort(index, sort_by_item_name)

	if #index > 0 then
		line, column = tooltip:AddHeader()
		local item = L["item"]
		if shuck_count > 1 then item = L["items"] end
		tooltip:SetCell(line, 1, format(L["|cffffd700%d %s to open|r"],shuck_count,item), "CENTER", 1)
		tooltip:AddSeparator()
	end

	for _, link in ipairs (index) do
		local count = shuck_table[link]
		local name, _, _, _, _, _, _, _, _, texture = GetItemInfo(link)
		
		line, column = tooltip:AddLine()
		tooltip:SetCell(line, 1, format(L["|T%s:16|t %s x %d"],
												  texture,
												  name,
												  count
										 ), "LEFT")
		tooltip:SetCellScript(line, column, "OnMouseUp", function() 
			if not InCombatLockdown() and not IsStealthed() and not busy and IsOpenable(shuck_table_bag[link], shuck_table_slot[link]) then
				UseContainerItem(shuck_table_bag[link], shuck_table_slot[link])
				return true
			elseif not InCombatLockdown() and not IsStealthed() and not busy and IsAClam(shuck_table_bag[link], shuck_table_slot[link]) then
				Print(L["Cannot open Clams by clicking on the LDB display. Use %s instead."], "|cffffd700/click ShuckItFrame|r")
			end
 		end)
 		--[[
		geterrorhandler()("Before SetCell")
		tooltip:SetCell(line, 1, format(L["|T%s:16|t %s x %d -- (B=%d, S=%d)"],
												  texture,
												  name,
												  count,
												  shuck_table_bag[link],
												  shuck_table_slot[link]
										 ), "LEFT", 1, ShuckItProvider, link, shuck_table_bag[link], shuck_table_slot[link])
		]]--
	end
	
	tooltip:Show()

end

function dataobj:OnEnter(motion)
	ShuckIt:DrawTooltip(self)
	tooltip_elapsed = 0
end

function dataobj:OnLeave()
   --lqt:Release(ShuckIt.tooltip)
   --ShuckIt.tooltip = nil
end

----------------------------
--      Secure frame      --
----------------------------

secureframe = CreateFrame("Button", "ShuckItFrame", UIParent, "SecureActionButtonTemplate")

secureframe:SetScript("PreClick", function(self)
	if InCombatLockdown() or IsStealthed() or busy or 
			(not IsOpenable(shuck_bag, shuck_slot) and not IsAClam(shuck_bag, shuck_slot)) then 
		Print(L["Nothing to do or in combat"])
		return 
	end
	self:SetAttribute( "type1", "macro" )
	self:SetAttribute( "macrotext1", "/use "..shuck_bag.." "..shuck_slot)
end)


secureframe:SetScript("PostClick", function(self)
	if InCombatLockdown() then return end
	self:SetAttribute( "type1", ATTRIBUTE_NOOP )
	self:SetAttribute( "macrotext1", nil)
end)

