﻿-- $Id: Localization.lua 30 2010-03-02 15:30:24Z LaoTseu $

-- Code borrowed from Tekkub

ShuckIt = ShuckIt or {}
ShuckIt.revision = ShuckIt.revision or {} 
ShuckIt.revision.loc	= ("$Revision: 30 $"):match("(%d+)")

local localized
local loc = GetLocale()

-----------------------
--      English      --
-----------------------

local english = {}
 
----------------------
--      French      --
----------------------

if loc == "frFR" then 

localized = {}
localized["Cannot open Clams by clicking on the LDB display. Use %s instead."] = "Impossible d'ouvrir des palourdes en cliquant sur l'écran LDB. Utiliser %s à la place."
localized["|cffffd700%d %s to open|r"] = "|cffffd700%d %s à ouvrir|r"
localized["item"] = "objet"
localized["items"] = "objets"
localized["Nothing to do or in combat"] = "Rien à faire ou en combat"
localized["Open those clams (and other containers)"] = "Ouvrez ces palourdes (et autres containers)"
localized["%s - %d"] = "%s - %d"
localized["ShuckIt"] = "ShuckIt"
localized["|T%s:16|t %s x %d"] = "|T%s:16|t %s x %d"
localized["Use: Open the clam!"] = "Utiliser: Ouvrez la palourde!"
localized["Use %s to open the next item"] = "Utilisez %s pour ouvrir le prochain objet"


end

----------------------
--      German      --
----------------------

if loc == "deDE" then 

localized = {}
localized["Cannot open Clams by clicking on the LDB display. Use %s instead."] = "Muscheln können nicht durch Klick auf das LDB geöffnet werden. Benutze stattdessen %s."
localized["|cffffd700%d %s to open|r"] = "|cffffd700%d %s zu öffnen|r"
localized["item"] = "Gegenstand"
localized["items"] = "Gegenstände"
localized["Nothing to do or in combat"] = "Nichts zu tun oder im Kampf"
localized["Open those clams (and other containers)"] = "Öffne Muscheln (und andere Behälter)"
-- localized["%s - %d"] = ""
-- localized["ShuckIt"] = ""
-- localized["|T%s:16|t %s x %d"] = ""
localized["Use: Open the clam!"] = "Benutzen: Öffnet die Muschel!"
localized["Use %s to open the next item"] = "Nutze %s, um den nächsten Gegenstand zu öffnen"


end

----------------------
--      Spanish     --
----------------------

if loc == "esES" then 

localized = {}
-- localized["Cannot open Clams by clicking on the LDB display. Use %s instead."] = ""
-- localized["|cffffd700%d %s to open|r"] = ""
-- localized["item"] = ""
-- localized["items"] = ""
-- localized["Nothing to do or in combat"] = ""
-- localized["Open those clams (and other containers)"] = ""
-- localized["%s - %d"] = ""
-- localized["ShuckIt"] = ""
-- localized["|T%s:16|t %s x %d"] = ""
localized["Use: Open the clam!"] = "Uso: Â¡Abre la almeja!"
-- localized["Use %s to open the next item"] = ""


end

----------------------------
-- Latin American Spanish --
----------------------------

if loc == "esMX" then 

localized = {}
-- Little hack to use esES translation if a phrase doesn't exist in esMX
-- localized["Cannot open Clams by clicking on the LDB display. Use %s instead."] = ""
-- localized["|cffffd700%d %s to open|r"] = ""
-- localized["item"] = ""
-- localized["items"] = ""
-- localized["Nothing to do or in combat"] = ""
-- localized["Open those clams (and other containers)"] = ""
-- localized["%s - %d"] = ""
-- localized["ShuckIt"] = ""
-- localized["|T%s:16|t %s x %d"] = ""
localized["Use: Open the clam!"] = "Uso: Â¡Abre la almeja!"
-- localized["Use %s to open the next item"] = ""

-- localized["Cannot open Clams by clicking on the LDB display. Use %s instead."] = ""
-- localized["|cffffd700%d %s to open|r"] = ""
-- localized["item"] = ""
-- localized["items"] = ""
-- localized["Nothing to do or in combat"] = ""
-- localized["Open those clams (and other containers)"] = ""
-- localized["%s - %d"] = ""
-- localized["ShuckIt"] = ""
-- localized["|T%s:16|t %s x %d"] = ""
-- localized["Use: Open the clam!"] = ""
-- localized["Use %s to open the next item"] = ""


end

----------------------
--      Rusian      --
----------------------

if loc == "ruRU" then 

localized = {}
-- localized["Cannot open Clams by clicking on the LDB display. Use %s instead."] = ""
-- localized["|cffffd700%d %s to open|r"] = ""
-- localized["item"] = ""
-- localized["items"] = ""
-- localized["Nothing to do or in combat"] = ""
-- localized["Open those clams (and other containers)"] = ""
-- localized["%s - %d"] = ""
-- localized["ShuckIt"] = ""
-- localized["|T%s:16|t %s x %d"] = ""
localized["Use: Open the clam!"] = "\208\152\209\129\208\191\208\190\208\187\209\140\208\183\208\190\208\178\208\176\208\189\208\184\208\181: \208\158\209\130\208\186\209\128\208\190\208\185 \209\128\208\176\208\186\208\190\208\178\208\184\208\189\209\131!"
-- localized["Use %s to open the next item"] = ""


end

----------------------
--      Korean      --
----------------------

if loc == "koKR" then 

localized = {}
-- localized["Cannot open Clams by clicking on the LDB display. Use %s instead."] = ""
-- localized["|cffffd700%d %s to open|r"] = ""
-- localized["item"] = ""
-- localized["items"] = ""
-- localized["Nothing to do or in combat"] = ""
-- localized["Open those clams (and other containers)"] = ""
-- localized["%s - %d"] = ""
-- localized["ShuckIt"] = ""
-- localized["|T%s:16|t %s x %d"] = ""
-- localized["Use: Open the clam!"] = ""
-- localized["Use %s to open the next item"] = ""


end

------------------------
-- Simplified Chinese --
------------------------

if loc == "zhCN" then 

localized = {}
-- localized["Cannot open Clams by clicking on the LDB display. Use %s instead."] = ""
-- localized["|cffffd700%d %s to open|r"] = ""
-- localized["item"] = ""
-- localized["items"] = ""
-- localized["Nothing to do or in combat"] = ""
-- localized["Open those clams (and other containers)"] = ""
-- localized["%s - %d"] = ""
-- localized["ShuckIt"] = ""
-- localized["|T%s:16|t %s x %d"] = ""
-- localized["Use: Open the clam!"] = ""
-- localized["Use %s to open the next item"] = ""


end

-------------------------
-- Traditional Chinese --
-------------------------

if loc == "zhTW" then 

localized = {}
-- localized["Cannot open Clams by clicking on the LDB display. Use %s instead."] = ""
-- localized["|cffffd700%d %s to open|r"] = ""
-- localized["item"] = ""
-- localized["items"] = ""
-- localized["Nothing to do or in combat"] = ""
-- localized["Open those clams (and other containers)"] = ""
-- localized["%s - %d"] = ""
-- localized["ShuckIt"] = ""
-- localized["|T%s:16|t %s x %d"] = ""
-- localized["Use: Open the clam!"] = ""
-- localized["Use %s to open the next item"] = ""


end


-- Metatable majicks... makes localized table fallback to english, or fallback to the index requested.
-- This ensures we ALWAYS get a value back, even if it's the index we requested originally
ShuckIt.localized = localized and setmetatable(localized, {__index = function(t,i) return english[i] or i end})
	or setmetatable(english, {__index = function(t,i) return i end})


