-- Spanish localization file for esES.
local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("Revelation", "esES")
if not L then return end

L["Armor Enchantment"] = "Encantamiento de Armadura"
L["Armor Vellum"] = "Vitela de armadura"
L["Boots"] = "botas"
L["Bracer"] = "brazales"
L["Chest"] = "pechera"
L["Cloak"] = "capa"
L["Create 1 - %d %s."] = "Crear 1 - %d %s."
L["Create every %s you have reagents for."] = "Crear todos los %s para los que tiene materiales." -- Needs review
L["Easy"] = "Fácil"
L["Either no recipe or no reagents were found."] = "No se encontró ninguna receta ni materiales." -- Needs review
-- L["Enchanting"] = ""
L["Gloves"] = "guantes"
L["Medium"] = "Medio"
L["Optimal"] = "Óptimo"
L["Ring"] = "anillo"
L["Select the key to press when mouse-clicking for menu display."] = "Seleccione una tecla para presionar cuando haga clic para mostrar el menú."
L["Select the mouse button to click for menu display."] = "Seleccione el botón de ratón para mostrar el menú."
L["Select the second key to press when mouse-clicking for menu display."] = "Seleccione una segunda tecla para presionar cuando haga clic para mostrar el menú."
L["Shield"] = "escudo"
L["Staff"] = "bastón"
L["Staves"] = "Bastones"
L["Trade Goods"] = "Objetos comerciables"
L["Trivial"] = "Trivial"
L["Weapon"] = "arma"
L["Weapon Enchantment"] = "Encantamiento de Arma"
L["Weapon Vellum"] = "Vitela de arma"
