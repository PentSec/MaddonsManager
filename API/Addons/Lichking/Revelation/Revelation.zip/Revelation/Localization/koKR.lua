-- Korean localization file for koKR.
local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("Revelation", "koKR")
if not L then return end

L["Armor Enchantment"] = "방어구 마법부여"
-- L["Armor Vellum"] = ""
L["Boots"] = "장화"
L["Bracer"] = "손목"
L["Chest"] = "가슴"
L["Cloak"] = "망토"
-- L["Create 1 - %d %s."] = ""
-- L["Create every %s you have reagents for."] = ""
-- L["Easy"] = ""
L["Either no recipe or no reagents were found."] = "조제법 또는 시약 발견" -- Needs review
-- L["Enchanting"] = ""
L["Gloves"] = "장갑"
-- L["Medium"] = ""
-- L["Optimal"] = ""
L["Ring"] = "반지"
-- L["Select the key to press when mouse-clicking for menu display."] = ""
-- L["Select the mouse button to click for menu display."] = ""
-- L["Select the second key to press when mouse-clicking for menu display."] = ""
L["Shield"] = "방패"
L["Staff"] = "지팡이"
L["Staves"] = "지팡이"
-- L["Trade Goods"] = ""
-- L["Trivial"] = ""
L["Weapon"] = "무기"
L["Weapon Enchantment"] = "무기 마법부여"
-- L["Weapon Vellum"] = ""
