-- Spanish localization file for esMX.
local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("Revelation", "esMX")
if not L then return end

L["Armor Enchantment"] = "Encantamiento de Armadura" -- Needs review
L["Armor Vellum"] = "Vitela de armadura" -- Needs review
L["Boots"] = "botas" -- Needs review
L["Bracer"] = "brazales" -- Needs review
L["Chest"] = "pechera" -- Needs review
L["Cloak"] = "capa" -- Needs review
L["Create 1 - %d %s."] = "Crear 1 - %d %s."
L["Create every %s you have reagents for."] = "Crear todos los %s para los que tiene materiales." -- Needs review
L["Easy"] = "Fácil"
L["Either no recipe or no reagents were found."] = "No se encontró ninguna receta ni reactivo." -- Needs review
-- L["Enchanting"] = ""
L["Gloves"] = "guantes" -- Needs review
L["Medium"] = "Medio"
L["Optimal"] = "Óptimo"
L["Ring"] = "anillo" -- Needs review
L["Select the key to press when mouse-clicking for menu display."] = "Seleccione una tecla para presionar cuando haga clic para mostrar el menú." -- Needs review
L["Select the mouse button to click for menu display."] = "Seleccione el botón de ratón para mostrar el menú." -- Needs review
L["Select the second key to press when mouse-clicking for menu display."] = "Seleccione una segunda tecla para presionar cuando haga clic para mostrar el menú." -- Needs review
L["Shield"] = "escudo" -- Needs review
L["Staff"] = "bastón" -- Needs review
L["Staves"] = "Bastones" -- Needs review
L["Trade Goods"] = "Objetos comerciables" -- Needs review
L["Trivial"] = "Trivial"
L["Weapon"] = "arma" -- Needs review
L["Weapon Enchantment"] = "Encantamiento de Arma" -- Needs review
L["Weapon Vellum"] = "Vitela de arma" -- Needs review
