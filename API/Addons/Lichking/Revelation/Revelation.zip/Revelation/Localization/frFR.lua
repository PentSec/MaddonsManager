-- French localization file for frFR.
local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("Revelation", "frFR")
if not L then return end

L["Armor Enchantment"] = "Enchantement d'armure"
L["Armor Vellum"] = "Vélin d'armure"
L["Boots"] = "bottes"
L["Bracer"] = "brassards"
L["Chest"] = "plastron"
L["Cloak"] = "cape"
-- L["Create 1 - %d %s."] = ""
-- L["Create every %s you have reagents for."] = ""
L["Easy"] = "Facile" -- Needs review
L["Either no recipe or no reagents were found."] = "Aucune recette ou aucun réactif n'ont été trouvés."
-- L["Enchanting"] = ""
L["Gloves"] = "gants"
L["Medium"] = "Moyen" -- Needs review
L["Optimal"] = "Optimal" -- Needs review
L["Ring"] = "d'anneau"
L["Select the key to press when mouse-clicking for menu display."] = "Sélectionnez la touche à maintenir quand vous cliquez sur le menu"
L["Select the mouse button to click for menu display."] = "Sélectionnez le bouton de la souris pour l'affichage du menu"
L["Select the second key to press when mouse-clicking for menu display."] = "Sélectionnez la deuxième touche à maintenir quand vous cliquez sur le menu"
L["Shield"] = "bouclier"
L["Staff"] = "de bâton"
L["Staves"] = "Bâtons"
L["Trade Goods"] = "Marchandises"
L["Trivial"] = "Trivial" -- Needs review
L["Weapon"] = "d'arme"
L["Weapon Enchantment"] = "Enchantement d'arme"
L["Weapon Vellum"] = "Vélin d'arme"

