-- BankStack Locale
-- Please use the Localization App on WoWAce to Update this
-- http://www.wowace.com/projects/bank-stack/localization/

local L = LibStub("AceLocale-3.0"):NewLocale("BankStack", "deDE")
if not L then return end

-- L["already_running"] = ""
L["ARMOR"] = "Rüstung"
-- L["at_bank"] = ""
-- L["BAG"] = ""
-- L["BINDING_HEADER_BANKSTACK_HEAD"] = ""
-- L["BINDING_NAME_BAGSORT"] = ""
-- L["BINDING_NAME_BANKSTACK"] = ""
-- L["BINDING_NAME_COMPRESS"] = ""
-- L["complete"] = ""
-- L["confused"] = ""
L["CONSUMABLE"] = "Verbrauchbar"
L["CONTAINER"] = "Behälter"
L["GEM"] = "Edelsteine"
L["KEY"] = "Schlüssel"
L["MISC"] = "Verschiedenes"
-- L["moving"] = ""
-- L["options"] = ""
-- L["opt_set"] = ""
-- L["perfect"] = ""
L["PROJECTILE"] = "Projektil"
L["QUEST"] = "Quest"
L["QUIVER"] = "Köcher"
L["REAGENT"] = "Reagenz"
L["RECIPE"] = "Rezept"
-- L["to_move"] = ""
L["TRADEGOODS"] = "Handwerkswaren"
L["WEAPON"] = "Waffe"

