-- MejDesign.lua
local NameOfDesign = "noTreants"
local layerFrame


local function design(mainFrame, cds)
	-- Update()
	-- CreateCastFrame( spellTexture, RTframe, height, width, relwhich, relto )
	-- createDesign()
	-- deleteDesign()

	local MoonTimeNextCastframe
	local MoonTimeEclipseframe
	local MoonTimeMoonfireframe
	local MoonTimeInsectswarmframe
	local MoonTimeStarrainframe
	local layerFrame = CreateFrame("Frame", "layerFrame", mainFrame )
	layerFrame:SetHeight( mainFrame:GetHeight() )
	layerFrame:SetWidth( mainFrame:GetWidth() )
	layerFrame:SetPoint("CENTER")
	layerFrame:Hide()
	
	layerFrame.Update = function()

		local lunar, solar = cds:GetEclipseEndTimes()
		local MF = cds:GetMoonfireCD()
		local IS = cds:GetInsectSwarmCD()
		local SR_cd = cds:GetStarrainCD()

		if lunar-15<GetTime() and GetTime()<lunar then											-- im Lunar
			MoonTimeEclipseframe:SetText(string.format("%2.1f", (lunar-GetTime())));
			MoonTimeEclipseframe:SetIcon( Lunar_icon )		
		elseif solar-15<GetTime() and GetTime()<solar then										-- im Solar
			MoonTimeEclipseframe:SetText(string.format("%2.1f", (solar-GetTime())));
			MoonTimeEclipseframe:SetIcon( Solar_icon )
		elseif solar>lunar then
			MoonTimeEclipseframe:SetIcon( Solar_icon )
			MoonTimeEclipseframe:SetText( ' ' )
			if solar+15>GetTime() then
				MoonTimeEclipseframe:SetText(string.format("|cfff6ffff%2.1f|r", (solar+15-GetTime())));
			end
		else
			MoonTimeEclipseframe:SetIcon( Lunar_icon )
			MoonTimeEclipseframe:SetText( ' ' )
			if lunar+15>GetTime() then
				MoonTimeEclipseframe:SetText(string.format("|cfff6ffff%2.1f|r", (lunar+15-GetTime())));		
			end
		end
		
		if MF>=0 then
			MoonTimeMoonfireframe:SetText( string.format("%2.1f", (MF) ) )
		else
			MoonTimeMoonfireframe:SetText( '' )
		end
		
		if IS>=0 then
			MoonTimeInsectswarmframe:SetText( string.format("%2.1f", (IS) ) )
		else
			MoonTimeInsectswarmframe:SetText( '' )
		end

		if SR_cd>1.5 then
			MoonTimeStarrainframe:SetText( '|cfff6ffff' .. math.ceil(SR_cd) .. '|r' )
		else
			MoonTimeStarrainframe:SetText( '' )
		end

	end

	layerFrame.CreateCastFrame = function( spellTexture, RTframe, height, width, relwhich, relto )
		local frame = CreateFrame( "Frame", "MTCastframe"..RTframe:GetName(), layerFrame )
		frame:SetBackdrop({
			bgFile = spellTexture,
			tile = false, tileSize = height, edgeSize = 0,
			insets = { left = 0, right = 0, top = 0, bottom = 0 }
		})
		frame:SetHeight(height)
		frame:SetWidth(width)
		frame:SetPoint(relwhich, RTframe, relto, 0, 0)

		local labelframe = frame:CreateFontString(nil,"ARTWORK","GameFontNormal")
		labelframe:SetPoint("TOPLEFT", frame, "TOPLEFT")
		labelframe:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT")
		labelframe:SetTextColor( 1, 1, 0, 1 );
		frame.SetText = function( self, msg )
			if( msg == '' ) then
				frame:SetBackdropColor(1,1,1,1)		
			else
				frame:SetBackdropColor(.3,.3,.3,.5)	
			end
			labelframe:SetText(msg)
		end
		frame.SetIcon = function( self, icon )
			frame:SetBackdrop({bgFile = icon})
		end
		
		return frame
	end

	layerFrame.createDesign = function ()
		mainFrame:SetHeight(96)
		mainFrame:SetWidth(64)
		local castwidth = 48
		local castheight = 16

		--MoonTimeNextCastframe = layerFrame.CreateCastFrame( "", layerFrame, 32, 32, "TOP", "TOP")
		MoonTimeEclipseframe = layerFrame.CreateCastFrame( Lunar_icon, layerFrame, castheight, castwidth, "TOP", "TOP")
		MoonTimeMoonfireframe = layerFrame.CreateCastFrame( MF_icon, MoonTimeEclipseframe, castheight, castwidth, "TOP", "BOTTOM")
		MoonTimeInsectswarmframe = layerFrame.CreateCastFrame( IS_icon, MoonTimeMoonfireframe, castheight, castwidth, "TOP", "BOTTOM")
		MoonTimeStarrainframe = layerFrame.CreateCastFrame( SR_icon, MoonTimeInsectswarmframe, castheight, castwidth, "TOP", "BOTTOM")

	end
	

	layerFrame.deleteDesign = function()
		MoonTimeEclipseframe:Hide()
		MoonTimeEclipseframe = nil
		MoonTimeMoonfireframe:Hide()
		MoonTimeMoonfireframe = nil
		MoonTimeInsectswarmframe:Hide()
		MoonTimeInsectswarmframe = nil
		MoonTimeStarrainframe:Hide()
		MoonTimeStarrainframe = nil
		
		layerFrame:Hide()
		layerFrame = nil
	end

	return layerFrame
end

-- ****************************************
--
-- DO NOT CHANGE ANYTHING BELOW THIS 
--
-- ****************************************

local function registerDesign( name )									-- Beginn initialize
	local designFrame
	local frame = CreateFrame( "Frame", name, UIPARENT	)
	frame.ID = name
	frame:RegisterEvent("VARIABLES_LOADED");
	frame:SetScript("OnEvent", 
		function( self, event )
			if event=="VARIABLES_LOADED" then							-- falls das ausloesende Event VARIABLES_LOADED ist ...
																		-- werden die ausstehenden Events registriert
				MoonTimeDoorKeeper:RegisterDesign(this);
			end
		end
	)
	
	frame.createDesign = function( this ) 
		designFrame = design(this.Mainframe, this.Objectframe)
		designFrame:createDesign()
	end

	frame.Hide = function()
		designFrame:Hide()
	end
	frame.Show = function()
		designFrame:Show()
	end
	frame.Update = function()
		designFrame:Update()
	end

	frame.deleteDesign = function()
		designFrame:deleteDesign()
	end
end																		-- Ende initialize

registerDesign(NameOfDesign)