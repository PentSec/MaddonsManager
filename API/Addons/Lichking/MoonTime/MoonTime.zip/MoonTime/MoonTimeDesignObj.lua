-- MoonTimeDesignObj.lua

function MoonTimeDesignObj()
	-- dieses Frame besitzt die Funktionen:
	-- GetStarrainCD
	-- GetTreantsCD
	-- GetMoonfireCD
	-- GetInsectSwarmCD
	-- GetEclipseEndTimes
	-- Next()
	local frame = CreateFrame( "Frame" )
	
	
	frame.GetStarrainCD = function()
		local start, duration, enabled = GetSpellCooldown(SR_name);
		
		return start+duration-GetTime();
	end
	
	frame.GetTreantsCD = function()
		local start, duration, enabled = GetSpellCooldown(Treants_name);
		
		return start+duration-GetTime();
	end

	frame.GetMoonfireCD = function()
		local _, _, _, _, _, _, MF_expirationTime, MF_unitCaster = UnitDebuff("target", MF_name);
		
		if MF_unitCaster=="player" then
			return MF_expirationTime-GetTime();
		else
			return -1;
		end
	end

	frame.GetInsectSwarmCD = function()
		local _, _, _, _, _, _, IS_expirationTime, IS_unitCaster = UnitDebuff("target", IS_name);
		
		if IS_unitCaster=="player" then
			return IS_expirationTime-GetTime();
		else
			return -1;
		end
	end
	
	local lunar = 0;
	local solar = 0;
	
	frame.GetEclipseEndTimes = function()
	
		_, _, _, _, _, _, lunar_expirationTime, _, _, _, _ = UnitBuff("player", Lunar_name);
		_, _, _, _, _, _, solar_expirationTime, _, _, _, _ = UnitBuff("player", Solar_name);
	
		if lunar_expirationTime then
			lunar = lunar_expirationTime;
		end
		if solar_expirationTime then
			solar = solar_expirationTime;
		end

		return lunar, solar	
	end
	
	frame.NextTrash = function ()
		local Lunar, Solar = frame:GetEclipseEndTimes();
		
--		echo (Lunar .. " " .. Solar)
		local cast_W=true;
				
		-- w�hrend Lunar SF casten
		if Lunar-15<=GetTime() and GetTime()<=Lunar+15 then
			cast_W = false;
		end
		if Solar-15<=GetTime() and GetTime()<=Solar then
			cast_W = true;
		end
		
		if cast_W then
			return W_icon
		else
			return SF_icon
		end
	return next
	end

	frame.Next = function ()
		local Lunar, Solar = frame:GetEclipseEndTimes();
		local MF = frame:GetMoonfireCD()+GetTime();
		local IS = frame:GetInsectSwarmCD()+GetTime();
		
	
		local cast_MF=true;
		local cast_IS=true;
		local cast_W=true;
		
		local spell, rank, displayName, icon, startTime, endTime, isTradeSkill, castID, interrupt = UnitCastingInfo("player")
		
		if not endTime then
			endTime = GetTime()*1000;
		end
		
	--	if name and MF_unitCaster=="player" then
		if MF>endTime/1000 then
			cast_MF = false;
		end
		if IS>endTime/1000 then
			cast_IS = false;
		end	
		
		-- w�hrend Lunar SF casten
		if Lunar-15<=GetTime() and GetTime()<=Lunar+15 then
			cast_W = false;
		end
		if Solar-15<=GetTime() and GetTime()<=Solar then
			cast_W = true;
		end
		
		--if Solar<=GetTime() and GetTime()<=Lunar+15 then
	--		cast_W = false;
	--	end
		
			
		
		if cast_MF then
			return MF_icon
		elseif cast_IS then
			return IS_icon
		elseif cast_W then
			return W_icon
		else
			return SF_icon
		end

	return next
end

	return frame
end