-- MoonTimeMain.lua

-- Variablen
local NameOfProject = "MoonTime"										-- Name des Projekts
local version = "1.0"													-- Versionsangabe
local EventFrame														-- Frame, das auf Events reagiert
local TimeSinceLastUpdate = 0.0
local UpdateFrequency = 0.02
local design
local MoonTimeObject													-- dummy fuer die Objects
local MoonTimeMainframe 												-- dummy fuer das Hauptframe

local MoonTime = {}
MoonTimeDoorKeeper = {}

MoonTime_DB = {															-- default Konfiguration,
																		-- wird w�hrend des Variabelnladens
																		-- ueberschrieben
	["position"] = {	
		["point"] = "CENTER",
		["relativeTo"] = UIPARENT,
		["relativePoint"] = "CENTER",
		["offsetX"] = 0,
		["offsetY"] = 0,
	},
	["layout"] = "default",
	["trashlayout"] = "defaultTrash",
	["hideontrash"] = false,
	["enabled"] = true,
	
	["trashhp_raid25"] = 1000000,									
	["trashhp_raid10"] = 200000,
	["trashhp_raid5"] = 50000,
};

local MoonTime_Design_Liste = {}										-- enthaelt moegliche designs

local debugging = false



MF_name, MF_rank, MF_icon, MF_cost, MF_isFunnel, MF_powerType, MF_castTime, MF_minRange, MF_maxRange = GetSpellInfo(48463); -- Mondfeuer
IS_name, IS_rank, IS_icon, IS_cost, IS_isFunnel, IS_powerType, IS_castTime, IS_minRange, IS_maxRange = GetSpellInfo(48468); -- Insektenschwarm
W_name, W_rank, W_icon, W_cost, W_isFunnel, W_powerType, W_castTime, W_minRange, W_maxRange = GetSpellInfo(48461); -- Zorn
SF_name, SF_rank, SF_icon, SF_cost, SF_isFunnel, SF_powerType, SF_castTime, SF_minRange, SF_maxRange = GetSpellInfo(48465); -- Sternenfeuer
Lunar_name, Lunar_rank, Lunar_icon, Lunar_cost, Lunar_isFunnel, Lunar_powerType, Lunar_castTime, Lunar_minRange, Lunar_maxRange = GetSpellInfo(48518); -- Lunar
Solar_name, Solar_rank, Solar_icon, Solar_cost, Solar_isFunnel, Solar_powerType, Solar_castTime, Solar_minRange, Solar_maxRange = GetSpellInfo(48517); -- Solar
SR_name, SR_rank, SR_icon, SR_cost, SR_isFunnel, SR_powerType, SR_castTime, SR_minRange, SR_maxRange = GetSpellInfo(53201); -- Sternenregen
Treants_name, Treants_rank, Treants_icon, Treants_cost, Treants_isFunnel, Treants_powerType, Treants_castTime, Treants_minRange, Treants_maxRange = GetSpellInfo(33831); -- Treants

function MoonTime.debug ( self, msg )							-- Beginn debug
	if debugging then 													-- falls debugging aktiv ist
		DEFAULT_CHAT_FRAME:AddMessage("|cff00FFFF"..NameOfProject.."(debug):|r "..msg)		
																		-- Einfache Routine zur Ausgabe von Informationen
	end
end																		-- Ende debug

function MoonTime.echo( self, msg )												-- Beginn echo
																		-- Einfache Routine zur Ausgabe von Nachrichten
	if not msg then
		msg = "Error: nil"
	end
	DEFAULT_CHAT_FRAME:AddMessage("|cff00FFFF"..NameOfProject..":|r "..msg)

end																		-- Ende echo

function MoonTime.help( self )															-- Beginn help
	MoonTime:echo("Version "..version.."")
	MoonTime:echo("|cffFFFF00/moontime move|r makes the frame moveable")
	MoonTime:echo("|cffFFFF00/moontime setlayout <name>|r sets the layout and the trashlayout")
	MoonTime:echo("|cffFFFF00/moontime settrashlayout name|r sets the trashlayout")
	MoonTime:echo("|cffFFFF00/moontime list|r gives a list of all layouts available")
	MoonTime:echo("|cffFFFF00/moontime toggletrash|r toggles visibility while fighting non elite mobs ")
	MoonTime:echo("|cffFFFF00/moontime settrashhp <raidsize> <value>|r sets the mark for each raidsize (5,10,25) from where a mob is treated as a boss")
end			

function MoonTime.list( self )										-- lists the layouts
	MoonTime:echo ("Available layouts:")
	for index, value in pairs(MoonTime_Design_Liste) do
		MoonTime:echo(index)
	end	
end											

function MoonTime.isTrash( self )
	local max_health = UnitHealthMax("target")
	local NumPartyMembers = GetNumRaidMembers();
	
	
	if NumPartyMembers > 10 and max_health > MoonTime_DB["trashhp_raid25"] -1 then
		return false
	elseif NumPartyMembers > 5 and NumPartyMembers < 11 and max_health > MoonTime_DB["trashhp_raid10"] -1 then
		return false
	elseif not UnitInRaid("player") and max_health > MoonTime_DB["trashhp_raid5"] -1 then
		return false
	else
		return true
	end
end

function MoonTime.canuse( self)
	local name = GetSpellInfo(24858)
	local moonkin = UnitBuff("player", name) 
	
	if moonkin and UnitLevel("player")==80 then
		return true
	else
		return false
	end
end


function MoonTime.registerMoonTimeDesign( self, frame )
	-- Die Moeglichkeit f�r Designs, sich einzutragen
	if frame.ID then
		MoonTime_Design_Liste[frame.ID] = frame;
		frame.Mainframe = MoonTimeMainframe
		frame.Objectframe = MoonTimeObject
		MoonTime:debug("Design \""..frame.ID.."\" has been registered.")
		MoonTime:CreateMoonTimeLayoutNow(frame.ID);

	end
end

function MoonTime.setTrashHP(self, raid, value)
	hp = tonumber(value);
	if hp and (raid==25 or raid == 10 or raid == 5) then
		MoonTime:echo("Old HP:" .. MoonTime_DB["trashhp_raid" .. raid])
		MoonTime_DB["trashhp_raid" .. raid] = hp
		MoonTime:echo("New HP:" .. MoonTime_DB["trashhp_raid" .. raid])
	else 
		MoonTime:echo("|cffFFFF00/moontime settrashhp <raidsize> <value>|r raidsize must be 5, 10 or 25, value must be a number")
	end
end

function MoonTime.setLayout( self, layoutName )
	local oldLayout = MoonTime_DB["layout"]								-- altes Layout wird behalten wegen Loeschen
	local oldTrashLayout = MoonTime_DB["trashlayout"]					-- altes Layout wird behalten wegen Loeschen
	if MoonTime_Design_Liste[layoutName] then							-- falls es das Layout gibt
		MoonTime_DB["layout"] = layoutName
		MoonTime_DB["trashlayout"] = layoutName
		MoonTimeMainframe:SetScript("OnUpdate", nil);					-- Update wird unterbunden waehrend des Wechsels
		if (MoonTime_Design_Liste[oldLayout] == MoonTime_Design_Liste[oldTrashLayout]) then
			-- falls identisch, genuegt es, nur eines zu loeschen
			if MoonTime_Design_Liste[oldLayout] then						-- altes Layout loeschen, falls existent
				MoonTime_Design_Liste[oldLayout]:deleteDesign()
			end
		else
			if MoonTime_Design_Liste[oldLayout] then						-- altes Layout loeschen, falls existent
				MoonTime_Design_Liste[oldLayout]:deleteDesign()
			end
			if MoonTime_Design_Liste[oldTrashLayout] then					-- altes Layout loeschen, falls existent
				MoonTime_Design_Liste[oldTrashLayout]:deleteDesign()
			end
		end
		MoonTime:CreateMoonTimeLayout(MoonTime_DB["layout"])						-- neues Layout erstellen
		MoonTime:CreateMoonTimeTrashLayout(MoonTime_DB["trashlayout"])			-- neues TrashLayout erstellen
		MoonTime:echo( "Layout \"" .. layoutName .. "\" is set for bosses and trash");
	else
		MoonTime:echo( "Layout \"" .. layoutName .. "\" is not known. Type |cffFFFF00/moontime list|r to get all available layouts");
	end
end

function MoonTime.setTrashLayout( self, layoutName )
	local oldTrashLayout = MoonTime_DB["trashlayout"]					-- altes Layout wird behalten wegen Loeschen
	if MoonTime_Design_Liste[layoutName] then							-- falls es das Layout gibt
		MoonTime_DB["trashlayout"] = layoutName
		MoonTimeMainframe:SetScript("OnUpdate", nil);					-- Update wird unterbunden waehrend des Wechsels
		if (MoonTime_Design_Liste[MoonTime_DB["layout"]] == MoonTime_Design_Liste[oldTrashLayout]) then
			-- falls identisch, genuegt es, nur eines zu loeschen
			if MoonTime_Design_Liste[MoonTime_DB["layout"]] then						-- altes Layout loeschen, falls existent
				MoonTime_Design_Liste[MoonTime_DB["layout"]]:deleteDesign()
			end
		else
			if MoonTime_Design_Liste[MoonTime_DB["layout"]] then						-- altes Layout loeschen, falls existent
				MoonTime_Design_Liste[MoonTime_DB["layout"]]:deleteDesign()
			end
			if MoonTime_Design_Liste[oldTrashLayout] then					-- altes Layout loeschen, falls existent
				MoonTime_Design_Liste[oldTrashLayout]:deleteDesign()
			end
		end
		MoonTime:CreateMoonTimeLayout(MoonTime_DB["layout"])						-- neues Layout erstellen
		MoonTime:CreateMoonTimeTrashLayout(MoonTime_DB["trashlayout"])			-- neues TrashLayout erstellen
		MoonTime:echo( "Layout \"" .. layoutName .. "\" is set for trash");
	else
		MoonTime:echo( "Layout \"" .. layoutName .. "\" is not known. Type |cffFFFF00/moontime list|r to get all available layouts");
	end
end

function MoonTime.CreateMoonTimeLayoutNow( self, name )
	if ( name == MoonTime_DB["layout"] ) then
		MoonTime:CreateMoonTimeLayout(MoonTime_DB["layout"])								-- Layout wird erstellt
	end
	if ( name == MoonTime_DB["trashlayout"] ) then
		MoonTime:CreateMoonTimeTrashLayout(MoonTime_DB["trashlayout"])								-- Layout wird erstellt
	end
end

function MoonTime.OnEvent( self, event, ...)										-- Beginn OnEvent
	if event=="VARIABLES_LOADED" then									-- falls das ausloesende Event VARIABLES_LOADED ist ...
																		-- werden die ausstehenden Events registriert
																		
		EventFrame:RegisterEvent("PLAYER_REGEN_DISABLED");				-- Spieler beginnt Kampf
		EventFrame:RegisterEvent("PLAYER_REGEN_ENABLED");				-- Spieler verlaesst Kampf
		EventFrame:RegisterEvent("PLAYER_TARGET_CHANGED");
		EventFrame:RegisterEvent("UNIT_COMBAT");
		EventFrame:RegisterEvent("UNIT_TARGET");
																		-- MoonTimeMainframe wird positioniert
		MoonTimeMainframe:SetPoint(MoonTime_DB["position"]["point"], MoonTime_DB["position"]["relativeTo"], MoonTime_DB["position"]["relativePoint"], MoonTime_DB["position"]["offsetX"], MoonTime_DB["position"]["offsetY"])

	elseif event=="PLAYER_TARGET_CHANGED" or event=="PLAYER_REGEN_DISABLED" or event=="UNIT_COMBAT" or event=="UNIT_TARGET" then	

		if MoonTime:canuse() and UnitCanAttack("player","target") and not ( UnitIsDead("target") or UnitIsCorpse("target") or UnitInVehicle("player") ) then
			
			EventFrame:UnregisterEvent("UNIT_COMBAT");
			EventFrame:UnregisterEvent("UNIT_TARGET");
			--local classification = UnitClassification("target")
			--if ( classification == "rare" or classification == "normal" or classification == "trivial" ) then 
--				classification = "trash"
			--end
			if MoonTime_DB["hideontrash"] then
				--	if not ( classification == "trash" ) then 
				if not MoonTime:isTrash() then
					MoonTime_Design_Liste[MoonTime_DB["trashlayout"]]:Hide()
					MoonTime_Design_Liste[MoonTime_DB["layout"]]:Show()
					MoonTimeMainframe:Show();
				else
					MoonTimeMainframe:Hide();
				end
			else
				-- if not (classification == "trash") then
				if not MoonTime:isTrash() then
					MoonTime:debug("Showing elite layout "..MoonTime_DB["layout"])
					MoonTime_Design_Liste[MoonTime_DB["trashlayout"]]:Hide()
					MoonTime_Design_Liste[MoonTime_DB["layout"]]:Show()
				else
					MoonTime:debug("Showing trash layout "..MoonTime_DB["trashlayout"])
					MoonTime_Design_Liste[MoonTime_DB["layout"]]:Hide()
					MoonTime_Design_Liste[MoonTime_DB["trashlayout"]]:Show()
				end
				MoonTimeMainframe:Show();
			end
		else
			if not EventFrame:IsEventRegistered("UNIT_TARGET") then
				EventFrame:RegisterEvent("UNIT_COMBAT");
				EventFrame:RegisterEvent("UNIT_TARGET");
			end
			MoonTimeMainframe:Hide();
		end		
	end
end																		-- Ende OnEvent


function MoonTime.enable()														-- Beginn enable
end																		-- Ende enable

function MoonTime.disable()														-- Beginn enable
end																		-- Ende enable

function MoonTime.move( self )															-- Beginn config
	MoonTimeMainframe:SetMovable(true)
	MoonTimeMainframe:EnableMouse(true)
	-- missing: ne besondere colorierung oder sowas, um anzuzeigen, dass config mode is
	MoonTimeMainframe:Show()

end																		-- Ende config

function MoonTime.trash( self )
	if MoonTime_DB["hideontrash"] then
		MoonTime_DB["hideontrash"] = false
		MoonTime:echo("Non elite mobs: visible")
	else
		MoonTime_DB["hideontrash"] = true
		MoonTime:echo("Non elite mobs: invisible")
	end
end

function MoonTime.toggle(self, msg)													-- Beginn toggle
	origMsg = msg
	msg = strtrim( msg )												-- entferne ueberfluessige whitespaces
	msg = msg:lower()													-- in Kleinbuchstaben verwandeln
	if( msg == "help" ) then MoonTime:help()										-- rufe help auf
	elseif( msg == "move" ) then MoonTime:move()									-- rufe move auf
	elseif( msg == "toggletrash" ) then MoonTime:trash()									-- rufe trash auf
	elseif( msg == "disable" ) then MoonTime:disable()							-- rufe disable auf
	elseif( msg == "enable" ) then MoonTime:enable()								-- rufe enable auf
	elseif( msg == "list" ) then MoonTime:list()
	elseif( type( strfind( msg, "setlayout" ) ) ~= "nil" and strfind(msg, "setlayout") > 0 ) then
		restOfMsg = string.sub( origMsg, string.len("setlayout")+1 )
		restOfMsg = strtrim( restOfMsg )
		MoonTime:setLayout( restOfMsg )
	elseif( type( strfind( msg, "settrashlayout" ) ) ~= "nil" and strfind(msg, "settrashlayout") > 0 ) then
		restOfMsg = string.sub( origMsg, string.len("settrashlayout")+1 )
		restOfMsg = strtrim( restOfMsg )
		MoonTime:setTrashLayout( restOfMsg )
	elseif( type( strfind( msg, "settrashhp" ) ) ~= "nil" and strfind(msg, "settrashhp") > 0 ) then
		restOfMsg = strtrim(string.sub( origMsg, string.len("settrashhp")+1 ))
		local raid = tonumber(string.sub( restOfMsg, 1,2 ))
		local value = tonumber(string.sub( restOfMsg, 3 ))

		MoonTime:setTrashHP( raid, value )
	else
		MoonTime:help()
	end
end																		-- Ende toggle

function MoonTime.OnUpdate(self, elapsed)										-- Beginn OnUpdate
	TimeSinceLastUpdate = TimeSinceLastUpdate + elapsed; 	

  while (TimeSinceLastUpdate > UpdateFrequency) do
		-- wie bei create wird dies umgeschrieben, dass die jeweils zutreffende Function angesprochen wird
		--MoonTime_Design_Liste[MoonTime_DB["layout"]]:Update()
		--echo (MoonTime_Design_Liste[MoonTime_DB["layout"]].ID)
		MoonTime_Design_Liste[MoonTime_DB["layout"]]:Update()
		MoonTime_Design_Liste[MoonTime_DB["trashlayout"]]:Update()
    TimeSinceLastUpdate = TimeSinceLastUpdate - UpdateFrequency;
  end

end																		-- Ende OnUpdate
function MoonTime.CreateMainFrame ( self )					
	
	local frame = CreateFrame( "Frame", "MTMainframe", UIPARENT )
	frame:SetMovable(false)
	frame:EnableMouse(false)
	frame:SetClampedToScreen(true)
	frame:SetBackdrop({
		bgFile = "",
		tile = true, tileSize = height, edgeSize = 10,
		insets = { left = 2, right = 2, top = 2, bottom = 2 }
	})
	frame:SetScript("OnMouseDown", 
			function()
				if ( ( ( not this.isLocked ) or ( this.isLocked == 0 ) ) and ( arg1 == "LeftButton" ) ) then
					this:StartMoving();
					this.isMoving = true;
				end
			end
		)
	frame:SetScript("OnMouseUp", 
			function()
				if ( this.isMoving ) then
					this:StopMovingOrSizing();
					this.isMoving = false;
					MoonTime_DB["position"]["point"], MoonTime_DB["position"]["relativeTo"], MoonTime_DB["position"]["relativePoint"], MoonTime_DB["position"]["offsetX"], MoonTime_DB["position"]["offsetY"] = frame:GetPoint(frame:GetNumPoints())
																				-- falls die Position gespeichert werden soll
					
					this:SetMovable(false)
					this:EnableMouse(false)
				end
			end
		)
	
	frame:SetHeight(100)
	frame:SetWidth(100)
	frame:SetPoint("CENTER", UIPARENT, "CENTER", 0, 0)
	frame:Hide()
	return frame
	
end

function MoonTime.CreateMoonTimeLayout( self, which )											-- Beginn CreateFrame
	if MoonTime_Design_Liste[which] then 
		MoonTime_Design_Liste[which]:createDesign(MoonTimeMainframe);
		MoonTime:debug("Design \""..which.."\" loaded.")
		local visible = ""
		if MoonTime_DB["hideontrash"] then visible = "in" end
		MoonTime:debug("Non elite mobs: "..visible.."visible")
	end

	MoonTimeMainframe:SetScript("OnUpdate", function(self, event, ... ) MoonTime:OnUpdate(event, ...) end)					-- Seine UpdateRoutine wird angeworfen
																		-- Da die Updateroutine nur dann angeworfen wird, wenn das Fenster
																		-- sichtbar ist, wird OnUpdate auch nur dann aufgerufen, wenn es gebraucht
																		-- wird

end																		-- Ende CreateFrame

function MoonTime.CreateMoonTimeTrashLayout( self, which )											-- Beginn CreateFrame
	if MoonTime_Design_Liste[which] then 
		MoonTime_Design_Liste[which]:createDesign(MoonTimeMainframe);
		MoonTime:debug("TrashDesign \""..which.."\" loaded.")
	end
	MoonTimeMainframe:SetScript("OnUpdate", function(self, event, ... ) MoonTime:OnUpdate(event, ...) end)					-- Seine UpdateRoutine wird angeworfen
																		-- Da die Updateroutine nur dann angeworfen wird, wenn das Fenster
																		-- sichtbar ist, wird OnUpdate auch nur dann aufgerufen, wenn es gebraucht
																		-- wird

end																		-- Ende CreateFrame

function MoonTime.initialize(self)													-- Beginn initialize
	SlashCmdList["MOONTIME"] = function( msg ) MoonTime:toggle( msg ) end
	SLASH_MOONTIME1 = "/moontime";
	SLASH_MOONTIME2 = "/moon";
	
	EventFrame = CreateFrame( "Frame", "MTEventframe", UIPARENT	)
	EventFrame:SetScript("OnEvent", function(self, event, ... ) MoonTime:OnEvent(event, ...) end)
	EventFrame:RegisterEvent("VARIABLES_LOADED");
	MoonTimeMainframe = MoonTime:CreateMainFrame()								-- Das Hauptfenster wird erzeugt
	MoonTimeObject = MoonTimeDesignObj()
	MoonTime:echo("initialized...")
	
	
end																		-- Ende initialize

MoonTimeDoorKeeper.RegisterDesign = function(self, frame, ... ) MoonTime:registerMoonTimeDesign(frame, ...) end







MoonTime:initialize()															-- make it so!
