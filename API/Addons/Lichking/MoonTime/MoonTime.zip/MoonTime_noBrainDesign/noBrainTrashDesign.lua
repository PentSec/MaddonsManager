-- MejDesign.lua
local NameOfDesign = "noBrainTrash"
local layerFrame


local function design(mainFrame, cds)
	-- Update()
	-- CreateCastFrame( spellTexture, RTframe, height, width, relwhich, relto )
	-- createDesign()
	-- deleteDesign()

	local MoonTimeNextCastframe
	local MoonTimeMoonfireframe
	local MoonTimeInsectswarmframe
	local layerFrame = CreateFrame("Frame", "layerFrame", mainFrame )
	layerFrame:SetHeight( mainFrame:GetHeight() )
	layerFrame:SetWidth( mainFrame:GetWidth() )
	layerFrame:SetPoint("CENTER")
	layerFrame:Hide()
	
	layerFrame.Update = function()
		MoonTimeNextCastframe:SetIcon(cds.NextTrash())

		local MF = cds:GetMoonfireCD()
		local IS = cds:GetInsectSwarmCD()

		if MF>=0 then
			MoonTimeMoonfireframe:SetText( math.ceil(MF) )
		else
			MoonTimeMoonfireframe:SetText( '' )
		end
		
		if IS>=0 then
			MoonTimeInsectswarmframe:SetText( math.ceil(IS) )
		else
			MoonTimeInsectswarmframe:SetText( '' )
		end
	
	end

	layerFrame.CreateCastFrame = function( spellTexture, RTframe, height, width, relwhich, relto )
		local frame = CreateFrame( "Frame", "MTCastframe"..RTframe:GetName(), layerFrame )
		frame:SetBackdrop({
			bgFile = spellTexture,
			tile = false, tileSize = height, edgeSize = 0,
			insets = { left = 0, right = 0, top = 0, bottom = 0 }
		})
		frame:SetHeight(height)
		frame:SetWidth(width)
		frame:SetPoint(relwhich, RTframe, relto, 0, 0)

		
		local labelframe = frame:CreateFontString(nil,"ARTWORK","GameFontNormal")
		labelframe:SetPoint("TOPLEFT", frame, "TOPLEFT")
		labelframe:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT")
		labelframe:SetTextColor( 1, 1, 0, 1 );
		frame.SetText = function( self, msg )
			if( msg == '' ) then
				frame:SetBackdropColor(1,1,1,1)		
			else
				frame:SetBackdropColor(.3,.3,.3,.5)	
			end
			labelframe:SetText(msg)
		end
		
		frame.SetIcon = function( self, icon )
			frame:SetBackdrop({bgFile = icon})
		end
		
		return frame
	end

	layerFrame.createDesign = function ()
		mainFrame:SetHeight(96)
		mainFrame:SetWidth(64)
		local castwidth = 48
		local castheight = 16
		-- design fuer eliteFrame

		MoonTimeNextCastframe = layerFrame.CreateCastFrame( "", layerFrame, 48, 48, "TOP", "CENTER")
		MoonTimeMoonfireframe = layerFrame.CreateCastFrame( "Interface\\Icons\\Spell_Nature_StarFall", MoonTimeNextCastframe, 16, 24, "TOPRIGHT", "BOTTOM")
		MoonTimeInsectswarmframe = layerFrame.CreateCastFrame( "Interface\\Icons\\Spell_Nature_InsectSwarm", MoonTimeNextCastframe, 16, 24, "TOPLEFT", "BOTTOM")

	end
	

	layerFrame.deleteDesign = function()
		MoonTimeNextCastframe:Hide()
		MoonTimeNextCastframe = nil
		MoonTimeMoonfireframe:Hide()
		MoonTimeMoonfireframe = nil
		MoonTimeInsectswarmframe:Hide()
		MoonTimeInsectswarmframe = nil
		
		layerFrame:Hide()
		layerFrame = nil
	end

	return layerFrame
end

-- ****************************************
--
-- DO NOT CHANGE ANYTHING BELOW THIS 
--
-- ****************************************

local function registerDesign( name )									-- Beginn initialize
	local designFrame
	local frame = CreateFrame( "Frame", name, UIPARENT	)
	frame.ID = name
	frame:RegisterEvent("VARIABLES_LOADED");
	frame:SetScript("OnEvent", 
		function( self, event )
			if event=="VARIABLES_LOADED" then							-- falls das ausloesende Event VARIABLES_LOADED ist ...
																		-- werden die ausstehenden Events registriert
				MoonTimeDoorKeeper:RegisterDesign(this);

			end
		end
	)
	
	frame.createDesign = function( this ) 
		designFrame = design(this.Mainframe, this.Objectframe)
		designFrame:createDesign()
	end

	frame.Hide = function()
		designFrame:Hide()
	end
	frame.Show = function()
		designFrame:Show()
	end
	frame.Update = function()
		designFrame:Update()
	end

	frame.deleteDesign = function()
		designFrame:deleteDesign()
	end
end																		-- Ende initialize

registerDesign(NameOfDesign)