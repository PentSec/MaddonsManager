-- MejDesign.lua
local NameOfDesign = "noBrain"
local layerFrame


local function design(mainFrame, cds)
	-- Update()
	-- CreateCastFrame( spellTexture, RTframe, height, width, relwhich, relto )
	-- createDesign()
	-- deleteDesign()

	local MoonTimeNextCastframe
	local MoonTimeStarrainframe
	local MoonTimeTreeframe

	local layerFrame = CreateFrame("Frame", "layerFrame", mainFrame )
	layerFrame:SetHeight( mainFrame:GetHeight() )
	layerFrame:SetWidth( mainFrame:GetWidth() )
	layerFrame:SetPoint("CENTER")
	layerFrame:Hide()
	
	layerFrame.Update = function()

		MoonTimeNextCastframe:SetIcon(cds:Next())
		
		local SR_cd = cds:GetStarrainCD()
		local Treants_cd = cds:GetTreantsCD()
		
		if SR_cd > 1.5 then
			MoonTimeStarrainframe:SetText( '|cfff6ffff' .. math.ceil(SR_cd) .. '|r' )
		else
			MoonTimeStarrainframe:SetText( '' )
		end
		
		if Treants_cd > 99 then
			MoonTimeTreantsframe:SetText( '|cfff6ffff' .. math.ceil(Treants_cd/60) .. 'm|r' )
		elseif Treants_cd > 1.5 then
			MoonTimeTreantsframe:SetText( '|cfff6ffff' .. math.ceil(Treants_cd) .. '|r' )
		else
			MoonTimeTreantsframe:SetText( '' )
		end

	end

	layerFrame.CreateCastFrame = function( spellTexture, RTframe, height, width, relwhich, relto )
		local frame = CreateFrame( "Frame", "MTCastframe"..RTframe:GetName(), layerFrame )
		frame:SetBackdrop({
			bgFile = spellTexture,
			tile = false, tileSize = height, edgeSize = 0,
			insets = { left = 0, right = 0, top = 0, bottom = 0 }
		})
		frame:SetHeight(height)
		frame:SetWidth(width)
		frame:SetPoint(relwhich, RTframe, relto, 0, 0)

		local labelframe = frame:CreateFontString(nil,"ARTWORK","GameFontNormal")
		labelframe:SetPoint("TOPLEFT", frame, "TOPLEFT")
		labelframe:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT")
		labelframe:SetTextColor( 1, 1, 0, 1 );
		frame.SetText = function( self, msg )
			if( msg == '' ) then
				frame:SetBackdropColor(1,1,1,1)		
			else
				frame:SetBackdropColor(.3,.3,.3,.5)	
			end
			labelframe:SetText(msg)
		end
		frame.SetIcon = function( self, icon )
			frame:SetBackdrop({bgFile = icon})
		end
		
		return frame
	end

	layerFrame.createDesign = function ()
		mainFrame:SetHeight(96)
		mainFrame:SetWidth(64)
		local castwidth = 48
		local castheight = 16

		MoonTimeNextCastframe = layerFrame.CreateCastFrame( "", layerFrame, 48, 48, "TOP", "CENTER")
		MoonTimeStarrainframe = layerFrame.CreateCastFrame(SR_icon, MoonTimeNextCastframe, 16, 24, "TOPLEFT", "BOTTOMLEFT")
		MoonTimeTreantsframe = layerFrame.CreateCastFrame(Treants_icon, MoonTimeStarrainframe, 16, 24, "TOPLEFT", "TOPRIGHT")

	end
	

	layerFrame.deleteDesign = function()
		MoonTimeNextCastframe:Hide()
		MoonTimeNextCastframe = nil
		MoonTimeStarrainframe:Hide()
		MoonTimeStarrainframe = nil
		MoonTimeTreantsframe:Hide()
		MoonTimeTreantsframe = nil
		
		layerFrame:Hide()
		layerFrame = nil
	end

	return layerFrame
end

-- ****************************************
--
-- DO NOT CHANGE ANYTHING BELOW THIS 
--
-- ****************************************

local function registerDesign( name )									-- Beginn initialize
	local designFrame
	local frame = CreateFrame( "Frame", name, UIPARENT	)
	frame.ID = name
	frame:RegisterEvent("VARIABLES_LOADED");
	frame:SetScript("OnEvent", 
		function( self, event )
			if event=="VARIABLES_LOADED" then							-- falls das ausloesende Event VARIABLES_LOADED ist ...
																		-- werden die ausstehenden Events registriert
				MoonTimeDoorKeeper:RegisterDesign(this);
			end
		end
	)
	
	frame.createDesign = function( this ) 
		designFrame = design(this.Mainframe, this.Objectframe)
		designFrame:createDesign()
	end

	frame.Hide = function()
		designFrame:Hide()
	end
	frame.Show = function()
		designFrame:Show()
	end
	frame.Update = function()
		designFrame:Update()
	end

	frame.deleteDesign = function()
		designFrame:deleteDesign()
	end
end																		-- Ende initialize

registerDesign(NameOfDesign)