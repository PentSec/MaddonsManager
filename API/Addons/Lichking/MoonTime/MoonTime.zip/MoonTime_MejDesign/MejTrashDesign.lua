-- MejDesign.lua
local NameOfDesign = "MejTrash"
local layerFrame


local function design(mainFrame, cds)
	-- Update()
	-- CreateCastFrame( spellTexture, RTframe, height, width, relwhich, relto )
	-- createDesign()
	-- deleteDesign()

	local MoonTimeNextCastframe
	local MoonTimeMoonfireframe
	local MoonTimeInsectswarmframe
	local layerFrame = CreateFrame("Frame", "layerFrame", mainFrame )
	layerFrame:SetHeight( mainFrame:GetHeight() )
	layerFrame:SetWidth( mainFrame:GetWidth() )
	layerFrame:SetPoint("CENTER")
	layerFrame:Hide()
	
	layerFrame.Update = function()
		MoonTimeNextCastframe:SetIcon(cds.NextTrash())

		local MF = cds:GetMoonfireCD()
		local IS = cds:GetInsectSwarmCD()

		if MF>=0 then
			MoonTimeMoonfireframe:SetText( string.format("%2.1f", (MF) ) )
		else
			MoonTimeMoonfireframe:SetText( '' )
		end
		
		if IS>=0 then
			MoonTimeInsectswarmframe:SetText( string.format("%2.1f", (IS) ) )
		else
			MoonTimeInsectswarmframe:SetText( '' )
		end
	
	end

	layerFrame.CreateCastFrame = function( spellTexture, RTframe, height, width, relwhich, relto )
		local frame = CreateFrame( "Frame", "MTCastframe"..RTframe:GetName(), layerFrame )
		frame:SetBackdrop({
			bgFile = "Interface\\TUTORIALFRAME\\TutorialFrameBackground",
			edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
			tile = true, tileSize = height, edgeSize = 10,
			insets = { left = 2, right = 2, top = 2, bottom = 2 }
		})
		frame:SetHeight(height)
		frame:SetWidth(width)
		frame:SetPoint(relwhich, RTframe, relto, 0, 0)

		local iconframe = CreateFrame( "Frame", "MTCastframe"..RTframe:GetName(), frame )
		iconframe:SetPoint("LEFT", frame, "LEFT")
		iconframe:SetBackdrop({
			bgFile = spellTexture,
			edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
			tile = false, tileSize = height, edgeSize = 10,
			insets = { left = 1, right = 1, top = 1, bottom = 1 }
		})
		iconframe:SetHeight(height)
		iconframe:SetWidth(height)
		
		local labelframe = frame:CreateFontString(nil,"ARTWORK","GameFontNormal")
		labelframe:SetPoint("TOPLEFT", iconframe, "TOPRIGHT")
		labelframe:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT")
		labelframe:SetTextColor( 1, 1, 0, 1 );
		frame.SetText = function( self, msg )
			if( msg == '' ) then
				iconframe:SetBackdropColor(1,1,1,1)		
			else
				iconframe:SetBackdropColor(1,1,1,.5)	
			end
			labelframe:SetText(msg)
		end
		frame.SetIcon = function( self, icon )
			iconframe:SetBackdrop({
			bgFile = icon,
			edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
			tile = true, tileSize = height, edgeSize = 10,
			insets = { left = 1, right = 1, top = 1, bottom = 1 }
			})
		end
		
		return frame
	end

	layerFrame.createDesign = function ()
		mainFrame:SetHeight(96)
		mainFrame:SetWidth(64)
		local castwidth = 48
		local castheight = 16
		-- design fuer eliteFrame

		MoonTimeNextCastframe = layerFrame.CreateCastFrame( "", layerFrame, 32, 32, "TOP", "TOP")
		MoonTimeMoonfireframe = layerFrame.CreateCastFrame( "Interface\\Icons\\Spell_Nature_StarFall", MoonTimeNextCastframe, castheight, castwidth, "TOP", "BOTTOM")
		MoonTimeInsectswarmframe = layerFrame.CreateCastFrame( "Interface\\Icons\\Spell_Nature_InsectSwarm", MoonTimeMoonfireframe, castheight, castwidth, "TOP", "BOTTOM")

	end
	

	layerFrame.deleteDesign = function()
		MoonTimeNextCastframe:Hide()
		MoonTimeNextCastframe = nil
		MoonTimeMoonfireframe:Hide()
		MoonTimeMoonfireframe = nil
		MoonTimeInsectswarmframe:Hide()
		MoonTimeInsectswarmframe = nil
		
		layerFrame:Hide()
		layerFrame = nil
	end

	return layerFrame
end

-- ****************************************
--
-- DO NOT CHANGE ANYTHING BELOW THIS 
--
-- ****************************************

local function registerDesign( name )									-- Beginn initialize
	local designFrame
	local frame = CreateFrame( "Frame", name, UIPARENT	)
	frame.ID = name
	frame:RegisterEvent("VARIABLES_LOADED");
	frame:SetScript("OnEvent", 
		function( self, event )
			if event=="VARIABLES_LOADED" then							-- falls das ausloesende Event VARIABLES_LOADED ist ...
																		-- werden die ausstehenden Events registriert
				MoonTimeDoorKeeper:RegisterDesign(this);
			end
		end
	)
	
	frame.createDesign = function( this ) 
		designFrame = design(this.Mainframe, this.Objectframe)
		designFrame:createDesign()
	end

	frame.Hide = function()
		designFrame:Hide()
	end
	frame.Show = function()
		designFrame:Show()
	end
	frame.Update = function()
		designFrame:Update()
	end

	frame.deleteDesign = function()
		designFrame:deleteDesign()
	end
end																		-- Ende initialize

registerDesign(NameOfDesign)