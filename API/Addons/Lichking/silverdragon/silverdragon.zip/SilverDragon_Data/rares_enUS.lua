-- This is a pure fall-through table. Anything you give it, it'll accept.
-- There's not anything stopping me writing out all the mob names here, too... but it seems pointless.
local L = LibStub("AceLocale-3.0"):NewLocale("SilverDragon_Rares", "enUS", true, true)
if not L then return end

