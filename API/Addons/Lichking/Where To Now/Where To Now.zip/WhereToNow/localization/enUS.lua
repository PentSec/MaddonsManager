﻿--[[
	Where To Now?
	English Localization File
	Version alpha
]]
local L = LibStub("AceLocale-3.0"):NewLocale("WTN","enUS",true)

L["WTN_TITLE"] = "Where To Now?";
L["WTN_VERSION"] = "Версия";
L["WTN_NOWLOADED"] = "сейчас загружен!";
L["WTN_ERROR"] = "Ошибка";
L["WTN_DEBUG"] = "Сообщение для исправления";
L["WTN_TOOLTIP"] = "Найдите где находятся мобы вышего уровня.";
L["WTN_NONE"] = "Нет";

L["WTN_REC_CURRENT_ZONE"] = "Текущая Зона: ";
L["WTN_REC_CURRENT_INSTANCE"] = "Текущее подземелье: ";
L["WTN_REC_ZONES"] = "Зоны: ";
L["WTN_REC_INSTANCES"] = "Подземелья: ";
L["WTN_REC_ZONES_FOR_LEVEL"] = "Зоны для уровня ";
L["WTN_REC_INSTANCES_FOR_LEVEL"] = "Подземелья для уровня ";
L["WTN_REC_NONE"] = "Не могу найти зоны или подземелья подходящее вашему уровню.";
L["WTN_ERROR_WRONGCMDORDERWHISPER"] = "Команда которую вы ввели была не в правильном порядке . Нужно так: <уровнь> <канал> <имя игрока>.";

L["WTN_MSG_WTNREPORT_START"] = "Where To Now? отчет для уровня ";
L["WTN_MSG_WTNREPORT_END "]= ":";

-- Slash commands
L["WTN_CMD_SLASH1"] = "/WTN";
L["WTN_CMD_SLASH2"] = "/where2now";
L["WTN_CMD_SLASH3"] = "/w2n";
L["WTN_CMD_SLASH4"] = "/wtn";