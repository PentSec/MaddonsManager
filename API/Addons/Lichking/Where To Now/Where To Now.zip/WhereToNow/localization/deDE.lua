--[[
	Where To Now?
	German Localization File
	Version alpha
]]

--== German Locale ==--
--Note: �=\195\164, �=\195\188, �=\195\182, �=\195\132, �=\195\156, �=\195\150, �=\195\159
local L = LibStub("AceLocale-3.0"):NewLocale("WTN","deDE",false)

L["WTN_NOWLOADED"] = "wurde gestartet!";
L["WTN_ERROR"] =  "Fehler";
L["WTN_DEBUG"] ="Debug-Nachricht";
L["WTN_TOOLTIP"] = "Findet zu deinem Level die passenden Gegner.";
L["WTN_NONE"] = "Keine";

L["WTN_REC_CURRENT_ZONE"] = "Gegenw�rtige Zonen: ";
L["WTN_REC_CURRENT_INSTANCE"] = "Gegenw�rtige Instanzen: ";
L["WTN_REC_ZONES"] = "Zonen: ";
L["WTN_REC_INSTANCES"] = "Instanzen: ";
L["WTN_REC_ZONES_FOR_LEVEL"] = "Zonen f\195\188r Level ";
L["WTN_REC_INSTANCES_FOR_LEVEL"] = "Instanzen f\195\188r Level ";
L["WTN_REC_NONE"] = "Keine zu deinem Level passenden Zonen oder Instanzen gefunden.";
L["WTN_ERROR_WRONGCMDORDERWHISPER"] = "Die Aufruffparameter wurden in falscher Reihenfolge eingegeben. Die Reihenfolge lautet <Level> <Kanal> <Spielername>.";

L["WTN_MSG_WTNREPORT_START"] = "Where To Now? Informationen f\195\188r Level ";

