--[[
	Zone/Instance Database
	Version alpha
]]

WhereToNowDatabaseRaid = {
	[WTN_RAID_UPPERBLACKROCKSPIRE] = {
		["Expan"] = 0,
		["zone"] = WTN_ZONE_BURNINGSTEPPS,
		["size"] = 10,
		["limit"] = 45,
		["min"] = 56,
		["max"] = 70,
	},
	[WTN_RAID_ZULGURUB] = {
		["Expan"] = 0,
		["zone"] = WTN_ZONE_STRANGLETHORNVALE,
		["size"] = 25,
		["limit"] = 50,
		["min"] = 56,
		["max"] = 70,
	},
	-- Burning Crusade
	[WTN_RAID_KARAZHAN] = {
		["Expan"] = 1,
		["zone"] = WTN_ZONE_DEADWINDPASS,
		["size"] = 10,
		["limit"] = 68,
		["min"] = 70,
		["max"] = 74,
	},
	-- Lich King
	[WTN_RAID_EYEOFETERNITY] = {
		["Expan"] = 2,
		["zone"] = WTN_ZONE_BOREANTUNDRA,
		["size"] = 10,
		["limit"] = 80,
		["min"] = 80,
		["max"] = 80,
	},
}