*---------------------------------------*
|	Where to Now			|
|	Version 1.6			|
|					|
|	by Jehris & Kjasi		|
*---------------------------------------*

A little tool for quick recommendation of zones and instances at your level. No bugs are currently known, so feel free to e-mail me if any are found!

Console Commands:
	/wheretonow
	/where2now
	/wtn
	/w2n

Command Options:
Here are the available commandlines. <Name> denotes a required value, while [Name] denotes an optional value.
	<Level> [Channel] [Player]: Outputs information on the level used. If channel is used, will send the message like that.
		Channel Values: say, party, raid, yell, guild & whisper. Player is needed for whisper.
	Minimap [on/off]: Toggles the minimap button. If specified "on" or "off" then will set the minimap on or off.
	Min Level <On/Off>: Turns on the displaying of the minimum level for instances. This will also show instances as soon as you can enter them.
	Tooltip Color <On/Off>: Turns on and off the tooltip coloring.
	Sort <Name/Min/Max>: Will change the sorting method to Alphabetically, by Minimum Level (Default), or by Maximum Level.
	Sort <Expansion/Expan/Xpan> [Min/Max/Min Level/Min Lvl/MinLvl [Min/Max]]: This will allow you to sort Zones and instances alphabetically by which expansion they came with. Additionally, you can sort by Expansion, then by minimum or maximum level.
	Sort <Min Level/Min Lvl/MinLvl> [Min/Max/Expansion [Min/Max]]: Sort by the minimum level to enter the instance. Will sort by name by default.

-=Version History=-
Version 2.0.0 beta
 - Updated Database
 - localizing of zones via LibBabble-Zone-3.0
 - reorganized addon structure

Version 1.6
 - Updated WotLK Database to 100% accurate!
 - Added Minlvl to Expansion sorting.
 - The commandline will now properly display all the instances when there are many many instances to list.
 - Now supports the German Client! Thanks to Raphael Bossek for the translations!

Version 1.5
 - Added a Shameless plug at the beginning of every announced report.
 - Added several command options.
 - You can now activate the minimum level, allowing you to see when you can enter an instance.
 - Added optional tooltip coloring!
 - Did some spelling/grammar fixes.
 - Database Update for Lich King! 95% accurate!

Version 1.4:
 - Updated for Patch 3.0.2
 - Preliminary Lich King data entered into the database.
 - Added Expansion sorting.

Version 1.3:
 - Fixed a bug that would hide certain zones from the Tooltip, but not the commandline/button press.
 - Added Sorting function! Commandline values: Name, Min, Max. Defaults to Min.

Version 1.2:
 - Added Level function to commandline.
 - Added Minimap button toggling and specific mode to the commandline.
 - New Minimap icon.
 - Right-Clicking Minimap Button will now hide the button.

Version 1.1:
 - Database update!
 - Fixed a bug that wouldn't show all the zones and instances available.
 - Changed Tooltip level display to not show the maximum level if it matches the minimum level.
 - Increased localization.

Version 1:
 - Initial Version

Contact Information:
	Jehris (lucius_arconis@yahoo.com)
	Kjasi (sephiroth3d@gmx.net)