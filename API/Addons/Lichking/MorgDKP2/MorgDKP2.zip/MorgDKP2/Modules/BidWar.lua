local mod = MorgDKP2:NewModule("BidWar", "AceComm-3.0", "AceSerializer-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.BidWar

local mdkp = MorgDKP2

mod.modName = LL["BidWar"]
mod.modref = "BidWar"

local Player = UnitName("player")
local db
local fmt = string.format

local defaults = { 
	profile = {
		bidstep = 5,
		overbid = 50,
		silent = nil,
		justenough = nil
	},
}

local options = {
		bidwarenable = {
			type = "toggle",
			name = LL["BidWar"],
			desc = LL["BidWar mode changes the MorgBid query to allow players to bid on items.  Also the MorgDKP tablet uses bids after this NOT member DKP."],
			get = function() return mdkp.db.profile.modules.BidWar end,
			set = 	function(info, v) 
					mdkp.db.profile.modules.BidWar = v
					if v then 
						mod:Enable()
						mod:debug("Enabled BidWar")
					else
						mod:Disable()
						mdkp:debug("Disabled BidWar")
					end
				end,
			order = 50
		},
		bidwarhead = {
			type = "header",
			name = LL["BidWar Options"],
			hidden = function() return not mdkp.db.profile.modules.BidWar end,
			order = 200
		},
		silent = {
			type = "toggle",
			name = LL["Silent auction"],
			desc = LL["Enable BidWar mode with only one round of bidding and no reporting to raid chat."],
			get = function() return mod.db.profile.silent end,
			set = function(info, v) mod.db.profile.silent = v end,
			hidden = function() return not mdkp.db.profile.modules.BidWar end,
			order = 210
		},
		jenough = {
			type = "toggle",
			name = LL["Just enough"],
			desc = LL["Enable BidWar mode where the winner is charged the 2nd highest bid value for the item."],
			get = function() return mod.db.profile.justenough end,
			set = function(info, v) mod.db.profile.justenough = v end,
			hidden = function() return not mdkp.db.profile.modules.BidWar end,
			order = 215
		},
		bwbidstep = {
			type = "range",
			name = LL["Bidstep"],
			desc = LL["Changes the DKP step for BidWar mode.  Passes this value to MorgBid2 clients."],
			get = function() return mod.db.profile.bidstep end,
			set = function(info, v) mod.db.profile.bidstep = v end,
			min = 1, 
			max = 100, 
			step = 1,
			hidden = function() return not mdkp.db.profile.modules.BidWar end,
			order = 220
		},
		bwoverbid = {
			type = "range",
			name = LL["Overbid"],
			desc = LL["Maximum amount of DKP that members can exceed their current DKP."],
			get = function() return mod.db.profile.overbid end,
			set = function(info, v) mod.db.profile.overbid = v end,
			min = 0, 
			max = 500, 
			step = 1,
			hidden = function() return not mdkp.db.profile.modules.BidWar end,
			order = 225
		},
}

function mod:GetOptions()
	return options
end

function mod:GetName()
	return mod.modName, mod.modref
end

function mod:IsDKP()
	return true
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("BidWar", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
	db.moduleON["BidWar"] = true
	self.MaxBid = {}
	self.BidWarDone = nil
	self.master = {}
	self:CheckConflicts()
end

function mod:OnDisable()
	db.moduleON["BidWar"] = nil
	local currdkp = self:GetModuleRef(db.currDKP)
	if currdkp then db.dkpstatustext = currdkp:GetName()
	else db.dkpstatustext = L["Not Set"] end
	self:ToggleFrameUpdate("TooltipLDB")
end

function mod:CheckConflicts()
	local currconflicts = mdkp.bidwarconflicts
	local isconflict
	for _, conflictname in pairs(currconflicts) do
		if db.modules[conflictname] then 
			local conflict = MorgDKP2:GetModule(conflictname)
			conflict:Disable()
			db.modules[conflictname] = nil
			self:debug("Disabled module.."..conflictname.." due to conflict")
			isconflict = true
			db.currDKP = nil
			break
		end
	end
	if isconflict then
		db.currDKP = nil
		self:IsDKPEnabled()
		db.dkpstatustext = "Fixed DKP & BidWar"
	else 
		if not string.find(db.dkpstatustext, "&") then db.dkpstatustext = db.dkpstatustext .. " & " .. LL["BidWar"] end
	end
	self:ToggleFrameUpdate("TooltipLDB")
end

function mod:StartAuction(id, itempoints, queries, link, mbidtable)
	self:AtStartQuery(id, queries)
	self:SendMessage(id, itempoints, queries, link, mbidtable)
end

function mod:AtStartQuery(id, queries)
	self.MaxBid[id] = 0
	self.BidWarDone = nil
	self.master[id] = true
	if self:PlayerIncluded(queries) then self.master[id] = nil end
end

function mod:PlayerIncluded(dkp)
	for i, v in pairs(dkp) do
		if v[1].n == Player then
			return true
		end
	end
	return false
end

function mod:SendMessage(id, itempoints, data, link, mbidtable)
	self:SendCommMessage("MorgBid2", self:Serialize("BIDWAR", id, itempoints, data, db.quality, self.db.profile.bidstep, self.db.profile.overbid, self.db.profile.silent, link, db.mbidupdating, mbidtable), "RAID")
end

function mod:StartOutput(link, id, itempoints) 
	SendChatMessage(fmt(LL["Beginning auction for %s:  ID = %s"], link, id), "RAID")
	SendChatMessage(fmt(LL["Bid Format = mbid [ID/link] [%s/%s/%s] [bid value]"], db.NEED, db.TAKE, db.PASS), "RAID")
end

function mod:OnBidMessage(bid, sender, item, action)
	local POOL = self:CheckPool(item)
	local overbid = db.info[sender][POOL].points + self.db.profile.overbid
	if overbid < 0 then overbid = self.db.profile.overbid end
	if bid > overbid then
		bid = overbid
		SendChatMessage(fmt(LL["You have exceeded the overbid amount of %s.  Your bid has been reset to the maximum."], self.db.profile.overbid), "WHISPER", nil, sender)
	end
	if mdkp.AuctionStatus[item] then
		if bid > self.MaxBid[item] then
			self.MaxBid[item] = bid
			self:BidWarQueryNeeded(item, sender, POOL, bid, nil, action)
		elseif bid == self.MaxBid[item] then
			self:BidWarQueryNeeded(item, sender, POOL, bid, true, action)
		end
	end
	return bid
end

function mod:OnOutputResluts(itemid, clickedwinner)
	SendChatMessage(LL["Bidding is now closed."], "RAID")
	
end

function mod:BidWarQueryNeeded(id, bidder, POOL, bid, tied, action)
	if action == "OFFSPEC" then 
		for i,v in pairs(mdkp.querytooltips[id]) do
			if v[1].n == bidder then 
				v[3].n = 0 
				break
			end
		end
		return
	end
	
	db.items[id].points = bid
	if self.db.profile.silent then return end
	local _, Link, _, _, _, _, _, _,_, _ = GetItemInfo(id)
	if not tied then 
		SendChatMessage(fmt(LL["New high bidder for %s: %s = %s"], Link, bidder, bid), "RAID")
	end
		
	--send new queries to needed members
	for i,v in pairs(mdkp.querytooltips[id]) do
		if v[1].n == bidder then 
			v[3].n = bid
			v[5] = db.info[v[1].n][POOL].points
			if tied then v[2] = "PENDING" end
		elseif v[2] == "NEED" or v[2] == "TAKE" then
			v[2] = "PENDING"
			v[5] = db.info[v[1].n][POOL].points
		end
	end
	local mbidtable = nil
	if db.mbidcustom then mbidtable = mdkp.statustext end
	self:SendCommMessage("MorgBid2", self:Serialize("BIDWAR", id, self.MaxBid[id] + self.db.profile.bidstep, mdkp.querytooltips[id], db.quality, self.db.profile.bidstep, self.db.profile.overbid, self.db.profile.silent, link, db.mbidupdating, mbidtable), "RAID")
end

function mod:GetItemValue(itemid, winner)
	local query = mdkp.querytooltips[itemid]
	local itempoints
	if self.db.profile.justenough then
		for num, data in ipairs(query) do
			if data[2] ~= "PASS" and data[2] ~= "PENDING" then
				if winner == data[1].n then
					if query[num + 1] and (query[num + 1][2] ~= "PASS" and query[num + 1][2] ~= "PENDING") then itempoints = query[num + 1][3].n
					else itempoints = 0 end
					if itempoints == 0 or itempoints > query[num][3].n then itempoints = query[num][3].n end
					break
				end
			end
		end
		mdkp.querytooltips[itemid][1][3].n = itempoints
	else 
		if winner ~= query[1][1].n then
			for num, data in pairs(query) do
				if data[1].n == winner then
					itempoints = query[num][3].n
					break
				end
			end
		else itempoints = query[1][3].n
		end
	end
	if not itempoints then itempoints = 0 end
	db.items[itemid].points = itempoints
	return itempoints, self.db.profile.silent
end

function mod:OnBidWhisper(sender, item, reply, bid)
	bid = tonumber(bid)
	if bid and bid > 0 then
		local POOL = self:CheckPool(item)
		for i,v in ipairs(mdkp.querytooltips[item]) do
			if v[1].n == sender then
				if self.db.profile.silent and v[3].n ~= 0 then
					SendChatMessage(LL["Sorry this is a silent auction and you have already placed your bid."], "WHISPER", nil, sender)
					return
				end
				v[2] = reply
				local overbid = db.info[sender][POOL].points + self.db.profile.overbid
				if bid > overbid then
					bid = overbid
					SendChatMessage(fmt(LL["You have exceeded the overbid amount of %s.  Your bid has been reset to the maximum."], self.db.profile.overbid), "WHISPER", nil, sender)
				end
				v[3].n = bid
				if bid > self.MaxBid[item] then
					self.MaxBid[item] = bid
					SendChatMessage(fmt(L["Your response has been accepted: %s"], bid), "WHISPER", nil, sender)
					self:BidWarQueryNeeded(item, sender, POOL, bid, nil, reply)
				elseif bid == self.MaxBid[item] then
					SendChatMessage(fmt(L["Your response has been accepted: %s"], bid), "WHISPER", nil, sender)
					self:BidWarQueryNeeded(item, sender, POOL, bid, true, reply)
				end
			end
		end
	end
end

function mod:ItemRecorded(itemId)
	db.items[itemId].points = 0
end
