local mod = MorgDKP2:NewModule("Whisper")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.Whisper

local mdkp = MorgDKP2
mod.modName = "Whisper"

local Player = UnitName("player")
local db
local fmt = string.format

local defaults = { 
	profile = {
		
	},
}

function mod:GetOptions()
	return nil
end

function mod:IsDKP()
	return nil
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("Whisper", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
	db.moduleON["Whisper"] = true
end

function mod:OnDisable()
	db.moduleON["Whisper"] = nil
						
end

function mod:SendStartMessage(id, link, itempoints, name)
	SendChatMessage(fmt(LL["%s: ID = %s  DKP/Bid value = %s  (Reply format: mbid ID [%s/%s/%s/%s bid value])"], link, id, itempoints, db.NEED, db.TAKE, db.OFFSPEC or "", db.PASS), "WHISPER", nil, name)
end
