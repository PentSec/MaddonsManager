local mod = MorgDKP2:NewModule("PointsDB")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.PointsDB
local BCR = LibStub("LibBabble-Class-3.0"):GetReverseLookupTable()

local mdkp = MorgDKP2
mod.modName = "PointsDB"

local db
local band = bit.band
local bor = bit.bor
local bxor = bit.bxor
local fmt = string.format
local upper = string.upper
local rankdata = {}
local ignorelinks = {}
local dbversion = 1.1

local defaults = { 
	profile = {
		culllvl = 200, 
		memculllvl = 4,
		DBversion = nil,
   	},
}

local options = {
		type = "group",
		handler = mod,
		name = LL["Database Functions"],
		desc = LL["Database Functions"],
		order = 200,
		args = {
			clearraiddb = {
				type = "execute",
				name = LL["Clear raid DB"],
				desc = LL["Clears the current tracked raids."],
				func = function() mod:ClearRaidDB() end,
				disabled = function() return not mod:IsEnabled() end,
				order = 1
			},
			clear = {
				type = "execute",
				name = LL["Clear player DB"],
				desc = LL["Clears all players currently in the database. Does not affect items."],
				func = function() mod:ClearDatabase() end,
				disabled = function() return not mod:IsEnabled() end,
				order = 3
			},
			zeroplayerdb = {
				type = "execute",
				name = LL["Zero player DB"],
				desc = LL["Resets all members DKP to zero."],
				func = function() mod:ZeroPLayerDB() end,
				disabled = function() return not mod:IsEnabled() end,
				order = 4
			},
			head = {
				type = "header",
				name = "",
				order = 6
			},
			additem = {
				type = "input",
				name = LL["Add item"],
				desc = LL["Add new item to track.  Drag the item to this input box."],
				set = 	function(info, v) mod:AddNewItem(v) end,
				order = 8
			},
			desc = {
				type = "description",
				name = "",
				order = 9
			},
			cullllvl = {
				type = "range",
				name = LL["Cull item level"],
				get = function() return mod.db.profile.culllvl end,
				set = 	function(info, v) mod.db.profile.culllvl = v end,
				min = 2, 
				max = 300, 
				step = 1,
				hidden = function() return not mod:IsEnabled() end,
				order = 10
			},
			cullitemdb = {
				type = "execute",
				name = LL["Cull item DB"],
				desc = LL["Clears all items in the database below the selected item level."],
				func = function() mod:CullItemDatabase() end,
				disabled = function() return not mod:IsEnabled() end,
				order = 15
			},
			desc2 = {
				type = "description",
				name = "",
				order = 16
			},
			cullmemllvl = {
				type = "range",
				name = LL["Cull member level (weeks)"],
				get = function() return mod.db.profile.memculllvl end,
				set = 	function(info, v) mod.db.profile.memculllvl = v end,
				min = 1, 
				max = 16, 
				step = 1,
				hidden = function() return not mod:IsEnabled() end,
				order = 17
			},
			cullmemberdb = {
				type = "execute",
				name = LL["Cull member DB"],
				desc = LL["Clears all members in the database inactive longer than the selected number of weeks."],
				func = function() mod:CullMemberDatabase() end,
				disabled = function() return not mod:IsEnabled() end,
				order = 18
			},
			head2 = {
				type = "header",
				name = "",
				order = 20
			},
			ignore = {
				type = "select",
				name = LL["Ignored items"],
				desc = LL["List of currently ignored items.  Click to remove item from ignore list."],
				get = false,
				set = function(info, v) mod:RemoveItemLink(v) end,
				values = function() return mod:GetIgnoredItemLinks() end,
				disabled = function() return not mod:IsEnabled() end,
				order = 50
			},
			addignore = {
				type = "input",
				name = LL["Add ignored item"],
				desc = LL["Add new item to ignore.  Drag the item to this input box."],
				set = 	function(info, v) mod:AddNewIgnoreItem(v) end,
				order = 51
			},
			head3 = {
				type = "description",
				name = "\n",
				order = 52
			},
			ranks = {
				type = "select",
				name = LL["Rank weights"],
				desc = LL["List of member ranks in the current pool."],
				get = function() return mdkp.db.profile.editrank end,
				set = function(info, v) mdkp.db.profile.editrank = v end,
				values = function() return mod:GetRankValues() end,
				hidden = function() return not mod:IsEnabled() or not mdkp.db.profile.useranks or not mdkp.db.profile.useranks[mdkp.db.profile.raid] end,
				order = 55
			},
			rankslider = {
				type = "range",
				name = LL["Current rank weight"],
				desc = LL["Higher number for higher display priority. (7 will appear above 3 on the tooltip)"],
				get = function() return mod:GetRankWeight() end,
				set = function(info, v) mod:SetRankWeight(v) end,
				min = 1, 
				max = 10,
				step = 1,
				hidden = function() return not mod:IsEnabled() or not mdkp.db.profile.useranks or not mdkp.db.profile.useranks[mdkp.db.profile.raid] end,
				order = 60
			},
        	},
}

StaticPopupDialogs["ImportMorgItems"] = {
	text = TEXT(LL["Import default item database?"]),
	button1 = TEXT(YES),
	button2 = TEXT(NO),
	OnAccept = function()
		mod:ImportMorgItems()
	end,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1,
}

function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return nil
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("PointsDB", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
	db.moduleON["PointsDB"] = true
	if not db.DBversion or dbversion > db.DBversion then self:ConvertDB() end
	if MorgDKP2_Items then StaticPopup_Show ("ImportMorgItems") end	--import item db?
	self:ImportDKPInfoFile()
end

function mod:OnDisable()
	db.moduleON["PointsDB"] = nil
end

function mod:ClearDatabase()
	self:debug("Clear DB")
	db.info = { }
	self:out(LL["Player database cleared!"])
end

function mod:ConvertDB()
	local currtime = self:GetServerTime()
	local converted = 0
	db.Timestamp = time()
	
	for name, data in pairs(db.info) do
		db.info[name].lastupdate = currtime
		converted = converted + 1
	end
	if converted > 0 then
		self:out(fmt("Converted %s members to new format.", converted))
	end
	db.DBversion = 1.1
	self:ClearRaidDB()
end

function mod:ZeroPLayerDB()
	local POOL = self:GetPool()
	for name, data in pairs(db.info) do
		data[POOL] = {points = 0, earned = 0, spent = 0}
		data.lastupdate = self:GetServerTime()
	end
	self:out(LL["Player DKP reset to zero!"])
end

function mod:ClearRaidDB()
	local tracker = self:GetModuleRef("Tracker")
	if tracker then tracker:ClearRaidDB(true) end
end

function mod:AddNewItem(itemlink)
	if not itemlink or itemlink == "" then return end
	local _,_, item = string.find(itemlink, "item:(%d+):")
	item = tonumber(item)
	self:IteminDB(item)
	self:out(fmt(LL["Addeded %s to item database."], itemlink))
end

function mod:GetRankValues()
	if not db.useranks or not db.useranks[db.raid] then return {"NONE"} end
	rankdata = {}
	local index = 1
	for rank in pairs(db.ranks[db.raid]) do
		rankdata[index] = rank
		index = index + 1
	end
	return rankdata
end

function mod:GetRankWeight()
	if not db.useranks or not db.useranks[db.raid] or not db.editrank then return 1 end
	return db.ranks[db.raid][rankdata[db.editrank]]
end

function mod:SetRankWeight(weight)
	db.ranks[db.raid][rankdata[db.editrank]] = weight
end

function mod:GetIgnoredItemLinks()
	ignorelinks = {}
	for itemid in pairs(db.ignore) do
		local _, iLink = GetItemInfo(itemid)
		table.insert(ignorelinks, iLink)
	end
	return ignorelinks
end

function mod:RemoveItemLink(index)
	local removelink = ignorelinks[index]
	local _,_, itemId = string.find(removelink, "item:(%d+):")
	itemId = tonumber(itemId)
	db.ignore[itemId] = nil
end

function mod:AddNewIgnoreItem(itemlink)
	if not itemlink or itemlink == "" then return end
	local _,_, item = string.find(itemlink, "item:(%d+):")
	item = tonumber(item)
	db.ignore[item] = true
	self:out(fmt(LL["Addeded %s to item database."], itemlink))
end

function mod:ImportMorgItems()
	local itemcount = self:ImportItemDB(MorgDKP2_Items)
	self:out(fmt(LL["Database transfer complete. %s items were transferred and %s members updated."], itemcount, 0))
	self:out(LL["Please delete the ItemData.lua file from the MorgDKP directory now."])
	MorgDKP2_Items = nil
end

function mod:ImportItemDB(items)
	local itemcount = 0
	if not db.items then db.items = {} end
	for id, data in pairs(items) do
		if not db.items[id] then
			db.items[id] = data
			itemcount = itemcount + 1
		end
	end
	return itemcount
end

function mod:ImportDKPInfoFile()
	local db = mdkp.db.profile
	local temptable = {}
	local count = 1
	if not MorgDKP2_DKP1 and not db.raid then self:DefaultDKP() end
	if not MorgDKP2_DKP1 then return end
	for i = 1,5 do
		local dkp = getglobal("MorgDKP2_DKP" .. i)
		if dkp then temptable[count] =  dkp
			count = count + 1
		end
	end
	local skipupdate = 1
	local timestamp
	if not db.Timestamp or type(temptable[1].Timestamp) == "string" or type(db.Timestamp) == "string" or temptable[1].Timestamp > db.Timestamp then
		skipupdate = nil
		db.Timestamp = temptable[1].Timestamp
		timestamp =  self:GetServerTime()
		self:out(LL["Updating DKP Points.."])
	end
	if not skipupdate then
		db.eqDKP = { }
		db.raidlist = { }
		if not db.raid or db.raid == L["NONE"] or #temptable == 1 then db.raid = temptable[1].Pool end
		for i, dkpray in pairs(temptable) do
			if dkpray.Pool then
				db.raidlist[i] = dkpray.Pool
				db.eqDKP[dkpray.Pool] = { }
				db.eqDKP[dkpray.Pool]["eqDKPsite"] = dkpray.eqdkpsite
				db.eqDKP[dkpray.Pool]["prefix"] = dkpray.prefix
				if dkpray.Events then
					db.eqDKP[dkpray.Pool]["Events"] = { }
					for event, details in pairs(dkpray.Events) do
						db.eqDKP[dkpray.Pool]["Events"][event] = { }
						db.eqDKP[dkpray.Pool]["Events"][event] = { ["id"] = details.id, ["value"] = details.value}
					end
				end
				if dkpray.Ranks then
					local num = 1
					if not db.ranks[dkpray.Pool] then db.ranks[dkpray.Pool] = {} end
					for id, rank in pairs(dkpray.Ranks) do
						if not db.ranks[dkpray.Pool][rank] then db.ranks[dkpray.Pool][rank] = num end
						num = num + 1
					end
					db.useranks[dkpray.Pool] = true
				else
					db.useranks[dkpray.Pool] = nil
				end
				if dkpray.Aliases then
					db.eqDKP[dkpray.Pool]["Aliases"] = { }
					for alias, main in pairs(dkpray.Aliases) do
						db.eqDKP[dkpray.Pool]["Aliases"][alias] = main
						self:PlayerinDB(main)
						self:PlayerinDB(alias)
						local present = false
						if not db.info[main].aliases then db.info[main].aliases = { } end
						for numalias = 1 , #db.info[main].aliases do
							if db.info[main].aliases[numalias].alt == alias and db.info[main].aliases[numalias].raid == dkpray.Pool then
								present = true
							end
						end
						if not present then table.insert(db.info[main].aliases , {raid = dkpray.Pool, alt = alias}) end
					end
				end
			end
			if dkpray.Points then
				local count = 0
				for name, v in pairs(dkpray.Points) do
					if not db.info[name] then db.info[name] = { } end
					local earned, adjust, spent, balance = floor(v.earn * 100 + .5)/100, floor(v.adj * 100 + .5)/100, floor(v.spent * 100 + .5)/100, floor(v.bal * 100 + .5)/100
					db.info[name][dkpray.Pool] = {earned = earned + adjust, spent = spent, points = balance }
					if not db.info[name].class and v.class and v.class ~= "Unknown" then 
						local englishclass = BCR[v.class]
						if englishclass then
							db.info[name].class = upper(englishclass) 
						end
					end
					db.info[name].raidloot = 0
					db.info[name].lastupdate = timestamp
					if v.rank and v.rank ~= "NONE" then
						db.info[name].rank = v.rank
					end
					count = count + 1
					if db.info[name].aliases then
						for m = 1, #db.info[name].aliases do
							if db.info[name].aliases[m].raid == db.raid then
								local alt = db.info[name].aliases[m].alt
								local mainpoints = db.info[name][dkpray.Pool].points
								if not db.info[alt] then db.info[alt] = { } end
								db.info[alt][dkpray.Pool] = { 	points = mainpoints,
												earned = db.info[name][dkpray.Pool].earned,
												spent = db.info[name][dkpray.Pool].spent }
								db.info[alt].raidloot = 0
								db.info[alt].lastupdate = timestamp
								self:debug(fmt(LL["Added alias: %s of %s with %s DKP."], alt, name, mainpoints)) 
							end
						end
					end
				end
				self:out(fmt(LL["Added %s players from %s"], count, dkpray.Pool))
			end
		end
		MorgDKP2_DKP1 = nil
		MorgDKP2_DKP2 = nil
		MorgDKP2_DKP3 = nil
		MorgDKP2_DKP4 = nil
		MorgDKP2_DKP5 = nil
	end
	self:ToggleFrameUpdate("TooltipLDB", true)
end

function mod:DefaultDKP()
	local db = mdkp.db.profile
	local name = UnitName("player")
	local ttime = time()
	MorgDKP2_DKP1 = {
		Timestamp = ttime,
		Pool = L["NONE"],
		eqdkpsite = "aqdkp",
		prefix = "eqdkp_",
		Points = {
			[name] = {earn = 1397.00,spent = 405.00,adj = 0.00,bal = 992}
		},
		Aliases = {
			["TestAlias"] = name
		},
		Events = {
			["Void Reaver"] = {id = 77,value = 3.00}
		},
	}
end

function mod:CullItemDatabase()
	local cull = self.db.profile.culllvl
	local culled = 0
	for item, data in pairs(db.items) do
		local _, iLink, iQuality, itemLevel, _, _, _, _, _, _ = GetItemInfo(item)
		if itemLevel and itemLevel < cull then
			if iQuality ~= 4 or (iQuality == 4 and itemLevel ~= 80 and itemLevel ~= 1) then 
				self:debug("Removing "..iLink)
				db.items[item] = nil
				culled = culled + 1
			end
		end
	end
	if culled > 0 then
		self:out(fmt(LL["Removed %s items from the database."], culled))
	end
end

function mod:CullMemberDatabase()
	local cull = self.db.profile.memculllvl
	local year = date("%Y")
	local month = date("%m")
	local day = date("%d")
	local hour = date("%H")
	local min = date("%M")
	local months = floor(cull/4) 
	local days = (cull - (months * 4)) * 7
	month = month - months
	day = day - days
	if day < 1 then 
		day = day + 30
		month = month - 1
	end
	if month < 1 then 
		month = month + 12 
		year = year - 1
	end
	if strlen(day) < 2 then day = "0"..day end
	if strlen(month) < 2 then month = "0"..month end
	local calctime = year..month..day..hour..min
	--self:debug("Y: "..year.." M: "..month.." D: "..day.." H: "..hour.." min: "..min.." Total: "..calctime)
	local culled = 0
	for name, data in pairs(db.info) do
		if data.lastupdate < calctime then
			self:debug("Removing "..name.." from database")
			db.info[name] = nil
			culled = culled + 1
		end
	end
	if culled > 0 then
		self:out(fmt(LL["Removed %s members from the database."], culled))
	end
end
