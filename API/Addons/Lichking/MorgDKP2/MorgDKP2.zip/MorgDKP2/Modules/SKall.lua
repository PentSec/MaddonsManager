local mod = MorgDKP2:NewModule("SKall")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.SKall

local mdkp = MorgDKP2

mod.modName = LL["SKall DKP"]
mod.modref = "SKall"

local Player = UnitName("player")
local db
local fmt = string.format
local temptable = {}

local defaults = { 
	profile = {
		zeromode = nil,
		percent = 100,
	},
}

local options = {
		skalldkp = {
			type = "toggle",
			name = LL["SKall DKP"],
			desc = LL["Enable Suicide Kings spend all DKP."],
			get = function() return mdkp.db.profile.modules.SKall end,
			set = 	function(info, v) 
					mdkp.db.profile.modules.SKall = v
					mod:DKPChange(mod.modName)
			end,
			order = 20
		},
		skhead = {
			type = "header",
			name = LL["SKall Options"],
			hidden = function() return not mdkp.db.profile.modules.SKall end,
			order = 100
		},
		skzerotog = {
			type = "toggle",
			name = LL["Enable raid award"],
			desc = LL["Enables DKP removed from item winner to be awarded to raid members.  You must check use zerosum on the import webscript for website DKP to be correct."],
			get = function() return mod.db.profile.zeromode end,
			set = function(info, v) mod.db.profile.zeromode = v end,
			hidden = function() return not mdkp.db.profile.modules.SKall end,
			order = 110
		},
		skpercent = {
			type = "range",
			name = LL["% Member DKP"],
			desc = LL["Percent of member DKP to remove."],
			get = function() return mod.db.profile.percent end,
			set = function(info, v) mod.db.profile.percent = v end,
			min = 1, 
			max = 100, 
			step = 1,
			hidden = function() return not mdkp.db.profile.modules.SKall end,
			order = 120
		},
}

function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return true
end

function mod:GetName()
	return mod.modName, mod.modref
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("SKall", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile	
	db.moduleON["SKall"] = true
	
end

function mod:OnDisable()
	db.moduleON["SKall"] = nil
end

function mod:GetPlayerPoints(name, POOL, showearned)
	if showearned then return db.info[name][POOL].earned
	else return db.info[name][POOL].points end
end

function mod:GetItemValue(itemid, player, POOL)
	local itempoints = self:GetPlayerPoints(player, POOL) * self.db.profile.percent / 100
	itempoints = floor(self:GetTAKEModeValue(itemid, itempoints, player) * 100) / 100
	return itempoints
end

function mod:ItemRecorded(id, looter, POOL, points, itempoints, link, attendees, boss)
	if looter == L["Bank"] then return end
	points = points - itempoints
	self:AwardItem(id, looter, POOL, points, itempoints, link)
	
	if self.db.profile.zeromode then
		if not attendees then return end
		temptable = {}
		for _, name in pairs(attendees) do
			tinsert(temptable, name)
		end
	
		--add zero sum points
		if itempoints == 0 then return end
		addpoints = floor(itempoints / #temptable * 100) / 100
		self:AwardDKP(addpoints, 0, POOL, temptable)
	end
end

function mod:ItemRebate(id, looter, POOL, itempoints, link, oldattends, newattends, trashadjust, points)
	if not self.db.profile.zeromode then
		if looter ~= L["Bank"] and id then
			self:AdjustDKPPoints(looter, looter, POOL, nil, itempoints)
		end
	else
		if newattends then		--changing item event
			--remove points from old attendees
			if oldattends then
				local addpoints = floor(itempoints / #oldattends * 100) / 100 
				self:AwardDKP(0, addpoints, POOL, oldattends)
			end
		
			--add points to new attendees
			if looter == L["Bank"] then return end
			local addpoints = floor(itempoints / #newattends * 100) / 100  
			self:AwardDKP(addpoints, 0, POOL, newattends)
		else
			if trashadjust then
				local addpoints = floor(itempoints / #oldattends * 100) / 100 
				points = points - itempoints
				self:AwardItem(id, looter, POOL, points, itempoints, link)
				self:AwardDKP(addpoints, 0, POOL, oldattends)
			elseif oldattends and looter ~= L["Bank"] then
				local addpoints = floor(itempoints / #oldattends * 100) / 100 
				self:AwardDKP(0, addpoints, POOL, oldattends)
				self:AdjustDKPPoints(looter, looter, POOL, nil, itempoints)
			end
		end
	end
end

function mod:ItemAdjustment(id, looter, POOL, newcost, link, oldcost, attends)
	if not self.db.profile.zeromode or not attends or looter == L["Bank"] then return end
	local diff = oldcost - newcost
	local addpoints = floor(diff / #attends * 100) / 100 
	self:AwardDKP(0, addpoints, POOL, attends)
end

function mod:ItemTransfer(id, newmember, oldmember, POOL, newcost, link, oldcost)
	self:AdjustDKPPoints(newmember, oldmember, POOL, newcost, oldcost, link)
end

function mod:IsZeroMode()
	return self.db.profile.zeromode
end
