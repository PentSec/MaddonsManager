local mod = MorgDKP2:NewModule("SKSotC")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.SKSotC

local mdkp = MorgDKP2

mod.modName = LL["SKSotC DKP"]
mod.modref = "SKSotC"

local Player = UnitName("player")
local db
local fmt = string.format
local tinsert = table.insert
local tremove  = table.remove
local tsort = table.sort
local temptable = {}
local RAIDCHANGED

local defaults = { 
	profile = {
		dkporder = {},
		demodkp = 3,
		demoevent = "<zone> Raid Missed",
	},
}

local options = {
		skallSOTCdkp = {
			type = "toggle",
			name = LL["SKSotC DKP"],
			desc = LL["Enable Suicide Kings SotC variant DKP."],
			get = function() return mdkp.db.profile.modules.SKSotC end,
			set = 	function(info, v) 
					mdkp.db.profile.modules.SKSotC = v
					mod:DKPChange(mod.modName)
			end,
			order = 20
		},
		sksotchead = {
			type = "header",
			name = LL["SKSotC Options"],
			hidden = function() return not mdkp.db.profile.modules.SKSotC end,
			order = 100
		},
		sksotchead2 = {
			type = "description",
			name = "",
			hidden = function() return not mdkp.db.profile.modules.SKSotC end,
			order = 102
		},
		skdemoteevent = {
			type = "input",
			name = LL["Demotion event"],
			desc = LL["Format of event name:  \n<zone> text  \nExample:  <zone> DKP"],
			get = function() return mod.db.profile.demoevent end,
			set = function(info, v) if v then mod.db.profile.demoevent = v end end,
			hidden = function() return not mdkp.db.profile.modules.SKSotC end,
			order = 105
		},
		skdemotedkp = {
			type = "range",
			name = LL["Missed raid DKP"],
			desc = LL["Amount of DKP to remove from members who miss a raid."],
			get = function() return mod.db.profile.demodkp end,
			set = function(info, v) mod.db.profile.demodkp = v end,
			min = 0, 
			max = 100, 
			step = 1,
			hidden = function() return not mdkp.db.profile.modules.SKSotC end,
			order = 110
		},
		
		
}

function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return true
end

function mod:GetName()
	return mod.modName, mod.modref
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("SKSotC", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile	
	db.moduleON["SKSotC"] = true
	
end

function mod:OnDisable()
	db.moduleON["SKSotC"] = nil
end

function mod:AtRaidStart()
	self.db.profile.dkporder = {}
	RAIDCHANGED = true
end

function mod:AtMemberAdded()
	RAIDCHANGED = true
end

function mod:UpdateRaidIndex()
	local POOL = db.raid
	for name, group in pairs(mdkp.roster) do
		if group < 6 then
			if not self:IsIncluded(name) then
				tinsert(self.db.profile.dkporder, {name = name, dkp = db.info[name][POOL].points})
			end
		end
	end
	tsort(self.db.profile.dkporder, function (a, b) return a.dkp > b.dkp end)
	RAIDCHANGED = nil
end

function mod:IsIncluded(newname)
	for index, data in pairs(self.db.profile.dkporder) do
		if newname == data.name then return index, data.dkp end
	end
	return nil
end

function mod:GetPlayerPoints(name, POOL, showearned)
	if RAIDCHANGED then self:UpdateRaidIndex() end
	if showearned then return db.info[name][POOL].earned
	else return self:IsIncluded(name) or db.info[name][POOL].points end
end

function mod:GetItemValue(itemid, player, POOL)
	local db2 = self.db.profile
	local itempoints = self:GetPlayerPoints(player, POOL)
	itempoints = self:GetTAKEModeValue(itemid, itempoints, player) 
	return itempoints
end

function mod:ItemRecorded(id, looter, POOL, points, itempoints, link, attendees, boss)
	if looter == L["Bank"] then return end
	points = points - itempoints
	self:AwardItem(id, looter, POOL, points, itempoints, link)
	self:UpdateRaidIndex()
end

function mod:ItemRebate(id, looter, POOL, itempoints, link, oldattends, newattends, trashadjust, points)
	if looter ~= L["Bank"] and id then
		self:AdjustDKPPoints(looter, looter, POOL, nil, itempoints)
	end
	self:UpdateRaidIndex()
end

function mod:AtRaidEnd()
	--remove DKP from missing members
	local POOL = db.raid
	local penalty = self.db.profile.demodkp
	temptable = {}
	for name, data in pairs(db.info) do
		if not self:IsIncluded(name) then
			if data[POOL] then tinsert(temptable, name) end
		end
	end
	
	local eventname = self:GetEventName(nil, self.db.profile.demoevent)
	if self.db.profile.demodkp ~= 0 then
		if not db.dkpevents then
			self:AwardWaitotimeDKP(-self.db.profile.demodkp, POOL, eventname, temptable, "Group", "Group")
		else
			local tracker = self:GetModuleRef("Tracker")
			if tracker then tracker:LogBossKill(time(), eventname, true, eventname, nil, 3, temptable, -self.db.profile.demodkp) end
		end
		self:AwardDKP(nil, -self.db.profile.demodkp, POOL, temptable, nil, true)
	end
end
