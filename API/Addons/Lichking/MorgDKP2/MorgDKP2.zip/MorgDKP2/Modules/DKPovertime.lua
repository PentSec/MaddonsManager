local mod = MorgDKP2:NewModule("DKPovertime", "AceTimer-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.DKPovertime

local mdkp = MorgDKP2
mod.modName = "DKP/time"
mod.modref = "DKPovertime"

local db
local Player = UnitName("player")
local tinsert = table.insert
local fmt = string.format
local attendees = { }

local defaults = { 
	profile = {
		dkpamount = 1,
		dkpsched = 1800,
		otimename = "<zone> DKP"
	},
}

local options = {
		timedkpenable = {
			type = "toggle",
			name = LL["DKP/time"],
			desc = LL["DKP/time system which allows you to award DKP at custom intervals."],
			get = function() return mdkp.db.profile.modules.DKPovertime end,
			set = 	function(info, v) 
					mdkp.db.profile.modules.DKPovertime = v
					if v then 
						mod:Enable()
						mod:debug("Enabled DKPovertime")
					else
						mod:Disable()
						mdkp:debug("Disabled DKPovertime")
					end
				end,
			order = 55
		},
		dkptimehead = {
			type = "header",
			name = LL["DKP/time Options"],
			hidden = function() return not mdkp.db.profile.modules.DKPovertime end,
			order = 400
		},
		dkpamount = {
			type = "range",
			name = LL["Award amount"],
			get = function() return mod.db.profile.dkpamount end,
			set = function(info, v) 
					mod.db.profile.dkpamount = v
			end,
			min = 1, 
			max = 1000, 
			step = 1,
			hidden = function() return not mdkp.db.profile.modules.DKPovertime end,
			order = 410
		},
		dkptime = {
			type = "range",
			name = LL["Award time"],
			desc = LL["Time in minutes between DKP awards."],
			get = function() return floor(mod.db.profile.dkpsched / 60) end,
			set = function(info, v) 
					mod.db.profile.dkpsched = floor(v * 60) 
					mod:StopTimer()
					mod:RestartTimer()
			end,
			min = 1, 
			max = 200, 
			step = 1,
			hidden = function() return not mdkp.db.profile.modules.DKPovertime end,
			order = 415
		},
		dkpotimename = {
			type = "input",
			name = LL["DKP/time event name"],
			desc = LL["Format of event name:  \n<zone> text  \nExample:  <zone> DKP"],
			get = function() return mod.db.profile.otimename end,
			set = 	function(info, v) if v then mod.db.profile.otimename = v end end,
			hidden = function() return not mdkp.db.profile.modules.DKPovertime or not mdkp.db.profile.dkpevents end,
			order = 420
		},
}

function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return true
end

function mod:GetName()
	return mod.modName, mod.modref
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("DKPovertime", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
	
	db.moduleON["DKPovertime"] = true
	self:RestartTimer()
end

function mod:OnDisable()
	db.moduleON["DKPovertime"] = nil
	self:StopTimer()
end

function mod:AtRaidStart()
	self:debug("Raidstart DKPovertime")
	self:RestartTimer()
end

function mod:AtRaidEnd()
	self:StopTimer()
end

function mod:StopTimer()
	self:CancelTimer(self.timer, true) 
	self.timer = nil
end

function mod:RestartTimer()
	if db.InRaid then
		self:debug("DKP/time event ON")
		self.timer = self:ScheduleRepeatingTimer("RecurrentReward", self.db.profile.dkpsched)
	end
end

function mod:RecurrentReward()
	self:debug("DKP/time reward")
	if not db.InRaid then return end 
	
	local POOL = db.raid
	local award = self.db.profile.dkpamount
	local currtime = time()
	local ZoneName = GetRealZoneText()
	attendees = {}
	local counter = 0
	local Runname = db.raidlog[db.raidnum].bosskills[self:GetEventID(2)].note
	local wait = self:GetModuleRef("Waitlist")
	local waitmembers
	if wait and wait.db.profile.waitotime == award then waitmembers = wait:GetWaitlist() end
	
	for name in pairs(mdkp.roster) do
		local testtime = db.raidlog[db.raidnum].join[name]
		if currtime - testtime >= self.db.profile.dkpsched then
			tinsert(attendees, name)
			counter = counter + 1
			if not db.dkpevents then
				db.info[name][POOL].points = db.info[name][POOL].points + award
				db.info[name][POOL].earned = db.info[name][POOL].earned + award
			end
		end
	end
	if waitmembers then
		for _, name in pairs(waitmembers) do
			if not self:IsRewarded(name) then
				tinsert(attendees, name)
				counter = counter + 1
			end
		end
	end
	
	if counter > 0 then
		if not db.dkpevents then
			self:AwardWaitotimeDKP(award, POOL, Runname, attendees, "Group", "Group")
			self:out(fmt(LL["Added %s DKP to %s attendees."], award, counter))
			if wait and not waitmembers then wait:AwardWaitlistDKPperTime(POOL, currtime, ZoneName, Runname, self.db.profile.dkpsched) end
		else
			local tracker = self:GetModuleRef("Tracker")
			if not self.db.profile.otimename then self.db.profile.otimename = "<zone> DKP" end
			local eventname = self:GetEventName(ZoneName, self.db.profile.otimename)
			if tracker then tracker:LogBossKill(currtime, eventname, true, eventname, nil, 3, attendees, award) end
			if wait and not waitmembers then wait:AwardWaitlistDKPperTimeEvent(POOL, currtime, ZoneName, Runname, self.db.profile.dkpsched) end
			local sync = self:GetModuleRef("Syncing")
			if sync then sync:CustomEvent(eventname) end
		end
	end
end

function mod:IsRewarded(name)
	for _, onname in pairs(attendees) do
		if onname == name then return true end
	end
	return false
end
