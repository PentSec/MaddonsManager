local mod = MorgDKP2:NewModule("Zerosum")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.Zerosum

local mdkp = MorgDKP2

mod.modName = LL["Zerosum DKP"]
mod.modref = "Zerosum"

local Player = UnitName("player")
local db
local fmt = string.format
local floor = math.floor
local tinsert = table.insert
local zeroattends = {}

local defaults = { 
	profile = {
		usewait = nil,
	},
}

local options = {
		zerodkp = {
			type = "toggle",
			name = LL["Zerosum DKP"],
			desc = LL["Standard zero sum system where member is charged for the item and the charged points are divided between all raid members.  You must check use zerosum on the import webscript for website DKP to be correct."],
			get = function() return mdkp.db.profile.modules.Zerosum end,
			set = 	function(info, v) 
					mdkp.db.profile.modules.Zerosum = v
					mod:DKPChange(mod.modName)
			end,
			order = 40
		},
		zerohead = {
			type = "header",
			name = LL["Zerosum Options"],
			hidden = function() return not mdkp.db.profile.modules.Zerosum end,
			order = 100
		},
		waitlist = {
			type = "toggle",
			name = LL["Include waitlist"],
			desc = LL["Include waitlist members in DKP calculations.  Note they will still get whatever DKP award is set in the waitlist module."],
			get = function() return mod.db.profile.usewait end,
			set = function(info, v) mod.db.profile.usewait = v end,
			hidden = function() return not mdkp.db.profile.modules.Zerosum end,
			order = 110
		},
}

function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return true
end

function mod:GetName()
	return mod.modName, mod.modref
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("Zerosum", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
	db.moduleON["Zerosum"] = true
	
end

function mod:OnDisable()
	db.moduleON["Zerosum"] = nil
end

function mod:GetPlayerPoints(name, POOL, showearned)
	if showearned then return db.info[name][POOL].earned
	else return db.info[name][POOL].points end
end

function mod:GetItemValue(itemid, player, POOL)
	local itempoints = db.items[itemid].points
	itempoints = floor(self:GetTAKEModeValue(itemid, itempoints, player) * 100) / 100
	return itempoints
end

function mod:ItemRecorded(id, looter, POOL, points, itempoints, link, attendees, boss)
	if looter == L["Bank"] or not attendees then return end
	points = points - itempoints
	self:AwardItem(id, looter, POOL, points, itempoints, link)
	
	zeroattends = {}
	for _, name in pairs(attendees) do
		tinsert(zeroattends, name)
	end
	
	--add zero sum points
	if itempoints == 0 or not attendees then return end
	if self.db.profile.usewait then
		local waitattends
		local killid = self:GetEventID(2)
		if boss ~= "Trash mob" then killid = #db.raidlog[db.raidnum].bosskills end
		local wait = self:GetModuleRef("Waitlist")
		if wait then waitattends = wait:GetWaitlist() end
		if waitattends then
			for _, name in pairs(waitattends) do
				tinsert(zeroattends, name)
				local found = nil
				for _, inname in pairs(db.raidlog[db.raidnum].bosskills[killid].attendees) do
					if inname == name then
						found = true
						break
					end
				end
				if not found then tinsert(db.raidlog[db.raidnum].bosskills[killid].attendees, name) end
			end
		end
	end
	local addpoints = floor(itempoints / #zeroattends * 100) / 100
	self:AwardDKP(addpoints, 0, POOL, zeroattends)
end

function mod:ItemRebate(id, looter, POOL, itempoints, link, oldattends, newattends, trashadjust, points)
	if newattends then		--changing item event
		--remove points from old attendees
		if oldattends then
			local addpoints = floor(itempoints / #oldattends * 100) / 100 
			self:AwardDKP(0, addpoints, POOL, oldattends)
		end
		
		--add points to new attendees
		if looter == L["Bank"] then return end
		local addpoints = floor(itempoints / #newattends * 100) / 100  
		self:AwardDKP(addpoints, 0, POOL, newattends)
	else
		if trashadjust then
			local addpoints = floor(itempoints / #oldattends * 100) / 100 
			points = points - itempoints
			self:AwardItem(id, looter, POOL, points, itempoints, link)
			self:AwardDKP(addpoints, 0, POOL, oldattends)
		elseif oldattends and looter ~= L["Bank"] then
			local addpoints = floor(itempoints / #oldattends * 100) / 100 
			self:AwardDKP(0, addpoints, POOL, oldattends)
			self:AdjustDKPPoints(looter, looter, POOL, nil, itempoints)
		end
	end
end

function mod:ItemAdjustment(id, looter, POOL, newcost, link, oldcost, attends)
	if not attends or looter == L["Bank"] then return end
	local diff = oldcost - newcost
	local addpoints = floor(diff / #attends * 100) / 100 
	self:AwardDKP(0, addpoints, POOL, attends)
end


function mod:ItemTransfer(id, newmember, oldmember, POOL, newcost, link, oldcost)
	self:AdjustDKPPoints(newmember, oldmember, POOL, newcost, oldcost, link)
end
