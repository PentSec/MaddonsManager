local mod = MorgDKP2:NewModule("Eventnaming")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.Eventnaming

local mdkp = MorgDKP2
mod.modName = "Eventnaming"

local db
local Player = UnitName("player")

local defaults = { 
	profile = {
		bossformat = "<boss>",
		startformat = "<zone> <diff> Start",
		trashformat = "<zone> <diff> Run",
	},
}

local options = {
		type = "group",
		handler = mod,
		name = LL["Event naming"],
		desc = LL["Event naming"],
		order = 300,
		args = {
			enable = {
				type = "toggle",
				name = LL["Enable"],
				desc = LL["Allows you to change the default format for event names."],
				get = function() return mdkp.db.profile.modules.Eventnaming end,
				set = 	function(info, v) 
						mdkp.db.profile.modules.Eventnaming = v
						if v then 
							mod:Enable()
							mod:debug("Enabled Eventnaming")
						else
							mod:Disable()
							mdkp:debug("Disabled Eventnaming")
						end
					end,
				order = 5
			},
			reset = {
				type = "execute",
				name = LL["Default"],
				desc = LL["Reset default values."],
				func = function() mod:ResetDefault() end,
				hidden = function() return not mdkp.db.profile.modules.Eventnaming end,
				order = 8
			},
			start = {
				type = "input",
				name = LL["Start format"],
				desc = LL["Format of start event name:  \n<zone> text  \nExample:  <zone> <diff> Start"],
				get = function() return mod.db.profile.startformat end,
				set = 	function(info, v) if v then mod.db.profile.startformat = v end end,
				hidden = function() return not mdkp.db.profile.modules.Eventnaming end,
				order = 10
			},
			trash = {
				type = "input",
				name = LL["Run format"],
				desc = LL["Format of run event name:  \n<zone> text  \nExample:  <zone> <diff> Run"],
				get = function() return mod.db.profile.trashformat end,
				set = 	function(info, v) if v then mod.db.profile.trashformat = v end end,
				hidden = function() return not mdkp.db.profile.modules.Eventnaming end,
				order = 15
			},
			boss = {
				type = "input",
				name = LL["Boss format"],
				desc = LL["Format of boss event names:  \n<zone> - <boss>\nExample:  <boss> <diff>"],
				get = function() return mod.db.profile.bossformat end,
				set = 	function(info, v) if v then mod.db.profile.bossformat = v end end,
				hidden = function() return not mdkp.db.profile.modules.Eventnaming end,
				order = 20
			},
			
		},
}

function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return nil
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("Eventnaming", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
	db.moduleON["Eventnaming"] = true
						
end

function mod:OnDisable()
	db.moduleON["Eventnaming"] = nil
						
end

function mod:ResetDefault()
	self.db.profile.startformat, self.db.profile.trashformat, self.db.profile.bossformat = "<zone> Start", "<zone> Run", "<boss>"
end

function mod:GetEventFormat()
	return self.db.profile.startformat, self.db.profile.trashformat, self.db.profile.bossformat
end

function mod:SetEventFormat(start, trash, boss)
	if start and trash and boss then
		self.db.profile.startformat, self.db.profile.trashformat, self.db.profile.bossformat = start, trash, boss
	end
end
