local mod = MorgDKP2:NewModule("LDBPlugin", "AceEvent-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local C = LibStub("AceConfigDialog-3.0")
local broker = LibStub("LibDataBroker-1.1", true)
local icon = LibStub("LibDBIcon-1.0", true)

local mdkp = MorgDKP2

local defaults = { 
	profile = {
		minimapicon = {
			hide = false
		},
   	},
}

mod.modName = L["LDB Plugin"]
mod.modref = "LDBPlugin"

function mod:GetOptions()
	return nil
end

function mod:IsDKP()
	return nil
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("LDBPlugin", defaults)
end

function mod:OnEnable()
	mdkp.db.profile.moduleON["LDBPlugin"] = true
	self:CreateLDBObject()
	if not icon:IsRegistered("MorgDKP2") then icon:Register("MorgDKP2", self.LDBframe.obj, self.db.profile.minimapicon) end
end

function mod:ToggleMinimapIcon(ON)
	if ON then icon:Show("MorgDKP2")
	else icon:Hide("MorgDKP2") end
end

function mod:OnDisable()
	mdkp.db.profile.moduleON["LDBPlugin"] = nil
end

function mod:ActivateCore()
	if not self.LDBframe then return end
	mod.LDBframe.obj.icon = "Interface\\AddOns\\MorgDKP2\\Icons\\AquaON"
	mod.LDBframe.hint:SetText(L["|c000070ddClick:|r MorgBid2 Base query.\n|c000070ddALT-Click:|r Toggle ML/DE\n|c000070ddSHIFT-Click:|r Invite & Waitlist.\n|c000070ddCTRL-Click:|r Raid Tracker.\n|c000070ddCTRL-Click Itemlink:|r Ignore item."])
	self:ToggleFrameUpdate("TooltipLDB", true)
end

function mod:DeActivateCore()
	if not self.LDBframe then return end
	mod.LDBframe.obj.icon = "Interface\\AddOns\\MorgDKP2\\Icons\\AquaOFF"
	mod.LDBframe.hint:SetText(L["On STANDBY.\n|c000070ddClick:|r to enable."])
	self:ToggleFrameUpdate("TooltipLDB", true)
end

function mod:CreateLDBObject()
	if self.LDBframe then return end
	local onenter = function(f) f:Show() end
	local onleave = function(f) f:Hide() end
	self.LDBframe = self:Createframe("Tooltip_BrokerMorgDKP2", onenter, onleave, nil, nil, L["On STANDBY.\n|c000070ddClick:|r to enable."], "TooltipLDB",nil, nil, mdkp.version or L["MorgDKP2"])
	self.LDBframe:SetFrameStrata("FULLSCREEN")
	self.LDBframe:SetClampedToScreen(true)
	self.LDBframe.obj = LibStub("LibDataBroker-1.1"):NewDataObject("Broker_MorgDKP2", {
		type = "data source",
		icon = "Interface\\AddOns\\MorgDKP2\\Icons\\AquaOFF",
		label = "MorgDKP2",
		OnClick = function(frame, button)
				if button == "RightButton" then
					if not C.OpenFrames["MorgDKP2"] then C:Open("MorgDKP2") 
					else C:Close("MorgDKP2") end
				else 
					if mod:CoreStatus() then
						if IsAltKeyDown() then
							mdkp.MLmode = not mdkp.MLmode
						elseif IsShiftKeyDown() then
							local core = self:GetModuleRef("CoreModule")
							core:ListDKP("All")
						elseif IsControlKeyDown() then
							local raidtracker = self:GetModuleRef("RaidTracker")
							if raidtracker then raidtracker:OpenFrame() end
						else 
							local core = self:GetModuleRef("CoreModule")
							core:MorgBidQuery()
						end
					else 
						self.LDBframe:Hide()
						mdkp:ActivateCore(true)
					end
					self:Updatetooltipdata(self.LDBframe)
				end
			end,
		OnEnter = function(frame)
				local point, relPoint
				local dewpoint = "RIGHT"
				local X, Y = self:GetScaledCursorPosition()
				local width = GetScreenWidth() 
				local height = GetScreenHeight() / 2
				if Y < height then point, relPoint = "BOTTOM", "TOP" 
				else point, relPoint = "TOP", "BOTTOM" 
				end
				if X + mdkp.db.profile.media.fontsize * 25 > width then dewpoint = "LEFT" end 
				mdkp.db.profile.dewpoint = dewpoint
				self.LDBframe:ClearAllPoints()
    				self.LDBframe:SetPoint(point, frame, relPoint)
				self.LDBframe:Show()
				self:FrameUpdate(self.LDBframe)
			end,
		OnLeave = function()
				self.LDBframe:Hide() 
			end,
	})

end
