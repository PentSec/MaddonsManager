local mod = MorgDKP2:NewModule("FixedDKP")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.FixedDKP

local mdkp = MorgDKP2

mod.modName = LL["Fixed DKP"]
mod.modref = "FixedDKP"

local Player = UnitName("player")
local db
local fmt = string.format
local floor = math.floor

local defaults = { 
	profile = {
		
	},
}

local options = {
		fixeddkp = {
			type = "toggle",
			name = LL["Fixed DKP"],
			desc = LL["Standard DKP system."],
			get = function() return mdkp.db.profile.modules.FixedDKP end,
			set = 	function(info, v) 
					mdkp.db.profile.modules.FixedDKP = not v
					mod:DKPChange(mod.modName)
			end,
			order = 5
		},	
		head33 = {
			type = "header",
			name = LL["DKP TAKE/OFFSPEC settings"],
			hidden = function() return mdkp.db.profile.currDKP == "Random" end,
			order = 300
		},
		taketog = {
			type = "toggle",
			name = LL["Enable TAKE"],
			desc = LL["Enables mode where members are charged a standard price for TAKE items."],
			get = function() return mdkp.db.profile.takemode end,
			set = function(info, v) mdkp.db.profile.takemode = v end,
			hidden = function() return mdkp.db.profile.currDKP == "Random" end,
			order = 310
		},
		takeamt = {
			type = "range",
			name = LL["TAKE value"],
			get = function() return mdkp.db.profile.takeamount end,
			set = 	function(info, v) if v then mdkp.db.profile.takeamount = v end end,
			min = 0, 
			max = 500, 
			step = 1,
			hidden = function() return not mdkp.db.profile.takemode or mdkp.db.profile.currDKP == "Random" end,
			order = 320
		},
		offspectog = {
			type = "toggle",
			name = LL["Enable OFFSPEC"],
			desc = LL["Enables mode where members are charged a standard price for OFFSPEC items."],
			get = function() return mdkp.db.profile.offspecmode end,
			set = function(info, v) mdkp.db.profile.offspecmode = v end,
			hidden = function() return mdkp.db.profile.currDKP == "Random" end,
			order = 330
		},
		offspecamt = {
			type = "range",
			name = LL["OFFSPEC value"],
			get = function() return mdkp.db.profile.offspecamount end,
			set = 	function(info, v) if v then mdkp.db.profile.offspecamount = v end end,
			min = 0, 
			max = 500, 
			step = 1,
			hidden = function() return not mdkp.db.profile.offspecmode or mdkp.db.profile.currDKP == "Random" end,
			order = 340
		},	
		usetakeperc = {
			type = "toggle",
			name = LL["TAKE Percent"],
			desc = LL["Use percent of item value for TAKE mode."],
			get = function() return mdkp.db.profile.takepercent end,
			set = function(info, v) mdkp.db.profile.takepercent = v end,
			hidden = function() return not mdkp.db.profile.takemode or mdkp.db.profile.currDKP == "Random" end,
			order = 350
		},
		useoffperc = {
			type = "toggle",
			name = LL["OFFSPEC Percent"],
			desc = LL["Use percent of item value for OFFSPEC mode."],
			get = function() return mdkp.db.profile.offspecpercent end,
			set = function(info, v) mdkp.db.profile.offspecpercent = v end,
			hidden = function() return not mdkp.db.profile.offspecmode or mdkp.db.profile.currDKP == "Random" end,
			order = 350
		},
}

function mod:GetOptions()
	return options
end

function mod:GetName()
	return mod.modName, mod.modref
end

function mod:IsDKP()
	return true
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("FixedDKP", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
	db.moduleON["FixedDKP"] = true
end

function mod:OnDisable()
	db.moduleON["FixedDKP"] = nil
				
end

function mod:GetPlayerPoints(name, POOL, showearned)
	if showearned then return db.info[name][POOL].earned
	else return db.info[name][POOL].points end
end

function mod:GetItemValue(itemid, player, POOL)
	local itempoints = db.items[itemid].points
	itempoints = floor(self:GetTAKEModeValue(itemid, itempoints, player) + 0.5)
	return itempoints
end

function mod:ItemRecorded(id, looter, POOL, points, itempoints, link)
	if looter == L["Bank"] then return end
	points = points - itempoints
	self:AwardItem(id, looter, POOL, points, itempoints, link)
end

function mod:ItemRebate(id, looter, POOL, itempoints, link)
	if not id or looter == L["Bank"] then return end
	self:AdjustDKPPoints(looter, looter, POOL, nil, itempoints)
end
