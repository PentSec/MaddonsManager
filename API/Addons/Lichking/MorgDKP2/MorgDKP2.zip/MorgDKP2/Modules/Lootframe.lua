local mod = MorgDKP2:NewModule("Lootframe", "AceEvent-3.0", "AceComm-3.0", "AceHook-3.0", "AceSerializer-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.Lootframe
local media = LibStub("LibSharedMedia-3.0", true)
local BC = LibStub("LibBabble-Class-3.0"):GetLookupTable()
local BB = LibStub("LibBabble-Boss-3.0"):GetLookupTable()

local mdkp = MorgDKP2
mod.modName = "Lootframe"

--static pops
StaticPopupDialogs["MorgLoot2"] = {
	text = TEXT(LL["Give %s to %s, are you sure?"]),
	button1 = TEXT(YES),
	button2 = TEXT(NO),
	OnAccept = function(v)
		mod:GiveOutLoot(v)
	end,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1,
}

local fmt = string.format
local upper = string.upper
local sub = string.sub
local slen = string.len
local find = string.find
local band = bit.band
local bor = bit.bor
local bxor = bit.bxor
local Player = UnitName("player")
local db
local coincolor = {{255, 215, 0}, {199, 199, 207}, {237, 165, 95}}
local coincolors = { g = "|c00ffd700", s = "|c00c7c7cf", c = "|c00eda55f"}
local coins = { " |TInterface\\MoneyFrame\\UI-GoldIcon:0|t",
		" |TInterface\\MoneyFrame\\UI-SilverIcon:0|t",
		" |TInterface\\MoneyFrame\\UI-CopperIcon:0|t"
}
local IGNORE = {}
local raidlink = {}
local scrollmaxes = {[1] = 15, [2] = 10, [3] = 5}
local ClassLootClasses = {
	["WarriorTanking"] = "WARRIOR",
	["WarriorDPS"] = "WARRIOR",
	["Rogue"] = "ROGUE",
	["Hunter"] = "HUNTER",
	["DruidFeral"] = "DRUID",
	["DruidHealing"] = "DRUID",
	["Mage"] = "MAGE",
	["Priest"] = "PRIEST",
	["Warlock"] = "WARLOCK",
	["PaladinDPS"] = "PALADIN",
	["PaladinHealing"] = "PALADIN",
	["ShamanDPS"] = "SHAMAN",
	["ShamanHealing"] = "SHAMAN",
	["WarriorProt"] = "WARRIOR",
	["WarriorArms"] = "WARRIOR",
	["WarriorFury"] = "WARRIOR",
	["PaladinHoly"] = "PALADIN",
	["PaladinProt"] = "PALADIN",
	["PaladinRet"] = "PALADIN",
	["ShamanElemental"] = "SHAMAN",
	["ShamanEnhance"] = "SHAMAN",
	["ShamanResto"] = "SHAMAN",
	["DruidBalance"] = "DRUID",
	["DruidResto"] = "DRUID",
	["PriestDPS"] = "PRIEST",
	["PriestHeal"] = "PRIEST",
	["DeathknightTank"] = "DEATHKNIGHT",
	["DeathknightDPS"] = "DEATHKNIGHT"
}
local ClassLoot = LibStub("AceAddon-3.0"):GetAddon("ClassLoot", true)
local ClassLoot_Data
if ClassLoot then ClassLoot_Data = ClassLoot.CD end

local defaults = { 
	profile = {
		usemorg = true,
		cursor = true,
		scale = 1.4,
		lootframe = {
			y = -46,
			x = -97,
			point = "CENTER",
			relpoint = "CENTER"
		},
   	},
}

local options = {
		type = "group",
		handler = mod,
		name = LL["Lootframe"],
		desc = LL["Lootframe"],
		order = 340,
		args = {
			replaceblizz = {
				type = "toggle",
				name = LL["Replace Blizzard"],
				desc = LL["When MorgDKP2 is active it's loot frame will replace default."],
				get = function() return mod.db.profile.usemorg end,
				set = 	function(info, v) 
						mod.db.profile.usemorg = v
						if v then 
							mod:EnableBlizzHooks()
							mod:debug("Enabled Morgframe")
						else
							mod:DisableBlizzHooks()
							mdkp:debug("Disabled Morgframe")
						end
					end,
				order = 1
			},
			atcursor = {
				type = "toggle",
				name = LL["Snap to cursor"],
				desc = LL["Open lootframe at cursor postition"],
				get = function() return mod.db.profile.cursor end,
				set = 	function(info, v) mod.db.profile.cursor = v end,
				order = 5
			},
			useinactive = {
				type = "toggle",
				name = LL["Always use"],
				desc = LL["Always use the MorgDKP2 loot window even when the mod is in standby mode."],
				get = function() return mdkp.db.profile.alwaysloot end,
				set = 	function(info, v) 
						mdkp.db.profile.alwaysloot = v 
						if v then
							if not mod:CoreStatus() then
								mod:Enable()
							end
						else 
							if not mod:CoreStatus() then
								mod:Disable()
							end
						end
					end,
				hidden = function() return not mod.db.profile.usemorg end,
				order = 3
			},
			desc = {
				type = "description",
				name = "",
				order = 10
			},
			lootscale = {
				type = "range",
				name = LL["Lootframe scale"],
				get = function() return mod.db.profile.scale end,
				set = function(info, v) if v then mod.db.profile.scale = v end mod:UpdateLootFrameMedia() end,
				min = .5, 
				max = 2, 
				step = .1,
				order = 15
			},
	      	},
}

function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return nil
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("Lootframe", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
      	db.moduleON["Lootframe"] = true
      	self.font = media:Fetch("font", db.media.font)
	self.target = nil
	self.clickedslot = nil
	self.awardedrandomitem = {}
	self.AwardBuffer = {}
	self.AwardIndex = 1
	self.closed = nil
	self.extrabutton = nil
	self.oldhighlight = nil
	self.lootalpha = 1
	
	if self.db.profile.usemorg then self:EnableBlizzHooks() 
	else self:RegisterEvent("LOOT_OPENED", "OnOpen") end
	self:RegisterEvent("RAID_ROSTER_UPDATE", "RaidEvent") 
	
	self:RawHook("ContainerFrameItemButton_OnModifiedClick", true)
end

function mod:OnDisable()
	--if self.db.profile.usemorg then self:DisableBlizzHooks() end
	if not mdkp.db.profile.alwaysloot then self:DisableBlizzHooks() end
	db.moduleON["Lootframe"] = nil
end

function mod:EnableBlizzHooks()
	self:debug("Enabling hooks")
	self.needreg = {}
	local events = {"LOOT_OPENED", "LOOT_SLOT_CLEARED", "LOOT_CLOSED", "OPEN_MASTER_LOOT_LIST"}
	for _, event in pairs(events) do
		if LootFrame:IsEventRegistered(event) then 
			LootFrame:UnregisterEvent(event) 
			tinsert(self.needreg, event)
		end
	end
	self:RegisterEvent("LOOT_OPENED", "OnOpen")
	self:RegisterEvent("LOOT_SLOT_CLEARED", "OnClear")
	self:RegisterEvent("LOOT_CLOSED", "OnClose")
	self:RegisterEvent("OPEN_MASTER_LOOT_LIST", "CreateMLMenu")
end

function mod:DisableBlizzHooks()
	self:UnregisterAllEvents()
	if self.needreg then
		for _, event in pairs(self.needreg) do
			LootFrame:RegisterEvent(event)
		end 
	end
	self:RegisterEvent("LOOT_OPENED", "OnOpen")
end

function mod:UpdateLootFrameMedia()
	if self.lootframe then self.lootframe:SetScale(self.db.profile.scale) end
end

function mod:RaidEvent()
	if mod:CoreStatus() then mod:UnregisterEvent("RAID_ROSTER_UPDATE") end
	mod:GetCurrentLootMethod()
end

function mod:ContainerFrameItemButton_OnModifiedClick(frame, button)
	if not self:CoreStatus() then return self.hooks.ContainerFrameItemButton_OnModifiedClick(frame, button) end
	self:debug("Container click..."..(button or "NIL"))
	if IsShiftKeyDown() and IsAltKeyDown() and button=="LeftButton" then
		local bag = frame:GetParent():GetID() 
		local slot = frame:GetID() 
		self:debug("bag="..(bag or "NIL").."slot="..(slot or "NIL")..(frame:GetName() or "NIL"))
		local itemlink = GetContainerItemLink(bag, slot)
		self:AddManualItem(itemlink)
	else return self.hooks.ContainerFrameItemButton_OnModifiedClick(frame, button) end
end

function mod:OnOpen()
	self:debug("Loot open")
	self.lootalpha = 1
	local numItems = GetNumLootItems()
	if numItems == 0 then return end
	self.numqueries = 0
      	local nitems = 0
      	self.items = {}
      	local link, itemId
	IGNORE = {}
	local needlinks = 1
	raidlink = {}
	local target = UnitName("target")
	self.target = target
	self.closed = nil
	raidlink[1] = (target or "") .. ": "
	for slot = 1, numItems  do
		link, itemId = nil, nil
		local lootIcon, lootName, lootQuantity, rarity = GetLootSlotInfo(slot)
		if LootSlotIsItem(slot) then
	    		link = GetLootSlotLink(slot)
			_,_, itemId = string.find(link, "item:(%d+):")
			itemId = tonumber(itemId)
			if nitems == 2 or nitems == 4 or nitems == 6 or nitems == 8 then
	    			needlinks = needlinks + 1
	    			raidlink[needlinks] = ""
	    		end
	    		if rarity >= db.quality and not IGNORE[itemId] then 
	    			raidlink[needlinks] = raidlink[needlinks] .. link
	    			nitems = nitems + 1
	    		end
		end
		if self.db.profile.usemorg or (not self.db.profile.usemorg and rarity >= db.quality and itemId and not db.ignore[itemId]) then
			self:AddItemforQuery(link, itemId, lootIcon, lootName, rarity, slot, db.ignore[itemId], lootQuantity)
		end
	end
 	if not db.dkplistener then
 		if nitems > 0 and self:CoreStatus() then
 			for _, v in pairs(raidlink) do
 				if mdkp.db.profile.raidlink then SendChatMessage(v , "RAID") end
 				if mdkp.db.profile.guildlink then SendChatMessage(v , "GUILD") end
 			end
		end
	end
	self:UpdateLootFrame()
end

function mod:OnClear(event, slot)
	self:debug("Loot clear"..slot)
	for key, data in pairs(self.items) do
		if data.slot == slot then
			table.remove(self.items, key)
			break
		end
	end
	self:UpdateLootFrame(nil, nil, nil, nil, self.extrabutton)
	if self.extrabutton then self.extrabutton = nil end
end

function mod:OnClose()
	self:debug("Loot close")
	self.lootalpha = .15
	if self.items then
		local temptable = {}
		local count = 1
		for key, data in pairs(self.items) do
			if not data.coin and not data.ignore and data.quality >= db.quality then
				data.slot = count
				table.insert(temptable, data)
				count = count + 1
			end
		end
		self.items = temptable
	end
	if (not self.items or (self.items and #self.items == 0) or not self:CoreStatus() or db.dkplistener) and self.lootframe then self.lootframe:Hide()
	else 
		local item, notsummary, id, force
		if self.itemframe and self.itemframe:IsVisible() then 
			item = self.itemframe:GetID()
			notsummary = true
			force = true
			id = self:GetRecord(item)
		end
		if self.lootframe and not self.closed then self:UpdateLootFrame(id, item, notsummary, force, true) end
	end
end

function mod:AddItemforQuery(link, id, icon, name, quality, index, ignore, quantity)
	self:debug("Adding "..name.." in slot "..index)
	local coin
	if LootSlotIsCoin(index) then
		local _, _, gold = string.find(name, "(%d+) Gold")
		local _, _, silver = string.find(name, "(%d+) Silver")
		local _, _, copper = string.find(name, "(%d+) Copper")
		coin = 1
		name = ""
		if gold then 
			name = coincolors.g .. gold .. "|r " .. coins[1] 
			coin = 3
		end
		if silver then 
			name = name .. coincolors.s .. silver .. "|r " ..coins[2] 
			if coin ~= 3 then coin = 2 end
		end
		if copper then
			name = name .. coincolors.c .. copper .. "|r" .. coins[3]
		end
	elseif ClassLoot_Data and self:CoreStatus() then	--adding item so get its info if using classloot
		local classlootdata = ClassLoot_Data[id]
		if classlootdata then
			self:IteminDB(id)
			if db.items[id].classes == 0 and db.items[id].altclasses == 0 then
				for class, rank in pairs(classlootdata) do
					self:ToggleClassinDB(id, ClassLootClasses[class], rank)
				end 
			end
		end
	end
	if quality >= db.quality and not ignore and id then self.numqueries = self.numqueries + 1 end
	table.insert(self.items, {	name = name,
					id = id,
					link = link,
					icon = icon,
					quality = quality,
					ignore = ignore,
					coin = coin,
					slot = index,
					quantity = quantity})
end

function mod:ShowTablet()
	if not self.lootframe then 
		local ondragstart = function(f) f:StartMoving() end
		local ondragstop =  function(f)
   						f:StopMovingOrSizing()
   						local point, _, relativePoint, x, y = f:GetPoint()
						mod.db.profile.lootframe = {point = point, relpoint = relativePoint, x = x, y = y}
   					end
		self.lootframe = self:Createframe(nil, nil, nil, nil, nil, nil, "Lootframe", nil, nil, "title", ondragstart, ondragstop)
		
		local f = self.lootframe
		f:SetScale(self.db.profile.scale)
		f:SetFrameStrata("DIALOG")
		f.close = CreateFrame("Button", nil, f)
   		f.close:SetScript("OnClick", function(f) self.closed = true self.items = {} f:GetParent():Hide() end)
   		f.close:SetWidth(18)
   		f.close:SetHeight(18)
   		f.close:SetNormalTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up")
   		f.close:SetPushedTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Down")
   		f.close:SetHighlightTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight")
   		f.close:ClearAllPoints()
   		f.close:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
   		f.close:SetHitRectInsets(5, 5, 5, 5)
   		f.close:Show()
   		f.title:SetText(self.target)
   		f.num = 0
   		f.buttons = {} 
   	end
	if not self.itemframe then self.itemframe = self:CreateItemsFrame() end
	if not self.rollframe then self:CreateRollFrame() end
end

function mod:UpdateLootFrame(rollid, rollitemID, rollflag, force, nomove, redraw)
	self:debug("Updating loot...")
	--if self.numqueries == 0 then return end
	if not self.lootframe then self:ShowTablet() end
	local f = self.lootframe
	f.title:SetText(self.target)
	local usemorg = db.usemorg
	local items = #self.items
	if items == 0 then f:Hide() return end
	local fontallowance = db.media.fontsize * 3 - 20
	local updated = nil
	local showroll = nil
	local numrolls = 0
	if fontallowance < 0 then fontallowance = 0 end
	f.textlen = 0
	for v = 1, f.num do
		f.buttons[v].dkp:Hide()
		f.buttons[v].class:Hide()
		f.buttons[v]:Hide()
		f.buttons[v].highlight:Hide()
	end
	f.num = 0
	f.height = 0
	for id, itemdata in ipairs(self.items) do
		local dkp = 0
		local classes = ""
		local r, g, b
		if not f.buttons[id] or redraw then 
			f.buttons[id] = self:CreateLootbutton(id, fontallowance) 
		end
		local bf = f.buttons[id]
		if itemdata.id then 
			r, g, b = mdkp.Quality[itemdata.quality+1].r, mdkp.Quality[itemdata.quality+1].g, mdkp.Quality[itemdata.quality+1].b
			bf:SetBackdropBorderColor(r, g, b, 1)
			bf:SetBackdropColor(r, g, b, .1)
			if not itemdata.ignore and itemdata.quality >= db.quality and self:CoreStatus() and not db.dkplistener then
				self:IteminDB(itemdata.id) 
				dkp = db.items[itemdata.id].points
				local selclasses = db.items[itemdata.id].classes 
				if band(selclasses, 2047) == 2047 then classes = L["ALL"]
				else 
					for _, class in ipairs(mdkp.orderedclasses) do
						if class ~= L["ALL"] then
							local bit = mdkp.Bits[class]
							if band(selclasses, bit) == bit then
								classes = classes .. mdkp.Classcolors[class] .. string.sub(class, 1, 1) .. "|r"
							end
						end
					end
				end
				if dkp == 0 then 
					bf.dkp:SetTextColor(1, 0, 0)
				else bf.dkp:SetTextColor(0, 1, 0) end
   				bf.dkp:SetText(dkp)
   		
   				if classes == "" then 
   					classes = L["NONE"]
   					bf.class:SetTextColor(1, 0, 0)
   					if not updated and not force then updated = self:UpdateItemFrame(id, itemdata.id) end 
   				else bf.class:SetTextColor(0, 1, 0, .65)
   				end
   				bf.class:SetText(classes)
   				bf.dkp:Show()
				bf.class:Show()
				if mdkp.AuctionStatus[itemdata.id] then 
					numrolls = numrolls + 1 
					showroll = true 
				end
			end
   			if (itemdata.quality >= db.lootthreshold and self:IsML() and self:CoreStatus() and not itemdata.ignore) or (not self:CoreStatus() and self:IsML() and itemdata.quality >= db.lootthreshold and not itemdata.ignore) then 
   				bf.selfloot:Show()
   				bf.random:Show()
   			else 
   				bf.selfloot:Hide()
   				bf.random:Hide()
  			end 	
  		else 
			if itemdata.coin then
				bf:SetBackdropBorderColor(unpack(coincolor[itemdata.coin], 1))
				bf.selfloot:Hide()
   				bf.random:Hide()
			else 
				bf:SetBackdropBorderColor(0, 0, 0, 1)
				r, g, b = 1, 1, 1
			end
			bf.highlight:Hide()
		end
		bf:SetAlpha(self.lootalpha)
		bf.icon:SetNormalTexture(itemdata.icon)
		bf.name:SetTextColor(r, g, b)
   		local itemname = itemdata.name
   		if itemdata.quantity > 1 then itemname = itemname .. " x " .. itemdata.quantity end
   		bf.name:SetText(itemname)
		local width = bf.name:GetStringWidth() + bf.icon:GetWidth()
		if width > f.textlen then f.textlen = width end
		
			
   		if id == 1 then bf:SetPoint("TOPLEFT", f, "TOPLEFT", 5, -7 - f.title:GetStringHeight())
   		else bf:SetPoint("TOPLEFT", f.buttons[id-1], "BOTTOMLEFT", 0, 0) end
   		bf:Show()
   		f.num = f.num + 1
   	
   	end
   	if not updated and showroll and not force then updated = self:UpdateRollFrame(rollid, rollitemID, rollflag, numrolls) end 		
   	if force then updated = self:UpdateItemFrame(rollid, rollitemID, rollflag) end
   	if self.db.profile.cursor and self.db.profile.usemorg and not nomove then 
   		f:ClearAllPoints()
   		local x, y = self:GetScaledCursorPosition()
   		x, y = x / self.db.profile.scale,  y / self.db.profile.scale
   		f:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", x - 45, y + 25) 
   	else
   		f:ClearAllPoints()
   		local point, relpoint, x, y
   		local db = self.db.profile.lootframe
   		if db then point, relpoint, x, y = db.point, db.relpoint, db.x, db.y
   		else point, relpoint, x, y = "CENTER", "CENTER", 0, 0 end
   		f:SetPoint(point, UIParent, relpoint, x, y)
   	end
   	local height = f.buttons[1]:GetHeight() * #self.items + 30
   	f:SetHeight(height)
   	local width = f.textlen + f.buttons[1].icon:GetWidth() 
   	local namewidth = f.title:GetWidth()
   	if width < namewidth + 10 then width = namewidth + 10 end
   	local addwidth = 0
   	if not updated then 
   		self.itemframe:Hide()
   		self.rollframe:Hide()
   		self.rollsummaryframe:Hide()
   		addwidth = 0
   		for v = 1, f.num do
			f.buttons[v].highlight:Hide()
		end
   	else 
   		addwidth = updated:GetWidth() 
   		if updated:GetHeight() < height then updated:SetHeight(height - 15) end
   	end
   	f:SetWidth(width + addwidth + 15)
   	for i = 1, #self.items do
   		f.buttons[i]:SetWidth(width + 5)
   		f.buttons[i].name:SetWidth(f.textlen)
   		f.buttons[i].class:SetWidth(f.textlen)
   	end
   	f:Show()
end

function mod:UpdateItemFrame(id, itemID, clicked)
	if not itemID then return end
	self:debug("Updating item.."..itemID)
	if mdkp.AuctionStatus[itemID] then return self:UpdateRollFrame(id, itemID, clicked) end
	self.rollframe:Hide() 
	self.rollsummaryframe:Hide() 
	self:IteminDB(itemID)
	local f = self.itemframe
	f.roll:SetHighlightTexture("Interface\\Buttons\\UI-GroupLoot-Dice-Highlight")
   	f.roll:SetButtonState("NORMAL", true)
   	f.bridge:Hide()
	if id then
		local r, g, b =  mdkp.Quality[self.items[id].quality+1].r, mdkp.Quality[self.items[id].quality+1].g, mdkp.Quality[self.items[id].quality+1].b
		f:SetBackdropBorderColor(r, g, b, 1)
		f.bridge:SetPoint("LEFT", self.lootframe.buttons[id], "RIGHT", -5, 0)
		f.bridge.texture:SetTexture(r, g, b, .3)
		f.bridge.texture2:SetTexture(r, g, b, .3)
   		f.bridge:Show()
   		self:UpdateHighlights(id, itemID, r, g, b)
	end
	local classes = db.items[itemID].classes 
	local altclasses = db.items[itemID].altclasses 
	if classes == 0 and altclasses == 0 then f.roll:Disable()
	else f.roll:Enable() end
	for class, bit in pairs(mdkp.Bits) do
		f.cf[class].altclass:SetChecked(band(altclasses, bit) == bit)
		f.cf[class].pclass:SetChecked(band(classes, bit) == bit)
	end
	f.value.text:SetText(db.items[itemID].points)
	if db.multiPool then
		local text = db.items[itemID].pool
		if not text then text = db.raid end
		f.multi.text:SetText(text)
		f.multi:Show()
	end
	f:SetID(itemID)
	f:SetPoint("TOPLEFT", self.lootframe.buttons[1], "TOPRIGHT", 0, 0)
	f:SetHeight(11 * db.media.fontsize + 85 * 10/db.media.fontsize)
	if not f:IsVisible() then 
		--self.lootframe:SetWidth(self.lootframe:GetWidth() + f:GetWidth())
		f:Show()
	end
	return f
end

function mod:UpdateRollFrame(id, itemID, clicked, numrolls)
	self:debug("Updating roll frame.."..(itemID or "nil"))
	self.itemframe:Hide()
	if not clicked or (numrolls and numrolls > 1) then
		self.rollframe:Hide()
		local f = self.rollsummaryframe
		local index = 1
		local background = media:Fetch("background", "Solid")
		local border = media:Fetch("border", "Blizzard Tooltip")
		local font = media:Fetch("font", db.media.font)
		local fontsize = db.media.fontsize
		local maxitems 
		local totalheight = 0
		local rolled = {}
		f.itemlist = {}
		for v = 1, f.numitems do
			f.title[v]:Hide()
			f.scroll[v]:Hide()
			f.stoproll[v]:Hide()
			f.de[v]:Hide()
		end
		if self.numqueries > 3 then maxitems = 5
		else maxitems = scrollmaxes[self.numqueries] end
		local width, height, titlewidth
		local frame, point, relpoint, x, y = f, "TOP", "TOP", 0, -5
		for slot, itemdata in ipairs(self.items) do
			local r, g, b = 1, 1, 1
			if itemdata.id and not itemdata.ignore and itemdata.quality >= db.quality and mdkp.AuctionStatus[itemdata.id] and not rolled[itemdata.id] then	
				r, g, b = mdkp.Quality[itemdata.quality+1].r, mdkp.Quality[itemdata.quality+1].g, mdkp.Quality[itemdata.quality+1].b
				
				if not f.title[index] then
					f.title[index] = f:CreateFontString()
					f.title[index]:SetPoint(point, frame, relpoint, x - 10, y)
   					f.title[index]:SetJustifyH("CENTER")
   					f.title[index]:SetFont(font, db.media.fontsize + 1)
   				end
   				f.title[index]:SetText(itemdata.name)
   				f.title[index]:SetTextColor(r, g, b)
   				f.title[index]:Show()
   				local titlewidth = f.title[index]:GetWidth()
   				if not f.scroll[index] then	
   					f.scroll[index] = self:CreateScrollFrame(f, background, border)
   				end
   				if not f.stoproll[index] then
   					f.stoproll[index] = self:CreateStopButton(f, background, border, true)
   				end
   				if not f.de[index] then
   					f.de[index] = self:CreateDEButton(f, background, border, true)
   				end
   				width, height = self:UpdateRollFrameData(f, f.scroll[index], itemdata.id, maxitems, slot)
   				totalheight = totalheight + height
				if titlewidth > width then width = titlewidth + 10 end
   				f.stoproll[index]:SetPoint("LEFT", f.title[index], "RIGHT", 5, -1)
				f.stoproll[index]:SetID(itemdata.id)
				f.stoproll[index]:Show()
				f.de[index]:SetPoint("LEFT", f.stoproll[index], "RIGHT", 2, 0)
				f.de[index]:SetID(itemdata.id)
				f.de[index]:Show()
				f.scroll[index]:SetPoint("TOP", f.title[index], "BOTTOM", 10, -5)
				f.scroll[index]:Show()
				f.scroll[index]:Show()
				index = index + 1
				frame, point, relpoint, x, y = f.scroll[index-1], "TOP", "BOTTOM", 0, -5
				f.itemlist[itemdata.id] = true
				rolled[itemdata.id] = true
			end
		end
		f.numitems = index - 1
		f.hint:SetWidth(width + 15)
		f:SetWidth(width + 45)
		f:SetHeight(totalheight + f.hint:GetHeight() + (fontsize + 5) * self.numqueries + 40)
		f.id = id
		f:SetScript("OnUpdate", function(f) self:RollUpdateCheck(f) end)
		f:Show()
		self:debug("Showing...summary frame")
		return f
	else
		self.rollsummaryframe:Hide()
		local f = self.rollframe
		local sf = self.rollframe.scroll
		local width, height = self:UpdateRollFrameData(f, sf, itemID, 15, id, true)
		local r, g, b = 1, 1, 1
		if id then r, g, b =  mdkp.Quality[self.items[id].quality+1].r, mdkp.Quality[self.items[id].quality+1].g, mdkp.Quality[self.items[id].quality+1].b end
		f.hint:SetWidth(width + 15)
		f.title:SetText(self.items[id].name)
		f.title:SetTextColor(r, g, b)
   		f.title:SetPoint("TOP", f, "TOP", -10, -5)
   		local titlewidth = f.title:GetWidth()
   		if titlewidth > width then width = titlewidth + 10 end
   		f:SetWidth(width + 45)
		f:SetHeight(height + f.hint:GetHeight() + f.title:GetHeight() + 30)
		f:SetID(itemID)
		f.stoproll:SetID(itemID)
		f.de:SetID(itemID)
		sf:SetPoint("TOP", f.title, "BOTTOM", 10, -5)
		sf:Show()
		f:SetScript("OnUpdate", function(f) self:RollUpdateCheck(f) end)
		f:Show()
		self:debug("Showing...rollframe")
		return f
	end
end

function mod:UpdateRollFrameData(f, sf, itemID, maxitems, id, bridge)
	for v = 1, sf.textid-1 do
    		sf.text[v]:Hide()
    	end
	sf.textid = 1
	sf.textlen = 0
	sf.height = 0
	local sr, sg, sb = 1, 1, 1
	local numitems = #mdkp.querytooltips[itemID]
	if numitems < maxitems then 
		maxitems = numitems 
		sr, sg, sb = 0, 0, 0
	end
	local data, data2
	for i = 1, numitems do
		data = mdkp.querytooltips[itemID][i]
		data2 = data[2]
		if type(data2) ~= "table" then data2 = mdkp.defaultstatustext[data2] end
		self:AddTextLine(sf, nil, data[1], data[3], data2, nil, nil, nil, nil)
		if i == maxitems then break end
	end
	if id then
		local r, g, b =  mdkp.Quality[self.items[id].quality+1].r, mdkp.Quality[self.items[id].quality+1].g, mdkp.Quality[self.items[id].quality+1].b
		f:SetBackdropBorderColor(r, g, b, 1)
		if bridge then
			f.bridge:Hide()
			f.bridge:SetPoint("LEFT", self.lootframe.buttons[id], "RIGHT", -5, 0)
			f.bridge.texture:SetTexture(r, g, b, .3)
			f.bridge.texture2:SetTexture(r, g, b, .3)
   			f.bridge:Show()
   			self:UpdateHighlights(id, itemID, r, g, b)
   		end
	end
	local lineheight = sf.text[1]:GetHeight()
	local width = sf.textlen + db.media.fontsize + 10
	local height = lineheight * maxitems + 10
	sf:SetHeight(height)
	sf:SetWidth(width + 5)
	f:SetPoint("TOPLEFT", self.lootframe.buttons[1], "TOPRIGHT", 0, 0)
	sf:SetID(itemID)
	sf:SetBackdropBorderColor(sr, sg, sb, 1)
	for v = 1, sf.textid-1 do
    		sf.text[v]:SetWidth(width)
    		
	end
	if not f:IsVisible() then 
		--self.lootframe:SetWidth(self.lootframe:GetWidth() + f:GetWidth())
		f:Show()
	end
	sf:SetScript("OnMouseWheel", function(f, direction) self:Scrollframe_Update(f, numitems, maxitems, mdkp.querytooltips[itemID], direction, "rollframe") end)
	self:Scrollframe_Update(sf, numitems, maxitems, mdkp.querytooltips[itemID], nil, "rollframe")
	return width or 0, height or 0
end

function mod:ShowTooltip(itemid, nameorlink)
	if not itemid then
		GameTooltip:SetHyperlink(nameorlink)
	else
		if db.info[nameorlink].raidloot == 0 then return end
		GameTooltip:AddLine(nameorlink.."'s Loot:", 0, 0, 1)
		GameTooltip:AddLine("\n", 0, 0, 1)
		for num, loot in pairs(db.raidlog[db.raidnum].loot) do
  			local name = loot.Player
  			if name == nameorlink and loot.Boss ~= "Bank" then
  				GameTooltip:AddLine(loot.ItemLink)
  			end
  		end
  	end
  	GameTooltip:Show()
end

function mod:AddDKPInfoTT(itemID, index)
	if self.items[index].quality < db.quality or self.items[index].ignore or not self:CoreStatus() or not db.InRaid or db.currDKP == "Random" then return end	
	local core = self:GetModuleRef("CoreModule")
	local needquery = core:HasItem(itemID, self.items[index].link)
	if not needquery or #needquery == 0 then return end
	local dkp = db.items[itemID].points or 0
	local currDKP = self:GetModuleRef(db.currDKP)
	local dkppoints = 0
	local POOL = db.raid
	
	--create table for output
	local temptable = {}
	local points
	for _, data in pairs(needquery) do
		self:PointsPoolExists(data.n, POOL)
		if currDKP then dkppoints = currDKP:GetPlayerPoints(data.n, POOL) end
		points = {n = dkppoints, r = 0, g = 1, b = 0}
		if db.info[data.n].raidloot == 1 then points.r = 1 end
		table.insert(temptable, {data, points, data.p})
	end
	
	--sort table
	table.sort(temptable, function(a,b)
    			if  a[3] == b[3] then
    				if a[2].n == b[2].n then
    					return a[1].n < b[1].n
    				else
					return a[2].n > b[2].n
				end
			else
				return  a[3] < b[3]
			end
		end)
	--update TT
	GameTooltip:AddLine(fmt(LL["DKP: %s"], dkp), 0, 1, 0)
	local count = 1
	for _, data in ipairs(temptable) do
		GameTooltip:AddDoubleLine("|c00FFFFFF" .. count .. ". |r" .. data[1].n, data[2].n, data[1].r, data[1].g, data[1].b, data[2].r, data[2].g, data[2].b)
		count = count + 1
		if count == 6 then break end
	end
end

function mod:RollUpdateCheck(frame)
	local id, itemID, summary, needupdate
	if frame == self.rollsummaryframe then 
		for itemid, _ in pairs(frame.itemlist) do
			if mdkp.updatedata[itemid] then
				mdkp.updatedata[itemid] = nil
				self:SortItemTT(itemid)
				needupdate = true
			end
		end
	else
		itemID = self.rollframe.scroll:GetID()
		id = self:GetRecord(itemID)
		if mdkp.updatedata[itemID] then
			mdkp.updatedata[itemID] = nil
			self:SortItemTT(itemID)
			summary = true
			needupdate = true
		end
	end
	if needupdate then self:UpdateRollFrame(id, itemID, summary) end
end

function mod:SortItemTT(item)
	if not item then return end
	local ranks
	if db.useranks and db.useranks[db.raid] then 
		ranks = db.ranks[db.raid]
	end
	local qso = { ["PENDING"] = 4, ["NEED"] = 4, ["OFFSPEC"] = 2, ["TAKE"] = 3, ["PASS"] = 1}
	table.sort(mdkp.querytooltips[item], function(a,b)
    			local ao = qso[a[2]] 
    			local bo = qso[b[2]] 
    			local ar, br
    			if ranks then
    				ar = ranks[db.info[a[1].n].rank] or 0
    				br = ranks[db.info[b[1].n].rank] or 0
    			end
    			if (not ar and not br) or (ar and br and ar == br) then
    				if  ao == bo then
    					if a[4] == b[4] then
    						if a[3].n == b[3].n then
    							return a[1].n < b[1].n
    						else
    							return a[3].n > b[3].n
						end
					else
						return a[4] < b[4]
					end
				else
					return  ao > bo
				end
			elseif ar and br then
				return ar > br
			end
		end)
end

function mod:OutputWinner(itemid, clickedwinner)
	self:debug("Output winners.."..clickedwinner..itemid)
	
	local itempoints, silent, disenchanted
	local Lootwinner = nil
	
	--modules
	self:IsDKPEnabled()
	local bidwar = self:GetModuleRef("BidWar")
	local currDKP = self:GetModuleRef(db.currDKP)
	local _, ref = currDKP:GetName()
	
	--eval winner
	local _, ItemLink, Lootitem, iQuality = self:GetRecord(itemid)
	Lootwinner = mdkp.querytooltips[itemid][1][1].n
	if Lootwinner == clickedwinner then
		if mdkp.querytooltips[itemid][1][2] == "PASS" then
			Lootwinner = db.disenchanter
			mdkp.given = nil
			disenchanted = true
		end
	else
		Lootwinner = clickedwinner
	end
	if not disenchanted and (Lootwinner == db.mlooter or Lootwinner == db.disenchanter) then mdkp.given = true end
	
	--get item value
	local POOL = self:CheckPool(itemid)
	itempoints = currDKP:GetItemValue(itemid, Lootwinner, POOL)
	if bidwar then 
		itempoints, silent = bidwar:GetItemValue(itemid, Lootwinner) 
	end
	if not itempoints then itempoints = 0 end
	
	--format output
	if not mdkp.spammed[itemid] then
		if bidwar then bidwar:OnOutputResluts(itemid, clickedwinner) end
		if disenchanted then SendChatMessage(fmt(LL["%s will be disenchanted in 5 seconds."], ItemLink), "RAID")
		elseif ref == "Random" or mdkp.random[itemid] or silent then SendChatMessage(fmt(LL["%s awarded to %s"], ItemLink, Lootwinner), "RAID") 
		else SendChatMessage(fmt(LL["%s awarded to %s for %s DKP"], ItemLink, Lootwinner, itempoints), "RAID") 
		end
		mdkp.spammed[itemid] = true
	end
	
	if GetNumLootItems() and db.mlooter == Player and Lootitem and Lootwinner then
		self.AwardBuffer[self.AwardIndex] = {item = Lootitem, winner = Lootwinner}
		local dialog = StaticPopup_Show ("MorgLoot2", ItemLink, Lootwinner)
		if dialog then dialog.data = self.AwardIndex end
		self.AwardIndex = self.AwardIndex + 1
  	end
  	
  	--end items auction
	self:SendCommMessage("MorgBid2", self:Serialize("CLOSEBID", itemid), "RAID")
end

function mod:CreateLootbutton(id, fontallowance)
	local f = CreateFrame("frame", nil, self.lootframe)
	f:SetID(id)
	f:SetFrameStrata("DIALOG")
   	f:EnableMouse(1)
   	f:ClearAllPoints()
   	f:SetBackdrop({ bgFile = media:Fetch("background", "Solid"), tile = false, tileSize = 16, edgeFile = media:Fetch("border", "Blizzard Tooltip"), edgeSize = 8, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
	f:SetBackdropColor(0,0,0,1)
	f:SetScript("OnMouseUp", function(f, button) mod:LootButton_Click(f, f:GetID(), button) end)
	f:SetScript("OnEnter", function(f)
					local slot = f:GetID()
					if db.hints and self.items[slot].id and self:CoreStatus() and not self.items[slot].ignore and self.items[slot].quality >= db.quality then 
						GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
						GameTooltip:AddLine(LL["|c000070ddClick:|r loot item\n|c000070ddR-Click:|r open itemdata or roll frame\n|c000070ddAlt-R-Click:|r start all queries"], 0, 1, 0)
						GameTooltip:Show()
					end
				end)
	f:SetScript("OnLeave", function() GameTooltip:Hide() end)
	f:SetHeight(26 + fontallowance)
	f:SetWidth(115)
	
	f.highlight = CreateFrame("frame", nil, f)
	f.highlight:SetAllPoints(f)
	f.highlight:SetBackdrop({ bgFile = "", tile = false, tileSize = 16, edgeFile = media:Fetch("border", "Blizzard Tooltip"), edgeSize = 20, insets = { left = 5, right = 5, top = 5, bottom = 5 } })
	f.highlight:SetFrameStrata("FULLSCREEN")
	f.highlight:Hide()
	
	f.icon = CreateFrame("Button", nil, f)
	f.icon:SetWidth(22 + fontallowance)
	f.icon:SetHeight(22 + fontallowance)
	f.icon:ClearAllPoints()
	f.icon:SetPoint("TOPLEFT", f, "TOPLEFT", 3, -3)
	f.icon:SetScript("OnEnter", function(f)
						local index = f:GetParent():GetID()
						if self.items[index].link then 
							GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
							GameTooltip:SetHyperlink(self.items[index].link)
							mod:AddDKPInfoTT(self.items[index].id, index)
							GameTooltip:Show()
						end
					end)
	f.icon:SetScript("OnLeave", function() GameTooltip:Hide() end)
	f.icon:SetScript("OnMouseUp", function(f, button) mod:LootButton_Click(f, f:GetParent():GetID(), button) end)
	f.icon:Show()
	
   	f.name = f:CreateFontString()
   	f.name:SetPoint("TOPLEFT", f.icon, "TOPRIGHT", 5, -1)
   	f.name:SetWidth(75)
   	f.name:SetJustifyH("LEFT")
   	f.name:SetFont(self.font, db.media.fontsize)
   	f.name:Show()
   	
	f.dkp = f:CreateFontString()
   	f.dkp:SetPoint("LEFT", f.icon, "RIGHT", 5, 0)
   	f.dkp:SetWidth(50)
   	f.dkp:SetJustifyH("LEFT")
   	f.dkp:SetFont(self.font, db.media.fontsize)
   	f.dkp:Show()
   	
   	local size = db.media.fontsize - 3
   	if size < 7 then size = 7 end
   	local yoff = db.media.fontsize - 6
   	if yoff > 4 then yoff = 4 end
   	f.class = f:CreateFontString()
   	f.class:SetPoint("BOTTOMLEFT", f.icon, "BOTTOMRIGHT", 5, yoff)
   	f.class:SetWidth(75)
   	f.class:SetJustifyH("LEFT")
   	f.class:SetTextColor(1, 1, 1)
   	f.class:SetFont(self.font, size)
   	f.class:Show()
   	
   	f.selfloot = CreateFrame("Button", nil, f)
	f.selfloot:SetWidth(15 + fontallowance/2)
	f.selfloot:SetHeight(15 + fontallowance/2)
	f.selfloot:ClearAllPoints()
	f.selfloot:SetPoint("TOPRIGHT", f, "TOPRIGHT", -3, -2)
	f.selfloot:SetScript("OnEnter", function(f)
						if db.hints then 
							GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
							GameTooltip:AddLine(LL["|c000070ddClick:|r self loot"], 0, 1, 0)
							GameTooltip:Show()
						end
					end)
	f.selfloot:SetScript("OnLeave", function() GameTooltip:Hide() end)
	f.selfloot:SetScript("OnMouseUp", function(f, button) mod:ExtraButton_Selfloot(f, self.items[f:GetParent():GetID()].slot, button) end)
	f.selfloot:SetNormalTexture("Interface\\Buttons\\UI-GroupLoot-Coin-Up")
   	f.selfloot:SetHighlightTexture("Interface\\Buttons\\UI-GroupLoot-Coin-Highlight")
	
	f.random = CreateFrame("Button", nil, f)
	f.random:SetWidth(15 + fontallowance/2)
	f.random:SetHeight(15 + fontallowance/2)
	f.random:ClearAllPoints()
	f.random:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -3, 0)
	f.random:SetScript("OnEnter", function(f)
						if db.hints then 
							GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
							GameTooltip:AddLine(LL["|c000070ddClick:|r allocate randomly"], 0, 1, 0)
							GameTooltip:Show()
						end
					end)
	f.random:SetScript("OnLeave", function() GameTooltip:Hide() end)
	f.random:SetScript("OnMouseUp", function(f, button) mod:ExtraButton_Random(f, self.items[f:GetParent():GetID()].slot, button) end)
	f.random:SetNormalTexture("Interface\\Buttons\\UI-GroupLoot-Dice-Up")
   	f.random:SetHighlightTexture("Interface\\Buttons\\UI-GroupLoot-Dice-Highlight")
	
	return f
end

function mod:CreateItemsFrame() 
	local background = media:Fetch("background", "Solid")
	local fontallowance = db.media.fontsize * 3 - 20
	if fontallowance < 0 then fontallowance = 0 end
	local f = CreateFrame("frame", nil, self.lootframe)
	f:SetFrameStrata("DIALOG")
   	f:EnableMouse(1)
   	f:ClearAllPoints()
   	f:SetBackdrop({ bgFile = background, tile = false, tileSize = 16, edgeFile = media:Fetch("border", "Blizzard Tooltip"), edgeSize = 8, insets = { left = 3, right = 0, top = 3, bottom = 3 } })
	f:SetBackdropColor(0,0,0,1)
	f:SetID(1)
	
	f.value = CreateFrame("Button", nil, f)
	f.value:EnableMouseWheel(1)
	f.value:SetWidth(25 + db.media.fontsize)
	f.value:SetHeight(25 + db.media.fontsize)
	f.value:ClearAllPoints()
	f.value:SetPoint("TOPLEFT", f, "TOPLEFT", 20, -5)
	f.value:SetNormalTexture("Interface\\Buttons\\ButtonHilight-Square")
	f.value:SetScript("OnMouseWheel", function(f, direction) self:SetValue(f, f:GetParent():GetID(), direction) end)
	f.value:SetScript("OnMouseDown", function(f, direction) self:SetValue(f, f:GetParent():GetID(), direction) end)
	f.value:SetScript("OnEnter", function(f)
					if db.hints then 
						GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
						GameTooltip:SetText(LL["|c000070ddMousewheel up/Click|r - Increase value.\n|c000070ddMousewheel down/R-Click|r - decrease value.\n|c000070ddSHIFT|r - change value by +/-1\n|c000070ddALT|r - change value by +/-20\n|c000070ddCTRL|r - change value by +/-100"])
						GameTooltip:Show()
					end
				end)
	f.value:SetScript("OnLeave", function() GameTooltip:Hide() end)
	f.value:Show()
	
	f.value.text = f.value:CreateFontString()
   	f.value.text:SetFont(self.font, db.media.fontsize + 2)
   	f.value.text:SetTextColor(0,1,0)
	f.value.text:ClearAllPoints()
	f.value.text:SetPoint("CENTER", f.value, "CENTER")
	f.value.text:SetText("0")
		
	f.multi = CreateFrame("Button", nil, f)
   	f.multi:SetWidth(50)
   	f.multi:SetHeight(20)
   	f.multi:ClearAllPoints()
	f.multi:SetPoint("TOPRIGHT", f, "TOPRIGHT", -15, -5)
   	f.multi:SetScript("OnClick", function(f) mod:ShowPoolMenu(f, f:GetParent():GetID()) end)
   	f.multi:SetScript("OnEnter", function(f)
					if db.hints and db.multiPool then 
						GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
						GameTooltip:SetText(LL["|c000070ddClick:|r select pool to use for item."])
						GameTooltip:Show()
					end
				end)
	f.multi:SetScript("OnLeave", function() GameTooltip:Hide() end)
	
   	f.multi.text = f.multi:CreateFontString()
   	f.multi.text:SetFont(self.font, db.media.fontsize)
   	f.multi.text:SetTextColor(1,1,0)
	f.multi.text:ClearAllPoints()
	f.multi.text:SetPoint("CENTER", f.multi, "CENTER")
	f.multi.text:SetText("")
	
   	f.roll = CreateFrame("Button", nil, f)
	f.roll:SetWidth(15 + fontallowance)
	f.roll:SetHeight(15 + fontallowance)
	f.roll:ClearAllPoints()
	f.roll:SetScript("OnEnter", function(f)
						if db.hints then 
							GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
							GameTooltip:AddLine(LL["|c000070ddClick:|r start item query.\n|c000070ddAlt-Click:|r start all queries\n|c000070ddShift-Click:|r random query for this item\n|c000070ddCtrl-Click:|r ignore this item"], 0, 1, 0)
							GameTooltip:Show()
						end
					end)
	f.roll:SetScript("OnLeave", function() GameTooltip:Hide() end)
	f.roll:SetScript("OnMouseUp", function(f, button) mod:ItemQuery_Button(f, f:GetParent():GetID(), button) end)
	f.roll:SetNormalTexture("Interface\\Buttons\\UI-GroupLoot-Dice-Up")
   	f.roll:SetHighlightTexture("Interface\\Buttons\\UI-GroupLoot-Dice-Highlight")
   	f.roll:SetDisabledTexture("Interface\\DialogFrame\\DialogAlertIcon")
   	f.roll:Show()
   	
   	self:CreateBridge(f, background, fontallowance)
	
	f.cf = {}
   	f.pclass = {}
	f.altclass = {}
	f.classname = {}
	
	f.actitle = f:CreateFontString()
   	f.actitle:SetJustifyH("LEFT")
   	f.actitle:SetFont(self.font, db.media.fontsize)
   	f.actitle:SetTextColor(1,1,1)
   	
   	f.actitle:SetText("Deathknight")
   	local length = f.actitle:GetStringWidth() + 30
   	f.actitle:SetText(LL["Alt"])
   	f.actitle:SetWidth(f.actitle:GetStringWidth() + 10)
   	f.actitle:Show()
   	
   	f.ctitle = f:CreateFontString()
   	f.ctitle:SetPoint("TOPLEFT", f.value, "BOTTOMLEFT", 5, -3)
   	f.ctitle:SetJustifyH("CENTER")
   	f.ctitle:SetFont(self.font, db.media.fontsize)
   	f.ctitle:SetTextColor(1,1,1)
   	f.ctitle:SetText(LL["Class"])
   	f.ctitle:SetWidth(f.ctitle:GetStringWidth() + 10)
   	f.ctitle:Show()
   	
   	local localizedclass
   	local height
   	local checksize
   	height = db.media.fontsize
   	checksize = 20
	if height < 15 then height = 15	end
	local frame = f.ctitle
   	local x, y = 5, 0
   	for _, class in ipairs(mdkp.orderedclasses) do
   		if class ~= L["ALL"] then localizedclass = BC[string.upper(string.sub(class,1,1)) .. string.lower(string.sub(class, 2, -1))] 
		else localizedclass = L["ALL"] end
		local color = mdkp.ClasscolorsDEC[class]
		f.cf[class] = CreateFrame("frame", nil, f)
		f.cf[class]:SetFrameStrata("DIALOG")
   		f.cf[class]:EnableMouse(1)
   		f.cf[class]:ClearAllPoints()
   		f.cf[class]:SetBackdrop({ bgFile = background, tile = false, tileSize = 16, edgeFile = "", edgeSize = 4, insets = { left = 3, right = 0, top = 3, bottom = 3 } })
		f.cf[class]:SetBackdropColor(0,0,0,1)
		f.cf[class]:SetHeight(height)
		f.cf[class]:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", x, y)
		f.cf[class]:SetWidth(length + 15)
		
		f.cf[class].pclass = CreateFrame("CheckButton", nil, f.cf[class])
		f.cf[class].pclass:SetWidth(checksize)
		f.cf[class].pclass:SetHeight(checksize)
		f.cf[class].pclass:ClearAllPoints()
		f.cf[class].pclass:SetPoint("LEFT", f.cf[class], "LEFT", 0, 0)
		f.cf[class].pclass:SetScript("OnEnter", function(f)
						if db.hints then 
							GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
							GameTooltip:AddLine(LL["Select primary class"], 0, 1, 0)
							GameTooltip:Show()
						end
					end)
		f.cf[class].pclass:SetScript("OnLeave", function() GameTooltip:Hide() end)
		f.cf[class].pclass:SetScript("OnMouseUp", function(f, button) mod:Toggle_Class(f, f:GetParent():GetParent():GetID(), class, "classes") end)
		f.cf[class].pclass:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
   		f.cf[class].pclass:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight")
   		f.cf[class].pclass:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")
   		f.cf[class].pclass:Show()
		
		f.cf[class].classname = f.cf[class]:CreateFontString()
   		f.cf[class].classname:ClearAllPoints()
   		f.cf[class].classname:SetPoint("TOP", f.cf[class], "TOP", 0, 0)
   		f.cf[class].classname:SetJustifyH("CENTER")
   		f.cf[class].classname:SetJustifyV("MIDDLE")
   		f.cf[class].classname:SetFont(self.font, db.media.fontsize)
   		f.cf[class].classname:SetTextColor(color.r, color.g, color.b)
   		f.cf[class].classname:SetHeight(height)
   		f.cf[class].classname:SetText(localizedclass)
   		f.cf[class].classname:Show()
   		
   		f.cf[class].altclass = CreateFrame("CheckButton", nil, f.cf[class])
		f.cf[class].altclass:SetWidth(checksize)
		f.cf[class].altclass:SetHeight(checksize)
		f.cf[class].altclass:ClearAllPoints()
		f.cf[class].altclass:SetPoint("RIGHT", f.cf[class], "RIGHT", 0, 0)
		f.cf[class].altclass:SetScript("OnEnter", function(f)
						if db.hints then 
							GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
							GameTooltip:AddLine(LL["Select secondary class"], 0, 1, 0)
							GameTooltip:Show()
						end
					end)
		f.cf[class].altclass:SetScript("OnLeave", function() GameTooltip:Hide() end)
		f.cf[class].altclass:SetScript("OnMouseUp", function(f, button) mod:Toggle_Class(f, f:GetParent():GetParent():GetID(), class, "altclasses") end)
		f.cf[class].altclass:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
   		f.cf[class].altclass:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight")
   		f.cf[class].altclass:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")
   		f.cf[class].altclass:Show()
		
		frame = f.cf[class]
		x = 0
		y = 3
	end
	
	f.actitle:SetPoint("BOTTOMRIGHT", f.cf["DRUID"].altclass, "TOPRIGHT", 2, 0)
	f.roll:SetPoint("BOTTOM", f.cf["DRUID"], "TOP", 0, 5)
	f:SetHeight(13 * height + checksize)
	f:SetWidth(f.cf["DRUID"]:GetWidth() + 55)
	
	return f
end

function mod:CreateBridge(f, background, fontallowance)
	f.bridge = CreateFrame("frame", nil, f)
	f.bridge:SetFrameStrata("DIALOG")
   	f.bridge:ClearAllPoints()
   	f.bridge:SetBackdrop({ bgFile = background, tile = false, tileSize = 16, edgeFile = "", edgeSize = 4, insets = { left = 3, right = 0, top = 3, bottom = 3 } })
	f.bridge:SetBackdropColor(0,0,0,1)
	f.bridge:SetHeight(34 + fontallowance)
	f.bridge:SetWidth(8)
	
	f.bridge.icon = f.bridge:CreateTexture()
	f.bridge.icon:ClearAllPoints()
	f.bridge.icon:SetPoint("LEFT", f.bridge, "LEFT", 8, -1)
	f.bridge.icon:SetHeight(20)
	f.bridge.icon:SetWidth(20)
	f.bridge.icon:SetTexture("Interface\\MoneyFrame\\Arrow-Right-Up")
	f.bridge.icon:SetVertexColor(0, 1, 0, 1)
	f.bridge.icon:Show()
   	
	f.bridge.texture = f.bridge:CreateTexture()
	f.bridge.texture:ClearAllPoints()
	f.bridge.texture:SetPoint("TOP", f.bridge, "TOP", 0, -3)
	f.bridge.texture:SetHeight(1)
	f.bridge.texture:SetWidth(4)
	f.bridge.texture:SetTexture("Interface\\Buttons\\UI-SliderBar-Border")
	f.bridge.texture:Show()
	
	f.bridge.texture2 = f.bridge:CreateTexture()
	f.bridge.texture2:ClearAllPoints()
	f.bridge.texture2:SetPoint("BOTTOM", f.bridge, "BOTTOM", 0, 3)
	f.bridge.texture2:SetHeight(1)
	f.bridge.texture2:SetWidth(4)
	f.bridge.texture2:SetTexture("Interface\\Buttons\\UI-SliderBar-Border")
	f.bridge.texture2:Show()
end

function mod:CreateRollFrame()
	local background = media:Fetch("background", "Solid")
	local border = media:Fetch("border", "Blizzard Tooltip")
	local font = media:Fetch("font", db.media.font)
	local fontallowance = db.media.fontsize * 3 - 20
	if fontallowance < 0 then fontallowance = 0 end
	self.rollframe = CreateFrame("frame", nil, self.lootframe)
	--single frame
	local f = self.rollframe
	
	f:SetFrameStrata("DIALOG")
   	f:ClearAllPoints()
   	f:SetBackdrop({ bgFile = background, tile = false, tileSize = 16, edgeFile = border, edgeSize = 8, insets = { left = 3, right = 0, top = 3, bottom = 3 } })
	f:SetBackdropColor(0,0,0,1)
	
	f.title = f:CreateFontString()
   	f.title:SetPoint("TOP", f, "TOP", -10, -5)
   	f.title:SetJustifyH("CENTER")
   	f.title:SetFont(font, db.media.fontsize + 1)
   	f.title:Show()
   	
   	f.stoproll = self:CreateStopButton(f, background, border)
   	f.stoproll:SetPoint("LEFT", f.title, "RIGHT", 5, -1)
   	
	f.de = self:CreateDEButton(f, background, border)
   	f.de:SetPoint("LEFT", f.stoproll, "RIGHT", 2, 0)
   	
   	f.hint = f:CreateFontString()
   	f.hint:SetPoint("BOTTOM", f, "BOTTOM", 3, 5)
   	f.hint:SetJustifyH("CENTER")
   	f.hint:SetFont(font, db.media.fontsize)
   	f.hint:SetText(LL["|c000070ddClick:|r Announce winner."])
   	f.hint:SetTextColor(0, 0.819, 0.0)
   	f.hint:Show()
   		
   	f.scroll = self:CreateScrollFrame(f, background, border)
   	self:CreateBridge(f, background, fontallowance)
	
	--summary frame
	self.rollsummaryframe = CreateFrame("frame", nil, self.lootframe)
	local f = self.rollsummaryframe
	
	f:SetFrameStrata("DIALOG")
   	f:ClearAllPoints()
   	f:SetBackdrop({ bgFile = background, tile = false, tileSize = 16, edgeFile = border, edgeSize = 8, insets = { left = 3, right = 0, top = 3, bottom = 3 } })
	f:SetBackdropColor(0,0,0,1)
	
	f.hint = f:CreateFontString()
   	f.hint:SetPoint("BOTTOM", f, "BOTTOM", 3, 5)
   	f.hint:SetJustifyH("CENTER")
   	f.hint:SetFont(font, db.media.fontsize)
   	f.hint:SetText(LL["|c000070ddClick:|r Announce winner."])
   	f.hint:SetTextColor(0, 0.819, 0.0)
   	f.hint:Show()
   	f.scroll = {}
   	f.stoproll = {}
   	f.de = {}
   	f.scroll.scrollid = 1
   	f.title = {}
   	f.itemlist = {}
   	f.numitems = 0
end

function mod:CreateScrollFrame(parent, background, border)
	local f = CreateFrame("ScrollFrame", nil, parent)
   	f:EnableMouse(1)
   	f:ClearAllPoints()
   	f:EnableMouseWheel(1)
   	f:SetBackdrop({ bgFile = background, tile = false, tileSize = 16, edgeFile = border, edgeSize = 8, insets = { left = 3, right = 0, top = 3, bottom = 3 } })
	f:SetBackdropColor(0,0,0,1)
	f:SetBackdropBorderColor(1, 1, 1, 1)
	f.text = {}
   	f.textid = 1
	f.textlen = 0
	f.height = 0
	return f
end

function mod:CreateStopButton(parent, background, border)
	local f = CreateFrame("Button", nil, parent)
	f:SetWidth(5 + db.media.fontsize)
	f:SetHeight(5 + db.media.fontsize)
	f:ClearAllPoints()
	f:SetScript("OnEnter", function(f)
						if db.hints then 
							GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
							GameTooltip:AddLine(LL["|c000070ddClick:|r stop this item query."], 0, 1, 0)
							GameTooltip:Show()
						end
					end)
	f:SetScript("OnLeave", function() GameTooltip:Hide() end)
	f:SetScript("OnMouseUp", function(f, button) mod:StopItemQuery_Button(f, f:GetID(), button) end)
	f:SetNormalTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Up")
   	f:SetHighlightTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Highlight")
   	f:Show()
   	return f
end

function mod:CreateDEButton(parent, background, border)
	local f = CreateFrame("Button", nil, parent)
	f:SetWidth(3 + db.media.fontsize)
	f:SetHeight(3 + db.media.fontsize)
	f:ClearAllPoints()
	f:SetScript("OnEnter", function(f)
						if db.hints then 
							GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
							GameTooltip:AddLine(LL["|c000070ddClick:|r give this item to disenchanter."], 0, 1, 0)
							GameTooltip:Show()
						end
					end)
	f:SetScript("OnLeave", function() GameTooltip:Hide() end)
	f:SetScript("OnMouseUp", function(f, button) mod:SendtoDisenchanter(f, f:GetID(), button) end)
	f:SetNormalTexture("Interface\\Icons\\INV_Enchant_ShardNexusLarge")
   	f:SetHighlightTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Highlight")
   	f:Show()
   	return f
end

function mod:IsML()
	if db.mlooter == Player then return true end
	return false
end

function mod:LootButton_Click(frame, slot, button)
	self:debug("Click.."..slot..button)
	local blizzslot = self.items[slot].slot
	if IsModifiedClick("DRESSUP") or IsModifiedClick("CHATLINK") or IsModifiedClick("SOCKETITEM") or IsModifiedClick("SPLITSTACK") or IsModifiedClick("COMPAREITEMS") then
		HandleModifiedItemClick(GetLootSlotLink(blizzslot))
		return
	end
	self.clickedslot = slot
	if button == "RightButton" and self:CoreStatus() then
		if IsAltKeyDown() then self:StartAllItemQueries() 
		else
			--open itemframe
			self:UpdateLootFrame(slot, self.items[slot].id, true, true, true)
		end
		return
	end
	if self.items[slot].quantity == -1 then self:OpenInvMenu(self.items[slot].link, frame)
	else LootSlot(blizzslot) end
end

function mod:UpdateHighlights(slot, itemid, r, g, b)
	self.lootframe.buttons[slot].highlight:Show()
	self.lootframe.buttons[slot].highlight:SetBackdropBorderColor(r,g,b,1) 
	self.highlightitem = itemid
end

function mod:ExtraButton_Selfloot(frame, slot, button)
	self:debug("Self looting.."..slot)
	self:GivetoX(slot, Player)
end

function mod:GivetoX(slot, name)
	local id
	for i = 1, 40 do
		if GetMasterLootCandidate(i) == name then
			id = i
			break
		end
	end
	if id then 
		GiveMasterLoot(slot, id)
		self:debug("Gave slot#"..slot.." to "..name..id)
	end
	self.extrabutton = true
end

function mod:ExtraButton_Random(f, slot, button)
	self:debug("Random item.."..slot)
	local candidates = self:GetMLCandidates()
	if #candidates == 0 then 
		self.awardedrandomitem = {}
		candidates = self:GetMLCandidates()
	end
	local winner
	if #candidates > 1 then winner = math.random(1, #candidates)
	else winner = 1 end
	local winnerid = candidates[winner].id
	self.awardedrandomitem[candidates[winner].n] = true
	if winnerid and slot then 
		GiveMasterLoot(slot, winnerid)
		self:debug("Gave slot#"..slot.." to "..candidates[winner].n..winnerid)
	end
	self.extrabutton = true
end

--returns all ML candidates
function mod:GetMLCandidates()
	local temptable = {}
	for i = 1, 40 do
		local name = GetMasterLootCandidate(i)
		if name then
			local online = UnitIsConnected(name) 
  			if online and not self.awardedrandomitem[name] then
				table.insert(temptable, {n = name, id = i})
			end
		end
	end
	return temptable
end

function mod:SetValue(frame, itemID, button)
	local db = db.items
	local value = db[itemID].points
	local step = 5
	if IsShiftKeyDown() then step = 1 
	elseif IsAltKeyDown() then step = 20 
	elseif IsControlKeyDown() then step = 100 
	end
	if button == 1 then value = value + step
	elseif button == -1 then value = value - step
	elseif button == "LeftButton" then value = value + step
	elseif button == "RightButton" then value = value - step
	end
	frame.text:SetText(value)
	db[itemID].points = value
	
	--add item for sync
	local sync = self:GetModuleRef("Syncing")
	if sync then sync:AddItem(itemID) end
end

function mod:Toggle_Class(frame, itemID, class, switch)
	local classes = db.items[itemID][switch]
	local bit = mdkp.Bits[class]
	local result
	local checked = not frame:GetChecked()
	local f = frame:GetParent():GetParent()
	if class == L["ALL"] then 
		for class2, bit in pairs(mdkp.Bits) do
			if class2 ~= L["ALL"] then
				if switch == "classes" then f.cf[class2].pclass:SetChecked(checked)
				else f.cf[class2].altclass:SetChecked(checked) end
			end
		end
		if checked then result = 2047
		else result = 0 end
	else result = bxor(classes, bit) 
	end
	if result == 2046 then result = 2047 end
	db.items[itemID][switch] = result
	if result == 0 and switch == "classes" then f.roll:Disable()
	else f.roll:Enable() end
	
	--add item for sync
	local sync = self:GetModuleRef("Syncing")
	if sync then sync:AddItem(itemID) end
end

function mod:ToggleClassinDB(id, class, rank)
	local classes = db.items[id].classes
	local altclasses = db.items[id].altclasses
	local bit = mdkp.Bits[class]
	local result, switch
	if rank == 5 then	--toggle primary class
		result = bor(classes, bit)
		if band(altclasses, bit) == bit then db.items[id].altclasses = bxor(altclasses, bit) end
		switch = "classes"
	else			--toggle alt class
		if band(classes, bit) == 0 then result = bor(altclasses, bit)
		else result = altclasses end
		switch = "altclasses"
	end
	if result == 2046 then result = 2047 end
	db.items[id][switch] = result
end

function mod:ItemQuery_Button(frame, itemID, button)
	self:debug("Item query.."..itemID)
	if not frame:IsEnabled() then return end
	if IsAltKeyDown() then self:StartAllItemQueries() return
	elseif IsShiftKeyDown() then mdkp.random[itemID] = true
	elseif IsControlKeyDown() then 
		local _, link = self:GetRecord(itemID)
		mdkp.db.profile.ignore[itemID] = true
		self:out(format(L["Added %s to ignore list."], link))
		self:UpdateLootFrame(nil, nil, nil, nil, true)
		return
	end
	self:StartItemQuery(frame, itemID, true)		--true to show itemroll frame not summary frame
end

function mod:StopItemQuery_Button(frame, itemID, button)
	self:debug("Stop query.."..itemID)
	mdkp.AuctionStatus[itemID] = nil
	mdkp.spammed[itemID] = nil
	self:SendCommMessage("MorgBid2", self:Serialize("CLOSE", itemID), "RAID")
	self:UpdateLootFrame(nil, nil, nil, nil, true)
end

function mod:SendtoDisenchanter(frame, itemID, button)
	self:debug("Give to DEer.."..itemID)
	self:SendCommMessage("MorgBid2", self:Serialize("CLOSE", itemID), "RAID")
	mdkp.AuctionStatus[itemID] = nil
	mdkp.spammed[itemID] = nil
	local slot = self:GetRecord(itemID)
	local blizzslot = self.items[slot].slot
	self:GivetoX(blizzslot, db.disenchanter)
	self:UpdateLootFrame(nil, nil, nil, nil, true)
end

function mod:ShowPoolMenu(f, itemID)
	self:debug("Pool menu.."..itemID)
	self:Opendewdrop(f, db.raidlist, nil, itemID)
	if db.items[itemID].pool then f:SetText(db.items[itemID].pool) end
end

function mod:CreateMLMenu()
	local validate = self:CreateClassMenu()
	self:Opendewdrop(self.lootframe.buttons[self.clickedslot], validate, nil, "ML", nil, 1)
end

function mod:CreateClassMenu()
	local temptable = {}
	local pdata
	for _, player in pairs(db.raidmembers) do
		pdata = self:GetClasscolors(player)
		if not pdata.c then pdata.c = "UNKNOWN" end
		if not temptable[pdata.c] then temptable[pdata.c] = {} end
		table.insert(temptable[pdata.c], {n = pdata.n, r = pdata.r, g = pdata.g, b = pdata.b})
	end
	table.sort(temptable, function(a,b)
  				if a < b then return true
				else return false end
			end)
	return temptable
end

function mod:MLchosen(Lootwinner)
	if not self.clickedslot then self:debug("!CLICKED SLOT IS NIL!") return end
	self:debug((Lootwinner or "Lootwinner is NIL"))
	self.AwardBuffer[self.AwardIndex] = {item = self.items[self.clickedslot].name, winner = Lootwinner}
	local dialog = StaticPopup_Show ("MorgLoot2", self.items[self.clickedslot].link, Lootwinner)
	if dialog then dialog.data = self.AwardIndex end
	self.AwardIndex = self.AwardIndex + 1
end

function mod:GiveOutLoot(data)
	local index = data.data
	local winner = self.AwardBuffer[index].winner
	local item = self.AwardBuffer[index].item
	self:debug((index or "NIL") .. (item or "NIL")..(winner or "NIL"))
	self.extrabutton = true		--so lootframe won't move
	for ci = 1, 40 do
		if GetMasterLootCandidate(ci) == winner then
  			for li = 1, GetNumLootItems() do
  				local lootIcon, lootName, lootQuantity, rarity = GetLootSlotInfo(li)
  				if lootName == item then
  					self:debug("GIVE!"..li..ci)
  					GiveMasterLoot(li, ci)
					return
				end
  			end
 		end
	end
end

--queries

function mod:StartAllItemQueries()
	self:debug("Start all queries")
	local core = self:GetModuleRef("CoreModule")
	if not core then self:out("ERROR! CoreModule not present") return end
	for i, itemdata in ipairs(self.items) do
		if itemdata.id and not itemdata.ignore and itemdata.quality >= db.quality and not itemdata.coin then
			core:ItemQuery(itemdata.id, itemdata.link)
		end
	end
	self:UpdateLootFrame(nil, nil, nil, nil, true)
end

function mod:StartItemQuery(frame, itemID, notsummary)
	local _, link = self:GetRecord(itemID)
	local core = self:GetModuleRef("CoreModule")
	if core then started = core:ItemQuery(itemID, link) 
	else self:out("ERROR! CoreModule not present") end
	if started then
		local id = self:GetRecord(itemID)
		self:UpdateLootFrame(id, itemID, notsummary, nil, true)
	end
end

--returns record#, link, name, quality, icon given itemid from self.items
function mod:GetRecord(itemID, link)
	for num, itemdata in pairs(self.items) do
		if itemID and itemID == itemdata.id then
			return num, itemdata.link, itemdata.name, itemdata.quality, itemdata.icon
		elseif link and link == itemdata.link then return num, itemdata.id, itemdata.name, itemdata.quality, itemdata.icon
		end
	end
	return nil
end

function mod:OpenInvMenu(itemlink, frame)
	local validate = self:CreateClassMenu()
	mdkp.boelink = itemlink
	self:Opendewdrop(self.lootframe.buttons[self.clickedslot], validate, nil, "BOE", nil, 1)
end

function mod:AddManualItem(itemlink)
	self:debug("Add manual item...")
	
	--get item info
	local _, _, qid = find(itemlink, "Hitem:(%d+)")
	local id = tonumber(qid)
	local sName, _, iQuality, _, _, class, subclass, _, iEquipLoc, iconGIF = GetItemInfo(id)
	local index 
	if self.items then index = #self.items + 1 
	else 
		self.items = {}
		index = 1 
	end
	self.numqueries = index
	self:AddItemforQuery(itemlink, id, iconGIF, sName, iQuality, index, nil, -1)
	self:UpdateLootFrame(nil, nil, nil, nil, true)
end
