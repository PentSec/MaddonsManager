local mod = MorgDKP2:NewModule("RaidTracker")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.RaidTracker
local media = LibStub("LibSharedMedia-3.0", true)
local BC = LibStub("LibBabble-Class-3.0"):GetLookupTable()


local mdkp = MorgDKP2
mod.modName = "RaidTracker"

local Player = UnitName("player")
local db
local fmt = string.format
local tsort = table.sort
local tinsert = table.insert
local tremove = table.remove
local find = string.find
local ssub = string.sub
local band = bit.band
local bor = bit.bor
local bxor = bit.bxor

local defaults = { 
	profile = {
		frames = {	
			raidtracker = {point = "CENTER", relpoint = "CENTER", x = 0, y = 0, width = 400, height = 400}
		},
	},
}

function mod:GetOptions()
	return nil
end

function mod:IsDKP()
	return nil
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("RaidTracker", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
	db.moduleON["RaidTracker"] = true
	
	self.scrolldata = nil
	self.font = media:Fetch("font", db.media.font)
	self.editing = nil
	self.editraid = nil
	self.maxitems = 1
	self.editpool = nil
	self.frameedit = 1
end

function mod:OnDisable()
	db.moduleON["RaidTracker"] = nil
						
end

function mod:OpenFrame()
	if not mdkp.frames["raidtracker"] then self:CreateRaidtrackerframe() end
	if not mdkp.frames["raidtracker"]:IsShown() then mdkp.frames["raidtracker"]:Show() end
	self:ShowRaidFrame(self.frameedit)
	--self:ShowRaid(db.raidnum)
end

function mod:ForceRaidUpdate()
	if mdkp.frames and mdkp.frames["raidtracker"] and mdkp.frames["raidtracker"]:IsShown() and self.frameedit == 1 then 
		self:ShowRaid()
	end
end

function mod:CreateRaidtrackerframe()
	local name = "raidtracker"
	local background = media:Fetch("background", db.media.background)
	local border
	if db.media.border == "None" then border = media:Fetch("border", "Blizzard Tooltip")
	else border = media:Fetch("border", db.media.border) end
	local font = self.font
	local fontsize = db.media.fontsize
	local fontallowance = db.media.fontsize * 3 - 25
	local masterframewidth, masterframeheight = self.db.profile.frames.raidtracker.width, self.db.profile.frames.raidtracker.height					
   	local lootbuttonwidth = masterframewidth - 300
   	if lootbuttonwidth > 300 then lootbuttonwidth = 300 
   	elseif lootbuttonwidth < 200 then lootbuttonwidth = 200 end
   	local mastereditwidth = masterframewidth - lootbuttonwidth - 80
   	if mastereditwidth > 275 then mastereditwidth = 275 end
   	
	local minwidth = 155
	local title = "Raid Tracker"
	local ondragstart = function(f) f:StartMoving() end
	local ondragstop =  function(f)
   					f:StopMovingOrSizing()
   					local point, _, relativePoint, x, y = f:GetPoint()
					self.db.profile.frames[name].point = point
					self.db.profile.frames[name].relpoint = relativePoint
					self.db.profile.frames[name].x = x
					self.db.profile.frames[name].y = y
   				end
   	local onmouseup = function(f, button) if button == "RightButton" then mdkp.querytooltips[f.datacheck] = nil f:Hide() end end 
   	mdkp.frames[name] = self:Createframe(nil, nil, nil, nil, onmouseup, nil, name, nil, nil, title, ondragstart, ondragstop)
	
	local f = mdkp.frames[name]
	local framepos = self.db.profile.frames[name]
	local point, relpoint, x, y = framepos.point, framepos.relpoint, framepos.x, framepos.y
	f:ClearAllPoints()
	f:SetPoint(point, UIParent, relpoint, x, y)
	f:SetResizable(1)
	f:SetFrameStrata("DIALOG")
	
	f.close = CreateFrame("Button", nil, f)
   	f.close:SetScript("OnClick", function(f) f:GetParent():Hide() end)
   	f.close:SetWidth(20)
   	f.close:SetHeight(20)
   	f.close:SetNormalTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up")
   	f.close:SetPushedTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Down")
   	f.close:SetHighlightTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight")
   	f.close:ClearAllPoints()
   	f.close:SetPoint("TOPRIGHT", f, "TOPRIGHT")
   	f.close:SetHitRectInsets(5, 5, 5, 5)
   	f.close:Show()
   	
   	f.size = CreateFrame("Button", nil, f)
   	f.size:SetScript("OnMouseDown", function(f) 
   						local p = f:GetParent()
   						p:StartSizing() 
				end)
   	f.size:SetScript("OnMouseUp", function(f)
   					local p = f:GetParent()
   					p:StopMovingOrSizing()
   					local width, height = p:GetWidth(), p:GetHeight()
					self.db.profile.frames[name].width = width
					self.db.profile.frames[name].height = height
					self:AdjustFrames(width, height)
   				end)
   	f.size:SetWidth(10)
   	f.size:SetHeight(10)
   	f.size:SetNormalTexture("Interface\\Buttons\\UI-AutoCastableOverlay")
   	local texture = f.size:GetNormalTexture()
   	texture:SetTexCoord(.629, .759, .615, .770)
   	texture:SetVertexColor(unpack(db.media.borderC))
   	f.size:SetPushedTexture("Interface\\Buttons\\UI-AutoCastableOverlay")
   	local texture = f.size:GetPushedTexture()
   	texture:SetTexCoord(.629, .759, .615, .770)
   	texture:SetVertexColor(1,0,0,1)
   	f.size:SetHighlightTexture("Interface\\Buttons\\UI-AutoCastableOverlay")
   	local texture = f.size:GetHighlightTexture()
   	texture:SetTexCoord(.629, .759, .615, .770)
   	texture:SetVertexColor(1,1,1,1)
   	f.size:ClearAllPoints()
   	f.size:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -2, 2)
   	f.size:Show()
   	
   	f.buttons = {}
   	--raid editing
   	f.buttons[1] = CreateFrame("Button", nil, f)
   	f.buttons[1]:SetID(1)
   	f.buttons[1]:SetScript("OnClick", function(f) self:ShowRaidFrame(f:GetID()) self:ShowRaid() end)
   	f.buttons[1]:SetNormalTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Up")
   	local texture = f.buttons[1]:GetNormalTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	f.buttons[1]:SetHighlightTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Glow")
   	local texture = f.buttons[1]:GetHighlightTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	f.buttons[1]:ClearAllPoints()
   	f.buttons[1]:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 4, 4)
   	f.buttons[1]:SetHitRectInsets(5, 5, 5, 5)
   	f.buttons[1]:Show()
   	
   	f.buttons[1].text = f.buttons[1]:CreateFontString()
   	f.buttons[1].text:SetFont(font, fontsize)
   	f.buttons[1].text:ClearAllPoints()
	f.buttons[1].text:SetPoint("CENTER", f.buttons[1], "CENTER",0,0)
	f.buttons[1].text:SetText(LL["Raids"])
	local width = f.buttons[1].text:GetStringWidth() + 15
	f.buttons[1].text:SetWidth(width)
	f.buttons[1]:SetWidth(width)
	f.buttons[1]:SetHeight(25)
   	minwidth = minwidth + width
   	
   	--item database
   	f.buttons[2] = CreateFrame("Button", nil, f)
   	f.buttons[2]:SetID(2)
   	f.buttons[2]:SetScript("OnClick", function(f) self:ShowRaidFrame(f:GetID()) self:ShowItemDB() end)
   	f.buttons[2]:SetNormalTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Up")
   	local texture = f.buttons[2]:GetNormalTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	f.buttons[2]:SetHighlightTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Glow")
   	local texture = f.buttons[2]:GetHighlightTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	f.buttons[2]:ClearAllPoints()
   	f.buttons[2]:SetPoint("LEFT", f.buttons[1], "RIGHT", 0, 0)
   	f.buttons[2]:Show()
   	
   	f.buttons[2].text = f.buttons[2]:CreateFontString()
   	f.buttons[2].text:SetFont(font, fontsize)
   	f.buttons[2].text:ClearAllPoints()
	f.buttons[2].text:SetPoint("CENTER", f.buttons[2], "CENTER",0,0)
	f.buttons[2].text:SetText(LL["Item DB"])
	local width = f.buttons[2].text:GetStringWidth() + 15
	f.buttons[2].text:SetWidth(width)
	f.buttons[2]:SetWidth(width)
	f.buttons[2]:SetHeight(25)
   	minwidth = minwidth + width
   	
	--ALiases
	f.buttons[3] = CreateFrame("Button", nil, f)
   	f.buttons[3]:SetID(3)
   	f.buttons[3]:SetScript("OnClick", function(f) self:ShowRaidFrame(f:GetID()) self:ShowAliases() end)
   	f.buttons[3]:SetNormalTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Up")
   	local texture = f.buttons[3]:GetNormalTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	f.buttons[3]:SetHighlightTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Glow")
   	local texture = f.buttons[3]:GetHighlightTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	f.buttons[3]:ClearAllPoints()
   	f.buttons[3]:SetPoint("LEFT", f.buttons[2], "RIGHT", 0, 0)
   	f.buttons[3]:SetHitRectInsets(5, 5, 5, 5)
   	f.buttons[3]:Show()
   	
   	f.buttons[3].text = f.buttons[3]:CreateFontString()
   	f.buttons[3].text:SetFont(font, fontsize)
   	f.buttons[3].text:ClearAllPoints()
	f.buttons[3].text:SetPoint("CENTER", f.buttons[3], "CENTER",0,0)
	f.buttons[3].text:SetText(LL["Aliases"])
	local width = f.buttons[3].text:GetStringWidth() + 15
	f.buttons[3].text:SetWidth(width)
	f.buttons[3]:SetWidth(width)
	f.buttons[3]:SetHeight(25)
   	minwidth = minwidth + width
   	
	--DKP changes
	f.buttons[4] = CreateFrame("Button", nil, f)
   	f.buttons[4]:SetID(4)
   	f.buttons[4]:SetScript("OnClick", function(f) self:ShowRaidFrame(f:GetID()) self:ShowDKPChanges() end)
   	f.buttons[4]:SetNormalTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Up")
   	local texture = f.buttons[4]:GetNormalTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	f.buttons[4]:SetHighlightTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Glow")
   	local texture = f.buttons[4]:GetHighlightTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	f.buttons[4]:ClearAllPoints()
   	f.buttons[4]:SetPoint("LEFT", f.buttons[3], "RIGHT", 0, 0)
   	f.buttons[4]:SetHitRectInsets(5, 5, 5, 5)
   	f.buttons[4]:Show()
   	
   	f.buttons[4].text = f.buttons[4]:CreateFontString()
   	f.buttons[4].text:SetFont(font, fontsize)
   	f.buttons[4].text:ClearAllPoints()
	f.buttons[4].text:SetPoint("CENTER", f.buttons[4], "CENTER",0,0)
	f.buttons[4].text:SetText(LL["DKP Changes"])
	local width = f.buttons[4].text:GetStringWidth() + 15
	f.buttons[4].text:SetWidth(width)
	f.buttons[4]:SetWidth(width)
	f.buttons[4]:SetHeight(25)
   	minwidth = minwidth + width
   	
   	f:SetMinResize(minwidth, 200)
   	local width, height = self.db.profile.frames[name].width, self.db.profile.frames[name].height					
   	if width < minwidth then width = minwidth end
   	f:SetWidth(width)
   	f:SetHeight(height)
   	
   	--raids frame
   	f.frame = {}
   	f.frame[1] = CreateFrame("frame", nil, f)
	local rf = f.frame[1]
	
	rf:ClearAllPoints()
   	rf:SetBackdrop({ bgFile = background, tile = false, tileSize = 16, edgeFile = border, edgeSize = 8, insets = { left = 6, right = 6, top = 6, bottom = 6 } })
	rf:SetBackdropColor(unpack(db.media.backdropC))
	rf:SetBackdropBorderColor(0,0,0,0)
	rf:SetPoint("CENTER", f, "CENTER")
	rf:SetHeight(height - 30)
	rf:SetWidth(width - 20)
	rf:Show()
	
	rf.RAID = CreateFrame("Button", nil, rf)
   	rf.RAID:SetScript("OnClick", function(f) self:DewthruMe(f, 100) end)
   	rf.RAID:SetNormalTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Up")
   	local texture = rf.RAID:GetNormalTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	rf.RAID:SetHighlightTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Glow")
   	local texture = rf.RAID:GetHighlightTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	rf.RAID:ClearAllPoints()
   	rf.RAID:SetPoint("TOP", rf, "TOP", 0, -5)
   	rf.RAID:Show()
   	
   	rf.RAID.text = rf.RAID:CreateFontString()
   	rf.RAID.text:SetFont(font, fontsize)
   	rf.RAID.text:ClearAllPoints()
	rf.RAID.text:SetPoint("CENTER", rf.RAID, "CENTER")
	rf.RAID.text:SetText("Raid1")
	local buttonwidth = rf.RAID.text:GetStringWidth() + 15
	rf.RAID.text:SetWidth(buttonwidth)
	rf.RAID:SetWidth(buttonwidth)
	rf.RAID:SetHeight(20)
   	
   	rf.scroll = self:CreateScrollFrame(rf, background, border)
   	rf.scroll:SetPoint("TOPLEFT", rf, "TOPLEFT", 10, -25)
   	
   	--edit raid events
   	rf.eventname = self:CreateEditBox(rf, font, fontsize, background, border, LL["Enter event name"])
   	rf.eventname:SetPoint("TOPLEFT", rf.scroll, "TOPRIGHT", 10, -5)
	rf.eventname:SetID(1)
	rf.eventname:SetHeight(20)
	
	rf.eventchoose = self:CreatDropDownButton(rf, font, fontsize, background, border)
	rf.eventchoose:SetPoint("TOPLEFT", rf.eventname, "TOPRIGHT")
   	rf.eventchoose:SetID(1)
	
	rf.eventnote = self:CreateEditBox(rf, font, fontsize, background, border, LL["Enter event note"])
   	rf.eventnote:SetPoint("TOPLEFT", rf.eventname, "BOTTOMLEFT", 0, -5)
	rf.eventnote:SetID(2)
	rf.eventnote:SetHeight(20)
	
	rf.eventvalue = self:CreateEditBox(rf, font, fontsize, background, border, LL["Enter event value"])
   	rf.eventvalue:SetPoint("TOPLEFT", rf.eventnote, "BOTTOMLEFT", 0, -5)
	rf.eventvalue:SetID(3)
	rf.eventvalue:SetHeight(20)
	rf.eventvalue:SetWidth(50)
	
	rf.eventattends = self:CreateEditBox(rf, font, fontsize, background, border, LL["Enter event attendees"])
   	rf.eventattends:SetPoint("TOPLEFT", rf.eventvalue, "BOTTOMLEFT", 0, -5)
	rf.eventattends:SetID(4)
	rf.eventattends:SetMultiLine(true)
	rf.eventattends:SetScript("OnEnterPressed", nil)
	rf.eventattends:SetFont(font, fontsize - 2)
   	
	rf.newevent = self:CreateStandardButton(rf, font, fontsize, LL["Create new event"])
   	rf.newevent:SetScript("OnClick", function(f) self:AddNewEvent() end)
   	rf.newevent:SetPoint("TOPLEFT", rf.scroll, "TOPRIGHT", 10, -5)
   	
	rf.exportraid = self:CreateStandardButton(rf, font, fontsize, LL["Export Raid"])
   	rf.exportraid:SetScript("OnClick", function(f) self:ExportCurrentRaid() end)
   	rf.exportraid:SetPoint("TOPLEFT", rf.newevent, "BOTTOMLEFT", 2, -5)
   	
   	rf.delraid = self:CreateStandardButton(rf, font, fontsize, LL["Delete Raid"])
   	rf.delraid:SetScript("OnClick", function(f) self:DeleteRaid() end)
   	rf.delraid:SetPoint("TOPLEFT", rf.exportraid, "BOTTOMLEFT", 0, -5)
   	
   	rf.eventadd = self:CreateStandardButton(rf, font, fontsize, LL["Add"])
   	rf.eventadd:SetScript("OnClick", function(f) f:Hide() self:UpdateNewEvent() end)
   	rf.eventadd:SetPoint("TOPLEFT", rf.eventattends, "BOTTOMLEFT", 0, -5)
	
	rf.eventdel = self:CreateStandardButton(rf, font, fontsize, LL["Delete"])
   	rf.eventdel:SetScript("OnClick", function(f) self:DeleteRaidEvent() end)
   	rf.eventdel:SetPoint("TOPLEFT", rf.eventattends, "BOTTOMLEFT", 0, -5)
   	
   	rf.eventupdate = self:CreateStandardButton(rf, font, fontsize, LL["Update attends"])
   	rf.eventupdate:SetScript("OnClick", function(f) self:UpdateRaidAttendees() end)
   	rf.eventupdate:SetPoint("TOPLEFT", rf.eventdel, "TOPRIGHT", 5, 0)
   	
   	--edit raid items
   	rf.itemevent = self:CreateEditBox(rf, font, fontsize, background, border, LL["Enter item event"])
   	rf.itemevent:SetPoint("TOPLEFT", rf.scroll, "TOPRIGHT", 10, -5)
	rf.itemevent:SetID(11)
	rf.itemevent:SetHeight(20)
	
	rf.itemchoose = self:CreatDropDownButton(rf, font, fontsize, background, border)
	rf.itemchoose:SetPoint("TOPLEFT", rf.itemevent, "TOPRIGHT")
   	rf.itemchoose:SetID(11)
	
   	rf.itemwinner = self:CreateEditBox(rf, font, fontsize, background, border, LL["Enter item winner"])
   	rf.itemwinner:SetPoint("TOPLEFT", rf.itemevent, "BOTTOMLEFT", 0, -5)
	rf.itemwinner:SetID(12)
	rf.itemwinner:SetHeight(20)
	
	rf.itemwinnerchoose = self:CreatDropDownButton(rf, font, fontsize, background, border)
	rf.itemwinnerchoose:SetPoint("TOPLEFT", rf.itemwinner, "TOPRIGHT")
   	rf.itemwinnerchoose:SetID(12)
   	
   	rf.itemvalue = self:CreateEditBox(rf, font, fontsize, background, border, LL["Enter item value"])
   	rf.itemvalue:SetPoint("TOPLEFT", rf.itemwinner, "BOTTOMLEFT", 0, -5)
	rf.itemvalue:SetID(13)
	rf.itemvalue:SetHeight(20)
	rf.itemvalue:SetWidth(50)
	
	rf.itemdel = self:CreateStandardButton(rf, font, fontsize, LL["Delete"])
   	rf.itemdel:SetScript("OnClick", function(f) f:Hide() self:DeleteRaidItem() end)
   	rf.itemdel:SetPoint("TOPLEFT", rf.itemvalue, "BOTTOMLEFT", 0, -5)
   	
   	--items frame
   	f.frame[2] = CreateFrame("frame", nil, f)
	local rf = f.frame[2]
	
	rf:ClearAllPoints()
   	rf:SetBackdrop({ bgFile = background, tile = false, tileSize = 16, edgeFile = border, edgeSize = 8, insets = { left = 6, right = 6, top = 6, bottom = 6 } })
	rf:SetBackdropColor(unpack(db.media.backdropC))
	rf:SetBackdropBorderColor(0,0,0,0)
	rf:SetPoint("CENTER", f, "CENTER")
	rf:SetHeight(height - 30)
	rf:SetWidth(width - 20)
	rf:Hide()
		
	rf.scroll = self:CreateScrollFrame(rf, background, border)
   	rf.scroll:SetPoint("TOPLEFT", rf, "TOPLEFT", 10, -25)
   	
   	rf.itemDBvalue = self:CreateEditBox(rf, font, fontsize, background, border, LL["Enter item value"])
   	rf.itemDBvalue:SetPoint("TOPLEFT", rf.scroll, "TOPRIGHT", 20, -5)
	rf.itemDBvalue:SetID(21)
	rf.itemDBvalue:SetHeight(20)
	rf.itemDBvalue:SetWidth(50)
	rf.itemDBvalue:Show()
	
	rf.pclass = {}
	rf.altclass = {}
	rf.classname = {}
	local localizedclass
   	local height2 = fontsize
   	local checksize = 15
	
   	
	rf.ctitle = rf:CreateFontString()
   	rf.ctitle:SetPoint("TOPLEFT", rf.scroll, "TOPRIGHT", 20, -30)
   	rf.ctitle:SetJustifyH("LEFT")
   	rf.ctitle:SetFont(font, fontsize)
   	rf.ctitle:SetTextColor(1,1,1)
   	rf.ctitle:SetText(LL["Class"])
   	rf.ctitle:SetWidth(40)
   	rf.ctitle:SetHeight(20)
   	rf.ctitle:Show()
   	
   	rf.actitle = rf:CreateFontString()
   	rf.actitle:SetPoint("LEFT", rf.ctitle, "LEFT", 70, 0)
   	rf.actitle:SetJustifyH("RIGHT")
   	rf.actitle:SetFont(font, fontsize)
   	rf.actitle:SetTextColor(1,1,1)
   	rf.actitle:SetText("Deathknight")
   	local length = rf.actitle:GetStringWidth() + 3 * fontallowance
   	if length < 70 then length = 70 end
   	rf.actitle:SetText(LL["Alt"])
   	rf.actitle:SetWidth(40)
   	rf.actitle:SetHeight(20)
   	rf.actitle:Show()
   	
   	rf.ctitle:SetWidth(length/2)
	rf.actitle:SetWidth(length/2)
	
   	if height2 < 12 then height2 = 12 end
	local frame = rf.ctitle
   	local color, localizedclass
   	for _, class in ipairs(mdkp.orderedclasses) do
   		if class ~= L["ALL"] then localizedclass = BC[string.upper(string.sub(class,1,1)) .. string.lower(string.sub(class, 2, -1))] 
		else localizedclass = L["ALL"] end
		color = mdkp.ClasscolorsDEC[class]
		rf.pclass[class] = CreateFrame("CheckButton", nil, rf)
		rf.pclass[class]:SetWidth(checksize)
		rf.pclass[class]:SetHeight(checksize)
		rf.pclass[class]:ClearAllPoints()
		rf.pclass[class]:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", 0, 0)
		rf.pclass[class]:SetScript("OnEnter", function(f)
						if db.hints then 
							GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
							GameTooltip:AddLine(LL["Select primary class"], 0, 1, 0)
							GameTooltip:Show()
						end
					end)
		rf.pclass[class]:SetScript("OnLeave", function() GameTooltip:Hide() end)
		rf.pclass[class]:SetScript("OnMouseUp", function(f, button) mod:Toggle_ItemDBClass(f, f:GetID(), class) end)
		rf.pclass[class]:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
   		rf.pclass[class]:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight")
   		rf.pclass[class]:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")
   		rf.pclass[class]:SetID(1)
   		rf.pclass[class]:Show()
   		rf.pclass[class]:Disable()

		rf.classname[class] = rf:CreateFontString()
   		rf.classname[class]:ClearAllPoints()
   		rf.classname[class]:SetPoint("LEFT", rf.pclass[class], "RIGHT", 0, 0)
   		rf.classname[class]:SetJustifyH("CENTER")
   		rf.classname[class]:SetJustifyV("MIDDLE")
   		rf.classname[class]:SetFont(font, fontsize)
   		rf.classname[class]:SetTextColor(color.r, color.g, color.b)
   		rf.classname[class]:SetHeight(height2)
   		rf.classname[class]:SetWidth(length)
   		rf.classname[class]:SetText(localizedclass)
   		rf.classname[class]:Show()
   		
   		rf.altclass[class] = CreateFrame("CheckButton", nil, rf)
		rf.altclass[class]:SetWidth(checksize)
		rf.altclass[class]:SetHeight(checksize)
		rf.altclass[class]:ClearAllPoints()
		rf.altclass[class]:SetPoint("LEFT", rf.classname[class], "RIGHT", 0, 0)
		rf.altclass[class]:SetScript("OnEnter", function(f)
						if db.hints then 
							GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
							GameTooltip:AddLine(LL["Select secondary class"], 0, 1, 0)
							GameTooltip:Show()
						end
					end)
		rf.altclass[class]:SetScript("OnLeave", function() GameTooltip:Hide() end)
		rf.altclass[class]:SetScript("OnMouseUp", function(f, button) mod:Toggle_ItemDBClass(f, f:GetID(), class) end)
		rf.altclass[class]:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
   		rf.altclass[class]:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight")
   		rf.altclass[class]:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")
   		rf.altclass[class]:SetID(2)
		rf.altclass[class]:Show()
		rf.altclass[class]:Disable()
		
		frame = rf.pclass[class]
	end
	
	rf.itemDBdel = self:CreateStandardButton(rf, font, fontsize, LL["Delete"])
   	rf.itemDBdel:SetScript("OnClick", function(f) self:DeleteItemDBItem() end)
   	rf.itemDBdel:SetPoint("TOPLEFT", rf.pclass[L["ALL"]], "BOTTOMLEFT", 0, -10)
   	
   	rf.itemDBignore = self:CreateStandardButton(rf, font, fontsize, LL["Ignore"])
   	rf.itemDBignore:SetScript("OnClick", function(f) self:IgnoreItemDBItem() end)
   	rf.itemDBignore:SetPoint("LEFT", rf.itemDBdel, "RIGHT", 10, 0)
   	
	--aliases frame
   	f.frame[3] = CreateFrame("frame", nil, f)
	local rf = f.frame[3]
	
	rf:ClearAllPoints()
   	rf:SetBackdrop({ bgFile = background, tile = false, tileSize = 16, edgeFile = border, edgeSize = 8, insets = { left = 6, right = 6, top = 6, bottom = 6 } })
	rf:SetBackdropColor(unpack(db.media.backdropC))
	rf:SetBackdropBorderColor(0,0,0,0)
	rf:SetPoint("CENTER", f, "CENTER")
	rf:SetHeight(height - 30)
	rf:SetWidth(width - 20)
	rf:Hide()
		
	rf.pool = CreateFrame("Button", nil, rf)
   	rf.pool:SetScript("OnClick", function(f) self:DewthruMe(f, 300) end)
   	rf.pool:SetNormalTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Up")
   	local texture = rf.pool:GetNormalTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	rf.pool:SetHighlightTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Glow")
   	local texture = rf.pool:GetHighlightTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	rf.pool:ClearAllPoints()
   	rf.pool:SetPoint("TOP", rf, "TOP", 0, -5)
   	rf.pool:Show()
   	
   	rf.pool.text = rf.pool:CreateFontString()
   	rf.pool.text:SetFont(font, fontsize)
   	rf.pool.text:ClearAllPoints()
	rf.pool.text:SetPoint("CENTER", rf.pool, "CENTER")
	rf.pool.text:SetText("DataBase1")
	local buttonwidth = rf.pool.text:GetStringWidth() + 15
	rf.pool.text:SetWidth(buttonwidth)
	rf.pool:SetWidth(buttonwidth)
	rf.pool:SetHeight(20)
	
	rf.scroll = self:CreateScrollFrame(rf, background, border)
   	rf.scroll:SetPoint("TOPLEFT", rf, "TOPLEFT", 10, -25)
   	
   	rf.alias = self:CreateEditBox(rf, font, fontsize, background, border, LL["Enter alias name"])
   	rf.alias:SetPoint("TOPLEFT", rf.scroll, "TOPRIGHT", 15, -5)
	rf.alias:SetID(31)
	rf.alias:SetHeight(20)
	rf.alias:SetWidth(mastereditwidth)
	rf.alias:Show()
	
	rf.aliaschoose = self:CreatDropDownButton(rf, font, fontsize, background, border)
	rf.aliaschoose:SetPoint("TOPLEFT", rf.alias, "TOPRIGHT")
   	rf.aliaschoose:SetID(31)
	rf.aliaschoose:Show()
	
	rf.main = self:CreateEditBox(rf, font, fontsize, background, border, LL["Enter main name"])
   	rf.main:SetPoint("TOPLEFT", rf.alias, "BOTTOMLEFT", 0, -10)
	rf.main:SetID(32)
	rf.main:SetHeight(20)
	rf.main:SetWidth(mastereditwidth)
	rf.main:Show()
	
	rf.mainchoose = self:CreatDropDownButton(rf, font, fontsize, background, border)
	rf.mainchoose:SetPoint("TOPLEFT", rf.main, "TOPRIGHT")
   	rf.mainchoose:SetID(32)
	rf.mainchoose:Show()
	
	rf.aliasadd = self:CreateStandardButton(rf, font, fontsize, LL["Add"])
   	rf.aliasadd:SetScript("OnClick", function(f) self:AddAlias() end)
   	rf.aliasadd:SetPoint("TOPLEFT", rf.main, "BOTTOMLEFT", 0, -10)
   	rf.aliasadd:Show()
	
   	rf.aliasdel = self:CreateStandardButton(rf, font, fontsize, LL["Delete"])
   	rf.aliasdel:SetScript("OnClick", function(f) self:DeleteAlias() end)
   	rf.aliasdel:SetPoint("LEFT", rf.aliasadd, "RIGHT", 10, 0)
   	rf.aliasdel:Show()
	
   	--dkp changes frame
   	f.frame[4] = CreateFrame("frame", nil, f)
	local rf = f.frame[4]
	
	rf:ClearAllPoints()
   	rf:SetBackdrop({ bgFile = background, tile = false, tileSize = 16, edgeFile = border, edgeSize = 8, insets = { left = 6, right = 6, top = 6, bottom = 6 } })
	rf:SetBackdropColor(unpack(db.media.backdropC))
	rf:SetBackdropBorderColor(0,0,0,0)
	rf:SetPoint("CENTER", f, "CENTER")
	rf:SetHeight(height - 30)
	rf:SetWidth(width - 20)
	rf:Hide()
		
	rf.pool = CreateFrame("Button", nil, rf)
   	rf.pool:SetScript("OnClick", function(f) self:DewthruMe(f, 400) end)
   	rf.pool:SetNormalTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Up")
   	local texture = rf.pool:GetNormalTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	rf.pool:SetHighlightTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Glow")
   	local texture = rf.pool:GetHighlightTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	rf.pool:ClearAllPoints()
   	rf.pool:SetPoint("TOP", rf, "TOP", 0, -5)
   	rf.pool:Show()
   	
   	rf.pool.text = rf.pool:CreateFontString()
   	rf.pool.text:SetFont(font, fontsize)
   	rf.pool.text:ClearAllPoints()
	rf.pool.text:SetPoint("CENTER", rf.pool, "CENTER")
	rf.pool.text:SetText("DataBase1")
	local buttonwidth = rf.pool.text:GetStringWidth() + 15
	rf.pool.text:SetWidth(buttonwidth)
	rf.pool:SetWidth(buttonwidth)
	rf.pool:SetHeight(20)
	
	rf.scroll = self:CreateScrollFrame(rf, background, border)
   	rf.scroll:SetPoint("TOPLEFT", rf, "TOPLEFT", 10, -25)
   	
   	rf.value = self:CreateEditBox(rf, font, fontsize, background, border, LL["Enter DKP change amount"])
   	rf.value:SetPoint("TOPLEFT", rf.scroll, "TOPRIGHT", 15, -5)
	rf.value:SetID(41)
	rf.value:SetHeight(20)
	rf.value:SetWidth(70)
	rf.value:Show()
	
	rf.event = self:CreateEditBox(rf, font, fontsize, background, border, LL["Enter event name"])
   	rf.event:SetPoint("TOPLEFT", rf.value, "BOTTOMLEFT", 0, -5)
	rf.event:SetID(43)
	rf.event:SetHeight(20)
	rf.event:SetWidth(mastereditwidth)
	rf.event:Show()
	
	rf.eventchoose = self:CreatDropDownButton(rf, font, fontsize, background, border)
	rf.eventchoose:SetPoint("TOPLEFT", rf.event, "TOPRIGHT")
   	rf.eventchoose:SetID(43)
	rf.eventchoose:Show()
	
	rf.dkpattends = self:CreateEditBox(rf, font, fontsize, background, border, LL["Enter DKP change members"])
   	rf.dkpattends:SetPoint("TOPLEFT", rf.event, "BOTTOMLEFT", 0, -5)
	rf.dkpattends:SetID(42)
	rf.dkpattends:SetMultiLine(true)
	rf.dkpattends:SetScript("OnEnterPressed", nil)
	rf.dkpattends:SetFont(font, fontsize)
	rf.dkpattends:SetWidth(mastereditwidth)
	rf.dkpattends:Show()
	
	rf.choose = self:CreatDropDownButton(rf, font, fontsize, background, border)
	rf.choose:SetPoint("TOPLEFT", rf.dkpattends, "TOPRIGHT")
   	rf.choose:SetID(42)
	rf.choose:Show()
	
   	rf.addchange = self:CreateStandardButton(rf, font, fontsize, LL["Add"])
   	rf.addchange:SetScript("OnClick", function(f) self:AddDKPChange() end)
   	rf.addchange:SetPoint("TOPLEFT", rf.dkpattends, "BOTTOMLEFT", 0, -10)
   	rf.addchange:Show()
	
   	rf.delchange = self:CreateStandardButton(rf, font, fontsize, LL["Delete"])
   	rf.delchange:SetScript("OnClick", function(f) self:DeleteDKPChange() end)
   	rf.delchange:SetPoint("LEFT", rf.addchange, "RIGHT", 10, 0)
   	rf.delchange:Show()
  
end

function mod:CreateEditBox(parent, font, fontsize, background, border, hint)
	local f = CreateFrame("EditBox", nil, parent)
	f:ClearAllPoints()
	f:SetMultiLine(nil)
	f:SetAutoFocus(nil)
	f:SetScript("OnEscapePressed", function(f) f:ClearFocus() end)
	f:SetScript("OnEnterPressed", function(f) f:ClearFocus() mod:EditBoxEnterPressed(f:GetID()) end)
	if hint then
		f:SetScript("OnEnter", function(f)
						if db.hints then 
							GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
							GameTooltip:AddLine(hint)
							GameTooltip:Show()
						end
					end)
		f:SetScript("OnLeave", function() GameTooltip:Hide() end)
	end
	f:SetFont(font, fontsize)
	f:SetTextColor(1, 1, 1)
	f:SetTextInsets(3, 3, 3, 3)
	f:SetBackdrop({ bgFile = background, tile = false, tileSize = 16, edgeFile = border, edgeSize = 16, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
	f:SetBackdropColor(unpack(db.media.backdropC))
	f:SetBackdropBorderColor(unpack(db.media.borderC))
   	return f
end

function mod:CreatDropDownButton(parent, font, fontsize, background, border)
	local f = CreateFrame("Button", nil, parent)
   	f:SetScript("OnClick", function(f) self:DewthruMe(f, f:GetID()) end)
   	f:SetWidth(20)
   	f:SetHeight(20)
   	f:SetNormalTexture("Interface/Buttons/UI-ScrollBar-ScrollDownButton-Up")
   	f:SetPushedTexture("Interface/Buttons/UI-ScrollBar-ScrollDownButton-Down")
   	f:SetHighlightTexture("Interface/Buttons/UI-ScrollBar-ScrollDownButton-Highlight")
   	f:ClearAllPoints()
   	f:SetHitRectInsets(5, 5, 5, 5)
   	return f
end

function mod:CreateStandardButton(parent, font, fontsize, text)
	local f = CreateFrame("Button", nil, parent)
   	f:SetNormalTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Up")
   	local texture = f:GetNormalTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	f:SetHighlightTexture("Interface\\GLUES\\COMMON\\Glues-BigButton-Glow")
   	local texture = f:GetHighlightTexture()
   	texture:SetTexCoord(.168, .818, .239, .753)
   	f:SetHeight(fontsize + 12)
   	f:ClearAllPoints()
   	f.text = f:CreateFontString()
   	f.text:SetFont(font, fontsize)
   	f.text:ClearAllPoints()
	f.text:SetPoint("CENTER", f, "CENTER")
	f.text:SetText(text)
	local width = f.text:GetStringWidth() + 15
	f:SetWidth(width)
	f.text:SetWidth(width)
   	return f
end

function mod:ShowRaidFrame(ID)
	if not ID then ID = 1 end
	if self.frameedit ~= ID then self.editing = nil end
	self.frameedit = ID
	mdkp.frames.raidtracker.frame[ID]:Show()
	mdkp.frames.raidtracker.buttons[ID]:LockHighlight()
	for num = 1,4 do
		if num ~= ID then
			mdkp.frames.raidtracker.buttons[num]:UnlockHighlight()
			mdkp.frames.raidtracker.frame[num]:Hide()
		end
	end
	if ID == 1 then self:ShowRaid(db.raidnum) end
end

function mod:AdjustFrames(width, height, main)
	if main then		--update main frame
		mdkp.frames.raidtracker:SetHeight(height)
		mdkp.frames.raidtracker:SetWidth(width)
	end
	for num = 1,4 do
		mdkp.frames.raidtracker.frame[num]:SetHeight(height - 30)
		mdkp.frames.raidtracker.frame[num]:SetWidth(width - 20)
	end
	self:UpdateScrollFrame(mdkp.frames.raidtracker.frame[self.frameedit])
	self:RedrawFrames()
end

function mod:DewthruMe(frame, ID)
	if self:CloseDewFrame() then return end
	
	local validate = {}
	local names
	
	if ID == 100 then	--raidlist
		if db.raidnum == 0 then return end
		for num = 1, db.raidnum do
			local eventid = self:GetEventID(2, num)
			local eventname = ((eventid and db.raidlog[num].bosskills[eventid].name) or db.raidlog[num].zone) .. " - " .. date("%m/%d %I:%M:%S", db.raidlog[num].raidstart)
			tinsert(validate, (eventname or num))
		end
	elseif ID == 1 then	--event name
		if not self.editraid then return end
		local POOL = self:GetRaidPool(self.editraid)
		if db.eqDKP[POOL].Events then
			for name in pairs(db.eqDKP[POOL].Events) do
				tinsert(validate, name)
			end
		else return end
		tsort(validate)
	elseif ID == 11 then	--item event
		for _, eventdata in ipairs(db.raidlog[self.editraid].bosskills) do
			if eventdata.note ~= L["Bank"] then tinsert(validate, eventdata.note) end
		end
		tinsert(validate, "Trash mob")
	elseif ID == 12 then	--item winner
		local allplayers = {}
		for _, eventdata in pairs(db.raidlog[self.editraid].bosskills) do
			for _, player in pairs(eventdata.attendees) do
				allplayers[player] = true
			end
		end
		for name in pairs(allplayers) do
			if name ~= L["Bank"] then tinsert(validate, name) end
		end
		tsort(validate)
		tinsert(validate, L["Bank"])
		names = true
	elseif ID == 300 or ID == 400 then	--database list
		if not db.eqDKP then return end
		for pool, data in pairs(db.eqDKP) do
			tinsert(validate, pool)
		end
		tsort(validate)
	elseif ID == 31 or ID == 42 then	--alias alt/dkpchanges choose
		for name in pairs(mdkp.roster) do
			tinsert(validate, name)
		end
		tsort(validate)
		if ID == 42 then tinsert(validate, LL["Current raid"]) end
	elseif ID == 32 then	--alias main
		for name, _ in pairs(db.info) do
			if db.eqDKP and db.eqDKP[self.editpool] and db.eqDKP[self.editpool].Aliases and not db.eqDKP[self.editpool].Aliases[name] then 
				tinsert(validate, name)
			end
		end
		tsort(validate)
	elseif ID == 43 then	--DKP changes event name
		if not self.editpool then return end
		local POOL = self.editpool
		if db.eqDKP[POOL].Events then
			for name in pairs(db.eqDKP[POOL].Events) do
				tinsert(validate, name)
			end
		else return end
		tsort(validate)
	end
	tinsert(validate, LL["Close"])
	self:Opendewdrop(frame, validate, "raidtracker", ID, names)
end

function mod:HandleDewAction(actionid, value, id)
	if value == LL["Close"] then return end
	local rf = mdkp.frames.raidtracker.frame[self.frameedit]
		
	if actionid == 100 then 		--raidlist
		self:HideLastHighlight(mdkp.frames.raidtracker.frame[1].scroll)
		self.editing = nil
		self:ShowRaid(id)
	elseif actionid == 1 then self:ChangeEventData(value)	--event name
	elseif actionid == 11 or actionid == 12 then self:ChangeItemData(actionid, value, id)	--item event 
	elseif actionid == 300 then 		--pools	
		self:HideLastHighlight(mdkp.frames.raidtracker.frame[3].scroll)
		self.editing = nil
		self:ShowAliases(value)
	elseif actionid == 31 then 	--alias alt
		rf.alias:SetText(value)
	elseif actionid == 32 then 	--alias main
		rf.main:SetText(value)
	elseif actionid == 400 then 		--dkp changes	
		self:HideLastHighlight(mdkp.frames.raidtracker.frame[4].scroll)
		self.editing = nil
		self:ShowDKPChanges(value)
	elseif actionid == 42 then 	--dkpchange members
		self:SetDKPChangeAttendees(value)
	elseif actionid == 43 then 	--dkpchange eventname
		rf.event:SetText(value)
		rf.event:SetCursorPosition(0)
	end
end

function mod:HideLastHighlight(f, newid)
	if not self.editing or not self.frameedit then return end
	local offset = floor(f:GetVerticalScroll() + 0.5)
	local edit = self.editing - offset
	if newid == self.editing then return end
	if edit < 1 or edit > self.maxitems then return end
	mdkp.frames.raidtracker.frame[self.frameedit].scroll.buttons[edit].highlight:Hide()
end

function mod:ShowRaid(raidnum)
	if not raidnum then
		if self.editraid then raidnum = self.editraid
		else raidnum = db.raidnum end
	end	
	local rf = mdkp.frames.raidtracker.frame[1]
	if not db.raidlog[raidnum] then 
		self:ClearRaidEditData()
   		rf.RAID.text:SetText("--------")
   		rf.scroll:Hide()
   		return 
   	end
   	local eventid = self:GetEventID(2, raidnum)
	local eventname = ((eventid and db.raidlog[raidnum].bosskills[eventid].name) or db.raidlog[raidnum].zone) .. " - " .. date("%m/%d %I:%M:%S", db.raidlog[raidnum].raidstart)
	rf.RAID.text:SetText(eventname)
	local buttonwidth = rf.RAID.text:GetStringWidth() + 20
	rf.RAID.text:SetWidth(buttonwidth)
	rf.RAID:SetWidth(buttonwidth)
	mdkp.frames.raidtracker.title:SetText("Raid Tracker - "..LL["Raid Editing"])
	
	self.editraid = raidnum
	
	--add raids and items
	local numevents = #db.raidlog[raidnum].bosskills
	self.scrolldata = { }
	if numevents > 0 then 
		for event, eventdata in ipairs(db.raidlog[raidnum].bosskills) do
			local note = eventdata.note
			if eventdata.name ~= L["Bank"] then
				tinsert(self.scrolldata, { name = eventdata.name, value = eventdata.value, time = eventdata.time, attendees = eventdata.attendees, note = note, trash = eventdata.trash, index = event})
			end
			if eventdata.trash ~= 1 then
				--add items
				if db.raidlog[raidnum].loot then
					for index, itemdata in ipairs(db.raidlog[raidnum].loot) do
						if (note == itemdata.Boss or (itemdata.Boss == "Trash mob" and eventdata.trash == 2)) and itemdata.Boss ~= L["Bank"] then
							tinsert(self.scrolldata, {link = itemdata.ItemLink, name = itemdata.ItemName, event = itemdata.Boss, winner = itemdata.Player, value = itemdata.Costs, quality = mdkp.Quality[itemdata.Quality+1], icon = itemdata.Icon, trash = nil, index = index})
						end
					end
   				end
   			end
   		end
   		if db.raidlog[raidnum].loot then
			local added = nil
			for index, itemdata in ipairs(db.raidlog[raidnum].loot) do
				if itemdata.Boss == L["Bank"] then
					if not added then
						tinsert(self.scrolldata, { name = L["Bank"], value = L["Bank"], time = nil, attendees = nil, note = note, trash = -1, index = nil})
						added = true
					end
					tinsert(self.scrolldata, {link = itemdata.ItemLink, name = itemdata.ItemName, event = itemdata.Boss, winner = itemdata.Player, value = itemdata.Costs, quality = mdkp.Quality[itemdata.Quality+1], icon = itemdata.Icon, trash = nil, index = index})
				end
			end
		end	
   	end
   	
   	--hide edit frames
   	self:ClearRaidEditData()
   	
   	self:UpdateScrollFrame(rf)
   	
   	--open to last edit
   	rf.eventadd:Hide()
   	if self.editing then 
   		self:ClicktoEdit(nil, self.editing)
   	else 
   		--rf.scroll:SetVerticalScroll(0)
		rf.newevent:Show() 
		rf.delraid:Show() 
		rf.exportraid:Show() 
	end
   	
end	

function mod:ShowItemDB()
	if not db.items then return end
	local rf = mdkp.frames.raidtracker.frame[2]
	self.scrolldata = { }
	local qualitytable = {}
	mdkp.frames.raidtracker.title:SetText("Raid Tracker - "..LL["Item Database"])
	
	--organise items by quality
	for item, data in pairs(db.items) do
		local sName, iLink, iQuality, itemLevel, _, _, _, _, _, iconGIF = GetItemInfo(item)
		if iQuality then
			iQuality = iQuality + 1
			if not qualitytable[iQuality] then qualitytable[iQuality] = {} end
			tinsert(qualitytable[iQuality], {link = iLink, name = sName,  winner = itemLevel, value = data.points, quality = mdkp.Quality[iQuality], icon = iconGIF, trash = nil, index = item})
		end
	end
	
	--insert into scrolldata
	local data
	for quality = 1, 7 do
		if qualitytable[quality] then
			data = qualitytable[quality]
			tinsert(self.scrolldata, { name = mdkp.Quality[quality].n, value = "", time = nil, attendees = nil, quality = mdkp.Quality[quality], note = "", trash = -2, index = nil})		--quality heading
			tsort(data, function(a,b) 
					if a.winner == b.winner then
						return a.name < b.name 
					else 
						return a.winner > b.winner
					end end)
			for _, table in ipairs(data) do
				tinsert(self.scrolldata, table)
			end
		end
	end
	
	self:UpdateScrollFrame(rf)
   	
   	--open to last edit
   	if self.editing then 
   		self:ClicktoEdit(nil, self.editing)
   	
	end
end

function mod:ShowAliases(pool)
	if not pool then
		if self.editpool then pool = self.editpool
		else pool = db.raid end
	end	
	if not pool then return end
	local rf = mdkp.frames.raidtracker.frame[3]
	mdkp.frames.raidtracker.title:SetText("Raid Tracker - "..LL["Alias Database"])
	rf.pool.text:SetText(pool)
	local buttonwidth = rf.pool.text:GetStringWidth() + 15
	rf.pool.text:SetWidth(buttonwidth)
	rf.pool:SetWidth(buttonwidth)
	
	self.editpool = pool
	self.scrolldata = { }
	local alts = {}
	
	self:ClearAliasEditData()
	
	--get alts
	for alias, main in pairs(db.eqDKP[pool].Aliases) do
		if not alts[main] then alts[main] = {} end
		tinsert(alts[main], alias)
	end
	
	--insert into scrolldata
	for alias, main in pairs(db.eqDKP[pool].Aliases) do
		tinsert(self.scrolldata, {link = nil, name = alias,  winner = main, value = "", trash = -3, alts = alts[main], index = alias})
	end
	tsort(self.scrolldata, function(a,b) return a.name < b.name end)
	
	self:UpdateScrollFrame(rf)
	
	--open to last edit
   	if self.editing then 
   		self:ClicktoEdit(nil, self.editing)
   	
	end
end

function mod:ShowDKPChanges(pool)
	if not pool then
		if self.editpool then pool = self.editpool
		else pool = db.raid end
	end	
	if not pool then return end
	local rf = mdkp.frames.raidtracker.frame[4]
	mdkp.frames.raidtracker.title:SetText("Raid Tracker - "..LL["DKP Changes"])
	rf.pool.text:SetText(pool)
	local buttonwidth = rf.pool.text:GetStringWidth() + 15
	rf.pool.text:SetWidth(buttonwidth)
	rf.pool:SetWidth(buttonwidth)
	
	self.editpool = pool
	self.scrolldata = { }
		
	--clear data
	rf.value:SetText("0")
	rf.event:SetText("")
	rf.dkpattends:SetText(LL["Attendees"])
	
	--insert into scrolldata
	if db.raidlog.dkpevents and db.raidlog.dkpevents[pool] then
		for num, data in ipairs(db.raidlog.dkpevents[pool]) do
			tinsert(self.scrolldata, {link = nil, name = data.addtype, winner = data.members, value = data.value, note = data.event, trash = -4, index = num})
   		end
	end   	
	
	self:UpdateScrollFrame(rf)
	
	--open to last edit
   	if self.editing then 
   		self:ClicktoEdit(nil, self.editing)
   	end
end

function mod:UpdateScrollFrame(f)
	local sf = f.scroll
	local fontallowance = db.media.fontsize * 3 - 25
	if fontallowance < 0 then fontallowance = 0 end
	local frameheight = 25 + fontallowance
	local totalheight = self.db.profile.frames["raidtracker"].height
	local maxitems = floor(((totalheight - 125)/frameheight) - .5)
	local attach, relpoint, x, y
	local masterframewidth, masterframeheight = self.db.profile.frames.raidtracker.width, self.db.profile.frames.raidtracker.height					
   	local lootbuttonwidth = masterframewidth - 300
   	if lootbuttonwidth > 300 then lootbuttonwidth = 300 
   	elseif lootbuttonwidth < 200 then lootbuttonwidth = 200 end
   	
	--clear old
	for i = 1, sf.maxitems do
		if sf.buttons[i] then sf.buttons[i]:Hide() end
	end
	sf.maxitems = maxitems
	
	--populate frame
	local sr, sg, sb = unpack(db.media.borderC)
	local numitems = #self.scrolldata
	if numitems < maxitems then 
		maxitems = numitems 
		sr, sg, sb = 0, 0, 0
	end
	local data
	for id = 1, numitems do
		data = self.scrolldata[id]
		if not sf.buttons[id] then 
			sf.buttons[id] = self:CreateLootbutton(id, fontallowance, sf) 
			if id == 1 then 
				attach = sf
				relpoint = "TOPLEFT"
				x = 5
				y = -5
			else 
				attach = sf.buttons[id-1]
				relpoint = "BOTTOMLEFT"
				x = 0
				y = 0
			end
			sf.buttons[id]:SetPoint("TOPLEFT", attach, relpoint, x , y)
		else
			sf.buttons[id]:SetWidth(lootbuttonwidth)
		end
		if id == maxitems then break end
	end
	
	self.maxitems = maxitems
	--position frame
	sf:SetHeight((30 + fontallowance) * maxitems + 10)
	sf:SetWidth(lootbuttonwidth + 10)
	sf:SetBackdropBorderColor(sr, sg, sb, 1)
	sf:Show()
	
	--update frame
	sf:SetScript("OnMouseWheel", function(f, direction) self:RaidTrackerScrollframe_Update(f, numitems, maxitems, direction) end)
	self:RaidTrackerScrollframe_Update(sf, numitems, maxitems)
end

function mod:RedrawFrames()
	local fontallowance = db.media.fontsize * 3 - 25
	local fontsize = db.media.fontsize
	local font = self.font
	local background = media:Fetch("background", db.media.background)
	local border
	if db.media.border == "None" then border = media:Fetch("border", "Blizzard Tooltip")
	else border = media:Fetch("border", db.media.border) end
	local r,g,b,a = unpack(db.media.backdropC)
	local r1,g1,b1,a1 = unpack(db.media.borderC)
	if fontallowance < 0 then fontallowance = 0 end
	local frameheight = 25 + fontallowance
	local totalheight = self.db.profile.frames["raidtracker"].height
	local backdrop = { bgFile = background, tile = false, tileSize = 16, edgeFile = border, edgeSize = 16, insets = { left = 3, right = 3, top = 3, bottom = 3 } }
	local maxitems = floor(((totalheight - 125)/frameheight) - .5)
	local height = fontsize
	if fontsize < 12 then height = 12 end
	local textheight = fontsize
	if textheight < 15 then textheight = 15 end
	local masterframewidth, masterframeheight = self.db.profile.frames.raidtracker.width, self.db.profile.frames.raidtracker.height					
   	local lootbuttonwidth = masterframewidth - 300
   	if lootbuttonwidth > 300 then lootbuttonwidth = 300 
   	elseif lootbuttonwidth < 200 then lootbuttonwidth = 200 end
   	local textwidth = lootbuttonwidth - 60
   					
	for num = 1,4 do
		local f = mdkp.frames.raidtracker.frame[num]
		if f then
			local sf = f.scroll
			if sf then
				for i = 1, sf.maxitems do
					if sf.buttons[i] then 
						sf.buttons[i]:SetHeight(30 + fontallowance)
						sf.buttons[i].icon:SetWidth(25 + fontallowance)
						sf.buttons[i].icon:SetHeight(25 + fontallowance)
						sf.buttons[i].name:SetWidth(textwidth)
						sf.buttons[i].name:SetHeight(textheight)
   						sf.buttons[i].name:SetFont(font, fontsize)
   						sf.buttons[i].note:SetWidth(textwidth)
   						sf.buttons[i].note:SetHeight(textheight)
   						sf.buttons[i].note:SetFont(font, fontsize)
   						sf.buttons[i].dkp:SetWidth(textwidth)
   						sf.buttons[i].dkp:SetFont(font, fontsize)
   						sf.buttons[i].winner:SetWidth(textwidth)
   						sf.buttons[i].winner:SetFont(font, fontsize)
   						sf.buttons[i].winner:SetHeight(textheight)
   						sf.buttons[i]:Show()
					end
				end
				for i = sf.maxitems + 1, 20 do
					if not sf.buttons[i] then break end
					sf.buttons[i]:Hide()
				end
				sf.maxitems = maxitems
				sf:SetHeight((30 + fontallowance) * maxitems + 10)
			end
			mdkp.frames.raidtracker.buttons[num].text:SetFont(font, fontsize)
   			local width = mdkp.frames.raidtracker.buttons[num].text:GetStringWidth() + 15
			mdkp.frames.raidtracker.buttons[num].text:SetWidth(width)
			mdkp.frames.raidtracker.buttons[num]:SetWidth(width)
			local editwidth = masterframewidth - lootbuttonwidth - 70
			if editwidth > 275 then editwidth = 275 end
			if num == 1 then
				self:ReskinEditbox(f.eventname, font, fontsize, backdrop, r, g, b, a, r1, g1, b1, a1, editwidth)
				self:ReskinEditbox(f.eventnote, font, fontsize, backdrop, r, g, b, a, r1, g1, b1, a1, editwidth)
				self:ReskinEditbox(f.eventvalue, font, fontsize, backdrop, r, g, b, a, r1, g1, b1, a1)
				self:ReskinEditbox(f.eventattends, font, 8, backdrop, r, g, b, a, r1, g1, b1, a1, editwidth)
				self:ReskinEditbox(f.itemevent, font, fontsize, backdrop, r, g, b, a, r1, g1, b1, a1, editwidth)
				self:ReskinEditbox(f.itemwinner, font, fontsize, backdrop, r, g, b, a, r1, g1, b1, a1, editwidth)
				self:ReskinEditbox(f.itemvalue, font, fontsize, backdrop, r, g, b, a, r1, g1, b1, a1)
				self:ReskinButton(f.RAID, font, fontsize)
				self:ReskinButton(f.newevent, font, fontsize)
				self:ReskinButton(f.exportraid, font, fontsize)
				self:ReskinButton(f.delraid, font, fontsize)
				self:ReskinButton(f.eventadd, font, fontsize)
				self:ReskinButton(f.eventdel, font, fontsize)
				self:ReskinButton(f.eventupdate, font, fontsize)
				self:ReskinButton(f.itemdel, font, fontsize)
			elseif num == 2 then
				self:ReskinEditbox(f.itemDBvalue, font, fontsize, backdrop, r, g, b, a, r1, g1, b1, a1)
				f.ctitle:SetFont(font, fontsize)
				f.actitle:SetFont(font, fontsize)
				f.actitle:SetText("Deathknight")
   				local length = f.actitle:GetStringWidth() + 3 * fontallowance
   				if length < 70 then length = 70
   				elseif length > editwidth then length = editwidth end
   				f.actitle:SetText(LL["Alt"])
   				f.ctitle:SetWidth(length/2)
				f.actitle:SetWidth(length/2)
				for _, class in ipairs(mdkp.orderedclasses) do
					f.classname[class]:SetFont(font, fontsize)
   					f.classname[class]:SetHeight(height)
   					f.classname[class]:SetWidth(length)
   				end
   				self:ReskinButton(f.itemDBdel, font, fontsize)
   				self:ReskinButton(f.itemDBignore, font, fontsize)
   			elseif num == 3 then
				self:ReskinEditbox(f.alias, font, fontsize, backdrop, r, g, b, a, r1, g1, b1, a1, editwidth)
				self:ReskinEditbox(f.main, font, fontsize, backdrop, r, g, b, a, r1, g1, b1, a1, editwidth)
				self:ReskinButton(f.pool, font, fontsize)
				self:ReskinButton(f.aliasadd, font, fontsize)
				self:ReskinButton(f.aliasdel, font, fontsize)
			elseif num == 4 then
				self:ReskinEditbox(f.value, font, fontsize, backdrop, r, g, b, a, r1, g1, b1, a1)
				self:ReskinEditbox(f.event, font, fontsize, backdrop, r, g, b, a, r1, g1, b1, a1, editwidth)
				self:ReskinEditbox(f.dkpattends, font, fontsize, backdrop, r, g, b, a, r1, g1, b1, a1, editwidth)
				self:ReskinButton(f.addchange, font, fontsize)
				self:ReskinButton(f.delchange, font, fontsize)
			end
		end
   	end
   	self:UpdateScrollFrame(mdkp.frames.raidtracker.frame[self.frameedit])
end

function mod:ReskinEditbox(f, font, fontsize, backdrop, r, g, b, a, r1, g1, b1, a1, width)
	f:SetBackdrop(backdrop)
	f:SetBackdropColor(r,g,b,a)
	f:SetBackdropBorderColor(r1,g1,b1,a1)
	f:SetFont(font, fontsize)
	if width then f:SetWidth(width) end
end

function mod:ReskinButton(f, font, fontsize)
	f.text:SetFont(font, fontsize)
	local butwidth = f.text:GetStringWidth() + 15
	f:SetWidth(butwidth)
	f.text:SetWidth(butwidth)
end

function mod:RaidTrackerScrollframe_Update(f, numitems, maxitems, direction)
	local line
	local lineplusoffset
	local change = 1
	local offset = floor(f:GetVerticalScroll() + 0.5)
	local x = 0
	local r,g,b,a = 1,1,1,1
	local r2,g2,b2,a2
	
	if IsControlKeyDown() then
		if direction == 1 then offset = 0
		elseif direction == -1 then offset = numitems - maxitems end
	else
		if IsShiftKeyDown() then change = 10 end
		if direction == -1 then offset = offset + change
		elseif direction == 1 then offset = offset - change end
	end
	if offset < 0 then offset = 0 
	elseif offset > (numitems - maxitems) then offset = numitems - maxitems end
	f:SetVerticalScroll(offset)
	local value
	for line = 1, maxitems do
		lineplusoffset = line + offset
		if lineplusoffset <= numitems then
			value = self.scrolldata[lineplusoffset]
			if value.trash then
				--not an item
				f.buttons[line].name:SetText(value.name)
				f.buttons[line].name:SetTextColor(r,g,b,a)
				if value.trash == -1 then
					f.buttons[line].icon:SetNormalTexture("Interface\\ICONS\\INV_Misc_Coin_02")
					f.buttons[line].winner:Hide()
					f.buttons[line].note:Hide()
					f.buttons[line].dkp:Hide()
					f.buttons[line].name:SetFont(self.font, db.media.fontsize + 2)
					r2,g2,b2,a2 = 1,1,0,1
				elseif value.trash == -2 then
					f.buttons[line].name:SetTextColor(value.quality.r, value.quality.g, value.quality.b)
					f.buttons[line].icon:SetNormalTexture("Interface\\ICONS\\INV_Misc_Note_05")
					f.buttons[line].winner:Hide()
					f.buttons[line].note:Hide()
					f.buttons[line].name:SetFont(self.font, db.media.fontsize + 2)
					f.buttons[line].dkp:Hide()
					r2,g2,b2,a2 = value.quality.r, value.quality.g, value.quality.b, 1
				elseif value.trash == -3 then
					f.buttons[line].name:SetTextColor(r,g,b,a)
					f.buttons[line].icon:SetNormalTexture("Interface\\ICONS\\Ability_Hunter_BeastWithin")
					f.buttons[line].winner:SetText(value.winner)
					f.buttons[line].winner:Show()
					f.buttons[line].note:Hide()
					f.buttons[line].name:SetFont(self.font, db.media.fontsize + 2)
					f.buttons[line].dkp:Hide()
					r2,g2,b2,a2 = 1,1,0,1
				elseif value.trash == -4 then
					f.buttons[line].name:SetTextColor(r,g,b,a)
					f.buttons[line].name:SetFont(self.font, db.media.fontsize)
					if value.value < 0 then 
						f.buttons[line].icon:SetNormalTexture("Interface\\ICONS\\Spell_ChargeNegative")
						f.buttons[line].dkp:SetTextColor(1,0,0,1)
					else 
						f.buttons[line].icon:SetNormalTexture("Interface\\ICONS\\Spell_ChargePositive") 
						f.buttons[line].dkp:SetTextColor(0,1,0,1)
					end
					if #value.winner > 1 then f.buttons[line].name:SetText(LL["Group"])
					else f.buttons[line].name:SetText(value.winner[1]) end
					f.buttons[line].winner:Hide()
					f.buttons[line].note:SetText(value.note)
					f.buttons[line].note:SetTextColor(r,g,b,a)
					f.buttons[line].note:Show()
					f.buttons[line].dkp:SetText(value.value)
					f.buttons[line].dkp:Show()
					r2,g2,b2,a2 = 1,1,0,1
				else 
					f.buttons[line].icon:SetNormalTexture("Interface\\ICONS\\Achievement_Quests_Completed_08")
					f.buttons[line].note:SetText(value.note)
					f.buttons[line].note:SetTextColor(r,g,b,a)
					f.buttons[line].note:Show()
					f.buttons[line].dkp:SetText(value.value)
					f.buttons[line].dkp:SetTextColor(0,1,0,1)
					f.buttons[line].dkp:Show()
					f.buttons[line].winner:Hide()
					f.buttons[line].name:SetFont(self.font, db.media.fontsize)
					r2,g2,b2,a2 = 1,1,0,1
				end
				x = 0
			else
				--is an item
				f.buttons[line].icon:SetNormalTexture(value.icon)
				f.buttons[line].name:SetText(value.name)
				f.buttons[line].name:SetTextColor(value.quality.r, value.quality.g, value.quality.b)
				f.buttons[line].dkp:SetText(value.value)
				f.buttons[line].dkp:SetTextColor(1,0,0)
				f.buttons[line].dkp:Show()
				f.buttons[line].winner:SetText(value.winner)
				f.buttons[line].winner:SetTextColor(1,1,1)
				f.buttons[line].winner:Show()
				f.buttons[line].note:Hide()
				f.buttons[line].name:SetFont(self.font, db.media.fontsize)
				x = 20
				r2,g2,b2,a2 = value.quality.r, value.quality.g, value.quality.b, 1
			end
			if self.editing and self.editing == lineplusoffset then	
				f.buttons[line].highlight:SetBackdropBorderColor(r2,g2,b2,a2) 
				f.buttons[line].highlight:Show()
			else f.buttons[line].highlight:Hide() end
			f.buttons[line]:SetBackdropBorderColor(r2,g2,b2,a2)
			f.buttons[line]:SetID(lineplusoffset)
			f.buttons[line]:Show()
		else
			if f.buttons[line] then f.buttons[line]:Hide() end
		end
	end
end

function mod:CreateScrollFrame(parent, background, border)
	local f = CreateFrame("ScrollFrame", nil, parent)
   	f:EnableMouse(1)
   	f:ClearAllPoints()
   	f:EnableMouseWheel(1)
   	f:SetBackdrop({ bgFile = background, tile = false, tileSize = 16, edgeFile = border, edgeSize = 8, insets = { left = 3, right = 0, top = 3, bottom = 3 } })
	f:SetBackdropColor(0,0,0,1)
	f:SetBackdropBorderColor(0, 0, 0, 1)
	f.buttons = {}
	f.maxitems = 0
	return f
end

function mod:CreateLootbutton(id, fontallowance, frame)
	local f = CreateFrame("frame", nil, frame)
	local height = db.media.fontsize
	if height < 15 then height = 15 end
	local masterframewidth, masterframeheight = self.db.profile.frames.raidtracker.width, self.db.profile.frames.raidtracker.height					
   	local lootbuttonwidth = masterframewidth - 300
   	if lootbuttonwidth > 300 then lootbuttonwidth = 300 
   	elseif lootbuttonwidth < 200 then lootbuttonwidth = 200 end
   	local textwidth = lootbuttonwidth - 60
	
	f:SetID(id)
	f:SetFrameStrata("DIALOG")
   	f:EnableMouse(1)
   	f:ClearAllPoints()
   	f:SetBackdrop({ bgFile = media:Fetch("background", "Solid"), tile = false, tileSize = 16, edgeFile = media:Fetch("border", "Blizzard Tooltip"), edgeSize = 8, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
	f:SetBackdropColor(0,0,0,1)
	f:SetBackdropBorderColor(1, 1, 1, 1)
	f:SetScript("OnMouseUp", function(f, button) 
					f.highlight:SetBackdropBorderColor(f:GetBackdropBorderColor()) 
					f.highlight:Show()
					self:HideLastHighlight(f:GetParent(), f:GetID())
					mod:ClicktoEdit(f, f:GetID(), button) end)
	f:SetHeight(30 + fontallowance)
	f:SetWidth(lootbuttonwidth)
	
	f.highlight = CreateFrame("frame", nil, f)
	f.highlight:SetAllPoints(f)
	f.highlight:SetBackdrop({ bgFile = "", tile = false, tileSize = 16, edgeFile = media:Fetch("border", "Blizzard Tooltip"), edgeSize = 30, insets = { left = 5, right = 5, top = 5, bottom = 5 } })
	f.highlight:SetFrameStrata("FULLSCREEN")
	f.highlight:Hide()
	
	f.icon = CreateFrame("Button", nil, f)
	f.icon:SetWidth(25 + fontallowance)
	f.icon:SetHeight(25 + fontallowance)
	f.icon:ClearAllPoints()
	f.icon:SetPoint("TOPLEFT", f, "TOPLEFT", 3, -3)
	f.icon:SetScript("OnEnter", function(f)
						local index = f:GetParent():GetID()
						if self.scrolldata[index].link then 
							GameTooltip:SetOwner(f, "ANCHOR_RIGHT")
							if IsShiftKeyDown() then
								local _,_, itemId = find(self.scrolldata[index].link, "item:(%d+):")
								itemId = tonumber(itemId)
								self:ShowBidSummary(itemId, self.scrolldata[index].name, self.scrolldata[index].quality, self.editraid)
								GameTooltip:Show()
							else
								GameTooltip:SetHyperlink(self.scrolldata[index].link)
								GameTooltip:Show()
							end
						elseif self.scrolldata[index].attendees then self:DoTTip(f, self.scrolldata[index].attendees, LL["Attendees"])
						elseif self.scrolldata[index].alts then self:DoTTip(f, self.scrolldata[index].alts, LL["Aliases"])
						elseif self.scrolldata[index].winner and self.scrolldata[index].trash == -4 and #self.scrolldata[index].winner > 1 then self:DoTTip(f, self.scrolldata[index].winner, LL["Attendees"])
						end
					end)
	f.icon:SetScript("OnLeave", function() GameTooltip:Hide() end)
	f.icon:SetScript("OnMouseUp", function(f, button) 
						if IsShiftKeyDown() then
							local index = f:GetParent():GetID()
							local ChatFrameEditBox = ChatEdit_GetActiveWindow()
							if self.scrolldata[index].link and ChatFrameEditBox then ChatFrameEditBox:Insert(self.scrolldata[index].link) end
							return
						end
						local parent = f:GetParent()
						parent.highlight:SetBackdropBorderColor(parent:GetBackdropBorderColor()) 
						parent.highlight:Show()
						self:HideLastHighlight(f:GetParent():GetParent(), f:GetParent():GetID())
						mod:ClicktoEdit(f:GetParent(), f:GetParent():GetID(), button) end)
	f.icon:Show()
	
   	f.name = f:CreateFontString()
   	f.name:SetPoint("TOPLEFT", f.icon, "TOPRIGHT", 5, 2)
   	f.name:SetWidth(textwidth)
   	f.name:SetHeight(height)
   	f.name:SetJustifyH("LEFT")
   	f.name:SetJustifyV("MIDDLE")
   	f.name:SetFont(self.font, db.media.fontsize)
   	f.name:Show()
   	
	f.note = f:CreateFontString()
   	f.note:SetPoint("LEFT", f.icon, "RIGHT", 5, 0)
   	f.note:SetWidth(textwidth)
   	f.note:SetHeight(height)
   	f.note:SetJustifyH("LEFT")
   	f.note:SetJustifyV("MIDDLE")
   	f.note:SetFont(self.font, db.media.fontsize)
   	f.note:Show()
   	
   	f.dkp = f:CreateFontString()
   	f.dkp:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -5, 2)
   	f.dkp:SetWidth(textwidth)
   	f.dkp:SetJustifyH("RIGHT")
   	f.dkp:SetFont(self.font, db.media.fontsize)
   	f.dkp:Show()
   	
   	f.winner = f:CreateFontString()
   	f.winner:SetPoint("BOTTOMLEFT", f.icon, "BOTTOMRIGHT", 5, 0)
   	f.winner:SetWidth(textwidth)
   	f.winner:SetHeight(height)
   	f.winner:SetJustifyH("LEFT")
   	f.winner:SetJustifyV("MIDDLE")
   	f.winner:SetTextColor(1, 1, 1)
   	f.winner:SetFont(self.font, db.media.fontsize)
   	f.winner:Show()
   	
   	return f
end

function mod:DoTTip(frame, attendees, heading)
	GameTooltip:SetOwner(frame, "ANCHOR_RIGHT")
	GameTooltip:AddLine(heading)
	local colorname
	for _, name in ipairs(attendees) do
  		colorname = self:GetClasscolors(name)
		GameTooltip:AddLine(name, colorname.r, colorname.g, colorname.b)
  	end
  	GameTooltip:Show()
end

function mod:ClicktoEdit(frame, ID, button)	--iID is index in self.scrolldata
	if not self.scrolldata[ID] then return end
	self.editing = ID
	local eventdata = self.scrolldata[ID]
	local eventindex = eventdata.index
	if not eventindex then return end	--this is the "heading" type entires
			
	if self.frameedit == 1 then		--raids frame
		if not eventdata.link then self:EditRaidEvent(frame, eventdata, eventindex)
		else self:EditRaidItem(frame, eventdata, eventindex) end
	elseif self.frameedit == 2 then		--itemDB frame
		self:EditItemDB(frame, eventdata, eventindex)
	elseif self.frameedit == 3 then		--aliases frame
		self:EditAlias(frame, eventdata, eventindex)
	elseif self.frameedit == 4 then		--dkpchanges frame
		self:EditDKPChange(frame, eventdata, eventindex)
	end
end

function mod:EditRaidEvent(frame, eventdata, eventindex)
	local rf = mdkp.frames.raidtracker.frame[1]
	local masterwidth = self.db.profile.frames.raidtracker.width
	local lootbuttonwidth = masterwidth - 300
   	if lootbuttonwidth > 300 then lootbuttonwidth = 300 
   	elseif lootbuttonwidth < 200 then lootbuttonwidth = 200 end
   	local width = masterwidth - lootbuttonwidth - 70
   	if width > 275 then width = 275 end
   	local height = self.db.profile.frames.raidtracker.height
	local font = media:Fetch("font", db.media.font)
	local fontsize = db.media.fontsize
	
	self:ClearRaidEditData()
	
	--show frames
	rf.eventname:SetText((eventdata and eventdata.name) or LL["Eventname"])
	rf.eventname:SetWidth(width)
	rf.eventname:SetCursorPosition(0)
	rf.eventname:Show()
	rf.eventchoose:Show()
	rf.eventnote:SetText((eventdata and eventdata.note) or LL["Eventnote"])
	rf.eventnote:SetWidth(width)
	rf.eventnote:SetCursorPosition(0)
	rf.eventnote:Show()
	rf.eventvalue:SetText((eventdata and eventdata.value) or LL["Value"])
	rf.eventvalue:Show()
	local attends = self:ArraytoString((eventdata and eventdata.attendees) or nil)
	rf.eventattends:SetText(attends or LL["Attendees"])
	if eventdata and eventdata.attendees then
		if #eventdata.attendees > 27 then fontsize = 5
		elseif #eventdata.attendees > 10 then fontsize = 7
		end
	end
	rf.eventattends:SetFont(font, fontsize)
	rf.eventattends:SetWidth(width)
	local heightneeded = rf.eventattends:GetHeight() + 3 * rf.eventname:GetHeight() + rf.eventdel:GetHeight() + 90
	if heightneeded > height then
		self.db.profile.frames.raidtracker.height = heightneeded
		self:AdjustFrames(self.db.profile.frames.raidtracker.width, heightneeded, true)
	end
	rf.eventattends:Show()
		
	--hide
	rf.newevent:Hide()
	if self.editing > 0 then 
		rf.eventadd:Hide() 
		rf.delraid:Hide() 
		rf.exportraid:Hide() 
		rf.eventupdate:Show()
		rf.eventdel:Show()
	end
end

function mod:EditRaidItem(frame, itemdata, itemindex)
	local rf = mdkp.frames.raidtracker.frame[1]
	local masterwidth = self.db.profile.frames.raidtracker.width
	local lootbuttonwidth = masterwidth - 300
   	if lootbuttonwidth > 300 then lootbuttonwidth = 300 
   	elseif lootbuttonwidth < 200 then lootbuttonwidth = 200 end
   	local width = masterwidth - lootbuttonwidth - 70
   	if width > 275 then width = 275 end
   	
	self:ClearRaidEditData()
	
	--show frames
	rf.itemevent:SetText(itemdata.event)
	rf.itemevent:SetWidth(width)
	rf.itemevent:SetCursorPosition(0)
	rf.itemevent:Show()
	rf.itemchoose:Show()
	rf.itemwinner:SetText(itemdata.winner)
	rf.itemwinner:SetWidth(width)
	rf.itemwinner:SetCursorPosition(0)
	rf.itemwinner:Show()
	rf.itemwinnerchoose:Show()
	rf.itemvalue:SetText(itemdata.value)
	rf.itemvalue:Show()
	rf.itemdel:Show()	
	rf.newevent:Hide()
end

function mod:EditItemDB(frame, itemdata, itemid)
	local rf = mdkp.frames.raidtracker.frame[2]
	local classes = db.items[itemid].classes 
	local altclasses = db.items[itemid].altclasses 
	
	--show frames
	rf.itemDBdel:Show()
	rf.itemDBignore:Show()
	rf.itemDBvalue:SetText(itemdata.value)
	for class, bit in pairs(mdkp.Bits) do
		rf.altclass[class]:SetChecked(band(altclasses, bit) == bit)
		rf.pclass[class]:SetChecked(band(classes, bit) == bit)
		rf.altclass[class]:Enable()
		rf.pclass[class]:Enable()
	end
end

function mod:EditAlias(frame, aliasdata, alias)
	local rf = mdkp.frames.raidtracker.frame[3]
	
	--show frames
	rf.alias:SetText(alias)
	rf.alias:SetCursorPosition(0)
	rf.main:SetText(aliasdata.winner)
	rf.main:SetCursorPosition(0)
end

function mod:EditDKPChange(frame, dkpdata, index)
	local rf = mdkp.frames.raidtracker.frame[4]
	
	--show frames
	rf.value:SetText(dkpdata.value)
	rf.event:SetText(dkpdata.note)
	rf.event:SetCursorPosition(0)
	self:UpdateDKPattends(rf.dkpattends, dkpdata.winner)
end

function mod:UpdateDKPattends(frame, attends)
	local rf = mdkp.frames.raidtracker.frame[4]
	local height = self.db.profile.frames.raidtracker.height
	local font = media:Fetch("font", db.media.font)
	local fontsize = db.media.fontsize
	
	local attendees = self:ArraytoString(attends)
	frame:SetText(attendees)
	if #attends > 27 then fontsize = 5
	elseif #attends > 10 then fontsize = 7
	end
	frame:SetFont(font, fontsize)
	local heightneeded = rf.dkpattends:GetHeight() + rf.value:GetHeight() + rf.addchange:GetHeight() + 90
	if heightneeded > height then
		self.db.profile.frames.raidtracker.height = heightneeded
		self:AdjustFrames(self.db.profile.frames.raidtracker.width, heightneeded, true)
	end
end

function mod:ClearItemDBFrame()
	local rf = mdkp.frames.raidtracker.frame[2]
	rf.itemDBvalue:SetText(0)
	rf.itemDBdel:Hide()
	rf.itemDBignore:Hide()
	for class, bit in pairs(mdkp.Bits) do
		rf.altclass[class]:SetChecked(nil)
		rf.pclass[class]:SetChecked(nil)
		rf.altclass[class]:Disable()
		rf.pclass[class]:Disable()
	end
end

function mod:Toggle_ItemDBClass(f, target, class)
	if not self.editing then return end
	local itemID = self.scrolldata[self.editing].index
	local switch = "classes"
	if target == 2 then switch = "altclasses" end
	local classes = db.items[itemID][switch]
	local bit = mdkp.Bits[class]
	local result
	local checked = not f:GetChecked()
	local parent = f:GetParent()
	if class == L["ALL"] then 
		for class2, bit in pairs(mdkp.Bits) do
			if class2 ~= L["ALL"] then
				if switch == "classes" then parent.pclass[class2]:SetChecked(checked)
				else parent.altclass[class2]:SetChecked(checked) end
			end
		end
		if checked then result = 2047
		else result = 0 end
	else result = bxor(classes, bit) 
	end
	if result == 2046 then result = 2047 end
	db.items[itemID][switch] = result
	
	--add item for sync
	local sync = self:GetModuleRef("Syncing")
	if sync then sync:AddItem(itemID) end
end

function mod:EditBoxEnterPressed(ID)
	self:debug("Frame ID="..ID)
	local index, POOL
	if self.editing and self.editing ~= 0 then 
		index = self.scrolldata[self.editing].index
		if self.editraid then POOL = self:GetRaidPool(self.editraid) end
	elseif self.frameedit ~= 3 then
		return
	end
	local rf = mdkp.frames.raidtracker.frame[self.frameedit]
	local sync = self:GetModuleRef("Syncing")
		
	if ID == 1 then		--event name
		local oldevent = db.raidlog[self.editraid].bosskills[index].name 
		local newevent = rf.eventname:GetText()
		self:ProcessEventNameNoteChange(self.editraid, index, newevent, oldevent)
		
		--add change to sync
		if sync then sync:ChangeEventNameNote(newevent, oldevent) end
		
	elseif ID == 2 then	--event note
		local oldnote = db.raidlog[self.editraid].bosskills[index].note 
		local newnote = rf.eventnote:GetText()
		self:ProcessEventNameNoteChange(self.editraid, index, nil, nil, newnote, oldnote)
		
		--add change to sync
		if sync then sync:ChangeEventNameNote(nil, nil, newnote, oldnote) end
		
	elseif ID == 3 then	--event value
		local oldval = db.raidlog[self.editraid].bosskills[index].value
		local newval = tonumber(rf.eventvalue:GetText())
		db.raidlog[self.editraid].bosskills[index].value = newval
		if oldval ~= newval then 
			local attendees = self.scrolldata[self.editing].attendees
			self:AwardDKP(newval, oldval, POOL, attendees)
		end
		local event = db.raidlog[self.editraid].bosskills[index].name
		if not db.eqDKP[POOL]["Events"][event] then db.eqDKP[POOL]["Events"][event] = {} end
		db.eqDKP[POOL]["Events"][event].value = newval
		
		--add change to sync
		if sync then sync:ChangeEventValue(db.raidlog[self.editraid].bosskills[index].name, newval, POOL) end
		
	elseif ID == 11 then	--item event
		local value = rf.itemevent:GetText()
		self:ChangeItemData(ID, value)
	elseif ID == 12 then	--item winner
		local value = rf.itemwinner:GetText()
		if value then
			value = string.utf8upper(string.utf8sub(value,1,1))..string.utf8lower(string.utf8sub(value,2,-1))
			self:PlayerinDB(value)
		end
		self:ChangeItemData(ID, value)
	elseif ID == 13 then	--item value
		local value = tonumber(rf.itemvalue:GetText())
		self:ChangeItemData(ID, value)
	elseif ID == 21 then	--itemDB value
		local value = tonumber(rf.itemDBvalue:GetText())
		db.items[index].points = value
		
		--add item for sync
		if sync then sync:AddItem(index) end
		
	elseif ID == 31 then	--alias alt
		local alt = rf.alias:GetText()
		alt = string.utf8upper(string.utf8sub(alt,1,1))..string.utf8lower(string.utf8sub(alt,2,-1))
		rf.alias:SetText(alt)
	elseif ID == 32 then	--alias main
		local main = rf.main:GetText()
		main = string.utf8upper(string.utf8sub(main,1,1))..string.utf8lower(string.utf8sub(main,2,-1))
		rf.main:SetText(main)
	end	
	if self.frameedit == 1 then self:ShowRaid()
	elseif self.frameedit == 2 then self:ShowItemDB()
	end
end

function mod:ProcessEventNameNoteChange(raidid, index, newevent, oldevent, newnote, oldnote)
	if newnote and oldnote then
		db.raidlog[raidid].bosskills[index].note = newnote
		self:ChangeEventNote(oldnote, newnote, raidid)
	end
	if newevent and oldevent then
		db.raidlog[raidid].bosskills[index].name = newevent
	end
end

function mod:GetRaidPool(raidid)
	if not raidid then return end
	for pool, data in pairs(db.eqDKP) do
		if pool == db.raidlog[raidid].pool then return pool end
	end
	return db.raid
end

function mod:ClearRaidEditData()
	local rf = mdkp.frames.raidtracker.frame[1]
	
	--clear events
	rf.eventname:Hide()
	rf.eventchoose:Hide()
	rf.eventnote:Hide()
	rf.eventvalue:Hide()
	rf.eventattends:Hide()
	rf.eventdel:Hide()
	rf.eventupdate:Hide()
	rf.newevent:Hide() 
	rf.delraid:Hide() 
	rf.exportraid:Hide() 
	
	--clear items
	rf.itemevent:Hide()
	rf.itemchoose:Hide()
	rf.itemwinner:Hide()
	rf.itemwinnerchoose:Hide()
	rf.itemvalue:Hide()
	rf.itemdel:Hide()
end

function mod:ClearAliasEditData()
	local rf = mdkp.frames.raidtracker.frame[3]
	
	--clear data
	rf.alias:SetText("")
	rf.main:SetText("")
end

function mod:ChangeEventData(value, id)
	if not self.editing then return end
	
	local rf = mdkp.frames.raidtracker.frame[1]
	local POOL = self:GetRaidPool(self.editraid)
	local newevent = db.eqDKP[POOL].Events[value]
	
	--update raidtracker
	rf.eventname:SetText(value)
	rf.eventname:SetCursorPosition(0)
	rf.eventnote:SetText(value)
	rf.eventnote:SetCursorPosition(0)
	rf.eventvalue:SetText(newevent.value)
	
	--update data
	if self.editing ~= 0 then
		local index = self.scrolldata[self.editing].index
		local oldval = db.raidlog[self.editraid].bosskills[index].value
		db.raidlog[self.editraid].bosskills[index].name = value
		db.raidlog[self.editraid].bosskills[index].note = value
		db.raidlog[self.editraid].bosskills[index].value = newevent.value
	
		--update DKP if event value changed
		if oldval ~= newevent.value then
			local attendees = self.scrolldata[self.editing].attendees
			self:AwardDKP(newevent.value, oldval, POOL, attendees)
		end
		self:ShowRaid()
	end
	
end

function mod:ChangeEventNote(oldnote, newnote, raidid)
	if not raidid then raidid = self.editraid end
	if db.raidlog[raidid].loot then
		for index, itemdata in ipairs(db.raidlog[raidid].loot) do
			if oldnote == itemdata.Boss then
				itemdata.Boss = newnote
			end
		end
   	end
end

function mod:ChangeItemData(actionid, value, id)
	if not self.editing then return end
	
	local rf = mdkp.frames.raidtracker.frame[1]
	self:IsDKPEnabled()
	local itemdata = self.scrolldata[self.editing]
	local index = itemdata.index
	local POOL = self:CheckPool(itemdata.ID)
	local oldwinner, oldattends, newattends
	local itemid = db.raidlog[self.editraid].loot[index].ID
	local sync = self:GetModuleRef("Syncing")
		
	--update raidtracker & data
	if actionid == 11 then		--change item event
		rf.itemevent:SetText(value)
		rf.itemevent:SetCursorPosition(0)
		self:ChangeItemEvent(self.editraid, index, value, itemdata, POOL)
		self.editing = nil
		
		--add change to sync
		if sync then sync:ChangeRaidItemEvent(value, itemdata, POOL, itemid) end
		
	elseif actionid == 12 then	--change item winner
		rf.itemwinner:SetText(value)
		rf.itemwinner:SetCursorPosition(0)
		if value == itemdata.winner then return end
		self:ChangeItemWinner(self.editraid, index, value, itemdata, POOL, itemid)
		
		--add change to sync
		if sync then sync:ChangeRaidItemWinner(value, itemdata, POOL, itemid) end
		
	elseif actionid == 13 then	--change item value
		local oldcost = itemdata.value
		if oldcost == value then return end
		self:ChangeItemDKPValue(self.editraid, index, value, itemdata, POOL, oldcost, itemid)
		
		--add change to sync
		if sync then sync:ChangeRaidItemValue(value, itemdata, POOL, oldcost, itemid) end
		
	end
	self:ShowRaid()
end

function mod:ChangeItemEvent(raidid, index, value, itemdata, POOL)
	local currDKP, ref = self:GetRaidModuleRef(raidid)
	if not currDKP or not ref then return end
	local zeroskall
	if ref == "SKall" then zeroskall = currDKP:IsZeroMode() end
	local oldattends, newattends
	if ref == "Zerosum" or zeroskall then oldattends, newattends = self:GetEventAttends(index, value, raidid) end
	currDKP:ItemRebate(nil, itemdata.winner, POOL, itemdata.value, itemdata.link, oldattends, newattends) 
	db.raidlog[raidid].loot[index].Boss = value
end

function mod:ChangeItemWinner(raidid, index, value, itemdata, POOL, itemid)
	local currDKP, ref = self:GetRaidModuleRef(raidid)
	if not currDKP or not ref then return end
	local zeroskall
	if ref == "SKall" then zeroskall = currDKP:IsZeroMode() end
	local oldattends, newattends = self:GetEventAttends(index, nil, raidid) 
	if (ref == "Zerosum" or zeroskall) and value ~= L["Bank"] and itemdata.winner ~= L["Bank"] then
		currDKP:ItemTransfer(itemid, value, itemdata.winner, POOL, itemdata.value, itemdata.link)
	else
		currDKP:ItemRebate(itemid, itemdata.winner, POOL, itemdata.value, itemdata.link, oldattends)
		local points
		if value ~= L["Bank"] then points = currDKP:GetPlayerPoints(value, POOL) end
		if (ref == "Zerosum" or zeroskall) and itemdata.winner == L["Bank"] then 
			db.raidlog[raidid].loot[index].Boss = "Trash mob"
			local newattends = db.raidlog[raidid].bosskills[self:GetEventID(2)].attendees
			currDKP:ItemRebate(itemid, value, POOL, itemdata.value, itemdata.link, newattends, nil, true, points) 
		else
			currDKP:ItemRecorded(itemid, value, POOL, points, itemdata.value, itemdata.link, oldattends) 
		end
	end
	db.raidlog[raidid].loot[index].Player = value
	if value == L["Bank"] then 
		db.raidlog[raidid].loot[index].Boss = value 
		db.raidlog[raidid].loot[index].Costs = 0 
	end
	
	--remove from old winner item DB and add to new winner
	local _, _, _, _, _, _, _, _, iEquipLoc = GetItemInfo(itemid)
	if iEquipLoc ~= "" then
		local index = self:ReturnItemIndex(itemid, itemdata.winner) 
		if index then tremove(db.info[itemdata.winner].items, itemid) end
		if not db.info[value].items then db.info[value].items = {} end
		if not self:ReturnItemIndex(itemid, value) then	tinsert(db.info[value].items, itemid) end
	end
end

function mod:ChangeItemDKPValue(raidid, index, value, itemdata, POOL, oldcost, itemid)
	if itemdata.winner == L["Bank"] then return end
	local currDKP, ref = self:GetRaidModuleRef(raidid)
	if not currDKP or not ref then return end
	local zeroskall
	if ref == "SKall" then zeroskall = currDKP:IsZeroMode() end
	if ref == "Zerosum" or zeroskall then	
		local points = currDKP:GetPlayerPoints(itemdata.winner, POOL)
		local oldattends, newattends = self:GetEventAttends(index, nil, raidid) 
		currDKP:ItemAdjustment(itemid, itemdata.winner, POOL, value, itemdata.link, oldcost, oldattends)
	end
	self:AdjustDKPPoints(itemdata.winner, itemdata.winner, POOL, value, oldcost)
	db.raidlog[raidid].loot[index].Costs = value
end

function mod:GetEventAttends(index, newevent, raidid)
	local oldattends, newattends
	local oldevent = db.raidlog[raidid].loot[index].Boss
	for event, eventdata in pairs(db.raidlog[raidid].bosskills) do
		if eventdata.name == oldevent or eventdata.note == oldevent then oldattends = eventdata.attendees
		elseif eventdata.name == newevent or eventdata.note == newevent then newattends = eventdata.attendees
		end
	end
	if newevent == L["Bank"] then newattends = nil 
	elseif newevent == "Trash mob" then newattends = db.raidlog[raidid].bosskills[self:GetEventID(2)].attendees end
	if oldevent == L["Bank"] then oldattends = nil 
	elseif oldevent == "Trash mob" then oldattends = db.raidlog[raidid].bosskills[self:GetEventID(2)].attendees end
	return oldattends, newattends
end

function mod:AddNewEvent()
	self.editing = 0
	local rf = mdkp.frames.raidtracker.frame[1]
	self:EditRaidEvent()
	rf.eventadd:Show()
end

function mod:UpdateNewEvent()
	local rf = mdkp.frames.raidtracker.frame[1]
	local POOL = self:GetRaidPool(self.editraid)
	local addtime = time()
	
	--get data
	local name = rf.eventname:GetText()
	local note = rf.eventnote:GetText()
	local value = tonumber(rf.eventvalue:GetText()) or 0
	local attends = self:AttendtoArray(rf.eventattends)
	
	--add event
	table.insert(db.raidlog[self.editraid].bosskills,
						{
							["name"] = name,
							["note"] = note,
							["time"] = addtime,
							["attendees"] = attends,					
							["value"] = value,
							["trash"] = 0
						}
	)
	self:AwardDKP(value, 0, POOL, attends)
	self.editing = nil
	self:ShowRaid()
end

function mod:DeleteRaidEvent(called, nosync)
	if not self.editing or not self.editraid then return end
	
	self:IsDKPEnabled()
	local index = self.scrolldata[self.editing].index
	
	local eventname = self.scrolldata[self.editing].name
	local eventnote =  self.scrolldata[self.editing].note
	local eventvalue = self.scrolldata[self.editing].value
	local attendees = self.scrolldata[self.editing].attendees
	local trash = self.scrolldata[self.editing].trash
	
	self:ProcessRaidEventDelete(index, self.editraid, eventname, eventnote, trash, attendees, eventvalue, called)
	
	if not called then
		self.editing = nil
		self:ShowRaid()
	end
	
	--add change to sync
	if not nosync then
		local sync = self:GetModuleRef("Syncing")
		if sync then sync:DeleteRaidEvent(eventname, eventnote, trash, attendees, eventvalue) end	
	end
end

function mod:ProcessRaidEventDelete(index, raidid, eventname, eventnote, trash, attendees, eventvalue, called)
	local currDKP, ref = self:GetRaidModuleRef(raidid)
	if not currDKP or not ref then return end
	local zeroskall
	if ref == "SKall" then zeroskall = currDKP:IsZeroMode() end
	local lootitems = #db.raidlog[raidid].loot
	
	--check for items from this raid
	if lootitems > 0 then
		local data
		for i = lootitems, 1, -1  do
			data = db.raidlog[raidid].loot[i]
			local POOL = self:CheckPool(data.ID)
			if find(eventname, data.Boss) or find(eventnote, data.Boss) or (trash == 2 and data.Boss == "Trash mob") then
				currDKP:ItemRebate(data.ID, data.Player, POOL, data.Costs, data.ItemLink, attendees)
				db.raidlog[raidid].loot[i].Boss = L["Bank"]
			end
		end
	end
	
	--remove points awarded for this event
	local POOL = self:GetRaidPool(raidid)
	if not zerosum and not zeroskall then self:AwardDKP(-eventvalue, 0, POOL, attendees) end
		
	--remove event
	if trash == 2 and not called then self:out(LL["You can not remove the run event."])
	else tremove(db.raidlog[raidid].bosskills, index)
	end
end

function mod:UpdateRaidAttendees()
	if not self.editing then return end
	
	local index = self.scrolldata[self.editing].index
	local rf = mdkp.frames.raidtracker.frame[1]
	local oldattend = { }
	local newattend = { }
	local POOL = self:GetPool(self.editraid)
	local eventvalue = self.scrolldata[self.editing].value
	
	for _, name in pairs(self.scrolldata[self.editing].attendees) do
		oldattend[name] = true
	end
	local temp = self:AttendtoArray(rf.eventattends)
	for _, name in pairs(temp) do
		newattend[name] = true
	end
	
	if eventvalue ~= 0 then
		for name, _ in pairs(newattend) do
			if name ~= LL["Attendees"] and not oldattend[name] then
				self:PlayerinDB(name)
				self:AwardDKP(eventvalue, 0, POOL, {[1] = name})
			end
		end
		for name, _ in pairs(oldattend) do
			if not newattend[name] and name ~= LL["Attendees"] then
				self:AwardDKP(-eventvalue, 0, POOL, {[1] = name})

			end
		end
	end
	db.raidlog[self.editraid].bosskills[index].attendees = temp
	self:ShowRaid()
end

function mod:DeleteRaidItem()
	if not self.editing then return end
	
	local rf = mdkp.frames.raidtracker.frame[1]
	self:IsDKPEnabled()
	local itemdata = self.scrolldata[self.editing]
	local index = itemdata.index
	local itemid = db.raidlog[self.editraid].loot[index].ID
	self:ProcessRaidItemDelete(index, self.editraid, itemdata, itemid)
	self.editing = nil
	self:ShowRaid()	
	
	--add change to sync
	local sync = self:GetModuleRef("Syncing")
	if sync then sync:DeleteRaidItem(itemdata, itemid) end		
end

function mod:ProcessRaidItemDelete(index, raidid, itemdata, itemid)
	local oldattendees, newattendees
	local currDKP, ref = self:GetRaidModuleRef(raidid)
	if not currDKP or not ref then return end
	local zeroskall
	if ref == "SKall" then zeroskall = currDKP:IsZeroMode() end
	local POOL = self:CheckPool(itemid)
	if ref == "Zerosum" or zeroskall then oldattends, newattends = self:GetEventAttends(index, itemdata.name, raidid) end
	currDKP:ItemRebate(itemid, itemdata.winner, POOL, itemdata.value, itemdata.link, oldattends) 
	tremove(db.raidlog[raidid].loot, index)	
end

function mod:ExportCurrentRaid()
	local tracker = self:GetModuleRef("Tracker")
	tracker:OutputRaid(db.raidlog, self.editraid)
end

function mod:DeleteRaid()
	if db.raidnum == 0 then return end
	local value
	if db.InRaid and self.editraid == db.raidnum then
		local tracker = self:GetModuleRef("Tracker")
		tracker:EndRaid()
	end
	for num = #self.scrolldata, 1, -1 do
		value = self.scrolldata[num]
		if value.trash and value.trash ~= -1 then
			self.editing = num
			self:debug("Deleting.."..value.name)
			self:DeleteRaidEvent(true, true)
		end
	end
	tremove(db.raidlog, self.editraid)
	db.raidnum = db.raidnum - 1
	self.editraid = nil
	self.editing = nil
	self:ShowRaid(db.raidnum)	
end

function mod:DeleteItemDBItem()
	if not self.editing then return end
	db.items[self.scrolldata[self.editing].index] = nil
	self:ClearItemDBFrame()
	self.editing = nil
	self:ShowItemDB()
end

function mod:IgnoreItemDBItem()
	if not self.editing then return end
	local _,_, itemId = find(self.scrolldata[self.editing].link, "item:(%d+):")
	itemId = tonumber(itemId)
	db.ignore[itemId] = true
	self:DeleteItemDBItem()
end

function mod:AddAlias()
	local rf = mdkp.frames.raidtracker.frame[3]
	local alt = rf.alias:GetText()
	local main = rf.main:GetText()
	local coremod = self:GetModuleRef("CoreModule")
	if coremod then coremod:AddAlias(alt, main, nil, self.editpool) end
	self.editing = nil
	self:ShowAliases()
end

function mod:DeleteAlias()
	local rf = mdkp.frames.raidtracker.frame[3]
	local alt = rf.alias:GetText()
	local main = rf.main:GetText()
	if not db.raidlog.aliases then db.raidlog.aliases = { } end
	if not db.raidlog.aliases[self.editpool] then db.raidlog.aliases[self.editpool] = { } end
	db.eqDKP[self.editpool].Aliases[alt] = nil
	tinsert(db.raidlog.aliases[self.editpool], {	alt = alt, 
							main = main, 
							eqdkp = db.eqDKP[self.editpool].eqDKPsite, 
							action = "DELETE"})
	for aliasnum, data in pairs(db.info[main].aliases) do
		if data.alt == alt and data.raid == self.editpool then
			tremove(db.info[main].aliases, aliasnum)
			break
		end
	end
	db.info[alt] = nil
	self.editing = nil
	self:ShowAliases()
end

function mod:AddDKPChange()
	local rf = mdkp.frames.raidtracker.frame[4]
	local attendees = self:AttendtoArray(rf.dkpattends)
	local value = tonumber(rf.value:GetText())
	local event = rf.event:GetText() or "UNKNOWN"
	if not attendees then return end
	
	self:ProcessDKPChange(event, value, attendees)
	
	--add change to sync
	local sync = self:GetModuleRef("Syncing")
	if sync then sync:DKPChangeSync(event, attendees, value, self.editpool) end
		
	self:ShowDKPChanges()
end

function mod:ProcessDKPChange(event, value, attendees, pool)
	local currtime = time()
	if not pool then pool = self.editpool end
	if not pool then pool = db.raid end
	if db.dkpevents then
		if db.eqdkp then event = gsub(event, "'", "") end
		local tracker = self:GetModuleRef("Tracker")
		if tracker then tracker:LogBossKill(currtime, event, true, event, nil, 3, attendees, value) end
	else
		self:AwardDKP(nil, value, pool, attendees)
	end
	if #attendees > 1 then self:InsertDKPChange("Group", attendees, value, event, pool)
	else self:InsertDKPChange("individual", attendees, value, event, pool) end
end

function mod:InsertDKPChange(addtype, members, value, event, pool)
	if not pool then pool = self.editpool end
	if not db.raidlog.dkpevents then db.raidlog.dkpevents = {} end
	if not db.raidlog.dkpevents[pool] then db.raidlog.dkpevents[pool] = {} end
	local name
	if addtype == "individual" then name = members[1]
	else name = addtype end
	tinsert(db.raidlog.dkpevents[pool], { 	name = name, 
							value = value, 
							members = members, 
							eqdkp = db.eqDKP[pool].eqDKPsite,
							prefix = db.eqDKP[pool].prefix,
							addtype = addtype,
							event = event})
end

function mod:DeleteDKPChange()
	if not self.editing then return end
	local rf = mdkp.frames.raidtracker.frame[4]
	local attendees = self.scrolldata[self.editing].winner
	local event = self.scrolldata[self.editing].note
	local value = self.scrolldata[self.editing].value
	if db.dkpevents then
		local POOL = db.raid
		local zerosum = self:GetModuleRef("Zerosum")
		if not zerosum then self:AwardDKP(-value, 0, POOL, attendees) end
		for index, data in ipairs(db.raidlog[db.raidnum].bosskills) do
			if data.name == event and data.value == value and data.attendees == attendees then
				tremove(db.raidlog[db.raidnum].bosskills, index)
				break
			end
		end
	else
		self:AwardDKP(0, value, self.editpool, attendees)
	end
	tremove(db.raidlog.dkpevents[self.editpool], self.editing)
	self.editing = nil
	self:ShowDKPChanges()
end

function mod:SetDKPChangeAttendees(name)
	local rf = mdkp.frames.raidtracker.frame[4]
	local font = media:Fetch("font", db.media.font)
	local fontsize = db.media.fontsize
	
	if name == LL["Current raid"] then
		self:UpdateDKPattends(rf.dkpattends, db.raidmembers)
	else
		rf.dkpattends:SetText(name)
		rf.dkpattends:SetFont(font, fontsize)
	end
end