local mod = MorgDKP2:NewModule("FubarPlugin")
local C = LibStub("AceConfigDialog-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local AA = LibStub("AceAddon-3.0")
local fubar = AA:EmbedLibrary(mod, "LibFuBarPlugin-3.0", true)

local mdkp = MorgDKP2

--translations
local LL = LibStub("AceLocale-3.0"):NewLocale("FubarPlugin", "enUS", true)

if LL then
	LL["Fubar Plugin"] = true
	LL["Fubar"] = true
	LL["Attach to minimap"] = true
	LL["Hide minimap icon"] = true
	LL["Show icon"] = true
	LL["Show text"] = true
	LL["Position"] = true
	LL["LEFT"] = true
	LL["CENTER"] = true
	LL["RIGHT"] = true
	LL["Toggle Fubar"] = true
	LL["Sorry you need LibFubarPlugin-3.0 to run the fubar plugin (included in Fubar3.5)"] = true
end

local LL = LibStub("AceLocale-3.0"):GetLocale("FubarPlugin")

--locals
mod.category = "Raid"
mod.title = "MorgDKP2"

mod.modName = LL["Fubar Plugin"]
mod.modref = "FubarPlugin"

local defaults = { 
	profile = {
		attachMinimap = false,
   	},
}

local options = {
		type = "group",
		handler = mod,
		name = LL["Fubar"],
		desc = LL["Fubar"],
		order = 1000,
		args = {
			toggle = {
				type = "toggle",
				name = LL["Toggle Fubar"],
				desc = LL["Toggle Fubar"],
				get = function() return mod:IsEnabled() end,
				set = 	function(info, v) 
						if v then 
							mod:Enable()
							mod:debug("Enabled FubarPlugin")
						else
							mod:Disable()
							mdkp:debug("Disabled FubarPlugin")
						end
					end,
				order = 5
			},
			attachMinimap = {
				type = "toggle",
				name = LL["Attach to minimap"],
				desc = LL["Attach to minimap"],
				get = function() return mod:IsFuBarMinimapAttached() end,
				set = 	function(info, v)
						mod:ToggleFuBarMinimapAttached()
						mod.db.profile.attachMinimap = v
					end,
				hidden = function() return not mod:IsEnabled() end,
				order = 10
			},
			hideIcon = {
				type = "toggle",
				name = LL["Hide minimap icon"],
				desc = LL["Hide minimap icon"],
				get = function() return mod.db.profile.hideIcon end,
				set = 	function(info, v)
						mod.db.profile.hideIcon = v
						if v then mod:Hide()
						else mod:Show()	end
					end,
				hidden = function() return not mod:IsEnabled() end,
				order = 15
			},
			showIcon = {
				type = "toggle",
				name = LL["Show icon"],
				desc = LL["Show icon"],
				get = function() return mod:IsFuBarIconShown() end,
				set = function(info, v) mod:ToggleFuBarIconShown() end,
				hidden = function() return not mod:IsEnabled() end,
				order = 20
			},
			showText = {
				type = "toggle",
				name = LL["Show text"],
				desc = LL["Show text"],
				get = function() return mod:IsFuBarTextShown() end,
				set = function(info, v) mod:ToggleFuBarTextShown() end,
				hidden = function() return not mod:IsEnabled() end,
				order = 25
			},
			position = {
				type = "select",
				name = LL["Position"],
				desc = LL["Position"],
				values = {LEFT = LL["LEFT"], CENTER = LL["CENTER"], RIGHT = LL["RIGHT"]},
				get = function() return mod:GetPanel() and mod:GetPanel():GetPluginSide(mod) end,
				set = 	function(info, v)
						if mod:GetPanel() then
							mod:GetPanel():SetPluginSide(mod, v)
						end
					end,
				hidden = function() return not mod:IsEnabled() end,
				order = 30
			}
		},
}

function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return nil
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("FubarPlugin", defaults)
	if not fubar then mod:Disable() return end
	
	--fubar config
	self:SetFuBarOption("tooltipType", "Custom")
	self:SetFuBarOption("configType", "AceConfigDialog-3.0")
	self:SetFuBarOption("hideWithoutStandby", true)
	self:SetFuBarOption("defaultMinimapPosition", 195)
	self:SetFuBarOption("independentProfile", true)
	self:SetFuBarOption("iconPath", "Interface\\AddOns\\MorgDKP2\\Icons\\AquaOFF")
	
end

function mod:OnEnable()
	if not fubar then 
		if mdkp.db.profile.modules.FubarPlugin then self:out(LL["Sorry you need LibFubarPlugin-3.0 to run the fubar plugin (included in Fubar3.5)"]) end
		mod:Disable() 
		return 
	end
	mdkp.db.profile.modules.FubarPlugin = true
	mdkp.db.profile.moduleON["FubarPlugin"] = true
	self.frame = self:GetFrame()
	self:CreateFubarObject()
end

function mod:OnDisable()
	mdkp.db.profile.moduleON["FubarPlugin"] = nil
	mdkp.db.profile.modules.FubarPlugin = nil
end


function mod:ActivateCore()
	if not self.Fubarframe then return end
	self:SetFuBarIcon("Interface\\AddOns\\MorgDKP2\\Icons\\AquaON")
	self.Fubarframe.hint:SetText(L["|c000070ddClick:|r MorgBid2 Base query.\n|c000070ddALT-Click:|r Toggle ML/DE\n|c000070ddSHIFT-Click:|r Invite & Waitlist.\n|c000070ddCTRL-Click:|r Raid Tracker.\n|c000070ddCTRL-Click Itemlink:|r Ignore item."])
	self:ToggleFrameUpdate("TooltipFubar", true)
end

function mod:DeActivateCore()
	if not self.Fubarframe then return end
	self:SetFuBarIcon("Interface\\AddOns\\MorgDKP2\\Icons\\AquaOFF")
	self.Fubarframe.hint:SetText(L["On STANDBY.\n|c000070ddClick:|r to enable."])
	self:ToggleFrameUpdate("TooltipFubar", true)
end


function mod:OnFuBarEnter()
	if not self.Fubarframe then self:CreateFubarObject() end
	local X, Y = self:GetScaledCursorPosition()
	if Y < GetScreenHeight() / 2 then
		point, relPoint = "BOTTOM", "TOP"
	else
		point, relPoint = "TOP", "BOTTOM"
	end
	self.Fubarframe:SetScript("OnUpdate", nil)
	self.Fubarframe:ClearAllPoints()
    	self.Fubarframe:SetPoint(point, self.frame, relPoint,0,0)
	self.Fubarframe:Show()
	self:FrameUpdate(self.Fubarframe)
	
end

function mod:OnFuBarLeave()
	self.Fubarframe:Hide()
end

function mod:CreateFubarObject()
	if self.Fubarframe then return end
	local onenter = function(f) f:Show() end
	local onleave = function(f) f:Hide() end
	self.Fubarframe = self:Createframe("Tooltip_FubarMorgDKP2", onenter, onleave, nil, nil, L["On STANDBY.\n|c000070ddClick:|r to enable."], "TooltipFubar",nil, nil, mdkp.version or L["MorgDKP2"])
	self.Fubarframe:SetFrameStrata("FULLSCREEN")
end

function mod:OpenMenu()
	if not C.OpenFrames["MorgDKP2"] then C:Open("MorgDKP2") 
	else C:Close("MorgDKP2") end
end

function mod:OnFuBarClick()
	local core = self:GetModuleRef("CoreModule")
	if mod:CoreStatus() then
		if IsAltKeyDown() then
			mdkp.MLmode = not mdkp.MLmode
		elseif IsShiftKeyDown() then
			core:ListDKP("All")
		elseif IsControlKeyDown() then
			local raidtracker = self:GetModuleRef("RaidTracker")
			if raidtracker then raidtracker:OpenFrame() end
		else 
			core:MorgBidQuery()
		end
	else
		self.Fubarframe:Hide()
		mdkp:ActivateCore()
	end
	self:Updatetooltipdata(self.Fubarframe)
end

