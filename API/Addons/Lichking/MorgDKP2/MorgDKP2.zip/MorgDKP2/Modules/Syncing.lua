local mod = MorgDKP2:NewModule("Syncing", "AceComm-3.0", "AceSerializer-3.0", "AceTimer-3.0")

local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.Syncing

local mdkp = MorgDKP2
mod.modName = "Syncing"

local Player = UnitName("player")
local db
local db2
local fmt = string.format
local tsort = table.sort
local tinsert = table.insert
local tremove = table.remove
local find = string.find
local band = bit.band
local bor = bit.bor
local bxor = bit.bxor
local core = mdkp:GetModule("CoreModule", true)
local tracker = mdkp:GetModule("Tracker", true)	
local popupused = {[1] = false, [2] = false}
local lastpopupclosed 
local numpopsopen = 0
local INSYNC
local SYNCENABLED
local INITIALSYNCING
local SYNCTRIES = 0
local syncversion = 1.1

--statics
StaticPopupDialogs["AcceptSync"] = {
	text = TEXT(LL["Import %s data from %s?"]),
	button1 = TEXT(YES),
	button2 = TEXT(NO),
	OnAccept = function(v)
		mod:AcceptImport(v, 1)
	end,
	OnCancel = function(v, x, y)
		mod:DenyImport(v, x, y, 1)
	end,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1,
}

StaticPopupDialogs["AcceptSync2"] = {
	text = TEXT(LL["Import %s data from %s?"]),
	button1 = TEXT(YES),
	button2 = TEXT(NO),
	OnAccept = function(v)
		mod:AcceptImport(v, 2)
	end,
	OnCancel = function(v, x, y)
		mod:DenyImport(v, x, y, 2)
	end,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1,
}

local defaults = { 
	profile = {
		auto = true,
		broadcast = nil,
		receive = true,
		SYNCNEEDED = nil,
		LASTSYNCNEEDED = nil,
		PW = "MorgDKP2PW",
		syncdone = 0,
		overwrite = true,
		syncdata = {["SYNCID"] = 0, ["LASTSYNC"] = 0, ["OUT"] = {}, ["IN"] = {}, ["CLIENTS"] = {}, ["BUFFER"] = {}, ["LASTSYNCDATA"] = {}}
	},
}

local options = {
		type = "group",
		handler = mod,
		name = LL["Syncing"],
		desc = LL["Syncing system for communicating DKP between raid leaders."],
		order = 380,
		args = {
			enable = {
				type = "toggle",
				name = LL["Enable"],
				desc = LL["Syncing system for communicating DKP between raid leaders."],
				get = function() return mdkp.db.profile.modules.Syncing end,
				set = 	function(info, v) 
						mdkp.db.profile.modules.Syncing = v
						if v then 
							mod:Enable()
							mod:debug("Enabled Syncing")
						else
							mod:Disable()
							mdkp:debug("Disabled Syncing")
						end
					end,
				order = 5
			},
			automatic = {
				type = "toggle",
				name = LL["Automatic"],
				desc = LL["Automatically set broadcast/receive depending if you are the master looter."],
				get = function() return mod.db.profile.auto end,
				set = function(info, v) mod.db.profile.auto = v end,
				hidden = function() return not mdkp.db.profile.modules.Syncing end,
				order = 8
			},
			broadcast = {
				type = "toggle",
				name = LL["Broadcast"],
				desc = LL["Broadcast DKP changes to other raid leaders."],
				get = function() return mod.db.profile.broadcast end,
				set = function(info, v) 
						mod.db.profile.broadcast = v 
						mod:GetClients()
				end,
				hidden = function() return not mdkp.db.profile.modules.Syncing end,
				order = 10
			},
			receive = {
				type = "toggle",
				name = LL["Receive"],
				desc = LL["Accept DKP changes from other raid leaders."],
				get = function() return mod.db.profile.receive end,
				set = function(info, v) 
						mod.db.profile.receive = v 
						mod:SendListener()
				end,
				hidden = function() return not mdkp.db.profile.modules.Syncing end,
				order = 20
			},
			over = {
				type = "toggle",
				name = LL["Overwrite raid"],
				desc = LL["Overwrite the current raid if you receive an initial sync and are currently in a raid."],
				get = function() return mod.db.profile.overwrite end,
				set = function(info, v) mod.db.profile.overwrite = v end,
				hidden = function() return not mdkp.db.profile.modules.Syncing or not mod.db.profile.receive end,
				order = 25
			},
			password = {
				type = "input",
				name = LL["Password"],
				desc = LL["Syncing password"],
				get = function() return mod.db.profile.PW end,
				set = 	function(info, v) if v then mod.db.profile.PW = v end end,
				hidden = function() return not mdkp.db.profile.modules.Syncing end,
				order = 30
			},
			head1 = {
				type = "header",
				name = LL["Immediate Sync Options"],
				hidden = function() return not mdkp.db.profile.modules.Syncing end,
				order = 100
			},
			syncdb = {
				type = "execute",
				name = LL["Send DB Sync"],
				desc = LL["Sends your current database of member DKP values, item values, and MorgDKP2 options to the current raid."],
				func = function() mod:SendManualFullSync() end,
				hidden = function() return not mdkp.db.profile.modules.Syncing end,
				order = 110
			},
			syncmem = {
				type = "execute",
				name = LL["Members Sync"],
				desc = LL["Sends your current database of member DKP values."],
				func = function() mod:SendManualMemberSync() end,
				hidden = function() return not mdkp.db.profile.modules.Syncing end,
				order = 120
			},
			syncitems = {
				type = "execute",
				name = LL["Items Sync"],
				desc = LL["Sends your current database of item DKP values."],
				func = function() mod:SendManualItemSync() end,
				hidden = function() return not mdkp.db.profile.modules.Syncing end,
				order = 130
			},
			syncoptions = {
				type = "execute",
				name = LL["Options Sync"],
				desc = LL["Sends your current MorgDKP2 options.  Note will restart MorgDKP2 so do not send another sync until it restarts or use full sync and it will be handled properly."],
				func = function() mod:SendManualOptionsSync() end,
				hidden = function() return not mdkp.db.profile.modules.Syncing end,
				order = 140
			},
			resendsync = {
				type = "execute",
				name = LL["Initial Sync"],
				desc = LL["Resends initial sync.  Only needed in cases where you have problems as this is done automatically."],
				func = function() mod:InitialSync() end,
				hidden = function() return not mdkp.db.profile.modules.Syncing end,
				order = 150
			},
		},
}

function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return nil
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("Syncing", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
	db2 = self.db.profile
	db.moduleON["Syncing"] = true
	
	self:ToggleSyncOptions()
	self:RegisterComm("MorgDKP2Syncing", "OnSyncMessage")
	if db2.broadcast then 
		self:GetClients()
	end
	if db2.receive then 
		self:SendListener()
	end
end

function mod:OnDisable()
	db.moduleON["Syncing"] = nil
	self:StopTimer()
end

function mod:StopTimer()
	self:CancelTimer(self.timer, true) 
	self.timer = nil
end

function mod:RestartTimer()
	if not self.timer then 
		self:debug("Sync timer started...")
		self.timer = self:ScheduleRepeatingTimer("RecurrentSync", 60)
	end
end

function mod:GetClients()
	if not UnitInRaid("Player") then return end
	self:SendSync("CLIENTPING", nil, true)
end

function mod:UpdateClients(name, action, syncdone)
	if not db2.broadcast then return end
	local ref = self:GetClientRef(name)
	if action == "+" then
		if not ref then
			tinsert(db2.syncdata.CLIENTS, {["name"] = name, ["updated"] = 0, ["syncdone"] = 0})
			self:debug("Added "..name.." to listeners")
			self:out(fmt(LL["Added %s to listeners."], name))
		else
			db2.syncdata.CLIENTS[ref].updated = syncdone
			self:debug("Updated "..name.." to syncdone ="..syncdone)
		end
	elseif action == "-" and ref then
		tremove(db2.syncdata.CLIENTS, ref)
		self:debug("Removed "..name.." from listeners")
		self:out(fmt(LL["Removed %s from listeners."], name))
	end
	self:IsEventneeded()
end

function mod:GetClientRef(name)
	for num, data in pairs(db2.syncdata.CLIENTS) do
		if data.name == name then return num end
	end
	return nil
end

function mod:MemberAdded(name)
	if not db2.broadcast then return end
	local ref = self:GetClientRef(name)
	if not ref then self:GetClients() end
end

function mod:ListenerRaidStartDone(name)
	local ref = self:GetClientRef(name)
	if ref then
		db2.syncdata.CLIENTS[ref].updated = 1
		self:debug(name.." received initial sync")
	end
end

function mod:ListenerSyncDone(name)
	local ref = self:GetClientRef(name)
	if ref then
		db2.syncdata.CLIENTS[ref].syncdone = 1
		self:debug(name.." received sync")
	end
	if self:AllListenersUpdated("syncdone") then
		self:debug("All listeners synced for current sync")
		db2.syncdata.LASTSYNCDATA = {}
		self:ReactivateListeners()
		SYNCTRIES = 0
		db2.LASTSYNCNEEDED = nil
	else 
		db2.LASTSYNCNEEDED = true
	end
end

function mod:ReactivateListeners()
	for num, data in pairs(db2.syncdata.CLIENTS) do
		data.syncdone = 0
	end
end

function mod:SendListener()
	if not UnitInRaid("Player") then return end
	self:SendSync("CLIENTLISTENING", db2.syncdone, true)
end

function mod:IsEventneeded()
	if db2.broadcast and db.InRaid and db2.syncdata.CLIENTS and #db2.syncdata.CLIENTS > 0 then
		self:RestartTimer()
		SYNCENABLED = true
		return true
	end
	SYNCENABLED = nil
	return false
end

function mod:ToggleSyncOptions()
	if not self.db.profile.auto then return end
	if mdkp.db.profile.dkplistener then
		self.db.profile.broadcast = nil
		self.db.profile.receive = true
	else
		self.db.profile.broadcast = true
		self.db.profile.receive = nil
	end
end

function mod:SendManualFullSync()
	self:debug("Sending full sync...")
	self:PrepareSyncData(true, true, true)
	self:SendSync("FULL", db2.syncdata.OUT)
end

function mod:SendManualMemberSync()
	self:debug("Sending member sync...")
	self:PrepareSyncData(nil, nil, true)
	self:SendSync("MEMBERS", db2.syncdata.OUT)
end

function mod:SendManualItemSync()
	self:debug("Sending item sync...")
	self:PrepareSyncData(nil, true)
	self:SendSync("ITEMS", db2.syncdata.OUT)
end

function mod:SendManualOptionsSync()
	self:debug("Sending option sync...")
	self:PrepareSyncData(true)
	self:SendSync("OPTIONS", db2.syncdata.OUT)
end

function mod:PrepareSyncData(options, items, players)
	db2.syncdata.OUT = {}
	for key, data in pairs(db) do
		if items and key == "items" then 
			--add itemDB to data
			db2.syncdata.OUT[key] = data
			
		elseif players and key == "info" then
			--add player DKP info to data
			db2.syncdata.OUT[key] = {}
			for name, playerdata in pairs(data) do
				db2.syncdata.OUT[key][name] = {}
				for key2, detaileddata in pairs(playerdata) do
					if key2 ~= "items" and (key2 ~= "aliases" or (key2 == "aliases" and #detaileddata > 0)) then
						db2.syncdata.OUT[key][name][key2] = detaileddata
					end
				end
			end
		elseif options and (key ~= "dbupdated" and key ~= "hints" and key ~= "menuzone" and key ~= "Timestamp" and key ~= "custom" and key ~= "items" and key ~= "info" and key ~= "devmode" and key ~= "dkplistener" and key ~= "InRaid" and key ~= "instancedifficulty" and key ~= "mlooter" and key ~= "raidend" and key ~= "raidended" and key ~= "raidexport" and key ~= "raidmembers" and key ~= "raidnum" and key ~= "raidstart" and key ~= "dkpmodules" and key ~= "moduleON" and key ~= "raidlog" and key ~= "lootbuffer") then
			--add options DB to data
			db2.syncdata.OUT[key] = data
		end
	end
	if options then
		db2.syncdata.OUT.namespaces = {}
		for key, data in pairs(MorgDKP2DB.namespaces) do
			if key ~= "LDBPlugin" and key ~= "FixedDKP" and key ~= "Whisper" and key ~= "Syncing" and key ~= "Relational" and key ~= "SKall" and key ~= "PointsDB" and key ~= "Random" then
				db2.syncdata.OUT.namespaces[key] = {}
				for key2, data2 in pairs(data) do
					if key2 ~= "profileKeys" then
						db2.syncdata.OUT.namespaces[key][key2] = data2
					end
				end
			end
		end
	end	
end

function mod:SendSync(datatype, data, silent)
	self:SendCommMessage("MorgDKP2Syncing", self:Serialize(datatype, syncversion, db2.PW, data, silent, db2.syncdata.SYNCID), "RAID")
end

function mod:OnSyncMessage(prefix, message, distribution, sender)
	if not db2.receive and not db2.broadcast then return end
	
	local result, command, version, password, data, silent, syncid = self:Deserialize(message)
	if not result then return end
	if syncversion < version then 
		self:out(fmt(LL["%s's MorgDKP2 is out of date!"], sender))
		return
	elseif password ~= db2.PW then 
		self:out(fmt(LL["%s's password does not match your password!"], sender))
		return
	end
	if command == "RAIDSTART" and sender == Player then 
		self:debug("Initial sync done")
		INITIALSYNCING = nil
		db2.syncdata.OUT = {}
		return
	elseif sender == Player then return end
	
	if command == "CLIENTSYNC" and syncid == db2.syncdata.LASTSYNC then self:debug("Already synced!") return end
	
	if data and command ~= "CLIENTLISTENING" then 
		tinsert(db2.syncdata.IN, {["COMMAND"] = command, ["DATA"] = data, ["SENDER"] = sender})
	end
	
	if silent then 
		self:AcceptImport(nil, nil, command, sender, syncid, data)
	else
		self:ShowPopup(command, sender)
	end
end

function mod:ShowPopup(command, sender)
	if numpopsopen == 2 then return end
	local popup 
	if not popupused[1] and lastpopupclosed ~= 1 then
		popup = "AcceptSync"
		popupused[1] = true
	elseif not popupused[2] and lastpopupclosed ~= 2 then
		popup = "AcceptSync2"
		popupused[2] = true
	else
		return
	end
	local dialog = StaticPopup_Show (popup, command, sender)
	if dialog then dialog.data = command end
	numpopsopen = numpopsopen + 1
end

function mod:AcceptImport(data, popup, command, sender, syncid, syncdone)
	if data then command = data.data end                       
	self:debug("Accepting import"..command)
	if popup then
		popupused[popup] = false
		lastpopupclosed = popup
		numpopsopen = numpopsopen - 1
	end
	
	local index = self:GetImportIndex(command)
	self:debug("SYNCID= "..(syncid or "NIL").." LASTSYNC= "..(db2.syncdata.LASTSYNC or "NIL"))
	
	if command == "OPTIONS" then
		self:ImportOptions(index)
	elseif command == "MEMBERS" then
		self:ImportMembers(index)
	elseif command == "ITEMS" then
		self:ImportItems(index)
	elseif command == "FULL" then
		self:ImportOptions(index, true)
		self:ImportItems(index, true)
		self:ImportMembers(index, true)
		mdkp:RestartMorgDKP2()
		self:StartNextImport()
	elseif command == "RAIDSTART" and db2.receive then
		self:ImportOptions(index, true)
		self:ImportMembers(index, true)
		self:CheckCurrentRaidValues()
		db2.syncdone = 1
		self:SendSync("STARTDONE", nil, true)
	elseif command == "CLIENTPING" and db2.receive then
		self:SendSync("CLIENTLISTENING", db2.syncdone, true)
	elseif command == "CLIENTLISTENING" then
		self:UpdateClients(sender, "+", syncdone)
	elseif command == "CLIENTSYNC" and db2.receive then
		self:ImportSync(index)
		self:SendSync("SYNCDONE", nil, true)
		db2.syncdata.LASTSYNC = syncid
	elseif command == "STARTDONE" and db2.broadcast then
		self:ListenerRaidStartDone(sender)
	elseif command == "SYNCDONE" and db2.broadcast then
		self:ListenerSyncDone(sender)
	end
	if index then tremove(db2.syncdata.IN, index) end
end

function mod:DenyImport(data, comm, reason, popup)
	local command
	if data then command = data.data end
	self:debug("Denying import"..command.." "..(reason or "NIL"))
	popupused[popup] = false
	lastpopupclosed = popup
	numpopsopen = numpopsopen - 1
	
	if reason ~= "clicked" then return end
	
	local index = self:GetImportIndex(command)
	if not index then return end
	
	tremove(db2.syncdata.IN, index)
	self:StartNextImport()
end

function mod:StartNextImport()
	if db2.syncdata.IN and #db2.syncdata.IN > 0 and numpopsopen == 0 then
		self:debug("Starting Qed import..."..db2.syncdata.IN[1].COMMAND.." from "..db2.syncdata.IN[1].SENDER)
		self:ShowPopup(db2.syncdata.IN[1].COMMAND, db2.syncdata.IN[1].SENDER)
	else lastpopupclosed = nil end
end

function mod:GetImportIndex(command)
	for index, sync in ipairs(db2.syncdata.IN) do
		if sync.COMMAND == command then
			return index
		end
	end
end

function mod:ImportOptions(index, FULL)
	if not db2.syncdata.IN[index] or not db2.receive then return end
	self:debug("Working on OPTIONS IMPORT...")
	
	for key, data in pairs(db2.syncdata.IN[index].DATA) do
		if key ~= "items" and key ~= "info" and key ~= "zone" and key ~= "diff" and key ~= "raidlog" and key ~= "attendancedone" then 
			if key == "namespaces" then
				for key2, data2 in pairs(data) do
					MorgDKP2DB.namespaces[key2] = data2
				end
			elseif key == "eqDKP" then
				if not db.eqDKP then db.eqDKP = {} end
				for key2, data2 in pairs(data) do
					if not db.eqDKP[key2] then 
						db.eqDKP[key2] = data2
					else
						for key3, data3 in pairs(data2) do
							if key3 == "Events" then
								for bossname, bossdata in pairs(data3) do
									db.eqDKP[key2][key3][bossname] = bossdata
									if db.InRaid then
										self:CheckCurrentRaidEvent(bossname, bossdata.value, db.raid, true)
									end
								end
							elseif key3 == "Aliases" then
								for alt, main in pairs(data3) do
									db.eqDKP[key2][key3][alt] = main
								end
							else
								db.eqDKP[key2][key3] = data3
							end
						end
					end
				end
			elseif key == "raidlist" then
				for key2, data2 in pairs(data) do
					if data2 then
						if not db.raidlist or (db.raidlist and db.raidlist[1] == L["NONE"]) then db.raidlist[1] = data2 
						elseif not self:DoesPoolexist(data2) then tinsert(db.raidlist, data2) 
						end
					end
				end
			elseif key == "currDKP" then
				if db.currDKP ~= data then 
					local module = mdkp:GetModule(data, true)
					if module then
						local name, ref = module:GetName()
						core:ChangeDKPType(name) 
					end
				end
			elseif key == "eventnaming" then
				local eventnaming = self:GetModuleRef("Eventnaming")
				if eventnaming then eventnaming:SetEventFormat(data.s, data.t, data.b) end
			elseif key == "InRaid" then
				if data then
					local newraid = db2.syncdata.IN[index].DATA.raidlog
					local pool = db2.syncdata.IN[index].DATA.raid
					self:UpdateeqDKPEvents(newraid.bosskills, pool)
					if not db.InRaid then
						if not db.raidnum then db.raidnum = 0 end
						db.raidnum = db.raidnum + 1
						db.InRaid = true
						db.raidlog[db.raidnum] = newraid
						db.raidlog.attendancedone = db2.syncdata.IN[index].DATA.attendancedone
						db.raidstart = newraid.raidstart
						db.raidend = L["PENDING"]
						db.raidexport = L["PENDING"]
					else
						if newraid.bosskills and #newraid.bosskills > 2 and db2.overwrite then
							db.raidlog[db.raidnum] = newraid
							db.raidlog.attendancedone = db2.syncdata.IN[index].DATA.attendancedone
							db.raidstart = newraid.raidstart
							db.raidend = L["PENDING"]
							db.raidexport = L["PENDING"]
						else
							self:EditCurrentRaidNames(db2.syncdata.IN[index].DATA.zone, db2.syncdata.IN[index].DATA.diff)
						end
					end
					self:ToggleFrameUpdate("TooltipLDB")
				end
			else
				db[key] = data
			end
		end
	end
	if not FULL then
		self:out(LL["Imported options...restarting."])
		mdkp:RestartMorgDKP2()
	end
end

function mod:UpdateeqDKPEvents(bosskills, pool)
	if not db.eqDKP then db.eqDKP = {} end
	if not db.eqDKP[pool] then db.eqDKP[pool] = {["Events"] = {}, ["Aliases"] = {}} end
				
	for id, bossdata in pairs(bosskills) do
		local bossname = bossdata.name
		if not db.eqDKP[pool].Events[bossname] then db.eqDKP[pool].Events[bossname] = {["id"] = 0, ["value"] = bossdata.value} 
		else db.eqDKP[pool].Events[bossname].value = bossdata.value end
	end
end

function mod:DoesPoolexist(newpool)
	for index, pool in pairs(db.raidlist) do
		if pool == newpool then return true end
	end
	return nil
end

function mod:ImportItems(index, FULL)
	if not db2.syncdata.IN[index] or not db2.receive then return end
	self:debug("Working on ITEMS IMPORT...")
	
	local itemcount = 0
	if not db.items then db.items = {} end
	for id, data in pairs(db2.syncdata.IN[index].DATA.items) do
		db.items[id] = data
		itemcount = itemcount + 1
	end
	
	self:out(fmt(LL["Imported %s items"], itemcount))
	if not FULL then 
		self:StartNextImport()	
	end
end

function mod:ImportMembers(index, FULL)
	if not db2.syncdata.IN[index] or not db2.receive then return end
	self:debug("Working on MEMBERS IMPORT...")
	
	local membercount = 0
	if not db.info then db.info = {} end
	for name, data in pairs(db2.syncdata.IN[index].DATA.info) do
		if not db.info[name] then 
			db.info[name] = data 
			self:AddNewAliases(name)
		elseif mdkp.roster[name] or data.lastupdate > db.info[name].lastupdate then
			for key, playerdata in pairs(data) do
				if key == "aliases" then 
					if db.info[name].aliases and #db.info[name].aliases > 0 then
						for _, newaliasdata in pairs(playerdata) do
							if not core:DoesAliasExist(name, newaliasdata.alt, newaliasdata.raid) then
								tinsert(db.info[name].aliases, newaliasdata)
								core:AddAlias(newaliasdata.alt, name, true)
							end
						end
					else
						db.info[name][key] = playerdata
						self:AddNewAliases(name)
					end
				else
					db.info[name][key] = playerdata
				end
			end
			membercount = membercount + 1
		end
	end
	
	self:out(fmt(LL["Updated %s members"], membercount))
	if not FULL then 
		self:StartNextImport()	
	end
end

function mod:AddNewAliases(name)
	local POOL = db.raid
	if not db.eqDKP then db.eqDKP = {} end 
	if not db.eqDKP[POOL] then db.eqDKP[POOL] = {["Aliases"] = {}, ["Events"] = {}} end 
	if not db.eqDKP[POOL].Aliases then db.eqDKP[POOL].Aliases = {} end 
	if db.info[name] and db.info[name].aliases and #db.info[name].aliases > 0 then
		for _, newaliasdata in pairs(db.info[name].aliases) do
			if not db.eqDKP[POOL].Aliases[newaliasdata.alt] then
				self:debug("Adding alias "..newaliasdata.alt.." of "..name)
				core:AddAlias(newaliasdata.alt, name, true)
			end
		end
	end
end

function mod:ImportSync(index)
	if not db2.syncdata.IN[index] or not db2.receive then return end
	self:debug("Importing syncdata...")
	local raidnum = db.raidnum
	local wait = self:GetModuleRef("Waitlist")
	local raidtracker = self:GetModuleRef("RaidTracker")
	local core = self:GetModuleRef("CoreModule")
	local raidupdated
	
	for key, data in pairs(db2.syncdata.IN[index].DATA) do
		if key == "alias" then
			for _, aliasdata in ipairs(data) do
				core:AddAlias(aliasdata.alt, aliasdata.main, nil, aliasdata.pool, true)
			end
		elseif key == "items" then
			if not db.items then db.items = {} end
			for _, itemdata in ipairs(data) do
				db.items[itemdata.item] = itemdata.data
			end
		elseif key == "recorditem" then
			for _, itemdata in ipairs(data) do
				self:IteminDB(itemdata.id)
				db.items[itemdata.id].points = itemdata.value
				core:RecordLoot(itemdata.link, itemdata.name)
			end
			raidupdated = true
		elseif key == "customevent" then
			for _, eventdata in ipairs(data) do
				tracker:CustomEvent(eventdata.event, true)
			end
			raidupdated = true
		elseif key == "raidend" then
			if db.InRaid then
				tracker:ShowEndRaidFrame(nil, true) 
				self:ShutDownAfterRaidEnd()
			end
			raidupdated = true
		elseif key == "waitlist" then
			if wait then wait:UpdateSyncWaitlist(data) end
		elseif key == "dkptype" then
			if core then core:ChangeDKPType(data.name, true) end
		elseif key == "quality" then
			db.quality = data.value
		elseif key == "disenchanter" then
			db.disenchanter = data.name
		elseif key == "addwait" then
			if wait then
				for _, waitdata in pairs(data) do
					wait:AddWait(waitdata.name, true)
				end
			end
		elseif key == "subwait" then
			if wait then
				for _, waitdata in pairs(data) do
					wait:SubWait(waitdata.name, true)
				end
			end
		elseif key == "eventchange" then
			local pool = db.raid
			if not db.eqDKP then db.eqDKP = {} end
			for _, eventdata in ipairs(data) do
				local newvalue, oldvalue
				local index = self:GetCorrectRaidEvent(raidnum, eventdata.oldevent, eventdata.oldnote)
				if index then
					raidtracker:ProcessEventNameNoteChange(raidnum, index, eventdata.newevent, eventdata.oldevent, eventdata.newnote, eventdata.oldnote)
					if db.eqDKP and db.eqDKP[pool] and db.eqDKP[pool]["Events"] then
						if db.eqDKP[pool]["Events"][newevent] then newvalue = db.eqDKP[pool]["Events"][newevent].value end
						if db.eqDKP[pool]["Events"][oldevent] then oldvalue = db.eqDKP[pool]["Events"][oldevent].value end
						if newvalue and oldvalue ~= newvalue then
							self:CheckCurrentRaidEvent(eventdata.newevent, newvalue, pool)
						end
					end
				end
				if eventdata.event then
					if not db.eqDKP[eventdata.pool] then db.eqDKP[eventdata.pool] = {["Events"] = {}, ["Aliases"] = {}} end
					if not db.eqDKP[eventdata.pool]["Events"][eventdata.event] then db.eqDKP[eventdata.pool]["Events"][eventdata.event] = {} end
					db.eqDKP[eventdata.pool]["Events"][eventdata.event].value = eventdata.value
					self:CheckCurrentRaidEvent(eventdata.event, eventdata.value, eventdata.pool)
				end
			end
			raidupdated = true
		elseif key == "dkpchange" then
			if raidtracker then 
				for _, eventdata in ipairs(data) do
					raidtracker:ProcessDKPChange(eventdata.event, eventdata.value, eventdata.attends, eventdata.pool)
				end
			end
		elseif key == "itemvalidate" then
			if raidtracker then
				if not db.raidlog[raidnum] or not db.raidlog[raidnum].loot then return end
				for _, itemdata in ipairs(data) do
					local index = self:GetCorrectRaidIndex(raidnum, itemdata.itemid)
					if index then
						local value = db.raidlog[raidnum].loot[index].Costs
						local newvalue = itemdata.value
						local oldwinner = db.raidlog[raidnum].loot[index].Player
						local newwinner = itemdata.winner
						local link = db.raidlog[raidnum].loot[index].ItemLink
						local boss = itemdata.boss
						local oldboss = db.raidlog[raidnum].loot[index].Boss
						if oldwinner ~= newwinner then
							raidtracker:ChangeItemWinner(raidnum, index, newwinner, {["winner"] = oldwinner, ["value"] = value, ["link"] = link}, itemdata.pool, itemdata.itemid) 
						end
						if boss ~= oldboss then
							raidtracker:ChangeItemEvent(raidnum, index, boss, {["winner"] = newwinner, ["value"] = value, ["link"] = link}, itemdata.pool)
						end
						if value ~= newvalue then
							itemdata.link = link
							raidtracker:ChangeItemDKPValue(raidnum, index, newvalue, itemdata, itemdata.pool, value, itemdata.itemid)
						end
					end
				end
				raidupdated = true
			end
		elseif key == "raiditemevent" then
			if raidtracker then
				if not db.raidlog[raidnum] or not db.raidlog[raidnum].loot then return end
				for _, itemdata in ipairs(data) do
					local index = self:GetCorrectRaidIndex(raidnum, itemdata.itemid, itemdata.oldevent, itemdata.value, itemdata.winner)
					if index then raidtracker:ChangeItemEvent(raidnum, index, itemdata.newevent, itemdata, itemdata.pool) end
				end
				raidupdated = true
			end
		elseif key == "raiditemwinner" then
			if raidtracker then
				if not db.raidlog[raidnum] or not db.raidlog[raidnum].loot then return end
				for _, itemdata in ipairs(data) do
					local index = self:GetCorrectRaidIndex(raidnum, itemdata.itemid, itemdata.event, itemdata.value, itemdata.winner)
					if index then raidtracker:ChangeItemWinner(raidnum, index, itemdata.newwinner, itemdata, itemdata.pool, itemdata.itemid) end
				end
				raidupdated = true
			end
		elseif key == "raiditemvalue" then
			if raidtracker then
				if not db.raidlog[raidnum] or not db.raidlog[raidnum].loot then return end
				for _, itemdata in ipairs(data) do
					local index = self:GetCorrectRaidIndex(raidnum, itemdata.itemid, itemdata.event, itemdata.oldcost, itemdata.winner)
					if index then raidtracker:ChangeItemDKPValue(raidnum, index, itemdata.newcost, itemdata, itemdata.pool, itemdata.oldcost, itemdata.itemid) end
				end
				raidupdated = true
			end
		elseif key == "deleteitem" then
			if raidtracker then
				if not db.raidlog[raidnum] or not db.raidlog[raidnum].loot then return end
				for _, itemdata in ipairs(data) do
					local index = self:GetCorrectRaidIndex(raidnum, itemdata.itemid, itemdata.name, itemdata.value, itemdata.winner)
					if index then raidtracker:ProcessRaidItemDelete(index, raidnum, itemdata, itemdata.itemid) end
				end
				raidupdated = true
			end
		elseif key == "deleteevent" then
			if raidtracker then
				if not db.raidlog[raidnum] or not db.raidlog[raidnum].bosskills then return end
				for _, itemdata in ipairs(data) do
					local index = self:GetCorrectRaidEvent(raidnum, itemdata.name, itemdata.note, itemdata.value, itemdata.trash, itemdata.attends)
					if index then raidtracker:ProcessRaidEventDelete(index, raidnum, itemdata.name, itemdata.note, itemdata.trash, itemdata.attends, itemdata.value) end
				end
			end
			raidupdated = true
		end
	end
	if raidupdated and raidtracker then raidtracker:ForceRaidUpdate() end
end

function mod:EditCurrentRaidNames(zone, diff)
	self:debug("Editing start/run events.."..zone)
	local eventnaming = self:GetModuleRef("Eventnaming")
	if eventnaming then startformat, trashformat, _ = eventnaming:GetEventFormat() 
	else 
		startformat = "<zone> <diff> Start"
		trashformat = "<zone> <diff> Run"
	end
	local raidnum = db.raidnum
	local POOL = db.raid
	local startindex = self:GetEventID(1)
	if startindex then
		local Startname = self:GetEventName(nil, startformat, zone, diff)
		db.raidlog[raidnum].bosskills[startindex].name = Startname
		db.raidlog[raidnum].bosskills[startindex].note = Startname
		if db.eqDKP and db.eqDKP[POOL] and db.eqDKP[POOL].Events and db.eqDKP[POOL].Events[Startname] then 
			db.raidlog[raidnum].bosskills[startindex].value = db.eqDKP[POOL].Events[Startname].value
		end
	end
	local Runname = self:GetEventName(nil, trashformat, zone, diff)
	local runindex = self:GetEventID(2)
	db.raidlog[raidnum].bosskills[runindex].name = Runname
	db.raidlog[raidnum].bosskills[runindex].note = Runname
	if not db.eqDKP or not db.eqDKP[POOL] or not db.eqDKP[POOL].Events then return end
	if db.eqDKP[POOL].Events[Runname] then
		db.raidlog[raidnum].bosskills[runindex].value = db.eqDKP[POOL].Events[Runname].value
	end
end

function mod:RecurrentSync()
	if INSYNC then self:debug("Syncing...please wait") return end
	self:debug("Checking if sync needed...")
	if not self:AllListenersUpdated("updated") and not INITIALSYNCING then self:InitialSync() end
	if (db2.SYNCNEEDED or db2.LASTSYNCNEEDED) and not INITIALSYNCING then
		INSYNC = true
		if db2.LASTSYNCNEEDED then 
			if SYNCTRIES > 3 then
				db2.syncdata.LASTSYNCDATA = {}
				self:ReactivateListeners()
				SYNCTRIES = 0
				db2.LASTSYNCNEEDED = nil
			else
				self:debug("Repeating last sync")
				self:SendSync("CLIENTSYNC", db2.syncdata.LASTSYNCDATA, true)
				SYNCTRIES = SYNCTRIES + 1
			end
		else
			self:debug("Sending new sync")
			db2.syncdata.SYNCID = db2.syncdata.SYNCID + 1
			self:SendSync("CLIENTSYNC", db2.syncdata.BUFFER, true)
			db2.syncdata.LASTSYNCDATA = db2.syncdata.BUFFER
			db2.syncdata.BUFFER = {}
			db2.LASTSYNCNEEDED = true
			db2.SYNCNEEDED = nil
			SYNCTRIES = 0
		end
		INSYNC = nil
	end
end

function mod:AllListenersUpdated(check)
	for _, data in pairs(db2.syncdata.CLIENTS) do
		if data[check] == 0 and UnitIsConnected(data.name) then self:debug(data.name.." needs sync! "..check) return nil end
	end
	self:debug("No users need "..check.." sync")
	return true
end

function mod:AddAliastoSync(alt, main, POOL)
	if not SYNCENABLED then return end
	self:debug("Add alias for sync")
	if not db2.syncdata.BUFFER["alias"] then db2.syncdata.BUFFER["alias"] = {} end
	tinsert(db2.syncdata.BUFFER["alias"], {["alt"] = alt, ["main"] = main, ["pool"] = POOL})
	db2.SYNCNEEDED = true
end

function mod:ManualItem(itemlink, name)
	if not SYNCENABLED then return end
	self:debug("Add BOE/manual item to sync")
	local _,_, item = find(itemlink, "item:(%d+):")
	item = tonumber(item)
	if not db2.syncdata.BUFFER["recorditem"] then db2.syncdata.BUFFER["recorditem"] = {} end
	tinsert(db2.syncdata.BUFFER["recorditem"], {["link"] = itemlink, ["name"] = name, ["id"] = item, ["value"] = db.items[item].points})
	db2.SYNCNEEDED = true
end

function mod:AtRaidStart()
	if not self:IsEventneeded() or INITIALSYNCING then return end
	self:SendSync("CLIENTPING", nil, true)
	self:RecurrentSync()
end

function mod:InitialSync()
	self:debug("Sending initial sync")
	self:PrepareSyncData(nil, nil, true)
	db2.syncdata.OUT.eqDKP = db.eqDKP
	db2.syncdata.OUT.raidlist = db.raidlist
	db2.syncdata.OUT.raid = db.raid
	db2.syncdata.OUT.InRaid = db.InRaid
	db2.syncdata.OUT.currDKP = db.currDKP
	db2.syncdata.OUT.quality = db.quality
	db2.syncdata.OUT.disenchanter = db.disenchanter
	db2.syncdata.OUT.zone = GetRealZoneText()
	db2.syncdata.OUT.diff = db.instancedifficulty
	db2.syncdata.OUT.raidlog = db.raidlog[db.raidnum]
	db2.syncdata.OUT.attendancedone = db.raidlog.attendancedone
	local eventnaming = self:GetModuleRef("Eventnaming")
	if eventnaming then
		local start, trash, boss = eventnaming:GetEventFormat()
		db2.syncdata.OUT.eventnaming = {["s"] = start, ["t"] = trash, ["b"] = boss}
	end
	self:SendSync("RAIDSTART", db2.syncdata.OUT, true)
	INITIALSYNCING = true
end

function mod:AtRaidEnd()
	if SYNCENABLED then 
		if not db2.syncdata.BUFFER["raidend"] then db2.syncdata.BUFFER["raidend"] = {} end
		db2.syncdata.BUFFER["raidend"] = true
		db2.SYNCNEEDED = true
		db2.LASTSYNCNEEDED = nil
		self:RecurrentSync()
	end
	self:ShutDownAfterRaidEnd()
end

function mod:ShutDownAfterRaidEnd()
	self:StopTimer()
	db2.syncdata = {["SYNCID"] = 0, ["LASTSYNC"] = 0, ["OUT"] = {}, ["IN"] = {}, ["CLIENTS"] = {}, ["BUFFER"] = {}, ["LASTSYNCDATA"] = {}}
	db2.SYNCNEEDED = nil
	db2.LASTSYNCNEEDED = nil
	db2.syncdone = 0
	self:GetClients()
end

function mod:CustomEvent(event)
	if not SYNCENABLED then return end
	self:debug("Add custom event to sync")
	if not db2.syncdata.BUFFER["customevent"] then db2.syncdata.BUFFER["customevent"] = {} end
	tinsert(db2.syncdata.BUFFER["customevent"], {["event"] = event})
	db2.SYNCNEEDED = true
end

function mod:AddItem(itemID)
	if not SYNCENABLED then return end
	self:debug("Adding "..itemID.." to sync")
	if not db2.syncdata.BUFFER["items"] then db2.syncdata.BUFFER["items"] = {} end
	if not self:ItemAlreadySyncing(itemID) then 
		tinsert(db2.syncdata.BUFFER["items"], {["item"] = itemID, ["data"] = db.items[itemID]})
	end
	db2.SYNCNEEDED = true
end

function mod:ItemAlreadySyncing(item)
	for num, data in pairs(db2.syncdata.BUFFER["items"]) do
		if data.item == item then return true end
	end
	return nil
end

function mod:SendWaitlist(waitlist, force)
	if not SYNCENABLED and not force then return end
	self:debug("Add waitlist to sync")
	db2.syncdata.BUFFER["waitlist"] = waitlist
	db2.SYNCNEEDED = true
	if force then self:SendSync("CLIENTSYNC", db2.syncdata.BUFFER, true) end
end

function mod:AddtoWait(name)
	if not SYNCENABLED then return end
	self:debug("Add "..name.." to waitlist sync")
	if not db2.syncdata.BUFFER["addwait"] then db2.syncdata.BUFFER["addwait"] = {} end
	tinsert(db2.syncdata.BUFFER["addwait"], {["name"] = name})
	db2.SYNCNEEDED = true
end

function mod:SubfromWait(name)
	if not SYNCENABLED then return end
	self:debug("Remove "..name.." to waitlist sync")
	if not db2.syncdata.BUFFER["subwait"] then db2.syncdata.BUFFER["subwait"] = {} end
	tinsert(db2.syncdata.BUFFER["subwait"], {["name"] = name})
	db2.SYNCNEEDED = true
end

function mod:ChangeEventNameNote(newevent, oldevent, newnote, oldnote)
	if not SYNCENABLED then return end
	self:debug("Change "..(oldevent or "NIL").." to "..(newevent or "NIL").." or note "..(newnote or "NIL").." to "..(oldnote or "NIL").." and sync")
	self:ChangeEventData(newevent, oldevent, newnote, oldnote, eventname, value, pool)
end

function mod:ChangeEventValue(eventname, value, pool)
	if not SYNCENABLED then return end
	self:debug("Change "..eventname.." value to "..value.." and sync")
	self:ChangeEventData(newevent, oldevent, newnote, oldnote, eventname, value, pool)
end

function mod:ChangeEventData(newevent, oldevent, newnote, oldnote, eventname, value, pool)
	if not db2.syncdata.BUFFER["eventchange"] then db2.syncdata.BUFFER["eventchange"] = {} end
	local found
	if eventname then
		for index, data in ipairs(db2.syncdata.BUFFER["eventchange"]) do
			if not data.event and (data.newevent == eventname or data.oldevent == eventname) then
				data.event = eventname
				data.value = value
				data.pool = pool
				found = true
				break
			end
		end
	end
	if not found then
		tinsert(db2.syncdata.BUFFER["eventchange"], {["newevent"] = newevent, ["oldevent"] = oldevent, ["newnote"] = newnote, ["oldnote"] = oldnote, ["event"] = eventname, ["value"] = value, ["pool"] = pool})
	end
	db2.SYNCNEEDED = true
end

function mod:CheckCurrentRaidEvent(event, value, POOL, initial)
	local raidnum = db.raidnum
	if not db.raidlog[raidnum] or not db.raidlog[raidnum].bosskills then return end
	local found = nil
	
	for id, data in pairs(db.raidlog[raidnum].bosskills) do
		if data.name == event and data.value ~= value then
			local oldval = data.value
			data.value = value
			if not initial then self:AwardDKP(value, oldval, POOL, data.attendees) end
			found = true
		end
	end
	return found
end

function mod:DKPChangeSync(event, attendees, value, pool)
	if not SYNCENABLED then return end
	self:debug("DKP Change "..event.." value= "..value.." and sync")
	if not db2.syncdata.BUFFER["dkpchange"] then db2.syncdata.BUFFER["dkpchange"] = {} end
	tinsert(db2.syncdata.BUFFER["dkpchange"], {["event"] = event, ["value"] = value, ["attends"] = attendees, ["pool"] = pool})
	db2.SYNCNEEDED = true
end

function mod:ItemValidate(item, points, player, pool, boss)
	if not SYNCENABLED then return end
	self:debug("Item validate "..points.." to "..player.." add for sync")
	if not db2.syncdata.BUFFER["itemvalidate"] then db2.syncdata.BUFFER["itemvalidate"] = {} end
	tinsert(db2.syncdata.BUFFER["itemvalidate"], {["itemid"] = item, ["value"] = points, ["winner"] = player, ["boss"] = boss, ["pool"] = pool})
	db2.SYNCNEEDED = true
end

function mod:CheckCurrentRaidValues()
	if not db2.receive then return end
	local raidnum = db.raidnum
	if not db.raidlog[raidnum] then return end
	db.raidlog[raidnum].eqdkp = db.eqDKP[db.raid].eqDKPsite
	db.raidlog[raidnum].prefix = db.eqDKP[db.raid].prefix
	if not db.raidlog[raidnum].bosskills or not db.eqDKP[db.raid] or not db.eqDKP[db.raid].Events then return end
	for bossname, bossdata in pairs(db.eqDKP[db.raid].Events) do
		self:CheckCurrentRaidEvent(bossname, bossdata.value, db.raid, true)
	end
end

function mod:ChangeRaidItemEvent(value, itemdata, POOL, itemid)
	if not SYNCENABLED then return end
	self:debug("Change "..itemdata.name.." event to "..value.." and sync")
	if not db2.syncdata.BUFFER["raiditemevent"] then db2.syncdata.BUFFER["raiditemevent"] = {} end
	tinsert(db2.syncdata.BUFFER["raiditemevent"], {["itemid"] = itemid, ["oldevent"] = itemdata.event, ["newevent"] = value, ["value"] = itemdata.value, ["winner"] = itemdata.winner, ["link"] = itemdata.link, ["pool"] = POOL})
	db2.SYNCNEEDED = true
end

function mod:ChangeRaidItemWinner(value, itemdata, POOL, itemid)
	if not SYNCENABLED then return end
	self:debug("Change "..itemdata.name.." winner to "..value.." and sync")
	if not db2.syncdata.BUFFER["raiditemwinner"] then db2.syncdata.BUFFER["raiditemwinner"] = {} end
	tinsert(db2.syncdata.BUFFER["raiditemwinner"], {["itemid"] = itemid, ["winner"] = itemdata.winner, ["newwinner"] = value, ["event"] = itemdata.event, ["value"] = itemdata.value, ["link"] = itemdata.link, ["pool"] = POOL})
	db2.SYNCNEEDED = true
end

function mod:ChangeRaidItemValue(value, itemdata, POOL, oldcost, itemid)
	if not SYNCENABLED then return end
	self:debug("Change "..itemdata.name.." value from "..oldcost.." to "..value.." and sync")
	if not db2.syncdata.BUFFER["raiditemvalue"] then db2.syncdata.BUFFER["raiditemvalue"] = {} end
	tinsert(db2.syncdata.BUFFER["raiditemvalue"], {["itemid"] = itemid, ["winner"] = itemdata.winner, ["newcost"] = value, ["oldcost"] = oldcost, ["event"] = itemdata.event, ["link"] = itemdata.link, ["pool"] = POOL})
	db2.SYNCNEEDED = true
end

function mod:DeleteRaidItem(itemdata, itemid)
	if not SYNCENABLED then return end
	self:debug("Delete "..itemid.." from "..itemdata.name.." and sync")
	if not db2.syncdata.BUFFER["deleteitem"] then db2.syncdata.BUFFER["deleteitem"] = {} end
	tinsert(db2.syncdata.BUFFER["deleteitem"], {["itemid"] = itemid, ["winner"] = itemdata.winner, ["value"] = value, ["name"] = itemdata.name, ["link"] = itemdata.link})
	db2.SYNCNEEDED = true
end

function mod:DeleteRaidEvent(eventname, eventnote, trash, attendees, eventvalue)
	if not SYNCENABLED then return end
	self:debug("Delete "..eventname.." from current raid and sync")
	if not db2.syncdata.BUFFER["deleteevent"] then db2.syncdata.BUFFER["deleteevent"] = {} end
	tinsert(db2.syncdata.BUFFER["deleteevent"], {["name"] = eventname, ["note"] = eventnote, ["value"] = eventvalue, ["attends"] = attendees, ["trash"] = trash})
	db2.SYNCNEEDED = true
end

function mod:ChangeDKPSystem(newtype)
	if not SYNCENABLED then return end
	self:debug("Send sync to change to DKP: "..newtype)
	db2.syncdata.BUFFER["dkptype"] = {["name"] = newtype}
	db2.SYNCNEEDED = true
end

function mod:ChangeQualityThreshold(newquality)
	if not SYNCENABLED then return end
	self:debug("Change quality threshold to "..newquality)
	db2.syncdata.BUFFER["quality"] = {["value"] = newquality}
	db2.SYNCNEEDED = true
end

function mod:ChangeDisenchanter(disenchanter)
	if not SYNCENABLED then return end
	self:debug("Change disenchanter to "..disenchanter)
	db2.syncdata.BUFFER["disenchanter"] = {["name"] = disenchanter}
	db2.SYNCNEEDED = true
end

function mod:GetCorrectRaidIndex(raidnum, id, event, value, winner)
	self:debug("Get raid index")
	local data
	for index = #db.raidlog[raidnum].loot, 1, -1 do
		data = db.raidlog[raidnum].loot[index]
		if (not event or (event and data.Boss == event)) and (not value or (value and data.Costs == value)) and (not winner or (winner and data.Player == winner)) and data.ID == id then
			self:debug("Index="..index)
			return index
		end
	end
	return nil
end
