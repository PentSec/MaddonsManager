local mod = MorgDKP2:NewModule("Relational")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.Relational

local mdkp = MorgDKP2 

mod.modName = LL["Relational DKP"]
mod.modref = "Relational"

local Player = UnitName("player")
local db
local fmt = string.format
local floor = math.floor

local defaults = { 
	profile = {
		baseDKP = 1,
	},
}

local options = {
		relationaldkp = {
			type = "toggle",
			name = LL["Relational DKP"],
			desc = LL["Enable Relational DKP for calculating the earned/spent dkp ratio."],
			get = function() return mdkp.db.profile.modules.Relational end,
			set = 	function(info, v) 
					mdkp.db.profile.modules.Relational = v
					mod:DKPChange(mod.modName)
			end,
			order = 10
		},
		relationalhead = {
			type = "header",
			name = LL["Relational DKP Options"],
			hidden = function() return not mdkp.db.profile.modules.Relational end,
			order = 100
		},
		relationalmin = {
			type = "range",
			name = LL["Minimum DKP base"],
			desc = LL["Minimum amount of DKP a member can have for calculating the DKP ratio to avoid a new member having a high ratio. ie  200 earned DKP/ (this value)"],
			get = function() return mod.db.profile.baseDKP end,
			set = function(info, v) mod.db.profile.baseDKP = v end,
			min = 1, 
			max = 1000, 
			step = 1,
			hidden = function() return not mdkp.db.profile.modules.Relational end,
			order = 110
		},
}

function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return true
end

function mod:GetName()
	return mod.modName, mod.modref
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("Relational", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile	
	db.moduleON["Relational"] = true
	
end

function mod:OnDisable()
	db.moduleON["Relational"] = nil
end

function mod:GetPlayerPoints(name, POOL, showearned)
	if showearned then return db.info[name][POOL].earned
	else
		local baseDKP = mod.db.profile.baseDKP
		local earned, spent = db.info[name][POOL].earned, db.info[name][POOL].spent
		if spent < baseDKP then spent = baseDKP end
		local points = fmt("%.2f", (earned / spent ))
		return points 
	end
end

function mod:GetItemValue(itemid, player, POOL)
	local itempoints = db.items[itemid].points
	itempoints = floor(self:GetTAKEModeValue(itemid, itempoints, player) + 0.5)
	return itempoints
end

function mod:ItemRecorded(id, looter, POOL, points, itempoints, link)
	if looter == L["Bank"] then return end
	points = db.info[looter][POOL].points - itempoints
	self:AwardItem(id, looter, POOL, points, itempoints, link)
end

function mod:ItemRebate(id, looter, POOL, itempoints, link)
	if not id or looter == L["Bank"] then return end
	self:AdjustDKPPoints(looter, looter, POOL, nil, itempoints)
end
