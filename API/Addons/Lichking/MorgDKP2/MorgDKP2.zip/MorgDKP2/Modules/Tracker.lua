local mod = MorgDKP2:NewModule("Tracker", "AceEvent-3.0", "AceTimer-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.Tracker
local media = LibStub("LibSharedMedia-3.0", true)
local BB = LibStub("LibBabble-Boss-3.0"):GetLookupTable()

local mdkp = MorgDKP2
mod.modName = "Tracker"

local fmt = string.format
local tinsert = table.insert
local tsort   = table.sort
local tremove = table.remove
local tostring = tostring 
local lower = string.lower
local gsub = string.gsub
local sub = string.sub
local floor = math.floor
local Player = UnitName("player")
local db

--statics
StaticPopupDialogs["BossAttempt2"] = {
	text = TEXT(L["Record boss attempt for %s?"]),
	button1 = TEXT(YES),
	button2 = TEXT(NO),
	OnAccept = function()
		mod:CustomEvent()
	end,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1,
}

local IgnoreMobs = {
	[L["Son of Flame"]] = true,
	[L["Onyxian Whelp"]] = true,
	[L["Kil'rek"]] = true,
	[L["Amani Dragonhawk Spirit"]] = true,
}

local defaults = { 
	profile = {
		runrewardtime = 1800,
   		savekilltimes = true,
   		killtimes = {[1] = {}, [2] = {}, [3] = {}, [4] = {}},
   	},
}

local options = {
		type = "group",
		handler = mod,
		name = LL["DKP Tracking"],
		desc = LL["Core of all MorgDKP2 raid tracking features. \nCan not be disabled."],
		order = 100,
		args = {
			head = {
				type = "header",
				name = LL["General options"],
				order = 10
			},
			usestart = {
				type = "toggle",
				name = LL["Start Event"],
				desc = LL["Use start event when raid begins."],
				get = function() return mdkp.db.profile.startrun end,
				set = function(info, v) mdkp.db.profile.startrun = v end,
				order = 100
			},	
			onerun = {
				type = "toggle",
				name = LL["Single run event"],
				desc = LL["Use one event for entire raid.  Boss kills will not be tracked separately."],
				get = function() return mdkp.db.profile.OneEvent end,
				set = function(info, v) mdkp.db.profile.OneEvent = v end,
				order = 105
			},
			eqdkpplus = {
				type = "toggle",
				name = LL["Eqdkp+ event format"],
				desc = LL["Remove the ' character from any event names because eqdkp+ is dumb."],
				get = function() return mdkp.db.profile.eqdkp end,
				set = function(info, v) mdkp.db.profile.eqdkp = v end,
				order = 110
			},
			dkplisten = {
				type = "toggle",
				name = LL["DKP listener"],
				desc = LL["When you are in a tracked zone you will track DKP but you will not get the loot popup window or link to the raid.  You will act like a backup raidlog."],
				get = function() return mdkp.db.profile.dkplistener end,
				set = function(info, v) mdkp.db.profile.dkplistener = v end,
				order = 115
			},
			ctrtexport = {
				type = "toggle",
				name = LL["CTRT format"],
				desc = LL["Use CTRT export format for raid exports."],
				get = function() return mdkp.db.profile.ctrtformat end,
				set = function(info, v) 
							mdkp.db.profile.ctrtformat = v 
							if v and mdkp.db.profile.guildlaunch then mdkp.db.profile.guildlaunch = nil end
				end,
				order = 116
			},
			guildlaunchexport = {
				type = "toggle",
				name = LL["Guildlaunch format"],
				desc = LL["Use guildlaunch export format for raid exports."],
				get = function() return mdkp.db.profile.guildlaunch end,
				set = function(info, v) 
							mdkp.db.profile.guildlaunch = v 
							if v and mdkp.db.profile.ctrtformat then mdkp.db.profile.ctrtformat = nil end
				end,
				order = 117
			},
			useevents = {
				type = "toggle",
				name = LL["Events for DKP changes"],
				desc = LL["Use events for DKP changes instead of database adjustments."],
				get = function() return mdkp.db.profile.dkpevents end,
				set = function(info, v) mdkp.db.profile.dkpevents = v end,
				order = 118
			},
			sarth = {
				type = "toggle",
				name = LL["Sartharion minibosses"],
				desc = LL["Trigger events for Sartharion minibosses."],
				get = function() return mdkp.db.profile.sarthextra end,
				set = function(info, v) mdkp.db.profile.sarthextra = v end,
				order = 119
			},
			bank = {
				type = "toggle",
				name = LL["Bank character"],
				desc = LL["Use a bank character in raids."],
				get = function() return mdkp.db.profile.bank end,
				set = function(info, v) mdkp.db.profile.bank = v end,
				order = 120
			},
			killtimes = {
				type = "toggle",
				name = LL["Remember kill times"],
				desc = LL["Store your best kill times for bosses."],
				get = function() return mod.db.profile.savekilltimes end,
				set = function(info, v) mod.db.profile.savekilltimes = v end,
				order = 121
			},
			head2 = {
				type = "description",
				name = "",
				order = 122
			},
			rewardtime = {
				type = "range",
				name = LL["Attendance reward"],
				desc = LL["Minimum time to add member to raid and award run DKP."],
				get = function() return floor(mod.db.profile.runrewardtime / 60) end,
				set = function(info, v) 
						mod.db.profile.runrewardtime = floor(v * 60) 
						mod:StopAttEvent()
						mod:StartAttEvent()
				end,
				min = 0, 
				max = 120, 
				step = 1,
				order = 124
			},
			newdkp = {
				type = "range",
				name = LL["New member start DKP"],
				desc = LL["DKP which new members to the database receive."],
				get = function() return mdkp.db.profile.newdkp end,
				set = function(info, v) mdkp.db.profile.newdkp = v end,
				min = 0, 
				max = 200, 
				step = 1,
				order = 125
			},
			newdkpname = {
				type = "input",
				name = LL["New member DKP event"],
				desc = LL["Format of new member DKP event name."],
				get = function() return mdkp.db.profile.newdkpname end,
				set = 	function(info, v) if v then mdkp.db.profile.newdkpname = v end end,
				hidden = function() return mdkp.db.profile.newdkp == 0 end,
				order = 130
			},
			head1 = {
				type = "header",
				name = LL["Shortcuts"],
				order = 200
			},
			startrd = {
				type = "execute",
				name = LL["Start Raid"],
				desc = LL["Starts a new raid."],
				func = function() mod:BeginRaid() end,
				disabled = function() return not mod:IsEnabled() or mdkp.db.profile.InRaid end,
				order = 201
			},
			endrd = {
				type = "execute",
				name = LL["End Raid"],
				desc = LL["Finalizes the current raid."],
				func = function() mod:ShowEndRaidFrame() end,
				disabled = function() return not mod:IsEnabled() or not mdkp.db.profile.InRaid end,
				order = 202
			},
			runbonus = {
				type = "execute",
				name = LL["Export Raids"],
				desc = LL["Exports current raid(s) data for import into website."],
				func = function() mod:ExportRaids() end,
				disabled = function() return not mod:IsEnabled() end,
				order = 203
			},
			raidtracker = {
				type = "execute",
				name = LL["Raid Tracker"],
				desc = LL["Opens the raidtracker interface."],
				func = function() 
						local raidtracker = mdkp:GetModule("RaidTracker", true)
						if raidtracker then raidtracker:OpenFrame() end
				 end,
				disabled = function() return not mod:IsEnabled() or not mdkp.db.profile.moduleON.RaidTracker end,
				order = 205
			},
			
		},
}


function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return nil
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("Tracker", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
	db.moduleON["Tracker"] = true
	if db.InRaid then self:StartAttEvent() end
	self.killed = {}
	self.updateframe = nil
	
	--events
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED", "CombatLogEvent")
	self:RegisterEvent("CHAT_MSG_MONSTER_YELL", "HostileYell")
	self:RegisterEvent("CHAT_MSG_MONSTER_EMOTE", "HostileEmote")
	
	self:TogglePlayerDies(db.attemptmode)
	
end

function mod:OnDisable()
	self:StopAttEvent(self.timer)
	db.moduleON["Tracker"] = nil 
end

function mod:StopAttEvent()
	self:CancelTimer(self.timer, true)
	self.timer = nil
end

function mod:StartAttEvent()
	self:debug("attendance check ON")
	if db.InRaid then self.timer = self:ScheduleRepeatingTimer("CheckAttendance", 60) end
end

function mod:CombatLogEvent(_, timestamp, eventtype, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags, ...)
	if not db.InRaid then return end
	--self:debug("Combat event.."..eventtype..","..(srcName or "nil")..","..(srcFlags or "nil")..","..(dstName or "nil")..","..(dstFlags or "nil"))
	if eventtype == "UNIT_DIED" or eventtype == "UNIT_DESTROYED" then self:HostileDeath(dstName) end
end

function mod:HostileDeath(mobName)
	--self:debug("Kill..."..mobName)
	if UnitInRaid(mobName) then return end
	local killTime = time()
	local RAID = db.raidnum
	if mobName then
  		if not IgnoreMobs[mobName] and RAID > 0 then db.raidlog.lastmob = mobName end
 		local Boss
   		if mobName == L["Romulo"] or mobName == L["Julianne"] then 
   			Boss = L["Romulo & Julianne"]
 			self.killed[Boss] = self.killed[Boss] + 1 
  			if self.killed[Boss] < 4 or (RAID > 0 and db.raidlog[RAID].lastboss == Boss) then return end
  		elseif mobName == BB["Essence of Anger"] then Boss = BB["Reliquary of Souls"]
  		elseif mobName == BB["Lady Sacrolash"] or mobName == BB["Grand Warlock Alythess"] then
  			Boss = BB["Eredar Twins"]
  			self.killed[Boss] = self.killed[Boss] + 1
  			if self.killed[Boss] < 2 then return end
  		elseif mobName == BB["Gathios the Shatterer"] then
  			Boss = BB["Illidari Council"]
  		elseif mobName == BB["Kalecgos"] or mobName == BB["Sathrovarr the Corruptor"] then
  			Boss = BB["Kalecgos"]
  			if not self.killed[Boss] then self.killed[Boss] = 1
  			else self.killed[Boss] = self.killed[Boss] + 1 end
  			if self.killed[Boss] < 2 then return end
  		elseif mobName == BB["Thane Korth'azz"] or mobName == BB["Sir Zeliek"] or mobName == BB["Lady Blaumeux"] or mobName == BB["Baron Rivendare"] then 
   			Boss = BB["The Four Horsemen"]
 			if not self.killed[Boss] then self.killed[Boss] = 0 end
 			self.killed[Boss] = self.killed[Boss] + 1 
  			if self.killed[Boss] < 4 or (RAID > 0 and db.raidlog[RAID].lastboss == Boss) then return end
  		elseif mobName == BB["Steelbreaker"] or mobName == BB["Stormcaller Brundir"] or mobName == BB["Runemaster Molgeim"] then 
   			Boss = BB["The Iron Council"]
 			if not self.killed[Boss] then self.killed[Boss] = 0 end
 			self.killed[Boss] = self.killed[Boss] + 1 
  			if self.killed[Boss] < 3 or (RAID > 0 and db.raidlog[RAID].lastboss == Boss) then return end
  		elseif mobName == BB["Icehowl"] then 
   			Boss = BB["The Beasts of Northrend"]
 		elseif mobName == BB["Eydis Darkbane"] then 
   			Boss = BB["The Twin Val'kyr"]
 		elseif mobName == BB["Prince Valanar"] then 
   			Boss = BB["Blood Princes"]
   		else
  			if not mdkp.ZoneBosses[db.menuzone] then return end
  			for _, bossname in pairs(mdkp.ZoneBosses[db.menuzone]) do
  				if mobName == bossname then Boss = mobName break end
  			end
  		end
  		if Boss then 
  			if not db.sarthextra and (Boss == BB["Shadron"] or Boss == BB["Tenebron"] or Boss == BB["Vesperon"] or Boss == BB["Saviana Ragefire"] or Boss == BB["Baltharus the Warborn"] or Boss == BB["General Zarithrian"]) then return end
			local bossformat = self:GetBossFormat()
 			local eventname = self:GetEventName(Boss, bossformat)
  			self:LogBossKill(killTime, eventname, nil, Boss) 
  			mdkp.itemrecorded = {}
  		end
  	end
end

function mod:HostileYell()
	--self:debug("YELL")
	if not db.InRaid then return end
	local killTime = time()
  	local bossformat = self:GetBossFormat()
 	if arg1 == L["Impossible! Stay your attack, mortals... I submit! I submit!"] then	--majordomo
  		local Boss = BB["Majordomo Executus"]
  		local eventname = self:GetEventName(Boss, bossformat)
 		self:LogBossKill(killTime, eventname, nil, Boss)
  	elseif arg1 == L["Stay your arms! I yield!"] then	--Thorim
  		local Boss = BB["Thorim"]
  		local eventname = self:GetEventName(Boss, bossformat)
 		self:LogBossKill(killTime, eventname, nil, Boss)
 	elseif arg1 == L["It would appear that I've made a slight miscalculation. I allowed my mind to be corrupted by the fiend in the prison, overriding my primary directive. All systems seem to be functional now. Clear."] then
  		local Boss = BB["Mimiron"]
  		local eventname = self:GetEventName(Boss, bossformat)
 		self:LogBossKill(killTime, eventname, nil, Boss)
  	elseif arg1 == L["His hold on me dissipates. I can see clearly once more. Thank you, heroes."] then	--Freya
  		local Boss = BB["Freya"]
  		local eventname = self:GetEventName(Boss, bossformat)
 		self:LogBossKill(killTime, eventname, nil, Boss)
 	elseif arg1 == L["I... I am released from his grasp... at last."] then	--Hodir
  		local Boss = BB["Hodir"]
  		local eventname = self:GetEventName(Boss, bossformat)
 		self:LogBossKill(killTime, eventname, nil, Boss)
 	elseif arg1 == L["Perhaps it is your imperfection that which grants you free will. That allows you to persevere against cosmically calculated odds. You prevailed where the Titans' own perfect creations have failed."] then	--Algalon
  		local Boss = BB["Algalon the Observer"]
  		local eventname = self:GetEventName(Boss, bossformat)
 		self:LogBossKill(killTime, eventname, nil, Boss)
 	elseif arg1 == L["Don't say I didn't warn ya, scoundrels! Onward, brothers and sisters!"] or arg1 == L["The Alliance falter. Onward to the Lich King!"] then	--Gunship battle
  		local Boss = BB["Icecrown Gunship Battle"]
  		local eventname = self:GetEventName(Boss, bossformat)
 		self:LogBossKill(killTime, eventname, nil, Boss)
 	elseif arg1 == L["I AM RENEWED! Ysera grant me the favor to lay these foul creatures to rest!"] then	--Valithria Dreamwalker
  		local Boss = BB["Valithria Dreamwalker"]
  		local eventname = self:GetEventName(Boss, bossformat)
 		self:LogBossKill(killTime, eventname, nil, Boss)
 	elseif arg1 == L["A shallow and tragic victory. We are weaker as a whole from the losses suffered today. Who but the Lich King could benefit from such foolishness? Great warriors have lost their lives. And for what? The true threat looms ahead - the Lich King awaits us all in death."] then
  		local Boss = BB["Faction Champions"]
  		local eventname = self:GetEventName(Boss, bossformat)
 		self:LogBossKill(killTime, eventname, nil, Boss)
 	elseif arg1 == L["What devil art thou, that dost torment me thus?"] then	--R&J start
   		self.killed[L["Romulo & Julianne"]] = 0
   	elseif arg1 == L["These are the hallmarks..."] then
   		self.killed[BB["Eredar Twins"]] = 0
   	elseif arg1 == L["No longer will I be a slave to Malygos! Challenge me and you will be destroyed!"] then	--Kalecgos start
   		self.killed[BB["Kalecgos"]] = 0
  	elseif arg1 == L["The first kill goes to me! Anyone care to wager?"] then	--4 horsemen start
   		self.killed[BB["The Four Horsemen"]] = 0
  	elseif arg1 == L["You will not defeat the Assembly of Iron so easily, invaders!"] then	--Iron Council start
   		self.killed[BB["The Iron Council"]] = 0
  	elseif arg1 == L["The time is now! Leave none standing! "] then self:ChangeLootMethod("freeforall") 	--vashj P2
  	elseif arg1 == L["You may want to take cover. "] then self:ChangeLootMethod("master") 			--vashj P3
  	elseif arg1 == L["The Legion's final conquest has begun! Once again the subjugation of this world is within our grasp. Let none survive!"] then self:ChangeLootMethod("master") 	--rage
  	elseif arg1 == L["You are defenders of a doomed world! Flee here, and perhaps you will prolong your pathetic lives!"] then self:ChangeLootMethod("master") 				--anatheron
  	elseif arg1 == L["Cry for mercy! Your meaningless lives will soon be forfeit!"] then self:ChangeLootMethod("master") 									--kazrogal
  	elseif arg1 == L["Abandon all hope! The Legion has returned to finish what was begun so many years ago. This time, there will be no escape!"] then self:ChangeLootMethod("master") 	--azgalore
  	elseif arg1 == L["Isn't it beautiful? I call it the magnificent aerial command unit!"] then self:ChangeLootMethod("freeforall") 	--Mimiron Aerial Command Unit
  	elseif arg1 == L["Preliminary testing phase complete. Now comes the true test!"] then self:ChangeLootMethod("master") 	--Mimiron Final stage
  	end
end

function mod:GetBossFormat()
	local bossformat
 	local eventnaming = self:GetModuleRef("Eventnaming")
	if eventnaming then _, _, bossformat = eventnaming:GetEventFormat() 
	else bossformat = "<boss>" end
	return bossformat
end

function mod:HostileEmote()
	if not db.InRaid then return end
	if  arg1 == L["The halls of Karazhan shake, as the curse binding the doors of the Gamesman's Hall is lifted."]  then	--chess
  		local killTime = time()
 		local Boss = BB["Chess Event"]
 		local bossformat = self:GetBossFormat()
 		local eventname = self:GetEventName(Boss, bossformat)
		self:LogBossKill(killTime, eventname, nil, Boss)
	end
end

function mod:TogglePlayerDies(switch)
	if switch then self:RegisterEvent("PLAYER_DEAD", "LeaderDied")
	else self:UnregisterEvent("PLAYER_DEAD") end
end

function mod:LeaderDied()
	if not db.InRaid then return end
	StaticPopup_Show ("BossAttempt2", db.custom)
end

function mod:BeginRaid(frame, ZoneName, difficulty)
	self:debug("Begin raid")
	if not self:IsRaided() then return end
	--self:RequestLeader()
	local StartDate = time()
	if not ZoneName then ZoneName = GetInstanceInfo() end
	local Startname, Runname, Startnote, Runnote, startformat, trashformat
	
	--initialise new raid database
	if not db.raidnum then db.raidnum = 0 end
	db.raidnum = db.raidnum + 1
	local raidnum = db.raidnum
	if not db.eqDKP or not db.eqDKP[db.raid] then
		db.raidnum = db.raidnum - 1
		self:out(fmt(LL["Sorry %s is an invalid database pool.  Please choose a correct one or export your DKP from your website."], db.raid))
		return 
	end
	db.raidlog[raidnum] = { }
	db.raidlog[raidnum].eqdkp = db.eqDKP[db.raid].eqDKPsite
	db.raidlog[raidnum].pool = db.raid
	db.raidlog[raidnum].prefix = db.eqDKP[db.raid].prefix
	db.raidlog[raidnum].playerinfo = { }
	db.raidlog[raidnum].join = { }
	db.raidlog[raidnum].leave = { }
	db.raidlog[raidnum].bosskills = { }
	db.raidlog[raidnum].loot = { }
	db.raidlog[raidnum].zone = ZoneName
	db.raidlog[raidnum].raidstart = StartDate
	db.raidlog[raidnum].dkptype = db.currDKP
	db.raidlog[raidnum].queries = {}
	db.raidlog.attendancedone = {}
	db.raidlog.lastboss = nil
	if not db.raidlog.dkpevents then db.raidlog.dkpevents = { } end
	if not db.raidlog.aliases then db.raidlog.aliases = { } end
	db.InRaid = true
	db.OneEventNote = nil
	db.instancedifficulty = difficulty or self:GetDifficulty()

	--clear player received loot flag
	for name, _ in pairs(db.info) do
		db.info[name].raidloot = 0
	end
	
	--update gear etc
	local core = self:GetModuleRef("CoreModule")
	if core then core:Scan() end 
		
	--module setup
	local dkpovertime = self:GetModuleRef("DKPovertime")
	if dkpovertime then dkpovertime:AtRaidStart() end
	local eventnaming = self:GetModuleRef("Eventnaming")
	if eventnaming then startformat, trashformat, _ = eventnaming:GetEventFormat() 
	else 
		startformat = "<zone> <diff> Start"
		trashformat = "<zone> <diff> Run"
	end
	
	--menu data
	db.raidstart = date("%m/%d %H:%M:%S", StartDate)
	db.raidend = L["PENDING"]
	db.raidexport = L["PENDING"]
	
	--start event
	if db.startrun then
		Startname = self:GetEventName(nil, startformat, ZoneName)
		self:LogBossKill(StartDate, Startname, 1, Startname, nil, 1) 
	end
	
	local wait = self:GetModuleRef("Waitlist")
	if wait then wait:AtRaidStart(StartDate, ZoneName, Startname) end
	local lootframe = self:GetModuleRef("Lootframe")
	if lootframe then 
		lootframe.AwardBuffer = {}
		lootframe.AwardIndex = 1
	end
	
	--run event
	Runname = self:GetEventName(nil, trashformat, ZoneName)
	self:LogBossKill(StartDate, Runname, 1, Runname, 1, 2) 
	
	--schedule attendance check
	if not self.timer then
		self.timer = self:ScheduleRepeatingTimer("CheckAttendance", 60)
	end
	
	--add attendess to raidlog if not already added
	local attendees = {}
	local counter = 0
	for name in pairs(mdkp.roster) do
    		local classtrue, englishclass = UnitClass(name)
		if not db.raidlog[raidnum].playerinfo[name] then 
			db.raidlog[raidnum].playerinfo[name] = { } 
			db.raidlog[raidnum].playerinfo[name].class = classtrue
			db.raidlog[raidnum].playerinfo[name].race = UnitRace(name) 
			db.raidlog[raidnum].playerinfo[name].level = UnitLevel(name) 
			db.raidlog[raidnum].playerinfo[name].guild = GetGuildInfo(name) 
		end
		db.raidlog[raidnum].join[name] = StartDate
		counter = counter + 1
		self:PlayerinDB(name, englishclass)
	end
	if db.bank then 
		db.raidlog[raidnum].playerinfo[L["Bank"]] = { } 
		db.raidlog[raidnum].join[L["Bank"]] = StartDate
		self:PlayerinDB(L["Bank"])
		self:LogBossKill(StartDate, L["Bank"], 1, L["Bank"]) 
	end
	if db.raidlog.new and #db.raidlog.new > 0 then
		local new = {}
		self:CopyTable(db.raidlog.new, new)
		self:AddNewMemberDKPChange(new)
		db.raidlog.new = {}
	end
	
	if db.currDKP == "SKSotC" then
		local currDKP = self:GetModuleRef(db.currDKP)
		if currDKP then currDKP:AtRaidStart() end
	end
	
	--start sync event
	local sync = self:GetModuleRef("Syncing")
	if sync then sync:AtRaidStart() end
	
	if frame then self:Updatetooltipdata(frame) end
	local raidtracker = self:GetModuleRef("RaidTracker")
	if raidtracker then raidtracker:ForceRaidUpdate() end
end

function mod:EndRaid(frame)
	self:debug("End Raid")
	local db = mdkp.db.profile
	if not db.InRaid then self:out(LL["No current raid exists."]) return end
	local raidnum = db.raidnum
	local EndTime = time()
	
	--get current state and turn on core so modules process properly
	local Core = mdkp:GetModule("CoreModule", true)
	local active = Core:IsEnabled()
	if not active then 
		mdkp:EnableModules(true) 
		mdkp:ToggleLDBFuStatus(true)
	end
		
	--end raid flags
	db.raidend = date("%m/%d %H:%M:%S", EndTime)
	db.InRaid = nil
	db.raidlog[raidnum].raidend = EndTime
	
	--clear raid values
	db.raidlog.attendancedone = {}
	db.custom = L["NEW"]
	db.raidlog.new = {}
	
	--onevent?
	if db.OneEvent then
		local eventnum = self:GetEventID(2)
		if not db.OneEventNote then db.OneEventNote = "Unknown" end
		db.raidlog[raidnum].bosskills[eventnum].note = db.OneEventNote
	end
	
	--module processing
	local wait = self:GetModuleRef("Waitlist")
	if wait then wait:AtRaidEnd() end
	local dkpovertime = self:GetModuleRef("DKPovertime")
	if dkpovertime then dkpovertime:AtRaidEnd() end
	local sync = self:GetModuleRef("Syncing")
	if sync then sync:AtRaidEnd() end
	
	--cancel attendance check
	self:StopAttEvent()
	
	counter = 0
	if mdkp.roster then
		for name in pairs(mdkp.roster) do
    			db.raidlog[raidnum].leave[name] = EndTime
			counter = counter + 1
		end
		self:out(fmt(LL["Removed %s raid attendees."], counter))
	end
	if frame then self:Updatetooltipdata(frame) end
	self:ToggleFrameUpdate("TooltipLDB", true)
	if mdkp.querytooltips["listdkp"] then self:ToggleFrameUpdate("listdkp", true) end
	
	if db.currDKP == "SKSotC" then
		local currDKP = self:GetModuleRef(db.currDKP)
		if currDKP then currDKP:AtRaidEnd() end
	end
	
	--turn off core if was off
	if not active then 
		mdkp:EnableModules() 
		mdkp:ToggleLDBFuStatus() 
	end
	local raidtracker = self:GetModuleRef("RaidTracker")
	if raidtracker then raidtracker:ForceRaidUpdate() end
end

function mod:ShowEndRaidFrame(frame, DIRECT)
	self:debug("End raid frame")
	local db = mdkp.db.profile
	local id = self:GetEventID(2)
	local runname = db.raidlog[db.raidnum].bosskills[id].note
	local attendees = {}
	for name, jointime in pairs(db.raidlog[db.raidnum].join) do
		if not db.raidlog.attendancedone or not db.raidlog.attendancedone[name] then
			table.insert(attendees, name)
		end
	end
	if DIRECT then self:AddandEnd(frame, attendees) return end
	
	if not self.frame then self.frame = self:CreateAttendanceFrame(frame) end
	local f = self.frame
	f.endraid:SetText(fmt(LL["End %s"], runname))
	local width, height = 100, 50
	
   	local num = #attendees
	if num > 0 then
		f.endraid2:SetText(fmt(LL["and add these attendees < %s min?"], self.db.profile.runrewardtime/60))
   		f.endraid2:Show()
   		attendees = self:ArraytoString(attendees)
		f.attends:SetText(attendees)
		f.attends:SetWidth(85)
		f.attends:Show()
   		height = 100 + num * db.media.fontsize
		width = f.endraid2:GetStringWidth() + 30
		f.yesadd:Show()
   	else
		f.endraid:SetText(f.endraid:GetText() .. "?")
		width = f.endraid:GetStringWidth() + 30
		f.attends:Hide()
   		f.endraid2:Hide()
		f.yesadd:Hide()
   	end
	f:SetHeight(height)
	f:SetWidth(width)
	f:Show()
end

function mod:FillDKPChanges()
	local temptable = {}
	local temptable2 = {}
	local name
	local started
	if not db.raidlog.dkpevents then return end
	
	if not db.dkpevents then
		for pool, data in pairs(db.raidlog.dkpevents) do
			for index, changes in pairs(data) do
				if changes.addtype == "individual" then
					name = self:CheckforAlias(changes.name, pool)
					self:PointsPoolExists(name, pool)
					if not temptable[changes.event] then temptable[changes.event] = {} end
					if not temptable[changes.event][name] then temptable[changes.event][name] = {["value"] = 0, ["eqdkp"] = changes.eqdkp, ["pool"] = pool, ["prefix"] = changes.prefix} end
					temptable[changes.event][name].value = temptable[changes.event][name].value + changes.value
				elseif changes.addtype == "Group" then
					for _, name in pairs(changes.members) do
						name = self:CheckforAlias(name, pool)
						self:PointsPoolExists(name, pool)
						if not temptable[changes.event] then temptable[changes.event] = {} end
						if not temptable[changes.event][name] then temptable[changes.event][name] = {["value"] = 0, ["eqdkp"] = changes.eqdkp, ["pool"] = pool, ["prefix"] = changes.prefix} end
						temptable[changes.event][name].value = temptable[changes.event][name].value + changes.value
					end
				end
			end
		end
		for event, data in pairs(temptable) do
			started = nil
			for name, eventdata in pairs(data) do
				if not started then
					tinsert(temptable2, { 	name = "Group", 
								value = eventdata.value, 
								members = {[1] = name},
								eqdkp = eventdata.eqdkp,
								prefix = eventdata.prefix,
								pool = eventdata.pool,
								addtype = "Group",
								event = event})
					started = true
				elseif not self:AddedtoExisting(name, eventdata, temptable2, event) then
					tinsert(temptable2, { 	name = "Group", 
								value = eventdata.value, 
								members = {[1] = name},
								eqdkp = eventdata.eqdkp,
								prefix = eventdata.prefix,
								pool = eventdata.pool,
								addtype = "Group",
								event = event})
				end
			end 
		end
		for _, group in pairs(temptable2) do
			tsort(group.members)
		end
	end
	for pool, data in pairs(db.raidlog.dkpevents) do
		for index, changes in pairs(data) do
			if changes.addtype == "Decay" then
				for key, name in pairs(changes.members) do
					name = self:CheckforAlias(name, pool)
					self:PointsPoolExists(name, pool)
					local value = 0 - (floor((db.info[name][pool].points * changes.value/100) + 0.5))
					tinsert(temptable2, { 	name = name, 
								value = value, 
								members = {[1] = name},
								eqdkp = changes.eqdkp,
								prefix = changes.prefix,
								pool = pool,
								addtype = "individual",
								event = changes.event})
				end
			end
		end
	end
	return temptable2
end

function mod:AddedtoExisting(name, eventdata, dkpchange, event)
	for _, group in pairs(dkpchange) do
		if eventdata.value == group.value and event == group.event and eventdata.eqdkp == group.eqdkp and eventdata.prefix == group.prefix then
			tinsert(group.members, name)  
			return true
		end
	end
	return nil 
end

function mod:ExportRaids(frame) 
	self:OutputRaid(db.raidlog, nil, frame)
	db.raidexport = L["COMPLETED"]
	if frame then 
		self.updateframe = frame
		self:Updatetooltipdata(frame)
	else
		self:ToggleFrameUpdate("TooltipLDB")
	end
end

function mod:ClearRaidDB(skip)
	if db.InRaid then self:EndRaid() end
	db.raidlog = {}
	db.raidnum = 0
	db.raidstart = L["PENDING"]
	db.raidend = L["PENDING"]
	db.raidexport = L["PENDING"]
	db.raidlog.dkpevents = {}
	db.raidlog.aliases = {}
	db.InRaid = nil
	self:out(L["Cleared the MorgDKP2 raid database."])
	if not skip then self:Updatetooltipdata(self.updateframe) end
	self.updateframe = nil
	local raidtracker = self:GetModuleRef("RaidTracker")
	if raidtracker then raidtracker:ForceRaidUpdate() end
end

function mod:OutputRaid(raidlog, raidid)
	self:debug("Export Raid")
	if db.guildlaunch then self:OutputGuildLaunchRaid(raidlog, raidid) return
	elseif db.ctrtformat then self:OutputCTRTFormat(raidlog, raidid) return end
	local DKPChanges = self:FillDKPChanges()
	local link = "<MorgDKP2><version>".. mdkp.webversion .. "</version>"
	if raidlog.aliases then
		link = link.."<Aliases>"
		local index = 1
		for pool, data in pairs(raidlog.aliases) do
			tsort(data, function (a, b) return a.alt < b.alt end)
			for _, data2 in pairs(data) do
				link = link .."<key".. index ..">"	
				link = link .."<alt>".. data2.alt .."</alt>"
				link = link .."<main>".. data2.main .."</main>"
				link = link .."<eqdkp>".. data2.eqdkp .."</eqdkp>"
				link = link .."<pool>".. pool .."</pool>"
				link = link .."<prefix>".. ((db.eqDKP[pool] and db.eqDKP[pool].prefix) or "ERROR") .."</prefix>"
				link = link .."<action>".. data2.action .."</action>"
				link = link .."</key".. index ..">"
				index = index + 1
			end
		end
		link = link.."</Aliases>"
	end
	if DKPChanges and not db.dkpevents then
		link = link.."<DKPChanges>"
		for key, data in pairs(DKPChanges) do
			link = link .."<key".. key ..">"	
			link = link .."<name>".. data.name .."</name>"
			link = link .."<value>".. data.value .."</value>"
			link = link .."<eqdkp>".. data.eqdkp .."</eqdkp>"
			link = link .."<prefix>".. data.prefix .."</prefix>"
			link = link .."<pool>".. data.pool .."</pool>"
			link = link .."<event>".. data.event .."</event>"
			link = link .."<addtype>".. data.addtype .."</addtype>"
			link = link .."<members>"
			for key2, val2 in pairs(data.members) do
				link = link .."<key".. key2 ..">" .. val2 .. "</key".. key2 ..">"
			end
			link = link .."</members>"
			link = link .."</key".. key ..">"
		end
		link = link .."</DKPChanges>"
	end
	link = link .."<Raids>"
	if db.raidnum > 0 then
		for raidindex = 1, db.raidnum do
			if not raidid or raidindex == raidid then
				local raiddata = raidlog[raidindex]
				link = link .."<key".. raidindex ..">"
				link = link .."<zone>".. raiddata.zone .."</zone>"
				link = link .."<date>".. raiddata.raidstart .."</date>"
				link = link .."<eqdkp>".. raiddata.eqdkp .."</eqdkp>"
				link = link .."<pool>".. raiddata.pool .."</pool>"
				link = link .."<prefix>".. raiddata.prefix .."</prefix>"
				link = link .."<Attendees>"
				local index = 1
				for key, _ in pairs(raiddata.playerinfo) do
					link = link .."<key".. index ..">"
					link = link .."<name>".. key .."</name>"
					for key2, val2 in pairs(raiddata.playerinfo[key]) do
						link = link .."<".. key2 ..">".. val2 .."</".. key2 ..">"
					end
					link = link .."</key".. index ..">"
					index = index + 1
				end
				link = link .."</Attendees>"
				link = link .."<Bosskills>"
				for key, data in pairs(raiddata.bosskills) do
					if not db.OneEvent or (db.OneEvent and data.trash ~= 0) then
						link = link .."<key".. key ..">"
						link = link .."<name>".. data.name .."</name>"
						link = link .."<note>".. data.note .."</note>"
						link = link .."<time>".. data.time .."</time>"
						link = link .."<value>".. data.value .."</value>"
						link = link .."<trash>".. data.trash .."</trash>"
						link = link .."<attendees>"
						for key2, val2 in pairs(data.attendees) do
							link = link .."<key".. key2 ..">" .. val2 .. "</key".. key2 ..">"
						end
						link = link .."</attendees>"
						link = link .."</key".. key ..">"
					end
				end
				link = link .."</Bosskills>"
				link = link .."<Loot>"
				for key, data in pairs(raiddata.loot) do
					link = link .."<key".. key ..">"
					for key2, val2 in pairs(data) do
						link = link .."<".. key2 ..">".. val2 .."</".. key2 ..">"
					end
					link = link .."</key".. key ..">"
				end
				link = link .."</Loot>"
				link = link .."</key".. raidindex ..">"
				raidindex = raidindex + 1
			end
		end
	end
	link = link .."</Raids>"
	link = link .."</MorgDKP2>"	
	self:DKPOutFrame(link)
end

function mod:OutputGuildLaunchRaid(raidlog, raidid)
	self:debug("Export Guildlaunch Raid")
	--DOES NOT CURRENTLY SUPPORT ALIASES/DKPCHANGES/MULTIPLE RAID EXPORT AND IS NOT TESTED BY ME!
	if not raidid then return end
	local link = "<RaidInfo><version>2.2</version>"
	if db.raidnum > 0 then
		for raidindex = 1, db.raidnum do
			if not raidid or raidindex == raidid then
				local raiddata = raidlog[raidindex]
				link = link .."<start>".. raiddata.raidstart .."</start>"
				link = link .."<end>".. raiddata.raidend .."</end>"
				link = link .."<zone>".. raiddata.zone .."</zone>"
				link = link .."<PlayerInfos>"
				local index = 1
				for key, _ in pairs(raiddata.playerinfo) do
					link = link .."<key".. index ..">"
					link = link .."<name>".. key .."</name>"
					link = link .."</key".. index ..">"
					index = index + 1
				end
				link = link .."</PlayerInfos>"
				link = link .."<Bosskills>"
				for key, data in pairs(raiddata.bosskills) do
					if not db.OneEvent or (db.OneEvent and data.trash ~= 0) then
						link = link .."<key".. key ..">"
						link = link .."<name>".. data.name .."</name>"
						link = link .."<time>".. data.time .."</time>"
						link = link .."<value>".. data.value .."</value>"
						link = link .."<attendees>"
						for key2, val2 in pairs(data.attendees) do
							link = link .."<key".. key2 ..">" .. val2 .. "</key".. key2 ..">"
						end
						link = link .."</attendees>"
						link = link .."<event_source>ManualXML</event_source>"
						link = link .."</key".. key ..">"
					end
				end
				link = link .."</Bosskills>"
				link = link .."<Join>"
				local index = 1
				for key, data in pairs(raiddata.join) do
					link = link .."<key".. index ..">"
					link = link .."<player>".. key .."</player>"
					link = link .."<time>".. data .."</time>"
					link = link .."</key".. index ..">"
					index = index + 1	
				end
				link = link .."</Join>"
				link = link .."<Leave>"
				local index = 1
				for key, data in pairs(raiddata.leave) do
					link = link .."<key".. index ..">"
					link = link .."<player>".. key .."</player>"
					link = link .."<time>".. data .."</time>"
					link = link .."</key".. index ..">"
					index = index + 1	
				end
				link = link .."</Leave>"
				link = link .."<Loot>"
				for key, data in pairs(raiddata.loot) do
					link = link .."<key".. key ..">"
					link = link .."<ItemName>".. data.ItemName .."</ItemName>"
					link = link .."<Count>1</Count>"
					link = link .."<Player>".. data.Player .."</Player>"
					link = link .."<Time>".. data.Time .."</Time>"
					link = link .."<Zone>".. data.Zone .."</Zone>"
					link = link .."<Boss>".. data.Boss .."</Boss>"
					link = link .."<Costs>".. data.Costs .."</Costs>"
					link = link .."</key".. key ..">"
				end
				link = link .."</Loot>"
				--link = link .."</key".. raidindex ..">"
				--raidindex = raidindex + 1
			end
		end
	end
	link = link .."</RaidInfo>"	
	self:DKPOutFrame(link)
end

function mod:OutputCTRTFormat(raidlog, raidid)
	self:debug("Export Guildlaunch Raid")
	--DOES NOT CURRENTLY SUPPORT ALIASES/DKPCHANGES AND IS NOT TESTED BY ME!
	if not raidid then return end
	local link = "<RaidInfo><version>2.2</version>"
	if db.raidnum > 0 then
		for raidindex = 1, db.raidnum do
			if not raidid or raidindex == raidid then
				local raiddata = raidlog[raidindex]
				link = link .."<start>".. raiddata.raidstart .."</start>"
				link = link .."<end>".. raiddata.raidend .."</end>"
				link = link .."<zone>".. raiddata.zone .."</zone>"
				link = link .."<PlayerInfos>"
				local index = 1
				for key, _ in pairs(raiddata.playerinfo) do
					link = link .."<key".. index ..">"
					link = link .."<name>".. key .."</name>"
					for key2, val2 in pairs(raiddata.playerinfo[key]) do
						link = link .."<".. key2 ..">".. val2 .."</".. key2 ..">"
					end
					link = link .."</key".. index ..">"
					index = index + 1
				end
				link = link .."</PlayerInfos>"
				link = link .."<BossKills>"
				for key, data in pairs(raiddata.bosskills) do
					if not db.OneEvent or (db.OneEvent and data.trash ~= 0) then
						link = link .."<key".. key ..">"
						link = link .."<name>".. data.name .."</name>"
						link = link .."<time>".. data.time .."</time>"
						link = link .."<attendees>"
						for key2, val2 in pairs(data.attendees) do
							link = link .."<key".. key2 ..">" .. val2 .. "</key".. key2 ..">"
						end
						link = link .."</attendees><event_source>ManualXML</event_source>"
						link = link .."<value>".. data.value .."</value>"
						link = link .."</key".. key ..">"
					end
				end
				link = link .."</BossKills><NextBoss>unused</NextBoss>"
				link = link .."<Join>"
				local index = 1
				for key, data in pairs(raiddata.join) do
					link = link .."<key".. index ..">"
					link = link .."<player>".. key .."</player>"
					link = link .."<time>".. data .."</time>"
					link = link .."</key".. index ..">"
					index = index + 1	
				end
				link = link .."</Join>"
				link = link .."<Leave>"
				local index = 1
				for key, data in pairs(raiddata.leave) do
					link = link .."<key".. index ..">"
					link = link .."<player>".. key .."</player>"
					link = link .."<time>".. data .."</time>"
					link = link .."</key".. index ..">"
					index = index + 1	
				end
				link = link .."</Leave>"
				link = link .."<Loot>"
				for key, data in pairs(raiddata.loot) do
					link = link .."<key".. key ..">"
					for key2, val2 in pairs(data) do
						if key2 ~= "ID" and key2 ~= "Icon" and key2 ~= "eqdkp" and key2 ~= "Class" and key2 ~= "SubClass" and key2 ~= "ItemLink" and key2 ~= "prefix" and key2 ~= "Quality" then
							link = link .."<".. key2 ..">".. val2 .."</".. key2 ..">"
						end
					end
					link = link .."<Count>1</Count></key".. key ..">"
				end
				link = link .."</Loot>"
				--link = link .."</key".. raidindex ..">"
				--raidindex = raidindex + 1
			end
		end
	end
	link = link .."</RaidInfo>"	
	self:DKPOutFrame(link)
end

function mod:DKPOutFrame(link)
	if not self.exportframe then
		local background = media:Fetch("background", db.media.background)
		local border = media:Fetch("border", db.media.border)
		local font = media:Fetch("font", db.media.font)
		
		self.exportframe = CreateFrame("frame", nil, UIParent)
		local f = self.exportframe
		
		f:SetFrameStrata("FULLSCREEN")
   		f:ClearAllPoints()
   		f:SetBackdrop({ bgFile = background, tile = false, tileSize = 16, edgeFile = border, edgeSize = 8, insets = { left = 6, right = 6, top = 6, bottom = 6 } })
		f:SetBackdropColor(unpack(db.media.backdropC))
		f:SetBackdropBorderColor(unpack(db.media.borderC))
		f:SetPoint("CENTER", UIParent, "CENTER")
		f:SetHeight(120)
		f:SetWidth(200)
		
		f.title = f:CreateFontString()
   		f.title:SetPoint("TOP", f, "TOP", 0, -10)
   		f.title:SetFont(font, 14)
   		f.title:SetText(LL["DKP Export"])
   		f.title:SetTextColor(unpack(db.media.borderC))
   		f.title:Show()
   	
   		f.edit = CreateFrame("EditBox", nil, f)
   		f.edit:ClearAllPoints()
   		f.edit:SetPoint("TOPLEFT", f, "TOPLEFT", 45, -30)
		f.edit:SetAutoFocus(true)
		f.edit:SetFont(font, 12)
		f.edit:SetHeight(30)
		f.edit:SetWidth(120)
		f.edit:SetBackdrop({ bgFile = background, tile = false, tileSize = 16, edgeFile = border, edgeSize = 16, insets = { left = 6, right = 6, top = 6, bottom = 6 } })
		f.edit:SetBackdropColor(unpack(db.media.backdropC))
		f.edit:SetBackdropBorderColor(unpack(db.media.borderC))
		f.edit:SetTextInsets(5, 5, 5, 5)
		f.edit:Show()
		
		f.ques = f:CreateFontString()
   		f.ques:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -15, 35)
   		f.ques:SetFont(font, 14)
   		f.ques:SetText(LL["Clear the raid database?"])
   		f.ques:Show()
   		
   		f.NO = CreateFrame("Button", nil, f, "OptionsButtonTemplate")
		f.NO:SetWidth(40)
		f.NO:SetHeight(20)
		f.NO:ClearAllPoints()
		f.NO:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -10, 10)
		f.NO:SetScript("OnClick", function(f) f:GetParent():Hide() end)
		f.NO:Show()
	
		f.NO.text = f.NO:CreateFontString()
   		f.NO.text:SetFont(font, 12)
   		f.NO.text:ClearAllPoints()
		f.NO.text:SetPoint("CENTER", f.NO, "CENTER")
		f.NO.text:SetText(LL["NO"])
		
		f.YES = CreateFrame("Button", nil, f, "OptionsButtonTemplate")
		f.YES:SetWidth(40)
		f.YES:SetHeight(20)
		f.YES:ClearAllPoints()
		f.YES:SetPoint("RIGHT", f.NO, "LEFT", -5)
		f.YES:SetScript("OnClick", function(f) f:GetParent():Hide() self:ClearRaidDB(true) end)
		f.YES:Show()
	
		f.YES.text = f.YES:CreateFontString()
   		f.YES.text:SetFont(font, 12)
   		f.YES.text:ClearAllPoints()
		f.YES.text:SetPoint("CENTER", f.YES, "CENTER")
		f.YES.text:SetText(LL["YES"])
	end
	local f = self.exportframe
	f.edit:SetText(link)
	f.edit:HighlightText()
	f:Show()
end

function mod:CustomEvent(event, skipsync)
	self:debug("Custom event")
	if not db.InRaid then 
		self:out(LL["No current raid exists."])
		return 
	end
	if not event then 
		event = db.custom
		if event == L["NEW"] then event = event .. " Event"
		else event = event .. " Attempt" end
	end
	self:LogBossKill(time(), event, 1, event, nil, 3) 
	
	--add to sync
	if not skipsync then
		local sync = self:GetModuleRef("Syncing")
		if sync then sync:CustomEvent(event) end
	end
	local raidtracker = self:GetModuleRef("RaidTracker")
	if raidtracker then raidtracker:ForceRaidUpdate() end
end

function mod:LogBossKill(killTime, Boss, notboss, Note, quiet, id, attends, dkpvalue)
	self:debug("Boss kill "..Boss.." "..Note)
	local raidnum = db.raidnum
	local POOL = db.raid
	local StrippedBoss, StrippedNote
	local counter
	if db.OneEvent and (id ~= 1 and id ~= 2) then
		if db.OneEventNote then db.OneEventNote = db.OneEventNote .. ", " .. Note
		else db.OneEventNote = Note
		end
	else
		local attendees = {}
		if not attends then
			if id ~= 2 then
				counter = 0
				for name in pairs(mdkp.roster) do
    					tinsert(attendees, name)
					counter = counter + 1
				end
				if db.bank then 
					tinsert(attendees, L["Bank"]) 
				end
			end
		else
			counter = #attends
			attendees = attends
		end
		if mdkp.db.profile.eqdkp then
			StrippedBoss = self:Removehash(Boss)
			StrippedNote = self:Removehash(Note)
		end
		local value = 0
		if dkpvalue then value = dkpvalue
		elseif db.eqDKP[POOL]["Events"][Boss] then value = db.eqDKP[POOL]['Events'][Boss].value 
		end
		table.insert(db.raidlog[raidnum].bosskills,
						{
							["name"] = StrippedBoss or Boss,
							["note"] = StrippedNote or Note,
							["time"] = killTime,
							["attendees"] = attendees,					
							["value"] = value,
							["trash"] = id or 0
						}
					)
		if not quiet then
			self:out(fmt(LL["%s recorded at %s with %s attendees."], Note, date("%I:%M:%S", killTime), counter))
			if id ~= 1 and id ~= 3 and mdkp.Starttime then
				local totaltime = killTime - mdkp.Starttime
				local time = date("%M:%S", totaltime)
				self:out(fmt(LL["%s defeated in %s!"], Note, time))
				if self.db.profile.savekilltimes then
					local difficulty = db.instancedifficulty
					local killtimes = self.db.profile.killtimes[difficulty]
					local bestkill = killtimes[Boss]
					if bestkill then
						if totaltime < bestkill then killtimes[Boss] = totaltime end
						self:out(fmt(LL["Previous best kill time: %s"], date("%M:%S", bestkill)))
					else 
						killtimes[Boss] = totaltime
					end
				end
			end
		end
		self:AwardDKP(nil, value, POOL, attendees, nil, quiet)
	end
	if not notboss then 
		db.raidlog.lastboss = Note 
		local wait = self:GetModuleRef("Waitlist")
		if wait then wait:AwardWaitlistDKP(killTime, Boss) end
	end
	if Boss == BB["Rage Winterchill"] or Boss == BB["Anetheron"] or Boss == BB["Kaz'rogal"] then self:ChangeLootMethod("group") end
	local raidtracker = self:GetModuleRef("RaidTracker")
	if raidtracker then raidtracker:ForceRaidUpdate() end
end

function mod:Removehash(event)
	event = gsub(event, "'", "")
	return event
end

function mod:ChangeLootMethod(method)
	if not self.lootmaster then self.lootmaster = Player end
	if method == "master" then SetLootMethod("master", self.lootmaster) 
  	else SetLootMethod(method) end
end

function mod:ItemRecorded(item, name)
	for _, ID in pairs(db.info[name].items) do
		if item == ID then
			return true
		end
	end
	return false
end

function mod:CreateAttendanceFrame(updateframe)
	local db = mdkp.db.profile
	local font = media:Fetch("font", db.media.font)
	local ondragstart = function(f) f:StartMoving() end
	local ondragstop =  function(f)
   					f:StopMovingOrSizing()
   					local point, _, relativePoint, x, y = f:GetPoint()
					mod.db.profile.attframe = {point = point, relpoint = relativePoint, x = x, y = y}
   				end
	local f = self:Createframe(nil, nil, nil, nil, nil, nil, "Attframe", nil, nil, nil, ondragstart, ondragstop)
	f:EnableKeyboard(1)
	f:ClearAllPoints()
	local point, relpoint, x, y
   	local db2 = self.db.profile.attframe
   	if db2 then point, relpoint, x, y = db2.point, db2.relpoint, db2.x, db2.y
   	else point, relpoint, x, y = "CENTER", "CENTER", 0, 0 end
   	f:SetPoint(point, UIParent, relpoint, x, y)
   	   		
	f.endraid = f:CreateFontString()
   	f.endraid:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -10)
   	f.endraid:SetJustifyH("LEFT")
   	f.endraid:SetFont(font, db.media.fontsize)
   	f.endraid:SetTextColor(unpack(db.media.borderC))
   	f.endraid:Show()
   	
   	f.endraid2 = f:CreateFontString()
   	f.endraid2:SetPoint("TOPLEFT", f.endraid, "BOTTOMLEFT", 10, -5)
   	f.endraid2:SetJustifyH("LEFT")
   	f.endraid2:SetFont(font, db.media.fontsize)
   	f.endraid2:SetTextColor(unpack(db.media.borderC))
   	
   	f.attends = CreateFrame("EditBox", nil, f)
	f.attends:ClearAllPoints()
	f.attends:SetMultiLine(1)
	f.attends:SetAutoFocus(nil)
	f.attends:SetPoint("TOPLEFT", f.endraid2, "BOTTOMLEFT", 20, -10)
	f.attends:SetScript("OnEscapePressed", function(f) f:ClearFocus() end)
	f.attends:SetFont(font, db.media.fontsize - 1)
	f.attends:SetTextColor(1, 1, 1)
	f.attends:SetTextInsets(3, 3, 3, 3)
	f.attends:SetBackdrop({ bgFile = media:Fetch("background", db.media.background), tile = false, tileSize = 16, edgeFile = media:Fetch("border", db.media.border), edgeSize = 8, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
	f.attends:SetBackdropColor(unpack(db.media.backdropC))
	f.attends:SetBackdropBorderColor(unpack(db.media.borderC))
   	
   	f.no = CreateFrame("Button", nil, f, "OptionsButtonTemplate")
   	f.no:SetScript("OnClick", function(f) f:GetParent():Hide() end)
   	f.no:SetWidth(40 * db.media.fontsize/8)
   	f.no:SetHeight(db.media.fontsize + 5)
   	f.no:ClearAllPoints()
   	f.no:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -10, 10)
   	f.no:Show()
   	
   	f.no.text = f.no:CreateFontString()
   	f.no.text:SetFont(font, db.media.fontsize)
   	f.no.text:ClearAllPoints()
	f.no.text:SetPoint("CENTER", f.no, "CENTER")
	f.no.text:SetText(LL["CANCEL"])
	
   	f.yes = CreateFrame("Button", nil, f, "OptionsButtonTemplate")
   	f.yes:SetScript("OnClick", function(f) f:GetParent():Hide() mod:EndRaid(updateframe) end)
   	f.yes:SetWidth(30 * db.media.fontsize/8)
   	f.yes:SetHeight(db.media.fontsize + 5)
   	f.yes:ClearAllPoints()
   	f.yes:SetPoint("RIGHT", f.no, "LEFT", -5, 0)
   	f.yes:Show()
   	
   	f.yes.text = f.yes:CreateFontString()
   	f.yes.text:SetFont(font, db.media.fontsize)
   	f.yes.text:ClearAllPoints()
	f.yes.text:SetPoint("CENTER", f.yes, "CENTER")
	f.yes.text:SetText(LL["YES"])
	
   	f.yesadd = CreateFrame("Button", nil, f, "OptionsButtonTemplate")
   	f.yesadd:SetScript("OnClick", function(f) f:GetParent():Hide() mod:AddandEnd(updateframe) end)
   	f.yesadd:SetWidth(55 * db.media.fontsize/8)
   	f.yesadd:SetHeight(db.media.fontsize + 5)
   	f.yesadd:ClearAllPoints()
   	f.yesadd:SetPoint("RIGHT", f.yes, "LEFT", -5, 0)
   	
   	f.yesadd.text = f.yesadd:CreateFontString()
   	f.yesadd.text:SetFont(font, db.media.fontsize)
   	f.yesadd.text:ClearAllPoints()
	f.yesadd.text:SetPoint("CENTER", f.yesadd, "CENTER")
	f.yesadd.text:SetText(LL["Yes & Add"])
	
   	return f
end

function mod:AddandEnd(frame, attendees)
	local db = mdkp.db.profile
	if not attendees then attendees = self:AttendtoArray(self.frame.attends) end
	if attendees then
		local id = self:GetEventID(2)
		local value = 0
		local POOL = db.raid
		if db.eqDKP[POOL] and db.eqDKP[POOL]["Events"] and db.eqDKP[POOL]['Events'][db.raidlog[db.raidnum].bosskills[id].name] then
			value = db.eqDKP[POOL]['Events'][db.raidlog[db.raidnum].bosskills[id].name].value
		end
		for num, name in pairs(attendees) do
			if not db.raidlog.attendancedone or not db.raidlog.attendancedone[name]  then
				table.insert(db.raidlog[db.raidnum].bosskills[id].attendees, name)
			end
		end
		if value then self:AwardDKP(nil, value, POOL, attendees, nil, 1) end
	end
	self:EndRaid(frame)
end

function mod:CheckAttendance()
	self:debug("Checking attendees...")
	if not db.InRaid then return end 
	local POOL = db.raid
	local raidnum = db.raidnum
	local runrewardtime = self.db.profile.runrewardtime
	local currtime = time()
	
	--get event value
	local value = 0
	local id = self:GetEventID(2)
	if db.eqDKP[POOL] and db.eqDKP[POOL]["Events"] and db.eqDKP[POOL]['Events'][db.raidlog[raidnum].bosskills[id].name] then
		value = db.eqDKP[POOL]['Events'][db.raidlog[raidnum].bosskills[id].name].value
	end
	
	--add player to run event if been here long enough
	for name, jointime in pairs(db.raidlog[raidnum].join) do
		if not db.raidlog.attendancedone[name] and not db.raidlog[raidnum].leave[name] then
			if currtime - jointime >= runrewardtime then	
				table.insert(db.raidlog[raidnum].bosskills[id].attendees, name)
				db.raidlog.attendancedone[name]  = true
				self:debug("Added "..name.." to run.")
				if value then self:AwardDKP(nil, value, POOL, {[1] = name}, nil, 1) end
			end
		end
	end
	
	--waitlist check
	local waitdone
	local wait = self:GetModuleRef("Waitlist")
	if wait then waitdone = wait:AtAttendanceCheck(value, id) end
	
	--turn off attendance event if all done
	local attdone = true
	for name, jointime in pairs(db.raidlog[raidnum].join) do
		if not db.raidlog.attendancedone[name] then attdone = nil end
	end
	if attdone and (not wait or (wait and waitdone)) then 
		self:StopAttEvent()
	end
end
