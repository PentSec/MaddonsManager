﻿local mod = MorgDKP2:NewModule("TakeBid", "AceComm-3.0", "AceSerializer-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.TakeBid

local mdkp = MorgDKP2

mod.modName = LL["TakeBid DKP"]
mod.modref = "TakeBid"

local Player = UnitName("player")
local db
local fmt = string.format
local floor = math.floor

local defaults = { 
	profile = {
		bidstep = 1,
		overbid = 50,
		minbid = 10
	},
}

local options = {
		takebiddkp = {
			type = "toggle",
			name = LL["TakeBid DKP"],
			desc = LL["Variation of Fixed DKP where when you bid take you also enter what you are willing to pay."],
			get = function() return mdkp.db.profile.modules.TakeBid end,
			set = 	function(info, v) 
					mdkp.db.profile.modules.TakeBid = not v
					mod:DKPChange(mod.modName)
			end,
			order = 30
		},
		takehead = {
			type = "header",
			name = LL["TakeBid Options"],
			hidden = function() return not mdkp.db.profile.modules.TakeBid end,
			order = 100
		},
		takebidstep = {
			type = "range",
			name = LL["Bidstep"],
			desc = LL["Changes the DKP step for TakeBid mode.  Passes this value to MorgBid2 clients."],
			get = function() return mod.db.profile.bidstep end,
			set = function(info, v) mod.db.profile.bidstep = v end,
			min = 1, 
			max = 100, 
			step = 1,
			hidden = function() return not mdkp.db.profile.modules.TakeBid end,
			order = 110
		},
		takeoverbid = {
			type = "range",
			name = LL["Overbid"],
			desc = LL["Maximum amount of DKP that members can exceed their current DKP."],
			get = function() return mod.db.profile.overbid end,
			set = function(info, v) mod.db.profile.overbid = v end,
			min = 0, 
			max = 500, 
			step = 1,
			hidden = function() return not mdkp.db.profile.modules.TakeBid end,
			order = 120
		},
		takeminbid = {
			type = "range",
			name = LL["Minimum bid"],
			desc = LL["Minimum amount of DKP that members can bid for an item."],
			get = function() return mod.db.profile.minbid end,
			set = function(info, v) mod.db.profile.minbid = v end,
			min = 0, 
			max = 100, 
			step = 1,
			hidden = function() return not mdkp.db.profile.modules.TakeBid end,
			order = 125
		},
}

function mod:GetOptions()
	return options
end

function mod:GetName()
	return mod.modName, mod.modref
end

function mod:IsDKP()
	return true
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("TakeBid", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
	db.moduleON["TakeBid"] = true
	
	self.master = {}
end

function mod:OnDisable()
	db.moduleON["TakeBid"] = nil
				
end

function mod:StartAuction(id, itempoints, queries, link, mbidtable)
	self:AtStartQuery(id, queries)
	self:SendCommMessage("MorgBid2", self:Serialize("TAKEBID", id, itempoints, queries, db.quality, self.db.profile.bidstep, self.db.profile.overbid, isrand, link, db.mbidupdating, mbidtable, self.db.profile.minbid), "RAID")
end

function mod:AtStartQuery(id, queries)
	self.master[id] = true
	if self:PlayerIncluded(queries) then self.master[id] = nil end
end

function mod:PlayerIncluded(dkp)
	for i, v in pairs(dkp) do
		if v[1].n == Player then
			return true
		end
	end
	return false
end

function mod:AddBids(itemid)
	self.master[itemid] = true 
	if mdkp.querytooltips[itemid] then
		for  i,v in pairs(mdkp.querytooltips[itemid]) do
			if v[5] then
				v[3].n = v[5]
			end
		end
	end
end

function mod:OnBidWhisper(sender, item, reply, bid)
	for i,v in ipairs(mdkp.querytooltips[item]) do
		if v[1].n == sender then
			v[2] = reply
			if reply == "TAKE" then 
				if self.master[item] then v[3].n = bid
				else 
					v[3].n = 0
					v[5] = bid
				end
			end
			break
		end
	end		
end

function mod:GetPlayerPoints(name, POOL, showearned)
	if showearned then return db.info[name][POOL].earned
	else return db.info[name][POOL].points end
end

function mod:GetItemValue(itemid, player, POOL)
	local itempoints = db.items[itemid].points
	if mdkp.querytooltips[itemid] then
		for  i,v in pairs(mdkp.querytooltips[itemid]) do
			if v[1].n == player then
				if v[2] == "TAKE" then 
					itempoints = v[3].n
				end
			end
		end
	end
	return itempoints
end

function mod:ItemRecorded(id, looter, POOL, points, itempoints, link)
	if looter == L["Bank"] then return end
	points = points - itempoints
	self:AwardItem(id, looter, POOL, points, itempoints, link)
end

function mod:ItemRebate(id, looter, POOL, itempoints, link)
	if not id or looter == L["Bank"] then return end
	self:AdjustDKPPoints(looter, looter, POOL, nil, itempoints)
end
