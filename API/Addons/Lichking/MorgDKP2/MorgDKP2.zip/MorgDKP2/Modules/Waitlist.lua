local mod = MorgDKP2:NewModule("Waitlist", "AceTimer-3.0", "LibWho-2.0")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.Waitlist

local mdkp = MorgDKP2

mod.modName = LL["Waitlist"]
mod.modref = "Waitlist"

local db
local fmt = string.format
local tinsert = table.insert
local tsort   = table.sort
local tremove = table.remove
local tostring = tostring 
local lower = string.lower
local sub = string.sub
local upper = string.upper
local gsub = string.gsub
local floor = math.floor
local find = string.find
local Player = UnitName("player")

local defaults = { 
	profile = {
		channels = {},
		spamchannel = nil,
		waitstart = 0,
		waitrun = 0,
		waitaward = nil,
		waitotime = 0,
		waitboss = 0,
		waitrewardtime = 1800,
		waitdeletetime = 600,
		waitname = "<zone> Waitlist DKP",
		waitbossname = "<boss> Waitlist DKP",
		Waitlist = {members = {}, join = {}}
	},
}

local options = {
		type = "group",
		handler = mod,
		name = LL["Waitlist"],
		desc = LL["Waitlist"],
		order = 400,
		args = {
			enable = {
				type = "toggle",
				name = LL["Enable"],
				desc = LL["Waitlist allows members to whisper you for invites and to receive DKP even if not in the actual raid."],
				get = function() return mdkp.db.profile.modules.Waitlist end,
				set = 	function(info, v) 
						mdkp.db.profile.modules.Waitlist = v
						if v then 
							mod:Enable()
							mod:debug("Enabled Waitlist")
						else
							mod:Disable()
							mdkp:debug("Disabled Waitlist")
						end
					end,
				order = 5
			},
			waitaward = {
				type = "toggle",
				name = LL["Award DKP"],
				desc = LL["Award DKP to current waitlist members"],
				get = function() return mod.db.profile.waitaward end,
				set = function(info, v) mod.db.profile.waitaward = v end,
				hidden = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 100
			},
			waitrewardtime = {
				type = "range",
				name = LL["Waitlist reward"],
				desc = LL["Minimum time to award run DKP to a waitlist member."],
				get = function() return floor(mod.db.profile.waitrewardtime / 60) end,
				set = function(info, v) mod.db.profile.waitrewardtime = floor(v * 60) end,
				min = 0, 
				max = 120, 
				step = 1,
				hidden = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 105
			},
			waitrun = {
				type = "range",
				name = LL["Waitlist run DKP"],
				desc = LL["Amount of DKP to reward after members have been on the waitlist for the current reward time."],
				get = function() return mod.db.profile.waitrun end,
				set = function(info, v) mod.db.profile.waitrun = v end,
				min = 0, 
				max = 500, 
				step = 1,
				hidden = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 110
			},
			waitstart = {
				type = "range",
				name = LL["Waitlist start DKP"],
				desc = LL["Amount of DKP to reward at raidstart."],
				get = function() return mod.db.profile.waitstart end,
				set = function(info, v) mod.db.profile.waitstart = v end,
				min = 0, 
				max = 500, 
				step = 1,
				hidden = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 115
			},
			waitboss = {
				type = "range",
				name = LL["Waitlist boss DKP"],
				desc = LL["Amount of DKP to reward to waitlist members per bosskill."],
				get = function() return mod.db.profile.waitboss end,
				set = function(info, v) mod.db.profile.waitboss = v end,
				min = 0, 
				max = 500, 
				step = 1,
				hidden = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 120
			},
			waitotime = {
				type = "range",
				name = LL["Waitlist DKP/time"],
				desc = LL["Amount of DKP to reward to waitlist members when awarding regular members DKP/time. Note: only works if you are awarding DKP/time."],
				get = function() return mod.db.profile.waitotime end,
				set = function(info, v) mod.db.profile.waitotime = v end,
				min = 0, 
				max = 500, 
				step = 1,
				hidden = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 120
			},
			waitdeltime = {
				type = "range",
				name = LL["Grace Period"],
				desc = LL["Minimum time before offline waitlist members will be removed."],
				get = function() return floor(mod.db.profile.waitdeletetime / 60) end,
				set = function(info, v) mod.db.profile.waitdeletetime = floor(v * 60) mod:StopTimer() mod:RestartTimer() end,
				min = 0, 
				max = 120, 
				step = 1,
				hidden = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 122
			},
			head = {
				type = "header",
				name = LL["Event Names"],
				hidden = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 125
			},
			waitname = {
				type = "input",
				name = LL["Waitlist event name"],
				desc = LL["Format of waitlist event names:  \n<zone> text  \nExample:  <zone> Waitlist DKP"],
				get = function() return mod.db.profile.waitname end,
				set = 	function(info, v) if v then mod.db.profile.waitname = v end end,
				hidden = function() return not mdkp.db.profile.modules.Waitlist or not mdkp.db.profile.dkpevents end,
				order = 130
			},
			waitbossname = {
				type = "input",
				name = LL["Waitlist boss event name"],
				desc = LL["Format of waitlist boss events:  \n<boss> text  \nExample:  <boss> Waitlist DKP"],
				get = function() return mod.db.profile.waitbossname end,
				set = 	function(info, v) if v then mod.db.profile.waitbossname = v end end,
				hidden = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 135
			},
			head1 = {
				type = "header",
				name = LL["Waitlist spamming"],
				hidden = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 140
			},
			dospam = {
				type = "execute",
				name = LL["Spam Waitinfo"],
				desc = LL["Spam channels with waitinfo now."],
				func = function() mod:SpamChannels(true) end,
				hidden = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 145
			},
			usespam = {
				type = "toggle",
				name = LL["Autochannel Spam"],
				desc = LL["Spam channels automatically when opening the invite tablet."],
				get = function() return mod.db.profile.spamchannel end,
				set = function(info, v) mod.db.profile.spamchannel = v end,
				hidden = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 150
			},
			spamchannel = {
		 		type = "multiselect",
		 		name = LL["Channels"],
		 		desc = LL["Channels to spam when starting invites."],
		 		get = function(info, v) 
		 				if mod.db.profile.channels[v] then return true
		 				else return nil end
		 			end,
		 		set = function(info, v) 
		 				local name = v
		 				if mod.db.profile.channels[name] then mod.db.profile.channels[name]  = nil
		 				else mod.db.profile.channels[name] = true end
		 			end,
		 		values = "GetDefaultChannels", 
				hidden = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 155
			},
			clearwaitlist = {
				type = "execute",
				name = LL["Clear Waitlist"],
				desc = LL["Clears the current wailist."],
				func = function() mod:AtRaidEnd() end,
				hidden = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 160
			},
			dospam2 = {
				type = "execute",
				name = LL["Spam Current"],
				desc = LL["Spam channels with current waitlist."],
				func = function() mod:SpamCurrent() end,
				disabled = function() return not mdkp.db.profile.modules.Waitlist end,
				order = 170
			},
		},
}

function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return nil
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("Waitlist", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
	db.moduleON["Waitlist"] = true
	self.informqueue = {}
	self.gracequeue = {}
	self.mainoffline = {}
	self.altsqeued = {}
	self.waitsyncdone = nil
	self:RestartTimer()
	
end

function mod:OnDisable()
	db.moduleON["Waitlist"] = nil
						
end

function mod:StopTimer()
	self:CancelTimer(self.timer, true) 
	self.timer = nil
end

function mod:RestartTimer()
	if db.InRaid then
		self:debug("Waitlist scanning ON")
		self.timer = self:ScheduleRepeatingTimer("WaitsOnline", self.db.profile.waitdeletetime)
	end
end

function mod:GetDefaultChannels()
	local ZoneName = GetRealZoneText()
	local Channels = { GetChatWindowChannels(DEFAULT_CHAT_FRAME:GetID()) }
	local defaults
	if IsInGuild() then defaults = {GUILD = "GUILD", SAY = "SAY"}
	else defaults = {SAY = "SAY"} end
	for num = 1, #Channels, 2 do
		local name = Channels[num]
		if name == "LookingForGroup" or name == "General" then name = name .. " - " .. ZoneName end
		if name ~= "Trade" then defaults[name] = name end
	end	
	for name in pairs(mod.db.profile.channels) do
		if not defaults[name] then mod.db.profile.channels[name] = nil end
	end
	return defaults
end

function mod:SpamChannels(direct)
	if self.db.profile.spamchannel or direct then
		for channelname in pairs(self.db.profile.channels) do
			if channelname == "GUILD" or channelname == "SAY" then SendChatMessage(format(LL["Now accepting tells for the waitlist.  Please whisper %s using this format:  mbid wait[+/-] [main]"], Player), channelname)
			else 
				local id = GetChannelName(channelname)
				if id then SendChatMessage(format(LL["Now accepting tells for the waitlist.  Please whisper %s using this format:  mbid wait[+/-] [main]"], Player), "CHANNEL", nil, id) end
			end
		end
	end
end

function mod:SpamCurrent()
	local spamtext = ""
	for num, name in pairs(self.db.profile.Waitlist.members) do
		if num ~= 1 then spamtext = spamtext .. ", " end
		spamtext = spamtext .. name
	end
	for channelname in pairs(self.db.profile.channels) do
		if channelname == "GUILD" or channelname == "SAY" then SendChatMessage(format(LL["Current waitlist: %s"], spamtext), channelname)
		else 
			local id = GetChannelName(channelname)
			if id then SendChatMessage(format(LL["Current waitlist: %s"], spamtext), "CHANNEL", nil, id) end
		end
	end
end

function mod:WaitsOnline()
	self:debug("Checking waitlist attendees online...")
	if #self.db.profile.Waitlist.members == 0 then return end
	
	for num, main in pairs(self.db.profile.Waitlist.members) do
		self:debug("ONWAIT.."..main)
		local result, Online = self:IsOnline(main)
		if result then
			if Online then
				self:debug("ONLINE")
				if self.mainoffline[main] then self.mainoffline[main] = nil end
			else
				self:debug("ISONALT?")
				self:SearchOnlineAlias(main)
			end
		else
			self:debug("QED")
			self.gracequeue[main] = true
			self.mainoffline[main] = true
		end
	end
end

function mod:SearchOnlineAlias(name)
	self:debug("SearchAlias")
	local found
	local POOL = db.raid
	self.altsqeued[name] = {}
	for alt, main in pairs(db.eqDKP[POOL].Aliases) do
		if main == name then
			local result, Online = self:IsOnline(alt)
			if result then
				if Online then 
					self:debug("ONLINE")
					if self.mainoffline[main] then self.mainoffline[main] = nil end
					found = true
					break
				end
			else 
				self:debug("QED")
				self.gracequeue[alt] = true 
				tinsert(self.altsqeued[name], alt)
			end
		end
	end
	if not found and #self.altsqeued[name] == 0 then self:SubWait(name) end
end

function mod:UserDataReturned(user, time)
	if not user then return end
	if user.Online then
		if self.informqueue[user.Name] then
			local main = self:CheckforAlias(user.Name, db.raid)
			if main == user.Name then InviteUnit(user.Name)
			else self:SendInformTell(user.Name) end 
		elseif self.gracequeue[user.Name] then
			local main = self:CheckforAlias(user.Name, db.raid)
			self.mainoffline[main] = nil
			if self.altsqeued[main] then self.altsqeued[main] = {} end
		end
	elseif self.gracequeue[user.Name] then
		local main = self:CheckforAlias(user.Name, db.raid)
		self:IsInAltTable(main)
		if #self.altsqeued[main] == 0 then
			self.mainoffline[main] = nil
			self:out(format(LL["Removed %s from waitlist due to inactivity"], main))
			self:SubWait(main)
		end
	end
	if self.informqueue[user.Name] then self.informqueue[user.Name] = nil end
end

function mod:IsInAltTable(main)
	for num, name in pairs(self.altsqeued[main]) do
		if name == main then 
			tremove(self.altsqeued[main], num)
			break
		end
	end
end

function mod:AtRaidStart(currtime, ZoneName, Startname)
	self:debug("Raidstart waitlist")
	self.waitlistdone = {}
	self.db.profile.lastawardtime = 0
	
	if #self.db.profile.Waitlist.members == 0 or self.db.profile.waitstart == 0 or not self.db.profile.waitaward or not db.startrun then return end
	local POOL = db.raid
	
	if not db.dkpevents then
		if self.db.profile.waitstart == db.raidlog[db.raidnum].bosskills[1].value then
			for num, name in pairs(self.db.profile.Waitlist.members) do
				tinsert(db.raidlog[db.raidnum].bosskills[1].attendees, name)
			end
		else
			self:AwardWaitotimeDKP(self.db.profile.waitstart, POOL, Startname, self.db.profile.Waitlist.members, "Group", "Group")
		end
	else
		local temptable = {}
		for _, waitname in pairs(self.db.profile.Waitlist.members) do
			tinsert(temptable, waitname)
		end
		local tracker = self:GetModuleRef("Tracker")
		if not self.db.profile.waitname then self.db.profile.waitname = "<zone> Waitlist DKP" end
		local eventname = self:GetEventName(ZoneName, self.db.profile.waitname)
		if tracker then tracker:LogBossKill(currtime, eventname, true, eventname, nil, 3, temptable, self.db.profile.waitstart) end
	end
	self:AwardDKP(nil, self.db.profile.waitstart, POOL, self.db.profile.Waitlist.members, 1, true)
	self:RestartTimer()
	
	--send waitlist sync
	local sync = self:GetModuleRef("Syncing")
	if sync then 
		sync:SendWaitlist(self.db.profile.Waitlist) 
		self.waitsyncdone = true
	end
end

function mod:AtRaidEnd()
	self.db.profile.Waitlist = {members = {}, join = {}}
	self:StopTimer() 
	self.waitsyncdone = nil
end

function mod:UpdateSyncWaitlist(waitlist)
	for _, name in pairs(waitlist.members) do
		if not self:IsOnWaitlist(name) then
			table.insert(self.db.profile.Waitlist.members, name)
			self.db.profile.Waitlist.join[name] = waitlist.join[name]
		end
	end
end

function mod:AtMemberAdded(name) 	
	local POOL = mdkp.db.profile.raid
	for _, waitname in pairs(self.db.profile.Waitlist.members) do
		if waitname == name then
			self:SubWait(name)	
		elseif db.eqDKP[POOL].Aliases[name] and db.eqDKP[POOL].Aliases[name] == waitname then
			self:SubWait(db.eqDKP[POOL].Aliases[name])
		end
	end
end

function mod:AtAttendanceCheck(value, eventid)
	local db2 = self.db.profile
	if db2.waitrun == 0 or not self.waitlistdone or not db2.waitaward then return true end
	self:debug("Waitlist attendance check")
	local POOL = db.raid
	local raidnum = db.raidnum
	local waitrewardtime = db2.waitrewardtime
	local currtime = time()
	local ZoneName = GetRealZoneText()
	
	--determine who needs awarded
	local temptable = {}
	for _,  name in pairs(db2.Waitlist.members) do
		if not self.waitlistdone[name] then
			if currtime - db2.Waitlist.join[name] >= db2.waitrewardtime then	
				table.insert(temptable, name)
				self:debug("Added "..name.." to waitlist run.") 
				self.waitlistdone[name] = true
			end
		end
	end
	
	--award if necessary
	if temptable and #temptable > 0 then
		if not db.dkpevents then
			if db2.waitrun == value then
		 		for _, name in pairs(temptable) do
		 			table.insert(db.raidlog[raidnum].bosskills[eventid].attendees, name)
		 		end
			else 
				self:AwardWaitotimeDKP(db2.waitrun, POOL, db.raidlog[raidnum].bosskills[eventid].name, temptable, "Group", "Group") 
			end
			self:AwardDKP(nil, db2.waitrun, POOL, temptable, 1, 1)
		else
			local id = self:GetEventID(3)
			if not id then
				local tracker = self:GetModuleRef("Tracker")
				if not db2.waitname then db2.waitname = "<zone> Waitlist DKP" end
				local eventname = self:GetEventName(ZoneName, db2.waitname)
				if tracker then tracker:LogBossKill(currtime, eventname, true, eventname, nil, 3, temptable, db2.waitrun) end
			else 
				for _, name in pairs(temptable) do
		 			tinsert(db.raidlog[raidnum].bosskills[id].attendees, name)
		 		end
		 		self:AwardDKP(nil, db2.waitrun, POOL, temptable, 1, 1)
			end
		end
	end
	
	--done with waitlist?
	local waitdone = true
	for _, name in pairs(db2.Waitlist.members) do
		if not self.waitlistdone[name] then waitdone = nil end
	end
	return waitdone
end

function mod:AwardWaitlistDKP(currtime, Boss)
	if #self.db.profile.Waitlist.members == 0 or self.db.profile.waitboss == 0 or not self.db.profile.waitaward then return end
	local ZoneName = GetRealZoneText()
	local POOL = db.raid
	
	if not db.dkpevents then
		local eventnum
		for num, data in pairs(db.raidlog[db.raidnum].bosskills) do
			if find(data.name, Boss) or find(data.note, Boss) then eventnum = num break end
		end
		if not eventnum then return end
		if self.db.profile.waitboss == db.raidlog[db.raidnum].bosskills[eventnum].value then
			for num, name in pairs(self.db.profile.Waitlist.members) do
				tinsert(db.raidlog[db.raidnum].bosskills[eventnum].attendees, name)
			end
		else
			self:AwardWaitotimeDKP(self.db.profile.waitboss, POOL, Boss, self.db.profile.Waitlist.members, "Group", "Group")
		end
	else
		local temptable = {}
		for _, waitname in pairs(self.db.profile.Waitlist.members) do
			tinsert(temptable, waitname)
		end
		local tracker = self:GetModuleRef("Tracker")
		if not self.db.profile.waitbossname then self.db.profile.waitbossname = "<boss> Waitlist DKP" end
		local eventname = self:GetEventName(Boss, self.db.profile.waitbossname)
		if tracker then tracker:LogBossKill(currtime, eventname, true, eventname, nil, 3, temptable, self.db.profile.waitboss) end
	end
	self:AwardDKP(nil, self.db.profile.waitboss, POOL, self.db.profile.Waitlist.members, 1, true)
end

function mod:AddWait(addname, skipsync)
	if UnitInRaid(addname) then return end
	local db = self.db.profile
	local POOL = mdkp.db.profile.raid
	local class = nil
	local ttime = time()
	
	--check if add is an alias as waitlist is only mains
	addname = self:CheckforAlias(addname, POOL)
	
	--initialise wl
	if not db.Waitlist then db.Waitlist = {members = {}, join = {} } end
	
	--add member
	if not self:IsOnWaitlist(addname) then
		table.insert(db.Waitlist.members, addname)
		db.Waitlist.join[addname] = ttime
		self:out(fmt(LL["Added %s to the waitlist."], addname))
		self:PlayerinDB(addname)
		
		--update wl
		if mdkp.querytooltips["listdkp"]  then
			local found
			for i, data in pairs(mdkp.querytooltips["listdkp"]) do
				if data[1].n == addname then
					found = i
					break
				end
			end
			local status = mdkp.guildstatustext[L["WAIT"]]
			local waittime = date("%I:%M:%S", ttime)
			local pointsdata = {n = waittime, r = 1, g = 1, b = 0}
			if not found then
				local namedata = self:GetDKPInfo(addname, POOL)
  				tinsert(mdkp.querytooltips["listdkp"], {namedata, status, pointsdata})
  			else 
  				mdkp.querytooltips["listdkp"][found][2] = status 
  				mdkp.querytooltips["listdkp"][found][3] = pointsdata 
  			end
  			self:ToggleFrameUpdate("listdkp")
		end
		
		--send waitlist sync
		if not skipsync then
			local sync = self:GetModuleRef("Syncing")
			if sync then
				if not self.waitsyncdone then 
					sync:SendWaitlist(self.db.profile.Waitlist, true) 
					self.waitsyncdone = true
				else sync:AddtoWait(addname) end
			end
		end
	end
end

function mod:GetWaitlist()
	if #self.db.profile.Waitlist.members > 0 then return self.db.profile.Waitlist.members end
	return nil
end

function mod:SubWait(name, skipsync)
	local db = self.db.profile
	local POOL = mdkp.db.profile.raid
	
	--check if add is an alias as waitlist is only mains
	name = self:CheckforAlias(name, POOL)
	
	local found
	for num, waitname in pairs(db.Waitlist.members) do
		if name == waitname then
			tremove(db.Waitlist.members, num)
			db.Waitlist.join[name] = nil
			self:out(fmt(LL["Removed %s from wailist."], name))
			found = true
			break
		end
	end
	
	--update tablet if open
	if found then
		if mdkp.querytooltips["listdkp"]  then
			local namedata, pointsdata = self:GetDKPInfo(name, POOL)
			for num, v in pairs(mdkp.querytooltips["listdkp"]) do
				if v[1].n == name then
					v[2] = mdkp.guildstatustext[L["UNKNOWN"]]
					v[3] = pointsdata
					break
				end
			end
			self:ToggleFrameUpdate("listdkp")
		end
	
		--send waitlist sync
		if not skipsync then
			local sync = self:GetModuleRef("Syncing")
			if sync then sync:SubfromWait(name) end
		end
	end
end

function mod:OnWaitWhisper(sender, actions)
	if not actions then return end
	local args = {self:Explode(actions, " ")}
	local action = args[2]
	local reportedmain = args[3]
	if reportedmain and string.utf8upper(sender) == reportedmain then reportedmain = nil end
	local POOL = db.raid
	local main
	local ADD = L["WAIT"] .. "+" 
	local SUB = L["WAIT"] .. "-"
	if action == L["WAIT"] or action == ADD then
		if reportedmain then
			main = string.utf8upper(string.utf8sub(reportedmain, 1, 1)) .. string.utf8lower(string.utf8sub(reportedmain, 2, -1))
			local core = self:GetModuleRef("CoreModule")
			if core then core:AddAlias(sender, main, true) end
			if db.info[main] then self:AddWait(main) 
			else SendChatMessage(LL["That main does not exist."], "WHISPER", nil, sender) return end
		else 
			main = self:CheckforAlias(sender, POOL) 
			self:PlayerinDB(main) 
			self:AddWait(main) 
		end
		SendChatMessage(LL["Added you to the waitlist."], "WHISPER", nil, sender)
	elseif action == SUB then
		main  = self:CheckforAlias(sender, POOL) 
		self:SubWait(main)
		SendChatMessage(LL["Removed you from the waitlist."], "WHISPER", nil, sender)
	end
end

function mod:IsOnWaitlist(onname)
	for num, name in pairs(self.db.profile.Waitlist.members) do
		if name == onname then return true, date("%I:%M:%S", self.db.profile.Waitlist.join[onname]) end
	end
	return nil
end

function mod:IsAltOnWait(member)
	local POOL = db.raid
	for alt, main in pairs(db.eqDKP[POOL].Aliases) do
		if main == member then
			local ison = self:IsOnWaitlist(alt)
			if ison then return true end
		end
	end
	return nil
end

function mod:InformOnlineAlias(name)
	local POOL = db.raid
	if not db.eqDKP[POOL] then return name end
	
	--check if main online
	local result, Online = self:IsOnline(name)
	if result and Online then return name end
	
	--if not check for alts online
	for alt, main in pairs(db.eqDKP[POOL].Aliases) do
		if main == name then
			local result, Online = self:IsOnline(alt)
			if result then
				if Online then 
					self:SendInformTell(alt) 
					break
				end
			else self.informqueue[alt] = true end
		end
	end
	return nil
end

function mod:SendInformTell(name) 
	SendChatMessage(LL["Please log on to your main for an invite to the raid.  Whisper me when online."], "WHISPER", nil, name)
end

function mod:IsOnline(name)
	local user, time = self:UserInfo(name, { callback = 'UserDataReturned'} )
	if user then return true, user.Online end
	return false
end

function mod:AwardWaitlistDKPperTime(POOL, currtime, ZoneName, Runname, mintime)
	if self.db.profile.waitaward and self.db.profile.waitotime ~= 0 and #self.db.profile.Waitlist.members ~= 0 then
		self:AwardWaitotimeDKP(self.db.profile.waitotime, POOL, Runname, self.db.profile.Waitlist.members, "Group", "Group") 
		self:AwardDKP(nil, self.db.profile.waitotime, POOL, self.db.profile.Waitlist.members, 1)
	end
end

function mod:AwardWaitlistDKPperTimeEvent(POOL, currtime, ZoneName, Runname, mintime)
	if self.db.profile.waitaward and self.db.profile.waitotime ~= 0 and #self.db.profile.Waitlist.members ~= 0 then
		local tracker = self:GetModuleRef("Tracker")
		if not self.db.profile.waitname then self.db.profile.waitname = "<zone> Waitlist DKP" end
		local eventname = self:GetEventName(ZoneName, self.db.profile.waitname)
		if tracker then tracker:LogBossKill(currtime, eventname, true, eventname, nil, 3, self.db.profile.Waitlist.members, self.db.profile.waitotime) end
	end
end
