local mod = MorgDKP2:NewModule("CoreModule", "AceEvent-3.0", "AceTimer-3.0", "AceComm-3.0", "AceSerializer-3.0", "LibWho-2.0")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local media = LibStub("LibSharedMedia-3.0", true)
local BB = LibStub("LibBabble-Boss-3.0"):GetLookupTable()
local BZ = LibStub("LibBabble-Zone-3.0"):GetLookupTable()

local mdkp = MorgDKP2
mod.modName = "CoreModule"

--locals

local fmt = string.format
local sub = string.sub
local gsub = string.gsub
local tinsert = table.insert
local tsort   = table.sort
local tremove = table.remove
local tostring = tostring 
local lower = string.lower
local find = string.find
local len = string.len
local upper = string.upper
local band = bit.band
local bor = bit.bor
local bxor = bit.bxor
local LOOT_SELF_REGEX = gsub(LOOT_ITEM_SELF, "%%s", "(.+)")
local LOOT_REGEX = gsub(LOOT_ITEM, "%%s", "(.+)")
local RANDOM_REGEX = gsub(RANDOM_ROLL_RESULT, "%(", "%%(")
RANDOM_REGEX = gsub(RANDOM_REGEX, "%)", "%%)")
RANDOM_REGEX = gsub(RANDOM_REGEX, "%%s", "(.+)")
RANDOM_REGEX = gsub(RANDOM_REGEX, "%%d", "(%%d+)")
local Player = UnitName("player")
local db
local RANDROLLID
local CHATLISTENING
local MorgDKP2_Scantip = CreateFrame("GameTooltip", "MorgDKP2_Scantip", nil, "GameTooltipTemplate")
MorgDKP2_Scantip:SetOwner(UIParent, "ANCHOR_NONE")

local defaults = { 
	profile = {
		frames = {	version = {point = "CENTER", relpoint = "CENTER", x = 0, y = 0},
				history = {point = "CENTER", relpoint = "CENTER", x = 0, y = 0},
				listdkp = {point = "CENTER", relpoint = "CENTER", x = 0, y = 0}
		},
   	},
}

local options = {
		type = "group",
		handler = mod,
		name = L["Core Options"],
		desc = L["Core of all MorgDKP2 features."],
		order = 5,
		args = {
			mlde = {
				type = "toggle",
				name = L["Enable ML/DE mode"],
				desc = L["If ML/DE Mode is on then no items will be recorded for the master looter or disenchanter defined by MorgDKP2."],
				get = function() return mdkp.MLmode end,
				set = function(info, v) mdkp.MLmode = v end,
				disabled = function() return not mod:IsEnabled() end,
				order = 5
			},
			mbidc = {
				type = "execute",
				name = L["Morgbid check"],
				desc = L["Determine MorgBid user base. \nAlso useful to check DKP for alts."],
				func = function() mod:MorgBidQuery() end,
				disabled = function() return not mod:IsEnabled() end,
				order = 10
			},
			hints = {
				type = "toggle",
				name = L["Enable tooltip hints"],
				desc = L["Enable tooltip hints"],
				get = function() return mdkp.db.profile.hints end,
				set = function(info, v) mdkp.db.profile.hints = v end,
				disabled = function() return not mod:IsEnabled() end,
				order = 15
			},
			toggleminimap = {
				type = "toggle",
				name = L["Show minimap icon"],
				desc = L["Show minimap icon"],
				get = function() 
					local ldbmod = mdkp:GetModule("LDBPlugin", true)
					if ldbmod then return not ldbmod.db.profile.minimapicon.hide end
				end,
				set = function(info, v) 
						local ldbmod = mdkp:GetModule("LDBPlugin", true)
						if ldbmod then
							ldbmod.db.profile.minimapicon.hide = not v
							ldbmod:ToggleMinimapIcon(v)
						end
				end,
				disabled = function() return not mod:IsEnabled() end,
				order = 16
			},
			raidtracker = {
				type = "toggle",
				name = L["Raid Tracker"],
				desc = L["Raid Tracker for viewing and editing current raids."],
				get = function() return mdkp.db.profile.modules.RaidTracker end,
				set = 	function(info, v) 
						mdkp.db.profile.modules.RaidTracker = v
						local raidtracker = mdkp:GetModule("RaidTracker", true)
						if raidtracker then 
							if v then raidtracker:Enable()
							else raidtracker:Disable() end
						end
					end,
				disabled = function() return not mod:IsEnabled() end,
				order = 17
			},
			whisper = {
				type = "toggle",
				name = L["Whisper system"],
				desc = L["Whispers all members (even if they have MorgBid2) so they can reply and bid using whispers."],
				get = function() return mdkp.db.profile.modules.Whisper end,
				set = 	function(info, v) 
						mdkp.db.profile.modules.Whisper = v
						local whisper = mdkp:GetModule("Whisper", true)
						if whisper then 
							if v then whisper:Enable()
							else whisper:Disable() end
						end
					end,
				disabled = function() return not mod:IsEnabled() end,
				order = 18
			},
			linkraid = {
				type = "toggle",
				name = L["Link to Raid"],
				desc = L["Link items on the boss/mob that are above the loot threshold to raid chat."],
				get = function() return mdkp.db.profile.raidlink end,
				set = function(info, v) mdkp.db.profile.raidlink = v end,
				disabled = function() return not mod:IsEnabled() end,
				order = 20
			},
			linkguild = {
				type = "toggle",
				name = L["Link to Guild"],
				desc = L["Link items on the boss/mob that are above the loot threshold to guild chat."],
				get = function() return mdkp.db.profile.guildlink end,
				set = function(info, v) mdkp.db.profile.guildlink = v end,
				disabled = function() return not mod:IsEnabled() end,
				order = 25
			},
			showearned = {
				type = "toggle",
				name = L["Earned DKP for Invites"],
				desc = L["Use earned DKP in the invite tablet (shift-click)."],
				get = function() return mdkp.db.profile.showearned end,
				set = function(info, v) mdkp.db.profile.showearned = v end,
				disabled = function() return not mod:IsEnabled() end,
				order = 27
			},
			ignore58 = {
				type = "toggle",
				name = L["Ignore 6-8"],
				desc = L["Ignore members in groups 6-8 when querying for items."],
				get = function() return mdkp.db.profile.ignore68 end,
				set = function(info, v) mdkp.db.profile.ignore68 = v end,
				disabled = function() return not mod:IsEnabled() end,
				order = 30
			},
			ignoreunique = {
				type = "toggle",
				name = L["Ignore worn"],
				desc = L["Ignore items worn by members.  This means queries will always be sent even if they have the item."],
				get = function() return mdkp.db.profile.ignoreunique end,
				set = function(info, v) mdkp.db.profile.ignoreunique = v end,
				disabled = function() return not mod:IsEnabled() end,
				order = 35
			},
			display = {
				type = "header",
				name = L["Display Options"],
				desc = L["General display options for main modules."],
				order = 100
			},
			font = {
		 		type = "select",
		 		dialogControl = "LSM30_Font",
		 		name = L["Font"],
		 		desc = L["Font used in tooltips and frames."],
		 		get = function() return mdkp.db.profile.media.font end,
		 		set = function(info, v) mdkp.db.profile.media.font = v mod:UpdateFrameMedia() end,
		 		values = AceGUIWidgetLSMlists.font, 
				disabled = function() return not mod:IsEnabled() end,
				order = 120
			},
			fontsize = {
				type = "range",
				name = L["Font size"],
				get = function() return mdkp.db.profile.media.fontsize end,
				set = function(info, v) mdkp.db.profile.media.fontsize = v mod:UpdateFrameMedia() end,
				min = 1, 
				max = 30, 
				step = 1,
				disabled = function() return not mod:IsEnabled() end,
				order = 125
			},
			background = {
				type = "select",
				dialogControl = "LSM30_Background",
				name = L["Background texture"],
				desc = L["Background texture of frames/tooltips."],
				get = function() return mdkp.db.profile.media.background end,
				set = function(info, v) 
						mdkp.db.profile.media.background = v
						mod:UpdateFrameMedia()
					end,
				values = AceGUIWidgetLSMlists.background, 
				disabled = function() return not mod:IsEnabled() end,
				order = 130
			},
			border = {
				type = "select",
				dialogControl = "LSM30_Border",
				name = L["Border texture"],
				desc = L["Border texture of frames/tooltips."],
				get = function() return mdkp.db.profile.media.border end,
				set = function(info, v) 
						mdkp.db.profile.media.border = v
						mod:UpdateFrameMedia()
					end,
				values = AceGUIWidgetLSMlists.border, 
				disabled = function() return not mod:IsEnabled() end,
				order = 135
			},
			scale = {
				type = "range",
				name = L["Frame scale"],
				get = function() return mdkp.db.profile.media.scale end,
				set = function(info, v) mdkp.db.profile.media.scale = v mod:UpdateFrameMedia() end,
				min = .5, 
				max = 2, 
				step = .1,
				disabled = function() return not mod:IsEnabled() end,
				order = 137
			},
			desc = {
				type = "description",
				name = "",
				order = 138
			},
			backdropC = {
				type = "color",
				name = L["Background color"],
				hasAlpha = true,
				set = "SetColorOpt",
				get = "GetColorOpt",
				disabled = function() return not mod:IsEnabled() end,
				order = 140
			},
			borderC = {
				type = "color",
				name = L["Border color"],
				hasAlpha = true,
				set = "SetColorOpt",
				get = "GetColorOpt",
				disabled = function() return not mod:IsEnabled() end,
				order = 145
			},
			fontC = {
				type = "color",
				name = L["Font color"],
				hasAlpha = true,
				set = "SetColorOpt",
				get = "GetColorOpt",
				disabled = function() return not mod:IsEnabled() end,
				order = 150
			},
			head3 = {
				type = "header",
				name = L["MorgBid2 Options"],
				order = 200
			},
			silent = {
				type = "toggle",
				name = L["MorgBid2 updating"],
				desc = L["Allow updating bid results in MorgBid2."],
				get = function() return mdkp.db.profile.mbidupdating end,
				set = function(info, v) mdkp.db.profile.mbidupdating = v end,
				disabled = function() return not mod:IsEnabled() end,
				order = 210
			},
			mbidcustom = {
				type = "toggle",
				name = L["Custom MorgBid2"],
				desc = L["Enables changing the text of button hints in MorgBid2."],
				get = function() return mdkp.db.profile.mbidcustom end,
				set = function(info, v) 
						mdkp.db.profile.mbidcustom = v 
						if v then mod:CreateCustomMbidTable() 
						else mod:RestoreDefaultMbidTable() end
				end,
				disabled = function() return not mod:IsEnabled() end,
				order = 212
			},
			useoffspec = {
				type = "toggle",
				name = L["Use OFFSPEC"],
				desc = L["Allow the OFFSPEC button to be used in MorgBid2."],
				get = function() return mdkp.db.profile.mbidoffspec end,
				set = function(info, v) 
						mdkp.db.profile.mbidoffspec = v 
						mod:CreateCustomMbidTable() 
				end,
				disabled = function() return not mod:IsEnabled() end,
				hidden = function() return not mdkp.db.profile.mbidcustom end,
				order = 215
			},
			desc2 = {
				type = "description",
				name = "",
				hidden = function() return not mdkp.db.profile.mbidcustom end,
				order = 230
			},
			need = {
				type = "input",
				name = L["NEED text"],
				desc = L["Text of MorgBid2 NEED button"],
				get = function() return mdkp.db.profile.NEED end,
				set = 	function(info, v) 
						local text = mod:CheckFormat(v)
						if text then mdkp.db.profile.NEED = text end
						mod:CreateCustomMbidTable() 
				end,
				disabled = function() return not mod:IsEnabled() end,
				hidden = function() return not mdkp.db.profile.mbidcustom end,
				order = 220
			},
			take = {
				type = "input",
				name = L["TAKE text"],
				desc = L["Text of MorgBid2 TAKE button"],
				get = function() return mdkp.db.profile.TAKE end,
				set = 	function(info, v) 
						local text = mod:CheckFormat(v)
						if text then mdkp.db.profile.TAKE = text end
						mod:CreateCustomMbidTable() 
				end,
				disabled = function() return not mod:IsEnabled() end,
				hidden = function() return not mdkp.db.profile.mbidcustom end,
				order = 230
			},
			offspec = {
				type = "input",
				name = L["OFFSPEC text"],
				desc = L["Text of MorgBid2 OFFSPEC button"],
				get = function() return mdkp.db.profile.OFFSPEC end,
				set = 	function(info, v) 
						local text = mod:CheckFormat(v)
						if text then mdkp.db.profile.OFFSPEC = text end
						mod:CreateCustomMbidTable() 
				end,
				disabled = function() return not mod:IsEnabled() end,
				hidden = function() return not mdkp.db.profile.mbidcustom or not mdkp.db.profile.mbidoffspec end,
				order = 240
			},
			pass = {
				type = "input",
				name = L["PASS text"],
				desc = L["Text of MorgBid2 PASS button"],
				get = function() return mdkp.db.profile.PASS end,
				set = 	function(info, v) 
						local text = mod:CheckFormat(v)
						if text then mdkp.db.profile.PASS = text end
						mod:CreateCustomMbidTable() 
				end,
				disabled = function() return not mod:IsEnabled() end,
				hidden = function() return not mdkp.db.profile.mbidcustom end,
				order = 250
			},
        	},
}


function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return nil
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("CoreModule", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
	db.moduleON["CoreModule"] = true
	mdkp.MLmode = true
	mdkp.updatedata = {}
	mdkp.lootmaster = nil 
	mdkp.AuctionStatus = {}
	mdkp.spammed = {}
	mdkp.roster = {}
	mdkp.oldroster = {}
	mdkp.Starttime = nil
	mdkp.origitempoints = {}
	mdkp.random = {}
	mdkp.given = nil
	mdkp.frames = {}
	mdkp.boelink = nil
	mdkp.itemrecorded = {}
	self.whoque = {}
	self:CreateCustomMbidTable()
	
	--events
	self:RegisterEvent("CHAT_MSG_LOOT", "OnLootMsg")
    	self:RegisterEvent("RAID_ROSTER_UPDATE", "UpdateRoster")
	self:RegisterEvent("GUILD_ROSTER_UPDATE", "GuildUpdate")
	self:RegisterEvent("PLAYER_REGEN_DISABLED", "StartCombat")
	self:RegisterComm("MorgDKP2MorgBid", "OnMorgBidCommReceive")
	
	self:GetCurrentLootMethod()
	self:InitialiseRoster()
	self:IsDKPEnabled()
end

function mod:OnDisable()
	if db.alwaysloot then 
		local loot = self:GetModuleRef("Lootframe")
		if loot then loot:RegisterEvent("RAID_ROSTER_UPDATE", loot.RaidEvent) end
	end
	mdkp.frames = nil
	db.moduleON["CoreModule"] = nil
end

function mod:CreateCustomMbidTable()
	mdkp.statustext = {	["NEED"] = db.NEED,
				["TAKE"] = db.TAKE,
				["PASS"] = db.PASS
	}
	if db.mbidoffspec then mdkp.statustext["OFFSPEC"] = db.OFFSPEC end
	mdkp.defaultstatustext = {	["NEED"] = {n = db.NEED, r = 0, g = 1, b = 0},
					["PASS"] = {n = db.PASS, r = 1, g = 0, b = 0},
					["TAKE"] = {n = db.TAKE, r = 0, g = .7, b = 0},
					["OFFSPEC"] = {n = db.OFFSPEC, r = 0, g = .5, b = 0},
					["PENDING"] = {n = L["PENDING"], r = 1, g = 1, b = 0},
					["NONE"] = {n = L["NONE"], r = 1, g = 0, b = 0}
	}
end

function mod:RestoreDefaultMbidTable()
	db.NEED = L["NEED"]
	db.TAKE = L["TAKE"]
	db.OFFSPEC = L["OFFSPEC"]
	db.PASS = L["PASS"]
	db.mbidoffspec = true
	self:CreateCustomMbidTable()
end

function mod:CheckFormat(term)
	if term then return string.utf8upper(term)
	else return nil end
end

--called when a new DKP system is toggled on and may result in a conflict
function mod:ChangeDKPType(newtype, nosync)
	self:debug("ChangeDKP type"..newtype)
	local refname = mdkp.dkpmenuconvert[newtype]
	self:debug("ref"..refname.." "..(db.currDKP or "NIL"))
	if refname == "attemptmode" then
		db.attemptmode = not db.attemptmode
		local tracker = MorgDKP2:GetModule("Tracker", true)
		if tracker then tracker:TogglePlayerDies(db.attemptmode) end
	elseif refname == "BidWar" then
		local bidwar = MorgDKP2:GetModule("BidWar", true)
		if bidwar then 
			if db.moduleON["BidWar"] then 
				bidwar:Disable()
				db.modules[refname] = nil
			else 
				bidwar:Enable() 
				db.modules[refname] = true
			end
		end
	elseif refname == db.currDKP and not nosync then
		local currDKP = MorgDKP2:GetModule(refname, true)
		db.modules[refname] = nil
		self:debug("Disabled "..refname)
		currDKP:Disable()
		db.currDKP = nil
		db.dkpstatustext = L["Not Set"] .. (db.moduleON["BidWar"] and " & BidWar" or "")
	elseif refname == "DKPovertime" then
		local newDKP = MorgDKP2:GetModule(refname, true)
		if newDKP then 
			if newDKP:IsEnabled() then 
				newDKP:Disable()
				db.modules[refname] = nil
			else 
				newDKP:Enable()
				db.modules[refname] = true
				self:debug("Enabled "..refname)
			end
		end
	else
		local text = newtype
		local conflict
		if db.modules.BidWar then
			local currconflicts = mdkp.bidwarconflicts
			for _, conflictname in pairs(currconflicts) do
				if conflictname == refname then 
					local bidwar = self:GetModuleRef("BidWar")
					bidwar:Disable()
					db.modules.BidWar = nil
					self:debug("Disabled BidWar due to conflict")
					conflict = true
					break
				end
			end
			if not conflict then text = text .. " & BidWar" end
		end
		if db.currDKP then
			local currDKP = MorgDKP2:GetModule(db.currDKP, true)
			db.modules[db.currDKP] = nil
			self:debug("Disabled "..db.currDKP)
			currDKP:Disable()
		end
		local newDKP = MorgDKP2:GetModule(refname, true)
		if newDKP then 
			newDKP:Enable()
			db.modules[refname] = true
			self:debug("Enabled "..refname)
		end
		db.currDKP = refname
		db.dkpstatustext = text
		if db.InRaid then
			db.raidlog[db.raidnum].dkptype = refname
		end
	end
	
	if db.currDKP ~= "Random" and CHATLISTENING then self:ToggleChatListening() end
	if db.InRaid and not nosync then
		local sync = self:GetModuleRef("Syncing")
		if sync then sync:ChangeDKPSystem(newtype) end	
	end	
	self:ToggleFrameUpdate("TooltipLDB")
end

function mod:UpdateFrameMedia()
	local LDB = self:GetModuleRef("LDBPlugin")
	if LDB and LDB.LDBframe then 
		self:CreateBackdrop(LDB.LDBframe)
		LDB.LDBframe:SetScale(db.media.scale)
		self:ToggleFrameUpdate("TooltipLDB", true)
	end
	local lootframe = self:GetModuleRef("Lootframe")
	if lootframe and lootframe.lootframe then 
		self:CreateBackdrop(lootframe.lootframe)
		self:CreateBackdrop(lootframe.itemframe, true)
		self:CreateBackdrop(lootframe.rollframe, true)
		self:CreateBackdrop(lootframe.rollsummaryframe, true)
		lootframe.font = media:Fetch("font", db.media.font)
		lootframe.itemframe:Hide()
		lootframe.itemframe = lootframe:CreateItemsFrame()
		lootframe:UpdateLootFrame(nil, nil, nil, nil, true, true)
	end
	if mdkp.frames.raidtracker then 
		self:debug("Raidtracker")
		local raidtracker = self:GetModuleRef("RaidTracker")
		self:CreateBackdrop(mdkp.frames.raidtracker, true)
		mdkp.frames.raidtracker:SetScale(db.media.scale)
		for num = 1,4 do
			if mdkp.frames.raidtracker.frame[num] then self:CreateBackdrop(mdkp.frames.raidtracker.frame[num], true, true) end
		end
		raidtracker.font = media:Fetch("font", db.media.font)
		raidtracker:RedrawFrames()
	end
	for name, data in pairs(mdkp.frames) do
		self:CreateBackdrop(data)
		data:SetScale(db.media.scale)
		self:ToggleFrameUpdate(name)
	end
end

function mod:CreateBackdrop(f, skip, noborder)
	local temptable = f:GetBackdrop()
	local font = media:Fetch("font", db.media.font)
	if not temptable then
		temptable = {
			insets = {left = 3, right = 3, top = 3, bottom = 3},
			tile = false, 
			tileSize = 16, 
			edgeSize = 8,
		}
	end
	temptable.edgeFile = media:Fetch("border", db.media.border)
	temptable.bgFile = media:Fetch("background", db.media.background)
	f:SetBackdrop(temptable)
	f:SetBackdropColor(unpack(db.media.backdropC))
   	if not noborder then f:SetBackdropBorderColor(unpack(db.media.borderC)) 
   	else f:SetBackdropBorderColor(0,0,0,0) end
   	if f.title and not skip then 
   		f.title:SetTextColor(unpack(db.media.borderC)) 
   		f.title:SetFont(font, db.media.fontsize + 1)
   	end
   	if f.hint then
   		f.hint:SetFont(font, db.media.fontsize) 
   	end
end

function mod:SetColorOpt(info, r, g, b, a)
	local db = mdkp.db.profile.media
	local opt = info[#info]
	db[opt][1] = r
	db[opt][2] = g
	db[opt][3] = b
	db[opt][4] = a
	self:UpdateFrameMedia()
end

function mod:GetColorOpt(info)
	local db = mdkp.db.profile.media
	local opt = info[#info]
	return unpack(db[opt])
end

function mod:OnLootMsg(_, lootmsg)
	if not db.InRaid then return end
	local sPlayer, sLink
	_, _, sPlayer, sLink = find(lootmsg, LOOT_REGEX)
  	if not sPlayer or not sLink then
		_, _, sLink = find(lootmsg, LOOT_SELF_REGEX)
    		sPlayer = Player
	end
	
	self:debug("Player.."..(sPlayer or "NIL").." Link.."..(sLink or "NIL"))
	-- Make sure there is a link
	if not mdkp.roster[sPlayer] then self:debug("Player not in raid "..sPlayer) return end
	if sLink and sPlayer then
		self:RecordLoot(sLink, sPlayer)
	end
end

function mod:InitialiseRoster()
	self:debug("Initialising roster..")
	local totalmembers = GetNumRaidMembers()
	if totalmembers == 0 then
		db.raidmembers = {Player}
		mdkp.roster[Player] = 1
	else
		db.raidmembers = {}
		for i = 1, totalmembers do
			local _, _, subgroup, _, _, _, _, _, _, _, _ = GetRaidRosterInfo(i)
			local name = UnitName("raid"..i)
			mdkp.roster[name] = subgroup
			tinsert(db.raidmembers, name)
		end
	end
	mdkp.oldroster = mdkp.roster
	tsort(db.raidmembers)
end

function mod:UpdateRoster()
	--self:debug("Updating roster..")
	
	if not UnitInRaid("player") and not mdkp.querytooltips["listdkp"] then return end 
	mdkp.oldroster = mdkp.roster
	mdkp.roster = {}
	local totalmembers = GetNumRaidMembers()
	for i = 1, totalmembers do
		local name, _, subgroup, _, _, _, _, _, _, _, _ = GetRaidRosterInfo(i)
		mdkp.roster[name] = subgroup
	end
	--new member?
	for name in pairs(mdkp.roster) do
		if not mdkp.oldroster[name] then
			self:AddMember(name)
		end
	end
	--member left?
	for name in pairs(mdkp.oldroster) do
		if not mdkp.roster[name] and name ~= Player and not UnitCanAttack("player", name) then
			self:RemoveMember(name)
		end
	end
	if mdkp.querytooltips["listdkp"] then 
		mdkp.querytooltips["listdkp"] = self:Onlinemembers(mdkp.querytooltips["listdkp"]) 
		self:ToggleFrameUpdate("listdkp")
	end
	tsort(db.raidmembers)
	self:GetCurrentLootMethod()
end

function mod:AddMember(name)
	self:debug("Add member.."..name)
	local raidnum = db.raidnum
	local ttime = time()
	local race = UnitRace(name)
    	local level = UnitLevel(name)
	local guild = GetGuildInfo(name)
	local classtrue, englishclass = UnitClass(name)
	local tracker = self:GetModuleRef("Tracker")
	if raidnum > 0 and db.InRaid then
		if not db.raidlog[raidnum].playerinfo then db.raidlog[raidnum].playerinfo = { } end
		if not db.raidlog[raidnum].playerinfo[name] then db.raidlog[raidnum].playerinfo[name] = { } end
		db.raidlog[raidnum].playerinfo[name].class = classtrue 
		db.raidlog[raidnum].playerinfo[name].race = race 
		db.raidlog[raidnum].playerinfo[name].level = level 
		db.raidlog[raidnum].playerinfo[name].guild = guild 
		if not db.raidlog[raidnum].join then db.raidlog[raidnum].join = { } end
		if not db.raidlog[raidnum].join[name] then 
			db.raidlog[raidnum].join[name] = ttime 
			if db.raidlog[raidnum].leave then
				if db.raidlog[raidnum].leave[name] then db.raidlog[raidnum].leave[name] = nil end
			end
			self:out(fmt(L["%s joined the raid at %s."], name, date("%I:%M:%S", ttime)))
			if tracker then tracker:StartAttEvent() end
		end
	end
	self:PlayerinDB(name, englishclass)
	
	if db.InRaid and db.raidlog.new and #db.raidlog.new > 0 then
		local new = {}
		self:CopyTable(db.raidlog.new, new)
		self:AddNewMemberDKPChange(new)
		db.raidlog.new = {}
	end
	
	--update listdkp
	if mdkp.querytooltips["listdkp"] then 
		local found = nil
		local namedata, pointsdata
		for _, data in pairs(mdkp.querytooltips["listdkp"]) do
			if data[1].n == name then 
				found = true
				break
			end
		end
		if not found then
			local POOL = db.raid
			namedata, pointsdata = self:GetDKPInfo(name, POOL)
			local status = mdkp.guildstatustext[L["INRAID"]]
			tinsert(mdkp.querytooltips["listdkp"], {namedata, status, pointsdata}) 
		end
	end
	
	--update waitlist
	local wait = self:GetModuleRef("Waitlist")
	if wait then wait:AtMemberAdded(name) end
	
	if db.currDKP == "SKSotC" then
		local currDKP = self:GetModuleRef(db.currDKP)
		if currDKP then currDKP:AtMemberAdded() end
	end
	
	--update sync listeners
	local sync = self:GetModuleRef("Syncing")
	if sync then sync:MemberAdded(name) end
	
	tinsert(db.raidmembers, name)
end

function mod:RemoveMember(name)
	self:debug("Remove member.."..name)
	local raidnum = db.raidnum
	local ttime = time()
	if raidnum > 0 then
		if not db.raidlog[raidnum].leave then db.raidlog[raidnum].leave = { } end
		db.raidlog[raidnum].leave[name] = ttime
		self:out(fmt(L["%s left the raid at %s."], name, date("%I:%M:%S", ttime)))
	end
	for num, listname in pairs(db.raidmembers) do
		if name == listname then
			tremove(db.raidmembers, num)
			break
		end
	end
	
	if db.currDKP == "SKSotC" then
		local currDKP = self:GetModuleRef(db.currDKP)
		if currDKP then currDKP:AtMemberAdded() end
	end
	
	--update sync listeners
	local sync = self:GetModuleRef("Syncing")
	if sync then sync:UpdateClients(name, "-") end
end

function mod:GuildUpdate(event, update)
	if mdkp.querytooltips["listdkp"] then
		mdkp.querytooltips["listdkp"] = self:Onlinemembers(mdkp.querytooltips["listdkp"])
		self:ToggleFrameUpdate("listdkp")
	end
end

function mod:StartCombat()
	if not db.InRaid then return end
	mdkp.Starttime = time()
	if CHATLISTENING then self:ToggleChatListening() end
end

function mod:Scan()
	local SLOTS = {
		"HeadSlot",
		"NeckSlot",
		"ShoulderSlot",
		"BackSlot",
		"ChestSlot",
		"WristSlot",
		"HandsSlot",
		"WaistSlot",
		"LegsSlot",
		"FeetSlot",
		"Finger0Slot",
		"Finger1Slot",
		"Trinket0Slot",
		"Trinket1Slot",
		"MainHandSlot",
		"SecondaryHandSlot",
		"RangedSlot"
	}
	
	for i = 1, GetNumRaidMembers() do
		local name = UnitName("raid"..i)
		local _, class = UnitClass("raid"..i)
		self:PlayerinDB(name, class)
		if not db.info[name].items then db.info[name].items = { } end
		if CheckInteractDistance(name, 1) then
			NotifyInspect(name)
			for _, slot in pairs(SLOTS) do
				local itemLink = GetInventoryItemLink(name, GetInventorySlotInfo(slot))
				if itemLink then
					local _, _, itemCode = find(itemLink, "(%d+):")
					itemCode = tonumber(itemCode)
					if not self:ItemRecorded(itemCode, name) then
						tinsert(db.info[name].items, itemCode)
						self:debug("Added ".. name .. " slot: ".. slot ..";item ".. itemLink ..";ID: " .. itemCode)
					end
				else self:debug(name.."'s slot: "..slot.."; no item")
				end
			end
			self:debug("Scanned "..name) 
		end
	end
end

function mod:ItemRecorded(item, name)
	for _, ID in pairs(db.info[name].items) do
		if item == ID then
			return true
		end
	end
	return false
end

function mod:ItemQuery(id, link)
	if not self:ValidRaid() then 
		self:out(L["You must start a raid before you can start a query."]) 
		return false 
	end
	
	--scan current members for gear
	self:Scan()
	
	--who needs the query?
	local needquery = self:HasItem(id, link)
	if not needquery or #needquery == 0 then 
		self:out(L["Either no classes are selected or no members need this item."]) 
		return false
	end
	
	if mdkp.AuctionStatus[id] then 
		mdkp.AuctionStatus[id] = mdkp.AuctionStatus[id] + 1
		return false 
	else mdkp.AuctionStatus[id] = 1
	end
	
	local itempoints = db.items[id].points or 0
	mdkp.origitempoints[id] = itempoints
	local POOL = self:CheckPool(id)
	local points = {}
	mdkp.querytooltips[id] = {}
  		
	--module stuff
	self:IsDKPEnabled()
	local bidwar = self:GetModuleRef("BidWar")
	local whisper = self:GetModuleRef("Whisper")
	local currDKP = self:GetModuleRef(db.currDKP)
	local _, ref = currDKP:GetName()
	local lootframe = self:GetModuleRef("Lootframe")
	local isrand
	if mdkp.random[id] or ref == "Random" then 
		isrand = true 
		itempoints = 0
		RANDROLLID = id
		self:ToggleChatListening(true)
	end
	
	--send queries & create query table
	for _, data in pairs(needquery) do
		self:PointsPoolExists(data.n, POOL)
		local dkppoints = currDKP:GetPlayerPoints(data.n, POOL)
		if whisper then whisper:SendStartMessage(id, link, itempoints, data.n) end
		if isrand then dkppoints = 0 end
		points = {n = dkppoints, r = 0, g = 1, b = 0}
		if db.info[data.n].raidloot == 1 then points.r = 1 end
		tinsert(mdkp.querytooltips[id], {data, "PENDING", points, data.p})
	end
	
	local mbidtable = nil
	if db.mbidcustom then mbidtable = mdkp.statustext end
	
	if bidwar then bidwar:StartAuction(id, itempoints, mdkp.querytooltips[id], link, mbidtable)
	elseif ref == "TakeBid" then currDKP:StartAuction(id, itempoints, mdkp.querytooltips[id], link, mbidtable)
	else self:SendCommMessage("MorgBid2", self:Serialize("QUERY", id, itempoints, mdkp.querytooltips[id], db.quality, isrand, link, db.mbidupdating, mbidtable), "RAID")
	end
		
	self:debug(fmt("Query sent %s for %s DKP", id, itempoints))
	
	--create output message for classes
	local mainstring = L["Main: "]
	local altstring = L["Offspec: "]
	local isaltstring = nil
	if db.items[id].classes == 2047 then mainstring = mainstring .. L["ALL"] ..", "
	else
		for bitclass, bit in pairs(mdkp.Bits) do
			if bitclass ~= L["ALL"] then
				if band(db.items[id].classes, bit) == bit then
					mainstring = mainstring .. bitclass .. ", "
				end
				if band(db.items[id].altclasses, bit) == bit then
					altstring = altstring .. bitclass .. ", "
					isaltstring = true
				end
			end
		end
	end
	if bidwar then bidwar:StartOutput(link, id, itempoints) 
	else
		SendChatMessage(fmt(L["Now querying for %s  ID = %s  DKP = %s"], link, id, itempoints), "RAID")
		mainstring = sub(mainstring, 1, -3)
		SendChatMessage(mainstring, "RAID")
		if isaltstring then
			altstring = sub(altstring, 1, -3)
			SendChatMessage(altstring, "RAID")
		end
	end
  	lootframe:SortItemTT(id)
  	return true
end

function mod:ToggleChatListening(ON)
	if ON then
		if not CHATLISTENING then
			self:RegisterEvent("CHAT_MSG_SYSTEM")
			CHATLISTENING = true
		end
	elseif CHATLISTENING then
		self:UnregisterEvent("CHAT_MSG_SYSTEM") 
		CHATLISTENING = nil
	end
end

function mod:CHAT_MSG_SYSTEM(_, msg)
	if not msg then return end
	local _, _, player, roll, minRoll, maxRoll = find(msg, RANDOM_REGEX)
	if player then
		roll = tonumber(roll)
		minRoll = tonumber(minRoll)
		maxRoll = tonumber(maxRoll)
		if minRoll ~= 0 and maxRoll ~= 100 then
			self:out(player.." used incorrect roll format!")
			return
		end
		if RANDROLLID and mdkp.querytooltips[RANDROLLID] then
			for i,v in ipairs(mdkp.querytooltips[RANDROLLID]) do
				if v[1].n == player and v[2] == "PENDING" then
					v[2] = "NEED"
					v[3].n = roll
					self:ToggleFrameUpdate(RANDROLLID)
					break
				end
			end
		end
	end
end

function mod:HasItem(id, link)
	if not db.items[id] then return end
	local classes = db.items[id].classes
	local altclasses = db.items[id].altclasses
	local _, _, _, _, _, _, _, _, iEquipLoc, _ = GetItemInfo(id)
	local needquery = {}
	local neededclasses = {}
	local needed = nil
	local unique = true
	local twohander = nil
	
	--scan tooltip for non-unique item
	if link and not db.ignoreunique and (iEquipLoc == "INVTYPE_FINGER" or iEquipLoc == "INVTYPE_TRINKET" or iEquipLoc == "INVTYPE_WEAPON" or iEquipLoc == "INVTYPE_2HWEAPON") then
		self:debug("Possibility for non-unique"..(link or "NIL"))
		MorgDKP2_Scantip:ClearLines()
		MorgDKP2_Scantip:SetHyperlink(link)
		local lines = MorgDKP2_Scantip:NumLines()
		if lines then 
			local tiptext = _G["MorgDKP2_ScantipTextLeft3"]:GetText() 
			local found = find(tiptext or "", L["Unique"]) and not find(tiptext or "", L["Unique-equipped"])
			self:debug(tiptext)
			if not found then 
				unique = nil
				if iEquipLoc == "INVTYPE_2HWEAPON" then twohander = true end
			end
		end
	end
	
	--set up classlist
	for bitclass, bit in pairs(mdkp.Bits) do
		if bitclass ~= L["ALL"] then
			if band(classes, bit) == bit then
				neededclasses[bitclass] = 1	--1st priority
				needed = true
			elseif band(altclasses, bit) == bit then
				neededclasses[bitclass] = 2	--2nd priority
				needed = true
			end
		end
	end
	if not needed then return end
					
	--check roster for needy classes
	local hasitem
	for pname, subgroup in pairs(mdkp.roster) do
		if not db.ignore68 or (db.ignore68 and subgroup < 6) then 
			local pdata = self:GetClasscolors(pname)
			if neededclasses[pdata.c] then
				if db.info[pname] and db.info[pname].items then
					local items = db.info[pname].items
					hasitem = nil
					for _, hasID in pairs(items) do
						if hasID == id and (unique or (twohander and pdata.c ~= "WARRIOR")) then
							hasitem = 1
						end
					end
				end
				if db.ignoreunique or not hasitem then
					pdata.p = neededclasses[pdata.c]	--insert priority data
					tinsert(needquery, pdata)
				end
			end
		end
	end
	return needquery
end

function mod:MorgBidQuery()
	self:debug("Morgbid check")
	--if not self:ValidRaid() then return end
	local POOL = db.raid
	
	--modules
	self:IsDKPEnabled()
	local currDKP = self:GetModuleRef(db.currDKP)
	local namedata, pointsdata
		
	--populate query table
	mdkp.querytooltips["version"] = {}
  	for name in pairs(mdkp.roster) do
  		self:PointsPoolExists(name, POOL)
  		local points = currDKP:GetPlayerPoints(name, POOL)
  		namedata = self:GetClasscolors(name)
  		pointsdata = {n = points, r = 0, g = 1, b = 0}
  		if db.info[name].raidloot == 1 then pointsdata.r = 1 end
  		tinsert(mdkp.querytooltips["version"], {namedata, {n = "NONE", r = 1, g = 0, b = 0}, pointsdata, 0})
  	end
  	
  	--fetch a free frame & create popup
  	local hint = L["|c000070ddClick:|r Nag old versions now\n|c000070ddR-Click:|r Close tablet."]
   	local title = L["MorgBid2 Version Query"]
   	local f = self:GetFrame("version", hint, title)
  	self:ToggleFrameUpdate("version")
  	f:Show()
  	self:SendCommMessage("MorgBid2", self:Serialize("CHECK", mdkp.morgbid2version, db.mbidnag), "RAID")
end

function mod:WhisperUsers()
	db.mbidnag = true
	for _, data in pairs(mdkp.querytooltips["version"]) do
		if data[2] == "NONE" then SendChatMessage(L["Please install MorgBid2 to bid on items.  http://www.wowace.com/projects/morg-bid2/ Thank-you:)"], "WHISPER", nil, data[1].n) end
	end
	self:MorgBidQuery()
	db.mbidnag = nil
end

function mod:ListDKP(listtext)
	if not listtext then return end
	self:debug("ListDKP"..listtext)
	mdkp.querytooltips["listdkp"] = self:FillDKPTable(nil, nil, listtext, nil, true, true, db.showearned)
	
	--fetch a free frame & create popup
  	local hint = L["|c000070ddL-Click:|r Invite.\n|c000070ddCTRL-Click:|r Delete Character.\n|c000070ddALT-Click:|r Add to waitlist.\n|c000070ddSHIFT-Click:|r Remove from waitlist.\n|c000070ddR-Click:|r Close tablet."]
   	local title = L["List DKP"]
   	local f = self:GetFrame("listdkp", hint, title)
  	f:Show()
  	self:ToggleFrameUpdate("listdkp")
  	
  	--spam waitlist info
  	local wait = self:GetModuleRef("Waitlist")
	if wait then wait:SpamChannels() end
end

function mod:OnListDKPClick(name, status)
	if IsShiftKeyDown() then
		local wait = self:GetModuleRef("Waitlist")
		if wait then wait:SubWait(name) end
	elseif IsControlKeyDown() then
		db.info[name] = nil
		for num, v in pairs(mdkp.querytooltips["listdkp"]) do
			if v[1].n == name then
				tremove(mdkp.querytooltips["listdkp"], num)
				break
			end
		end
		self:out(fmt(L["Deleting %s from MorgDKP2 database."], name))
		self:ToggleFrameUpdate("listdkp")
	elseif IsAltKeyDown() then
		local wait = self:GetModuleRef("Waitlist")
		if wait then wait:AddWait(name) end
	else
		if status == L["WAIT"] or status == L["xWAITx"] then
			InviteUnit(name)
			local wait = self:GetModuleRef("Waitlist")
			if wait then name = wait:InformOnlineAlias(name) end
		end
		InviteUnit(name)
	end
end

function mod:ShowAliasTip(member)
	local POOL = db.raid
	local alts = {}
	for alt, main in pairs(db.eqDKP[POOL].Aliases) do
		if main == member then tinsert(alts, alt) end
	end
	if alts and #alts > 0 then
		GameTooltip:AddLine("Aliases:", 1, 1, 1)
		for _, alt in pairs(alts) do
			local name = self:GetClasscolors(alt)
			GameTooltip:AddLine(alt, name.r, name.g, name.b)
		end
		GameTooltip:Show()
	end
  		
end

function mod:Onlinemembers(dkplist)
	local guildmembers = self:GetOnlineGuildMembers()
	local status
	local POOL = db.raid
	local wait = self:GetModuleRef("Waitlist")
	local namedata, pointsdata
	for num, data in pairs(dkplist) do
		data[2] = self:GetStatus(data[1].n, guildmembers, wait)
		guildmembers[data[1].n] = nil
	end
	for name, data in pairs(guildmembers) do
		if data.o and db.info[name] then 
			namedata, pointsdata = self:GetDKPInfo(name, POOL)
			status = mdkp.guildstatustext[L["ONLINE"]]
			tinsert(dkplist, {namedata, status, pointsdata}) 
		end
	end
	return dkplist
end

function mod:UserDataReturned(user, time)
	if not user or not self.whoque[user.Name] then return end
	self.whoque[user.Name] = nil
	self:UpdateUser(user.Name, user.Online)
end

function mod:UpdateUser(name, Online)
	if not mdkp.querytooltips["listdkp"] then return end
	local members = mdkp.querytooltips["listdkp"]
	
	for num, data in pairs(members) do
		if data[1].n == name then
			local status, waittime = self:GetOutGuildStatus(name, Online)
			data[2] = status
			if waittime then
				waittime = sub(waittime, -8)
				data[3] = {n = waittime, r = 1, g = 1, b = 0}
			end
			break
		end
	end
	self:ToggleFrameUpdate("listdkp")
end

function mod:GetStatus(name, guildmembers, wait)
	local isonwait, waittime, status
	local inraid = UnitInRaid(name)
	local guilddata = guildmembers[name]
	if wait then isonwait, waittime = wait:IsOnWaitlist(name) end
	if guilddata then 
		if guilddata.o then
			if inraid then
				if guilddata.s == "<AFK>" then status = mdkp.guildstatustext["<AFK>"]
				else status = mdkp.guildstatustext[L["INRAID"]] 
				end
			elseif isonwait then status = mdkp.guildstatustext[L["WAIT"]]
			else status = mdkp.guildstatustext[L["ONLINE"]]
			end
		elseif inraid then status = mdkp.guildstatustext[L["xINRAIDx"]] 
		elseif isonwait then status = mdkp.guildstatustext[L["xWAITx"]]
		else status = mdkp.guildstatustext[L["OFFLINE"]]
		end
	elseif inraid then status = mdkp.guildstatustext[L["INRAID"]] 
	elseif isonwait then status = mdkp.guildstatustext[L["WAIT"]]
	else 
		if not self.whoque[name] then
			self:debug("Getting outguild data for "..name)
			local user, time = self:UserInfo(name, { callback = 'UserDataReturned', timeout = 10} )
			if user then 
				status = self:GetOutGuildStatus(name, user.Online) 
			else 
				self.whoque[name] = true
				status = mdkp.guildstatustext[L["OFFLINE"]] 
			end
		else 
			status = mdkp.guildstatustext[L["OFFLINE"]] 
		end
	end
	return status, waittime
end

function mod:GetOutGuildStatus(name, Online)
	local status
	local isonwait, waittime
	local inraid = UnitInRaid(name)
	local wait = self:GetModuleRef("Waitlist")
	if wait then isonwait, waittime = wait:IsOnWaitlist(name) end
	if Online then
		if inraid then status = mdkp.guildstatustext[L["INRAID"]] 
		elseif isonwait then status = mdkp.guildstatustext[L["WAIT"]]
		else status = mdkp.guildstatustext[L["ONLINE"]]
		end
	elseif inraid then status = mdkp.guildstatustext[L["xINRAIDx"]] 
	elseif isonwait then status = mdkp.guildstatustext[L["xWAITx"]]
	else status = mdkp.guildstatustext[L["OFFLINE"]]
	end
	return status, waittime
end

function mod:GetOnlineGuildMembers()
	local numGuildMembers = GetNumGuildMembers(true)
	local Onlinemembers = {}
	for i = 1, numGuildMembers do
		local name, _, _, _, _, _, _, _, online, status = GetGuildRosterInfo(i)
		if name then Onlinemembers[name] = {o = online, s = status} end
	end
	return Onlinemembers
end

function mod:FillDKPTable(sender, senderclass, txt, raided, showstatus, islistdkp, showearned)
	local POOL = db.raid
	if not POOL then return end
	local dkplist = {}
	local namedata, pointsdata
	txt = upper(txt)
	
	--add for ALL/add sender if needed
	if find(txt, "ALL") then
		txt = "DKPLIST DRUID HUNTER MAGE PALADIN PRIEST ROGUE SHAMAN WARLOCK WARRIOR DEATHKNIGHT"
	elseif senderclass and not find(txt, upper(senderclass)) then
		txt = txt .. " ".. upper(senderclass)
	end
	
	local args = {self:Explode(txt, " ")}
	
	--is pool in txt?
	for _, name in pairs(db.raidlist) do
		if upper(name) == args[2] then
			POOL = name
		end
	end
	
	--modules
	self:IsDKPEnabled()
	
	if not db.eqDKP[POOL] then db.eqDKP[POOL] = {["Events"] = {}, ["Aliases"] = {}} end
	
	--format table for output
	local guildmembers = self:GetOnlineGuildMembers()
	local wait = self:GetModuleRef("Waitlist")
	local numargs = #args
	for i = 2, numargs do
		local class = args[i]
		if raided then
			for pname in pairs(mdkp.roster) do
				local pclass = db.info[pname].class
				if pclass == class then
					namedata, pointsdata = self:GetDKPInfo(pname, POOL)
  					tinsert(dkplist, {namedata, pointsdata}) 
				end
			end
		else
			for pname, data in pairs(db.info) do
				if data.class and data.class == class then
					local status, waittime = self:GetStatus(pname, guildmembers, wait) 
					if not db.eqDKP[POOL].Aliases[pname] or (db.eqDKP[POOL].Aliases[pname] and islistdkp and (status.n ~= L["OFFLINE"] or self.whoque[pname])) then
						namedata, pointsdata = self:GetDKPInfo(pname, POOL, showearned)
						if showstatus then
  							if waittime then
  								waittime = sub(waittime, -8)
								pointsdata = {n = waittime, r = 1, g = 1, b = 0}
							end
							if not wait or (wait and not wait:IsAltOnWait(pname)) then tinsert(dkplist, {namedata, status, pointsdata}) end
  						else tinsert(dkplist, {namedata, pointsdata}) end
  					end
  				end
			end
		end
	end
	return dkplist, POOL
end

function mod:OnMorgBidCommReceive(prefix, message, distribution, sender)
	--self:debug("Addon message..."..prefix..message..distribution..sender)
	local result, command, item, points, roll = self:Deserialize(message)
	if command == "PASS" or command == "TAKE" or command == "NEED" or command == "OFFSPEC" then
		--self:debug("From "..sender..": "..command)
		if not mdkp.querytooltips[item] then
			--self:debug("No query for "..item)
			return
		end
		local bidwar = self:GetModuleRef("BidWar")
		local takebid = self:GetModuleRef("TakeBid")
		local rand = self:GetModuleRef("Random")
		for i,v in ipairs(mdkp.querytooltips[item]) do
			if v[1].n == sender then
				v[2] = command
				if v[1].n == Player and takebid then takebid:AddBids(item) end
				if command ~= "PASS" or (command == "PASS" and bidwar) then
					if bidwar then 
						if command == "PASS" then v[3].n = 0 
						else v[3].n = bidwar:OnBidMessage(points, sender, item, command) 
						end
						if v[1].n == Player then bidwar.master[item] = true end
					elseif takebid then
						if command == "TAKE" then 
							if takebid.master[item] then v[3].n = points
							else 
								v[3].n = 0
								v[5] = points
							end
						end						
					elseif rand or mdkp.random[item] then v[3].n = roll or math.random(100)
					end
					break
				end
			end
		end
		if not bidwar or (bidwar and not bidwar.db.profile.silent) or (bidwar and bidwar.db.profile.silent and bidwar.master[item]) then
			self:ToggleFrameUpdate(item)
		end
	elseif command == "REPLY" then
		if not mdkp.querytooltips["version"] then
			--self:debug("No version query exists.") 
			return
		end
		local version
		for i,v in ipairs(mdkp.querytooltips["version"]) do
			if v[1].n == sender then 
				if points < mdkp.morgbid2version then v[2].g = 1
				else v[2].r, v[2].g = 0, 1 end
				if roll then v[2].n = roll
				else v[2].n = points end
				v[4] = points
				break
			end
		end
		self:ToggleFrameUpdate("version")
	elseif command == "ITEMLOOTED" then
		self:RecordLoot(nil, sender, item)
	end
end

function mod:GetFrame(name, hint, title)
	if not mdkp.frames[name] then
		local ondragstart = function(f) f:StartMoving() end
		local ondragstop =  function(f)
   						f:StopMovingOrSizing()
   						local point, _, relativePoint, x, y = f:GetPoint()
						self.db.profile.frames[name] = {point = point, relpoint = relativePoint, x = x, y = y}
   					end
   		local onmouseup = function(f, button) if button == "RightButton" then mdkp.querytooltips[f.datacheck] = nil f:Hide() end end 
   		local onupdate = function(f) self:FrameUpdate(f) end
   		mdkp.frames[name] = self:Createframe(nil, nil, nil, onupdate, onmouseup, hint, name, nil, nil, title, ondragstart, ondragstop, true)
		
		local f = mdkp.frames[name]
		local framepos = self.db.profile.frames[name]
		local point, relpoint, x, y = framepos.point, framepos.relpoint, framepos.x, framepos.y
		f:SetPoint(point, UIParent, relpoint, x, y)
	
		f.close = CreateFrame("Button", nil, f)
   		f.close:SetScript("OnClick", function(f) mdkp.querytooltips[f:GetParent().datacheck] = nil f:GetParent():Hide() end)
   		f.close:SetWidth(20)
   		f.close:SetHeight(20)
   		f.close:SetNormalTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up")
   		f.close:SetPushedTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Down")
   		f.close:SetHighlightTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight")
   		f.close:ClearAllPoints()
   		f.close:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
   		f.close:SetHitRectInsets(5, 5, 5, 5)
   		f.close:Show()
   	end
   	return mdkp.frames[name]
end

function mod:IncomingWhispers(command, sender, actions)
	local raided = UnitInRaid(sender)
	
	--player class
	local pdata = self:GetClasscolors(sender)
	local pclass = pdata.c
	
	--actions
	if command == "MBID" then 
		--waitlist??
		if find(actions, L["WAIT"]) then 
			local wait = self:GetModuleRef("Waitlist")
			if wait then wait:OnWaitWhisper(sender, actions) end
			return 
		end
		
		--format correct?
		local args = {}
		local _,_, item = find(actions, "ITEM:(%d+):")
		if item then
			args[1] = sub(actions, 1, 4)
			args[2] = item
			local sstart, send = find(actions, "]")
			if sstart then args[3] = sub(actions, sstart + 6) end
			local sstart, send = find(args[3], " ")
			if sstart then 
				args[4] = sub(args[3], sstart + 1) 
				args[3] = sub(args[3], 1, sstart - 1)
			end
		else 
			args = {self:Explode(actions, " ")}
			item = args[2]
		end
		item = tonumber(item)
		if #args < 3 then SendChatMessage(fmt(L["Sorry your response format is incorrect or no item with that ID is up for bidding.  Format = mbid [ID/link] [%s/%s/%s/%s] [bid value]"], db.NEED, db.TAKE, db.OFFSPEC or "", db.PASS), "WHISPER", nil, sender) return end
	
		--item in auction?
		if not mdkp.AuctionStatus[item] then
			SendChatMessage(L["This item is not currently up for bid."], "WHISPER", nil, sender)
			return
		end
		
		local bidwar = self:GetModuleRef("BidWar")
		local takebid = self:GetModuleRef("TakeBid")
		
		local BID
		if args[3] == db.PASS or args[3] == L["PASS"] or args[3] == "PASS" then BID = "PASS"
		elseif args[3] == db.NEED or args[3] == L["NEED"] or args[3] == "NEED" then BID = "NEED"
		elseif args[3] == db.TAKE or args[3] == L["TAKE"] or args[3] == "TAKE" then BID = "TAKE"
		elseif args[3] == db.OFFSPEC or args[3] == L["OFFSPEC"] or args[3] == "OFFSPEC" then BID = "OFFSPEC"
		end
		if not args[4] then
			local rand = self:GetModuleRef("Random")
			for i,v in pairs(mdkp.querytooltips[item]) do
				if v[1].n == sender then
					v[2] = BID
					SendChatMessage(fmt(L["Your response has been accepted: %s"], args[3]), "WHISPER", nil, sender)
					if (rand or mdkp.random[item]) and BID ~= "PASS" then v[3].n = math.random(100) end
				end
			end
		else
			--bidwar??
			if bidwar and args[4] then bidwar:OnBidWhisper(sender, item, BID, args[4])
			elseif takebid then takebid:OnBidWhisper(sender, item, BID, args[4])			
			else SendChatMessage(fmt(L["Sorry your response format is incorrect or no item with that ID is up for bidding.  Format = mbid [ID/link] [%s/%s/%s/%s] [bid value]"], db.NEED, db.TAKE, db.OFFSPEC or "", db.PASS), "WHISPER", nil, sender) return end
		end
		if not bidwar or bidwar.master[item] then self:ToggleFrameUpdate(item) end
		return
	end
	--output pools if toggle
	if command == "DKPL" and find(actions, "POOLS") then 
		self:ShowPools(sender)
		return
	end
	
	--send dkplist results
	local dkplist, pool = self:FillDKPTable(sender, pclass, actions, raided)
	sort(dkplist, function(a,b) return a[2].n > b[2].n end)
	local distribution
	if IsInGuild() then distribution = "GUILD" end
	if UnitInRaid(sender) then distribution = "RAID" end
	if distribution then 
		self:SendCommMessage("MorgBid2", self:Serialize("INITIATE", sender), distribution)
		self:SendCommMessage("MorgBid2", self:Serialize("DKPL", sender, dkplist, pool), distribution)
	else self:debug("Not in guild!  Can't send addon message.") end
end

function mod:ShowPools(sender)
	SendChatMessage(L["Currently loaded DKP pools..."], "WHISPER", nil, sender)
	local counter = 1
	for _, name in pairs(db.raidlist) do
		SendChatMessage(counter .. ". " .. name, "WHISPER", nil, sender)
		counter = counter + 1
	end
	SendChatMessage(L["Please whisper: dkplist [poolname] [class] [class] .... [all]"], "WHISPER", nil, sender)
end

function mod:AddAlias(alt, main, quiet, POOL, skipsync)
	self:debug("addalias"..alt.." of "..main)
	if not POOL then POOL = db.raid end
	mainpoints = 0
	
	--return if no main
	if db.info[main] and db.info[main][POOL] then mainpoints = db.info[main][POOL].points
	else
		if not quiet then self:out(fmt(L["Main character %s does not exist.  No changes made."], main)) end
		return
	end
	
	--return if alias exists
	if db.eqDKP[POOL].Aliases and db.eqDKP[POOL].Aliases[alt] then
		if not quiet then self:out(fmt(L["Alias %s already exihists.  No changes made."], alt)) end
		return
	end
	
	--add alias
	self:out(fmt(L["Transeferred %s DKP to %s from %s"], mainpoints, alt, main))
	self:PlayerinDB(alt)
	db.info[alt][POOL]  =  {points = mainpoints,
				earned = db.info[main][POOL].earned,
				spent = db.info[main][POOL].spent}
	db.info[alt].raidloot = 0
	if not self:DoesAliasExist(main, alt, POOL) then 
		self:PlayerinDB(main)
		tinsert(db.info[main].aliases, {raid = POOL, alt = alt}) 
	end
	local update = self:GetServerTime()
	db.info[main].lastupdate = update
	db.info[alt].lastupdate = update
	if not db.raidlog.aliases then db.raidlog.aliases = { } end
	if not db.raidlog.aliases[POOL] then db.raidlog.aliases[POOL] = { } end
	tinsert(db.raidlog.aliases[POOL], {alt = alt,
						main = main,
						eqdkp = db.eqDKP[POOL].eqDKPsite,
						action = "ADD" })
	db.eqDKP[POOL].Aliases[alt] = main
	
	--add to sync list
	if not skipsync then
		local sync = self:GetModuleRef("Syncing")
		if sync then sync:AddAliastoSync(alt, main, POOL) end	
	end
end

function mod:DoesAliasExist(main, alt, pool)
	if not db.info[main] or not db.info[main]["aliases"] then return nil end
	for _, aliasdata in pairs(db.info[main]["aliases"]) do
		if aliasdata.alt == alt and aliasdata.raid == pool then
			return true
		end
	end
end

function mod:GiveBOE(name)
	self:debug("Give BOE to "..name)
	local itemlink = mdkp.boelink
	mod:RecordLoot(itemlink, name, nil, true)
end

function mod:RecordLoot(itemlink, player, itemId, BOE)
	if db.raidnum < 1 then self:out(L["No current raid exists."]) return end
	if not itemId then
		_,_, itemId = find(itemlink, "item:(%d+):")
		itemId = tonumber(itemId)
	end
	
	--is this item ignored?
	if db.ignore[itemId] == true then self:debug("Item Ignored") return end
		
	--get item info
	local sName, iLink, iQuality, _, _, class, subclass, _, iEquipLoc, iconGIF = GetItemInfo(itemId)
	
	--activate scanning if not in cache
	if not iQuality then
		self:ScanTooltip(itemId, player)
		return
	end
	
	--return if qual < threshold
	if iQuality < db.quality then self:debug("Below threshold..") return end
	
	--determine what mob dropped item
	local PT = LibStub("LibPeriodicTable-3.1"):ItemSearch(itemId)
	local lootTime = time()
	local lastboss = db.raidlog.lastboss
	local lastmob = db.raidlog.lastmob
	local BossMob
	local disenchanted
	local sync = self:GetModuleRef("Syncing")
	
	if PT then
		for _, v in pairs(PT) do
			local set, instance, boss = strsplit(".", v)
			if set:match("^InstanceLoot") then
				BossMob = mdkp.chests[boss] or boss
			end
		end
	end
	--failsafe
	if not BossMob then BossMob = lastboss end
	--special mobs
	if BossMob == L["Assembly of Iron"] or BossMob == BB["Runemaster Molgeim"] or BossMob == BB["Steelbreaker"] or BossMob == BB["Stormcaller Brundir"] then
		BossMob = BB["The Iron Council"]
	elseif BossMob == BB["High Nethermancer Zerevor"] or BossMob == BB["Gathios the Shatterer"] or BossMob == BB["Lady Malande"] or BossMob == BB["Veras Darkshadow"] then
		BossMob = BB["Illidari Council"]
	end
	if BossMob ~= lastboss and BossMob ~= "Trash Mobs" then BossMob = lastboss end
	local match = nil
	for _, bossname in pairs(mdkp.ZoneBosses[db.menuzone]) do
  		if BossMob == bossname then
  			match = true
  			break
  		end
  	end
  	if not BossMob or db.OneEvent or not match or BOE then BossMob = "Trash mob" end
	
	--remove hash for eqdkp+
	if db.eqdkp then BossMob = gsub(BossMob, "'", "") end
	
	local POOL = self:CheckPool(itemId)
	if mdkp.MLmode and (player == db.mlooter or player == db.disenchanter) and not mdkp.given then 
		disenchanted = true
		if self:ItemAlreadyLooted(itemId, player, BossMob, lootTime) then return end
		BossMob = L["Bank"]
		player = L["Bank"]
	else 
		mdkp.given = nil 
	end
	
	--is it recorded already?
	if self:ItemAlreadyLooted(itemId, player, BossMob, lootTime) then return end
	
	
	--modules
	self:IsDKPEnabled()
	local currDKP = self:GetModuleRef(db.currDKP)
	local bidwar = self:GetModuleRef("BidWar")
	
	--determine item value etc
	self:IteminDB(itemId)
	self:PointsPoolExists(player, POOL)
	local points = currDKP:GetPlayerPoints(player, POOL)
	local itempoints = 0
	if not disenchanted then itempoints = currDKP:GetItemValue(itemId, player, POOL) end
	local Zone = GetRealZoneText()
	
	--determine if need a sync
	if sync and not disenchanted then
		if BOE then sync:ManualItem(itemlink, player) 
		else sync:ItemValidate(itemId, itempoints, player, POOL, BossMob) end
	end
	
	--insert item data into raidlog
	tinsert(db.raidlog[db.raidnum].loot,
					{
						["ItemName"] = sName,
						["ItemLink"] = iLink,
						["Quality"] = iQuality,
						["ID"] = itemId,
						["Icon"] = iconGIF,
						["Class"] = class,
						["SubClass"] = subclass,
						["Player"] = player,
						["Costs"] = itempoints,
						["Time"] = lootTime,
						["Zone"] = Zone,
						["Boss"] = BossMob,
						["eqdkp"] = db.eqDKP[POOL].eqDKPsite or "UNKNOWN",
						["prefix"] = db.eqDKP[POOL].prefix or "UNKNOWN"
					}
				)
	
	if mdkp.AuctionStatus[itemId] then
		if mdkp.AuctionStatus[itemId] > 1 then mdkp.AuctionStatus[itemId] = mdkp.AuctionStatus[itemId] - 1
		elseif mdkp.AuctionStatus[itemId] == 1 then 
			mdkp.AuctionStatus[itemId] = nil
			mdkp.spammed[itemId] = nil
			self:SaveAuctionData(itemId)
			mdkp.querytooltips[itemId] = nil
		end
	end
	
	if not disenchanted then
		--deduct points from player etc
		currDKP:ItemRecorded(itemId, player, POOL, points, itempoints, iLink, db.raidmembers, BossMob)
		if bidwar then bidwar:ItemRecorded(itemId) end
	
		--add item into player DB
		if iEquipLoc ~= "" then
			if not db.info[player].items then db.info[player].items = {} end
			if not self:ItemRecorded(itemId, player) then
				tinsert(db.info[player].items, itemId)
			end
		end
	end
	local raidtracker = self:GetModuleRef("RaidTracker")
	if raidtracker then raidtracker:ForceRaidUpdate() end
	self:ToggleFrameUpdate("TooltipLDB")
end

function mod:ItemAlreadyLooted(ID, winner, boss, time)
	for _, lootdata in pairs(db.raidlog[db.raidnum].loot) do
		if (lootdata.ID == ID and lootdata.Player == winner and lootdata.Boss == boss) then
			if time - lootdata.Time < 60 then return true end
		end
	end
	return false
end

function mod:SaveAuctionData(id)
	if not mdkp.querytooltips[id] then return end
	db.raidlog[db.raidnum].queries[id] = {}
	for _, data in ipairs(mdkp.querytooltips[id]) do
		tinsert(db.raidlog[db.raidnum].queries[id], {[1] = data[1].n, [2] = data[2], [3] = data[3].n})
	end
end

function mod:ScanTooltip(item, player)
	self:debug("Start scanning .."..item)
	MorgDKP2_Scantip:ClearLines()
	MorgDKP2_Scantip:SetHyperlink('item:'..item)
	self.scanid = item
	self.scanplayer = player
	MorgDKP2_Scantip:SetScript('OnTooltipSetItem', function() return mod:OnTooltipSetItem() end)
end

function mod:OnTooltipSetItem()
	mod:debug("Returned itemlookup")
	if GetItemInfo(mod.scanid) then
		MorgDKP2_Scantip:SetScript('OnTooltipSetItem', nil)
		mod:RecordLoot(nil, self.scanplayer, self.scanid)
	end
end