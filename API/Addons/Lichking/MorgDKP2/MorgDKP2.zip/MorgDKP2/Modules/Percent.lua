local mod = MorgDKP2:NewModule("Percent")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.Percent

local mdkp = MorgDKP2

mod.modName = LL["Percent DKP"]
mod.modref = "Percent"

local Player = UnitName("player")
local floor = math.floor
local fmt = string.format
local db

local defaults = { 
	profile = {
		percent = 50,
		percenttake = nil,
	},
}

local options = {
		percentdkp = {
			type = "toggle",
			name = LL["Percent DKP"],
			desc = LL["Items will cost a percentage of the members total DKP."],
			get = function() return mdkp.db.profile.modules.Percent end,
			set = 	function(info, v) 
					mdkp.db.profile.modules.Percent = v
					mod:DKPChange(mod.modName)
			end,
			order = 35
		},
		percenthead = {
			type = "header",
			name = LL["Percent DKP Options"],
			hidden = function() return not mdkp.db.profile.modules.Percent end,
			order = 100
		},
		percent = {
			type = "range",
			name = LL["Percent cost"],
			get = function() return mod.db.profile.percent end,
			set = function(info, v) mod.db.profile.percent = v end,
			min = 1, 
			max = 100, 
			step = 1,
			hidden = function() return not mdkp.db.profile.modules.Percent end,
			order = 110
		},
		ptake = {
			type = "toggle",
			name = LL["Percent take"],
			desc = LL["When using the percent DKP system this option enables TAKE looting.  This means if the winning member rolled TAKE he will not be charged x% DKP he will instead be charged the base price of the item (Set using original itempoints."],
			get = function() return mod.db.profile.percenttake end,
			set = function(info, v) mod.db.profile.percenttake = v end,
			hidden = function() return not mdkp.db.profile.modules.Percent end,
			order = 120
		},
}

function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return true
end

function mod:GetName()
	return mod.modName, mod.modref
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("Percent", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile
	db.moduleON["Percent"] = true
	
end

function mod:OnDisable()
	db.moduleON["Percent"] = nil
end

function mod:GetPlayerPoints(name, POOL, showearned)
	if showearned then return db.info[name][POOL].earned
	else return db.info[name][POOL].points end
end

function mod:GetItemValue(itemid, player, POOL)
	local points = self:GetPlayerPoints(player, POOL)
	local itempoints = floor((points * self.db.profile.percent/100)  + 0.5)
	if self.db.profile.percenttake then
		if mdkp.querytooltips[itemid] then
			for  i,v in pairs(mdkp.querytooltips[itemid]) do
				if v[1].n == player then
					if v[2] == "TAKE" then itempoints = mdkp.origitempoints[itemid]  end
					break
				end
			end
		end
	end
	
	return itempoints
end

function mod:ItemRecorded(id, looter, POOL, points, itempoints, link)
	if looter == L["Bank"] then return end
	points = points - itempoints
	self:AwardItem(id, looter, POOL, points, itempoints, link)
end

function mod:ItemRebate(id, looter, POOL, itempoints, link)
	if not id or looter == L["Bank"] then return end
	self:AdjustDKPPoints(looter, looter, POOL, nil, itempoints)
end
