local mod = MorgDKP2:NewModule("Random")
local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local LL = L.Random

local mdkp = MorgDKP2
local db 
	
mod.modName = LL["Random rolls"]
mod.modref = "Random"

local Player = UnitName("player")
local fmt = string.format

local defaults = { 
	profile = {
		
	},
}

local options = {
		randomdkp = {
			type = "toggle",
			name = LL["Random rolls"],
			desc = LL["Enable random rolling for items."],
			get = function() return mdkp.db.profile.modules.Random end,
			set = 	function(info, v) 
					mdkp.db.profile.modules.Random = v
					mod:DKPChange(mod.modName)
			end,
			order = 15
		},
}

function mod:GetOptions()
	return options
end

function mod:IsDKP()
	return true
end

function mod:GetName()
	return mod.modName, mod.modref
end

function mod:OnInitialize()
	self.db = mdkp.db:RegisterNamespace("Random", defaults)
	
end

function mod:OnEnable()
	db = mdkp.db.profile	
	db.moduleON["Random"] = true
	
end

function mod:OnDisable()
	db.moduleON["Random"] = nil
end

function mod:GetPlayerPoints(name, POOL, showearned)
	if showearned then return db.info[name][POOL].earned
	else return db.info[name][POOL].points end
end

function mod:GetItemValue(itemid)
	return 0
end

function mod:ItemRecorded(id, looter, POOL, points, itempoints, link)
	if looter == L["Bank"] then return end
	db.info[looter].raidloot = 1
	db.info[looter].lastupdate = self:GetServerTime()
	self:out(fmt(LL["%s received %s."], looter, link))
end

function mod:ItemRebate(id, looter, POOL, itempoints, link)
	
end
