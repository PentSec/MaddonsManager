﻿local L = LibStub("AceLocale-3.0"):NewLocale("MorgDKP2", "ruRU")
if not L then return end

L["Abandon all hope! The Legion has returned to finish what was begun so many years ago. This time, there will be no escape!"] = "Оставьте надежду! Легион вернулся, чтобы завершить то, что было начато много лет назад. На этот раз спасения не будет!"
L["Add a custom raid event.  This will record all attendees when you click the event menu by adding Attempt to the end of the boss name you have targeted.  You can change event name value through raid tracker.  SHIFT-Click to bypass menu."] = "Добавить событие в текущий рейд. Вы можете изменить название события в менеджере рейдов. SHIFT-Click для вызова меню."
L["Added %s DKP to %s."] = "Начислено %s DKP для %s."
L["Added %s DKP to %s attendees."] = "Начислено %s DKP для %s учасника(ов)."
L["Added %s DKP to waitlist attendees."] = "Начислено %s DKP участника(ам) из списка ожидания."
L["Added %s to ignore list."] = "%s Внесен в черный список."
L["Alexstrasza's Gift"] = "Дар Алекстразы"
L["Alias %s already exihists.  No changes made."] = "Псевдоним %s уже существует. Изменения не произведены."
L["ALL"] = "Все"
L["Allow the OFFSPEC button to be used in MorgBid2."] = "Разрешить использование кнопки \"Оффспек\" в MorgBid2"
L["Allow updating bid results in MorgBid2."] = "Всегда обновлять результаы ставок в MorgBid2."
L["Amani Dragonhawk Spirit"] = "Дух аманийского дракондора"
L["Anything below this quality threshold will NOT be logged."] = "Все ниже этого уровня качества не будет зарегистрировано."
L["Artifact"] = "|c00e6cc80Артефакт|r"
L["A shallow and tragic victory. We are weaker as a whole from the losses suffered today. Who but the Lich King could benefit from such foolishness? Great warriors have lost their lives. And for what? The true threat looms ahead - the Lich King awaits us all in death."] = "Пустая и горькая победа. После сегодняшних потерь мы стали слабее как целое. Кто еще, кроме Короля-лича, выиграет от подобной глупости? Пали великие воины. И ради чего? Истинная опасность еще впереди – нас ждет битва с Королем-личом."
L["Assembly of Iron"] = "Железное собрание"
L["Automatically enable MorgDKP2 and start a raid when entering a trackable zone."] = "Автоматически начинает рейд если зона есть в списке автозон."
L["Autozone"] = "Автозона"
L["Background color"] = "Цвет фона"
L["Background texture"] = "Текстура фона"
L["Background texture of frames/tooltips."] = "Текстура фона для окон/подсказок"
L["Bank"] = "Предмет получен ML/DE"
L["Border color"] = "Цвет границ"
L["Border texture"] = "Текстура границ"
L["Border texture of frames/tooltips."] = "Текстура границ для окон/подсказок"
L["Boss attempt mode"] = "Попытка Босса"
L["Boss Attempt Mode"] = "Попытка Босса"
L[ [=[|c000070ddClick:|r MorgBid2 Base query.
|c000070ddALT-Click:|r Toggle ML/DE
|c000070ddSHIFT-Click:|r Invite & Waitlist.
|c000070ddCTRL-Click:|r Raid Tracker.
|c000070ddCTRL-Click Itemlink:|r Ignore item.]=] ] = [=[|c000070ddClick:|r Проверка MorgBid2.
|c000070ddALT-Click:|r Переключить ML/DE
|c000070ddSHIFT-Click:|r Пригласить & Список ожидания.
|c000070ddCTRL-Click:|r Менеджер рейда.
|c000070ddCTRL-Click Предмет:|r Игнорировать предмет.]=]
L[ [=[|c000070ddClick:|r Nag old versions now
|c000070ddR-Click:|r Close tablet.]=] ] = [=[|c000070ddClick:|r Напомнить о старых версиях сейчас
|c000070ddR-Click:|r Закрыть таблицу.]=]
L[ [=[|c000070ddL-Click:|r Invite.
|c000070ddCTRL-Click:|r Delete Character.
|c000070ddALT-Click:|r Add to waitlist.
|c000070ddSHIFT-Click:|r Remove from waitlist.
|c000070ddR-Click:|r Close tablet.]=] ] = [=[|c000070ddL-Click:|r Пригласить.
|c000070ddSHIFT-Click:|r Исключить.
|c000070ddCTRL-Click:|r Удалить персонажа.
|c000070ddALT-Click:|r В список ожидания.
|c000070ddR-Click:|r Закрыть окно.]=]
L["|c001eff00ON|r"] = "|c001eff00Вкл.|r"
L["|c009d9d9dOFF|r"] = "|c009d9d9dВыкл.|r"
L["Cache of Innovation"] = "Склад изобретателя"
L["Cache of Living Stone"] = "Ларь из живящего камня"
L["Cache of Storms"] = "Тайник Торима"
L["Cache of the Firelord"] = "Тайник повелителя огня"
L["Cache of Winter"] = "Тайник Ходира"
L["|cff0070dd|Hitem:14344:0:0:0:0:0:0:0|h[Large Brilliant Shard]|h|r"] = "|cff0070dd|Hitem:14344:0:0:0:0:0:0:0|h[Большой сверкающий осколок]|h|r"
L["|cff0070dd|Hitem:22448:0:0:0:0:0:0:0|h[Small Prismatic Shard]|h|r"] = "|cff0070dd|Hitem:22448:0:0:0:0:0:0:0|h[Малый радужный осколок]|h|r"
L["|cff0070dd|Hitem:22449:0:0:0:0:0:0:0|h[Large Prismatic Shard]|h|r"] = "|cff0070dd|Hitem:22449:0:0:0:0:0:0:0|h[Большой радужный осколок]|h|r"
L["|cffa335ee|Hitem:18562:0:0:0:0:0:0:0|h[Elementium Ore]|h|r"] = "|cffa335ee|Hitem:18562:0:0:0:0:0:0:0|h[Элементиевая руда]|h|r"
L["|cffa335ee|Hitem:20725:0:0:0:0:0:0:0|h[Nexus Crystal]|h|r"] = "|cffa335ee|Hitem:20725:0:0:0:0:0:0:0|h[Кристалл-источник]|h|r"
L["|cffa335ee|Hitem:22450:0:0:0:0:0:0:0|h[Void Crystal]|h|r"] = "|cffa335ee|Hitem:22450:0:0:0:0:0:0:0|h[Кристалл Бездны]|h|r"
L["|cffa335ee|Hitem:29434:0:0:0:0:0:0:0|h[Badge of Justice]|h|r"] = "|cffa335ee|Hitem:29434:0:0:0:0:0:0:0|h[Знак справедливости]|h|r"
L["|cffa335ee|Hitem:32230:0:0:0:0:0:0:0|h[Shadowsong Amethyst]|h|r"] = "|cffa335ee|Hitem:32230:0:0:0:0:0:0:0|h[Аметист Песни Теней]|h|r"
L["|cffa335ee|Hitem:34057:0:0:0:0:0:0:0:80|h[Abyss Crystal]|h|r"] = "|cffa335ee|Hitem:34057:0:0:0:0:0:0:0:80|h[Кристалл пропасти]|h|r"
L["|cffa335ee|Hitem:40752:0:0:0:0:0:0:0:80|h[Emblem of Heroism]|h|r"] = "|cffa335ee|Hitem:40752:0:0:0:0:0:0:0:80|h[Эмблема героизма]|h|r"
L["|cffa335ee|Hitem:40753:0:0:0:0:0:0:0:80|h[Emblem of Valor]|h|r"] = "|cffa335ee|Hitem:40753:0:0:0:0:0:0:0:80|h[Эмблема доблести]|h|r"
L["|cffa335ee|Hitem:45624:0:0:0:0:0:0:0:80|h[Emblem of Conquest]|h|r"] = "|cffa335ee|Hitem:45624:0:0:0:0:0:0:0:80|h[Эмблема завоевания]|h|r"
L["|cffa335ee|Hitem:47241:0:0:0:0:0:0:0:80|h[Emblem of Triumph]|h|r"] = "|cffa335ee|Hitem:47241:0:0:0:0:0:0:0:80|h[Эмблема триумфа]|h|r"
L["|cffff8000|Hitem:30311:0:0:0:0:0:0:0|h[Warp Slicer]|h|"] = "|cffff8000|Hitem:30311:0:0:0:0:0:0:0|h[Искореженная ломтерезка]|h|r"
L["|cffff8000|Hitem:30312:0:0:0:0:0:0:0|h[Infinity Blade]|h|r"] = "|cffff8000|Hitem:30312:0:0:0:0:0:0:0|h[Клинок Бесконечности]|h|r"
L["|cffff8000|Hitem:30313:0:0:0:0:0:0:0|h[Staff of Disintegration]|h|r"] = "|cffff8000|Hitem:30313:0:0:0:0:0:0:0|h[Посох Распыления]|h|r"
L["|cffff8000|Hitem:30314:0:0:0:0:0:0:0|h[Phaseshift Bulwark]|h|r"] = "|cffff8000|Hitem:30314:0:0:0:0:0:0:0|h[Фазовый колет]|h|r"
L["|cffff8000|Hitem:30316:0:0:0:0:0:0:0|h[Devastation]|h|r"] = "|cffff8000|Hitem:30316:0:0:0:0:0:0:0|h[Сокрушение]|h|r"
L["|cffff8000|Hitem:30317:0:0:0:0:0:0:0|h[Cosmic Infuser]|h|r"] = "|cffff8000|Hitem:30317:0:0:0:0:0:0:0|h[Вселенский вдохновитель]|h|r"
L["|cffff8000|Hitem:30318:0:0:0:0:0:0:0|h[Netherstrand Longbow]|h|r"] = "|cffff8000|Hitem:30318:0:0:0:0:0:0:0|h[Длинный лук Края Пустоты]|h|r"
L["|cffff8000|Hitem:30319:0:0:0:0:0:0:0|h[Nether Spike]|h|r"] = "|cffff8000|Hitem:30319:0:0:0:0:0:0:0|h[Шип Пустоты]|h|r"
L["|cffff8000|Hitem:30320:0:0:0:0:0:0:0|h[Bundle of Nether Spikes]|h|r"] = "|cffff8000|Hitem:30320:0:0:0:0:0:0:0|h[Сверток шипов Пустоты]|h|r"
L["Changed itemcost from %s to %s DKP for %s."] = "Изменена стоимость предмета %s на %s DKP вместо %s"
L["Chess Event"] = "Шахматная партия"
L["Clear currently tracked raids."] = "Очистить записи текущего рейда"
L["Cleared current raid database."] = "База данных текущего рейда очищена."
L["Cleared the MorgDKP2 raid database."] = "Удалены записи всех рейдов из БД."
L["Clear raid DB"] = "Очистить DB рейда"
L["Clear the raid database?"] = "Очистить базу данных рейда?"
L["Close"] = "Закрыть"
L["Common"] = "|c00ffffffОбычное качество|r"
L["COMPLETED"] = "Завершено"
L["Core Modules"] = "Модули ядра"
L["Core of all MorgDKP2 features."] = [=[Ядро MorgDKP2. 
Не может быть отключено.]=]
L["Core Options"] = "Опции ядра"
L["Cry for mercy! Your meaningless lives will soon be forfeit!"] = "Молите о пощаде! Вскоре ваше ничтожное существование закончится!"
L["Currently loaded DKP pools..."] = "Данные DKP загружены..."
L["Custom Event"] = "Текущее событие"
L["Custom MorgBid2"] = "Свой MorgBid2"
L["Deleting %s from MorgDKP2 database."] = "Удаление %s из базы данных MorgDKP2."
L[ [=[Determine MorgBid user base. 
Also useful to check DKP for alts.]=] ] = [=[Определение базы пользователей MorgBid. 
Также полезно для проверки DKP альтов.]=]
L["Developer mode"] = "Режим разработчика"
L["Disenchanter"] = "Дизенчатер"
L["Display Options"] = "Настройки отображения"
L["DKP Modules"] = "Модули ДКП"
L["DKP Standings for %s:"] = "Позиции DKP для %s: "
L["DKP System"] = "Система ДКП"
L["Don't say I didn't warn ya, scoundrels! Onward, brothers and sisters!"] = "Ну не говорите потом, что я не предупреждал. В атаку, братья и сестры!"
L["Dust Covered Chest"] = "Пыльный сундук"
L["Earned DKP for Invites"] = "Заработанные DKP в таблице приглашения"
L["Either no classes are selected or no members need this item."] = "Либо не определены классы для которых розыгрывается данный предмет, либо у участников нет в нем потребности."
L["Enable ML/DE mode"] = "Включить режим ML/DE"
L["Enable more than one DKP pool for rolling on items.  When starting auction you have to choose the alternate pool (Defaults to primary pool)"] = "Включить больше чем один пул DKP для розыгрыша предметов.  При начале розыгрыша вы должны выбрать альтернативный пул (По умолчанию - первичный пул)"
L["Enables changing the text of button hints in MorgBid2."] = "Включает изменение текста подсказок кнопок в MorgBid2."
L["Enables the main MorgDKP interface for raid tracking."] = "Включить интерфейс MorgDKP для слежения за рейдом."
L["Enable tooltip hints"] = "Включить всплывающие подсказки"
L["End Raid"] = "Завершить Рейд"
L["Epic"] = "|c00a335eeПревосходный|r"
L["Export Raid"] = "Экспортировать Рейд"
L["Fixed DKP"] = "Фиксированное ДКП"
L["Font"] = "Шрифт"
L["Font color"] = "Цвет шрифта"
L["Font size"] = "Размер шрифта"
L["Font used in tooltips and frames."] = "Шрифт используемый в подсказках и фреймах"
L["Four Horsemen Chest"] = "Сундук Четырех Всадников"
L["Frame scale"] = "Маштаб окна"
L["Freya's Gift"] = "Дар Фрейи"
L["General display options for main modules."] = "Общие параметры отображения для модулей"
L["Gift of the Observer"] = "Дар Наблюдателя"
L["Give %s to %s, are you sure?"] = "Подтверждаете передачу %s персонажу %s?"
L["His hold on me dissipates. I can see clearly once more. Thank you, heroes."] = "Он больше не властен надо мной. Мой взор снова ясен. Благодарю вас, герои."
L["I AM RENEWED! Ysera grant me the favor to lay these foul creatures to rest!"] = "Я ИЗЛЕЧИЛАСЬ! Изера, даруй мне силу покончить с этими нечестивыми тварями."
L["If ML/DE Mode is on then no items will be recorded for the master looter or disenchanter defined by MorgDKP2."] = "Если режим ML/DE включен то лут полученный мастер лутером или дизенчатером не будет учитываться."
L["Ignore 6-8"] = "Игнорировать 6-8"
L["Ignore items worn by members.  This means queries will always be sent even if they have the item."] = "Игнорировать предметы, которые носят участники. Это означает, что запрос будут всегда посылать, даже если у них будет этот предмет."
L["Ignore members in groups 6-8 when querying for items."] = "Игнорировать членов 6-8 группы в очереди на предмет"
L["Ignore worn"] = "Игнорировать носимое"
L["I... I am released from his grasp... at last."] = "Наконец-то я... свободен от его оков…"
L["Impossible! Stay your attack, mortals... I submit! I submit!"] = "Impossible! Stay your attack, mortals... I submit! I submit!" -- Requires localization
L["INRAID"] = "В рейде"
L["Isn't it beautiful? I call it the magnificent aerial command unit!"] = "Красота, правда? Я называю это непревзойденной воздушной боевой единицей!"
L["It would appear that I've made a slight miscalculation. I allowed my mind to be corrupted by the fiend in the prison, overriding my primary directive. All systems seem to be functional now. Clear."] = "Очевидно, я совершил небольшую ошибку в расчетах. Пленный злодей затуманил мой разум и заставил меня отклониться от инструкций. Сейчас все системы в норме. Конец связи."
L["Julianne"] = "Джулианна"
L["Kil'rek"] = "Кил'рек"
L["LDB Plugin"] = "Плагин LDB"
L["Legendary"] = "|c00ff8000Реликвия|r"
L["Link items on the boss/mob that are above the loot threshold to guild chat."] = "Сообщение о предметах выпавших с босса/моба в канал гильдии"
L["Link items on the boss/mob that are above the loot threshold to raid chat."] = "Сообщение о предметах выпавших с босса/моба в канал рейда"
L["Link to Guild"] = "Сообщения в гильдию"
L["Link to Raid"] = "Сообщения в рейд"
L["List DKP"] = "Список DKP"
L["Main: "] = "Основной: "
L["Main character %s does not exist.  No changes made."] = "Основной персонаж %s не найден. Изменения не произведены."
L["Main DKP Pool"] = "Текущий DKP пулл"
L["Master Looter"] = "Ответственный за добычу"
L["Member assigned to disenchant items."] = "Участник ответственный за разбиение предметов."
L["ML/DE mode"] = "Режим ML/DE"
L["Mode where a boss attempt is recorded when you die via a confirmation dialogue."] = "Включает настройку при которой трай босса записывается через диалог подтверждения в случае вашей смерти."
L["MorgBid2 Options"] = "Насторойки MorgBid2"
L["MorgBid2 updating"] = "Обновление MorgBid2"
L["MorgBid2 Version Query"] = "Проверка версии MorgBid2"
L["Morgbid check"] = "Проверка MorgBID"
L["MorgDKP2"] = "MorgDKP2"
L["MultiPool"] = "Мультипулл"
L["NEED"] = "Нужно"
L["NEED text"] = "Текст НУЖНО"
L["NEW"] = "Новый"
L["No current raid exists."] = "Не найдено текущих рейдов"
L["No longer will I be a slave to Malygos! Challenge me and you will be destroyed!"] = "No longer will I be a slave to Malygos! Challenge me and you will be destroyed!" -- Requires localization
L["NONE"] = "НЕТ"
L["Not Set"] = "Не установлено"
L["Now querying for %s  ID = %s  DKP = %s"] = "Запущен запрос для %s  ID = %s  DKP = %s"
L["OFFLINE"] = "Вышел"
L["Offspec: "] = "Дополнительный: "
L["OFFSPEC"] = "Офф. билд"
L["OFFSPEC text"] = "Текст ОФФСПЕК"
L["ONLINE"] = "В сети"
L[ [=[On STANDBY.
|c000070ddClick:|r to enable.]=] ] = [=[В ОЖИДАНИИ.
|c000070ddНажать:|r для включения.]=]
L["Onyxian Whelp"] = "Дракончик Ониксии"
L["PASS"] = "ПАС"
L["PASS text"] = "Текст ПАС"
L["PENDING"] = "Ожидание"
L["PENDING..."] = "ОЖИДАНИЕ..."
L["Perhaps it is your imperfection that which grants you free will. That allows you to persevere against cosmically calculated odds. You prevailed where the Titans' own perfect creations have failed."] = "Perhaps it is your imperfection that which grants you free will. That allows you to persevere against cosmically calculated odds. You prevailed where the Titans' own perfect creations have failed." -- Requires localization
L["Please install MorgBid2 to bid on items.  http://www.wowace.com/projects/morg-bid2/ Thank-you:)"] = "Пожалйста установите/обновите MorgBid2 для ставок на предмет. http://www.wowace.com/projects/morg-bid2/ Спасибо:)"
L["Please whisper: dkplist [poolname] [class] [class] .... [all]"] = "Пожалуйста шепните: dkplist [poolname] [class] [class] .... [all]"
L["Plugin frame will not disappear until UI reloaded."] = "Для измениня необходимо перезагрузить UI."
L["Poor"] = "|c009d9d9dНизкое качество|r"
L["Preliminary testing phase complete. Now comes the true test!"] = "Фаза предварительной проверки завершена. Пора начать главный тест!"
L["Quality Threshold"] = "Качество"
L["Raid Tracker"] = "Рейдтрекер"
L["Raid Tracker for viewing and editing current raids."] = "Рейдтрекер для просмотра и редактирования текущих рейдов."
L["Rare"] = "|c000070ddРедкое качество|r"
L["Record boss attempt for %s?"] = "Сделать запись попытки босса %s?"
L["Romulo"] = "Ромуло"
L["Romulo & Julianne"] = "Ромуло & Джулианна"
L["Set DKP Pool to be primary DKP pool. Only pool if not using multiPool"] = "Определить DKP пулл основным пуллом. Только если не используется Мультипулл."
L["Show minimap icon"] = "Показать иконку на мини карте"
L["%s joined the raid at %s."] = "%s присоеденился к рейду в %s."
L["%s left the raid at %s."] = "%s вышел из рейда в %s"
L["Son of Flame"] = "Сын Пламени"
L["Sorry your response format is incorrect or no item with that ID is up for bidding.  Format = mbid [ID/link] [%s/%s/%s/%s] [bid value]"] = "Извините Ваш формат ответа является неправильным, или нет предмета с данным ID, для того чтобы предложить цену.  Формат = mbid ID [%s/%s/%s/%s] [bid value]"
L["%s received %s for %s DKP"] = "%s получил(а) %s за %s DKP"
L["Start Raid"] = "Начать Рейд"
L["Stay your arms! I yield!"] = "Придержите мечи! Я сдаюсь."
L["TAKE"] = "Беру"
L["TAKE text"] = "Текст ВОЗЬМУ"
L["Text of MorgBid2 NEED button"] = "Текст кнопки MorgBid2 НУЖНО"
L["Text of MorgBid2 OFFSPEC button"] = "Текст кнопки MorgBid2 ОФФСПЕК"
L["Text of MorgBid2 PASS button"] = "Текст кнопки MorgBid2 ПАС"
L["Text of MorgBid2 TAKE button"] = "Текст кнопки MorgBid2 ВОЗЬМУ"
L["The Alliance falter. Onward to the Lich King!"] = "Альянс повержен. Вперед, к Королю-личу!"
L["The first kill goes to me! Anyone care to wager?"] = "Первая жертва будет на моем счету! Кто-нибудь хочет пари?"
L["The halls of Karazhan shake, as the curse binding the doors of the Gamesman's Hall is lifted."] = "Залы Каражана трясутся, когда спадает проклятие, запечатывающее двери Игрового зала."
L["The Legion's final conquest has begun! Once again the subjugation of this world is within our grasp. Let none survive!"] = "Началось последнее завоевание Легиона! Скоро весь этот мир покорится нам! Пленных не брать!"
L["These are the hallmarks..."] = "These are the hallmarks..." -- Requires localization
L["The time is now! Leave none standing! "] = "Время пришло! Не щадите никого!"
L["This item is not currently up for bid."] = "Этот предмет еще не указан в предложении."
L["Toggle LDB Plugin"] = "Включить LDB плагин"
L["Toggle MorgDKP2"] = "Включить MorgDKP2"
L["Transeferred %s DKP to %s from %s"] = "Перечислено %s DKP для %s с %s"
L["Transferred %s to %s for %s DKP."] = "Передано %s от %s для %s DKP."
L["Uncommon"] = "|c001eff00Необычное качество|r"
L["Unique"] = "Уникальный"
L["Unique-equipped"] = "Уникальный при надевании"
L["UNKNOWN"] = "НЕИЗВЕСТНО"
L["Use earned DKP in the invite tablet (shift-click)."] = "Использовать заработанные DKP в таблице приглашений (shift-click)."
L["Use OFFSPEC"] = "Использовать ОФФСПЕК"
L["WAIT"] = "ЖДАТЬ"
L["What devil art thou, that dost torment me thus?"] = "Что ты за дьявол, что меня так мучишь?"
L["Whispers all members (even if they have MorgBid2) so they can reply and bid using whispers."] = "Шептать всем персонажам (даже если у них есть MorgBid2) для того, чтобы они смогли ответить и сделать ставку используя шепот."
L["Whisper system"] = "Система шепота"
L["World Boss"] = "Мировой босс"
L["xINRAIDx"] = "В рейде"
L["xWAITx"] = "хОжидаетх"
L["You are defenders of a doomed world! Flee here, and perhaps you will prolong your pathetic lives!"] = "Мир, который вы защищаете, обречен! Бегите прочь, и, быть может, вы продлите свои жалкие жизни!"
L["You can not use this function out of a raid group."] = "Вы не можетеиспользовать данную функцию вне рейда."
L["You may want to take cover."] = "Вам не пора прятаться?"
L["You must start a raid before you can start a query."] = "Для выполнения запроса необходимо создать рейд."
L["Your response has been accepted: %s"] = "Ваш ответ был принят: %s"
L["You will not defeat the Assembly of Iron so easily, invaders!"] = "Чужаки! Вам не одолеть Железное Собрание!"
L.BidWar = {
	["Beginning auction for %s:  ID = %s"] = "Начало аукциона для %s:  ID = %s",
	["Bidding is now closed."] = "Прием ставок завершен.",
	["Bid Format = mbid [ID/link] [%s/%s/%s] [bid value]"] = "Формат ставки = mbid [ID/link] [%s/%s/%s] [ставка]",
	Bidstep = "Шаг ставок",
	BidWar = "BidWar",
	["BidWar mode changes the MorgBid query to allow players to bid on items.  Also the MorgDKP tablet uses bids after this NOT member DKP."] = "Режим BidWar изменяет запрос MorgBid, чтобы игроки могли делать ставки на предметы. Также таблица MorgDKP использует СТАВКИ после этого а НЕ DKP персонажей.",
	["BidWar Options"] = "Настройки BidWar",
	["Changes the DKP step for BidWar mode.  Passes this value to MorgBid2 clients."] = "Изменяет шаг DKP для режима BidWar.",
	["Enable BidWar mode where the winner is charged the 2nd highest bid value for the item."] = "Включает режим BidWar, где победитель платит платит за предмет в размере 2го наивысшего знчения ставок.",
	["Enable BidWar mode with only one round of bidding and no reporting to raid chat."] = "Включает режим BidWar только с одним раундом ставок и без отчетов в рейдчат.",
	["Just enough"] = "Достаточно",
	["Maximum amount of DKP that members can exceed their current DKP."] = "Максимальное количество DKP, на которое персонаж может превысить текущее DKP.",
	["New high bidder for %s: %s = %s"] = "Новый возможный победитель %s: %s = %s",
	Overbid = "Перебить",
	["Silent auction"] = "Закрытый аукцион",
	["Sorry this is a silent auction and you have already placed your bid."] = "Извините, это закрытый аукцион и вы уже сделали свою ставку.",
	["You have exceeded the overbid amount of %s.  Your bid has been reset to the maximum."] = "Вы превысили размер перебивания %s.  Ваша ставка была сброшена до максимальной.",
}
L.DKPovertime = {
	["Added %s DKP to %s attendees."] = "Добавлено %s DKP %s присутствующим.",
	["Award amount"] = "Размер вознаграждения",
	["Award time"] = "Время для вознаграждения",
	["DKP/time"] = "DKP/time",
	["DKP/time event name"] = "Названия событий DKP/time",
	["DKP/time Options"] = "Настройки DKP/time",
	["DKP/time system which allows you to award DKP at custom intervals."] = "Система DKP/time позволяет начислять DKP за некоторые промежутки времени.",
	[ [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=] ] = [=[Формат названия событий:  
<zone> текст  
Пример:  <zone> DKP]=],
	["Time in minutes between DKP awards."] = "Время в минутах между начислением DKP",
}
L.Eventnaming = {
	["Allows you to change the default format for event names."] = "Позволяет Вам изменить стандартный формат названий событий",
	["Boss format"] = "Формат босса",
	Default = "По умолчанию",
	Enable = "Включено",
	["Event naming"] = "Названия событий",
	[ [=[Format of boss event names:  
<zone> - <boss>
Example:  <boss> <diff>]=] ] = [=[ормат названия события босса:  
<zone> - <boss>
Пример:  <boss> <diff>]=],
	[ [=[Format of run event name:  
<zone> text  
Example:  <zone> <diff> Run]=] ] = [=[Формат названия события захода:  
<zone> текст  
Пример:  <zone> <diff> Заход]=],
	[ [=[Format of start event name:  
<zone> text  
Example:  <zone> <diff> Start]=] ] = [=[Формат названия события старта: 
<zone> текст  
Пример:  <zone> <diff> Старт]=],
	["Reset default values."] = "Сброс значений по умолчанию",
	["Run format"] = "Формат захода",
	["Start format"] = "Формат старта",
	["Toggle event naming"] = "Переключить названия событий",
}
L.FixedDKP = {
	["DKP TAKE/OFFSPEC settings"] = "Настройки DKP ВОЗЬМУ/ОФФСПЕК",
	Enable = "Включено",
	["Enable OFFSPEC"] = "Включить ОФФСПЕК",
	["Enables mode where members are charged a standard price for OFFSPEC items."] = "Включить режим где персонажи платят стандартную стоимость предметов на ОФФСПЕК.",
	["Enables mode where members are charged a standard price for TAKE items."] = "Включить режим где персонажи платят стандартную стоимость предметов на ВОЗЬМУ.",
	["Enable TAKE"] = "Включить ВОЗЬМУ",
	["Fixed DKP"] = "Fixed DKP",
	["OFFSPEC Percent"] = "Процент на ОФФСПЕК",
	["OFFSPEC value"] = "Стоимость ОФФСПЕК",
	["Standard DKP system."] = "Стандартная система DKP.",
	["TAKE Percent"] = "Процент на ВОЗЬМУ",
	["TAKE value"] = "Стоимость ВОЗЬМУ",
	["Use percent of item value for OFFSPEC mode."] = "Использовать процентное значение стоимости для режима ОФФСПЕК",
	["Use percent of item value for TAKE mode."] = "Использовать процентное значение стоимости для режима ВОЗЬМУ",
}
L.Lootframe = {
	Alt = "Alt",
	["Always use"] = "Всегда использовать",
	["Always use the MorgDKP2 loot window even when the mod is in standby mode."] = "Всегда использовать окно добычи MorgDKP2, даже если аддон находится в ожидании.",
	["|c000070ddClick:|r allocate randomly"] = "отдать случайному",
	["|c000070ddClick:|r Announce winner."] = "|c000070ddClick:|r Объявить победителя.",
	["|c000070ddClick:|r give item to disenchanter"] = "|c000070ddClick:|r отдать предмет разбирателю",
	["|c000070ddClick:|r give this item to disenchanter."] = "|c000070ddClick:|r отдать этот предмет разбирателю.",
	[ [=[|c000070ddClick:|r loot item
|c000070ddR-Click:|r open itemdata or roll frame
|c000070ddAlt-R-Click:|r start all queries]=] ] = [=[|c000070ddClick:|r взять предмет
|c000070ddR-Click:|r открыть данные предмета или окно раздачи
|c000070ddAlt-R-Click:|r начать все раздачи]=],
	["|c000070ddClick:|r select pool to use for item."] = "|c000070ddClick:|r выберите пул используемый для предмета.",
	["|c000070ddClick:|r self loot"] = "взять себе",
	[ [=[|c000070ddClick:|r start item query.
|c000070ddAlt-Click:|r start all queries
|c000070ddShift-Click:|r random query for this item
|c000070ddCtrl-Click:|r ignore this item]=] ] = [=[|c000070ddClick:|r Начать раздачу предмета.
|c000070ddAlt-Click:|r Начать все раздачи.
|c000070ddShift-Click:|r Случайный розыгрыш для этого предмета.
|c000070ddCtrl-Click:|r Игнорировать предмет.]=],
	["|c000070ddClick:|r stop this item query."] = "|c000070ddClick:|r остановить раздачу этого предмета.",
	[ [=[|c000070ddMousewheel up/Click|r - Increase value.
|c000070ddMousewheel down/R-Click|r - decrease value.
|c000070ddSHIFT|r - change value by +/-1
|c000070ddALT|r - change value by +/-20
|c000070ddCTRL|r - change value by +/-100]=] ] = [=[|c000070ddMousewheel up/Click|r - Увеличить стоимость.
|c000070ddMousewheel down/R-Click|r - Уменьшить стоимость.
|c000070ddSHIFT|r - изменить стоимость на +/-1
|c000070ddALT|r - изменить стоимость на +/-20
|c000070ddCTRL|r - изменить стоимость на +/-100]=],
	Class = "Класс",
	["DKP: %s"] = "ДКП: %s",
	["Give %s to %s, are you sure?"] = "Отдать %s за %s, вы уверены?",
	Lootframe = "Окно добычи",
	["Lootframe scale"] = "Размер окна добычи",
	["Open lootframe at cursor postition"] = "Открыть окно добычи на месте указателя",
	["Replace Blizzard"] = "Заменить стандартное",
	["%s awarded to %s"] = "%s получает %s",
	["%s awarded to %s for %s DKP"] = "%s выигран %s за %s ДКП",
	["Select primary class"] = "Выберите первичный класс",
	["Select secondary class"] = "Выберите вторичный класс",
	["Snap to cursor"] = "Привязать к указателю",
	["%s will be disenchanted in 5 seconds."] = "%s будет разобрано через 5 секунд.",
	["When MorgDKP2 is active it's loot frame will replace default."] = "Когда MorgDKP2 включен, его окно добычи заменит стандартное.",
}
L.Percent = {
	["Items will cost a percentage of the members total DKP."] = "Предметы будут стоить проценты от общих DKP персонажа.",
	["Percent cost"] = "Стоимость в процентах",
	["Percent DKP"] = "Percent DKP",
	["Percent DKP Options"] = "Настройки Percent DKP",
	["Percent take"] = "Процентное ВОЗЬМУ",
	["When using the percent DKP system this option enables TAKE looting.  This means if the winning member rolled TAKE he will not be charged x% DKP he will instead be charged the base price of the item (Set using original itempoints."] = "При использовании системы процентного DKP эта опция позволяет выбрать ВОЗЬМУ.  Это значит что если выигравший персонаж выбирал ВОЗЬМУ, то он не платит x% DKP, а вместо этого платит базовую стоимость предмета (Установленную исполюзуя очки предмета).",
}
L.PointsDB = {
	["Added alias: %s of %s with %s DKP."] = "Добавлен псевдоним: %s(%s) с %s DKP.",
	["Addeded %s to item database."] = "%s добавлен в базу данных предметов.",
	["Added %s players from %s"] = "Добавлено %s персонажей из %s",
	["Add ignored item"] = "Добавить ингнорируемую вещь",
	["Add item"] = "Добавить предмет",
	["Add new item to ignore.  Drag the item to this input box."] = "Добавить вещь в игнор. Перетащите вещь в это окно",
	["Add new item to track.  Drag the item to this input box."] = "Добавить новый предмет для отслеживания. Перетащите предмет в поле ввода.",
	["Clear player DB"] = "Очистить БД персонажей",
	["Clear raid DB"] = "Очистить БД рейдов",
	["Clears all items in the database below the selected item level."] = "Удаляет все предметы в базе данных ниже выбранного ilvl.",
	["Clears all members in the database inactive longer than the selected number of weeks."] = "Удаляет всех персонажей в базе данных неактивных дольше выбранного числа недель.",
	["Clears all players currently in the database. Does not affect items."] = "Удаляет всех персонажей имеющихся в базе данных. Не касается предметов.",
	["Clears the current tracked raids."] = "Удаляет все текущие рейды.",
	["Cull item DB"] = "Отбор по базе предметов",
	["Cull item level"] = "Уровень предмета для отбора",
	["Cull member DB"] = "Отбор по базе персонажей",
	["Cull member level (weeks)"] = "Уровень(недели) персонажей для отбора",
	["Current rank weight"] = "Вес текущего ранга",
	["Database Functions"] = "Функции базы данных",
	["Database transfer complete. %s items were transferred and %s members updated."] = "Перенос базы данных выполнен. Было перенесено %s предметов и обновлено %s персонажей.",
	["Higher number for higher display priority. (7 will appear above 3 on the tooltip)"] = "Большее число отображается выше. (7 появится выше 3 в подсказке)",
	["Ignored items"] = "Игнорируемые предметы",
	["Import database from MorgDKP?"] = "Импортировать базу данных из MorgDKP?",
	["Import default item database?"] = "Импортировать базу предметов по умолчанию?",
	["Imported MorgDKP DB with %s players and %s items."] = "Из базы данных MorgDKP импортировано %s персонажей и %s предметов.",
	["List of currently ignored items.  Click to remove item from ignore list."] = "Список игнорируемых сейчас предметов. Щелкните для удаления предмета из списка.",
	["List of member ranks in the current pool."] = "Список рангов персонажей в текущем пуле.",
	["Player database cleared!"] = "База данных персонажей очищена!",
	["Player DKP reset to zero!"] = "DKP персонажей обнулено!",
	["Please delete the ItemData.lua file from the MorgDKP directory now."] = "Пожалуйста, удалите файл ItemData.lua из папки MorgDKP2 прямо сейчас.",
	["Rank weights"] = "Веса рангов",
	["Removed %s items from the database."] = "Из базы данных удалено %s предметов.",
	["Removed %s members from the database."] = "Из базы данных удалено %s персонажей.",
	["Resets all members DKP to zero."] = "Обнуляет DKP всех персонажей.",
	["Updating DKP Points.."] = "Обновление DKP...",
	["Zero player DB"] = "Обнулить БД персонажей",
}
L.RaidTracker = {
	Add = "Добавить",
	["Alias Database"] = "База псевдонимов",
	Aliases = "Псевдонимы",
	Alt = "Альт",
	Attendees = "Присутствующие",
	Class = "Класс",
	Close = "Закрыть",
	["Create new event"] = "Создать новое событие",
	["Current raid"] = "Текущий рейд",
	Delete = "Удалить",
	["Delete Raid"] = "Удалить Рейд",
	["DKP Changes"] = "Изменения DKP",
	Enable = "Включено",
	["Enter alias name"] = "Введите имя псевдонима",
	["Enter DKP change amount"] = "Введите размер изменения DKP",
	["Enter DKP change members"] = "Введите персонажей для изменения DKP",
	["Enter event attendees"] = "Введите присутствующих на событии",
	["Enter event name"] = "Введите имя события",
	["Enter event note"] = "Введите заметку события",
	["Enter event value"] = "Введите цену события",
	["Enter item event"] = "Введите событие для предмета",
	["Enter item value"] = "Введите стоимость предмета",
	["Enter item winner"] = "Введите выигравшего предмет",
	["Enter main name"] = "Введите имя главного персонажа",
	Eventname = "Название события",
	Eventnote = "Заметка события",
	["Export Raid"] = "Экспорт Рейда",
	Group = "Группа",
	Ignore = "Игнорировать",
	["Item Database"] = "База данных предметов",
	["Item DB"] = "БД предметов",
	["Raid Editing"] = "Редактирование рейда",
	Raids = "Рейды",
	["Raid Tracker"] = "Рейдтрекер",
	["Raid Tracker for viewing and editing current raids."] = "Рейдтрекер для просмотра и редактирования текущих рейдов.",
	["Select primary class"] = "Выбрать первичный класс",
	["Select secondary class"] = "Выбрать вторичный класс",
	["Update attends"] = "Обновить присутствующих",
	Value = "Стоимость",
	["You can not remove the run event."] = "Вы не можете удалить запущенное событие.",
}
L.Random = {
	["Enable random rolling for items."] = "Включить случайный розыгрыш для предметов.",
	["Random rolls"] = "Броски костей",
	["%s received %s."] = "%s получает %s.",
}
L.Relational = {
	["Enable Relational DKP for calculating the earned/spent dkp ratio."] = "Включить Relational DKP для вычисления рейтинга заработанного/потраченного dkp.",
	["Minimum amount of DKP a member can have for calculating the DKP ratio to avoid a new member having a high ratio. ie  200 earned DKP/ (this value)"] = "Минимальное количество DKP персонажа, которые тот должен иметь для вычисления DKP-рейтинга во избежание получения новичками высокого рейтинга. т.е.  200 заработанных DKP/ (это значение)",
	["Minimum DKP base"] = "Минимальное базовое DKP",
	["Relational DKP"] = "Relational DKP",
	["Relational DKP Options"] = "Настройки Relational DKP",
}
L.SKSotC = {
	["Amount of DKP to remove from members who miss a raid."] = "Amount of DKP to remove from members who miss a raid.", -- Requires localization
	["Demotion event"] = "Demotion event", -- Requires localization
	["Enable Suicide Kings SotC variant DKP."] = "Enable Suicide Kings SotC variant DKP.", -- Requires localization
	[ [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=] ] = [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=], -- Requires localization
	["Missed raid DKP"] = "Missed raid DKP", -- Requires localization
	["SKSotC DKP"] = "SKSotC DKP", -- Requires localization
	["SKSotC Options"] = "SKSotC Options", -- Requires localization
}
L.SKall = {
	["Enable raid award"] = "Включить вознаграждение рейда",
	["Enables DKP removed from item winner to be awarded to raid members.  You must check use zerosum on the import webscript for website DKP to be correct."] = "Позволяет награждать рейдеров DKP, списываемыми с победителя. Вы должны проставить use zerosum в скрипте на сайте DKP для правильности занесения.",
	["Enable Suicide Kings spend all DKP."] = "Включить Suicide Kings spend all DKP.",
	["% Member DKP"] = "% DKP персонажа",
	["Percent of member DKP to remove."] = "Процент DKP персонажа для списывания.",
	["SKall DKP"] = "SKall DKP ",
	["SKall Options"] = "Настройки  SKall",
}
L.Syncing = {
	["Accept DKP changes from other raid leaders."] = "Принимать изменения DKP от другого рейдлидера.",
	["Added %s to listeners."] = "%s добавлен к слушателям.",
	Automatic = "Автоматически",
	["Automatically set broadcast/receive depending if you are the master looter."] = "Автоматически устанавливает прием/передачу в зависимости от того мастер добычи вы или нет.",
	Broadcast = "Передача",
	["Broadcast DKP changes to other raid leaders."] = "Передача изменений DKP другим рейдлидерам.",
	Enable = "Включено",
	["Immediate Sync Options"] = "Настройки немедленной синхронизации",
	["Imported options...restarting."] = "Настройки импортированы... перезагрузка.",
	["Imported %s items"] = "Импортировано %s предметов",
	["Import %s data from %s?"] = "Импортировать %s данных от %s?",
	["Initial Sync"] = "Немедленная синхронизация",
	["Items Sync"] = "Синхронизация предметов",
	["Members Sync"] = "Синхронизация персонажей",
	["Options Sync"] = "Синхронизация настроек",
	["Overwrite raid"] = "Перезапись рейда",
	["Overwrite the current raid if you receive an initial sync and are currently in a raid."] = "Перезаписать текущий рейд если вы получаете запрос синхронизации и уже в рейде.",
	Password = "Пароль",
	Receive = "Прием",
	["Removed %s from listeners."] = "%s удален из слушателей.",
	["Resends initial sync.  Only needed in cases where you have problems as this is done automatically."] = "Посылает запрос немедленной синхронизации заного. Требуется только при наличии проблем, так как должно выполняться автоматически.",
	["Send DB Sync"] = "Послать запрос синхрониации базы",
	["Sends your current database of item DKP values."] = "Посылает вашу текущую базу DKP-стоимости предметов.",
	["Sends your current database of member DKP values."] = "Посылает вашу текущую базу значений DKP персонажей.",
	["Sends your current database of member DKP values, item values, and MorgDKP2 options to the current raid."] = "Посылает вашу текущую базу значений DKP персонажей, стоимости предметов и насторойки MorgDKP2 в текущий рейд.",
	["Sends your current MorgDKP2 options.  Note will restart MorgDKP2 so do not send another sync until it restarts or use full sync and it will be handled properly."] = "Посылает ваши текущие настройки MorgDKP2. Это перезагрузит MorgDKP2 поэтому не посылайте еще синхронизацию до перезагрузки или используйте полную синхронизацию для правильного выполнения.",
	["%s's MorgDKP2 is out of date!"] = "MorgDKP2 у %s  устарел!",
	["%s's password does not match your password!"] = "Пароль у %s не совпадает с вашим!",
	Syncing = "Синхронизация",
	["Syncing password"] = "Пароль синхронизации",
	["Syncing system for communicating DKP between raid leaders."] = "Система синхронизации для связи DKP между рейдлидерами.",
	["Updated %s members"] = "Обновлено %s персонажей",
}
L.TakeBid = {
	Bidstep = "Шаг ставок",
	["Changes the DKP step for TakeBid mode.  Passes this value to MorgBid2 clients."] = "Изменяет шаг DKP для режима TakeBid. Передает это значение клиентам MorgBid2.",
	["Maximum amount of DKP that members can exceed their current DKP."] = "Максимальное количество DKP, на которое персонажи могут превысить свое DKP.",
	["Minimum amount of DKP that members can bid for an item."] = "Минимальное количество DKP, который участники могут предложить за предмет.",
	["Minimum bid"] = "Минимальная ставка",
	Overbid = "Сверхставка",
	["TakeBid DKP"] = "TakeBid DKP",
	["TakeBid Options"] = "Настройки TakeBid",
	["Variation of Fixed DKP where when you bid take you also enter what you are willing to pay."] = "Вариация Fixed DKP, где когда вы делаете ставку, вы также должны указать размер ставки.",
}
L.Tracker = {
	["and add these attendees < %s min?"] = "и добавить присутствующих меньше < %s минут?",
	["Attendance reward"] = "Награда за присутствие",
	["Bank character"] = "Персонаж-банк",
	CANCEL = "ОТМЕНА",
	["Clear the raid database?"] = "Очистить базу данных рейда?",
	[ [=[Core of all MorgDKP2 raid tracking features. 
Can not be disabled.]=] ] = [=[Ядро всех особенностей рейдтрекера MorgDKP2.
Не может быть отключено.]=],
	["CTRT format"] = "CTRT format", -- Requires localization
	["DKP Export"] = "Экспорт ДКП",
	["DKP listener"] = "Слушатель DKP",
	["DKP Tracking"] = "Отслеживание DKP",
	["DKP which new members to the database receive."] = "DKP получаемые новыми персонажами при внесении в базу.",
	["End Raid"] = "Завершить рейд",
	["End %s"] = "Завершить",
	["Eqdkp+ event format"] = "Формат событий Eqdkp+",
	["Events for DKP changes"] = "События для изменения DKP",
	["Export Raids"] = "Экспорт рейда",
	["Exports current raid(s) data for import into website."] = "Экспортирует данные текущего рейда(ов) для импортирования на сайт.",
	["Finalizes the current raid."] = "Завершает текущий рейд.",
	["Format of new member DKP event name."] = "Формат нового члена DKP имени события",
	["General options"] = "Общие настройки",
	["Guildlaunch format"] = "Формат Гильдзапуска",
	["Minimum time to add member to raid and award run DKP."] = "Минимальное время для для добавления персонажа в рейд и начисления DKP за заход.",
	["New member DKP event"] = "Новый член DKP события",
	["New member start DKP"] = "Начальное DKP нового персонажа",
	NO = "НЕТ",
	["No current raid exists."] = "Нет текущего рейда.",
	["Opens the raidtracker interface."] = "Открывает интерфейс рейдтрекера.",
	["Previous best kill time: %s"] = "Предыдущее лучшее время убийства: %s",
	["Raid Tracker"] = "Рейдтрекер",
	["Remember kill times"] = "Запоминать время убийства",
	["Removed %s raid attendees."] = "Удалено %s присутствующих из рейда.",
	["Remove the ' character from any event names because eqdkp+ is dumb."] = "Удаляет символы ' из всех названий событий, потому что eqdkp+ бестолочь.",
	["Sartharion minibosses"] = "Минибоссы Сартариона",
	["%s defeated in %s!"] = "%s побежден за %s!",
	Shortcuts = "Ярлыки",
	["Single run event"] = "Единый заход",
	["Sorry %s is an invalid database pool.  Please choose a correct one or export your DKP from your website."] = "Sorry %s is an invalid database pool.  Please choose a correct one or export your DKP from your website.",
	["%s recorded at %s with %s attendees."] = "%s записан в %s с %s присутствующими.",
	["Start Event"] = "Событие старта",
	["Start Raid"] = "Запустить Рейд",
	["Starts a new raid."] = "Запустить новый рейд.",
	["Store your best kill times for bosses."] = "Хранилище лучших убийств боссов по времени.",
	["Trigger events for Sartharion minibosses."] = "Отдельные события для минибоссов Сартариона.",
	["Use a bank character in raids."] = "Использование персонажа-банка в рейдах.",
	["Use CTRT export format for raid exports."] = "Use CTRT export format for raid exports.", -- Requires localization
	["Use events for DKP changes instead of database adjustments."] = "Использовать события для изменения DKP вместо изменений базы данных.",
	["Use guildlaunch export format for raid exports."] = "Использовать формат экспорта гильдзапуска для экспорта рейда.",
	["Use one event for entire raid.  Boss kills will not be tracked separately."] = "Использовать одно событие для всего рейда. Убийства боссов не будут отслеживаться по отдельности.",
	["Use start event when raid begins."] = "Использовать стартовое событие при начале рейда",
	["When you are in a tracked zone you will track DKP but you will not get the loot popup window or link to the raid.  You will act like a backup raidlog."] = "Когда вы в отслеживаемой зоне вы будете отслеживать DKP но окно раздачи добычи и ссылки в рейд появляться не будут.  Вы будете действовать как резервный регистратор.",
	YES = "ДА",
	["Yes & Add"] = "Да и Добавить",
}
L.Waitlist = {
	["Added %s to the waitlist."] = "%s добавлен в список ожидания.",
	["Added you to the waitlist."] = "Вас добавили в список ожидания.",
	["Amount of DKP to reward after members have been on the waitlist for the current reward time."] = "Количество DKP начисляемое после того как персонажи были в списке ожидания врямя определенное для награды.",
	["Amount of DKP to reward at raidstart."] = "Количество DKP начисляемое при старте.",
	["Amount of DKP to reward to waitlist members per bosskill."] = "Количество DKP начисляемое персонажам в списке ожидания за убийство босса.",
	["Amount of DKP to reward to waitlist members when awarding regular members DKP/time. Note: only works if you are awarding DKP/time."] = "Кол-во DKP, начисляемое персонажам в списке ожидания при начислении действительным рейдерам DKP/time. Заметка: работает только если начисляется DKP/time.",
	["Autochannel Spam"] = "Спам в автоканал",
	["Award DKP"] = "Начисляемое DKP",
	["Award DKP to current waitlist members"] = "Начислить DKP текущему списку ожидания",
	Channels = "Каналы",
	["Channels to spam when starting invites."] = "Каналы для спама при начале сбора.",
	["Clears the current wailist."] = "Список ожидания",
	["Clear Waitlist"] = "Очистить Список ожидания",
	["Current waitlist: %s"] = "Текущий список ожидания: %s",
	Enable = "Включено",
	["Event Names"] = "Названия событий",
	[ [=[Format of waitlist boss events:  
<boss> text  
Example:  <boss> Waitlist DKP]=] ] = [=[Формат события босса списка ожидания:  
<boss> текст
Пример:  <boss> DKP списка ожидания]=],
	[ [=[Format of waitlist event names:  
<zone> text  
Example:  <zone> Waitlist DKP]=] ] = [=[Формат события списка ожидания:  
<zone> текст  
Пример:  <zone> DKP списка ожидания]=],
	["Grace Period"] = "Период милосердия",
	["Minimum time before offline waitlist members will be removed."] = "Минимальное время до того как персонажи списка ожидания в оффлайне будут удалены.",
	["Minimum time to award run DKP to a waitlist member."] = "Минимальное время для начисления DKP захода списку ожидания. ",
	["Now accepting tells for the waitlist.  Please whisper %s using this format:  mbid wait[+/-] [main]"] = "Принимаются запросы на включение в список ожидания. Пожалуйста шепните в форме: mbid wait[+/-] [main]",
	["Please log on to your main for an invite to the raid.  Whisper me when online."] = "Пожалуйста, зайдите на основного персонажа для приглашения в рейд. Шепните мне когда будете онлайн.",
	["Removed %s from wailist."] = "%s удален из списка ожидания.",
	["Removed %s from waitlist due to inactivity"] = "%s удален из списка ожидания ввиду бездействия",
	["Removed you from the waitlist."] = "Вы удалены из списка ожидания.",
	["Spam channels automatically when opening the invite tablet."] = "Спамить в каналы автоматически при открытии таблицы приглашений.",
	["Spam channels with current waitlist."] = "Спамить в каналы текущий список ожидания.",
	["Spam channels with waitinfo now."] = "Спамить в каналы информацию об ожидании.",
	["Spam Current"] = "Спам текущих",
	["Spam Waitinfo"] = "Спам информации о списке ожидания",
	["That main does not exist."] = "Этот главный персонаж не существует.",
	Waitlist = "Список ожидания",
	["Waitlist allows members to whisper you for invites and to receive DKP even if not in the actual raid."] = "Список ожидания позволяет персонажам шептать вам для приглашения, чтобы получить DKP даже не находясь в рейде.",
	["Waitlist boss DKP"] = "DKP списка ожидания за босса",
	["Waitlist boss event name"] = "Название события босса списка ожидания",
	["Waitlist DKP/time"] = "Список ожидания DKP/time",
	["Waitlist event name"] = "Название события списка ожидания",
	["Waitlist reward"] = "Награда списку ожидания",
	["Waitlist run DKP"] = "DKP списка ожидания захода",
	["Waitlist spamming"] = "Спам списка ожидания",
	["Waitlist start DKP"] = "DKP списка ожидания старта",
}
L.Whisper = {
	Enable = "Включено",
	["%s: ID = %s  DKP/Bid value = %s  (Reply format: mbid ID [%s/%s/%s/%s bid value])"] = "%s: ID = %s  DKP/Ставка = %s  (Формат ответа: mbid ID [%s/%s/%s/%s ставки])",
	["Whispers all members (even if they have MorgBid) so they can reply and bid using whispers."] = "Шептать всем персонажам (даже если у них есть MorgBid2) для того, чтобы они смогли ответить и сделать ставку используя шепот.",
	["Whisper system"] = "Система шепота",
}
L.Zerosum = {
	["Added %s DKP to %s attendees."] = "Добавлено %s DKP %s присутствующим.",
	["DKP award event name"] = "Название награждаемого DKP события",
	[ [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=] ] = [=[Формат названий событий:  
<zone> текст  
Пример:  <zone> DKP]=],
	["Include waitlist"] = "Включать список ожидания",
	["Include waitlist members in DKP calculations.  Note they will still get whatever DKP award is set in the waitlist module."] = "Включает список ожидания в подсчет DKP. Заметьте, что что DKP-награды, установленные в модуле списка ожидания, также будут начисляться.",
	["Standard zero sum system where member is charged for the item and the charged points are divided between all raid members.  You must check use zerosum on the import webscript for website DKP to be correct."] = "Обычная zero sum система, где персонажи платят за предметы и уплаченные очки делятся между всеми рейдерами. Вы должны проверить использование zerosum в импортном скрипте сайта чтобы DKP на сайте было верным.",
	["Zerosum DKP"] = "Zerosum DKP",
	["Zerosum Options"] = "Настройки Zerosum",
}

