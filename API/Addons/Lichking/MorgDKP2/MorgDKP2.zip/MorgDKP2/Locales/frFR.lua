local L = LibStub("AceLocale-3.0"):NewLocale("MorgDKP2", "frFR")
if not L then return end

L["Abandon all hope! The Legion has returned to finish what was begun so many years ago. This time, there will be no escape!"] = "Abandon all hope! The Legion has returned to finish what was begun so many years ago. This time, there will be no escape!" -- Requires localization
L["Add a custom raid event.  This will record all attendees when you click the event menu by adding Attempt to the end of the boss name you have targeted.  You can change event name value through raid tracker.  SHIFT-Click to bypass menu."] = "Ajoute un evenement de raid personnalise.  Cela enregistrera tous les membres quand vous cliquerez dans le menu Evenement en ajoutant Essai a la fin du nom du boss selectionne.  Vous pouvez changer le nom de l evenement via le suivi de raid.  SHIFT-Clic pour passer outre le menu."
L["Added %s DKP to %s."] = "%s DKP ajoutes a %s."
L["Added %s DKP to %s attendees."] = "%s DKP ajoutes a %s membres"
L["Added %s DKP to waitlist attendees."] = "%s DKP ajoutes aux membres de la file d attente."
L["Added %s to ignore list."] = "%s ajoute a la liste des ignores"
L["Alexstrasza's Gift"] = "Alexstrasza's Gift" -- Requires localization
L["Alias %s already exihists.  No changes made."] = "Le reroll %s existe deja. Aucun changement effectue"
L["ALL"] = "TOUS"
L["Allow the OFFSPEC button to be used in MorgBid2."] = "Autorise l utilisation du bouton SPE SECONDAIRE dans MorgBid2"
L["Allow updating bid results in MorgBid2."] = "Autorise la mise a jour des resultats dans MorgBid2"
L["Amani Dragonhawk Spirit"] = "Amani Dragonhawk Spirit" -- Requires localization
L["Anything below this quality threshold will NOT be logged."] = "Tout ce qui sera en dessous de ce niveau de qualite ne sera pas enregistre"
L["Artifact"] = "Artefact"
L["A shallow and tragic victory. We are weaker as a whole from the losses suffered today. Who but the Lich King could benefit from such foolishness? Great warriors have lost their lives. And for what? The true threat looms ahead - the Lich King awaits us all in death."] = "A shallow and tragic victory. We are weaker as a whole from the losses suffered today. Who but the Lich King could benefit from such foolishness? Great warriors have lost their lives. And for what? The true threat looms ahead - the Lich King awaits us all in death." -- Requires localization
L["Assembly of Iron"] = "Assembly of Iron" -- Requires localization
L["Automatically enable MorgDKP2 and start a raid when entering a trackable zone."] = "Active automatiquement MorgDKP2 et debute un raid quand on entre dans une zone de raid"
L["Autozone"] = "Zone automatique"
L["Background color"] = "Couleur de fond"
L["Background texture"] = "Texture de fond"
L["Background texture of frames/tooltips."] = "Texture utilisee pour les fenetres et les infobulles"
L["Bank"] = "Banque"
L["Border color"] = "Couleur de bordure"
L["Border texture"] = "Texture de la bordure"
L["Border texture of frames/tooltips."] = "Texture de la bordure des fenetres et des infobulles"
L["Boss attempt mode"] = "Mode Essai des boss"
L["Boss Attempt Mode"] = "Mode essai de boss"
L[ [=[|c000070ddClick:|r MorgBid2 Base query.
|c000070ddALT-Click:|r Toggle ML/DE
|c000070ddSHIFT-Click:|r Invite & Waitlist.
|c000070ddCTRL-Click:|r Raid Tracker.
|c000070ddCTRL-Click Itemlink:|r Ignore item.]=] ] = [=[|c000070ddClic:|r Requete de la base MorgBid2.
|c000070ddALT-Clic:|r Basculer le mode ML/DE
|c000070ddSHIFT-Clic:|r Invite & File d attente.
|c000070ddCTRL-Clic:|r Traqueur de raid.
|c000070ddCTRL-Clic Lien d objet:|r Ignorer l objet.]=]
L[ [=[|c000070ddClick:|r Nag old versions now
|c000070ddR-Click:|r Close tablet.]=] ] = [=[|c000070ddClick:|r Nag old versions now
|c000070ddR-Click:|r Close tablet.]=] -- Requires localization
L[ [=[|c000070ddL-Click:|r Invite.
|c000070ddCTRL-Click:|r Delete Character.
|c000070ddALT-Click:|r Add to waitlist.
|c000070ddSHIFT-Click:|r Remove from waitlist.
|c000070ddR-Click:|r Close tablet.]=] ] = [=[|c000070ddClic-gauche:|r Inviter.
|c000070ddCTRL-Clic:|r Effacer le personnage.
|c000070ddALT-Clic:|r Ajouter a la file d attente.
|c000070ddSHIFT-Clic:|r Retirer de la liste d attente.
|c000070ddClic-droit:|r Fermer la fenetre.]=]
L["|c001eff00ON|r"] = "|c001eff00ON|r"
L["|c009d9d9dOFF|r"] = "|c009d9d9dOFF|r"
L["Cache of Innovation"] = "Cache of Innovation" -- Requires localization
L["Cache of Living Stone"] = "Cache de pierre vivante"
L["Cache of Storms"] = "Cache des tempêtes"
L["Cache of the Firelord"] = "Cache of the Firelord" -- Requires localization
L["Cache of Winter"] = "Cache of Winter" -- Requires localization
L["|cff0070dd|Hitem:14344:0:0:0:0:0:0:0|h[Large Brilliant Shard]|h|r"] = "|cff0070dd|Hitem:14344:0:0:0:0:0:0:0|h[Large Brilliant Shard]|h|r" -- Requires localization
L["|cff0070dd|Hitem:22448:0:0:0:0:0:0:0|h[Small Prismatic Shard]|h|r"] = "|cff0070dd|Hitem:22448:0:0:0:0:0:0:0|h[Small Prismatic Shard]|h|r" -- Requires localization
L["|cff0070dd|Hitem:22449:0:0:0:0:0:0:0|h[Large Prismatic Shard]|h|r"] = "|cff0070dd|Hitem:22449:0:0:0:0:0:0:0|h[Large Prismatic Shard]|h|r" -- Requires localization
L["|cffa335ee|Hitem:18562:0:0:0:0:0:0:0|h[Elementium Ore]|h|r"] = "|cffa335ee|Hitem:18562:0:0:0:0:0:0:0|h[Elementium Ore]|h|r" -- Requires localization
L["|cffa335ee|Hitem:20725:0:0:0:0:0:0:0|h[Nexus Crystal]|h|r"] = "|cffa335ee|Hitem:20725:0:0:0:0:0:0:0|h[Nexus Crystal]|h|r" -- Requires localization
L["|cffa335ee|Hitem:22450:0:0:0:0:0:0:0|h[Void Crystal]|h|r"] = "|cffa335ee|Hitem:22450:0:0:0:0:0:0:0|h[Void Crystal]|h|r" -- Requires localization
L["|cffa335ee|Hitem:29434:0:0:0:0:0:0:0|h[Badge of Justice]|h|r"] = "|cffa335ee|Hitem:29434:0:0:0:0:0:0:0|h[Badge of Justice]|h|r" -- Requires localization
L["|cffa335ee|Hitem:32230:0:0:0:0:0:0:0|h[Shadowsong Amethyst]|h|r"] = "|cffa335ee|Hitem:32230:0:0:0:0:0:0:0|h[Shadowsong Amethyst]|h|r" -- Requires localization
L["|cffa335ee|Hitem:34057:0:0:0:0:0:0:0:80|h[Abyss Crystal]|h|r"] = "|cffa335ee|Hitem:34057:0:0:0:0:0:0:0:80|h[Abyss Crystal]|h|r" -- Requires localization
L["|cffa335ee|Hitem:40752:0:0:0:0:0:0:0:80|h[Emblem of Heroism]|h|r"] = "|cffa335ee|Hitem:40752:0:0:0:0:0:0:0:80|h[Emblem of Heroism]|h|r" -- Requires localization
L["|cffa335ee|Hitem:40753:0:0:0:0:0:0:0:80|h[Emblem of Valor]|h|r"] = "|cffa335ee|Hitem:40753:0:0:0:0:0:0:0:80|h[Emblem of Valor]|h|r" -- Requires localization
L["|cffa335ee|Hitem:45624:0:0:0:0:0:0:0:80|h[Emblem of Conquest]|h|r"] = "|cffa335ee|Hitem:45624:0:0:0:0:0:0:0:80|h[Emblem of Conquest]|h|r" -- Requires localization
L["|cffa335ee|Hitem:47241:0:0:0:0:0:0:0:80|h[Emblem of Triumph]|h|r"] = "|cffa335ee|Hitem:47241:0:0:0:0:0:0:0:80|h[Emblem of Triumph]|h|r" -- Requires localization
L["|cffff8000|Hitem:30311:0:0:0:0:0:0:0|h[Warp Slicer]|h|"] = "|cffff8000|Hitem:30311:0:0:0:0:0:0:0|h[Warp Slicer]|h|" -- Requires localization
L["|cffff8000|Hitem:30312:0:0:0:0:0:0:0|h[Infinity Blade]|h|r"] = "|cffff8000|Hitem:30312:0:0:0:0:0:0:0|h[Infinity Blade]|h|r" -- Requires localization
L["|cffff8000|Hitem:30313:0:0:0:0:0:0:0|h[Staff of Disintegration]|h|r"] = "|cffff8000|Hitem:30313:0:0:0:0:0:0:0|h[Staff of Disintegration]|h|r" -- Requires localization
L["|cffff8000|Hitem:30314:0:0:0:0:0:0:0|h[Phaseshift Bulwark]|h|r"] = "|cffff8000|Hitem:30314:0:0:0:0:0:0:0|h[Phaseshift Bulwark]|h|r" -- Requires localization
L["|cffff8000|Hitem:30316:0:0:0:0:0:0:0|h[Devastation]|h|r"] = "|cffff8000|Hitem:30316:0:0:0:0:0:0:0|h[Devastation]|h|r" -- Requires localization
L["|cffff8000|Hitem:30317:0:0:0:0:0:0:0|h[Cosmic Infuser]|h|r"] = "|cffff8000|Hitem:30317:0:0:0:0:0:0:0|h[Cosmic Infuser]|h|r" -- Requires localization
L["|cffff8000|Hitem:30318:0:0:0:0:0:0:0|h[Netherstrand Longbow]|h|r"] = "|cffff8000|Hitem:30318:0:0:0:0:0:0:0|h[Netherstrand Longbow]|h|r" -- Requires localization
L["|cffff8000|Hitem:30319:0:0:0:0:0:0:0|h[Nether Spike]|h|r"] = "|cffff8000|Hitem:30319:0:0:0:0:0:0:0|h[Nether Spike]|h|r" -- Requires localization
L["|cffff8000|Hitem:30320:0:0:0:0:0:0:0|h[Bundle of Nether Spikes]|h|r"] = "|cffff8000|Hitem:30320:0:0:0:0:0:0:0|h[Bundle of Nether Spikes]|h|r" -- Requires localization
L["Changed itemcost from %s to %s DKP for %s."] = "Valeur DKP changee de %s a %s pour l objet %s."
L["Chess Event"] = "Chess Event" -- Requires localization
L["Clear currently tracked raids."] = "Efface les raids actuellement suivis"
L["Cleared current raid database."] = "Base des raids effacee."
L["Cleared the MorgDKP2 raid database."] = "Base de raid de MorgDKP2 effacee"
L["Clear raid DB"] = "Effacer la base des raids"
L["Clear the raid database?"] = "Effacer la base de raid?"
L["Close"] = "Close" -- Requires localization
L["Common"] = "Commun"
L["COMPLETED"] = "TERMINE"
L["Core Modules"] = "Modules principaux"
L["Core of all MorgDKP2 features."] = "Coeur des fonctions de MorgDKP2"
L["Core Options"] = "Options principales"
L["Cry for mercy! Your meaningless lives will soon be forfeit!"] = "Cry for mercy! Your meaningless lives will soon be forfeit!" -- Requires localization
L["Currently loaded DKP pools..."] = "Pools de DKP charg?s actuellement..."
L["Custom Event"] = "Evenement personnalise"
L["Custom MorgBid2"] = "Personnaliser MorgBid2"
L["Deleting %s from MorgDKP2 database."] = "Suppression de %s de la base MorgDKP2"
L[ [=[Determine MorgBid user base. 
Also useful to check DKP for alts.]=] ] = [=[Determine la base des utilisateurs MorgBid. 
Utile pour verifier les DKP des rerolls]=]
L["Developer mode"] = "Mode developpeur"
L["Disenchanter"] = "Desenchanteur"
L["Display Options"] = "Options d affichage"
L["DKP Modules"] = "Modules DKP"
L["DKP Standings for %s:"] = "Tableau des DKP pour %s :"
L["DKP System"] = "Systeme de DKP"
L["Don't say I didn't warn ya, scoundrels! Onward, brothers and sisters!"] = "Don't say I didn't warn ya, scoundrels! Onward, brothers and sisters!" -- Requires localization
L["Dust Covered Chest"] = "Coffre couvert de poussière"
L["Earned DKP for Invites"] = "Earned DKP for Invites" -- Requires localization
L["Either no classes are selected or no members need this item."] = "Soit aucune classe de selectionnee soit personne ne veut cet objet"
L["Enable ML/DE mode"] = "Activer le mode ML/DE"
L["Enable more than one DKP pool for rolling on items.  When starting auction you have to choose the alternate pool (Defaults to primary pool)"] = "Activer plus d un seul pool pour les encheres. Au debut d une enchere, vous devrez choisir le pool a utiliser (Pool principal par defaut)"
L["Enables changing the text of button hints in MorgBid2."] = "Autorise la modification des textes des boutons dans MorgBid2"
L["Enables the main MorgDKP interface for raid tracking."] = "Active l interface principale de suivi du raid"
L["Enable tooltip hints"] = "Active les infobulles d astuce"
L["End Raid"] = "Terminer un raid"
L["Epic"] = "Epique"
L["Export Raid"] = "Exporter un raid"
L["Fixed DKP"] = "DKP Fixe"
L["Font"] = "Police"
L["Font color"] = "Couleur de police"
L["Font size"] = "Taille de police"
L["Font used in tooltips and frames."] = "Police utilisee pour les infobulles et les fenetres"
L["Four Horsemen Chest"] = "Coffre des quatre cavaliers"
L["Frame scale"] = "Echelle de la fenetre"
L["Freya's Gift"] = "Cadeau de Freya"
L["General display options for main modules."] = "Options generales pour l affichage des modules principaux"
L["Gift of the Observer"] = "Gift of the Observer" -- Requires localization
L["Give %s to %s, are you sure?"] = "Donner %s a %s, etes-vous sur ?"
L["His hold on me dissipates. I can see clearly once more. Thank you, heroes."] = "Son emprise sur moi ce dissipe. Je peux voir clairement une fois de plus. Merci, Monsieur le héros."
L["I AM RENEWED! Ysera grant me the favor to lay these foul creatures to rest!"] = "I AM RENEWED! Ysera grant me the favor to lay these foul creatures to rest!" -- Requires localization
L["If ML/DE Mode is on then no items will be recorded for the master looter or disenchanter defined by MorgDKP2."] = "Si le mode ML/DE est actif alors aucun objet ne sera enregistre pour le maitre du butin ou le desenchanteur defini par MorgDKP2"
L["Ignore 6-8"] = "Ignorer 6-8"
L["Ignore items worn by members.  This means queries will always be sent even if they have the item."] = "Ignore items worn by members.  This means queries will always be sent even if they have the item." -- Requires localization
L["Ignore members in groups 6-8 when querying for items."] = "Ignore les joueurs dans les groupes 6 a 8 au moment des requetes des objets"
L["Ignore worn"] = "Ignore worn" -- Requires localization
L["I... I am released from his grasp... at last."] = "J... Je suis libéré de ses mains... enfin."
L["Impossible! Stay your attack, mortals... I submit! I submit!"] = "Impossible! de continuer votre attaque, mortels ... envoyer! envoyer!"
L["INRAID"] = "DANS LE RAID"
L["Isn't it beautiful? I call it the magnificent aerial command unit!"] = "Isn't it beautiful? I call it the magnificent aerial command unit!" -- Requires localization
L["It would appear that I've made a slight miscalculation. I allowed my mind to be corrupted by the fiend in the prison, overriding my primary directive. All systems seem to be functional now. Clear."] = "Il semblerait que j'ai fait une légère erreur de calcul. Je laissais mon esprit être corrompue par les démon dans la prison, les lois de ma directive primaire. Tous les systèmes semblent être fonctionnels dès maintenant. Clair."
L["Julianne"] = "Julianne"
L["Kil'rek"] = "Kil'rek"
L["LDB Plugin"] = "Plugin LDB"
L["Legendary"] = "Legendaire"
L["Link items on the boss/mob that are above the loot threshold to guild chat."] = "Montre les objets lootes dans le canal de guilde"
L["Link items on the boss/mob that are above the loot threshold to raid chat."] = "Montre les objets lootes dans le canal de raid"
L["Link to Guild"] = "Montre a la guilde"
L["Link to Raid"] = "Montrer au raid"
L["List DKP"] = "Liste des DKP"
L["Main: "] = "Perso principal: "
L["Main character %s does not exist.  No changes made."] = "Le perso principal %s n existe pas. Aucun changement effectue"
L["Main DKP Pool"] = "Pool de DKP principal"
L["Master Looter"] = "Maitre du butin"
L["Member assigned to disenchant items."] = "Joueur assign au dispell des objets"
L["ML/DE mode"] = "Mode ML/DE"
L["Mode where a boss attempt is recorded when you die via a confirmation dialogue."] = "Mode ou un essai de boss est valide quand vous mourrez via une fenetre de confirmation."
L["MorgBid2 Options"] = "Options de MorgBid2"
L["MorgBid2 updating"] = "Mise a jour de MorgBid2"
L["MorgBid2 Version Query"] = "Verification des versions MorgBid2"
L["Morgbid check"] = "Verification MorgBid"
L["MorgDKP2"] = "MorgDKP2"
L["MultiPool"] = "Pools multiples"
L["NEED"] = "BESOIN"
L["NEED text"] = "Texte de BESOIN"
L["NEW"] = "NOUVEAU"
L["No current raid exists."] = "Aucun raid existant"
L["No longer will I be a slave to Malygos! Challenge me and you will be destroyed!"] = "No longer will I be a slave to Malygos! Challenge me and you will be destroyed!" -- Requires localization
L["NONE"] = "AUCUN"
L["Not Set"] = "Pas regle"
L["Now querying for %s  ID = %s  DKP = %s"] = "Enchere en cours pour : %s ID= %s Valeur=%s DKP"
L["OFFLINE"] = "HORS LIGNE"
L["Offspec: "] = "Reroll: "
L["OFFSPEC"] = "SPE SECONDAIRE"
L["OFFSPEC text"] = "Texte de SPE SECONDAIRE"
L["ONLINE"] = "EN LIGNE"
L[ [=[On STANDBY.
|c000070ddClick:|r to enable.]=] ] = [=[En veille.
|c000070ddCliquez pour activer.]=]
L["Onyxian Whelp"] = "Dragonnet onyxien"
L["PASS"] = "PASSE"
L["PASS text"] = "Texte de PASSE"
L["PENDING"] = "ATTENTE"
L["PENDING..."] = "EN ATTENTE..."
L["Perhaps it is your imperfection that which grants you free will. That allows you to persevere against cosmically calculated odds. You prevailed where the Titans' own perfect creations have failed."] = "Perhaps it is your imperfection that which grants you free will. That allows you to persevere against cosmically calculated odds. You prevailed where the Titans' own perfect creations have failed." -- Requires localization
L["Please install MorgBid2 to bid on items.  http://www.wowace.com/projects/morg-bid2/ Thank-you:)"] = "Veuillez installer MorgBid2 pour encherir sur les objets. http://www.wowace.com/projects/morg-bid2/ Merci."
L["Please whisper: dkplist [poolname] [class] [class] .... [all]"] = "SVP, chuchotez : dkplist [nom du pool] [classe] [classe] .... [all]"
L["Plugin frame will not disappear until UI reloaded."] = "La fenetre du plugin ne disparaitra qu au rechargement de l UI."
L["Poor"] = "Mediocre"
L["Preliminary testing phase complete. Now comes the true test!"] = "Preliminary testing phase complete. Now comes the true test!" -- Requires localization
L["Quality Threshold"] = "Niveau de qualite"
L["Raid Tracker"] = "Raid Tracker" -- Requires localization
L["Raid Tracker for viewing and editing current raids."] = "Raid Tracker pour la visualisation et l'édition des raids en cours."
L["Rare"] = "Rare"
L["Record boss attempt for %s?"] = "Enregistrer l essai du boss pour %s?"
L["Romulo"] = "Romulo"
L["Romulo & Julianne"] = "Romulo & Julianne"
L["Set DKP Pool to be primary DKP pool. Only pool if not using multiPool"] = "Regle le pool DKP principal. Le seul pool si pas de pools multiples"
L["Show minimap icon"] = "Montrer l icone de la minimap"
L["%s joined the raid at %s."] = "%s rejoint le raid a %."
L["%s left the raid at %s."] = "%s quitte le raid a %s."
L["Son of Flame"] = "Fils des flammes"
L["Sorry your response format is incorrect or no item with that ID is up for bidding.  Format = mbid [ID/link] [%s/%s/%s/%s] [bid value]"] = "Desole, le format de votre reponse est incorrect ou aucun objet avec cet ID n est pas en enchere.  Format = mbid [ID ou lien] [%s/%s/%s/%s] [valeur enchere]"
L["%s received %s for %s DKP"] = "%s recoit %s pour %s DKP."
L["Start Raid"] = "Commencer un raid"
L["Stay your arms! I yield!"] = "Stay your arms! I yield!" -- Requires localization
L["TAKE"] = "PREND"
L["TAKE text"] = "Texte de PREND"
L["Text of MorgBid2 NEED button"] = "Texte du bouton BESOIN de MorgBid2"
L["Text of MorgBid2 OFFSPEC button"] = "Texte du bouton SPE SECONDAIRE de MorgBid2"
L["Text of MorgBid2 PASS button"] = "Texte du bouton PASSE de MorgBid2"
L["Text of MorgBid2 TAKE button"] = "Texte du bouton PREND de MorgBid2"
L["The Alliance falter. Onward to the Lich King!"] = "The Alliance falter. Onward to the Lich King!" -- Requires localization
L["The first kill goes to me! Anyone care to wager?"] = "The first kill goes to me! Anyone care to wager?" -- Requires localization
L["The halls of Karazhan shake, as the curse binding the doors of the Gamesman's Hall is lifted."] = "The halls of Karazhan shake, as the curse binding the doors of the Gamesman's Hall is lifted." -- Requires localization
L["The Legion's final conquest has begun! Once again the subjugation of this world is within our grasp. Let none survive!"] = "La onquête finale de la Légion a commencé! Une fois de plus l'assujettissement de ce monde est à notre portée. Personne ne survivra"
L["These are the hallmarks..."] = "Ces sont les maîtres mots ..."
L["The time is now! Leave none standing! "] = "The time is now! Leave none standing! " -- Requires localization
L["This item is not currently up for bid."] = "Cet objet n est pas en enchere actuellement"
L["Toggle LDB Plugin"] = "Activer le plugin LDB"
L["Toggle MorgDKP2"] = "Activer/Arreter MorgDKP2"
L["Transeferred %s DKP to %s from %s"] = "%s DKP transferes vers %s depuis %s"
L["Transferred %s to %s for %s DKP."] = "%s donne a %s pour % DKP"
L["Uncommon"] = "Inhabituel"
L["Unique"] = "Unique"
L["Unique-equipped"] = "Unique-equipped" -- Requires localization
L["UNKNOWN"] = "INCONNU"
L["Use earned DKP in the invite tablet (shift-click)."] = "Use earned DKP in the invite tablet (shift-click)." -- Requires localization
L["Use OFFSPEC"] = "Utiliser SPE SECONDAIRE"
L["WAIT"] = "ATTEND"
L["What devil art thou, that dost torment me thus?"] = "What devil art thou, that dost torment me thus?" -- Requires localization
L["Whispers all members (even if they have MorgBid2) so they can reply and bid using whispers."] = "Whispers all members (even if they have MorgBid2) so they can reply and bid using whispers." -- Requires localization
L["Whisper system"] = "Chuchotement système"
L["World Boss"] = "World Boss" -- Requires localization
L["xINRAIDx"] = "x DANS LE RAID x"
L["xWAITx"] = "x ATTEND x"
L["You are defenders of a doomed world! Flee here, and perhaps you will prolong your pathetic lives!"] = "You are defenders of a doomed world! Flee here, and perhaps you will prolong your pathetic lives!" -- Requires localization
L["You can not use this function out of a raid group."] = "Vous ne pouvez pas utiliser cette fonction en dehors d un groupe de raid."
L["You may want to take cover."] = "You may want to take cover." -- Requires localization
L["You must start a raid before you can start a query."] = "Vous devez commencer un raid avant de pouvoir lancer une enchere"
L["Your response has been accepted: %s"] = "Votre reponse a ete acceptee : %s"
L["You will not defeat the Assembly of Iron so easily, invaders!"] = "You will not defeat the Assembly of Iron so easily, invaders!" -- Requires localization
L.BidWar = {
	["Beginning auction for %s:  ID = %s"] = "Beginning auction for %s:  ID = %s", -- Requires localization
	["Bidding is now closed."] = "Bidding is now closed.", -- Requires localization
	["Bid Format = mbid [ID/link] [%s/%s/%s] [bid value]"] = "Bid Format = mbid [ID/link] [%s/%s/%s] [bid value]", -- Requires localization
	Bidstep = "Bidstep", -- Requires localization
	BidWar = "BidWar",
	["BidWar mode changes the MorgBid query to allow players to bid on items.  Also the MorgDKP tablet uses bids after this NOT member DKP."] = "BidWar mode changes the MorgBid query to allow players to bid on items.  Also the MorgDKP tablet uses bids after this NOT member DKP.", -- Requires localization
	["BidWar Options"] = "BidWar Options", -- Requires localization
	["Changes the DKP step for BidWar mode.  Passes this value to MorgBid2 clients."] = "Changes the DKP step for BidWar mode.  Passes this value to MorgBid2 clients.", -- Requires localization
	["Enable BidWar mode where the winner is charged the 2nd highest bid value for the item."] = "Enable BidWar mode where the winner is charged the 2nd highest bid value for the item.", -- Requires localization
	["Enable BidWar mode with only one round of bidding and no reporting to raid chat."] = "Enable BidWar mode with only one round of bidding and no reporting to raid chat.", -- Requires localization
	["Just enough"] = "Just enough", -- Requires localization
	["Maximum amount of DKP that members can exceed their current DKP."] = "Maximum amount of DKP that members can exceed their current DKP.", -- Requires localization
	["New high bidder for %s: %s = %s"] = "New high bidder for %s: %s = %s", -- Requires localization
	Overbid = "Overbid", -- Requires localization
	["Silent auction"] = "Silent auction", -- Requires localization
	["Sorry this is a silent auction and you have already placed your bid."] = "Sorry this is a silent auction and you have already placed your bid.", -- Requires localization
	["You have exceeded the overbid amount of %s.  Your bid has been reset to the maximum."] = "You have exceeded the overbid amount of %s.  Your bid has been reset to the maximum.", -- Requires localization
}
L.DKPovertime = {
	["Added %s DKP to %s attendees."] = "Added %s DKP to %s attendees.", -- Requires localization
	["Award amount"] = "Award amount", -- Requires localization
	["Award time"] = "Award time", -- Requires localization
	["DKP/time"] = "DKP/time", -- Requires localization
	["DKP/time event name"] = "DKP/time event name", -- Requires localization
	["DKP/time Options"] = "DKP/time Options", -- Requires localization
	["DKP/time system which allows you to award DKP at custom intervals."] = "DKP/time system which allows you to award DKP at custom intervals.", -- Requires localization
	[ [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=] ] = [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=], -- Requires localization
	["Time in minutes between DKP awards."] = "Time in minutes between DKP awards.", -- Requires localization
}
L.Eventnaming = {
	["Allows you to change the default format for event names."] = "Allows you to change the default format for event names.", -- Requires localization
	["Boss format"] = "Boss format", -- Requires localization
	Default = "Default", -- Requires localization
	Enable = "Enable", -- Requires localization
	["Event naming"] = "Event naming", -- Requires localization
	[ [=[Format of boss event names:  
<zone> - <boss>
Example:  <boss> <diff>]=] ] = [=[Format of boss event names:  
<zone> - <boss>
Example:  <boss> <diff>]=], -- Requires localization
	[ [=[Format of run event name:  
<zone> text  
Example:  <zone> <diff> Run]=] ] = [=[Format of run event name:  
<zone> text  
Example:  <zone> <diff> Run]=], -- Requires localization
	[ [=[Format of start event name:  
<zone> text  
Example:  <zone> <diff> Start]=] ] = [=[Format of start event name:  
<zone> text  
Example:  <zone> <diff> Start]=], -- Requires localization
	["Reset default values."] = "Reset default values.", -- Requires localization
	["Run format"] = "Run format", -- Requires localization
	["Start format"] = "Start format", -- Requires localization
	["Toggle event naming"] = "Toggle event naming", -- Requires localization
}
L.FixedDKP = {
	["DKP TAKE/OFFSPEC settings"] = "DKP TAKE/OFFSPEC settings", -- Requires localization
	Enable = "Enable", -- Requires localization
	["Enable OFFSPEC"] = "Enable OFFSPEC", -- Requires localization
	["Enables mode where members are charged a standard price for OFFSPEC items."] = "Enables mode where members are charged a standard price for OFFSPEC items.", -- Requires localization
	["Enables mode where members are charged a standard price for TAKE items."] = "Enables mode where members are charged a standard price for TAKE items.", -- Requires localization
	["Enable TAKE"] = "Enable TAKE", -- Requires localization
	["Fixed DKP"] = "Fixed DKP", -- Requires localization
	["OFFSPEC Percent"] = "OFFSPEC Percent", -- Requires localization
	["OFFSPEC value"] = "OFFSPEC value", -- Requires localization
	["Standard DKP system."] = "Standard DKP system.", -- Requires localization
	["TAKE Percent"] = "TAKE Percent", -- Requires localization
	["TAKE value"] = "TAKE value", -- Requires localization
	["Use percent of item value for OFFSPEC mode."] = "Use percent of item value for OFFSPEC mode.", -- Requires localization
	["Use percent of item value for TAKE mode."] = "Use percent of item value for TAKE mode.", -- Requires localization
}
L.Lootframe = {
	Alt = "Alt", -- Requires localization
	["Always use"] = "Always use", -- Requires localization
	["Always use the MorgDKP2 loot window even when the mod is in standby mode."] = "Always use the MorgDKP2 loot window even when the mod is in standby mode.", -- Requires localization
	["|c000070ddClick:|r allocate randomly"] = "|c000070ddClick:|r allocate randomly", -- Requires localization
	["|c000070ddClick:|r Announce winner."] = "|c000070ddClick:|r Announce winner.", -- Requires localization
	["|c000070ddClick:|r give item to disenchanter"] = "|c000070ddClick:|r give item to disenchanter", -- Requires localization
	["|c000070ddClick:|r give this item to disenchanter."] = "|c000070ddClick:|r give this item to disenchanter.", -- Requires localization
	[ [=[|c000070ddClick:|r loot item
|c000070ddR-Click:|r open itemdata or roll frame
|c000070ddAlt-R-Click:|r start all queries]=] ] = [=[|c000070ddClick:|r loot item
|c000070ddR-Click:|r open itemdata or roll frame
|c000070ddAlt-R-Click:|r start all queries]=], -- Requires localization
	["|c000070ddClick:|r select pool to use for item."] = "|c000070ddClick:|r select pool to use for item.", -- Requires localization
	["|c000070ddClick:|r self loot"] = "|c000070ddClick:|r self loot", -- Requires localization
	[ [=[|c000070ddClick:|r start item query.
|c000070ddAlt-Click:|r start all queries
|c000070ddShift-Click:|r random query for this item
|c000070ddCtrl-Click:|r ignore this item]=] ] = [=[|c000070ddClick:|r start item query.
|c000070ddAlt-Click:|r start all queries
|c000070ddShift-Click:|r random query for this item
|c000070ddCtrl-Click:|r ignore this item]=], -- Requires localization
	["|c000070ddClick:|r stop this item query."] = "|c000070ddClick:|r stop this item query.", -- Requires localization
	[ [=[|c000070ddMousewheel up/Click|r - Increase value.
|c000070ddMousewheel down/R-Click|r - decrease value.
|c000070ddSHIFT|r - change value by +/-1
|c000070ddALT|r - change value by +/-20
|c000070ddCTRL|r - change value by +/-100]=] ] = [=[|c000070ddMousewheel up/Click|r - Increase value.
|c000070ddMousewheel down/R-Click|r - decrease value.
|c000070ddSHIFT|r - change value by +/-1
|c000070ddALT|r - change value by +/-20
|c000070ddCTRL|r - change value by +/-100]=], -- Requires localization
	Class = "Class", -- Requires localization
	["DKP: %s"] = "DKP: %s", -- Requires localization
	["Give %s to %s, are you sure?"] = "Give %s to %s, are you sure?", -- Requires localization
	Lootframe = "Lootframe", -- Requires localization
	["Lootframe scale"] = "Lootframe scale", -- Requires localization
	["Open lootframe at cursor postition"] = "Open lootframe at cursor postition", -- Requires localization
	["Replace Blizzard"] = "Replace Blizzard", -- Requires localization
	["%s awarded to %s"] = "%s awarded to %s", -- Requires localization
	["%s awarded to %s for %s DKP"] = "%s awarded to %s for %s DKP", -- Requires localization
	["Select primary class"] = "Select primary class", -- Requires localization
	["Select secondary class"] = "Select secondary class", -- Requires localization
	["Snap to cursor"] = "Snap to cursor", -- Requires localization
	["%s will be disenchanted in 5 seconds."] = "%s will be disenchanted in 5 seconds.", -- Requires localization
	["When MorgDKP2 is active it's loot frame will replace default."] = "When MorgDKP2 is active it's loot frame will replace default.", -- Requires localization
}
L.Percent = {
	["Items will cost a percentage of the members total DKP."] = "Items will cost a percentage of the members total DKP.", -- Requires localization
	["Percent cost"] = "Percent cost", -- Requires localization
	["Percent DKP"] = "Percent DKP", -- Requires localization
	["Percent DKP Options"] = "Percent DKP Options", -- Requires localization
	["Percent take"] = "Percent take", -- Requires localization
	["When using the percent DKP system this option enables TAKE looting.  This means if the winning member rolled TAKE he will not be charged x% DKP he will instead be charged the base price of the item (Set using original itempoints."] = "When using the percent DKP system this option enables TAKE looting.  This means if the winning member rolled TAKE he will not be charged x% DKP he will instead be charged the base price of the item (Set using original itempoints.", -- Requires localization
}
L.PointsDB = {
	["Added alias: %s of %s with %s DKP."] = "Added alias: %s of %s with %s DKP.", -- Requires localization
	["Addeded %s to item database."] = "Addeded %s to item database.", -- Requires localization
	["Added %s players from %s"] = "Added %s players from %s", -- Requires localization
	["Add ignored item"] = "Add ignored item", -- Requires localization
	["Add item"] = "Add item", -- Requires localization
	["Add new item to ignore.  Drag the item to this input box."] = "Add new item to ignore.  Drag the item to this input box.", -- Requires localization
	["Add new item to track.  Drag the item to this input box."] = "Add new item to track.  Drag the item to this input box.", -- Requires localization
	["Clear player DB"] = "Clear player DB", -- Requires localization
	["Clear raid DB"] = "Clear raid DB", -- Requires localization
	["Clears all items in the database below the selected item level."] = "Clears all items in the database below the selected item level.", -- Requires localization
	["Clears all members in the database inactive longer than the selected number of weeks."] = "Clears all members in the database inactive longer than the selected number of weeks.", -- Requires localization
	["Clears all players currently in the database. Does not affect items."] = "Clears all players currently in the database. Does not affect items.", -- Requires localization
	["Clears the current tracked raids."] = "Clears the current tracked raids.", -- Requires localization
	["Cull item DB"] = "Cull item DB", -- Requires localization
	["Cull item level"] = "Cull item level", -- Requires localization
	["Cull member DB"] = "Cull member DB", -- Requires localization
	["Cull member level (weeks)"] = "Cull member level (weeks)", -- Requires localization
	["Current rank weight"] = "Current rank weight", -- Requires localization
	["Database Functions"] = "Database Functions", -- Requires localization
	["Database transfer complete. %s items were transferred and %s members updated."] = "Database transfer complete. %s items were transferred and %s members updated.", -- Requires localization
	["Higher number for higher display priority. (7 will appear above 3 on the tooltip)"] = "Higher number for higher display priority. (7 will appear above 3 on the tooltip)", -- Requires localization
	["Ignored items"] = "Ignored items", -- Requires localization
	["Import database from MorgDKP?"] = "Import database from MorgDKP?", -- Requires localization
	["Import default item database?"] = "Import default item database?", -- Requires localization
	["Imported MorgDKP DB with %s players and %s items."] = "Imported MorgDKP DB with %s players and %s items.", -- Requires localization
	["List of currently ignored items.  Click to remove item from ignore list."] = "List of currently ignored items.  Click to remove item from ignore list.", -- Requires localization
	["List of member ranks in the current pool."] = "List of member ranks in the current pool.", -- Requires localization
	["Player database cleared!"] = "Player database cleared!", -- Requires localization
	["Player DKP reset to zero!"] = "Player DKP reset to zero!", -- Requires localization
	["Please delete the ItemData.lua file from the MorgDKP directory now."] = "Please delete the ItemData.lua file from the MorgDKP directory now.", -- Requires localization
	["Rank weights"] = "Rank weights", -- Requires localization
	["Removed %s items from the database."] = "Removed %s items from the database.", -- Requires localization
	["Removed %s members from the database."] = "Removed %s members from the database.", -- Requires localization
	["Resets all members DKP to zero."] = "Resets all members DKP to zero.", -- Requires localization
	["Updating DKP Points.."] = "Updating DKP Points..", -- Requires localization
	["Zero player DB"] = "Zero player DB", -- Requires localization
}
L.RaidTracker = {
	Add = "Add", -- Requires localization
	["Alias Database"] = "Alias Database", -- Requires localization
	Aliases = "Aliases", -- Requires localization
	Alt = "Alt", -- Requires localization
	Attendees = "Attendees", -- Requires localization
	Class = "Class", -- Requires localization
	Close = "Close", -- Requires localization
	["Create new event"] = "Create new event", -- Requires localization
	["Current raid"] = "Current raid", -- Requires localization
	Delete = "Delete", -- Requires localization
	["Delete Raid"] = "Delete Raid", -- Requires localization
	["DKP Changes"] = "DKP Changes", -- Requires localization
	Enable = "Enable", -- Requires localization
	["Enter alias name"] = "Enter alias name", -- Requires localization
	["Enter DKP change amount"] = "Enter DKP change amount", -- Requires localization
	["Enter DKP change members"] = "Enter DKP change members", -- Requires localization
	["Enter event attendees"] = "Enter event attendees", -- Requires localization
	["Enter event name"] = "Enter event name", -- Requires localization
	["Enter event note"] = "Enter event note", -- Requires localization
	["Enter event value"] = "Enter event value", -- Requires localization
	["Enter item event"] = "Enter item event", -- Requires localization
	["Enter item value"] = "Enter item value", -- Requires localization
	["Enter item winner"] = "Enter item winner", -- Requires localization
	["Enter main name"] = "Enter main name", -- Requires localization
	Eventname = "Eventname", -- Requires localization
	Eventnote = "Eventnote", -- Requires localization
	["Export Raid"] = "Export Raid", -- Requires localization
	Group = "Group", -- Requires localization
	Ignore = "Ignore", -- Requires localization
	["Item Database"] = "Item Database", -- Requires localization
	["Item DB"] = "Item DB", -- Requires localization
	["Raid Editing"] = "Raid Editing", -- Requires localization
	Raids = "Raids", -- Requires localization
	["Raid Tracker"] = "Raid Tracker", -- Requires localization
	["Raid Tracker for viewing and editing current raids."] = "Raid Tracker for viewing and editing current raids.", -- Requires localization
	["Select primary class"] = "Select primary class", -- Requires localization
	["Select secondary class"] = "Select secondary class", -- Requires localization
	["Update attends"] = "Update attends", -- Requires localization
	Value = "Value", -- Requires localization
	["You can not remove the run event."] = "You can not remove the run event.", -- Requires localization
}
L.Random = {
	["Enable random rolling for items."] = "Enable random rolling for items.", -- Requires localization
	["Random rolls"] = "Random rolls", -- Requires localization
	["%s received %s."] = "%s received %s.", -- Requires localization
}
L.Relational = {
	["Enable Relational DKP for calculating the earned/spent dkp ratio."] = "Enable Relational DKP for calculating the earned/spent dkp ratio.", -- Requires localization
	["Minimum amount of DKP a member can have for calculating the DKP ratio to avoid a new member having a high ratio. ie  200 earned DKP/ (this value)"] = "Minimum amount of DKP a member can have for calculating the DKP ratio to avoid a new member having a high ratio. ie  200 earned DKP/ (this value)", -- Requires localization
	["Minimum DKP base"] = "Minimum DKP base", -- Requires localization
	["Relational DKP"] = "Relational DKP", -- Requires localization
	["Relational DKP Options"] = "Relational DKP Options", -- Requires localization
}
L.SKSotC = {
	["Amount of DKP to remove from members who miss a raid."] = "Amount of DKP to remove from members who miss a raid.", -- Requires localization
	["Demotion event"] = "Demotion event", -- Requires localization
	["Enable Suicide Kings SotC variant DKP."] = "Enable Suicide Kings SotC variant DKP.", -- Requires localization
	[ [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=] ] = [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=], -- Requires localization
	["Missed raid DKP"] = "Missed raid DKP", -- Requires localization
	["SKSotC DKP"] = "SKSotC DKP", -- Requires localization
	["SKSotC Options"] = "SKSotC Options", -- Requires localization
}
L.SKall = {
	["Enable raid award"] = "Enable raid award", -- Requires localization
	["Enables DKP removed from item winner to be awarded to raid members.  You must check use zerosum on the import webscript for website DKP to be correct."] = "Enables DKP removed from item winner to be awarded to raid members.  You must check use zerosum on the import webscript for website DKP to be correct.", -- Requires localization
	["Enable Suicide Kings spend all DKP."] = "Enable Suicide Kings spend all DKP.", -- Requires localization
	["% Member DKP"] = "% Member DKP", -- Requires localization
	["Percent of member DKP to remove."] = "Percent of member DKP to remove.", -- Requires localization
	["SKall DKP"] = "SKall DKP", -- Requires localization
	["SKall Options"] = "SKall Options", -- Requires localization
}
L.Syncing = {
	["Accept DKP changes from other raid leaders."] = "Accept DKP changes from other raid leaders.", -- Requires localization
	["Added %s to listeners."] = "Added %s to listeners.", -- Requires localization
	Automatic = "Automatic", -- Requires localization
	["Automatically set broadcast/receive depending if you are the master looter."] = "Automatically set broadcast/receive depending if you are the master looter.", -- Requires localization
	Broadcast = "Broadcast", -- Requires localization
	["Broadcast DKP changes to other raid leaders."] = "Broadcast DKP changes to other raid leaders.", -- Requires localization
	Enable = "Enable", -- Requires localization
	["Immediate Sync Options"] = "Immediate Sync Options", -- Requires localization
	["Imported options...restarting."] = "Imported options...restarting.", -- Requires localization
	["Imported %s items"] = "Imported %s items", -- Requires localization
	["Import %s data from %s?"] = "Import %s data from %s?", -- Requires localization
	["Initial Sync"] = "Initial Sync", -- Requires localization
	["Items Sync"] = "Items Sync", -- Requires localization
	["Members Sync"] = "Members Sync", -- Requires localization
	["Options Sync"] = "Options Sync", -- Requires localization
	["Overwrite raid"] = "Overwrite raid", -- Requires localization
	["Overwrite the current raid if you receive an initial sync and are currently in a raid."] = "Overwrite the current raid if you receive an initial sync and are currently in a raid.", -- Requires localization
	Password = "Password", -- Requires localization
	Receive = "Receive", -- Requires localization
	["Removed %s from listeners."] = "Removed %s from listeners.", -- Requires localization
	["Resends initial sync.  Only needed in cases where you have problems as this is done automatically."] = "Resends initial sync.  Only needed in cases where you have problems as this is done automatically.", -- Requires localization
	["Send DB Sync"] = "Send DB Sync", -- Requires localization
	["Sends your current database of item DKP values."] = "Sends your current database of item DKP values.", -- Requires localization
	["Sends your current database of member DKP values."] = "Sends your current database of member DKP values.", -- Requires localization
	["Sends your current database of member DKP values, item values, and MorgDKP2 options to the current raid."] = "Sends your current database of member DKP values, item values, and MorgDKP2 options to the current raid.", -- Requires localization
	["Sends your current MorgDKP2 options.  Note will restart MorgDKP2 so do not send another sync until it restarts or use full sync and it will be handled properly."] = "Sends your current MorgDKP2 options.  Note will restart MorgDKP2 so do not send another sync until it restarts or use full sync and it will be handled properly.", -- Requires localization
	["%s's MorgDKP2 is out of date!"] = "%s's MorgDKP2 is out of date!", -- Requires localization
	["%s's password does not match your password!"] = "%s's password does not match your password!", -- Requires localization
	Syncing = "Syncing", -- Requires localization
	["Syncing password"] = "Syncing password", -- Requires localization
	["Syncing system for communicating DKP between raid leaders."] = "Syncing system for communicating DKP between raid leaders.", -- Requires localization
	["Updated %s members"] = "Updated %s members", -- Requires localization
}
L.TakeBid = {
	Bidstep = "Bidstep", -- Requires localization
	["Changes the DKP step for TakeBid mode.  Passes this value to MorgBid2 clients."] = "Changes the DKP step for TakeBid mode.  Passes this value to MorgBid2 clients.", -- Requires localization
	["Maximum amount of DKP that members can exceed their current DKP."] = "Maximum amount of DKP that members can exceed their current DKP.", -- Requires localization
	["Minimum amount of DKP that members can bid for an item."] = "Minimum amount of DKP that members can bid for an item.", -- Requires localization
	["Minimum bid"] = "Minimum bid", -- Requires localization
	Overbid = "Overbid", -- Requires localization
	["TakeBid DKP"] = "TakeBid DKP", -- Requires localization
	["TakeBid Options"] = "TakeBid Options", -- Requires localization
	["Variation of Fixed DKP where when you bid take you also enter what you are willing to pay."] = "Variation of Fixed DKP where when you bid take you also enter what you are willing to pay.", -- Requires localization
}
L.Tracker = {
	["and add these attendees < %s min?"] = "and add these attendees < %s min?", -- Requires localization
	["Attendance reward"] = "Attendance reward", -- Requires localization
	["Bank character"] = "Bank character", -- Requires localization
	CANCEL = "CANCEL", -- Requires localization
	["Clear the raid database?"] = "Clear the raid database?", -- Requires localization
	[ [=[Core of all MorgDKP2 raid tracking features. 
Can not be disabled.]=] ] = [=[Core of all MorgDKP2 raid tracking features. 
Can not be disabled.]=], -- Requires localization
	["CTRT format"] = "CTRT format", -- Requires localization
	["DKP Export"] = "DKP Export", -- Requires localization
	["DKP listener"] = "DKP listener", -- Requires localization
	["DKP Tracking"] = "DKP Tracking", -- Requires localization
	["DKP which new members to the database receive."] = "DKP which new members to the database receive.", -- Requires localization
	["End Raid"] = "End Raid", -- Requires localization
	["End %s"] = "End %s", -- Requires localization
	["Eqdkp+ event format"] = "Eqdkp+ event format", -- Requires localization
	["Events for DKP changes"] = "Events for DKP changes", -- Requires localization
	["Export Raids"] = "Export Raids", -- Requires localization
	["Exports current raid(s) data for import into website."] = "Exports current raid(s) data for import into website.", -- Requires localization
	["Finalizes the current raid."] = "Finalizes the current raid.", -- Requires localization
	["Format of new member DKP event name."] = "Format of new member DKP event name.", -- Requires localization
	["General options"] = "General options", -- Requires localization
	["Guildlaunch format"] = "Guildlaunch format", -- Requires localization
	["Minimum time to add member to raid and award run DKP."] = "Minimum time to add member to raid and award run DKP.", -- Requires localization
	["New member DKP event"] = "New member DKP event", -- Requires localization
	["New member start DKP"] = "New member start DKP", -- Requires localization
	NO = "NO", -- Requires localization
	["No current raid exists."] = "No current raid exists.", -- Requires localization
	["Opens the raidtracker interface."] = "Opens the raidtracker interface.", -- Requires localization
	["Previous best kill time: %s"] = "Previous best kill time: %s", -- Requires localization
	["Raid Tracker"] = "Raid Tracker", -- Requires localization
	["Remember kill times"] = "Remember kill times", -- Requires localization
	["Removed %s raid attendees."] = "Removed %s raid attendees.", -- Requires localization
	["Remove the ' character from any event names because eqdkp+ is dumb."] = "Remove the ' character from any event names because eqdkp+ is dumb.", -- Requires localization
	["Sartharion minibosses"] = "Sartharion minibosses", -- Requires localization
	["%s defeated in %s!"] = "%s defeated in %s!", -- Requires localization
	Shortcuts = "Shortcuts", -- Requires localization
	["Single run event"] = "Single run event", -- Requires localization
	["Sorry %s is an invalid database pool.  Please choose a correct one or export your DKP from your website."] = "Sorry %s is an invalid database pool.  Please choose a correct one or export your DKP from your website.", -- Requires localization
	["%s recorded at %s with %s attendees."] = "%s recorded at %s with %s attendees.", -- Requires localization
	["Start Event"] = "Start Event", -- Requires localization
	["Start Raid"] = "Start Raid", -- Requires localization
	["Starts a new raid."] = "Starts a new raid.", -- Requires localization
	["Store your best kill times for bosses."] = "Store your best kill times for bosses.", -- Requires localization
	["Trigger events for Sartharion minibosses."] = "Trigger events for Sartharion minibosses.", -- Requires localization
	["Use a bank character in raids."] = "Use a bank character in raids.", -- Requires localization
	["Use CTRT export format for raid exports."] = "Use CTRT export format for raid exports.", -- Requires localization
	["Use events for DKP changes instead of database adjustments."] = "Use events for DKP changes instead of database adjustments.", -- Requires localization
	["Use guildlaunch export format for raid exports."] = "Use guildlaunch export format for raid exports.", -- Requires localization
	["Use one event for entire raid.  Boss kills will not be tracked separately."] = "Use one event for entire raid.  Boss kills will not be tracked separately.", -- Requires localization
	["Use start event when raid begins."] = "Use start event when raid begins.", -- Requires localization
	["When you are in a tracked zone you will track DKP but you will not get the loot popup window or link to the raid.  You will act like a backup raidlog."] = "When you are in a tracked zone you will track DKP but you will not get the loot popup window or link to the raid.  You will act like a backup raidlog.", -- Requires localization
	YES = "YES", -- Requires localization
	["Yes & Add"] = "Yes & Add", -- Requires localization
}
L.Waitlist = {
	["Added %s to the waitlist."] = "Added %s to the waitlist.", -- Requires localization
	["Added you to the waitlist."] = "Added you to the waitlist.", -- Requires localization
	["Amount of DKP to reward after members have been on the waitlist for the current reward time."] = "Amount of DKP to reward after members have been on the waitlist for the current reward time.", -- Requires localization
	["Amount of DKP to reward at raidstart."] = "Amount of DKP to reward at raidstart.", -- Requires localization
	["Amount of DKP to reward to waitlist members per bosskill."] = "Amount of DKP to reward to waitlist members per bosskill.", -- Requires localization
	["Amount of DKP to reward to waitlist members when awarding regular members DKP/time. Note: only works if you are awarding DKP/time."] = "Amount of DKP to reward to waitlist members when awarding regular members DKP/time. Note: only works if you are awarding DKP/time.", -- Requires localization
	["Autochannel Spam"] = "Autochannel Spam", -- Requires localization
	["Award DKP"] = "Award DKP", -- Requires localization
	["Award DKP to current waitlist members"] = "Award DKP to current waitlist members", -- Requires localization
	Channels = "Channels", -- Requires localization
	["Channels to spam when starting invites."] = "Channels to spam when starting invites.", -- Requires localization
	["Clears the current wailist."] = "Clears the current wailist.", -- Requires localization
	["Clear Waitlist"] = "Clear Waitlist", -- Requires localization
	["Current waitlist: %s"] = "Current waitlist: %s", -- Requires localization
	Enable = "Enable", -- Requires localization
	["Event Names"] = "Event Names", -- Requires localization
	[ [=[Format of waitlist boss events:  
<boss> text  
Example:  <boss> Waitlist DKP]=] ] = [=[Format of waitlist boss events:  
<boss> text  
Example:  <boss> Waitlist DKP]=], -- Requires localization
	[ [=[Format of waitlist event names:  
<zone> text  
Example:  <zone> Waitlist DKP]=] ] = [=[Format of waitlist event names:  
<zone> text  
Example:  <zone> Waitlist DKP]=], -- Requires localization
	["Grace Period"] = "Grace Period", -- Requires localization
	["Minimum time before offline waitlist members will be removed."] = "Minimum time before offline waitlist members will be removed.", -- Requires localization
	["Minimum time to award run DKP to a waitlist member."] = "Minimum time to award run DKP to a waitlist member.", -- Requires localization
	["Now accepting tells for the waitlist.  Please whisper %s using this format:  mbid wait[+/-] [main]"] = "Now accepting tells for the waitlist.  Please whisper %s using this format:  mbid wait[+/-] [main]", -- Requires localization
	["Please log on to your main for an invite to the raid.  Whisper me when online."] = "Please log on to your main for an invite to the raid.  Whisper me when online.", -- Requires localization
	["Removed %s from wailist."] = "Removed %s from wailist.", -- Requires localization
	["Removed %s from waitlist due to inactivity"] = "Removed %s from waitlist due to inactivity", -- Requires localization
	["Removed you from the waitlist."] = "Removed you from the waitlist.", -- Requires localization
	["Spam channels automatically when opening the invite tablet."] = "Spam channels automatically when opening the invite tablet.", -- Requires localization
	["Spam channels with current waitlist."] = "Spam channels with current waitlist.", -- Requires localization
	["Spam channels with waitinfo now."] = "Spam channels with waitinfo now.", -- Requires localization
	["Spam Current"] = "Spam Current", -- Requires localization
	["Spam Waitinfo"] = "Spam Waitinfo", -- Requires localization
	["That main does not exist."] = "That main does not exist.", -- Requires localization
	Waitlist = "Waitlist", -- Requires localization
	["Waitlist allows members to whisper you for invites and to receive DKP even if not in the actual raid."] = "Waitlist allows members to whisper you for invites and to receive DKP even if not in the actual raid.", -- Requires localization
	["Waitlist boss DKP"] = "Waitlist boss DKP", -- Requires localization
	["Waitlist boss event name"] = "Waitlist boss event name", -- Requires localization
	["Waitlist DKP/time"] = "Waitlist DKP/time", -- Requires localization
	["Waitlist event name"] = "Waitlist event name", -- Requires localization
	["Waitlist reward"] = "Waitlist reward", -- Requires localization
	["Waitlist run DKP"] = "Waitlist run DKP", -- Requires localization
	["Waitlist spamming"] = "Waitlist spamming", -- Requires localization
	["Waitlist start DKP"] = "Waitlist start DKP", -- Requires localization
}
L.Whisper = {
	Enable = "Enable", -- Requires localization
	["%s: ID = %s  DKP/Bid value = %s  (Reply format: mbid ID [%s/%s/%s/%s bid value])"] = "%s: ID = %s  DKP/Bid value = %s  (Reply format: mbid ID [%s/%s/%s/%s bid value])", -- Requires localization
	["Whispers all members (even if they have MorgBid) so they can reply and bid using whispers."] = "Whispers all members (even if they have MorgBid) so they can reply and bid using whispers.", -- Requires localization
	["Whisper system"] = "Whisper system", -- Requires localization
}
L.Zerosum = {
	["Added %s DKP to %s attendees."] = "Added %s DKP to %s attendees.", -- Requires localization
	["DKP award event name"] = "DKP award event name", -- Requires localization
	[ [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=] ] = [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=], -- Requires localization
	["Include waitlist"] = "Include waitlist", -- Requires localization
	["Include waitlist members in DKP calculations.  Note they will still get whatever DKP award is set in the waitlist module."] = "Include waitlist members in DKP calculations.  Note they will still get whatever DKP award is set in the waitlist module.", -- Requires localization
	["Standard zero sum system where member is charged for the item and the charged points are divided between all raid members.  You must check use zerosum on the import webscript for website DKP to be correct."] = "Standard zero sum system where member is charged for the item and the charged points are divided between all raid members.  You must check use zerosum on the import webscript for website DKP to be correct.", -- Requires localization
	["Zerosum DKP"] = "Zerosum DKP", -- Requires localization
	["Zerosum Options"] = "Zerosum Options", -- Requires localization
}

