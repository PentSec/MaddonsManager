﻿local L = LibStub("AceLocale-3.0"):NewLocale("MorgDKP2", "deDE")
if not L then return end

L["Abandon all hope! The Legion has returned to finish what was begun so many years ago. This time, there will be no escape!"] = "Lasst alle Hoffnungen zurück! Die Legion ist zurückgekehrt um zu beenden, was sie vor so vielen Jahren begonnen hat. Dieses Mal wird es kein Entkommen geben!"
L["Add a custom raid event.  This will record all attendees when you click the event menu by adding Attempt to the end of the boss name you have targeted.  You can change event name value through raid tracker.  SHIFT-Click to bypass menu."] = "Ein besonderes Raidereignis hinzufügen.  Es wird die Liste der Anwesenden aufgezeichnet, wenn man auf das Ereignismenü klickt. Es wird Attempt (Versuch) an das Ende des Bossnamens gehängt, der bekämpft wurde.  Der Eventname kann danach über den Raidtracker geändert werden.  Shift-Klick, um das Menü zu umgehen."
L["Added %s DKP to %s."] = "%s DKP an %s vergeben."
L["Added %s DKP to %s attendees."] = "%s DKP an %s Anwesende vergeben."
L["Added %s DKP to waitlist attendees."] = "%s DKP an alle in der Warteliste vergeben."
L["Added %s to ignore list."] = "%s zur Ignore Liste hinzugefügt."
L["Alexstrasza's Gift"] = "Alexstraszas Geschenk"
L["Alias %s already exihists.  No changes made."] = "Twink %s existiert bereits. Keine Änderungen vorgenommen."
L["ALL"] = "ALLE"
L["Allow the OFFSPEC button to be used in MorgBid2."] = "Erlaubt es, den OFFSPEC Knopf in MorgBid2 zu verwenden."
L["Allow updating bid results in MorgBid2."] = "Erlaubt es, Bietergebnisse in MorgBid2 nachträglich zu verändern."
L["Amani Dragonhawk Spirit"] = "Drachenfalkengeist der Amani"
L["Anything below this quality threshold will NOT be logged."] = "Alle Teile unterhalb dieser Schwelle werden nicht aufgezeichnet."
L["Artifact"] = "Artefakt"
L["A shallow and tragic victory. We are weaker as a whole from the losses suffered today. Who but the Lich King could benefit from such foolishness? Great warriors have lost their lives. And for what? The true threat looms ahead - the Lich King awaits us all in death."] = "A shallow and tragic victory. We are weaker as a whole from the losses suffered today. Who but the Lich King could benefit from such foolishness? Great warriors have lost their lives. And for what? The true threat looms ahead - the Lich King awaits us all in death." -- Requires localization
L["Assembly of Iron"] = "Versammlung des Eisens"
L["Automatically enable MorgDKP2 and start a raid when entering a trackable zone."] = "Schaltet MorgDKP2 automatisch ein, wenn eine Raidzone betreten wird."
L["Autozone"] = "Autozone"
L["Background color"] = "Hintergrundfarbe"
L["Background texture"] = "Hintergrundmuster"
L["Background texture of frames/tooltips."] = [=[Muster, das für den Hintergrund von 
Fentern und Tooltips verwendet wird.]=]
L["Bank"] = "Bank"
L["Border color"] = "Rahmenfarbe"
L["Border texture"] = "Rahmenmuster"
L["Border texture of frames/tooltips."] = [=[Muster, das für Rahmen von 
Fenstern und Tooltips verwendet wird.]=]
L["Boss attempt mode"] = "Bossversuchsmodus"
L["Boss Attempt Mode"] = "Bossversuchsmodus"
L[ [=[|c000070ddClick:|r MorgBid2 Base query.
|c000070ddALT-Click:|r Toggle ML/DE
|c000070ddSHIFT-Click:|r Invite & Waitlist.
|c000070ddCTRL-Click:|r Raid Tracker.
|c000070ddCTRL-Click Itemlink:|r Ignore item.]=] ] = [=[|c000070ddR-Klick:|r Optionsmenü.
|c000070ddKlick:|r MorgBid2 Versionsabgleich.
|c000070ddALT-Klick:|r ML/DE Modus umschalten
|c000070ddSHIFT-Klick:|r Lade- & Warteliste.
|c000070ddCTRL-Klick:|r Raid Tracker.
|c000070ddCTRL-Klick auf Gegenstand:|r Ignorieren.]=]
L[ [=[|c000070ddClick:|r Nag old versions now
|c000070ddR-Click:|r Close tablet.]=] ] = [=[|c000070ddClick:|r Klepper jetzt alte Versin
|c000070ddR-Click:|r Tablet schließen.]=]
L[ [=[|c000070ddL-Click:|r Invite.
|c000070ddCTRL-Click:|r Delete Character.
|c000070ddALT-Click:|r Add to waitlist.
|c000070ddSHIFT-Click:|r Remove from waitlist.
|c000070ddR-Click:|r Close tablet.]=] ] = [=[|c000070ddL-Klick:|r Einladen.
|c000070ddCTRL-Klick:|r Character löschen.
|c000070ddALT-Klick:|r Zur Warteliste hinzufügen.
|c000070ddSHIFT-Klick:|r Aus Warteliste entfernen.
|c000070ddR-Klick:|r Fenster schliessen.]=]
L["|c001eff00ON|r"] = "|c001eff00ON|r"
L["|c009d9d9dOFF|r"] = "|c009d9d9dOFF|r"
L["Cache of Innovation"] = "Schrein der Innovation"
L["Cache of Living Stone"] = "Schrein des lebenden Gesteins"
L["Cache of Storms"] = "Schrein der Stürme"
L["Cache of the Firelord"] = "Behälter des Feuerfürsten"
L["Cache of Winter"] = "Schrein des Winters"
L["|cff0070dd|Hitem:14344:0:0:0:0:0:0:0|h[Large Brilliant Shard]|h|r"] = "|cff0070dd|Hitem:14344:0:0:0:0:0:0:0|h[Großer glänzender Splitter]|h|r"
L["|cff0070dd|Hitem:22448:0:0:0:0:0:0:0|h[Small Prismatic Shard]|h|r"] = "|cff0070dd|Hitem:22448:0:0:0:0:0:0:0|h[Kleiner Prismasplitter]|h|r"
L["|cff0070dd|Hitem:22449:0:0:0:0:0:0:0|h[Large Prismatic Shard]|h|r"] = "|cff0070dd|Hitem:22449:0:0:0:0:0:0:0|h[Großer Prismasplitter]|h|r"
L["|cffa335ee|Hitem:18562:0:0:0:0:0:0:0|h[Elementium Ore]|h|r"] = "|cffa335ee|Hitem:18562:0:0:0:0:0:0:0|h[Elementiumerz]|h|r"
L["|cffa335ee|Hitem:20725:0:0:0:0:0:0:0|h[Nexus Crystal]|h|r"] = "|cffa335ee|Hitem:20725:0:0:0:0:0:0:0|h[Nexuskristall]|h|r"
L["|cffa335ee|Hitem:22450:0:0:0:0:0:0:0|h[Void Crystal]|h|r"] = "|cffa335ee|Hitem:22450:0:0:0:0:0:0:0|h[Kristall der Leere]|h|r"
L["|cffa335ee|Hitem:29434:0:0:0:0:0:0:0|h[Badge of Justice]|h|r"] = "|cffa335ee|Hitem:29434:0:0:0:0:0:0:0|h[Abzeichen der Gerechtigkeit]|h|r"
L["|cffa335ee|Hitem:32230:0:0:0:0:0:0:0|h[Shadowsong Amethyst]|h|r"] = "|cffa335ee|Hitem:32230:0:0:0:0:0:0:0|h[Schattensangamethyst]|h|r"
L["|cffa335ee|Hitem:34057:0:0:0:0:0:0:0:80|h[Abyss Crystal]|h|r"] = "|cffa335ee|Hitem:34057:0:0:0:0:0:0:0:80|h[Tiefenkristall]|h|r"
L["|cffa335ee|Hitem:40752:0:0:0:0:0:0:0:80|h[Emblem of Heroism]|h|r"] = "|cffa335ee|Hitem:40752:0:0:0:0:0:0:0:80|h[Emblem des Heldentums]|h|r"
L["|cffa335ee|Hitem:40753:0:0:0:0:0:0:0:80|h[Emblem of Valor]|h|r"] = "|cffa335ee|Hitem:40753:0:0:0:0:0:0:0:80|h[Emblem der Ehre]|h|r"
L["|cffa335ee|Hitem:45624:0:0:0:0:0:0:0:80|h[Emblem of Conquest]|h|r"] = "|cffa335ee|Hitem:45624:0:0:0:0:0:0:0:80|h[Emblem der Eroberung]|h|r"
L["|cffa335ee|Hitem:47241:0:0:0:0:0:0:0:80|h[Emblem of Triumph]|h|r"] = "|cffa335ee|Hitem:47241:0:0:0:0:0:0:0:80|h[Emblem des Triumphs]|h|r"
L["|cffff8000|Hitem:30311:0:0:0:0:0:0:0|h[Warp Slicer]|h|"] = "|cffff8000|Hitem:30311:0:0:0:0:0:0:0|h[Warpschnitter]|h|"
L["|cffff8000|Hitem:30312:0:0:0:0:0:0:0|h[Infinity Blade]|h|r"] = "|cffff8000|Hitem:30312:0:0:0:0:0:0:0|h[Klinge der Unendlichkeit]|h|r"
L["|cffff8000|Hitem:30313:0:0:0:0:0:0:0|h[Staff of Disintegration]|h|r"] = "|cffff8000|Hitem:30313:0:0:0:0:0:0:0|h[Stab der Auflösung]|h|r"
L["|cffff8000|Hitem:30314:0:0:0:0:0:0:0|h[Phaseshift Bulwark]|h|r"] = "|cffff8000|Hitem:30314:0:0:0:0:0:0:0|h[Phasenverschobenes Bollwerk]|h|r"
L["|cffff8000|Hitem:30316:0:0:0:0:0:0:0|h[Devastation]|h|r"] = "|cffff8000|Hitem:30316:0:0:0:0:0:0:0|h[Macht der Verwüstung]|h|r"
L["|cffff8000|Hitem:30317:0:0:0:0:0:0:0|h[Cosmic Infuser]|h|r"] = "|cffff8000|Hitem:30317:0:0:0:0:0:0:0|h[Kosmische Macht]|h|r"
L["|cffff8000|Hitem:30318:0:0:0:0:0:0:0|h[Netherstrand Longbow]|h|r"] = "|cffff8000|Hitem:30318:0:0:0:0:0:0:0|h[Netherbespannter Langbogen]|h|r"
L["|cffff8000|Hitem:30319:0:0:0:0:0:0:0|h[Nether Spike]|h|r"] = "|cffff8000|Hitem:30319:0:0:0:0:0:0:0|h[Netherstachel]|h|r"
L["|cffff8000|Hitem:30320:0:0:0:0:0:0:0|h[Bundle of Nether Spikes]|h|r"] = "|cffff8000|Hitem:30320:0:0:0:0:0:0:0|h[Bündel mit Netherstacheln]|h|r"
L["Changed itemcost from %s to %s DKP for %s."] = "Kosten von %s auf %s DKP für folgenden Gegenstand geändert: %s"
L["Chess Event"] = "Schachevent"
L["Clear currently tracked raids."] = "Aufgezeichnete Raids löschen."
L["Cleared current raid database."] = "Raid Datenbank gelöscht."
L["Cleared the MorgDKP2 raid database."] = "Die MordDKP2 Raid Datenbank wurde gelöscht."
L["Clear raid DB"] = "Raid DB löschen"
L["Clear the raid database?"] = "Die Raid Datenbank löschen?"
L["Close"] = "Schließen"
L["Common"] = "Gewöhnlich"
L["COMPLETED"] = "FERTIG"
L["Core Modules"] = "Zentrale Module"
L["Core of all MorgDKP2 features."] = "Standard MorgDKP2 Features."
L["Core Options"] = "Allgemeine Einstellungen"
L["Cry for mercy! Your meaningless lives will soon be forfeit!"] = "Bettelt um Gnade! Eure bedeutungslosen Leben werden bald vernichtet sein!"
L["Currently loaded DKP pools..."] = "Momentan geladene DKP Pools..."
L["Custom Event"] = "Sonderereignis"
L["Custom MorgBid2"] = "MorgBid2 anpassen"
L["Deleting %s from MorgDKP2 database."] = "Lösche %s aus der MorgDKP2 Datenbank."
L[ [=[Determine MorgBid user base. 
Also useful to check DKP for alts.]=] ] = [=[MorgBid Nutzerbasis wählen. 
Ebenfalls nützlich zur DKP Überprüfung von Alts.]=]
L["Developer mode"] = "Entwicklermodus"
L["Disenchanter"] = "Entzauberer"
L["Display Options"] = "Anzeigeoptionen"
L["DKP Modules"] = "DKP Module"
L["DKP Standings for %s:"] = "DKP Werte für %s:"
L["DKP System"] = "DKP System"
L["Don't say I didn't warn ya, scoundrels! Onward, brothers and sisters!"] = "Don't say I didn't warn ya, scoundrels! Onward, brothers and sisters!" -- Requires localization
L["Dust Covered Chest"] = "Staubbedeckte Truhe"
L["Earned DKP for Invites"] = "Erhaltene DKP für Invite"
L["Either no classes are selected or no members need this item."] = "Entweder wurden keine Klassen ausgewählt oder niemand benötigt diesen Gegenstand."
L["Enable ML/DE mode"] = "ML/DE Modus aktiv"
L["Enable more than one DKP pool for rolling on items.  When starting auction you have to choose the alternate pool (Defaults to primary pool)"] = "Mehr als einen DKP Pool zum Bieten einschalten.  Wenn eine Auktion gestartet wird, muss der zu verwendende Pool angegeben werden (Default: Der Hauptpool)"
L["Enables changing the text of button hints in MorgBid2."] = "Den Tooltip der MorgBid2 Knöpfe anpassen."
L["Enables the main MorgDKP interface for raid tracking."] = "Schaltet das MorgDKP Hauptinterface zur Raidverfolgung ein."
L["Enable tooltip hints"] = "Tooltips einschalten"
L["End Raid"] = "Raid beenden"
L["Epic"] = "Episch"
L["Export Raid"] = "Raid exportieren"
L["Fixed DKP"] = "Feste DKP"
L["Font"] = "Schriftart"
L["Font color"] = "Zeichenfarbe"
L["Font size"] = "Schriftgröße"
L["Font used in tooltips and frames."] = "Schriftart, der in Tooltips und Fenstern benutzt wird."
L["Four Horsemen Chest"] = "Truhe der Vier Reiter"
L["Frame scale"] = "Fensterskalierung"
L["Freya's Gift"] = "Freyas Geschenk"
L["General display options for main modules."] = "Allgemeine Anzeigeoptionen für die Hauptmodule."
L["Gift of the Observer"] = "Geschenk des Beobachters"
L["Give %s to %s, are you sure?"] = "%s an %s geben. Sicher?"
L["His hold on me dissipates. I can see clearly once more. Thank you, heroes."] = "Seine Kontrolle über mich schwindet. Ich kann endlich wieder klar sehen. Ich danke euch, Helden."
L["I AM RENEWED! Ysera grant me the favor to lay these foul creatures to rest!"] = "I AM RENEWED! Ysera grant me the favor to lay these foul creatures to rest!" -- Requires localization
L["If ML/DE Mode is on then no items will be recorded for the master looter or disenchanter defined by MorgDKP2."] = "Wenn der ML/DE Modus aktiv ist, werden keine Gegenstände aufgezeichnet, die an den in MorgDKP2 eingestellten Lootmeister oder Entzauberer gehen."
L["Ignore 6-8"] = "Keine Gruppe 6-8"
L["Ignore items worn by members.  This means queries will always be sent even if they have the item."] = "Ignore items worn by members.  This means queries will always be sent even if they have the item." -- Requires localization
L["Ignore members in groups 6-8 when querying for items."] = "Leute der Gruppen 6-8 ignorieren, wenn Gegenstände vergeben werden."
L["Ignore worn"] = "Ignore worn" -- Requires localization
L["I... I am released from his grasp... at last."] = "Ich... Ich wurde aus seinem Griff befreit... endlich."
L["Impossible! Stay your attack, mortals... I submit! I submit!"] = "Haltet ein, Sterbliche"
L["INRAID"] = "IM RAID"
L["Isn't it beautiful? I call it the magnificent aerial command unit!"] = "Isn't it beautiful? I call it the magnificent aerial command unit!" -- Requires localization
L["It would appear that I've made a slight miscalculation. I allowed my mind to be corrupted by the fiend in the prison, overriding my primary directive. All systems seem to be functional now. Clear."] = "It would appear that I've made a slight miscalculation. I allowed my mind to be corrupted by the fiend in the prison, overriding my primary directive. All systems seem to be functional now. Clear." -- Requires localization
L["Julianne"] = "Julianne"
L["Kil'rek"] = "Kil'rek"
L["LDB Plugin"] = "LDB Plugin"
L["Legendary"] = "Legendär"
L["Link items on the boss/mob that are above the loot threshold to guild chat."] = "Schreibt die Gegenstände, die oberhalb der Lootschwelle sind, in den Gildenchat."
L["Link items on the boss/mob that are above the loot threshold to raid chat."] = "Schreibt die Gegenstände, die oberhalb der Lootschwelle sind, in den Raidchat."
L["Link to Guild"] = "Gildenchat Posts"
L["Link to Raid"] = "Raidchat Posts"
L["List DKP"] = "DKP anzeigen"
L["Main: "] = "Firts: "
L["Main character %s does not exist.  No changes made."] = "Hauptcharakter %s existiert nicht.  Keine Änderungen vorgenommen."
L["Main DKP Pool"] = "Haupt DKP Pool"
L["Master Looter"] = "Lootmeister"
L["Member assigned to disenchant items."] = "Zugewiesener Entzauberer"
L["ML/DE mode"] = "ML/DE Modus"
L["Mode where a boss attempt is recorded when you die via a confirmation dialogue."] = "Modus, in dem ein Bossversuch aufgezeichnet wird, wenn man beim Sterben eine Bestätigungsmeldung auf dem Bildschirm erhält."
L["MorgBid2 Options"] = "MorgBid2 Optionen"
L["MorgBid2 updating"] = "MorgBid2 Update"
L["MorgBid2 Version Query"] = "MorgBid2 Versionsabfrage"
L["Morgbid check"] = "Morgbid Check"
L["MorgDKP2"] = "MorgDKP2"
L["MultiPool"] = "MultiPool"
L["NEED"] = "BEDARF"
L["NEED text"] = "Text für BEDARF"
L["NEW"] = "NEU"
L["No current raid exists."] = "Im Moment findet kein Raid statt."
L["No longer will I be a slave to Malygos! Challenge me and you will be destroyed!"] = "Nicht länger werde ich Malygos' Sklave sein! Fordert mich heraus und Ihr werdet vernichtet!"
L["NONE"] = "OHNE"
L["Not Set"] = "Nicht gesetzt"
L["Now querying for %s  ID = %s  DKP = %s"] = "Anfrage für %s  ID = %s  DKP = %s"
L["OFFLINE"] = "OFFLINE"
L["Offspec: "] = "Offspec: "
L["OFFSPEC"] = "OFFSPEC"
L["OFFSPEC text"] = "Text für OFFSPEC"
L["ONLINE"] = "ONLINE"
L[ [=[On STANDBY.
|c000070ddClick:|r to enable.]=] ] = [=[Im STANDBY Modus.
|c000070ddKlick:|r Aktivieren.]=]
L["Onyxian Whelp"] = "Onyxiawelpe"
L["PASS"] = "PASSE"
L["PASS text"] = "Text für PASSE"
L["PENDING"] = "WARTE"
L["PENDING..."] = "WARTE..."
L["Perhaps it is your imperfection that which grants you free will. That allows you to persevere against cosmically calculated odds. You prevailed where the Titans' own perfect creations have failed."] = "Perhaps it is your imperfection that which grants you free will. That allows you to persevere against cosmically calculated odds. You prevailed where the Titans' own perfect creations have failed." -- Requires localization
L["Please install MorgBid2 to bid on items.  http://www.wowace.com/projects/morg-bid2/ Thank-you:)"] = "Bitte MorgBid2 installieren, um auf Gegenstände bieten zu können.  http://www.wowace.com/projects/morg-bid2/  - Vielen Dank :)"
L["Please whisper: dkplist [poolname] [class] [class] .... [all]"] = "Bitte anflüstern: dkplist [Poolname] [Klasse1] [Klasse2] ... [all(Alle)]"
L["Plugin frame will not disappear until UI reloaded."] = "Plugin Fenster wird bis zum /uireload nicht verschwinden."
L["Poor"] = "Schlecht"
L["Preliminary testing phase complete. Now comes the true test!"] = "Preliminary testing phase complete. Now comes the true test!" -- Requires localization
L["Quality Threshold"] = "Lootschwelle"
L["Raid Tracker"] = "Schlachtzugs Verfolge"
L["Raid Tracker for viewing and editing current raids."] = "Raid Tracker zur Aufzeichnung und Bearbeitung aktueller Raids."
L["Rare"] = "Rar"
L["Record boss attempt for %s?"] = "Bossversuche für %s aufzeichnen?"
L["Romulo"] = "Romulo"
L["Romulo & Julianne"] = "Romulo & Julianne"
L["Set DKP Pool to be primary DKP pool. Only pool if not using multiPool"] = "Den DKP Pool einstellen, der als Haupt DKP Pool verwendet werden soll. Wird kein MultiPool verwendet, ist dies der einzige Pool."
L["Show minimap icon"] = "Minimap Icon anzeigen"
L["%s joined the raid at %s."] = "%s ist dem Raid um %s beigetreten."
L["%s left the raid at %s."] = "%s hat den Raid um %s verlassen."
L["Son of Flame"] = "Sohn der Flamme"
L["Sorry your response format is incorrect or no item with that ID is up for bidding.  Format = mbid [ID/link] [%s/%s/%s/%s] [bid value]"] = "Das Eingabeformat ist leider falsch oder auf die angegbene ID wird nicht geboten.  Format = mbid [ID/Link] [%s/%s/%s/%s] [DKP Wert]"
L["%s received %s for %s DKP"] = "%s hat %s erhalten. Kosten: %s DKP"
L["Start Raid"] = "Raid beginnen"
L["Stay your arms! I yield!"] = "Nehmt die Waffen runter! Ich ergebe mich!"
L["TAKE"] = "GIER"
L["TAKE text"] = "Text für GIER"
L["Text of MorgBid2 NEED button"] = "Text des MorgBid2 BEDARF Knopfs"
L["Text of MorgBid2 OFFSPEC button"] = "Text des MorgBid2 OFFSPEC Knopfs"
L["Text of MorgBid2 PASS button"] = "Text des MorgBid2 PASSE Knopfs"
L["Text of MorgBid2 TAKE button"] = "Text des MorgBid2 GIER Knopfs"
L["The Alliance falter. Onward to the Lich King!"] = "The Alliance falter. Onward to the Lich King!" -- Requires localization
L["The first kill goes to me! Anyone care to wager?"] = "Der erste Todesstoß gehört mir! Wer wagt es mich herauszufordern?"
L["The halls of Karazhan shake, as the curse binding the doors of the Gamesman's Hall is lifted."] = "The halls of Karazhan shake, as the curse binding the doors of the Gamesman's Hall is lifted." -- Requires localization
L["The Legion's final conquest has begun! Once again the subjugation of this world is within our grasp. Let none survive!"] = "The Legion's final conquest has begun! Once again the subjugation of this world is within our grasp. Let none survive!" -- Requires localization
L["These are the hallmarks..."] = "Das sind die Anzeichen..."
L["The time is now! Leave none standing! "] = "Die Zeit ist gekommen! Lasst keinen am Leben!"
L["This item is not currently up for bid."] = "Um diesen Gegenstand wird im Moment nicht geboten."
L["Toggle LDB Plugin"] = "LDB Plugin aktiv"
L["Toggle MorgDKP2"] = "MorgDKP2 aktiv"
L["Transeferred %s DKP to %s from %s"] = "%s DKP von %s auf %s übertragen."
L["Transferred %s to %s for %s DKP."] = "%s auf %s für %s DKP übertragen."
L["Uncommon"] = "Gut"
L["Unique"] = "Einzigartig anlegbar"
L["Unique-equipped"] = "Einzigartig Getragen"
L["UNKNOWN"] = "UNBEKANNT"
L["Use earned DKP in the invite tablet (shift-click)."] = "Erhaltene DKP im Ladebildschirm verwenden (Shift-Klick)."
L["Use OFFSPEC"] = "OFFSPEC verwenden"
L["WAIT"] = "WARTE"
L["What devil art thou, that dost torment me thus?"] = "Welch' Teufel bist du, dass du mich so folterst?"
L["Whispers all members (even if they have MorgBid2) so they can reply and bid using whispers."] = "Flüstert an alle Teilnehmer (auch Spieler mit MorgBid2) damit sie Antworten und Gebote per flüstern abgeben können."
L["Whisper system"] = "Flüster System"
L["World Boss"] = "Weltboss"
L["xINRAIDx"] = "xIM RAIDx"
L["xWAITx"] = "xWARTEx"
L["You are defenders of a doomed world! Flee here, and perhaps you will prolong your pathetic lives!"] = "Ihr verteidigt eine verlorene Welt! Flieht! Vielleicht verlängert dies Euer erbärmliches Leben!"
L["You can not use this function out of a raid group."] = "Diese Funktion ist ausserhalb eines Raids nicht verfügbar."
L["You may want to take cover."] = "Eventuell wollt ihr euch verstecken."
L["You must start a raid before you can start a query."] = "Ein Raid muss angefangen haben bevor man eine Anfrage stellen kann."
L["Your response has been accepted: %s"] = "Die Antwort wurde angenommen: %s"
L["You will not defeat the Assembly of Iron so easily, invaders!"] = "You will not defeat the Assembly of Iron so easily, invaders!" -- Requires localization
L.BidWar = {
	["Beginning auction for %s:  ID = %s"] = "Beginne Auktion für %s:  ID = %s",
	["Bidding is now closed."] = "Die Bietrunde ist beendet.",
	["Bid Format = mbid [ID/link] [%s/%s/%s] [bid value]"] = "Whisper zum Bieten: mbid [ID/Link] [%s/%s/%s] [Wert], z.B. mbid 12059 bedarf 12",
	Bidstep = "Bietschritt",
	BidWar = "Biet-DKP",
	["BidWar mode changes the MorgBid query to allow players to bid on items.  Also the MorgDKP tablet uses bids after this NOT member DKP."] = "Biet-DKP ändert MorgBid2 so ab, dass Mitspieler auf Gegenstände bieten können.  MorgDKP zeigt bei Biet-DKP die Gebote an, nicht die DKP der Mitspieler.",
	["BidWar Options"] = "Gebotsschlacht Optionen",
	["Changes the DKP step for BidWar mode.  Passes this value to MorgBid2 clients."] = "Die DKP Schritte ändern, in denen geboten werden kann.  Dieser Wert wird an MorgBid2 übergeben.",
	["Enable BidWar mode where the winner is charged the 2nd highest bid value for the item."] = "Biet-DKP, bei der der Gewinner das zweithöchste Gebot zahlt.",
	["Enable BidWar mode with only one round of bidding and no reporting to raid chat."] = "Biet-DKP, in der nur eine einzige Bietrunde stattfindet und keine Punkte an den Raid gesendet werden.",
	["Just enough"] = "Genug ist Genug",
	["Maximum amount of DKP that members can exceed their current DKP."] = "Der Maximalwert, den ein Teilnehmer über seine DKP hinaus bieten darf.",
	["New high bidder for %s: %s = %s"] = "Neues Höchstgebot für %s: %s = %s",
	Overbid = "Überbieten",
	["Silent auction"] = "Geheime Auktion",
	["Sorry this is a silent auction and you have already placed your bid."] = "Dies ist eine geheime Auktion und du hast dein Gebot leider schon abgegeben.",
	["You have exceeded the overbid amount of %s.  Your bid has been reset to the maximum."] = "Du hast dich dein Limit von %s überboten.  Dein Gebot wurde auf das Maximum gekürzt.",
}
L.DKPovertime = {
	["Added %s DKP to %s attendees."] = "%s DKP %s Anwesenden gutgeschrieben.",
	["Award amount"] = "DKP Menge",
	["Award time"] = "Zeitraum",
	["DKP/time"] = "DKP/Zeit",
	["DKP/time event name"] = "Eventname für DKP über Zeit",
	["DKP/time Options"] = "DKP/Zeit Optionen",
	["DKP/time system which allows you to award DKP at custom intervals."] = "DKP über Zeit System, dass den Teilnehmern feste DKP pro Zeitintervall gutschreibt.",
	[ [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=] ] = [=[Format des Eventnamens:  
<zone> text  
Beispiel:  <zone> DKP]=],
	["Time in minutes between DKP awards."] = "Zeit in Minuen zwischen den DKP Zuteilungen",
}
L.Eventnaming = {
	["Allows you to change the default format for event names."] = "Erlaubt es, eigene Namen für die Events zu erstellen.",
	["Boss format"] = "Boss Format",
	Default = "Zurücksetzen",
	Enable = "Aktiv",
	["Event naming"] = "Ereignisnamen",
	[ [=[Format of boss event names:  
<zone> - <boss>
Example:  <boss> <diff>]=] ] = [=[Format of boss event names:  
<zone> - <boss>
Example:  <boss> <diff>]=], -- Requires localization
	[ [=[Format of run event name:  
<zone> text  
Example:  <zone> <diff> Run]=] ] = [=[Format des Raidevents:  
<zone> text  
Beispiel:  <zone> <diff> Run]=],
	[ [=[Format of start event name:  
<zone> text  
Example:  <zone> <diff> Start]=] ] = [=[Format des Startevents:  
<zone> text  
Beispiel:  <zone> <diff> Start]=],
	["Reset default values."] = "Auf Standardwerte zurücksetzen.",
	["Run format"] = "Raid Format",
	["Start format"] = "Start Format",
	["Toggle event naming"] = "Eigene Ereignisnamen aktivieren",
}
L.FixedDKP = {
	["DKP TAKE/OFFSPEC settings"] = "DKP Erst-/Zweitbedarf Einstellungen",
	Enable = "Aktiv",
	["Enable OFFSPEC"] = "Aktiviere Zweitbedarf",
	["Enables mode where members are charged a standard price for OFFSPEC items."] = "Aktiviert den Modus, das Teilnehmern ein Standardpreis auch für Zweitausrüstung abgezogen wird.",
	["Enables mode where members are charged a standard price for TAKE items."] = "Aktiviert den Modus, das Teilnehmern ein Standardpreis für Erstausrüstung abgezogen wird.",
	["Enable TAKE"] = "Aktiviere Erstbedarf",
	["Fixed DKP"] = "Feste DKP",
	["OFFSPEC Percent"] = [=[OFFSPEC Prozent

Feste DKP]=],
	["OFFSPEC value"] = "Zweitausrüstungskosten",
	["Standard DKP system."] = "Standard DKP System.",
	["TAKE Percent"] = [=[NEHMEN Prozent

Feste DKP]=],
	["TAKE value"] = "Erstausrüstungskosten",
	["Use percent of item value for OFFSPEC mode."] = [=[Prozent des Itemwertes für den OFFSPEC Modus verwenden.

Feste DKP]=],
	["Use percent of item value for TAKE mode."] = [=[Prozent des Itemwertes für den NEHMEN Modus verwenden

Feste DKP]=],
}
L.Lootframe = {
	Alt = "Alt",
	["Always use"] = "Immer nutzen",
	["Always use the MorgDKP2 loot window even when the mod is in standby mode."] = "Das MorgDKP2 Lootfenster auch dann benutzen, wenn MorgDKP2 im Standby Modus ist.",
	["|c000070ddClick:|r allocate randomly"] = "|c000070ddKlick:|r Zufällig zuweisen",
	["|c000070ddClick:|r Announce winner."] = "|c000070ddKlick:|r Gewinner festlegen.",
	["|c000070ddClick:|r give item to disenchanter"] = "|c000070ddKlick:|r An Entzauberer geben",
	["|c000070ddClick:|r give this item to disenchanter."] = "|c000070ddKlick:|r Gegenstand entzaubern.",
	[ [=[|c000070ddClick:|r loot item
|c000070ddR-Click:|r open itemdata or roll frame
|c000070ddAlt-R-Click:|r start all queries]=] ] = [=[|c000070ddKlick:|r Gegenstand Looten
|c000070ddR-Klick:|r Daten-/Würfelfenster öffnen
|c000070ddAlt-R-Klick:|r Alle Anfragen starten]=],
	["|c000070ddClick:|r select pool to use for item."] = "|c000070ddKlick:|r DKP Pool auswählen.",
	["|c000070ddClick:|r self loot"] = "|c000070ddKlick:|r Selbst Looten",
	[ [=[|c000070ddClick:|r start item query.
|c000070ddAlt-Click:|r start all queries
|c000070ddShift-Click:|r random query for this item
|c000070ddCtrl-Click:|r ignore this item]=] ] = [=[|c000070ddKlick:|r Gegenstand abfragen.
|c000070ddAlt-Klick:|r Alle Abfragen starten
|c000070ddShift-Klick:|r Zufallsabfrage für diesen Gegenstand
|c000070ddCtrl-Klick:|r Diesen Gegenstand ignorieren]=],
	["|c000070ddClick:|r stop this item query."] = "|c000070ddKlick:|r Abfrage abbrechen.",
	[ [=[|c000070ddMousewheel up/Click|r - Increase value.
|c000070ddMousewheel down/R-Click|r - decrease value.
|c000070ddSHIFT|r - change value by +/-1
|c000070ddALT|r - change value by +/-20
|c000070ddCTRL|r - change value by +/-100]=] ] = [=[|c000070ddMousewheel up/Click|r - erhöht Wert.
|c000070ddMousewheel down/R-Click|r - veringert Wert.
|c000070ddSHIFT|r - ändert Wert um +/-1
|c000070ddALT|r - ändert Wert um +/-20
|c000070ddCTRL|r - ändert Wert um +/-100
]=],
	Class = "Klasse",
	["DKP: %s"] = "DKP: %s",
	["Give %s to %s, are you sure?"] = "%s an %s geben. Sicher?",
	Lootframe = "Lootfenster",
	["Lootframe scale"] = "Skalierung Lootfenster",
	["Open lootframe at cursor postition"] = "Das Lootfenster an der aktuellen Mausposition einblenden",
	["Replace Blizzard"] = "Blizzards ersetzen",
	["%s awarded to %s"] = "%s geht an %s",
	["%s awarded to %s for %s DKP"] = "%s geht an %s für %s DKP",
	["Select primary class"] = "Primärklasse wählen",
	["Select secondary class"] = "Sekundärklasse wählen",
	["Snap to cursor"] = "Einblenden bei Maus",
	["%s will be disenchanted in 5 seconds."] = "%s wird in 5 Sekunden entzaubert.",
	["When MorgDKP2 is active it's loot frame will replace default."] = "Wenn MorgDKP2 aktiv ist, wird dessen Lootfenster das Standardfenster ersetzen.",
}
L.Percent = {
	["Items will cost a percentage of the members total DKP."] = "Gegenstände kosten einen bestimmten Prozentsatz der gesamten DKP des Spielers.",
	["Percent cost"] = "Kosten (Prozent)",
	["Percent DKP"] = "Prozent DKP",
	["Percent DKP Options"] = "Prozent DKP Optionen",
	["Percent take"] = "GIER aktivieren",
	["When using the percent DKP system this option enables TAKE looting.  This means if the winning member rolled TAKE he will not be charged x% DKP he will instead be charged the base price of the item (Set using original itempoints."] = "Die Option GIER wird freigeschaltet.  Falls der Gewinner auf GIER geklickt hat, wird statt dessen der Grundpreis des Gegenstandes von seinen DKP abgezogen.",
}
L.PointsDB = {
	["Added alias: %s of %s with %s DKP."] = "Twink zugefügt: %s von %s mit %s DKP.",
	["Addeded %s to item database."] = "%s zur Datenbank hinzugefügt.",
	["Added %s players from %s"] = "%s Spieler aus %s hinzugefügt.",
	["Add ignored item"] = [=[Ignorierten Gegenstand zufügen

PunkteDB]=],
	["Add item"] = "Gegenstand zufügen",
	["Add new item to ignore.  Drag the item to this input box."] = [=[Neuen Gegenstand zur Ignoreliste hinzufügen. Den Gegenstand in die Box ziehen.

PunkteDB]=],
	["Add new item to track.  Drag the item to this input box."] = "Neuen Gegenstand hinzufügen.  Den Gegenstand einfach in die Box ziehen.",
	["Clear player DB"] = "Spieler DB löschen",
	["Clear raid DB"] = "Raid DB löschen",
	["Clears all items in the database below the selected item level."] = "Alle Gegenstände aus der Datenbank löschen, die unter der ausgewählten Gegenstandsstufe liegen.",
	["Clears all members in the database inactive longer than the selected number of weeks."] = "Löscht alle Mitglieder in der Datenbank, welche länger als die eingestellte Anzahl an Wochen inaktiv sind.",
	["Clears all players currently in the database. Does not affect items."] = "Alle Spieler löschen, die Momentan in der Datenbank sind. Wirkt sich nicht auf Gegenstände aus.",
	["Clears the current tracked raids."] = "Alle aufgezeichneten Raids löschen.",
	["Cull item DB"] = "Gegenstandsliste säubern",
	["Cull item level"] = "Gegenstandsstufe",
	["Cull member DB"] = [=[Mitglieder DB kürzen

PunkteDB]=],
	["Cull member level (weeks)"] = [=[Mitglieder DB kürzen (Wochen)

PunkteDB]=],
	["Current rank weight"] = [=[Aktuelles Gewicht des Ranges

PunkteDB]=],
	["Database Functions"] = "Datenbank Funktionen",
	["Database transfer complete. %s items were transferred and %s members updated."] = "Datenbanktransfer vollständig. %s Gegenstände wurden übertragen und %s Mitglieder upgedatet.",
	["Higher number for higher display priority. (7 will appear above 3 on the tooltip)"] = [=[Größere Zahl für höhere Priorität bei der Anzeige (7 erscheint oberhalb von 3 im Tooltip)

PunkteDB]=],
	["Ignored items"] = "Ignorierte Gegenstände",
	["Import database from MorgDKP?"] = "Datenbank aus MorgDKP1 importieren?",
	["Import default item database?"] = "Standard Datenbank für Gegenstände importieren?",
	["Imported MorgDKP DB with %s players and %s items."] = "MorgDKP1 Datenbank mit %s Spielern und %s Gegenständen importiert.",
	["List of currently ignored items.  Click to remove item from ignore list."] = "Liste der Gegenstände, die im Moment ignoriert werden.  Klicken, um einen Gegenstand aus der Liste zu entfernen.",
	["List of member ranks in the current pool."] = [=[Liste der Mitgliedsränge im momentanen Pool

PunkteDB]=],
	["Player database cleared!"] = "Spielerdatenbank gelöscht!",
	["Player DKP reset to zero!"] = "DKP aller Spieler zurückgesetzt!",
	["Please delete the ItemData.lua file from the MorgDKP directory now."] = "Bitte jetzt die ItemData.lua Datei aus dem MorgDKP Verzeichnis löschen.",
	["Rank weights"] = [=[Gewichtung der Ränge

PunkteDB]=],
	["Removed %s items from the database."] = [=[%s Teile aus der Datenbank entfernt.

PunkteDB]=],
	["Removed %s members from the database."] = [=[%s Mitglieder aus der Datenbank entfernt.

PunkteDB]=],
	["Resets all members DKP to zero."] = "Die DKP aller Teilnehmer löschen.",
	["Updating DKP Points.."] = "Update der DKP Punkte...",
	["Zero player DB"] = "DKP löschen",
}
L.RaidTracker = {
	Add = "Zufügen",
	["Alias Database"] = "Twink Datenbank",
	Aliases = "Twinks",
	Alt = "Alt",
	Attendees = "Teilnehmer",
	Class = "Klasse",
	Close = "Schliessen",
	["Create new event"] = "Neues Ereignis",
	["Current raid"] = "Alle im Raid",
	Delete = "Löschen",
	["Delete Raid"] = "Raid löschen",
	["DKP Changes"] = "DKP ändern",
	Enable = "Aktiv",
	["Enter alias name"] = "Twink Name",
	["Enter DKP change amount"] = "Wert für DKP Änderung",
	["Enter DKP change members"] = "Betroffene der DKP Änderung",
	["Enter event attendees"] = "Teilnehmer",
	["Enter event name"] = "Ereignisname",
	["Enter event note"] = "Ereignisnotiz",
	["Enter event value"] = "Ereigniswert",
	["Enter item event"] = "Gegenstand",
	["Enter item value"] = "Wert",
	["Enter item winner"] = "Gewinner",
	["Enter main name"] = "Hauptname",
	Eventname = "Name",
	Eventnote = "Kommentag",
	["Export Raid"] = "Raid exportieren",
	Group = "Gruppe",
	Ignore = "Ignorieren",
	["Item Database"] = "Gegenstandsdatenbank",
	["Item DB"] = "Gegenstände",
	["Raid Editing"] = "Raid ändern",
	Raids = "Raids",
	["Raid Tracker"] = "Raid Tracker",
	["Raid Tracker for viewing and editing current raids."] = "Raid Tracker, mit dem man Raids anschauen und editieren kann.",
	["Select primary class"] = "Primärklasse wählen",
	["Select secondary class"] = "Sekundärklasse wählen",
	["Update attends"] = "Teilnehmerupdate",
	Value = "Wert",
	["You can not remove the run event."] = "Dieses Raid Event kann nicht gelöscht werden.",
}
L.Random = {
	["Enable random rolling for items."] = "Zufälliges Würfeln für Gegenstände einschalten.",
	["Random rolls"] = "Zufallswurf",
	["%s received %s."] = "%s hat %s erhalten.",
}
L.Relational = {
	["Enable Relational DKP for calculating the earned/spent dkp ratio."] = "Verhältnis DKP System aktivieren, um einen Faktor Erhalten/Ausgegeben zu errechnen.",
	["Minimum amount of DKP a member can have for calculating the DKP ratio to avoid a new member having a high ratio. ie  200 earned DKP/ (this value)"] = [=[Minimale Anzahl an DKP die ein Mitglied haben kann, damit eine DKP Ratio ermittelt wird. So werden neuen Mitgliedern keine überhöhten Ratios gegeben. Bsp: 200 DKP/(diesen Wert)

Relational]=],
	["Minimum DKP base"] = [=[Minimale DKP Basis

Relational]=],
	["Relational DKP"] = "Verhältnis DKP",
	["Relational DKP Options"] = [=[Relationale DKP Optionen

Relational]=],
}
L.SKSotC = {
	["Amount of DKP to remove from members who miss a raid."] = "Amount of DKP to remove from members who miss a raid.", -- Requires localization
	["Demotion event"] = "Demotion event", -- Requires localization
	["Enable Suicide Kings SotC variant DKP."] = "Enable Suicide Kings SotC variant DKP.", -- Requires localization
	[ [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=] ] = [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=], -- Requires localization
	["Missed raid DKP"] = "Missed raid DKP", -- Requires localization
	["SKSotC DKP"] = "SKSotC DKP", -- Requires localization
	["SKSotC Options"] = "SKSotC Options", -- Requires localization
}
L.SKall = {
	["Enable raid award"] = "Aktiviere Raidbelohnung",
	["Enables DKP removed from item winner to be awarded to raid members.  You must check use zerosum on the import webscript for website DKP to be correct."] = "Aktiviert das dem Gegenstandsgewinner die DKP abgezogen und den Raidteilnehmern gutschrieben werden. Es muss ZeroSum im Import-Webskript aktiviert sein, damit das auf den Webseiten DKP richtig funktioniert.",
	["Enable Suicide Kings spend all DKP."] = "Aktiviert 'Nur Selbstmörder geben alle DKP'.",
	["% Member DKP"] = "% Mitglieder DKP",
	["Percent of member DKP to remove."] = "Prozent des Mitglieder-DKP werden abgezogen.",
	["SKall DKP"] = "SKall DKP",
	["SKall Options"] = "SKall Optionen",
}
L.Syncing = {
	["Accept DKP changes from other raid leaders."] = "Aktzeptiere DKP-Veränderungen anderen Raidleiter.",
	["Added %s to listeners."] = "%s als Zuhörer hinzugefügt.",
	Automatic = "Automatisch",
	["Automatically set broadcast/receive depending if you are the master looter."] = "Wenn du Plündermeister bist automatisch Beute verkünden.",
	Broadcast = "Nachricht an alle Benutzer",
	["Broadcast DKP changes to other raid leaders."] = "Teile DKP-Änderung mit den anderen Schlachtzugsleitern.",
	Enable = "Aktivieren",
	["Immediate Sync Options"] = "Sofortige Sync.-Optionen",
	["Imported options...restarting."] = "Optionen importiert... Neustart.",
	["Imported %s items"] = "%s Gegenstände importiert",
	["Import %s data from %s?"] = "%s Daten von %s importieren?",
	["Initial Sync"] = "Erst Sync.",
	["Items Sync"] = "Gegenstands Sync.",
	["Members Sync"] = "Mitglieder synchronisieren",
	["Options Sync"] = "Optionen synchronisieren",
	["Overwrite raid"] = "Überschreibe Raid",
	["Overwrite the current raid if you receive an initial sync and are currently in a raid."] = [=[Überschreibe den aktuellen Raid wenn du einen initialen Sync bekommst und in einem Raid bist.

Synchronisiere]=],
	Password = "Passwort",
	Receive = [=[erhalten
]=],
	["Removed %s from listeners."] = "%s als Zuhörer entfernen.",
	["Resends initial sync.  Only needed in cases where you have problems as this is done automatically."] = [=[Initialen Sync neu senden. Wird nur bei Probleme verwendet, weil dies normalerweise automatisch geschieht.

Synchronisiere]=],
	["Send DB Sync"] = "Sende Data Base Sync.",
	["Sends your current database of item DKP values."] = "Sendet die aktuelle Datenbank mit den Gegenstands-DKP-Preisen.",
	["Sends your current database of member DKP values."] = "Sendet die aktuelle Datenbank mit den Mitglieder-DKP-Werten.",
	["Sends your current database of member DKP values, item values, and MorgDKP2 options to the current raid."] = "Sendet die aktuelle Datenbank mit den Mitglieder-DKP-Werten,Item-Preisen und MorgDKP2-Optionen an den Schlachtzug.",
	["Sends your current MorgDKP2 options.  Note will restart MorgDKP2 so do not send another sync until it restarts or use full sync and it will be handled properly."] = [=[Übermittelt deine momentanen MorgDKP2 Einstellungen. Bemerkung: MorgDKP2 wird danach neu gestartet, also vor dem Neustart keinen weiteren Sync schicken. Alternativ: Einen Vollsync machen, dann wird auch alles richtig verarbeitet.

Synchronisiere]=],
	["%s's MorgDKP2 is out of date!"] = "%s hat eine veraltete Version von MorgDKP2!",
	["%s's password does not match your password!"] = "Das Passwort von %s stimmt nicht mit deinem überein!",
	Syncing = "Synchronisieren",
	["Syncing password"] = "Synchronisiere Passwart",
	["Syncing system for communicating DKP between raid leaders."] = "System-Synchronisation für den DKP-Abgleich zwischen den Raid-Leitern.",
	["Updated %s members"] = "%s Mitglieder aktualisiert",
}
L.TakeBid = {
	Bidstep = "Bietschritt",
	["Changes the DKP step for TakeBid mode.  Passes this value to MorgBid2 clients."] = "Ändert die Schrittweite für Gebote beim Biet-DKP System. Dieser Wert wird an MorgBid2 übergeben.",
	["Maximum amount of DKP that members can exceed their current DKP."] = "Maximalwert an DKP, die über die momentanen DKP geboten werden darf.",
	["Minimum amount of DKP that members can bid for an item."] = [=[Mindestzahl an DKP, die Mitglieder auf einen Gegenstand bieten können.

NimmGebot]=],
	["Minimum bid"] = [=[Minimales Gebot.

NimmGebot]=],
	Overbid = "Überbieten",
	["TakeBid DKP"] = "Gier-Auktions-DKP",
	["TakeBid Options"] = "Gier Auktion Optionen",
	["Variation of Fixed DKP where when you bid take you also enter what you are willing to pay."] = "Eine DKP Art, bei der der Bietende bei Gier bestimmt, was er zahlen will.",
}
L.Tracker = {
	["and add these attendees < %s min?"] = "und füge diese Teilnehmer mit weniger als %s Minuten Anwesenheit hinzu?",
	["Attendance reward"] = "Zeit für Teilnahmebonus",
	["Bank character"] = "Bank Charakter",
	CANCEL = "ABBRUCH",
	["Clear the raid database?"] = "Raid Datenbank löschen?",
	[ [=[Core of all MorgDKP2 raid tracking features. 
Can not be disabled.]=] ] = [=[Kern der MorgDKP2 Aufzeichnung. 
Kann nicht abgeschaltet werden.]=],
	["CTRT format"] = "CTRT format", -- Requires localization
	["DKP Export"] = "DKP Export",
	["DKP listener"] = "DKP Backup",
	["DKP Tracking"] = "DKP Aufzeichnung",
	["DKP which new members to the database receive."] = "Anzahl der DKP, die neue Raidteilnehmer automatisch erhalten.",
	["End Raid"] = "Raid beenden",
	["End %s"] = "Beende %s",
	["Eqdkp+ event format"] = "EqDKP+ Format",
	["Events for DKP changes"] = "DKP Änderung als Ereignis",
	["Export Raids"] = "Raid exportieren",
	["Exports current raid(s) data for import into website."] = "Die Daten aller Raids für einen Import in die Webseite exportieren.",
	["Finalizes the current raid."] = "Eine Raidaufzeichnung abschliessen.",
	["Format of new member DKP event name."] = "Format of new member DKP event name.", -- Requires localization
	["General options"] = "Grundlagen",
	["Guildlaunch format"] = "Guildlaunch format", -- Requires localization
	["Minimum time to add member to raid and award run DKP."] = "Zeit in Minuten, die eine Person am Raid teilgenommen haben muss, um am dort gelistet zu werden und DKP für die Teilnahme zu erhalten.",
	["New member DKP event"] = "New member DKP event", -- Requires localization
	["New member start DKP"] = "Start DKP für neue Teilnehmer",
	NO = "NEIN",
	["No current raid exists."] = "Kein Raid verfügbar.",
	["Opens the raidtracker interface."] = "Öffnet das Fenster des Raidtrackers.",
	["Previous best kill time: %s"] = "Previous best kill time: %s", -- Requires localization
	["Raid Tracker"] = "Raid Tracker",
	["Remember kill times"] = "Remember kill times", -- Requires localization
	["Removed %s raid attendees."] = "%s Raidteilnehmer entfernt.",
	["Remove the ' character from any event names because eqdkp+ is dumb."] = "Das ' Zeichen aus Eventnamen entfernrn - EqDKP+ kommt damit nicht klar.",
	["Sartharion minibosses"] = "Sartharion Minibosse",
	["%s defeated in %s!"] = "%s wurde gelegt in %s!",
	Shortcuts = "Kürzel",
	["Single run event"] = "Nur ein Eintrag",
	["Sorry %s is an invalid database pool.  Please choose a correct one or export your DKP from your website."] = "%s ist leider ein ungültiger DKP Pool.  Bitte einen gültigen Pool auswählen oder die Pools erneut von der Website importieren.",
	["%s recorded at %s with %s attendees."] = "%s aufgezeichnet am %s mit %s Teilnehmern.",
	["Start Event"] = "Mit Start Ereignis",
	["Start Raid"] = "Raid beginnen",
	["Starts a new raid."] = "Einen neuen Raid beginnen.",
	["Store your best kill times for bosses."] = "Store your best kill times for bosses.", -- Requires localization
	["Trigger events for Sartharion minibosses."] = "Zusätzliche Events für die Sartharion Minibosse aktivieren.",
	["Use a bank character in raids."] = "Einen Bank Charakter in Raids verwenden.",
	["Use CTRT export format for raid exports."] = "Use CTRT export format for raid exports.", -- Requires localization
	["Use events for DKP changes instead of database adjustments."] = "DKP Änderungen als Ereignis statt als Änderung der Datenbank eintragen.",
	["Use guildlaunch export format for raid exports."] = "Use guildlaunch export format for raid exports.", -- Requires localization
	["Use one event for entire raid.  Boss kills will not be tracked separately."] = "Schreibt den gesamten Raid in einen einzigen Eintrag. Bosskills werden nicht getrennt erfasst.",
	["Use start event when raid begins."] = "Start Ereignis Aufzeichnen, wenn der Raid beginnt.",
	["When you are in a tracked zone you will track DKP but you will not get the loot popup window or link to the raid.  You will act like a backup raidlog."] = "Der Tracker zeichnet nur auf.  DKPs werden aufgezeichnet, aber es erscheint weder ein Lootfenster noch werden die Lootdaten an den Raid oder die Gilde gesendet.",
	YES = "JA",
	["Yes & Add"] = "JA+Eintragen",
}
L.Waitlist = {
	["Added %s to the waitlist."] = "%s zur Warteliste hinzugefügt.",
	["Added you to the waitlist."] = "Du wurdest zur Warteliste hinzugefügt.",
	["Amount of DKP to reward after members have been on the waitlist for the current reward time."] = "Anzahl der DKP, die Leute in der Warteliste nach der vorgegebenen Wartezeit erhalten.",
	["Amount of DKP to reward at raidstart."] = "Anzahl der DKP, die Leute in der Warteliste beim Raidbeginn erhalten.",
	["Amount of DKP to reward to waitlist members per bosskill."] = "Anzahl der DKP, die Leute in der Warteliste pro Bosskill bekommen.",
	["Amount of DKP to reward to waitlist members when awarding regular members DKP/time. Note: only works if you are awarding DKP/time."] = "Anzahl an DKP über Zeit, die Leuten in der Warteliste zugeteilt wird. Funktioniert nur, wenn man DKP über Zeit vergibt.",
	["Autochannel Spam"] = "Automatisch posten",
	["Award DKP"] = "DKP zuweisen",
	["Award DKP to current waitlist members"] = "DKP an Leute zuweisen, die sich im Moment in der Warteliste befinden.",
	Channels = "Kanäle",
	["Channels to spam when starting invites."] = "Kanäle, in die die Nachricht zum Laden gepostet wird.",
	["Clears the current wailist."] = "Die momentane Warteliste löschen.",
	["Clear Waitlist"] = "Warteliste löschen",
	["Current waitlist: %s"] = "Aktuelle Warteliste: %s",
	Enable = "Aktiv",
	["Event Names"] = "Namen der Events",
	[ [=[Format of waitlist boss events:  
<boss> text  
Example:  <boss> Waitlist DKP]=] ] = [=[Format des Eventnamens: <boss> text  
Beispiel: <boss> Warteliste DKP]=],
	[ [=[Format of waitlist event names:  
<zone> text  
Example:  <zone> Waitlist DKP]=] ] = [=[Format des Eventnamens: <zone> text  
Beispiel: <zone> Warteliste DKP]=],
	["Grace Period"] = "Gnadenfrist",
	["Minimum time before offline waitlist members will be removed."] = "Zeit in Minuten, bevor Leute aus der Warteliste geworfen werden, die Offline sind.",
	["Minimum time to award run DKP to a waitlist member."] = "Zeit, die man in der Warteliste verbracht haben muss, um DKP zu erhalten.",
	["Now accepting tells for the waitlist.  Please whisper %s using this format:  mbid wait[+/-] [main]"] = "Whispers für die Warteliste werden jetzt angenommen!  Bitte folgendes Format benutzen:  mbid warte[+/-] [Main], z.B. mbid warte+ Hugendubel",
	["Please log on to your main for an invite to the raid.  Whisper me when online."] = "Bitte mit dem Mainchar einloggen, um eine Einladung zum Raid zu erhalten.  Nach dem Einloggen mich bitte anflüstern.",
	["Removed %s from wailist."] = "%s aus der Warteliste entfernt.",
	["Removed %s from waitlist due to inactivity"] = "%s wegen Inaktivität aus der Warteliste entfernt.",
	["Removed you from the waitlist."] = "Du wurdest aus der Warteliste entfernt.",
	["Spam channels automatically when opening the invite tablet."] = "Automatisch in Kanäle posten, wenn das Ladefenster geöffnet wird.",
	["Spam channels with current waitlist."] = "Spamme Channels mit aktueller Warteliste.",
	["Spam channels with waitinfo now."] = "Jetzt die Info zur Warteliste posten.",
	["Spam Current"] = "Spamme Aktuelle",
	["Spam Waitinfo"] = "Jetzt posten",
	["That main does not exist."] = "Dieser Main Char existiert nicht.",
	Waitlist = "Warteliste",
	["Waitlist allows members to whisper you for invites and to receive DKP even if not in the actual raid."] = "Die Warteliste erlaubt es Leuten, sich per Whisper einzuladen und DKP dafür zu erhalten, dass sie in Bereitschaft sind.",
	["Waitlist boss DKP"] = "Boss DKP für Warteliste",
	["Waitlist boss event name"] = "Bossname für Warteliste",
	["Waitlist DKP/time"] = "DKP/Zeit für Wateliste",
	["Waitlist event name"] = "Eventname für Warteliste",
	["Waitlist reward"] = "Zeit für Warteliste",
	["Waitlist run DKP"] = "Raid DKP für Warteliste",
	["Waitlist spamming"] = "Poste in Kanäle",
	["Waitlist start DKP"] = "Start DKP für Warteliste",
}
L.Whisper = {
	Enable = "Aktiv",
	["%s: ID = %s  DKP/Bid value = %s  (Reply format: mbid ID [%s/%s/%s/%s bid value])"] = "%s: ID = %s  DKP/Bietwert = %s - Antwort wie folgt: mbid ID [%s/%s/%s/%s Wert], z.B. mbid 12059 gier 5",
	["Whispers all members (even if they have MorgBid) so they can reply and bid using whispers."] = "Alle Teilnehmer (selbst die mit MorgBid2) anflüstern, damit sie bei Auktionen direkt antworten können.",
	["Whisper system"] = "Flüstersystem",
}
L.Zerosum = {
	["Added %s DKP to %s attendees."] = "%s DKP zu %s Teilnehmern hinzugefügt.",
	["DKP award event name"] = "Eventname der DKP Zuweisung",
	[ [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=] ] = [=[Format des Eventnamens:  
<zone> test  
Beispiel:  <zone> DKP]=],
	["Include waitlist"] = "Mit Warteliste",
	["Include waitlist members in DKP calculations.  Note they will still get whatever DKP award is set in the waitlist module."] = "Leute in der Warteliste in die Berechnung einschlissen.  Bitte beachten: Die Leute in der Warteliste bekommen trotzdem die DKP Boni, die im Modul 'Warteliste' eingestellt wurden.",
	["Standard zero sum system where member is charged for the item and the charged points are divided between all raid members.  You must check use zerosum on the import webscript for website DKP to be correct."] = "Standard Nullsummen-System, bei dem die für ein Item ausgegebenen Punkte geteilt durch die Anzahl der Raidteilnehmer für alle Teilnehmer gutgeschrieben werden. Dafür muß in dem importierenden Webscript Nullsummen-DKP aktiviert sein.",
	["Zerosum DKP"] = "Nullsummen DKP",
	["Zerosum Options"] = "ZeroSum Optionen",
}

