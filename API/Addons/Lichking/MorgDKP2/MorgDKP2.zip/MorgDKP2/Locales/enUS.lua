local L = LibStub("AceLocale-3.0"):NewLocale("MorgDKP2", "enUS", true)

--module setup/options
L["|c000070ddClick:|r Nag old versions now\n|c000070ddR-Click:|r Close tablet."] = true
L["|c000070ddL-Click:|r Invite.\n|c000070ddCTRL-Click:|r Delete Character.\n|c000070ddALT-Click:|r Add to waitlist.\n|c000070ddSHIFT-Click:|r Remove from waitlist.\n|c000070ddR-Click:|r Close tablet."] = true
L["ALL"] = true
L["Allow the OFFSPEC button to be used in MorgBid2."] = true
L["Allow updating bid results in MorgBid2."] = true
L["Automatically enable MorgDKP2 and start a raid when entering a trackable zone."] = true
L["Autozone"] = true
L["Background color"] = true
L["Background texture of frames/tooltips."] = true
L["Background texture"] = true
L["Bank"] = true
L["Border color"] = true
L["Border texture of frames/tooltips."] = true
L["Border texture"] = true
L["Boss Attempt Mode"] = true
L["Clear currently tracked raids."] = true
L["Clear raid DB"] = true
L["Clear the raid database?"] = true
L["Close"] = true
L["COMPLETED"] = true
L["Core Modules"] = true
L["Core of all MorgDKP2 features."] = true
L["Core Options"] = true
L["Custom MorgBid2"] = true
L["Determine MorgBid user base. \nAlso useful to check DKP for alts."] = true
L["Developer mode"] = true
L["Display Options"] = true
L["DKP Modules"] = true
L["Earned DKP for Invites"] = true
L["Enable ML/DE mode"] = true
L["Enable tooltip hints"] = true
L["Enables changing the text of button hints in MorgBid2."] = true
L["Enables the main MorgDKP interface for raid tracking."] = true
L["Font color"] = true
L["Font size"] = true
L["Font used in tooltips and frames."] = true
L["Font"] = true
L["Frame scale"] = true
L["General display options for main modules."] = true
L["If ML/DE Mode is on then no items will be recorded for the master looter or disenchanter defined by MorgDKP2."] = true
L["Ignore 6-8"] = true
L["Ignore items worn by members.  This means queries will always be sent even if they have the item."] = true
L["Ignore members in groups 6-8 when querying for items."] = true														
L["Ignore worn"] = true
L["INRAID"] = true
L["Link items on the boss/mob that are above the loot threshold to guild chat."] = true
L["Link items on the boss/mob that are above the loot threshold to raid chat."] = true
L["Link to Guild"] = true
L["Link to Raid"] = true
L["List DKP"] = true
L["Morgbid check"] = true
L["MorgBid2 Options"] = true
L["MorgBid2 updating"] = true
L["MorgBid2 Version Query"] = true
L["MorgDKP2"] = true
L["NEED text"] = true
L["NEED"] = true
L["NONE"] = true
L["Not Set"] = true
L["OFFLINE"] = true
L["OFFSPEC text"] = true
L["OFFSPEC"] = true
L["ONLINE"] = true
L["PASS text"] = true
L["PASS"] = true
L["PENDING"] = true
L["Percent DKP"] = true
L["Percent DKP"] = true
L["Raid Tracker for viewing and editing current raids."] = true
L["Raid Tracker"] = true
L["Record boss attempt for %s?"] = true
L["TAKE text"] = true
L["TAKE"] = true
L["Text of MorgBid2 NEED button"] = true
L["Text of MorgBid2 OFFSPEC button"] = true
L["Text of MorgBid2 PASS button"] = true
L["Text of MorgBid2 TAKE button"] = true
L["Toggle MorgDKP2"] = true
L["UNKNOWN"] = true
L["Use earned DKP in the invite tablet (shift-click)."] = true
L["Use OFFSPEC"] = true
L["WAIT"] = true
L["Whisper system"] = true
L["Whispers all members (even if they have MorgBid2) so they can reply and bid using whispers."] = true
L["World Boss"] = true
L["xINRAIDx"] = true
L["xWAITx"] = true


--output messages
L["%s joined the raid at %s."] = true
L["%s left the raid at %s."] = true
L["%s received %s for %s DKP"] = true
L["Added %s DKP to %s attendees."] = true
L["Added %s DKP to %s."] = true
L["Added %s DKP to waitlist attendees."] = true
L["Added %s to ignore list."] = true
L["Alias %s already exihists.  No changes made."] = true
L["Changed itemcost from %s to %s DKP for %s."] = true
L["Cleared current raid database."] = true
L["Cleared the MorgDKP2 raid database."] = true
L["Currently loaded DKP pools..."] = true
L["Deleting %s from MorgDKP2 database."] = true
L["DKP Standings for %s:"] = true
L["Either no classes are selected or no members need this item."] = true
L["Give %s to %s, are you sure?"] = true
L["Main character %s does not exist.  No changes made."] = true
L["Main: "] = true
L["No current raid exists."] = true
L["Now querying for %s  ID = %s  DKP = %s"] = true
L["Offspec: "] = true
L["Please install MorgBid2 to bid on items.  http://www.wowace.com/projects/morg-bid2/ Thank-you:)"] = true
L["Please whisper: dkplist [poolname] [class] [class] .... [all]"] = true
L["Sorry your response format is incorrect or no item with that ID is up for bidding.  Format = mbid [ID/link] [%s/%s/%s/%s] [bid value]"] = true
L["This item is not currently up for bid."] = true
L["Transeferred %s DKP to %s from %s"] = true
L["Transferred %s to %s for %s DKP."] = true
L["You can not use this function out of a raid group."] = true
L["You must start a raid before you can start a query."] = true
L["Your response has been accepted: %s"] = true


--LDB 
L["|c000070ddClick:|r MorgBid2 Base query.\n|c000070ddALT-Click:|r Toggle ML/DE\n|c000070ddSHIFT-Click:|r Invite & Waitlist.\n|c000070ddCTRL-Click:|r Raid Tracker.\n|c000070ddCTRL-Click Itemlink:|r Ignore item."] = true
L["|c001eff00ON|r"] = true
L["|c009d9d9dOFF|r"] = true
L["Add a custom raid event.  This will record all attendees when you click the event menu by adding Attempt to the end of the boss name you have targeted.  You can change event name value through raid tracker.  SHIFT-Click to bypass menu."] = true
L["Anything below this quality threshold will NOT be logged."] = true
L["Boss attempt mode"] = true
L["COMPLETED"] = true
L["Custom Event"] = true
L["Disenchanter"] = true
L["DKP System"] = true
L["Enable more than one DKP pool for rolling on items.  When starting auction you have to choose the alternate pool (Defaults to primary pool)"] = true
L["End Raid"] = true
L["Export Raid"] = true
L["Fixed DKP"] = true
L["LDB Plugin"] = true
L["Main DKP Pool"] = true
L["Master Looter"] = true
L["Member assigned to disenchant items."] = true
L["ML/DE mode"] = true
L["Mode where a boss attempt is recorded when you die via a confirmation dialogue."] = true
L["MultiPool"] = true
L["NEW"] = true
L["NONE"] = true
L["On STANDBY.\n|c000070ddClick:|r to enable."] = true
L["PENDING"] = true
L["PENDING..."] = true
L["Plugin frame will not disappear until UI reloaded."] = true
L["Quality Threshold"] = true
L["Set DKP Pool to be primary DKP pool. Only pool if not using multiPool"] = true
L["Show minimap icon"] = true
L["Start Raid"] = true
L["Toggle LDB Plugin"] = true

--ignored mobs
L["Amani Dragonhawk Spirit"] = true
L["Kil'rek"] = true
L["Onyxian Whelp"] = true
L["Son of Flame"] = true

--custom mob triggers
L["Alexstrasza's Gift"] = true
L["Assembly of Iron"] = true	--hack for PT calling them that
L["Cache of Innovation"] = true
L["Cache of Living Stone"] = true
L["Cache of Storms"] = true
L["Cache of the Firelord"] = true
L["Cache of Winter"] = true
L["Chess Event"] = true
L["Dust Covered Chest"] = true
L["Four Horsemen Chest"] = true
L["Freya's Gift"] = true
L["Gift of the Observer"] = true
L["Julianne"] = true
L["Romulo & Julianne"] = true
L["Romulo"] = true

--unique loot
L["Unique"] = true
L["Unique-equipped"] = true

--boss YELLS
--majordomo
L["Impossible! Stay your attack, mortals... I submit! I submit!"] = true
--R&J start
L["What devil art thou, that dost torment me thus?"] = true
--Chess
L["The halls of Karazhan shake, as the curse binding the doors of the Gamesman's Hall is lifted."] = true
--Vashj enter P2
L["The time is now! Leave none standing! "] = true
--Vashj enter P3
L["You may want to take cover. "] = true
--Rage enters
L["The Legion's final conquest has begun! Once again the subjugation of this world is within our grasp. Let none survive!"] = true
--Anetheron enters
L["You are defenders of a doomed world! Flee here, and perhaps you will prolong your pathetic lives!"] = true
--Kazrogal enters
L["Cry for mercy! Your meaningless lives will soon be forfeit!"] = true
--Azgalore enters
L["Abandon all hope! The Legion has returned to finish what was begun so many years ago. This time, there will be no escape!"] = true
--Erador yell
L["These are the hallmarks..."] = true
--Kalecgos start yell
L["No longer will I be a slave to Malygos! Challenge me and you will be destroyed!"] = true
--4 horsemen start yell
L["The first kill goes to me! Anyone care to wager?"] = true
--Thorim
L["Stay your arms! I yield!"] = true
--Mimiron
L["It would appear that I've made a slight miscalculation. I allowed my mind to be corrupted by the fiend in the prison, overriding my primary directive. All systems seem to be functional now. Clear."] = true
L["Isn't it beautiful? I call it the magnificent aerial command unit!"] = true
L["Preliminary testing phase complete. Now comes the true test!"] = true
--Freya
L["His hold on me dissipates. I can see clearly once more. Thank you, heroes."] = true
--Hodir
L["I... I am released from his grasp... at last."] = true
--Iron Council start
L["You will not defeat the Assembly of Iron so easily, invaders!"] = true
--Algalon defeated
L["Perhaps it is your imperfection that which grants you free will. That allows you to persevere against cosmically calculated odds. You prevailed where the Titans' own perfect creations have failed."] = true
--Faction champs success
L["A shallow and tragic victory. We are weaker as a whole from the losses suffered today. Who but the Lich King could benefit from such foolishness? Great warriors have lost their lives. And for what? The true threat looms ahead - the Lich King awaits us all in death."] = true
--Gunship battle
L["Don't say I didn't warn ya, scoundrels! Onward, brothers and sisters!"] = true	
L["The Alliance falter. Onward to the Lich King!"] = true
--Valithria Dreamwalker
L["I AM RENEWED! Ysera grant me the favor to lay these foul creatures to rest!"] = true

--MODULES
L.BidWar = {
	["Beginning auction for %s:  ID = %s"] = "Beginning auction for %s:  ID = %s",
	["Bid Format = mbid [ID/link] [%s/%s/%s] [bid value]"] = "Bid Format = mbid [ID/link] [%s/%s/%s] [bid value]",
	["Bidding is now closed."] = "Bidding is now closed.",
	["BidWar mode changes the MorgBid query to allow players to bid on items.  Also the MorgDKP tablet uses bids after this NOT member DKP."] = "BidWar mode changes the MorgBid query to allow players to bid on items.  Also the MorgDKP tablet uses bids after this NOT member DKP.",
	["BidWar Options"] = "BidWar Options",
	["Changes the DKP step for BidWar mode.  Passes this value to MorgBid2 clients."] = "Changes the DKP step for BidWar mode.  Passes this value to MorgBid2 clients.",
	["Enable BidWar mode where the winner is charged the 2nd highest bid value for the item."] = "Enable BidWar mode where the winner is charged the 2nd highest bid value for the item.",
	["Enable BidWar mode with only one round of bidding and no reporting to raid chat."] = "Enable BidWar mode with only one round of bidding and no reporting to raid chat.",
	["Just enough"] = "Just enough",
	["Maximum amount of DKP that members can exceed their current DKP."] = "Maximum amount of DKP that members can exceed their current DKP.",
	["New high bidder for %s: %s = %s"] = "New high bidder for %s: %s = %s",
	["Silent auction"] = "Silent auction",
	["Sorry this is a silent auction and you have already placed your bid."] = "Sorry this is a silent auction and you have already placed your bid.",
	["You have exceeded the overbid amount of %s.  Your bid has been reset to the maximum."] = "You have exceeded the overbid amount of %s.  Your bid has been reset to the maximum.",
	Bidstep = "Bidstep",
	BidWar = "BidWar",
	Overbid = "Overbid",
}

L.DKPovertime = {
	["Added %s DKP to %s attendees."] = "Added %s DKP to %s attendees.",
	["Award amount"] = "Award amount",
	["Award time"] = "Award time",
	["DKP/time event name"] = "DKP/time event name",
	["DKP/time Options"] = "DKP/time Options",
	["DKP/time system which allows you to award DKP at custom intervals."] = "DKP/time system which allows you to award DKP at custom intervals.",
	["DKP/time"] = "DKP/time",
	["Format of event name:  \n<zone> text  \nExample:  <zone> DKP"] = "Format of event name:  \n<zone> text  \nExample:  <zone> DKP",
	["Time in minutes between DKP awards."] = "Time in minutes between DKP awards.",
}

L.Eventnaming = {
	["Allows you to change the default format for event names."] = "Allows you to change the default format for event names.",
	["Boss format"] = "Boss format",
	["Event naming"] = "Event naming",
	["Format of boss event names:  \n<zone> - <boss>\nExample:  <boss> <diff>"] = "Format of boss event names:  \n<zone> - <boss>\nExample:  <boss> <diff>",
	["Format of run event name:  \n<zone> text  \nExample:  <zone> <diff> Run"] = "Format of run event name:  \n<zone> text  \nExample:  <zone> <diff> Run",
	["Format of start event name:  \n<zone> text  \nExample:  <zone> <diff> Start"] = "Format of start event name:  \n<zone> text  \nExample:  <zone> <diff> Start",
	["Reset default values."] = "Reset default values.",
	["Run format"] = "Run format",
	["Start format"] = "Start format",
	["Toggle event naming"] = "Toggle event naming",
	Default = "Default",
	Enable = "Enable",
}

L.FixedDKP = {
	["DKP TAKE/OFFSPEC settings"] = "DKP TAKE/OFFSPEC settings",
	["Enable OFFSPEC"] = "Enable OFFSPEC",
	["Enable TAKE"] = "Enable TAKE",
	["Enables mode where members are charged a standard price for OFFSPEC items."] = "Enables mode where members are charged a standard price for OFFSPEC items.",
	["Enables mode where members are charged a standard price for TAKE items."] = "Enables mode where members are charged a standard price for TAKE items.",
	["Fixed DKP"] = "Fixed DKP",
	["OFFSPEC Percent"] = "OFFSPEC Percent",
	["OFFSPEC value"] = "OFFSPEC value",
	["Standard DKP system."] = "Standard DKP system.",
	["TAKE Percent"] = "TAKE Percent",
	["TAKE value"] = "TAKE value",
	["Use percent of item value for OFFSPEC mode."] = "Use percent of item value for OFFSPEC mode.",
	["Use percent of item value for TAKE mode."] = "Use percent of item value for TAKE mode.",
	Enable = "Enable",
}

L.Lootframe = {
	["%s awarded to %s for %s DKP"] = "%s awarded to %s for %s DKP",
	["%s awarded to %s"] = "%s awarded to %s",
	["%s will be disenchanted in 5 seconds."] = "%s will be disenchanted in 5 seconds.",
	["|c000070ddClick:|r allocate randomly"] = "|c000070ddClick:|r allocate randomly",
	["|c000070ddClick:|r Announce winner."] = "|c000070ddClick:|r Announce winner.",
	["|c000070ddClick:|r give item to disenchanter"] = "|c000070ddClick:|r give item to disenchanter",
	["|c000070ddClick:|r give this item to disenchanter."] = "|c000070ddClick:|r give this item to disenchanter.",
	["|c000070ddClick:|r loot item\n|c000070ddR-Click:|r open itemdata or roll frame\n|c000070ddAlt-R-Click:|r start all queries"] = "|c000070ddClick:|r loot item\n|c000070ddR-Click:|r open itemdata or roll frame\n|c000070ddAlt-R-Click:|r start all queries",
	["|c000070ddClick:|r select pool to use for item."] = "|c000070ddClick:|r select pool to use for item.",
	["|c000070ddClick:|r self loot"] = "|c000070ddClick:|r self loot",
	["|c000070ddClick:|r start item query.\n|c000070ddAlt-Click:|r start all queries\n|c000070ddShift-Click:|r random query for this item\n|c000070ddCtrl-Click:|r ignore this item"] = "|c000070ddClick:|r start item query.\n|c000070ddAlt-Click:|r start all queries\n|c000070ddShift-Click:|r random query for this item\n|c000070ddCtrl-Click:|r ignore this item",
	["|c000070ddClick:|r stop this item query."] = "|c000070ddClick:|r stop this item query.",
	["|c000070ddMousewheel up/Click|r - Increase value.\n|c000070ddMousewheel down/R-Click|r - decrease value.\n|c000070ddSHIFT|r - change value by +/-1\n|c000070ddALT|r - change value by +/-20\n|c000070ddCTRL|r - change value by +/-100"] = "|c000070ddMousewheel up/Click|r - Increase value.\n|c000070ddMousewheel down/R-Click|r - decrease value.\n|c000070ddSHIFT|r - change value by +/-1\n|c000070ddALT|r - change value by +/-20\n|c000070ddCTRL|r - change value by +/-100",
	["Always use the MorgDKP2 loot window even when the mod is in standby mode."] = "Always use the MorgDKP2 loot window even when the mod is in standby mode.",
	["Always use"] = "Always use",
	["DKP: %s"] = "DKP: %s",
	["Give %s to %s, are you sure?"] = "Give %s to %s, are you sure?",
	["Lootframe scale"] = "Lootframe scale",
	["Open lootframe at cursor postition"] = "Open lootframe at cursor postition",
	["Replace Blizzard"] = "Replace Blizzard",
	["Select primary class"] = "Select primary class",
	["Select secondary class"] = "Select secondary class",
	["Snap to cursor"] = "Snap to cursor",
	["When MorgDKP2 is active it's loot frame will replace default."] = "When MorgDKP2 is active it's loot frame will replace default.",
	Alt = "Alt",
	Class = "Class",
	Lootframe = "Lootframe",
}

L.Percent = {
	["Items will cost a percentage of the members total DKP."] = "Items will cost a percentage of the members total DKP.",
	["Percent cost"] = "Percent cost",
	["Percent DKP"] = "Percent DKP",
	["Percent DKP Options"] = "Percent DKP Options",
	["Percent take"] = "Percent take",
	["When using the percent DKP system this option enables TAKE looting.  This means if the winning member rolled TAKE he will not be charged x% DKP he will instead be charged the base price of the item (Set using original itempoints."] = "When using the percent DKP system this option enables TAKE looting.  This means if the winning member rolled TAKE he will not be charged x% DKP he will instead be charged the base price of the item (Set using original itempoints.",
}

L.PointsDB = {
	["Added alias: %s of %s with %s DKP."] = "Added alias: %s of %s with %s DKP.",
	["Addeded %s to item database."] = "Addeded %s to item database.",
	["Added %s players from %s"] = "Added %s players from %s",
	["Add item"] = "Add item",
	["Add new item to track.  Drag the item to this input box."] = "Add new item to track.  Drag the item to this input box.",
	["Clear player DB"] = "Clear player DB",
	["Clear raid DB"] = "Clear raid DB",
	["Clears all items in the database below the selected item level."] = "Clears all items in the database below the selected item level.",
	["Clears all members in the database inactive longer than the selected number of weeks."] = "Clears all members in the database inactive longer than the selected number of weeks.",
	["Clears all players currently in the database. Does not affect items."] = "Clears all players currently in the database. Does not affect items.",
	["Clears the current tracked raids."] = "Clears the current tracked raids.",
	["Cull item DB"] = "Cull item DB",
	["Cull item level"] = "Cull item level",
	["Cull member DB"] = "Cull member DB",
	["Cull member level (weeks)"] = "Cull member level (weeks)",
	["Current rank weight"] = "Current rank weight",
	["Database Functions"] = "Database Functions",
	["Database transfer complete. %s items were transferred and %s members updated."] = "Database transfer complete. %s items were transferred and %s members updated.",
	["Higher number for higher display priority. (7 will appear above 3 on the tooltip)"] = "Higher number for higher display priority. (7 will appear above 3 on the tooltip)",
	["Ignored items"] = "Ignored items",
	["Import database from MorgDKP?"] = "Import database from MorgDKP?",
	["Import default item database?"] = "Import default item database?",
	["Imported MorgDKP DB with %s players and %s items."] = "Imported MorgDKP DB with %s players and %s items.",
	["List of currently ignored items.  Click to remove item from ignore list."] = "List of currently ignored items.  Click to remove item from ignore list.",
	["List of member ranks in the current pool."] = "List of member ranks in the current pool.",
	["Player database cleared!"] = "Player database cleared!",
	["Player DKP reset to zero!"] = "Player DKP reset to zero!",
	["Please delete the ItemData.lua file from the MorgDKP directory now."] = "Please delete the ItemData.lua file from the MorgDKP directory now.",
	["Rank weights"] = "Rank weights",
	["Removed %s items from the database."] = "Removed %s items from the database.",
	["Removed %s members from the database."] = "Removed %s members from the database.",
	["Resets all members DKP to zero."] = "Resets all members DKP to zero.",
	["Updating DKP Points.."] = "Updating DKP Points..",
	["Zero player DB"] = "Zero player DB",
	["Add ignored item"] = "Add ignored item",
	["Add new item to ignore.  Drag the item to this input box."] = "Add new item to ignore.  Drag the item to this input box."
}

L.RaidTracker = {
	["Alias Database"] = "Alias Database",
	["Create new event"] = "Create new event",
	["Current raid"] = "Current raid",
	["Delete Raid"] = "Delete Raid",
	["DKP Changes"] = "DKP Changes",
	["Enter alias name"] = "Enter alias name",
	["Enter DKP change amount"] = "Enter DKP change amount",
	["Enter DKP change members"] = "Enter DKP change members",
	["Enter event attendees"] = "Enter event attendees",
	["Enter event name"] = "Enter event name",
	["Enter event note"] = "Enter event note",
	["Enter event value"] = "Enter event value",
	["Enter item event"] = "Enter item event",
	["Enter item value"] = "Enter item value",
	["Enter item winner"] = "Enter item winner",
	["Enter main name"] = "Enter main name",
	["Export Raid"] = "Export Raid",
	["Item Database"] = "Item Database",
	["Item DB"] = "Item DB",
	["Raid Editing"] = "Raid Editing",
	["Raid Tracker for viewing and editing current raids."] = "Raid Tracker for viewing and editing current raids.",
	["Raid Tracker"] = "Raid Tracker",
	["Select primary class"] = "Select primary class",
	["Select secondary class"] = "Select secondary class",
	["Update attends"] = "Update attends",
	["You can not remove the run event."] = "You can not remove the run event.",
	Add = "Add",
	Aliases = "Aliases",
	Alt = "Alt",
	Attendees = "Attendees",
	Class = "Class",
	Close = "Close",
	Delete = "Delete",
	Enable = "Enable",
	Eventname = "Eventname",
	Eventnote = "Eventnote",
	Group = "Group",
	Ignore = "Ignore",
	Raids = "Raids",
	Value = "Value",
}

L.Random = {
	["Enable random rolling for items."] = "Enable random rolling for items.",
	["Random rolls"] = "Random rolls",
	["%s received %s."] = "%s received %s.",
}

L.Relational = {
	["Enable Relational DKP for calculating the earned/spent dkp ratio."] = "Enable Relational DKP for calculating the earned/spent dkp ratio.",
	["Relational DKP"] = "Relational DKP",
	["Relational DKP Options"] = "Relational DKP Options",
	["Minimum DKP base"] = "Minimum DKP base",
	["Minimum amount of DKP a member can have for calculating the DKP ratio to avoid a new member having a high ratio. ie  200 earned DKP/ (this value)"] = "Minimum amount of DKP a member can have for calculating the DKP ratio to avoid a new member having a high ratio. ie  200 earned DKP/ (this value)",
}

L.SKall = {
	["Enable raid award"] = "Enable raid award",
	["Enables DKP removed from item winner to be awarded to raid members.  You must check use zerosum on the import webscript for website DKP to be correct."] = "Enables DKP removed from item winner to be awarded to raid members.  You must check use zerosum on the import webscript for website DKP to be correct.",
	["Enable Suicide Kings spend all DKP."] = "Enable Suicide Kings spend all DKP.",
	["% Member DKP"] = "% Member DKP",
	["Percent of member DKP to remove."] = "Percent of member DKP to remove.",
	["SKall DKP"] = "SKall DKP",
	["SKall Options"] = "SKall Options",
}

L.SKSotC = {
	["SKSotC DKP"] = "SKSotC DKP",
	["Enable Suicide Kings SotC variant DKP."] = "Enable Suicide Kings SotC variant DKP.",
	["SKSotC Options"] = "SKSotC Options",
	["Missed raid DKP"] = "Missed raid DKP",
	["Amount of DKP to remove from members who miss a raid."] = "Amount of DKP to remove from members who miss a raid.",
	["Demotion event"] = "Demotion event",
	["Format of event name:  \n<zone> text  \nExample:  <zone> DKP"] = "Format of event name:  \n<zone> text  \nExample:  <zone> DKP",
}

L.Syncing = {
	["%s's MorgDKP2 is out of date!"] = "%s's MorgDKP2 is out of date!",
	["%s's password does not match your password!"] = "%s's password does not match your password!",
	["Accept DKP changes from other raid leaders."] = "Accept DKP changes from other raid leaders.",
	["Added %s to listeners."] = "Added %s to listeners.",
	["Automatically set broadcast/receive depending if you are the master looter."] = "Automatically set broadcast/receive depending if you are the master looter.",
	["Broadcast DKP changes to other raid leaders."] = "Broadcast DKP changes to other raid leaders.",
	["Immediate Sync Options"] = "Immediate Sync Options",
	["Import %s data from %s?"] = "Import %s data from %s?",
	["Imported %s items"] = "Imported %s items",
	["Imported options...restarting."] = "Imported options...restarting.",
	["Initial Sync"] = "Initial Sync",
	["Items Sync"] = "Items Sync",
	["Members Sync"] = "Members Sync",
	["Options Sync"] = "Options Sync",
	["Overwrite raid"] = "Overwrite raid",
	["Overwrite the current raid if you receive an initial sync and are currently in a raid."] = "Overwrite the current raid if you receive an initial sync and are currently in a raid.",
	["Removed %s from listeners."] = "Removed %s from listeners.",
	["Resends initial sync.  Only needed in cases where you have problems as this is done automatically."] = "Resends initial sync.  Only needed in cases where you have problems as this is done automatically.",
	["Send DB Sync"] = "Send DB Sync",
	["Sends your current database of item DKP values."] = "Sends your current database of item DKP values.",
	["Sends your current database of member DKP values, item values, and MorgDKP2 options to the current raid."] = "Sends your current database of member DKP values, item values, and MorgDKP2 options to the current raid.",
	["Sends your current database of member DKP values."] = "Sends your current database of member DKP values.",
	["Sends your current MorgDKP2 options.  Note will restart MorgDKP2 so do not send another sync until it restarts or use full sync and it will be handled properly."] = "Sends your current MorgDKP2 options.  Note will restart MorgDKP2 so do not send another sync until it restarts or use full sync and it will be handled properly.",
	["Syncing password"] = "Syncing password",
	["Syncing system for communicating DKP between raid leaders."] = "Syncing system for communicating DKP between raid leaders.",
	["Updated %s members"] = "Updated %s members",
	Automatic = "Automatic",
	Broadcast = "Broadcast",
	Enable = "Enable",
	Password = "Password",
	Receive = "Receive",
	Syncing = "Syncing",
}

L.TakeBid = {
	["Changes the DKP step for TakeBid mode.  Passes this value to MorgBid2 clients."] = "Changes the DKP step for TakeBid mode.  Passes this value to MorgBid2 clients.",
	["Maximum amount of DKP that members can exceed their current DKP."] = "Maximum amount of DKP that members can exceed their current DKP.",
	["TakeBid DKP"] = "TakeBid DKP",
	["TakeBid Options"] = "TakeBid Options",
	["Minimum bid"] = "Minimum bid",
	["Minimum amount of DKP that members can bid for an item."] = "Minimum amount of DKP that members can bid for an item.",
	["Variation of Fixed DKP where when you bid take you also enter what you are willing to pay."] = "Variation of Fixed DKP where when you bid take you also enter what you are willing to pay.",
	Bidstep = "Bidstep",
	Overbid = "Overbid",
}

L.Tracker = {
	["%s defeated in %s!"] = "%s defeated in %s!",
	["%s recorded at %s with %s attendees."] = "%s recorded at %s with %s attendees.",
	["and add these attendees < %s min?"] = "and add these attendees < %s min?",
	["Attendance reward"] = "Attendance reward",
	["Bank character"] = "Bank character",
	["Clear the raid database?"] = "Clear the raid database?",
	["Core of all MorgDKP2 raid tracking features. \nCan not be disabled."] = "Core of all MorgDKP2 raid tracking features. \nCan not be disabled.",
	["CTRT format"] = "CTRT format",
	["DKP Export"] = "DKP Export",
	["DKP listener"] = "DKP listener",
	["DKP Tracking"] = "DKP Tracking",
	["DKP which new members to the database receive."] = "DKP which new members to the database receive.",
	["End %s"] = "End %s",
	["End Raid"] = "End Raid",
	["Eqdkp+ event format"] = "Eqdkp+ event format",
	["Events for DKP changes"] = "Events for DKP changes",
	["Export Raids"] = "Export Raids",
	["Exports current raid(s) data for import into website."] = "Exports current raid(s) data for import into website.",
	["Finalizes the current raid."] = "Finalizes the current raid.",
	["Format of new member DKP event name."] = "Format of new member DKP event name.",
	["General options"] = "General options",
	["Guildlaunch format"] = "Guildlaunch format",
	["Minimum time to add member to raid and award run DKP."] = "Minimum time to add member to raid and award run DKP.",
	["New member DKP event"] = "New member DKP event",
	["New member start DKP"] = "New member start DKP",
	["No current raid exists."] = "No current raid exists.",
	["Opens the raidtracker interface."] = "Opens the raidtracker interface.",
	["Previous best kill time: %s"] = "Previous best kill time: %s",
	["Raid Tracker"] = "Raid Tracker",
	["Remember kill times"] = "Remember kill times",
	["Remove the ' character from any event names because eqdkp+ is dumb."] = "Remove the ' character from any event names because eqdkp+ is dumb.",
	["Removed %s raid attendees."] = "Removed %s raid attendees.",
	["Sartharion minibosses"] = "Sartharion minibosses",
	["Single run event"] = "Single run event",
	["Sorry %s is an invalid database pool.  Please choose a correct one or export your DKP from your website."] = "Sorry %s is an invalid database pool.  Please choose a correct one or export your DKP from your website.",
	["Start Event"] = "Start Event",
	["Start Raid"] = "Start Raid",
	["Starts a new raid."] = "Starts a new raid.",
	["Store your best kill times for bosses."] = "Store your best kill times for bosses.",
	["Trigger events for Sartharion minibosses."] = "Trigger events for Sartharion minibosses.",
	["Use a bank character in raids."] = "Use a bank character in raids.",
	["Use CTRT export format for raid exports."] = "Use CTRT export format for raid exports.",
	["Use events for DKP changes instead of database adjustments."] = "Use events for DKP changes instead of database adjustments.",
	["Use guildlaunch export format for raid exports."] = "Use guildlaunch export format for raid exports.",
	["Use one event for entire raid.  Boss kills will not be tracked separately."] = "Use one event for entire raid.  Boss kills will not be tracked separately.",
	["Use start event when raid begins."] = "Use start event when raid begins.",
	["When you are in a tracked zone you will track DKP but you will not get the loot popup window or link to the raid.  You will act like a backup raidlog."] = "When you are in a tracked zone you will track DKP but you will not get the loot popup window or link to the raid.  You will act like a backup raidlog.",
	["Yes & Add"] = "Yes & Add",
	CANCEL = "CANCEL",
	NO = "NO",
	Shortcuts = "Shortcuts",
	YES = "YES",
}

L.Waitlist = {
	["Added %s to the waitlist."] = "Added %s to the waitlist.",
	["Added you to the waitlist."] = "Added you to the waitlist.",
	["Amount of DKP to reward after members have been on the waitlist for the current reward time."] = "Amount of DKP to reward after members have been on the waitlist for the current reward time.",
	["Amount of DKP to reward at raidstart."] = "Amount of DKP to reward at raidstart.",
	["Amount of DKP to reward to waitlist members per bosskill."] = "Amount of DKP to reward to waitlist members per bosskill.",
	["Amount of DKP to reward to waitlist members when awarding regular members DKP/time. Note: only works if you are awarding DKP/time."] = "Amount of DKP to reward to waitlist members when awarding regular members DKP/time. Note: only works if you are awarding DKP/time.",
	["Autochannel Spam"] = "Autochannel Spam",
	["Award DKP to current waitlist members"] = "Award DKP to current waitlist members",
	["Award DKP"] = "Award DKP",
	["Channels to spam when starting invites."] = "Channels to spam when starting invites.",
	["Clear Waitlist"] = "Clear Waitlist",
	["Clears the current wailist."] = "Clears the current wailist.",
	["Current waitlist: %s"] = "Current waitlist: %s",
	["Event Names"] = "Event Names",
	["Format of waitlist boss events:  \n<boss> text  \nExample:  <boss> Waitlist DKP"] = "Format of waitlist boss events:  \n<boss> text  \nExample:  <boss> Waitlist DKP",
	["Format of waitlist event names:  \n<zone> text  \nExample:  <zone> Waitlist DKP"] = "Format of waitlist event names:  \n<zone> text  \nExample:  <zone> Waitlist DKP",
	["Grace Period"] = "Grace Period",
	["Minimum time before offline waitlist members will be removed."] = "Minimum time before offline waitlist members will be removed.",
	["Minimum time to award run DKP to a waitlist member."] = "Minimum time to award run DKP to a waitlist member.",
	["Now accepting tells for the waitlist.  Please whisper %s using this format:  mbid wait[+/-] [main]"] = "Now accepting tells for the waitlist.  Please whisper %s using this format:  mbid wait[+/-] [main]",
	["Please log on to your main for an invite to the raid.  Whisper me when online."] = "Please log on to your main for an invite to the raid.  Whisper me when online.",
	["Removed %s from wailist."] = "Removed %s from wailist.",
	["Removed %s from waitlist due to inactivity"] = "Removed %s from waitlist due to inactivity",
	["Removed you from the waitlist."] = "Removed you from the waitlist.",
	["Spam channels automatically when opening the invite tablet."] = "Spam channels automatically when opening the invite tablet.",
	["Spam channels with current waitlist."] = "Spam channels with current waitlist.",
	["Spam channels with waitinfo now."] = "Spam channels with waitinfo now.",
	["Spam Current"] = "Spam Current",
	["Spam Waitinfo"] = "Spam Waitinfo",
	["That main does not exist."] = "That main does not exist.",
	["Waitlist allows members to whisper you for invites and to receive DKP even if not in the actual raid."] = "Waitlist allows members to whisper you for invites and to receive DKP even if not in the actual raid.",
	["Waitlist boss DKP"] = "Waitlist boss DKP",
	["Waitlist boss event name"] = "Waitlist boss event name",
	["Waitlist DKP/time"] = "Waitlist DKP/time",
	["Waitlist event name"] = "Waitlist event name",
	["Waitlist reward"] = "Waitlist reward",
	["Waitlist run DKP"] = "Waitlist run DKP",
	["Waitlist spamming"] = "Waitlist spamming",
	["Waitlist start DKP"] = "Waitlist start DKP",
	Channels = "Channels",
	Enable = "Enable",
	Waitlist = "Waitlist",
}

L.Whisper = {
	["%s: ID = %s  DKP/Bid value = %s  (Reply format: mbid ID [%s/%s/%s/%s bid value])"] = "%s: ID = %s  DKP/Bid value = %s  (Reply format: mbid ID [%s/%s/%s/%s bid value])",
	["Whisper system"] = "Whisper system",
	["Whispers all members (even if they have MorgBid) so they can reply and bid using whispers."] = "Whispers all members (even if they have MorgBid) so they can reply and bid using whispers.",
	Enable = "Enable",
}

L.Zerosum = {
	["Added %s DKP to %s attendees."] = "Added %s DKP to %s attendees.",
	["DKP award event name"] = "DKP award event name",
	["Format of event name:  \n<zone> text  \nExample:  <zone> DKP"] = "Format of event name:  \n<zone> text  \nExample:  <zone> DKP",
	["Include waitlist"] = "Include waitlist",
	["Include waitlist members in DKP calculations.  Note they will still get whatever DKP award is set in the waitlist module."] = "Include waitlist members in DKP calculations.  Note they will still get whatever DKP award is set in the waitlist module.",
	["Standard zero sum system where member is charged for the item and the charged points are divided between all raid members.  You must check use zerosum on the import webscript for website DKP to be correct."] = "Standard zero sum system where member is charged for the item and the charged points are divided between all raid members.  You must check use zerosum on the import webscript for website DKP to be correct.",
	["Zerosum DKP"] = "Zerosum DKP",
	["Zerosum Options"] = "Zerosum Options",
}

