﻿local L = LibStub("AceLocale-3.0"):NewLocale("MorgDKP2", "esES")
if not L then return end

L["Abandon all hope! The Legion has returned to finish what was begun so many years ago. This time, there will be no escape!"] = "Abandon all hope! The Legion has returned to finish what was begun so many years ago. This time, there will be no escape!" -- Requires localization
L["Add a custom raid event.  This will record all attendees when you click the event menu by adding Attempt to the end of the boss name you have targeted.  You can change event name value through raid tracker.  SHIFT-Click to bypass menu."] = "Add a custom raid event.  This will record all attendees when you click the event menu by adding Attempt to the end of the boss name you have targeted.  You can change event name value through raid tracker.  SHIFT-Click to bypass menu." -- Requires localization
L["Added %s DKP to %s."] = "Añadidos %s DKP a %s."
L["Added %s DKP to %s attendees."] = "Añadidos %s DKP a %s asistentes."
L["Added %s DKP to waitlist attendees."] = "Added %s DKP to waitlist attendees." -- Requires localization
L["Added %s to ignore list."] = "Añadido %s a la lista de ignorados"
L["Alexstrasza's Gift"] = "Alexstrasza's Gift" -- Requires localization
L["Alias %s already exihists.  No changes made."] = "El alias %s ya existe. No se hizo ningún cambio."
L["ALL"] = "TODOS"
L["Allow the OFFSPEC button to be used in MorgBid2."] = "Permitir el uso del botón OFFSPEC en MorgBid2."
L["Allow updating bid results in MorgBid2."] = "Allow updating bid results in MorgBid2." -- Requires localization
L["Amani Dragonhawk Spirit"] = "Amani Dragonhawk Spirit" -- Requires localization
L["Anything below this quality threshold will NOT be logged."] = "Cualquier cosa por debajo de este umbral de calidad no será registrado."
L["Artifact"] = "Artefacto"
L["A shallow and tragic victory. We are weaker as a whole from the losses suffered today. Who but the Lich King could benefit from such foolishness? Great warriors have lost their lives. And for what? The true threat looms ahead - the Lich King awaits us all in death."] = "A shallow and tragic victory. We are weaker as a whole from the losses suffered today. Who but the Lich King could benefit from such foolishness? Great warriors have lost their lives. And for what? The true threat looms ahead - the Lich King awaits us all in death." -- Requires localization
L["Assembly of Iron"] = "Assembly of Iron" -- Requires localization
L["Automatically enable MorgDKP2 and start a raid when entering a trackable zone."] = "Activar automáticamente MorgDKP2 y empezar una raid cuando se entre en una zona conocida."
L["Autozone"] = "Autozona"
L["Background color"] = "Color de fondo"
L["Background texture"] = "Textura de fondo"
L["Background texture of frames/tooltips."] = "Textura de fondo de frames/tooltips"
L["Bank"] = "Banco"
L["Border color"] = "Color del borde"
L["Border texture"] = "Textura del borde"
L["Border texture of frames/tooltips."] = "Border texture of frames/tooltips." -- Requires localization
L["Boss attempt mode"] = "Boss attempt mode" -- Requires localization
L["Boss Attempt Mode"] = "Boss Attempt Mode" -- Requires localization
L[ [=[|c000070ddClick:|r MorgBid2 Base query.
|c000070ddALT-Click:|r Toggle ML/DE
|c000070ddSHIFT-Click:|r Invite & Waitlist.
|c000070ddCTRL-Click:|r Raid Tracker.
|c000070ddCTRL-Click Itemlink:|r Ignore item.]=] ] = [=[|c000070ddClick:|r MorgBid2 Base query.
|c000070ddALT-Click:|r Toggle ML/DE
|c000070ddSHIFT-Click:|r Invite & Waitlist.
|c000070ddCTRL-Click:|r Raid Tracker.
|c000070ddCTRL-Click Itemlink:|r Ignore item.]=] -- Requires localization
L[ [=[|c000070ddClick:|r Nag old versions now
|c000070ddR-Click:|r Close tablet.]=] ] = [=[|c000070ddClick:|r Nag old versions now
|c000070ddR-Click:|r Close tablet.]=] -- Requires localization
L[ [=[|c000070ddL-Click:|r Invite.
|c000070ddCTRL-Click:|r Delete Character.
|c000070ddALT-Click:|r Add to waitlist.
|c000070ddSHIFT-Click:|r Remove from waitlist.
|c000070ddR-Click:|r Close tablet.]=] ] = [=[|c000070ddL-Click:|r Invite.
|c000070ddCTRL-Click:|r Delete Character.
|c000070ddALT-Click:|r Add to waitlist.
|c000070ddSHIFT-Click:|r Remove from waitlist.
|c000070ddR-Click:|r Close tablet.]=] -- Requires localization
L["|c001eff00ON|r"] = "|c001eff00ON|r" -- Requires localization
L["|c009d9d9dOFF|r"] = "|c009d9d9dOFF|r" -- Requires localization
L["Cache of Innovation"] = "Alijo de innovación"
L["Cache of Living Stone"] = "Alijo de piedra viva"
L["Cache of Storms"] = "Alijo de tormentas"
L["Cache of the Firelord"] = "Botín del señor del fuego"
L["Cache of Winter"] = "Alijo de invierno"
L["|cff0070dd|Hitem:14344:0:0:0:0:0:0:0|h[Large Brilliant Shard]|h|r"] = "|cff0070dd|Hitem:14344:0:0:0:0:0:0:0|h[Large Brilliant Shard]|h|r" -- Requires localization
L["|cff0070dd|Hitem:22448:0:0:0:0:0:0:0|h[Small Prismatic Shard]|h|r"] = "|cff0070dd|Hitem:22448:0:0:0:0:0:0:0|h[Small Prismatic Shard]|h|r" -- Requires localization
L["|cff0070dd|Hitem:22449:0:0:0:0:0:0:0|h[Large Prismatic Shard]|h|r"] = "|cff0070dd|Hitem:22449:0:0:0:0:0:0:0|h[Large Prismatic Shard]|h|r" -- Requires localization
L["|cffa335ee|Hitem:18562:0:0:0:0:0:0:0|h[Elementium Ore]|h|r"] = "|cffa335ee|Hitem:18562:0:0:0:0:0:0:0|h[Elementium Ore]|h|r" -- Requires localization
L["|cffa335ee|Hitem:20725:0:0:0:0:0:0:0|h[Nexus Crystal]|h|r"] = "|cffa335ee|Hitem:20725:0:0:0:0:0:0:0|h[Nexus Crystal]|h|r" -- Requires localization
L["|cffa335ee|Hitem:22450:0:0:0:0:0:0:0|h[Void Crystal]|h|r"] = "|cffa335ee|Hitem:22450:0:0:0:0:0:0:0|h[Void Crystal]|h|r" -- Requires localization
L["|cffa335ee|Hitem:29434:0:0:0:0:0:0:0|h[Badge of Justice]|h|r"] = "|cffa335ee|Hitem:29434:0:0:0:0:0:0:0|h[Badge of Justice]|h|r" -- Requires localization
L["|cffa335ee|Hitem:32230:0:0:0:0:0:0:0|h[Shadowsong Amethyst]|h|r"] = "|cffa335ee|Hitem:32230:0:0:0:0:0:0:0|h[Shadowsong Amethyst]|h|r" -- Requires localization
L["|cffa335ee|Hitem:34057:0:0:0:0:0:0:0:80|h[Abyss Crystal]|h|r"] = "|cffa335ee|Hitem:34057:0:0:0:0:0:0:0:80|h[Cristal Abisal]|h|r"
L["|cffa335ee|Hitem:40752:0:0:0:0:0:0:0:80|h[Emblem of Heroism]|h|r"] = "|cffa335ee|Hitem:40752:0:0:0:0:0:0:0:80|h[Emblema de Heroismo]|h|r"
L["|cffa335ee|Hitem:40753:0:0:0:0:0:0:0:80|h[Emblem of Valor]|h|r"] = " |cffa335ee|Hitem:40753:0:0:0:0:0:0:0:80|h[Emblema de Valor]|h|r"
L["|cffa335ee|Hitem:45624:0:0:0:0:0:0:0:80|h[Emblem of Conquest]|h|r"] = " |cffa335ee|Hitem:45624:0:0:0:0:0:0:0:80|h[Emblema de Conquista]|h|r"
L["|cffa335ee|Hitem:47241:0:0:0:0:0:0:0:80|h[Emblem of Triumph]|h|r"] = "|cffa335ee|Hitem:47241:0:0:0:0:0:0:0:80|h[Emblem of Triumph]|h|r" -- Requires localization
L["|cffff8000|Hitem:30311:0:0:0:0:0:0:0|h[Warp Slicer]|h|"] = "|cffff8000|Hitem:30311:0:0:0:0:0:0:0|h[Warp Slicer]|h|" -- Requires localization
L["|cffff8000|Hitem:30312:0:0:0:0:0:0:0|h[Infinity Blade]|h|r"] = "|cffff8000|Hitem:30312:0:0:0:0:0:0:0|h[Infinity Blade]|h|r" -- Requires localization
L["|cffff8000|Hitem:30313:0:0:0:0:0:0:0|h[Staff of Disintegration]|h|r"] = "|cffff8000|Hitem:30313:0:0:0:0:0:0:0|h[Staff of Disintegration]|h|r" -- Requires localization
L["|cffff8000|Hitem:30314:0:0:0:0:0:0:0|h[Phaseshift Bulwark]|h|r"] = "|cffff8000|Hitem:30314:0:0:0:0:0:0:0|h[Phaseshift Bulwark]|h|r" -- Requires localization
L["|cffff8000|Hitem:30316:0:0:0:0:0:0:0|h[Devastation]|h|r"] = "|cffff8000|Hitem:30316:0:0:0:0:0:0:0|h[Devastation]|h|r" -- Requires localization
L["|cffff8000|Hitem:30317:0:0:0:0:0:0:0|h[Cosmic Infuser]|h|r"] = "|cffff8000|Hitem:30317:0:0:0:0:0:0:0|h[Cosmic Infuser]|h|r" -- Requires localization
L["|cffff8000|Hitem:30318:0:0:0:0:0:0:0|h[Netherstrand Longbow]|h|r"] = "|cffff8000|Hitem:30318:0:0:0:0:0:0:0|h[Netherstrand Longbow]|h|r" -- Requires localization
L["|cffff8000|Hitem:30319:0:0:0:0:0:0:0|h[Nether Spike]|h|r"] = "|cffff8000|Hitem:30319:0:0:0:0:0:0:0|h[Nether Spike]|h|r" -- Requires localization
L["|cffff8000|Hitem:30320:0:0:0:0:0:0:0|h[Bundle of Nether Spikes]|h|r"] = "|cffff8000|Hitem:30320:0:0:0:0:0:0:0|h[Bundle of Nether Spikes]|h|r" -- Requires localization
L["Changed itemcost from %s to %s DKP for %s."] = "Modificado el coste del objeto de %s a %s DKP para %s"
L["Chess Event"] = "Evento del ajedrez"
L["Clear currently tracked raids."] = "Borrar las raids registradas actualmente"
L["Cleared current raid database."] = "La base de datos de la raid actual ha sido borrada."
L["Cleared the MorgDKP2 raid database."] = "Borrada la base de datos de raids de MorgDKP2"
L["Clear raid DB"] = "Vaciar la BD de raids"
L["Clear the raid database?"] = "¿Borrar la base de datos de raids?"
L["Close"] = "Cerrar"
L["Common"] = "Común"
L["COMPLETED"] = "COMPLETED" -- Requires localization
L["Core Modules"] = "Core Modules" -- Requires localization
L["Core of all MorgDKP2 features."] = "Core of all MorgDKP2 features." -- Requires localization
L["Core Options"] = "Core Options" -- Requires localization
L["Cry for mercy! Your meaningless lives will soon be forfeit!"] = "Cry for mercy! Your meaningless lives will soon be forfeit!" -- Requires localization
L["Currently loaded DKP pools..."] = "Currently loaded DKP pools..." -- Requires localization
L["Custom Event"] = "Evento personalizado"
L["Custom MorgBid2"] = "Custom MorgBid2" -- Requires localization
L["Deleting %s from MorgDKP2 database."] = "Eliminando %s de la base de datos de MorgDKP2"
L[ [=[Determine MorgBid user base. 
Also useful to check DKP for alts.]=] ] = [=[Determine MorgBid user base. 
Also useful to check DKP for alts.]=] -- Requires localization
L["Developer mode"] = "Modo desarrollador"
L["Disenchanter"] = "Desencantador"
L["Display Options"] = "Display Options" -- Requires localization
L["DKP Modules"] = "Módulos DKP"
L["DKP Standings for %s:"] = "DKP Standings for %s:" -- Requires localization
L["DKP System"] = "Sistema DKP"
L["Don't say I didn't warn ya, scoundrels! Onward, brothers and sisters!"] = "Don't say I didn't warn ya, scoundrels! Onward, brothers and sisters!" -- Requires localization
L["Dust Covered Chest"] = "Cofre cubierto de polvo"
L["Earned DKP for Invites"] = "Earned DKP for Invites" -- Requires localization
L["Either no classes are selected or no members need this item."] = "No se ha seleccionado ninguna clase o ningún miemgro necesita este objeto"
L["Enable ML/DE mode"] = "Modo ML/DE activado"
L["Enable more than one DKP pool for rolling on items.  When starting auction you have to choose the alternate pool (Defaults to primary pool)"] = "Activar más de un DKP pool para las pujas por objetos. En el momento de empezar una subasta deberá seleccionar el pool alternativo (por defecto se coge el pool primario)"
L["Enables changing the text of button hints in MorgBid2."] = "Enables changing the text of button hints in MorgBid2." -- Requires localization
L["Enables the main MorgDKP interface for raid tracking."] = "Enables the main MorgDKP interface for raid tracking." -- Requires localization
L["Enable tooltip hints"] = "Habilitar tooltips de sugerencias"
L["End Raid"] = "Finalizar raid"
L["Epic"] = "Épico"
L["Export Raid"] = "Exportar raid"
L["Fixed DKP"] = "Fixed DKP" -- Requires localization
L["Font"] = "Fuente"
L["Font color"] = "Color de la fuente"
L["Font size"] = "Tamaño de la fuente"
L["Font used in tooltips and frames."] = "Fuente usada en tooltips y frames"
L["Four Horsemen Chest"] = "Cofre de los Cuatro Jinetes"
L["Frame scale"] = "Escala del frame"
L["Freya's Gift"] = "Freya's Gift" -- Requires localization
L["General display options for main modules."] = "General display options for main modules." -- Requires localization
L["Gift of the Observer"] = "Gift of the Observer" -- Requires localization
L["Give %s to %s, are you sure?"] = "Dar %s a %s, ¿estás seguro?"
L["His hold on me dissipates. I can see clearly once more. Thank you, heroes."] = "His hold on me dissipates. I can see clearly once more. Thank you, heroes." -- Requires localization
L["I AM RENEWED! Ysera grant me the favor to lay these foul creatures to rest!"] = "I AM RENEWED! Ysera grant me the favor to lay these foul creatures to rest!" -- Requires localization
L["If ML/DE Mode is on then no items will be recorded for the master looter or disenchanter defined by MorgDKP2."] = "Si el modo ML/DE está activado los objetos no seran registrados para el maestro despojador o el desencantador definido por MorgDKP2."
L["Ignore 6-8"] = "Ignora 6-8"
L["Ignore items worn by members.  This means queries will always be sent even if they have the item."] = "Ignore items worn by members.  This means queries will always be sent even if they have the item." -- Requires localization
L["Ignore members in groups 6-8 when querying for items."] = "Ignorar miembros en los grupos 6-8 cuando se pregunte por objetos."
L["Ignore worn"] = "Ignore worn" -- Requires localization
L["I... I am released from his grasp... at last."] = "I... I am released from his grasp... at last." -- Requires localization
L["Impossible! Stay your attack, mortals... I submit! I submit!"] = "Impossible! Stay your attack, mortals... I submit! I submit!" -- Requires localization
L["INRAID"] = "ENRAID"
L["Isn't it beautiful? I call it the magnificent aerial command unit!"] = "Isn't it beautiful? I call it the magnificent aerial command unit!" -- Requires localization
L["It would appear that I've made a slight miscalculation. I allowed my mind to be corrupted by the fiend in the prison, overriding my primary directive. All systems seem to be functional now. Clear."] = "It would appear that I've made a slight miscalculation. I allowed my mind to be corrupted by the fiend in the prison, overriding my primary directive. All systems seem to be functional now. Clear." -- Requires localization
L["Julianne"] = "Julianne" -- Requires localization
L["Kil'rek"] = "Kil'rek" -- Requires localization
L["LDB Plugin"] = "LDB Plugin" -- Requires localization
L["Legendary"] = "Legendario"
L["Link items on the boss/mob that are above the loot threshold to guild chat."] = "Mostrar los objetos del boss/mob que esta por encima del umbral de loteo al chat de hermandad"
L["Link items on the boss/mob that are above the loot threshold to raid chat."] = "Mostrar los objetos del boss/mob que esta por encima del umbral de loteo al chat de raid"
L["Link to Guild"] = "Mostrar a la hermandad"
L["Link to Raid"] = "Mostrar a la raid"
L["List DKP"] = "List DKP" -- Requires localization
L["Main: "] = "Principal:"
L["Main character %s does not exist.  No changes made."] = "El personaje principal %s no existe. No se hicieron cambios."
L["Main DKP Pool"] = "Pool de DKP principal"
L["Master Looter"] = "Maestro despojador"
L["Member assigned to disenchant items."] = "Miembro asignado para desencantar objetos"
L["ML/DE mode"] = "Modo ML/DE"
L["Mode where a boss attempt is recorded when you die via a confirmation dialogue."] = "Mode where a boss attempt is recorded when you die via a confirmation dialogue." -- Requires localization
L["MorgBid2 Options"] = "Opciones de MorgBid2"
L["MorgBid2 updating"] = "Actualizando MorgBid2"
L["MorgBid2 Version Query"] = "Consulta de versión de MorgBid2"
L["Morgbid check"] = "Comprobación Morgbid"
L["MorgDKP2"] = "MorgDKP2"
L["MultiPool"] = "MultiPool" -- Requires localization
L["NEED"] = "NEED" -- Requires localization
L["NEED text"] = "NEED text" -- Requires localization
L["NEW"] = "NEW" -- Requires localization
L["No current raid exists."] = "No hay ninguna raid activa."
L["No longer will I be a slave to Malygos! Challenge me and you will be destroyed!"] = "No longer will I be a slave to Malygos! Challenge me and you will be destroyed!" -- Requires localization
L["NONE"] = "NONE" -- Requires localization
L["Not Set"] = "Not Set" -- Requires localization
L["Now querying for %s  ID = %s  DKP = %s"] = "Preguntando por %s ID = %s DKP = %s"
L["OFFLINE"] = "OFFLINE" -- Requires localization
L["Offspec: "] = "Offspec: " -- Requires localization
L["OFFSPEC"] = "OFFSPEC" -- Requires localization
L["OFFSPEC text"] = "OFFSPEC text" -- Requires localization
L["ONLINE"] = "ONLINE" -- Requires localization
L[ [=[On STANDBY.
|c000070ddClick:|r to enable.]=] ] = [=[On STANDBY.
|c000070ddClick:|r to enable.]=] -- Requires localization
L["Onyxian Whelp"] = "Onyxian Whelp" -- Requires localization
L["PASS"] = "PASS" -- Requires localization
L["PASS text"] = "PASS text" -- Requires localization
L["PENDING"] = "PENDING" -- Requires localization
L["PENDING..."] = "PENDING..." -- Requires localization
L["Perhaps it is your imperfection that which grants you free will. That allows you to persevere against cosmically calculated odds. You prevailed where the Titans' own perfect creations have failed."] = "Perhaps it is your imperfection that which grants you free will. That allows you to persevere against cosmically calculated odds. You prevailed where the Titans' own perfect creations have failed." -- Requires localization
L["Please install MorgBid2 to bid on items.  http://www.wowace.com/projects/morg-bid2/ Thank-you:)"] = "Por favor instala MorgBid2 para pujar por los objetos. http://www.wowace.com/projects/morg-bid2/ Gracias :)"
L["Please whisper: dkplist [poolname] [class] [class] .... [all]"] = "Please whisper: dkplist [poolname] [class] [class] .... [all]" -- Requires localization
L["Plugin frame will not disappear until UI reloaded."] = "Plugin frame will not disappear until UI reloaded." -- Requires localization
L["Poor"] = "Pobre"
L["Preliminary testing phase complete. Now comes the true test!"] = "Preliminary testing phase complete. Now comes the true test!" -- Requires localization
L["Quality Threshold"] = "Umbral de calidad"
L["Raid Tracker"] = "Raid Tracker" -- Requires localization
L["Raid Tracker for viewing and editing current raids."] = "Raid tracker para ver y editar las raids actuales."
L["Rare"] = "Raro"
L["Record boss attempt for %s?"] = "¿Registrar intento de boss para %s?"
L["Romulo"] = "Romulo" -- Requires localization
L["Romulo & Julianne"] = "Romulo & Julianne" -- Requires localization
L["Set DKP Pool to be primary DKP pool. Only pool if not using multiPool"] = "Set DKP Pool to be primary DKP pool. Only pool if not using multiPool" -- Requires localization
L["Show minimap icon"] = "Show minimap icon" -- Requires localization
L["%s joined the raid at %s."] = "%s se unió a la raid a las %s."
L["%s left the raid at %s."] = "%s dejó la raid a las %s."
L["Son of Flame"] = "Son of Flame" -- Requires localization
L["Sorry your response format is incorrect or no item with that ID is up for bidding.  Format = mbid [ID/link] [%s/%s/%s/%s] [bid value]"] = "Sorry your response format is incorrect or no item with that ID is up for bidding.  Format = mbid [ID/link] [%s/%s/%s/%s] [bid value]" -- Requires localization
L["%s received %s for %s DKP"] = "%s recibió %s por %s DKP"
L["Start Raid"] = "Start Raid" -- Requires localization
L["Stay your arms! I yield!"] = "Stay your arms! I yield!" -- Requires localization
L["TAKE"] = "TAKE" -- Requires localization
L["TAKE text"] = "TAKE text" -- Requires localization
L["Text of MorgBid2 NEED button"] = "Text of MorgBid2 NEED button" -- Requires localization
L["Text of MorgBid2 OFFSPEC button"] = "Text of MorgBid2 OFFSPEC button" -- Requires localization
L["Text of MorgBid2 PASS button"] = "Text of MorgBid2 PASS button" -- Requires localization
L["Text of MorgBid2 TAKE button"] = "Text of MorgBid2 TAKE button" -- Requires localization
L["The Alliance falter. Onward to the Lich King!"] = "The Alliance falter. Onward to the Lich King!" -- Requires localization
L["The first kill goes to me! Anyone care to wager?"] = "The first kill goes to me! Anyone care to wager?" -- Requires localization
L["The halls of Karazhan shake, as the curse binding the doors of the Gamesman's Hall is lifted."] = "The halls of Karazhan shake, as the curse binding the doors of the Gamesman's Hall is lifted." -- Requires localization
L["The Legion's final conquest has begun! Once again the subjugation of this world is within our grasp. Let none survive!"] = "The Legion's final conquest has begun! Once again the subjugation of this world is within our grasp. Let none survive!" -- Requires localization
L["These are the hallmarks..."] = "These are the hallmarks..." -- Requires localization
L["The time is now! Leave none standing! "] = "The time is now! Leave none standing! " -- Requires localization
L["This item is not currently up for bid."] = "This item is not currently up for bid." -- Requires localization
L["Toggle LDB Plugin"] = "Toggle LDB Plugin" -- Requires localization
L["Toggle MorgDKP2"] = "Toggle MorgDKP2" -- Requires localization
L["Transeferred %s DKP to %s from %s"] = "Transeferred %s DKP to %s from %s" -- Requires localization
L["Transferred %s to %s for %s DKP."] = "Transferred %s to %s for %s DKP." -- Requires localization
L["Uncommon"] = "Uncommon" -- Requires localization
L["Unique"] = "Unique" -- Requires localization
L["Unique-equipped"] = "Unique-equipped" -- Requires localization
L["UNKNOWN"] = "UNKNOWN" -- Requires localization
L["Use earned DKP in the invite tablet (shift-click)."] = "Use earned DKP in the invite tablet (shift-click)." -- Requires localization
L["Use OFFSPEC"] = "Use OFFSPEC" -- Requires localization
L["WAIT"] = "WAIT" -- Requires localization
L["What devil art thou, that dost torment me thus?"] = "What devil art thou, that dost torment me thus?" -- Requires localization
L["Whispers all members (even if they have MorgBid2) so they can reply and bid using whispers."] = "Whispers all members (even if they have MorgBid2) so they can reply and bid using whispers." -- Requires localization
L["Whisper system"] = "Whisper system" -- Requires localization
L["World Boss"] = "World Boss" -- Requires localization
L["xINRAIDx"] = "xINRAIDx" -- Requires localization
L["xWAITx"] = "xWAITx" -- Requires localization
L["You are defenders of a doomed world! Flee here, and perhaps you will prolong your pathetic lives!"] = "You are defenders of a doomed world! Flee here, and perhaps you will prolong your pathetic lives!" -- Requires localization
L["You can not use this function out of a raid group."] = "You can not use this function out of a raid group." -- Requires localization
L["You may want to take cover."] = "You may want to take cover." -- Requires localization
L["You must start a raid before you can start a query."] = "You must start a raid before you can start a query." -- Requires localization
L["Your response has been accepted: %s"] = "Your response has been accepted: %s" -- Requires localization
L["You will not defeat the Assembly of Iron so easily, invaders!"] = "You will not defeat the Assembly of Iron so easily, invaders!" -- Requires localization
L.BidWar = {
	["Beginning auction for %s:  ID = %s"] = "Beginning auction for %s:  ID = %s", -- Requires localization
	["Bidding is now closed."] = "Bidding is now closed.", -- Requires localization
	["Bid Format = mbid [ID/link] [%s/%s/%s] [bid value]"] = "Bid Format = mbid [ID/link] [%s/%s/%s] [bid value]", -- Requires localization
	Bidstep = "Bidstep", -- Requires localization
	BidWar = "BidWar", -- Requires localization
	["BidWar mode changes the MorgBid query to allow players to bid on items.  Also the MorgDKP tablet uses bids after this NOT member DKP."] = "BidWar mode changes the MorgBid query to allow players to bid on items.  Also the MorgDKP tablet uses bids after this NOT member DKP.", -- Requires localization
	["BidWar Options"] = "BidWar Options", -- Requires localization
	["Changes the DKP step for BidWar mode.  Passes this value to MorgBid2 clients."] = "Changes the DKP step for BidWar mode.  Passes this value to MorgBid2 clients.", -- Requires localization
	["Enable BidWar mode where the winner is charged the 2nd highest bid value for the item."] = "Enable BidWar mode where the winner is charged the 2nd highest bid value for the item.", -- Requires localization
	["Enable BidWar mode with only one round of bidding and no reporting to raid chat."] = "Enable BidWar mode with only one round of bidding and no reporting to raid chat.", -- Requires localization
	["Just enough"] = "Just enough", -- Requires localization
	["Maximum amount of DKP that members can exceed their current DKP."] = "Maximum amount of DKP that members can exceed their current DKP.", -- Requires localization
	["New high bidder for %s: %s = %s"] = "New high bidder for %s: %s = %s", -- Requires localization
	Overbid = "Overbid", -- Requires localization
	["Silent auction"] = "Silent auction", -- Requires localization
	["Sorry this is a silent auction and you have already placed your bid."] = "Sorry this is a silent auction and you have already placed your bid.", -- Requires localization
	["You have exceeded the overbid amount of %s.  Your bid has been reset to the maximum."] = "You have exceeded the overbid amount of %s.  Your bid has been reset to the maximum.", -- Requires localization
}
L.DKPovertime = {
	["Added %s DKP to %s attendees."] = "Añadidos %s DKP a %s asistentes",
	["Award amount"] = "Award amount", -- Requires localization
	["Award time"] = "Award time", -- Requires localization
	["DKP/time"] = "DKP/time", -- Requires localization
	["DKP/time event name"] = "DKP/time event name", -- Requires localization
	["DKP/time Options"] = "DKP/time Options", -- Requires localization
	["DKP/time system which allows you to award DKP at custom intervals."] = "DKP/time system which allows you to award DKP at custom intervals.", -- Requires localization
	[ [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=] ] = [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=], -- Requires localization
	["Time in minutes between DKP awards."] = "Time in minutes between DKP awards.", -- Requires localization
}
L.Eventnaming = {
	["Allows you to change the default format for event names."] = "Allows you to change the default format for event names.", -- Requires localization
	["Boss format"] = "Boss format", -- Requires localization
	Default = "Default", -- Requires localization
	Enable = "Enable", -- Requires localization
	["Event naming"] = "Event naming", -- Requires localization
	[ [=[Format of boss event names:  
<zone> - <boss>
Example:  <boss> <diff>]=] ] = [=[Format of boss event names:  
<zone> - <boss>
Example:  <boss> <diff>]=], -- Requires localization
	[ [=[Format of run event name:  
<zone> text  
Example:  <zone> <diff> Run]=] ] = [=[Format of run event name:  
<zone> text  
Example:  <zone> <diff> Run]=], -- Requires localization
	[ [=[Format of start event name:  
<zone> text  
Example:  <zone> <diff> Start]=] ] = [=[Format of start event name:  
<zone> text  
Example:  <zone> <diff> Start]=], -- Requires localization
	["Reset default values."] = "Reset default values.", -- Requires localization
	["Run format"] = "Run format", -- Requires localization
	["Start format"] = "Start format", -- Requires localization
	["Toggle event naming"] = "Toggle event naming", -- Requires localization
}
L.FixedDKP = {
	["DKP TAKE/OFFSPEC settings"] = "DKP TAKE/OFFSPEC settings", -- Requires localization
	Enable = "Enable", -- Requires localization
	["Enable OFFSPEC"] = "Enable OFFSPEC", -- Requires localization
	["Enables mode where members are charged a standard price for OFFSPEC items."] = "Enables mode where members are charged a standard price for OFFSPEC items.", -- Requires localization
	["Enables mode where members are charged a standard price for TAKE items."] = "Enables mode where members are charged a standard price for TAKE items.", -- Requires localization
	["Enable TAKE"] = "Enable TAKE", -- Requires localization
	["Fixed DKP"] = "Fixed DKP", -- Requires localization
	["OFFSPEC Percent"] = "OFFSPEC Percent", -- Requires localization
	["OFFSPEC value"] = "OFFSPEC value", -- Requires localization
	["Standard DKP system."] = "Standard DKP system.", -- Requires localization
	["TAKE Percent"] = "TAKE Percent", -- Requires localization
	["TAKE value"] = "TAKE value", -- Requires localization
	["Use percent of item value for OFFSPEC mode."] = "Use percent of item value for OFFSPEC mode.", -- Requires localization
	["Use percent of item value for TAKE mode."] = "Use percent of item value for TAKE mode.", -- Requires localization
}
L.Lootframe = {
	Alt = "Alt", -- Requires localization
	["Always use"] = "Always use", -- Requires localization
	["Always use the MorgDKP2 loot window even when the mod is in standby mode."] = "Always use the MorgDKP2 loot window even when the mod is in standby mode.", -- Requires localization
	["|c000070ddClick:|r allocate randomly"] = "|c000070ddClick:|r allocate randomly", -- Requires localization
	["|c000070ddClick:|r Announce winner."] = "|c000070ddClick:|r Announce winner.", -- Requires localization
	["|c000070ddClick:|r give item to disenchanter"] = "|c000070ddClick:|r give item to disenchanter", -- Requires localization
	["|c000070ddClick:|r give this item to disenchanter."] = "|c000070ddClick:|r give this item to disenchanter.", -- Requires localization
	[ [=[|c000070ddClick:|r loot item
|c000070ddR-Click:|r open itemdata or roll frame
|c000070ddAlt-R-Click:|r start all queries]=] ] = [=[|c000070ddClick:|r loot item
|c000070ddR-Click:|r open itemdata or roll frame
|c000070ddAlt-R-Click:|r start all queries]=], -- Requires localization
	["|c000070ddClick:|r select pool to use for item."] = "|c000070ddClick:|r select pool to use for item.", -- Requires localization
	["|c000070ddClick:|r self loot"] = "|c000070ddClick:|r self loot", -- Requires localization
	[ [=[|c000070ddClick:|r start item query.
|c000070ddAlt-Click:|r start all queries
|c000070ddShift-Click:|r random query for this item
|c000070ddCtrl-Click:|r ignore this item]=] ] = [=[|c000070ddClick:|r start item query.
|c000070ddAlt-Click:|r start all queries
|c000070ddShift-Click:|r random query for this item
|c000070ddCtrl-Click:|r ignore this item]=], -- Requires localization
	["|c000070ddClick:|r stop this item query."] = "|c000070ddClick:|r stop this item query.", -- Requires localization
	[ [=[|c000070ddMousewheel up/Click|r - Increase value.
|c000070ddMousewheel down/R-Click|r - decrease value.
|c000070ddSHIFT|r - change value by +/-1
|c000070ddALT|r - change value by +/-20
|c000070ddCTRL|r - change value by +/-100]=] ] = [=[|c000070ddMousewheel up/Click|r - Increase value.
|c000070ddMousewheel down/R-Click|r - decrease value.
|c000070ddSHIFT|r - change value by +/-1
|c000070ddALT|r - change value by +/-20
|c000070ddCTRL|r - change value by +/-100]=], -- Requires localization
	Class = "Class", -- Requires localization
	["DKP: %s"] = "DKP: %s", -- Requires localization
	["Give %s to %s, are you sure?"] = "Give %s to %s, are you sure?", -- Requires localization
	Lootframe = "Lootframe", -- Requires localization
	["Lootframe scale"] = "Lootframe scale", -- Requires localization
	["Open lootframe at cursor postition"] = "Open lootframe at cursor postition", -- Requires localization
	["Replace Blizzard"] = "Replace Blizzard", -- Requires localization
	["%s awarded to %s"] = "%s awarded to %s", -- Requires localization
	["%s awarded to %s for %s DKP"] = "%s awarded to %s for %s DKP", -- Requires localization
	["Select primary class"] = "Select primary class", -- Requires localization
	["Select secondary class"] = "Select secondary class", -- Requires localization
	["Snap to cursor"] = "Snap to cursor", -- Requires localization
	["%s will be disenchanted in 5 seconds."] = "%s will be disenchanted in 5 seconds.", -- Requires localization
	["When MorgDKP2 is active it's loot frame will replace default."] = "When MorgDKP2 is active it's loot frame will replace default.", -- Requires localization
}
L.Percent = {
	["Items will cost a percentage of the members total DKP."] = "Los objetos costarán un porcentaje de los DKP totales de los miembros",
	["Percent cost"] = "Percent cost", -- Requires localization
	["Percent DKP"] = "Percent DKP", -- Requires localization
	["Percent DKP Options"] = "Percent DKP Options", -- Requires localization
	["Percent take"] = "Percent take", -- Requires localization
	["When using the percent DKP system this option enables TAKE looting.  This means if the winning member rolled TAKE he will not be charged x% DKP he will instead be charged the base price of the item (Set using original itempoints."] = "When using the percent DKP system this option enables TAKE looting.  This means if the winning member rolled TAKE he will not be charged x% DKP he will instead be charged the base price of the item (Set using original itempoints.", -- Requires localization
}
L.PointsDB = {
	["Added alias: %s of %s with %s DKP."] = "Added alias: %s of %s with %s DKP.", -- Requires localization
	["Addeded %s to item database."] = "Addeded %s to item database.", -- Requires localization
	["Added %s players from %s"] = "Added %s players from %s", -- Requires localization
	["Add ignored item"] = "Add ignored item", -- Requires localization
	["Add item"] = "Add item", -- Requires localization
	["Add new item to ignore.  Drag the item to this input box."] = "Add new item to ignore.  Drag the item to this input box.", -- Requires localization
	["Add new item to track.  Drag the item to this input box."] = "Add new item to track.  Drag the item to this input box.", -- Requires localization
	["Clear player DB"] = "Clear player DB", -- Requires localization
	["Clear raid DB"] = "Clear raid DB", -- Requires localization
	["Clears all items in the database below the selected item level."] = "Clears all items in the database below the selected item level.", -- Requires localization
	["Clears all members in the database inactive longer than the selected number of weeks."] = "Clears all members in the database inactive longer than the selected number of weeks.", -- Requires localization
	["Clears all players currently in the database. Does not affect items."] = "Clears all players currently in the database. Does not affect items.", -- Requires localization
	["Clears the current tracked raids."] = "Clears the current tracked raids.", -- Requires localization
	["Cull item DB"] = "Cull item DB", -- Requires localization
	["Cull item level"] = "Cull item level", -- Requires localization
	["Cull member DB"] = "Cull member DB", -- Requires localization
	["Cull member level (weeks)"] = "Cull member level (weeks)", -- Requires localization
	["Current rank weight"] = "Current rank weight", -- Requires localization
	["Database Functions"] = "Database Functions", -- Requires localization
	["Database transfer complete. %s items were transferred and %s members updated."] = "Database transfer complete. %s items were transferred and %s members updated.", -- Requires localization
	["Higher number for higher display priority. (7 will appear above 3 on the tooltip)"] = "Higher number for higher display priority. (7 will appear above 3 on the tooltip)", -- Requires localization
	["Ignored items"] = "Ignored items", -- Requires localization
	["Import database from MorgDKP?"] = "Import database from MorgDKP?", -- Requires localization
	["Import default item database?"] = "Import default item database?", -- Requires localization
	["Imported MorgDKP DB with %s players and %s items."] = "Imported MorgDKP DB with %s players and %s items.", -- Requires localization
	["List of currently ignored items.  Click to remove item from ignore list."] = "List of currently ignored items.  Click to remove item from ignore list.", -- Requires localization
	["List of member ranks in the current pool."] = "List of member ranks in the current pool.", -- Requires localization
	["Player database cleared!"] = "Player database cleared!", -- Requires localization
	["Player DKP reset to zero!"] = "Player DKP reset to zero!", -- Requires localization
	["Please delete the ItemData.lua file from the MorgDKP directory now."] = "Please delete the ItemData.lua file from the MorgDKP directory now.", -- Requires localization
	["Rank weights"] = "Rank weights", -- Requires localization
	["Removed %s items from the database."] = "Removed %s items from the database.", -- Requires localization
	["Removed %s members from the database."] = "Removed %s members from the database.", -- Requires localization
	["Resets all members DKP to zero."] = "Resets all members DKP to zero.", -- Requires localization
	["Updating DKP Points.."] = "Updating DKP Points..", -- Requires localization
	["Zero player DB"] = "Zero player DB", -- Requires localization
}
L.RaidTracker = {
	Add = "Añadir",
	["Alias Database"] = "Base de datos de alias",
	Aliases = "Alias",
	Alt = "Alt", -- Requires localization
	Attendees = "Asistentes",
	Class = "Clase",
	Close = "Cerrar",
	["Create new event"] = "Crear nuevo evento",
	["Current raid"] = "Raid actual",
	Delete = "Eliminar",
	["Delete Raid"] = "Eliminar Raid",
	["DKP Changes"] = "Cambios en DKP",
	Enable = "Activar",
	["Enter alias name"] = "Introduzca nombre del alias",
	["Enter DKP change amount"] = "Introducir cantidad de DKP del cambio",
	["Enter DKP change members"] = "Enter DKP change members", -- Requires localization
	["Enter event attendees"] = "Introduzca el nombre de los asistentes",
	["Enter event name"] = "Introduzca el nombre del evento",
	["Enter event note"] = "Enter event note", -- Requires localization
	["Enter event value"] = "Introduzca el valor del evento",
	["Enter item event"] = "Enter item event", -- Requires localization
	["Enter item value"] = "Introduzca el valor del objeto",
	["Enter item winner"] = "Introduzca el ganador del objeto",
	["Enter main name"] = "Enter main name", -- Requires localization
	Eventname = "Nombre del evento",
	Eventnote = "Eventnote", -- Requires localization
	["Export Raid"] = "Exportar Raid",
	Group = "Grupo",
	Ignore = "Ignorar",
	["Item Database"] = "Base de datos de objetos",
	["Item DB"] = "Item DB", -- Requires localization
	["Raid Editing"] = "Raid Editing", -- Requires localization
	Raids = "Raids",
	["Raid Tracker"] = "Raid Tracker", -- Requires localization
	["Raid Tracker for viewing and editing current raids."] = "Raid Tracker para ver y editar las raids actuales",
	["Select primary class"] = "Seleccione la clase principal",
	["Select secondary class"] = "Seleccione la clase secundaria",
	["Update attends"] = "Actualizar asistentes",
	Value = "Valor",
	["You can not remove the run event."] = "No puedes eliminar el evento Run",
}
L.Random = {
	["Enable random rolling for items."] = "Enable random rolling for items.", -- Requires localization
	["Random rolls"] = "Random rolls", -- Requires localization
	["%s received %s."] = "%s received %s.", -- Requires localization
}
L.Relational = {
	["Enable Relational DKP for calculating the earned/spent dkp ratio."] = "Enable Relational DKP for calculating the earned/spent dkp ratio.", -- Requires localization
	["Minimum amount of DKP a member can have for calculating the DKP ratio to avoid a new member having a high ratio. ie  200 earned DKP/ (this value)"] = "Minimum amount of DKP a member can have for calculating the DKP ratio to avoid a new member having a high ratio. ie  200 earned DKP/ (this value)", -- Requires localization
	["Minimum DKP base"] = "Minimum DKP base", -- Requires localization
	["Relational DKP"] = "Relational DKP", -- Requires localization
	["Relational DKP Options"] = "Relational DKP Options", -- Requires localization
}
L.SKSotC = {
	["Amount of DKP to remove from members who miss a raid."] = "Amount of DKP to remove from members who miss a raid.", -- Requires localization
	["Demotion event"] = "Demotion event", -- Requires localization
	["Enable Suicide Kings SotC variant DKP."] = "Enable Suicide Kings SotC variant DKP.", -- Requires localization
	[ [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=] ] = [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=], -- Requires localization
	["Missed raid DKP"] = "Missed raid DKP", -- Requires localization
	["SKSotC DKP"] = "SKSotC DKP", -- Requires localization
	["SKSotC Options"] = "SKSotC Options", -- Requires localization
}
L.SKall = {
	["Enable raid award"] = "Enable raid award", -- Requires localization
	["Enables DKP removed from item winner to be awarded to raid members.  You must check use zerosum on the import webscript for website DKP to be correct."] = "Enables DKP removed from item winner to be awarded to raid members.  You must check use zerosum on the import webscript for website DKP to be correct.", -- Requires localization
	["Enable Suicide Kings spend all DKP."] = "Enable Suicide Kings spend all DKP.", -- Requires localization
	["% Member DKP"] = "% Member DKP", -- Requires localization
	["Percent of member DKP to remove."] = "Percent of member DKP to remove.", -- Requires localization
	["SKall DKP"] = "SKall DKP", -- Requires localization
	["SKall Options"] = "SKall Options", -- Requires localization
}
L.Syncing = {
	["Accept DKP changes from other raid leaders."] = "Accept DKP changes from other raid leaders.", -- Requires localization
	["Added %s to listeners."] = "Added %s to listeners.", -- Requires localization
	Automatic = "Automatic", -- Requires localization
	["Automatically set broadcast/receive depending if you are the master looter."] = "Automatically set broadcast/receive depending if you are the master looter.", -- Requires localization
	Broadcast = "Broadcast", -- Requires localization
	["Broadcast DKP changes to other raid leaders."] = "Broadcast DKP changes to other raid leaders.", -- Requires localization
	Enable = "Enable", -- Requires localization
	["Immediate Sync Options"] = "Immediate Sync Options", -- Requires localization
	["Imported options...restarting."] = "Opciones importadas... reempezando",
	["Imported %s items"] = "Imported %s items", -- Requires localization
	["Import %s data from %s?"] = "Import %s data from %s?", -- Requires localization
	["Initial Sync"] = "Initial Sync", -- Requires localization
	["Items Sync"] = "Items Sync", -- Requires localization
	["Members Sync"] = "Members Sync", -- Requires localization
	["Options Sync"] = "Options Sync", -- Requires localization
	["Overwrite raid"] = "Overwrite raid", -- Requires localization
	["Overwrite the current raid if you receive an initial sync and are currently in a raid."] = "Overwrite the current raid if you receive an initial sync and are currently in a raid.", -- Requires localization
	Password = "Password", -- Requires localization
	Receive = "Receive", -- Requires localization
	["Removed %s from listeners."] = "Removed %s from listeners.", -- Requires localization
	["Resends initial sync.  Only needed in cases where you have problems as this is done automatically."] = "Resends initial sync.  Only needed in cases where you have problems as this is done automatically.", -- Requires localization
	["Send DB Sync"] = "Send DB Sync", -- Requires localization
	["Sends your current database of item DKP values."] = "Sends your current database of item DKP values.", -- Requires localization
	["Sends your current database of member DKP values."] = "Sends your current database of member DKP values.", -- Requires localization
	["Sends your current database of member DKP values, item values, and MorgDKP2 options to the current raid."] = "Sends your current database of member DKP values, item values, and MorgDKP2 options to the current raid.", -- Requires localization
	["Sends your current MorgDKP2 options.  Note will restart MorgDKP2 so do not send another sync until it restarts or use full sync and it will be handled properly."] = "Sends your current MorgDKP2 options.  Note will restart MorgDKP2 so do not send another sync until it restarts or use full sync and it will be handled properly.", -- Requires localization
	["%s's MorgDKP2 is out of date!"] = "%s's MorgDKP2 is out of date!", -- Requires localization
	["%s's password does not match your password!"] = "%s's password does not match your password!", -- Requires localization
	Syncing = "Syncing", -- Requires localization
	["Syncing password"] = "Syncing password", -- Requires localization
	["Syncing system for communicating DKP between raid leaders."] = "Syncing system for communicating DKP between raid leaders.", -- Requires localization
	["Updated %s members"] = "Updated %s members", -- Requires localization
}
L.TakeBid = {
	Bidstep = "Bidstep", -- Requires localization
	["Changes the DKP step for TakeBid mode.  Passes this value to MorgBid2 clients."] = "Changes the DKP step for TakeBid mode.  Passes this value to MorgBid2 clients.", -- Requires localization
	["Maximum amount of DKP that members can exceed their current DKP."] = "Maximum amount of DKP that members can exceed their current DKP.", -- Requires localization
	["Minimum amount of DKP that members can bid for an item."] = "Minimum amount of DKP that members can bid for an item.", -- Requires localization
	["Minimum bid"] = "Minimum bid", -- Requires localization
	Overbid = "Overbid", -- Requires localization
	["TakeBid DKP"] = "TakeBid DKP", -- Requires localization
	["TakeBid Options"] = "TakeBid Options", -- Requires localization
	["Variation of Fixed DKP where when you bid take you also enter what you are willing to pay."] = "Variation of Fixed DKP where when you bid take you also enter what you are willing to pay.", -- Requires localization
}
L.Tracker = {
	["and add these attendees < %s min?"] = "and add these attendees < %s min?", -- Requires localization
	["Attendance reward"] = "Attendance reward", -- Requires localization
	["Bank character"] = "Bank character", -- Requires localization
	CANCEL = "CANCEL", -- Requires localization
	["Clear the raid database?"] = "Clear the raid database?", -- Requires localization
	[ [=[Core of all MorgDKP2 raid tracking features. 
Can not be disabled.]=] ] = [=[Core of all MorgDKP2 raid tracking features. 
Can not be disabled.]=], -- Requires localization
	["CTRT format"] = "CTRT format", -- Requires localization
	["DKP Export"] = "DKP Export", -- Requires localization
	["DKP listener"] = "DKP listener", -- Requires localization
	["DKP Tracking"] = "DKP Tracking", -- Requires localization
	["DKP which new members to the database receive."] = "DKP which new members to the database receive.", -- Requires localization
	["End Raid"] = "End Raid", -- Requires localization
	["End %s"] = "End %s", -- Requires localization
	["Eqdkp+ event format"] = "Eqdkp+ event format", -- Requires localization
	["Events for DKP changes"] = "Events for DKP changes", -- Requires localization
	["Export Raids"] = "Export Raids", -- Requires localization
	["Exports current raid(s) data for import into website."] = "Exports current raid(s) data for import into website.", -- Requires localization
	["Finalizes the current raid."] = "Finalizes the current raid.", -- Requires localization
	["Format of new member DKP event name."] = "Format of new member DKP event name.", -- Requires localization
	["General options"] = "General options", -- Requires localization
	["Guildlaunch format"] = "Guildlaunch format", -- Requires localization
	["Minimum time to add member to raid and award run DKP."] = "Minimum time to add member to raid and award run DKP.", -- Requires localization
	["New member DKP event"] = "New member DKP event", -- Requires localization
	["New member start DKP"] = "New member start DKP", -- Requires localization
	NO = "NO", -- Requires localization
	["No current raid exists."] = "No current raid exists.", -- Requires localization
	["Opens the raidtracker interface."] = "Opens the raidtracker interface.", -- Requires localization
	["Previous best kill time: %s"] = "Previous best kill time: %s", -- Requires localization
	["Raid Tracker"] = "Raid Tracker", -- Requires localization
	["Remember kill times"] = "Remember kill times", -- Requires localization
	["Removed %s raid attendees."] = "Removed %s raid attendees.", -- Requires localization
	["Remove the ' character from any event names because eqdkp+ is dumb."] = "Remove the ' character from any event names because eqdkp+ is dumb.", -- Requires localization
	["Sartharion minibosses"] = "Sartharion minibosses", -- Requires localization
	["%s defeated in %s!"] = "%s defeated in %s!", -- Requires localization
	Shortcuts = "Shortcuts", -- Requires localization
	["Single run event"] = "Single run event", -- Requires localization
	["Sorry %s is an invalid database pool.  Please choose a correct one or export your DKP from your website."] = "Sorry %s is an invalid database pool.  Please choose a correct one or export your DKP from your website.", -- Requires localization
	["%s recorded at %s with %s attendees."] = "%s recorded at %s with %s attendees.", -- Requires localization
	["Start Event"] = "Start Event", -- Requires localization
	["Start Raid"] = "Start Raid", -- Requires localization
	["Starts a new raid."] = "Starts a new raid.", -- Requires localization
	["Store your best kill times for bosses."] = "Store your best kill times for bosses.", -- Requires localization
	["Trigger events for Sartharion minibosses."] = "Trigger events for Sartharion minibosses.", -- Requires localization
	["Use a bank character in raids."] = "Use a bank character in raids.", -- Requires localization
	["Use CTRT export format for raid exports."] = "Use CTRT export format for raid exports.", -- Requires localization
	["Use events for DKP changes instead of database adjustments."] = "Use events for DKP changes instead of database adjustments.", -- Requires localization
	["Use guildlaunch export format for raid exports."] = "Use guildlaunch export format for raid exports.", -- Requires localization
	["Use one event for entire raid.  Boss kills will not be tracked separately."] = "Use one event for entire raid.  Boss kills will not be tracked separately.", -- Requires localization
	["Use start event when raid begins."] = "Use start event when raid begins.", -- Requires localization
	["When you are in a tracked zone you will track DKP but you will not get the loot popup window or link to the raid.  You will act like a backup raidlog."] = "When you are in a tracked zone you will track DKP but you will not get the loot popup window or link to the raid.  You will act like a backup raidlog.", -- Requires localization
	YES = "YES", -- Requires localization
	["Yes & Add"] = "Yes & Add", -- Requires localization
}
L.Waitlist = {
	["Added %s to the waitlist."] = "Added %s to the waitlist.", -- Requires localization
	["Added you to the waitlist."] = "Added you to the waitlist.", -- Requires localization
	["Amount of DKP to reward after members have been on the waitlist for the current reward time."] = "Amount of DKP to reward after members have been on the waitlist for the current reward time.", -- Requires localization
	["Amount of DKP to reward at raidstart."] = "Amount of DKP to reward at raidstart.", -- Requires localization
	["Amount of DKP to reward to waitlist members per bosskill."] = "Amount of DKP to reward to waitlist members per bosskill.", -- Requires localization
	["Amount of DKP to reward to waitlist members when awarding regular members DKP/time. Note: only works if you are awarding DKP/time."] = "Amount of DKP to reward to waitlist members when awarding regular members DKP/time. Note: only works if you are awarding DKP/time.", -- Requires localization
	["Autochannel Spam"] = "Autochannel Spam", -- Requires localization
	["Award DKP"] = "Award DKP", -- Requires localization
	["Award DKP to current waitlist members"] = "Award DKP to current waitlist members", -- Requires localization
	Channels = "Channels", -- Requires localization
	["Channels to spam when starting invites."] = "Channels to spam when starting invites.", -- Requires localization
	["Clears the current wailist."] = "Clears the current wailist.", -- Requires localization
	["Clear Waitlist"] = "Clear Waitlist", -- Requires localization
	["Current waitlist: %s"] = "Current waitlist: %s", -- Requires localization
	Enable = "Enable", -- Requires localization
	["Event Names"] = "Event Names", -- Requires localization
	[ [=[Format of waitlist boss events:  
<boss> text  
Example:  <boss> Waitlist DKP]=] ] = [=[Format of waitlist boss events:  
<boss> text  
Example:  <boss> Waitlist DKP]=], -- Requires localization
	[ [=[Format of waitlist event names:  
<zone> text  
Example:  <zone> Waitlist DKP]=] ] = [=[Format of waitlist event names:  
<zone> text  
Example:  <zone> Waitlist DKP]=], -- Requires localization
	["Grace Period"] = "Grace Period", -- Requires localization
	["Minimum time before offline waitlist members will be removed."] = "Minimum time before offline waitlist members will be removed.", -- Requires localization
	["Minimum time to award run DKP to a waitlist member."] = "Minimum time to award run DKP to a waitlist member.", -- Requires localization
	["Now accepting tells for the waitlist.  Please whisper %s using this format:  mbid wait[+/-] [main]"] = "Now accepting tells for the waitlist.  Please whisper %s using this format:  mbid wait[+/-] [main]", -- Requires localization
	["Please log on to your main for an invite to the raid.  Whisper me when online."] = "Please log on to your main for an invite to the raid.  Whisper me when online.", -- Requires localization
	["Removed %s from wailist."] = "Removed %s from wailist.", -- Requires localization
	["Removed %s from waitlist due to inactivity"] = "Removed %s from waitlist due to inactivity", -- Requires localization
	["Removed you from the waitlist."] = "Removed you from the waitlist.", -- Requires localization
	["Spam channels automatically when opening the invite tablet."] = "Spam channels automatically when opening the invite tablet.", -- Requires localization
	["Spam channels with current waitlist."] = "Spam channels with current waitlist.", -- Requires localization
	["Spam channels with waitinfo now."] = "Spam channels with waitinfo now.", -- Requires localization
	["Spam Current"] = "Spam Current", -- Requires localization
	["Spam Waitinfo"] = "Spam Waitinfo", -- Requires localization
	["That main does not exist."] = "That main does not exist.", -- Requires localization
	Waitlist = "Waitlist", -- Requires localization
	["Waitlist allows members to whisper you for invites and to receive DKP even if not in the actual raid."] = "Waitlist allows members to whisper you for invites and to receive DKP even if not in the actual raid.", -- Requires localization
	["Waitlist boss DKP"] = "Waitlist boss DKP", -- Requires localization
	["Waitlist boss event name"] = "Waitlist boss event name", -- Requires localization
	["Waitlist DKP/time"] = "Waitlist DKP/time", -- Requires localization
	["Waitlist event name"] = "Waitlist event name", -- Requires localization
	["Waitlist reward"] = "Waitlist reward", -- Requires localization
	["Waitlist run DKP"] = "Waitlist run DKP", -- Requires localization
	["Waitlist spamming"] = "Waitlist spamming", -- Requires localization
	["Waitlist start DKP"] = "Waitlist start DKP", -- Requires localization
}
L.Whisper = {
	Enable = "Enable", -- Requires localization
	["%s: ID = %s  DKP/Bid value = %s  (Reply format: mbid ID [%s/%s/%s/%s bid value])"] = "%s: ID = %s  DKP/Bid value = %s  (Reply format: mbid ID [%s/%s/%s/%s bid value])", -- Requires localization
	["Whispers all members (even if they have MorgBid) so they can reply and bid using whispers."] = "Whispers all members (even if they have MorgBid) so they can reply and bid using whispers.", -- Requires localization
	["Whisper system"] = "Whisper system", -- Requires localization
}
L.Zerosum = {
	["Added %s DKP to %s attendees."] = "Añadidos %s DKP a %s asistentes",
	["DKP award event name"] = "DKP award event name", -- Requires localization
	[ [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=] ] = [=[Format of event name:  
<zone> text  
Example:  <zone> DKP]=], -- Requires localization
	["Include waitlist"] = "Include waitlist", -- Requires localization
	["Include waitlist members in DKP calculations.  Note they will still get whatever DKP award is set in the waitlist module."] = "Include waitlist members in DKP calculations.  Note they will still get whatever DKP award is set in the waitlist module.", -- Requires localization
	["Standard zero sum system where member is charged for the item and the charged points are divided between all raid members.  You must check use zerosum on the import webscript for website DKP to be correct."] = "Standard zero sum system where member is charged for the item and the charged points are divided between all raid members.  You must check use zerosum on the import webscript for website DKP to be correct.", -- Requires localization
	["Zerosum DKP"] = "Zerosum DKP", -- Requires localization
	["Zerosum Options"] = "Zerosum Options", -- Requires localization
}

