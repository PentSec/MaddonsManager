local mdkp = MorgDKP2

local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local media = LibStub("LibSharedMedia-3.0", true)
local dewvalidate = {}
local dewmulti = nil
local dewdbvalue = nil
	
mdkp.modulePrototype = {}

function mdkp.modulePrototype:CoreStatus()
	return mdkp.db.profile.moduleON.CoreModule
end

function mdkp.modulePrototype:GetPool()
	return mdkp.db.profile.raid
end

function mdkp.modulePrototype:debug(message)
	if mdkp.db.profile.devmode and mdkp.db.profile.moduleON["CoreModule"] then
		mdkp:Print(message)
	end
end

function mdkp.modulePrototype:out(message)
	if message then
		DEFAULT_CHAT_FRAME:AddMessage(message)
	end
end

--returns the module object
function mdkp.modulePrototype:GetModuleRef(mod)
	local modref
	if mdkp.db.profile.moduleON[mod] then
		modref = MorgDKP2:GetModule(mod, true)
	end
	return modref
end

function mdkp.modulePrototype:GetRaidModuleRef(raidid)
	local dkp 
	if raidid then dkp = mdkp.db.profile.raidlog[raidid].dkptype end
	if not dkp then dkp = mdkp.db.profile.currDKP end
	local currDKP = MorgDKP2:GetModule(dkp, true)
	local _, ref = currDKP:GetName()
	return currDKP, ref
end

function mdkp.modulePrototype:IsDKPEnabled()
	if not mdkp.db.profile.currDKP then
		self:debug("No current DKP set!  Automatically loading FixedDKP.")
		self:DKPChange(L["Fixed DKP"])
	end 
end

--sets loot method ML etc 
function mdkp.modulePrototype:GetCurrentLootMethod()
	local lootmethod, masterlooterPartyID, masterlooterRaidID = GetLootMethod()
   	local lootmaster
   	if lootmethod == "master" then
   		if masterlooterPartyID then
   			if masterlooterPartyID == 0 then 
   				lootmaster = UnitName("player")
   				mdkp.db.profile.dkplistener = nil
   			else  
   				lootmaster = UnitName("party"..masterlooterPartyID) 
   				mdkp.db.profile.dkplistener = true
   			end
   		else 
   			lootmaster = UnitName("raid"..masterlooterRaidID)
   			mdkp.db.profile.dkplistener = true
   		end
   		mdkp.db.profile.mlooter = lootmaster
   		mdkp.lootmaster = lootmaster
   	else 
   		mdkp.db.profile.mlooter = lootmethod
   		mdkp.db.profile.dkplistener = true
  	end
  	mdkp.db.profile.lootthreshold = GetLootThreshold()
  	mdkp.db.profile.instancedifficulty = self:GetDifficulty()
  	if mdkp.db.profile.moduleON["Syncing"] then
  		local sync = self:GetModuleRef("Syncing")
  		if sync then sync:ToggleSyncOptions() end
  	end
  	self:ToggleFrameUpdate("TooltipLDB", true)
end

function mdkp.modulePrototype:GetDifficulty()
	local _, _, difficultyIndex, _, maxPlayers, dynamicHeroic, isDynamic = GetInstanceInfo()
	if maxPlayers == 0 then return GetRaidDifficulty()
	else return (isDynamic and (2-(difficultyIndex%2)+2*dynamicHeroic)) or difficultyIndex
	end
end

function mdkp.modulePrototype:ValidRaid()
	if not mdkp.db.profile.InRaid or not UnitInRaid("Player") then return false end	
	return true
end

function mdkp.modulePrototype:IsRaided()
	if not UnitInRaid("player") then
		self:out(L["You can not use this function out of a raid group."])
		return true
	end
	return true
end

-- Code by Kaelten (split & explode)
function mdkp.modulePrototype:Split(string, sep)
	if (not string) then error("Bad String", 2) end
	local x = strfind(string , sep) or 0
	return (tonumber(strsub(string, 1, x-1)) or strsub(string, 1, x-1)), (tonumber(strsub(string, x+1)) or strsub(string, x+1))
end

function mdkp.modulePrototype:Explode(string, sep)
	if (not string) then return nil end
	local a, b = self:Split(string, sep)
	if (not b or b == "") then return a; end
	if (not strfind(b or "", sep)) then return a, b; end
	return a, self:Explode(b, sep)
end

function mdkp.modulePrototype:AttendtoArray(frame)
	local attends = {self:Explode(frame:GetText(), "\n")}
	local attendees = {}
	local added = {}
	local count = 1
	for i = 1, #attends do
		if attends[i] and attends[i] ~= "" and string.utf8len(attends[i]) > 1 then 
			attends[i] = string.utf8upper(string.utf8sub(attends[i],1,1))..string.utf8lower(string.utf8sub(attends[i],2,-1))
			if not added[attends[i]] then
				attendees[count] = attends[i] 
				added[attends[i]] = true
				count = count + 1
			end
		end
	end
	table.sort(attendees)
	return attendees
end

function mdkp.modulePrototype:ArraytoString(array)
	local attend = ""
	if not array then return nil end
	if #array > 1 then
		table.sort(array)
		for _, name in pairs(array) do
			attend = attend .. name .."\n"
		end
	else attend = array[1] end
	return attend
end

function mdkp.modulePrototype:GetServerTime()
	--get UTC time
	return date("%Y%m%d%H%M%S")
end

function mdkp.modulePrototype:PlayerinDB(playname, playclass)
	local db = mdkp.db.profile
	if not db.info[playname] then
		db.info[playname] = { }
		db.info[playname][db.raid] = {points = 0, earned = 0, spent = 0}
		db.info[playname].raidloot = 0
		db.info[playname].lastupdate = self:GetServerTime()
		if mdkp.db.profile.newdkp ~= 0 then 
			if not db.raidlog.new then db.raidlog.new = {} end
			table.insert(db.raidlog.new, playname)
		end
	end
	if not db.info[playname].aliases then db.info[playname].aliases = { } end
	if playclass and not db.info[playname].class then
		db.info[playname].class = playclass
		db.info[playname].lastupdate = self:GetServerTime()
	end
end

function mdkp.modulePrototype:AddNewMemberDKPChange(attendees)
	local db = mdkp.db.profile
	local raidnum = db.raidnum
	local event = db.newdkpname
	local value = db.newdkp
	local index
	local sync = self:GetModuleRef("Syncing")
	if db.dkpevents then
		index = self:GetCorrectRaidEvent(raidnum, event, event, value) 
		if index then 
			for _, name in pairs(attendees) do
				name = self:CheckforAlias(name)
				if not self:InTable(name, db.raidlog[raidnum].bosskills[index].attendees) then
					table.insert(db.raidlog[raidnum].bosskills[index].attendees, name)
					self:AwardDKP(nil, value, db.raid, {[1] = name})
				end
			end
		end
	end
	if not index then
		local tracker = self:GetModuleRef("RaidTracker")
		tracker:ProcessDKPChange(event, value, attendees, db.raid)
	end
	
	--add change to sync
	if sync then sync:DKPChangeSync(event, attendees, value, db.raid) end
end

function mdkp.modulePrototype:InTable(value, table)
	for index, data in pairs(table) do
		if data == value then 
			return true 
		end
	end
	return nil
end

function mdkp.modulePrototype:CopyTable(table1, table2)
	for index, data in pairs(table1) do
		table2[index] = data
	end
end

function mdkp.modulePrototype:IteminDB(item)
	local db = mdkp.db.profile
	if not db.items[item] then db.items[item] = {points = 0, classes = 0, altclasses = 0 } end
	if not db.items[item].points then db.items[item].points = 0 end
	--if not db.items[item].pool then db.items[item].pool = db.raid end
end

function mdkp.modulePrototype:GetCorrectRaidEvent(raidnum, event, note, value, trash, attendees)
	self:debug("Get event index")
	local db = mdkp.db.profile
	local data
	for index = #db.raidlog[raidnum].bosskills, 1, -1 do
		data = db.raidlog[raidnum].bosskills[index]
		if (not event or (event and event == data.name)) and (not note or (note and note == data.note)) and (not value or (value and value == data.value)) and (not trash or (trash and trash == data.trash)) then
			self:debug("Index="..index)
			return index
		end
	end
	return nil
end

function mdkp.modulePrototype:PointsPoolExists(playname, pool)
	local db = mdkp.db.profile
	self:PlayerinDB(playname)
	if not db.info[playname][pool] then
		db.info[playname][pool] = {points = 0, earned = 0, spent = 0}
		db.info[playname].lastupdate = self:GetServerTime()
	end
end

function mdkp.modulePrototype:CheckPool(item)
	local POOL = mdkp.db.profile.raid
	if mdkp.db.profile.multiPool then
		if mdkp.db.profile.items[item] then
			POOL = mdkp.db.profile.items[item].pool
		end
	end
	return POOL
end

--add classcolor to name if known or try get it manually if needed 
function mdkp.modulePrototype:GetClasscolors(name)
	local db = mdkp.db.profile
	if not name then return end
	local class, r, g, b = nil, 1, 1, 1
	if db.info[name] then
		if db.info[name].class then class = db.info[name].class
		else 
			_, class = UnitClass(name) 
			db.info[name].class = class
		end
	end
	if class and mdkp.ClasscolorsDEC[class] then r, g, b = mdkp.ClasscolorsDEC[class].r, mdkp.ClasscolorsDEC[class].g, mdkp.ClasscolorsDEC[class].b end
	return {n = name, c = class, r = r, g = g, b = b}
end

--[[create a simple frame for use
	name = non nil
	onenter = script or nil
	onleave = script or nil
	onupdate = script or nil
	onmouseup = script or nil
	hint = text or nil
	datacheck = toggle to check for data update (frame needs updating)
	datasource = pointer to data frame displays
	parent = parentframe for dewdrops
	title = header or nil
	ondragstart = script or nil
	ondragstop = script or nil
	hasscrollframe = true or nil
]]--

function mdkp.modulePrototype:Createframe(name, onenter, onleave, onupdate, onmouseup, hint, datacheck, datasource, parent, title, ondragstart, ondragstop, hasscrollframe)
	local f = {}
	local db = mdkp.db.profile
	local font = media:Fetch("font", db.media.font)
	f = CreateFrame("Frame", name, UIParent)
	f.textid = 1
	f.textlen = 0
	f.height = 0
	f.text = {}
	f.datacheck = datacheck
	f.datasource = datasource
	f.parent = parent
	f.scrollpresent = hasscrollframe
	if datacheck then self:ToggleFrameUpdate(datacheck, true) end
	f:SetFrameStrata("MEDIUM")
   	f:EnableMouse(1)
   	f:SetMovable(1)
   	f:RegisterForDrag("LeftButton")
   	f:ClearAllPoints()
  	f:SetScale(db.media.scale)
  	
  	if onenter then f:SetScript("OnEnter", onenter) end
  	if onleave then f:SetScript("OnLeave", onleave) end
  	if onupdate then f:SetScript("OnUpdate", onupdate) end
  	if onmouseup then f:SetScript("OnMouseUp", onmouseup) end
  	if ondragstart then 
  		f:SetScript("OnDragStart", ondragstart) 
  	end
  	if ondragstop then f:SetScript("OnDragStop", ondragstop) end
  	
  	if title then
  		f.title = f:CreateFontString()
   		f.title:SetPoint("TOP", f, "TOP", 0, -5)
   		f.title:SetJustifyH("CENTER")
   		f.title:SetFont(font, db.media.fontsize + 1)
   		f.title:SetTextColor(unpack(db.media.borderC))
   		f.title:SetText(title)
   		f.title:Show()
   	end
   	
	f.hint = f:CreateFontString()
   	f.hint:SetPoint("BOTTOM", f, "BOTTOM", 3, 5)
   	f.hint:SetJustifyH("LEFT")
   	f.hint:SetFont(font, db.media.fontsize)
   	f.hint:SetTextColor(0, 0.819, 0.0)
   	if hint then 
   		f.hint:SetText(hint)
   		f.hint:Show()
   	end
   	
   	if hasscrollframe then
   		f.scroll = CreateFrame("ScrollFrame", nil, f)
   		f.scroll:EnableMouse(1)
   		f.scroll:ClearAllPoints()
   		f.scroll:EnableMouseWheel(1)
   		f.scroll:SetPoint("TOP", f.title, "BOTTOM", 0, -5)
   		f.scroll:SetBackdrop({ bgFile = "", tile = false, tileSize = 16, edgeFile = media:Fetch("border", db.media.border), edgeSize = 8, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
		f.scroll:SetBackdropBorderColor(0, 0, 0, 1)
		f.scroll.text = {}
   		f.scroll.textid = 1
		f.scroll.textlen = 0
		f.scroll.height = 0
   	end
   	
	f:SetBackdrop({ bgFile = media:Fetch("background", db.media.background), tile = false, tileSize = 16, edgeFile = media:Fetch("border", db.media.border), edgeSize = 8, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
	f:SetBackdropColor(unpack(db.media.backdropC))
	f:SetBackdropBorderColor(unpack(db.media.borderC))
	return f
end

--[[add a single/double/triple text line to any frame
	f = frame - required
	onclick = script or nil
	t1 = left text - required
	t2 = right text
	t3 = center text
	typeid = toggle or nil
	icon = icon
	checked = item is selected
	disabled = unselectable
	onenter = script or nil
	onleave = script or nil
	
]]--

function mdkp.modulePrototype:AddTextLine(f, onclick, t1, t2, t3, typeid, icon, checked, disabled, onenter, onleave)
	local db = mdkp.db.profile
	local id = f.textid or 1
	local attach, relpoint, top
	local t2width = 0
	local t3width = 0
	local iconwidth = 0
	local addwidth = 30
	local font = media:Fetch("font", db.media.font) 
	local height = db.media.fontsize
	local r1, g1, b1 = unpack(db.media.fontC)
	local r2, g2, b2 = unpack(db.media.fontC)
	local r3, g3, b3 = unpack(db.media.fontC)
	if type(t1) == "table" then t1, r1, g1, b1 = t1.n, t1.r, t1.g, t1.b end
	if type(t2) == "table" then t2, r2, g2, b2 = t2.n, t2.r, t2.g, t2.b end
	if type(t3) == "table" then t3, r3, g3, b3 = t3.n, t3.r, t3.g, t3.b end
	if id == 1 then 
		attach = f
		relpoint = "TOPLEFT"
		if f.title then	
			local titleheight = f.title:GetStringHeight() + 5
			top = -titleheight
			f.height = f.height + titleheight	
		else top = -5 end
	else 
		attach = f.text[id-1]
		relpoint = "BOTTOMLEFT"
		top = 0
	end
	if not f.text[id] then 
		f.text[id] = CreateFrame("Button", nil, f) 
		f.text[id]:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
   		f.text[id]:ClearAllPoints()
   		f.text[id]:SetPoint("TOPLEFT", attach, relpoint, 0 , top)
   		f.text[id]:SetFrameStrata(f:GetFrameStrata())
   		f.text[id]:SetBackdropColor(0, 0, 0, 1)
	end
	f.text[id]:SetID(id)
	f.text[id].type = typeid
	f.text[id].disabled = disabled
	f.text[id]:SetScript("OnEnter", function(f) f:GetParent():Show() end)
   	if onclick and not disabled then
   		f.text[id]:SetScript("OnClick", onclick)
   		if disabled then 
   			f.text[id]:Disable()
   		else 
   			f.text[id]:Enable()
   		end
   	end
   	if onenter or onleave then
   		f.text[id]:SetScript("OnEnter", onenter)
   		f.text[id]:SetScript("OnLeave", onleave)
   	end
   	f.text[id]:Show()
   	
   	local offset = 5
   	if icon then	--thanks ck for code
   		iconframe = CreateFrame("Button", nil, f.text[id])
		iconframe:SetFrameStrata(f:GetFrameStrata())
		iconframe:SetHeight(height)
		local highlight = iconframe:CreateTexture(nil, "BACKGROUND")
		highlight:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
		iconframe.highlight = highlight
		highlight:SetBlendMode("ADD")
		highlight:SetAllPoints(iconframe)
		highlight:Hide()
		local check = iconframe:CreateTexture(nil, "ARTWORK")
		iconframe.check = check
		check:SetTexture(icon)
		check:ClearAllPoints()
		check:SetPoint("LEFT", f.text[id], "LEFT", 3, 0)
		check:SetWidth(height)
		check:SetHeight(height)
		f.text[id].icon = iconframe
		if icon == "Interface\\Buttons\\UI-RadioButton" then
			if checked then
				f.text[id].icon.check:SetTexCoord(0.25, 0.5, 0, 1)
				f.text[id].icon.check:SetVertexColor(1, 1, 1, 1)
			else
				f.text[id].icon.check:SetTexCoord(0, 0.25, 0, 1)
				f.text[id].icon.check:SetVertexColor(1, 1, 1, 0.5)
			end
		elseif icon == "Interface\\Buttons\\UI-CheckBox-Check" then
			if checked then	f.text[id].icon.check:SetVertexColor(1, 1, 1, 1)
			else f.text[id].icon.check:SetVertexColor(1, 1, 1, 0) end
		end
		f.text[id].icon:Show()
		iconwidth = 12 + height - 8
		offset = iconwidth
	end
	
	if not f.text[id].text1 then
		f.text[id].text1 = f.text[id]:CreateFontString()
   		f.text[id].text1:SetPoint("LEFT", f.text[id], "LEFT", offset, 0)
   		f.text[id].text1:SetJustifyH("LEFT")
   		f.text[id].text1:SetFont(font, db.media.fontsize)
   	end
   	f.text[id].text1:SetTextColor(r1, g1, b1)
   	f.text[id].text1:SetText(t1 or "")
   	f.text[id].text1:Show()
   	
   	if t3 then
   		if not f.text[id].text3 then
   			f.text[id].text3 = f.text[id]:CreateFontString()
   			f.text[id].text3:SetPoint("CENTER", f.text[id], "CENTER")
   			f.text[id].text3:SetJustifyH("CENTER")
   			f.text[id].text3:SetFont(font, db.media.fontsize)
   		end
   		f.text[id].text3:SetTextColor(r3, g3, b3)
   		f.text[id].text3:SetText(t3)
   		f.text[id].text3:Show()
   		t3width = f.text[id].text3:GetStringWidth()
   		addwidth = addwidth + 25
   	end
   	
   	if t2 then
   		if not f.text[id].text2 then
   			f.text[id].text2 = f.text[id]:CreateFontString()
   			f.text[id].text2:SetPoint("RIGHT", f.text[id], "RIGHT")
   			f.text[id].text2:SetJustifyH("RIGHT")
   			f.text[id].text2:SetFont(font, db.media.fontsize)
   		end
   		f.text[id].text2:SetTextColor(r2, g2, b2)
   		f.text[id].text2:SetText(t2)
   		f.text[id].text2:Show()
   		t2width = f.text[id].text2:GetStringWidth()
   	end
   	
   	local width = f.text[id].text1:GetStringWidth() + t2width + t3width + iconwidth + addwidth
   	if t3width == 0 then width = width + 5 end
   	if width > f.textlen then f.textlen = width end
   	f.textid = f.textid + 1
   	f.height = f.height + height
   	f.text[id]:SetHeight(height)
end

--[[update any scrollframe
	f = frame (actual scrollframe NOT parent)
	numitems = number of items total in dataset
	maxitems = max to display
	data = dataset
	direction = scroll direction (-1 or 1)
	functype = name of passing function
]]--
function mdkp.modulePrototype:Scrollframe_Update(f, numitems, maxitems, data, direction, functype, dewtype, dewdbvalue, dewframe, dewolddata)
	local line
	local lineplusoffset
	local change = 1
	local offset = floor(f:GetVerticalScroll() + 0.5)
	if IsControlKeyDown() then
		if direction == 1 then offset = 0
		elseif direction == -1 then offset = numitems - maxitems end
	else
		if IsShiftKeyDown() then change = 10 end
		if direction == -1 then offset = offset + change
		elseif direction == 1 then offset = offset - change end
	end
	if offset < 0 then offset = 0 
	elseif offset > (numitems - maxitems) then offset = numitems - maxitems end
	f:SetVerticalScroll(offset)
	for line = 1, maxitems do
		lineplusoffset = line + offset
		if lineplusoffset <= numitems then
			local value = data[lineplusoffset]
			f.text[line].text1:SetText(value[1].n)
			f.text[line].text1:SetTextColor(value[1].r, value[1].g, value[1].b)
			if functype ~= "dewframe" then
				local BIDdata = value[2]
				if type(BIDdata) ~= "table" then BIDdata = mdkp.defaultstatustext[value[2]] end
				f.text[line].text2:SetText(value[3].n)
				f.text[line].text2:SetTextColor(value[3].r, value[3].g, value[3].b)
				f.text[line].text3:SetText(BIDdata.n)
				f.text[line].text3:SetTextColor(BIDdata.r, BIDdata.g, BIDdata.b)
			else
				f.text[line].icon.check:SetTexture(value[1].i)
				f.text[line]:SetID(lineplusoffset)
				if value[1].i == "Interface\\Buttons\\UI-RadioButton" then
					if value[1].check then
						f.text[line].icon.check:SetTexCoord(0.25, 0.5, 0, 1)
						f.text[line].icon.check:SetVertexColor(1, 1, 1, 1)
					else
						f.text[line].icon.check:SetTexCoord(0, 0.25, 0, 1)
						f.text[line].icon.check:SetVertexColor(1, 1, 1, 0.5)
					end
				else
					if value[1].check then f.text[line].icon.check:SetVertexColor(1, 1, 1, 1)
					else f.text[line].icon.check:SetVertexColor(1, 1, 1, 0) end
				end
				local width = f.text[line].text1:GetStringWidth()
				if width > f.textlen then 
					f.textlen = width 
					f.text[line].text1:SetWidth(width)
					f:SetWidth(width)
				end
			end
			local onclick, onenter, onleave
			if functype then
				if functype == "rollframe" then
					onclick = function(f) self:OutputWinner(f:GetParent():GetID(), value[1].n) end
					onenter = function(f)
    							GameTooltip:SetOwner(f, "ANCHOR_LEFT")
    							self:ShowTooltip(f:GetParent():GetID(), value[1].n)	
    						end
    					onleave = function(f) GameTooltip:Hide() end
				elseif functype == "listdkp" then
					onclick = function(f) self:OnListDKPClick(value[1].n, value[2].n) end
					onenter = function(f)
    							GameTooltip:SetOwner(f, "ANCHOR_LEFT")
    							self:ShowAliasTip(value[1].n)	
    						end
    					onleave = function(f) GameTooltip:Hide() end
				elseif functype == "version" then
					onclick = function(f) self:WhisperUsers() end
				elseif functype == "dewframe" then
					onclick = function(f) self:Activatedewoption(dewframe, f:GetID(), dewolddata, dewtype, dewdbvalue) end
				end
    				f.text[line]:SetScript("OnClick", onclick) 
				f.text[line]:SetScript("OnEnter", onenter) 
				f.text[line]:SetScript("OnLeave", onleave) 
			end
			f.text[line]:Show()
		else
			if f.text[line] then f.text[line]:Hide() end
		end
	end
end

--determine if frame needs an update
function mdkp.modulePrototype:FrameUpdate(f)
	if mdkp.updatedata[f.datacheck] then
		--frame needs updated
		mdkp.updatedata[f.datacheck] = nil
		if f.datacheck == "TooltipLDB" then
			--LDB tooltip update
			self:Updatetooltipdata(f)
		else
			--normal datatooltip update
			self:debug(f.datacheck.." update")
			self:UpdateFrameData(f)
		end
	end
end

--sort generic frames data
function mdkp.modulePrototype:SortFrameData(f) 
	local framename = f.datacheck
	if framename == "version" then
		table.sort(mdkp.querytooltips[framename], function(a,b)
    			if  a[4] == b[4] then
    				if a[3].n == b[3].n then
    					return a[1].n < b[1].n
    				else
    					return a[3].n > b[3].n
				
				end
			else
				return  a[4] > b[4]
			end
		end)
	else 
		local qso = {[L["ONLINE"]] = 3, [L["OFFLINE"]] = 2, [L["INRAID"]] = 8, [L["xINRAIDx"]] = 7, [L["UNKNOWN"]] = 1,	["<AFK>"] = 6, [L["WAIT"]] = 5, [L["xWAITx"]] = 4}
		table.sort(mdkp.querytooltips[framename], function(a,b)
    			local ao = qso[a[2].n]
    			local bo = qso[b[2].n]
    			if ao == bo then
    				if type(a[3].n) == type(b[3].n) then
    					if a[3].n == b[3].n then
    						return a[1].n < b[1].n
    					else
    						return a[3].n > b[3].n
					end
				end
			else return ao > bo
			end
		end)
	end
end

--update generic frames (with scrollframe)
function mdkp.modulePrototype:UpdateFrameData(f) 
	self:SortFrameData(f)
	local db = mdkp.db.profile
	local framename = f.datacheck
	local sf = f.scroll
	local maxitems = 35
	local data, data2
	
	--clear frame
	for v = 1, sf.textid-1 do
    		sf.text[v]:Hide()
    	end
	sf.textid = 1
	sf.textlen = 0
	sf.height = 0
	
	--populate frame
	local sr, sg, sb = 1, 1, 1
	local numitems = #mdkp.querytooltips[framename]
	if numitems < maxitems then 
		maxitems = numitems 
		sr, sg, sb = 0, 0, 0
	end
	for i = 1, numitems do
		data = mdkp.querytooltips[framename][i]
		data2 = data[2]
		if type(data2) ~= "table" then data2 = mdkp.defaultstatustext[data2] end
		self:AddTextLine(sf, nil, data[1], data[3], data2)
		if i == maxitems then break end
	end
	
	--position frame
	local lineheight = 0
	if numitems ~= 0 then lineheight = sf.text[1]:GetHeight() end
	local width = sf.textlen + db.media.fontsize + 10
	if width < 150 then width = 150 end
	local height = lineheight * maxitems + 10
	sf:SetHeight(height)
	sf:SetWidth(width + 5)
	sf:SetBackdropBorderColor(sr, sg, sb, 1)
	f:SetWidth(width + 35)
	f:SetHeight(height + f.hint:GetHeight() + f.title:GetHeight() + 30)
	for v = 1, sf.textid-1 do
    		sf.text[v]:SetWidth(width)
    	end
	
	--update frame
	sf:SetScript("OnMouseWheel", function(f, direction) self:Scrollframe_Update(f, numitems, maxitems, mdkp.querytooltips[framename], direction, framename) end)
	self:Scrollframe_Update(sf, numitems, maxitems, mdkp.querytooltips[framename], nil, framename)
end

--update fubar/LDB tooltip
function mdkp.modulePrototype:Updatetooltipdata(f)
	for v = 1, f.textid-1 do
    		f.text[v]:Hide()
    		f.text[v] = nil
	end
	f.textid = 1
	f.textlen = 0
	f.height = 0
	f:Hide()
	local width
	if mdkp.db.profile.moduleON.CoreModule then 
		local db = mdkp.db.profile
		local MLstatustext = L["|c009d9d9dOFF|r"]
		local attstatus = L["PENDING..."]
		if mdkp.MLmode then MLstatustext = L["|c001eff00ON|r"] end
		local dkpstatus = db.dkpstatustext
		local tracker = mdkp:GetModule("Tracker", true)
		local added
		local onleave = function(f) if not MouseIsOver(f:GetParent()) and (not self.dewframe or (self.dewframe and not MouseIsOver(self.dewframe))) then f:GetParent():Hide() end end
		local onenter = function(f) f:GetParent():Show() end
		
		if db.raidnum ~= 0 and db.raidlog[db.raidnum] and db.raidlog[db.raidnum].loot and #db.raidlog[db.raidnum].loot ~= 0 then
			self:AddTextLine(f)
			for num, loot in pairs(db.raidlog[db.raidnum].loot) do
  				local name = self:GetClasscolors(loot.Player)
  				if loot.ItemLink and loot.Boss ~= "Bank" then
  					local onclick = function() self:TooltipLootClick(loot.ID, loot.ItemLink) end
  					local onenter = function(f) 
								GameTooltip:SetOwner(f, "ANCHOR_LEFT")
								if IsShiftKeyDown() then self:ShowBidSummary(loot.ID, loot.ItemName, loot.Quality, mdkp.db.profile.raidnum)
								else GameTooltip:SetHyperlink(loot.ItemLink) end
								GameTooltip:Show()
								f:GetParent():Show()
							end
					local onleave = function(f) 
								GameTooltip:Hide()
								if not MouseIsOver(f:GetParent()) then f:GetParent():Hide() end
							end
					self:AddTextLine(f, onclick, loot.ItemLink, name, nil, nil, loot.Icon, nil, nil, onenter, onleave)
					added = true
				end
			end
			if added then self:AddTextLine(f) end
		end
		
		local onclick = function(f) self:Opendewdrop(f, {"master", "group", "freeforall"}, f.type, "lootmethod") end
		self:AddTextLine(f, onclick, L["Master Looter"], self:GetClasscolors(db.mlooter), nil, nil, nil, nil, disabled, onenter, onleave)
		
		local onclick = function(f) self:Opendewdrop(f, db.raidmembers, f.type, "disenchanter", true) end
		self:AddTextLine(f, onclick, L["Disenchanter"], self:GetClasscolors(db.disenchanter), nil, nil, nil, nil, disabled, onenter, onleave)
		
		local onclick = function(f) self:ToggleML(f:GetParent()) end
		self:AddTextLine(f, onclick, L["ML/DE mode"], MLstatustext, nil, nil, nil, nil, disabled, onenter, onleave)
	
		local onclick = function(f) self:Opendewdrop(f, db.raidlist, f.type, "raid") end
		local r,g,b = 0, 1, 0
		if db.raid == L["NONE"] then r,g,b = 1,0,0 end
		local text = {n = db.raid, r = r, g = g, b = b} 
		self:AddTextLine(f, onclick, L["Main DKP Pool"], text, nil, nil, nil, nil, disabled, onenter, onleave)
	
		local onclick = function(f) self:Opendewdrop(f, mdkp.dkpmenu, f.type, "dkpstatustext") end
		self:AddTextLine(f, onclick, L["DKP System"], dkpstatus, nil, true, nil, nil, disabled, onenter, onleave)
	
		local onclick = function(f) self:Opendewdrop(f, mdkp.Quality, f.type, "quality") end
		self:AddTextLine(f, onclick, L["Quality Threshold"], mdkp.Quality[db.quality + 1], nil, nil, nil, nil, disabled, onenter, onleave)
	
		self:AddTextLine(f)
	
		local r,g,b = 0,1,0
		if db.raidstart == L["PENDING"] then r,g,b = 1,1,0 end
		local text = {n = db.raidstart, r = r, g = g, b = b}
		local onclick = function(f) tracker:BeginRaid(f:GetParent()) end
		local disabled = nil
		if db.InRaid then disabled = true end
		self:AddTextLine(f, onclick, L["Start Raid"], text, nil, nil, nil, nil, disabled, onenter, onleave)
	
		local r,g,b = 0,1,0
		if db.raidend == L["PENDING"] then r,g,b = 1,1,0 end
		local text = {n = db.raidend, r = r, g = g, b = b}
		local onclick = function(f) 
					local direct
					if IsShiftKeyDown() then direct = true end 
					tracker:ShowEndRaidFrame(f:GetParent(), direct) 
				end
		local disabled = nil
		if not db.InRaid then disabled = true end
		self:AddTextLine(f, onclick, L["End Raid"], text, nil, nil, nil, nil, disabled, onenter, onleave)
	
		local r,g,b = 0,1,0
		if db.raidexport == L["PENDING"] then r,g,b = 1,1,0 end
		local text = {n = db.raidexport, r = r, g = g, b = b}
		local onclick = function(f) tracker:ExportRaids(f:GetParent()) end
		self:AddTextLine(f, onclick, L["Export Raid"], text, nil, nil, nil, nil, nil, onenter, onleave)
		
		local onclick = function(f) 
					if IsShiftKeyDown() then tracker:CustomEvent()
					else self:Opendewdrop(f, mdkp.ZoneBosses[db.menuzone], f.type, "custom") 
					end
				end
		self:AddTextLine(f, onclick, L["Custom Event"], db.custom, nil, nil, nil, nil, disabled, onenter, onleave)
	
		
		width = f.hint:GetStringWidth()/4 + 10
		if width < f.textlen then width = f.textlen end
		f.hint:SetWidth(width)
    		f:SetHeight(f.height + f.hint:GetStringHeight() + 25)
    		for v = 1, f.textid-1 do
    			f.text[v]:SetWidth(width)
    			f.text[v]:Show()
		end
	else 
    		width = f.hint:GetStringWidth() + 15
    		f.hint:SetWidth(width)
    		f.height = f.height + f.hint:GetStringHeight()
    		if f.title then f.height = f.height + f.title:GetStringHeight() + 5 end
    		f:SetHeight(f.height + 10)
    	end
    	f:SetWidth(width+5)
    	f:Show()
end

function mdkp.modulePrototype:ShowBidSummary(id, itemname, quality, raidid)
	local querydata
	if mdkp.db.profile.raidlog[raidid] and mdkp.db.profile.raidlog[raidid].queries then querydata = mdkp.db.profile.raidlog[raidid].queries[id] end
	if querydata then
		local r, g, b
		if type(quality) ~= "table" then
			quality = quality + 1
			r, g, b = mdkp.Quality[quality].r, mdkp.Quality[quality].g, mdkp.Quality[quality].b
		else 
			r, g, b = quality.r, quality.g, quality.b
		end
		GameTooltip:AddLine(itemname, r, g, b)
		for _, result in ipairs(querydata) do
			local name = self:GetClasscolors(result[1])
			local vote = mdkp.defaultstatustext[result[2]] 
			local points = result[3]
  			GameTooltip:AddDoubleLine(name.n, vote.n .. "   " .. points, name.r, name.g, name.b, vote.r, vote.g, vote.b)
  		end
  	end
end

--switch to let frame know needs updating
function mdkp.modulePrototype:ToggleFrameUpdate(togglename)
	if not mdkp.updatedata then mdkp.updatedata = {} end
	mdkp.updatedata[togglename] = true
end

--fubar/LDB link click
function mdkp.modulePrototype:TooltipLootClick(itemID, itemlink)
	self:debug("Itemlink click")
	if IsShiftKeyDown() then
		local ChatFrameEditBox = ChatEdit_GetActiveWindow()
		if ChatFrameEditBox then ChatFrameEditBox:Insert(itemlink) end
	elseif IsControlKeyDown() then
		mdkp.db.profile.ignore[itemID] = true
		self:out(string.format(L["Added %s to ignore list."], itemlink))
	else 
		local loot = self:GetModuleRef("Lootframe")
		if loot then loot:AddManualItem(itemlink) end
	end
end

function mdkp.modulePrototype:ToggleML(f)
	mdkp.MLmode = not mdkp.MLmode
	self:Updatetooltipdata(f)
end

--[[opens dewdrop type frame
	frame = frame to anchor on
	validate = data table
	type = toggle or nil
	dbvalue = switch to change
	names = values are names and need to be colored
	level = dew level or nil

Multilevel dew format {PALADIN = {{n="Morgalm", c="PALADIN", r=1,b=1,g=1}, {n="John", c="PALADIN", r=1,b=1,g=1}, {n="Henry", c="PALADIN", r=1,b=1,g=1}},
			DRUID = {{n="Taisch", c="DRUID", r=1,b=1,g=1}}}
]]--
function mdkp.modulePrototype:Opendewdrop(frame, validate, typeid, dbvalue, names, level)
	local db = mdkp.db.profile
	if not type(validate) == "table" then return end
	local parent = frame:GetParent()
	if not parent then parent = frame end
	if not self.dewframe then
		self.dew = {}
		self.dewframe = self:Createframe("MorgDKP2_dewtip", nil, nil, nil, nil, nil, "Dewframe", validate, parent, nil, nil, nil, true)
		self.dewframe:SetFrameStrata("FULLSCREEN")
		self.dewframe.scroll:SetAllPoints()
		self.dewframe.scroll:SetBackdrop({ bgFile = media:Fetch("background", db.media.background), tile = false, tileSize = 16, edgeFile = media:Fetch("border", db.media.border), edgeSize = 8, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
		self.dewframe.scroll:SetBackdropColor(unpack(db.media.backdropC))
		self.dewframe.scroll:SetBackdropBorderColor(unpack(db.media.borderC))
		self.dewframe:Show()
	end
	if level and level > 1 then 
		if not self.dew[level] then 
			self.dew[level] = self:Createframe("MorgDKP2_dewtip"..level, nil, nil, nil, nil, nil, "Dewframe"..level, validate, parent, nil, nil, nil, true)
			self.dew[level]:SetFrameStrata("FULLSCREEN")
			self.dew[level].scroll:SetAllPoints()
			self.dew[level].scroll:SetBackdrop({ bgFile = media:Fetch("background", db.media.background), tile = false, tileSize = 16, edgeFile = media:Fetch("border", db.media.border), edgeSize = 8, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
			self.dew[level].scroll:SetBackdropColor(unpack(db.media.backdropC))
			self.dew[level].scroll:SetBackdropBorderColor(unpack(db.media.borderC))
			self.dew[level]:Show()
		end
	end
	if not level or level == 1 then
		self.dewframe.timer = 75
		self.dewframe:SetScript("OnUpdate", function(f) 
						if f.timer == 0 then 
							if not MouseIsOver(self.dewframe.scroll) and not MouseIsOver(self.dewframe) and (not self.dew[2] or (self.dew[2] and not MouseIsOver(self.dew[2].scroll))) then
								self.dewopen = nil
								f:Hide() 
								if self.dew[2] then self.dew[2]:Hide() end
								f:SetScript("OnUpdate", nil)
							end
						elseif f.timer > 0 then f.timer = f.timer - 1
						end
					end)
	end
	self.dewopen = true
	self:Updatedewdrop(frame, validate, typeid, dbvalue, names, level)
end

--update dewframe when necessary
function mdkp.modulePrototype:Updatedewdrop(frame, validate, typeid, dbvalue, names, level)
	--self:debug("Dewupdate"..(level or "nil"))
	local df = self.dewframe.scroll
	if level and level > 1 then df = self.dew[level].scroll end
	for v = 1, df.textid-1 do
    		df.text[v]:Hide()
    		df.text[v] = nil
	end
	local numitems = #validate
	local maxitems = nil
	local screenheight = GetScreenHeight() * UIParent:GetEffectiveScale()
	local heightneeded =  numitems * mdkp.db.profile.media.fontsize
	if screenheight/heightneeded < 2 then
		maxitems = math.floor(((screenheight/2) / mdkp.db.profile.media.fontsize) + .5)
	end
	df.textid = 1
	df.height = 0
	df.textlen = 0
	df.datasource = validate
	local temp = {}
	
	if not level then
		local counter = 1
		for key, data in ipairs(validate) do
			local onclick = function(f) self:Activatedewoption(frame, f:GetID(), validate, f.type, dbvalue, f.datacheck, nil, names) end
			local icon, checked
			local disabled = nil
			if typeid and typeid ~= "raidtracker" then
				--toggle
				if dbvalue == "dkpstatustext" then
					local refname = mdkp.dkpmenuconvert[data]
					if mdkp.db.profile.moduleON[refname] or (refname == "attemptmode" and mdkp.db.profile.attemptmode) then
						icon = "Interface\\Buttons\\UI-CheckBox-Check"
						checked = true
					else 
						icon = "Interface\\Buttons\\UI-CheckBox-Check"
						checked = nil
					end
				else
					if mdkp.db.profile[dbvalue] then
						icon = "Interface\\Buttons\\UI-CheckBox-Check"
						checked = true
					else 
						icon = "Interface\\Buttons\\UI-CheckBox-Check"
						checked = nil
						disabled = self:CheckDisabledState(dbvalue)
					end
				end
				if maxitems then 
					local r1, g1, b1 = unpack(mdkp.db.profile.media.fontC)
					table.insert(temp, {[1] = {n = data, r = r1, g = g1, b = b1, i = icon, check = checked}})
				end
			else
				if data == mdkp.db.profile[dbvalue] or (dbvalue == "quality" and mdkp.db.profile[dbvalue] + 1 == key) then
					icon = "Interface\\Buttons\\UI-RadioButton"
					checked = true
				else
					icon = "Interface\\Buttons\\UI-RadioButton"
					checked = nil
				end
				if names then data = self:GetClasscolors(data) end
				if maxitems then 
					if dbvalue == "quality" then
						data.i = icon
						data.check = checked
						table.insert(temp, {[1] = data})
					elseif not names then
						local r1, g1, b1 = unpack(mdkp.db.profile.media.fontC)
						table.insert(temp, {[1] = {n = data, r = r1, g = g1, b = b1, i = icon, check = checked}})
					else
						data.i = icon
						data.check = checked
						table.insert(temp, data)
					end
				end
			end
			if not maxitems or counter <= maxitems then 
				self:AddTextLine(df, onclick, data, nil, nil, typeid, icon, checked, disabled) 
			end
			counter = counter + 1
		end
	else
		if level == 1 then
			for menuopt, data in pairs(validate) do
				local onenter, onclick
				if type(data) == "table" then onenter = function(f) self:Opendewdrop(f, data, nil, dbvalue, nil, 2) end
				else onclick = function(f) self:Activatedewoption(frame, f:GetID(), menuopt, f.type, dbvalue, f.datacheck, level, names) end
				end
				if dbvalue == "ML" or dbvalue == "BOE" then
					local temp = mdkp.ClasscolorsDEC[menuopt]
					if not temp then temp = {r = 1.0 , g = 1.0 , b = 1.0} end
					temp.n = menuopt
					menuopt = temp
				end
				self:AddTextLine(df, onclick, menuopt, nil, nil, nil, nil, nil, nil, onenter)
			end
			if dbvalue == "ML" or dbvalue == "BOE" then
				local onclick = function(f) self:Activatedewoption(frame, f:GetID(), "Close", f.type, dbvalue, f.datacheck, level, names) end
				self:AddTextLine(df, onclick, L["Close"], nil, nil, nil, nil, nil, nil)
			end
			self.dewframe:Show()
		elseif level > 1 then
			--self:debug("level="..level)
			if validate[1] then
				for _, data in ipairs(validate) do
					local onclick = function(f) self:Activatedewoption(f, f:GetID(), data, f.type, dbvalue, f.datacheck, level, names) end
					local icon = "Interface\\Buttons\\UI-RadioButton"
					self:AddTextLine(df, onclick, data, nil, nil, nil, icon)
				end
			else 
				for menuopt2, data in pairs(validate) do
					local onenter = function(f) self:Opendewdrop(f, data, nil, dbvalue, nil, level + 1) end
					self:AddTextLine(df, nil, menuopt2, nil, nil, nil, nil, nil, nil, onenter)
				end
			end
			if self.dew[level] then self.dew[level]:Show() end
		end
	end
	if not level and maxitems then
		df:SetScript("OnMouseWheel", function(f, direction) self:Scrollframe_Update(f, numitems, maxitems, temp, direction, "dewframe", typeid, dbvalue, frame, validate) end)
		self:Scrollframe_Update(df, numitems, maxitems, temp, nil, "dewframe", typeid, dbvalue, frame, validate)
	end
	df:ClearAllPoints()
	if frame:GetParent().datacheck == "TooltipLDB" then
		local point = "LEFT"
		local relpoint = mdkp.db.profile.dewpoint
		if relpoint == "LEFT" then point = "RIGHT" end
		df:SetPoint(point, frame, relpoint, 0, 0)
	else
		df:SetPoint("LEFT", frame, "RIGHT", 0, 0)
	end
	df:SetHeight(df.height + 10)
    	df:SetWidth(df.textlen)
    	for v = 1, df.textid-1 do
    		df.text[v]:SetWidth(df.textlen)
	end
	df:Show()
	self.dewframe:Show()
end	

function mdkp.modulePrototype:CloseDewFrame()
	if self.dewopen then 
		self.dewopen = nil
		self.dewframe:Hide() 
		return true
	end
	return false
end

--return if dewoption should be disabled
function mdkp.modulePrototype:CheckDisabledState(dbvalue)
	local disabledtable = mdkp.db.profile.dkpmodules.conflicts
	for _, dkp in pairs(disabledtable[dbvalue]) do
		if mdkp.db.profile.moduleON[dkp] then return true end
	end
	return false 
end

--[[toggle dewoption
	parent = frame dew is anchored to
	id = id of clicked on frame
	data = table of values 
	switch = SV item to change
	frameupdatecheck = update master frame toggle
	level = level to close up to or nil
	names = player names toggle
]]--
function mdkp.modulePrototype:Activatedewoption(parent, id, data, typeid, switch, frameupdatecheck, level, names)
	self:debug("ID = "..id..(switch or "NIL"))
	if typeid then
		--its a toggle
		if typeid == "raidtracker" then
			local raidtracker = self:GetModuleRef("RaidTracker")
			if raidtracker then 
				self.dewframe:Hide()
				self.dewopen = nil
				raidtracker:HandleDewAction(switch, data[id], id) 
			end
			return
		elseif switch == "dkpstatustext" then 
			local core = self:GetModuleRef("CoreModule")
			if core then core:ChangeDKPType(data[id]) end
		else mdkp.db.profile[switch] = not mdkp.db.profile[switch] 
		end
	else
		if switch == "BOE" then
			self.dewopen = nil
			self.dewframe:Hide()
			self.dew[2]:Hide()
			if data == "Close" then return end
			local core = self:GetModuleRef("CoreModule")
			if core then core:GiveBOE(data.n) end
			return
		elseif switch == "ML" then
			self.dewopen = nil
			self.dewframe:Hide()
			self.dew[2]:Hide()
			if data == "Close" then return end
			local lootframe = self:GetModuleRef("Lootframe")
			if lootframe then lootframe:MLchosen(data.n) end
			return
		elseif switch == "lootmethod" then 
			local tracker = self:GetModuleRef("Tracker")
			if tracker then tracker:ChangeLootMethod(data[id]) end
		elseif switch == "quality" then 
			mdkp.db.profile[switch] = id - 1
			local sync = self:GetModuleRef("Syncing")
			if sync and mdkp.db.profile.InRaid then sync:ChangeQualityThreshold(id - 1) end	
		elseif switch == "disenchanter" then 
			mdkp.db.profile[switch] = data[id]
			local sync = self:GetModuleRef("Syncing")
			if sync and mdkp.db.profile.InRaid then sync:ChangeDisenchanter(data[id]) end	
		elseif type(switch) == "number" then mdkp.db.profile.items[switch].pool = data[id]
		else mdkp.db.profile[switch] = data[id] end
	end
	self:Updatedewdrop(parent, data, typeid, switch, names, level, parent)
	local frame = parent:GetParent()
	local name = frame:GetName()
	if name == "Tooltip_BrokerMorgDKP2" then self:Updatetooltipdata(frame) end
end


function mdkp.modulePrototype:GetScaledCursorPosition()
	local x, y = GetCursorPosition()
	local scale = UIParent:GetEffectiveScale()
	return x / scale, y / scale, scale
end

function mdkp.modulePrototype:AwardDKP(new, old, pool, attendees, wait, quiet)
	self:debug("AwardDKP")
	if not attendees or #attendees == 0 then return end
	local db = mdkp.db.profile
	local update = self:GetServerTime()
	if new == old then return end
	local diff
	if new then
		diff = new - old
	elseif old == 0 then return
	else diff = old end
	local counter = 0
	for _, name in pairs(attendees) do
		local main = self:CheckforAlias(name, pool)
		self:PointsPoolExists(name, pool)
		db.info[name][pool].points = db.info[name][pool].points + diff
		db.info[name][pool].earned = db.info[name][pool].earned + diff
		db.info[name].lastupdate = update
		counter = counter + 1
		--self:debug("1. "..name..db.info[name][pool].points)
		if main ~= name then self:UpdateMain(main, db.info[name][pool].points, db.info[name][pool].earned, nil, pool) end
		
		--update alts
		self:UpdateAlts(main, name, db.info[name][pool].points, db.info[name][pool].earned, nil, pool)
	end
	if not quiet then
		if wait then self:out(string.format(L["Added %s DKP to waitlist attendees."], diff))
		else
			if #attendees == 1 then self:out(string.format(L["Added %s DKP to %s."], diff, attendees[1]))
			else self:out(string.format(L["Added %s DKP to %s attendees."], diff, counter))
			end
		end
	end
end

function mdkp.modulePrototype:AwardItem(id, looter, POOL, points, itempoints, link)
	self:debug("AwardItem")
	local db = mdkp.db.profile
	local main = self:CheckforAlias(looter, POOL)
	db.info[looter][POOL].points = points
	db.info[looter][POOL].spent = db.info[looter][POOL].spent + itempoints
	db.info[looter].raidloot = 1
	db.info[looter].lastupdate = self:GetServerTime()
	--self:debug("1. "..looter.."MAIN="..main..db.info[looter][POOL].points)
	if main ~= looter then self:UpdateMain(main, db.info[looter][POOL].points, db.info[looter][POOL].earned, db.info[looter][POOL].spent, POOL) end
		
	--update alts
	self:UpdateAlts(main, looter, db.info[looter][POOL].points, db.info[looter][POOL].earned, db.info[looter][POOL].spent, POOL)
	
	self:out(string.format(L["%s received %s for %s DKP"], looter, link, itempoints)) 
end

function mdkp.modulePrototype:AdjustDKPPoints(new, old, pool, newcost, oldcost, link)
	self:debug("AdjustDKPPoints")
	local db = mdkp.db.profile
	local update = self:GetServerTime()
	local newmain = self:CheckforAlias(new, pool)
	local oldmain = self:CheckforAlias(old, pool)
	if new ~= old then
		db.info[old][pool].points = db.info[old][pool].points + newcost
		db.info[old][pool].spent = db.info[old][pool].spent - newcost
		db.info[old].raidloot = 0
		db.info[old].lastupdate = update
		db.info[new][pool].points = db.info[new][pool].points - newcost
		db.info[new][pool].spent = db.info[new][pool].spent + newcost
		db.info[new].raidloot = 1
		db.info[new].lastupdate = update
		--self:debug("1. "..old..db.info[old][pool].points)
		--self:debug("1. "..new..db.info[new][pool].points)
		if newmain ~= new then self:UpdateMain(newmain, db.info[new][pool].points, nil, db.info[new][pool].spent, pool) end
		if oldmain ~= old then self:UpdateMain(oldmain, db.info[old][pool].points, nil, db.info[old][pool].spent, pool) end
		
		--update alts
		self:UpdateAlts(newmain, new, db.info[new][pool].points, nil, db.info[new][pool].spent, pool)
		self:UpdateAlts(oldmain, old, db.info[old][pool].points, nil, db.info[old][pool].spent, pool)
	
		self:out(string.format(L["Transferred %s to %s for %s DKP."], link, new, newcost))
	else
		local costdiff
		if not newcost then
			costdiff = oldcost
			newcost = 0
			db.info[old].raidloot = 0
		else costdiff = oldcost - newcost  end
		db.info[old][pool].points = db.info[old][pool].points + costdiff
		db.info[old][pool].spent = db.info[old][pool].spent - costdiff
		db.info[old].lastupdate = update
		--self:debug("1. "..old..db.info[old][pool].points)
		if oldmain ~= old then self:UpdateMain(oldmain, db.info[old][pool].points, nil, db.info[old][pool].spent, pool) end
		
		--update alts
		self:UpdateAlts(oldmain, old, db.info[old][pool].points, nil, db.info[old][pool].spent, pool)
		
		self:out(string.format(L["Changed itemcost from %s to %s DKP for %s."], oldcost, newcost, old))
	end
end

function mdkp.modulePrototype:UpdateAlts(main, updatee, points, earned, spent, pool)
	local db = mdkp.db.profile
	if db.eqDKP[pool].Aliases then
		for alt, MAIN in pairs(db.eqDKP[pool].Aliases) do
			if MAIN == main and alt ~= updatee then
				self:PointsPoolExists(alt, pool)
				db.info[alt][pool].points = points
				if earned then db.info[alt][pool].earned = earned end
				if spent then db.info[alt][pool].spent = spent end
				--self:debug("3. "..alt..points)
			end
		end
	end
end

function mdkp.modulePrototype:UpdateMain(main, points, earned, spent, pool)
	local db = mdkp.db.profile
	self:PointsPoolExists(main, pool)
	db.info[main][pool].points = points
	if earned then db.info[main][pool].earned = earned end
	if spent then db.info[main][pool].spent = spent end
	--self:debug("2. "..main..db.info[main][pool].points)
end

function mdkp.modulePrototype:CheckforAlias(name, pool)
	if not name then return end
	if mdkp.db.profile.eqDKP and mdkp.db.profile.eqDKP[pool] and mdkp.db.profile.eqDKP[pool].Aliases and mdkp.db.profile.eqDKP[pool].Aliases[name] then
		return mdkp.db.profile.eqDKP[pool].Aliases[name]
	end
	return name
end

--return eventID 
--	1 = start
--	2 = run
--	3 = waitlist/run
function mdkp.modulePrototype:GetEventID(eventcode, raidnum)
	if not raidnum then raidnum = mdkp.db.profile.raidnum end
	for id, event in pairs(mdkp.db.profile.raidlog[raidnum].bosskills) do
		if event.trash == eventcode then return id end
	end
	return false
end

function mdkp.modulePrototype:GetEventName(boss, eventformat, zone, difficulty)
	if not zone then zone = GetRealZoneText() end
	if not difficulty then difficulty = mdkp.db.profile.instancedifficulty end
	local note
	local event = eventformat
	event = string.gsub(event, "<zone>", zone)
	event = string.gsub(event, "<boss>", boss)
	event = string.gsub(event, "<diff>", mdkp.difftable[difficulty])
	return event
end

function mdkp.modulePrototype:DKPChange(newtype)
	mdkp:ActivateCore(true)
	local core = self:GetModuleRef("CoreModule")
	if core then core:ChangeDKPType(newtype) end
end


function mdkp.modulePrototype:GetDKPInfo(name, POOL, showearned)
	local db = mdkp.db.profile
	local currDKP = self:GetModuleRef(db.currDKP)
	self:PointsPoolExists(name, POOL)
	local points = currDKP:GetPlayerPoints(name, POOL, showearned) 
	local pointsdata = {n = points, r = 0, g = 1, b = 0}
  	if db.info[name].raidloot == 1 then pointsdata.r = 1 end
  	local namedata = self:GetClasscolors(name)
  	return namedata, pointsdata 	
end

function mdkp.modulePrototype:GetTAKEModeValue(itemid, itempoints, player)
	local db = mdkp.db.profile
	if db.takemode or db.offspecmode then
		local take = db.takeamount
		local offspec = db.offspecamount
		if mdkp.querytooltips[itemid] then
			for  i,v in pairs(mdkp.querytooltips[itemid]) do
				if v[1].n == player then
					if db.takemode and v[2] == "TAKE" then 
						if db.takepercent then itempoints = itempoints * take / 100
						else itempoints = take end
					elseif db.offspecmode and v[2] == "OFFSPEC" then 
						if db.offspecpercent then itempoints = itempoints * offspec / 100
						else itempoints = offspec end
					end
					break
				end
			end
		end
	end
	return itempoints
end

function mdkp.modulePrototype:ReturnItemIndex(item, name)
	local db = mdkp.db.profile
	if not db.info[name] or not db.info[name].items then return nil end
	for index, ID in pairs(db.info[name].items) do
		if item == ID then
			return index
		end
	end
	return nil
end

function mdkp.modulePrototype:AwardWaitotimeDKP(value, POOL, eventname, attendees, name, type)
	local db = mdkp.db.profile
	if not db.raidlog.dkpevents then db.raidlog.dkpevents = { } end
	if not db.raidlog.dkpevents[POOL] then db.raidlog.dkpevents[POOL] = { } end
	table.insert(db.raidlog.dkpevents[POOL], {	name = name,
							value = value,
							members = attendees,
							eqdkp = db.eqDKP[POOL].eqDKPsite,
							prefix = db.eqDKP[POOL].prefix,
							addtype = type,
							event = eventname})
end

mdkp:SetDefaultModulePrototype(mdkp.modulePrototype)
