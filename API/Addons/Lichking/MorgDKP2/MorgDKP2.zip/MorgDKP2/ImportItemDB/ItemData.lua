MorgDKP2_Items = {
			[46992] = {
					["classes"] = 328,
					["points"] = 75,
					["altclasses"] = 1040,
				},
				[47056] = {
					["classes"] = 16,
					["points"] = 75,
					["altclasses"] = 128,
				},
				[40979] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45137] = {
					["classes"] = 4,
					["points"] = 80,
					["altclasses"] = 512,
				},
				[45265] = {
					["classes"] = 1056,
					["points"] = 65,
					["altclasses"] = 662,
				},
				[45329] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[41299] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45649] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45713] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39764] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46033] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[40340] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[40532] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51023] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[47057] = {
					["classes"] = 128,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[47121] = {
					["classes"] = 134,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[45138] = {
					["classes"] = 134,
					["points"] = 40,
					["altclasses"] = 1024,
				},
				[49296] = {
					["classes"] = 678,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45266] = {
					["classes"] = 32,
					["points"] = 40,
					["altclasses"] = 518,
				},
				[39189] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[43347] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45458] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45650] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41620] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39701] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[39765] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[50064] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[41940] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[42004] = {
					["classes"] = 8,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40277] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40341] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[40405] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46994] = {
					["classes"] = 512,
					["points"] = 90,
					["altclasses"] = 4,
				},
				[32748] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45139] = {
					["classes"] = 132,
					["points"] = 65,
					["altclasses"] = 2,
				},
				[49297] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 2,
				},
				[45267] = {
					["classes"] = 134,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[39190] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[39254] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[45523] = {
					["classes"] = 1056,
					["points"] = 65,
					["altclasses"] = 528,
				},
				[47634] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45651] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39702] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[39766] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[46035] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[42005] = {
					["classes"] = 8,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[42069] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40278] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40342] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40406] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40982] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47187] = {
					["classes"] = 328,
					["points"] = 75,
					["altclasses"] = 1040,
				},
				[45268] = {
					["classes"] = 128,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[39191] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[39255] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45524] = {
					["classes"] = 528,
					["points"] = 65,
					["altclasses"] = 134,
				},
				[45652] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39703] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39767] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45972] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46036] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 514,
				},
				[32269] = {
					["classes"] = 36,
					["points"] = 100,
					["altclasses"] = 528,
				},
				[44309] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40279] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 2,
				},
				[40343] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[40407] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 518,
				},
				[46996] = {
					["classes"] = 32,
					["points"] = 90,
					["altclasses"] = 514,
				},
				[40983] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49235] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[49299] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45269] = {
					["classes"] = 128,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[39192] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1024,
				},
				[39256] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[37401] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45653] = {
					["classes"] = 200,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[39704] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39768] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[45973] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[43990] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[48212] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40280] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40344] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40408] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50771] = {
					["classes"] = 264,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[46997] = {
					["classes"] = 134,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[45142] = {
					["classes"] = 32,
					["points"] = 40,
					["altclasses"] = 514,
				},
				[45270] = {
					["classes"] = 1024,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45334] = {
					["classes"] = 134,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[39257] = {
					["classes"] = 1686,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45654] = {
					["classes"] = 532,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[45974] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[46038] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50452] = {
					["classes"] = 1590,
					["points"] = 40,
					["altclasses"] = 128,
				},
				[24242] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40345] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 2,
				},
				[40409] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[50772] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[32750] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47126] = {
					["classes"] = 328,
					["points"] = 75,
					["altclasses"] = 1040,
				},
				[45143] = {
					["classes"] = 528,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[45271] = {
					["classes"] = 1368,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[39194] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[39258] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 2,
				},
				[45463] = {
					["classes"] = 1078,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[39386] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[45655] = {
					["classes"] = 1314,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[47830] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39706] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47958] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[45975] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[43992] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[50453] = {
					["classes"] = 1158,
					["points"] = 60,
					["altclasses"] = 48,
				},
				[40282] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40346] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 36,
				},
				[40410] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40474] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50773] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40602] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[46999] = {
					["classes"] = 134,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[45144] = {
					["classes"] = 2,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[23635] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45272] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[39195] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39259] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[45464] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[47703] = {
					["classes"] = 1584,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[39579] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47959] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[45976] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[43993] = {
					["classes"] = 1584,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[42074] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40283] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[40347] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[44569] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40539] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50966] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[47000] = {
					["classes"] = 1056,
					["points"] = 75,
					["altclasses"] = 528,
				},
				[45145] = {
					["classes"] = 128,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45273] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[45337] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39260] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39388] = {
					["classes"] = 1088,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45657] = {
					["classes"] = 532,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[39580] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47832] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[40284] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40348] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[40412] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50775] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50967] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45146] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[49304] = {
					["classes"] = 1216,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[45274] = {
					["classes"] = 16,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[39197] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39261] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39389] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[45658] = {
					["classes"] = 1314,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[47961] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[30321] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40285] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[40349] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[40541] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[18423] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45147] = {
					["classes"] = 1232,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[49305] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 36,
				},
				[39262] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45467] = {
					["classes"] = 528,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[47578] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45659] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39582] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[31089] = {
					["classes"] = 200,
					["points"] = 115,
					["altclasses"] = 0,
				},
				[40286] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1024,
				},
				[40350] = {
					["classes"] = 1088,
					["points"] = 0,
					["altclasses"] = 408,
				},
				[40414] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[25396] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40926] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45148] = {
					["classes"] = 1368,
					["points"] = 40,
					["altclasses"] = 128,
				},
				[39199] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[39391] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[37408] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45660] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47835] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50010] = {
					["classes"] = 128,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[41886] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41950] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40287] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40351] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1024,
				},
				[40415] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40543] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40927] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40991] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45149] = {
					["classes"] = 1024,
					["points"] = 65,
					["altclasses"] = 144,
				},
				[49307] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39200] = {
					["classes"] = 392,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45469] = {
					["classes"] = 1158,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[39392] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45661] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[31090] = {
					["classes"] = 1312,
					["points"] = 115,
					["altclasses"] = 0,
				},
				[39712] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50011] = {
					["classes"] = 328,
					["points"] = 85,
					["altclasses"] = 1040,
				},
				[41951] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[42015] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40288] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[40352] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[50779] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49116] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45086] = {
					["classes"] = 32,
					["points"] = 40,
					["altclasses"] = 516,
				},
				[45150] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[49308] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[49500] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 130,
				},
				[39393] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[47837] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[47965] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[32242] = {
					["classes"] = 16,
					["points"] = 90,
					["altclasses"] = 0,
				},
				[42016] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[48349] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40289] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 1288,
				},
				[48541] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40417] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50780] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[47070] = {
					["classes"] = 1584,
					["points"] = 50,
					["altclasses"] = 134,
				},
				[45151] = {
					["classes"] = 16,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[39394] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[47838] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[39714] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[47966] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[44000] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[48222] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50333] = {
					["classes"] = 1056,
					["points"] = 85,
					["altclasses"] = 528,
				},
				[40418] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50781] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[40610] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47071] = {
					["classes"] = 1056,
					["points"] = 75,
					["altclasses"] = 528,
				},
				[49310] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39139] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51485] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39267] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39395] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47711] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30068] = {
					["classes"] = 16,
					["points"] = 65,
					["altclasses"] = 640,
				},
				[49950] = {
					["classes"] = 1056,
					["points"] = 85,
					["altclasses"] = 528,
				},
				[50014] = {
					["classes"] = 1496,
					["points"] = 60,
					["altclasses"] = 0,
				},
				[42018] = {
					["classes"] = 8,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[32307] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[44577] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40547] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40611] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40803] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47072] = {
					["classes"] = 134,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[51358] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39140] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[39396] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1024,
				},
				[31092] = {
					["classes"] = 200,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[39716] = {
					["classes"] = 144,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50015] = {
					["classes"] = 16,
					["points"] = 85,
					["altclasses"] = 128,
				},
				[44002] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[46113] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[48224] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[48288] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50783] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[40612] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47073] = {
					["classes"] = 528,
					["points"] = 75,
					["altclasses"] = 134,
				},
				[41060] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45282] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45538] = {
					["classes"] = 1158,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[19802] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39717] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 2,
				},
				[44003] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[50400] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40549] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40613] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47138] = {
					["classes"] = 1352,
					["points"] = 50,
					["altclasses"] = 144,
				},
				[41061] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45283] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39270] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 518,
				},
				[39398] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[31093] = {
					["classes"] = 1312,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[39718] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[41893] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[44004] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[48226] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40294] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40486] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50785] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40614] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47139] = {
					["classes"] = 1496,
					["points"] = 50,
					["altclasses"] = 0,
				},
				[47203] = {
					["classes"] = 328,
					["points"] = 75,
					["altclasses"] = 1040,
				},
				[45284] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 516,
				},
				[39271] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45540] = {
					["classes"] = 1158,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[39719] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[47971] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[44005] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46116] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[32405] = {
					["classes"] = 2047,
					["points"] = 5,
					["altclasses"] = 0,
				},
				[40423] = {
					["classes"] = 8,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50786] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40615] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47140] = {
					["classes"] = 1024,
					["points"] = 75,
					["altclasses"] = 144,
				},
				[47204] = {
					["classes"] = 16,
					["points"] = 75,
					["altclasses"] = 128,
				},
				[49315] = {
					["classes"] = 8,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45285] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[39272] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[45541] = {
					["classes"] = 1496,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45605] = {
					["classes"] = 48,
					["points"] = 40,
					["altclasses"] = 512,
				},
				[47780] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[31094] = {
					["classes"] = 532,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[39720] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[44006] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50339] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[48484] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40488] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50787] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 642,
				},
				[40616] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47141] = {
					["classes"] = 328,
					["points"] = 75,
					["altclasses"] = 1040,
				},
				[45158] = {
					["classes"] = 1158,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45286] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39273] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[39401] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 560,
				},
				[47717] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39721] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 1288,
				},
				[47973] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 130,
				},
				[45990] = {
					["classes"] = 264,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[44007] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[48165] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50340] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40297] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40489] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[50788] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40617] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40809] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47142] = {
					["classes"] = 128,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[49317] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39146] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39274] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[45479] = {
					["classes"] = 1368,
					["points"] = 80,
					["altclasses"] = 0,
				},
				[45543] = {
					["classes"] = 528,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[47718] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[47782] = {
					["classes"] = 8,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[31095] = {
					["classes"] = 532,
					["points"] = 115,
					["altclasses"] = 0,
				},
				[39722] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[45927] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[41897] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[44008] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[46119] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50341] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40234] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1024,
				},
				[40298] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40362] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[40426] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50789] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40618] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47079] = {
					["classes"] = 144,
					["points"] = 50,
					["altclasses"] = 0,
				},
				[45096] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49318] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45288] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[39275] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[45480] = {
					["classes"] = 1584,
					["points"] = 40,
					["altclasses"] = 134,
				},
				[39403] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39467] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47719] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[39595] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30104] = {
					["classes"] = 528,
					["points"] = 70,
					["altclasses"] = 0,
				},
				[41898] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40107] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40235] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[40299] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40363] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40427] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[40491] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 514,
				},
				[40555] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40619] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40811] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40939] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45161] = {
					["classes"] = 134,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[45225] = {
					["classes"] = 134,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[45289] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[45353] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39276] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45481] = {
					["classes"] = 134,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[39404] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39468] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 516,
				},
				[47720] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[31096] = {
					["classes"] = 1312,
					["points"] = 115,
					["altclasses"] = 0,
				},
				[45865] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[45929] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45993] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[42027] = {
					["classes"] = 1590,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40108] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[40236] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 1288,
				},
				[40300] = {
					["classes"] = 1088,
					["points"] = 0,
					["altclasses"] = 280,
				},
				[40428] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40556] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40620] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[19390] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47081] = {
					["classes"] = 328,
					["points"] = 75,
					["altclasses"] = 1040,
				},
				[45162] = {
					["classes"] = 1056,
					["points"] = 65,
					["altclasses"] = 656,
				},
				[45226] = {
					["classes"] = 128,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[45418] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39405] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[2214] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47721] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[45866] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45930] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[44011] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[40237] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[40301] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1024,
				},
				[40365] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40429] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 516,
				},
				[50792] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40621] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47082] = {
					["classes"] = 134,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[45099] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45227] = {
					["classes"] = 528,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[45291] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[39278] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[45483] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[45547] = {
					["classes"] = 1056,
					["points"] = 65,
					["altclasses"] = 528,
				},
				[45675] = {
					["classes"] = 1158,
					["points"] = 35,
					["altclasses"] = 0,
				},
				[31097] = {
					["classes"] = 200,
					["points"] = 115,
					["altclasses"] = 0,
				},
				[39726] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45931] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[23069] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40238] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[40302] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40366] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40430] = {
					["classes"] = 1088,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[40558] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40622] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47083] = {
					["classes"] = 16,
					["points"] = 75,
					["altclasses"] = 128,
				},
				[41006] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45164] = {
					["classes"] = 528,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[45228] = {
					["classes"] = 132,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[45292] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[39215] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[39279] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[39407] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[45676] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41774] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[19903] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45996] = {
					["classes"] = 1536,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[46124] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46188] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40239] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 532,
				},
				[40303] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 1288,
				},
				[40367] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40431] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40495] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40559] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40623] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45165] = {
					["classes"] = 134,
					["points"] = 80,
					["altclasses"] = 16,
				},
				[49323] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39216] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[51562] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39344] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45549] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[39472] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47724] = {
					["classes"] = 1360,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[31098] = {
					["classes"] = 200,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[39728] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45933] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45997] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50411] = {
					["classes"] = 48,
					["points"] = 60,
					["altclasses"] = 646,
				},
				[40240] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40304] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[40368] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[40432] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40496] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40560] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40624] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[19360] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47149] = {
					["classes"] = 1158,
					["points"] = 50,
					["altclasses"] = 0,
				},
				[45166] = {
					["classes"] = 134,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[41136] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45294] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39217] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[39281] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39345] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39409] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[39473] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[47725] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45870] = {
					["classes"] = 548,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45934] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[46126] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40241] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40305] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[40369] = {
					["classes"] = 1716,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40433] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[40497] = {
					["classes"] = 642,
					["points"] = 0,
					["altclasses"] = 4,
				},
				[40561] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40625] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50988] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[46958] = {
					["classes"] = 48,
					["points"] = 50,
					["altclasses"] = 1536,
				},
				[47150] = {
					["classes"] = 134,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[45167] = {
					["classes"] = 128,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[49325] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[37171] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30907] = {
					["classes"] = 528,
					["points"] = 115,
					["altclasses"] = 128,
				},
				[47726] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[41649] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[31099] = {
					["classes"] = 1312,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[47918] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45935] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50413] = {
					["classes"] = 528,
					["points"] = 85,
					["altclasses"] = 134,
				},
				[40242] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40306] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40370] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40562] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40626] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46959] = {
					["classes"] = 134,
					["points"] = 50,
					["altclasses"] = 1584,
				},
				[47151] = {
					["classes"] = 1056,
					["points"] = 75,
					["altclasses"] = 528,
				},
				[45168] = {
					["classes"] = 1496,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45232] = {
					["classes"] = 1056,
					["points"] = 65,
					["altclasses"] = 528,
				},
				[45296] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 4,
				},
				[39283] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[47663] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[45680] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39731] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[45936] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41970] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[42034] = {
					["classes"] = 1590,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46192] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40243] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[40371] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40563] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40627] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50990] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[46960] = {
					["classes"] = 528,
					["points"] = 75,
					["altclasses"] = 134,
				},
				[40883] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47152] = {
					["classes"] = 528,
					["points"] = 65,
					["altclasses"] = 134,
				},
				[45169] = {
					["classes"] = 16,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[49327] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45297] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[39284] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[45489] = {
					["classes"] = 48,
					["points"] = 40,
					["altclasses"] = 512,
				},
				[47728] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[31100] = {
					["classes"] = 532,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[45873] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41971] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[42035] = {
					["classes"] = 1590,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50415] = {
					["classes"] = 134,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[40244] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40372] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40564] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[40628] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46961] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47089] = {
					["classes"] = 1368,
					["points"] = 50,
					["altclasses"] = 128,
				},
				[45106] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45170] = {
					["classes"] = 328,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45234] = {
					["classes"] = 1368,
					["points"] = 80,
					["altclasses"] = 0,
				},
				[41204] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39221] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[39285] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 1288,
				},
				[45490] = {
					["classes"] = 1496,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45682] = {
					["classes"] = 144,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39733] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[47985] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41908] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41972] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[42036] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50352] = {
					["classes"] = 1158,
					["points"] = 60,
					["altclasses"] = 0,
				},
				[40245] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[40373] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[40437] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[40629] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46962] = {
					["classes"] = 134,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[47090] = {
					["classes"] = 16,
					["points"] = 75,
					["altclasses"] = 128,
				},
				[45107] = {
					["classes"] = 134,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[45171] = {
					["classes"] = 1352,
					["points"] = 80,
					["altclasses"] = 16,
				},
				[41141] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45299] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45491] = {
					["classes"] = 1056,
					["points"] = 65,
					["altclasses"] = 528,
				},
				[31101] = {
					["classes"] = 200,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[39734] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[41909] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40246] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1024,
				},
				[40374] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40438] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[40566] = {
					["classes"] = 1040,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40630] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46963] = {
					["classes"] = 132,
					["points"] = 50,
					["altclasses"] = 0,
				},
				[45108] = {
					["classes"] = 1056,
					["points"] = 65,
					["altclasses"] = 662,
				},
				[29758] = {
					["classes"] = 1092,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45236] = {
					["classes"] = 1496,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45492] = {
					["classes"] = 1024,
					["points"] = 65,
					["altclasses"] = 144,
				},
				[39415] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41654] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39735] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[45940] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[41910] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30238] = {
					["classes"] = 776,
					["points"] = 95,
					["altclasses"] = 0,
				},
				[30302] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40247] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 1288,
				},
				[40375] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[40439] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[40567] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40631] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47092] = {
					["classes"] = 328,
					["points"] = 75,
					["altclasses"] = 1040,
				},
				[45109] = {
					["classes"] = 528,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[41143] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39224] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[45493] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39416] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 516,
				},
				[45685] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41655] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[31102] = {
					["classes"] = 1312,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[47924] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45941] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[46133] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40184] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40376] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1024,
				},
				[40504] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50803] = {
					["classes"] = 1584,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40632] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49076] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47093] = {
					["classes"] = 128,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[45110] = {
					["classes"] = 132,
					["points"] = 40,
					["altclasses"] = 2,
				},
				[29759] = {
					["classes"] = 776,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45238] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[45302] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 656,
				},
				[39225] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39417] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47669] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[45686] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[39609] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30239] = {
					["classes"] = 176,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[30303] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40185] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40249] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[40377] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50804] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40633] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40889] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47094] = {
					["classes"] = 1024,
					["points"] = 75,
					["altclasses"] = 144,
				},
				[45111] = {
					["classes"] = 134,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[45239] = {
					["classes"] = 16,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[45303] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39226] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 6,
				},
				[45687] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[31103] = {
					["classes"] = 532,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[47926] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[50037] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46135] = {
					["classes"] = 8,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51554] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[50796] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40250] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45333] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[21220] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50795] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[50021] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[25410] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40634] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51354] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51556] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41080] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50859] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41840] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45112] = {
					["classes"] = 1158,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[47223] = {
					["classes"] = 1232,
					["points"] = 50,
					["altclasses"] = 264,
				},
				[45240] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[45304] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45539] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50794] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41656] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47607] = {
					["classes"] = 1584,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[50000] = {
					["classes"] = 528,
					["points"] = 85,
					["altclasses"] = 134,
				},
				[39547] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[29753] = {
					["classes"] = 1092,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[29755] = {
					["classes"] = 776,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[47927] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[49998] = {
					["classes"] = 1584,
					["points"] = 60,
					["altclasses"] = 134,
				},
				[46008] = {
					["classes"] = 1584,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[37884] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30240] = {
					["classes"] = 1092,
					["points"] = 70,
					["altclasses"] = 0,
				},
				[50450] = {
					["classes"] = 16,
					["points"] = 85,
					["altclasses"] = 128,
				},
				[30304] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40187] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40251] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40315] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40379] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[50342] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50008] = {
					["classes"] = 1496,
					["points"] = 60,
					["altclasses"] = 0,
				},
				[40635] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50002] = {
					["classes"] = 134,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[50998] = {
					["classes"] = 1536,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50801] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39730] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 518,
				},
				[43345] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45113] = {
					["classes"] = 1496,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[49324] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51382] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[49999] = {
					["classes"] = 134,
					["points"] = 60,
					["altclasses"] = 1584,
				},
				[49463] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39292] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45864] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[47608] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[45136] = {
					["classes"] = 1024,
					["points"] = 65,
					["altclasses"] = 144,
				},
				[47736] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[41659] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49490] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[49975] = {
					["classes"] = 1368,
					["points"] = 60,
					["altclasses"] = 128,
				},
				[45945] = {
					["classes"] = 1584,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[46009] = {
					["classes"] = 1040,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[50797] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[40060] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[50359] = {
					["classes"] = 1232,
					["points"] = 60,
					["altclasses"] = 0,
				},
				[40188] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40252] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40316] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40380] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1024,
				},
				[50858] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[40786] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40572] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40636] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50776] = {
					["classes"] = 544,
					["points"] = 0,
					["altclasses"] = 4,
				},
				[50999] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 516,
				},
				[47922] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50003] = {
					["classes"] = 134,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[39419] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 36,
				},
				[45114] = {
					["classes"] = 16,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[47225] = {
					["classes"] = 1232,
					["points"] = 50,
					["altclasses"] = 264,
				},
				[51383] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45306] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[39229] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45434] = {
					["classes"] = 128,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[45946] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[47609] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40940] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47737] = {
					["classes"] = 646,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[17106] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49494] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47929] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[50040] = {
					["classes"] = 1536,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[46010] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46351] = {
					["classes"] = 1204,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30241] = {
					["classes"] = 776,
					["points"] = 70,
					["altclasses"] = 0,
				},
				[40061] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[45876] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 2,
				},
				[40189] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 6,
				},
				[40253] = {
					["classes"] = 1528,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40317] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40381] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 1288,
				},
				[50798] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[46045] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[47920] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 1584,
				},
				[40637] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45868] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51000] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46970] = {
					["classes"] = 1584,
					["points"] = 50,
					["altclasses"] = 134,
				},
				[32736] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45532] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[45115] = {
					["classes"] = 1352,
					["points"] = 40,
					["altclasses"] = 144,
				},
				[39762] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[41835] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45307] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[39230] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[45435] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[48163] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39422] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46051] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[47738] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[42041] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49976] = {
					["classes"] = 144,
					["points"] = 60,
					["altclasses"] = 0,
				},
				[47930] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[45947] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 514,
				},
				[46011] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[50791] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46139] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40062] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[50005] = {
					["classes"] = 1368,
					["points"] = 60,
					["altclasses"] = 128,
				},
				[40190] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 4,
				},
				[40254] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[40318] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40382] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40446] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40574] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50809] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40638] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[29761] = {
					["classes"] = 1092,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51001] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 1584,
				},
				[49320] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50805] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50778] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[45116] = {
					["classes"] = 1496,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[41086] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50793] = {
					["classes"] = 1104,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[45308] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39231] = {
					["classes"] = 208,
					["points"] = 0,
					["altclasses"] = 1288,
				},
				[45436] = {
					["classes"] = 128,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[51148] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39423] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40849] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47739] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[46202] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41205] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47931] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[50042] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[46012] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[47921] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[32289] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40063] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[50362] = {
					["classes"] = 1574,
					["points"] = 60,
					["altclasses"] = 144,
				},
				[40191] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40255] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[40319] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 534,
				},
				[40383] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 516,
				},
				[49464] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40511] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50810] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 1158,
				},
				[40639] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40529] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51002] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[46972] = {
					["classes"] = 328,
					["points"] = 75,
					["altclasses"] = 1040,
				},
				[30242] = {
					["classes"] = 176,
					["points"] = 90,
					["altclasses"] = 0,
				},
				[41768] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45117] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[47916] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[45091] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45309] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 36,
				},
				[39232] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[45437] = {
					["classes"] = 392,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[46350] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[47612] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47676] = {
					["classes"] = 1584,
					["points"] = 0,
					["altclasses"] = 4,
				},
				[47740] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 36,
				},
				[45397] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49333] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[52026] = {
					["classes"] = 532,
					["points"] = 120,
					["altclasses"] = 0,
				},
				[46158] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46013] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[41957] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[32746] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40064] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41903] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40192] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[40256] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40320] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40384] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[40448] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49996] = {
					["classes"] = 1024,
					["points"] = 85,
					["altclasses"] = 144,
				},
				[50811] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51387] = {
					["classes"] = 1584,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[45438] = {
					["classes"] = 1496,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[47613] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[47069] = {
					["classes"] = 134,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[45544] = {
					["classes"] = 16,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[19720] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45118] = {
					["classes"] = 16,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[29763] = {
					["classes"] = 176,
					["points"] = 60,
					["altclasses"] = 0,
				},
				[45246] = {
					["classes"] = 32,
					["points"] = 40,
					["altclasses"] = 512,
				},
				[49468] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39233] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[39297] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45502] = {
					["classes"] = 134,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[39425] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[49484] = {
					["classes"] = 8,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45694] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[52027] = {
					["classes"] = 200,
					["points"] = 120,
					["altclasses"] = 0,
				},
				[49980] = {
					["classes"] = 128,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[45886] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[47954] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[46014] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41772] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30243] = {
					["classes"] = 1092,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[40065] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40257] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40193] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[48445] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40321] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40385] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 36,
				},
				[45338] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49302] = {
					["classes"] = 1666,
					["points"] = 0,
					["altclasses"] = 4,
				},
				[39277] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[42042] = {
					["classes"] = 1590,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49496] = {
					["classes"] = 1538,
					["points"] = 0,
					["altclasses"] = 132,
				},
				[51004] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46974] = {
					["classes"] = 1056,
					["points"] = 75,
					["altclasses"] = 528,
				},
				[32738] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40938] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45119] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[41303] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45247] = {
					["classes"] = 132,
					["points"] = 40,
					["altclasses"] = 1026,
				},
				[45311] = {
					["classes"] = 1670,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49469] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45439] = {
					["classes"] = 1024,
					["points"] = 65,
					["altclasses"] = 144,
				},
				[45503] = {
					["classes"] = 1584,
					["points"] = 40,
					["altclasses"] = 134,
				},
				[47614] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[48160] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45695] = {
					["classes"] = 1536,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39618] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47934] = {
					["classes"] = 1584,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[45887] = {
					["classes"] = 144,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41857] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[48537] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39729] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45677] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 656,
				},
				[40475] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47080] = {
					["classes"] = 1158,
					["points"] = 50,
					["altclasses"] = 0,
				},
				[40194] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 1288,
				},
				[40258] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40322] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40386] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 516,
				},
				[48638] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49465] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 1028,
				},
				[30814] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39235] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39427] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[49995] = {
					["classes"] = 128,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[40281] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[19433] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47949] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45440] = {
					["classes"] = 16,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[29764] = {
					["classes"] = 1092,
					["points"] = 30,
					["altclasses"] = 0,
				},
				[45248] = {
					["classes"] = 134,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[45696] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49470] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39299] = {
					["classes"] = 1072,
					["points"] = 0,
					["altclasses"] = 646,
				},
				[45504] = {
					["classes"] = 528,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[47615] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45632] = {
					["classes"] = 200,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[47743] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[41666] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47186] = {
					["classes"] = 1024,
					["points"] = 75,
					["altclasses"] = 144,
				},
				[47935] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40209] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[46163] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39248] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[30244] = {
					["classes"] = 776,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[45325] = {
					["classes"] = 1056,
					["points"] = 65,
					["altclasses"] = 662,
				},
				[48319] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45874] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40259] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40323] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[40387] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40451] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40515] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45633] = {
					["classes"] = 532,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[45869] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[45287] = {
					["classes"] = 264,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[51006] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[46976] = {
					["classes"] = 1496,
					["points"] = 50,
					["altclasses"] = 0,
				},
				[39236] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[47104] = {
					["classes"] = 48,
					["points"] = 50,
					["altclasses"] = 1540,
				},
				[46988] = {
					["classes"] = 1024,
					["points"] = 75,
					["altclasses"] = 144,
				},
				[45185] = {
					["classes"] = 1024,
					["points"] = 65,
					["altclasses"] = 144,
				},
				[45249] = {
					["classes"] = 528,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[45313] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49471] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45441] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[45505] = {
					["classes"] = 128,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[47616] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[47680] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47744] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[47808] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 514,
				},
				[45140] = {
					["classes"] = 128,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[49983] = {
					["classes"] = 134,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[47610] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[47194] = {
					["classes"] = 328,
					["points"] = 75,
					["altclasses"] = 1040,
				},
				[41000] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[25127] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[48256] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39293] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40196] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40260] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[40324] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40388] = {
					["classes"] = 1536,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[48640] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39420] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[25415] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[48252] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47233] = {
					["classes"] = 1538,
					["points"] = 90,
					["altclasses"] = 132,
				},
				[51007] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[45378] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[47041] = {
					["classes"] = 1232,
					["points"] = 50,
					["altclasses"] = 0,
				},
				[47105] = {
					["classes"] = 134,
					["points"] = 50,
					["altclasses"] = 0,
				},
				[40207] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45186] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[45250] = {
					["classes"] = 1158,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45314] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[39237] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[39760] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[42116] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[19722] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45634] = {
					["classes"] = 1314,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[47745] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[47809] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39557] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47937] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49319] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46018] = {
					["classes"] = 548,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46142] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50240] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40069] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47915] = {
					["classes"] = 1584,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40197] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1024,
				},
				[40261] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40325] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1024,
				},
				[39759] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40453] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40517] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40378] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[51584] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[45708] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51008] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[45093] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47042] = {
					["classes"] = 1158,
					["points"] = 50,
					["altclasses"] = 0,
				},
				[47106] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[49489] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47234] = {
					["classes"] = 134,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[45251] = {
					["classes"] = 134,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[45315] = {
					["classes"] = 48,
					["points"] = 40,
					["altclasses"] = 6,
				},
				[39724] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[45443] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[45507] = {
					["classes"] = 1158,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[47618] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45635] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47746] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[47810] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 2,
				},
				[45452] = {
					["classes"] = 128,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[47938] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[49482] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41925] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45699] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[49985] = {
					["classes"] = 1158,
					["points"] = 60,
					["altclasses"] = 0,
				},
				[49474] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[29766] = {
					["classes"] = 176,
					["points"] = 60,
					["altclasses"] = 0,
				},
				[40198] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40262] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40326] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45237] = {
					["classes"] = 1024,
					["points"] = 65,
					["altclasses"] = 144,
				},
				[40454] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[19371] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47923] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[41286] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46148] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51009] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[46979] = {
					["classes"] = 1368,
					["points"] = 50,
					["altclasses"] = 0,
				},
				[19435] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47107] = {
					["classes"] = 1056,
					["points"] = 75,
					["altclasses"] = 528,
				},
				[29734] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47235] = {
					["classes"] = 328,
					["points"] = 75,
					["altclasses"] = 1040,
				},
				[45252] = {
					["classes"] = 128,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[45316] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[39239] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45444] = {
					["classes"] = 528,
					["points"] = 65,
					["altclasses"] = 134,
				},
				[42118] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47619] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47683] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[47747] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[47811] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40590] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49986] = {
					["classes"] = 134,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[48714] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 2,
				},
				[41926] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39424] = {
					["classes"] = 1048,
					["points"] = 0,
					["altclasses"] = 320,
				},
				[50242] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40071] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[47939] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46340] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40263] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40327] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[24304] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40455] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[48446] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40206] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39421] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49231] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[47700] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[33809] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[48074] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47108] = {
					["classes"] = 134,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[39240] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[47946] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[45253] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[45317] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49475] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47947] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[39725] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45235] = {
					["classes"] = 1496,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45637] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45701] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[47812] = {
					["classes"] = 144,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30236] = {
					["classes"] = 176,
					["points"] = 95,
					["altclasses"] = 0,
				},
				[45893] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[41863] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46021] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[48132] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49987] = {
					["classes"] = 1072,
					["points"] = 85,
					["altclasses"] = 646,
				},
				[39193] = {
					["classes"] = 192,
					["points"] = 0,
					["altclasses"] = 1304,
				},
				[39310] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 1288,
				},
				[46341] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40264] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 6,
				},
				[40328] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41293] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45892] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[48708] = {
					["classes"] = 264,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[47953] = {
					["classes"] = 544,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[32303] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39196] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[41767] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40840] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[19436] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45157] = {
					["classes"] = 1584,
					["points"] = 40,
					["altclasses"] = 134,
				},
				[43346] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[29767] = {
					["classes"] = 1092,
					["points"] = 60,
					["altclasses"] = 0,
				},
				[45254] = {
					["classes"] = 2,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45318] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 1024,
				},
				[39241] = {
					["classes"] = 1304,
					["points"] = 0,
					["altclasses"] = 192,
				},
				[35211] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45510] = {
					["classes"] = 128,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[47621] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[45638] = {
					["classes"] = 200,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[45702] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[39369] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[19852] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45894] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40520] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46022] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[48133] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30247] = {
					["classes"] = 776,
					["points"] = 80,
					["altclasses"] = 0,
				},
				[45871] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39390] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[46342] = {
					["classes"] = 548,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40265] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 36,
				},
				[40329] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[39399] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[39589] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49476] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45141] = {
					["classes"] = 1056,
					["points"] = 65,
					["altclasses"] = 528,
				},
				[47727] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40205] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[51012] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 1584,
				},
				[47750] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39242] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 1288,
				},
				[30249] = {
					["classes"] = 1092,
					["points"] = 80,
					["altclasses"] = 0,
				},
				[41033] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45872] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 36,
				},
				[45255] = {
					["classes"] = 16,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45319] = {
					["classes"] = 1158,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[49477] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45447] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45511] = {
					["classes"] = 328,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[47622] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39498] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45703] = {
					["classes"] = 1088,
					["points"] = 0,
					["altclasses"] = 408,
				},
				[47814] = {
					["classes"] = 546,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[37643] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47942] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[41865] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45331] = {
					["classes"] = 678,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39306] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47945] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[40074] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45548] = {
					["classes"] = 1024,
					["points"] = 65,
					["altclasses"] = 144,
				},
				[46343] = {
					["classes"] = 1158,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[40266] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40330] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[29757] = {
					["classes"] = 176,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40458] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40522] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49644] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45895] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[45542] = {
					["classes"] = 132,
					["points"] = 65,
					["altclasses"] = 2,
				},
				[39426] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[19405] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45450] = {
					["classes"] = 132,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[41292] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40200] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[32285] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45256] = {
					["classes"] = 1536,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45320] = {
					["classes"] = 134,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[39243] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[39307] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[45530] = {
					["classes"] = 1496,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[47623] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45640] = {
					["classes"] = 1314,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[45704] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47815] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[45832] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[47943] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39188] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46024] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 1536,
				},
				[45384] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30248] = {
					["classes"] = 176,
					["points"] = 80,
					["altclasses"] = 0,
				},
				[40075] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 560,
				},
				[39282] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46344] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40267] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40331] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40395] = {
					["classes"] = 1232,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46985] = {
					["classes"] = 128,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[45636] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[37193] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49992] = {
					["classes"] = 1352,
					["points"] = 100,
					["altclasses"] = 16,
				},
				[47617] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[30280] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[29765] = {
					["classes"] = 776,
					["points"] = 60,
					["altclasses"] = 0,
				},
				[40201] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[49479] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39756] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[45193] = {
					["classes"] = 134,
					["points"] = 40,
					["altclasses"] = 1024,
				},
				[45257] = {
					["classes"] = 328,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45321] = {
					["classes"] = 128,
					["points"] = 35,
					["altclasses"] = 0,
				},
				[39244] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39308] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[40204] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47624] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45641] = {
					["classes"] = 200,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[47752] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47816] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 2,
				},
				[37645] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49991] = {
					["classes"] = 328,
					["points"] = 85,
					["altclasses"] = 1040,
				},
				[39298] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46025] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45224] = {
					["classes"] = 1584,
					["points"] = 40,
					["altclasses"] = 134,
				},
				[47944] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30901] = {
					["classes"] = 36,
					["points"] = 100,
					["altclasses"] = 528,
				},
				[39296] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 36,
				},
				[46345] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40268] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40332] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40396] = {
					["classes"] = 392,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40460] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50759] = {
					["classes"] = 562,
					["points"] = 0,
					["altclasses"] = 132,
				},
				[19003] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40203] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45187] = {
					["classes"] = 16,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[51015] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40844] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[32754] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[32295] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[33102] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45362] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45258] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[45322] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39245] = {
					["classes"] = 150,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39309] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[45514] = {
					["classes"] = 328,
					["points"] = 65,
					["altclasses"] = 1040,
				},
				[47625] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45642] = {
					["classes"] = 532,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[45639] = {
					["classes"] = 532,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[39727] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[32385] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39757] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50056] = {
					["classes"] = 328,
					["points"] = 85,
					["altclasses"] = 1040,
				},
				[25408] = {
					["classes"] = 2047,
					["points"] = 20,
					["altclasses"] = 0,
				},
				[49989] = {
					["classes"] = 134,
					["points"] = 60,
					["altclasses"] = 1584,
				},
				[32296] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30281] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39732] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46346] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[40269] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40333] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[40296] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[40526] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1024,
				},
				[50760] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[31091] = {
					["classes"] = 532,
					["points"] = 100,
					["altclasses"] = 0,
				},
				[29754] = {
					["classes"] = 176,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[35198] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49988] = {
					["classes"] = 528,
					["points"] = 85,
					["altclasses"] = 134,
				},
				[39723] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[32744] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47114] = {
					["classes"] = 1536,
					["points"] = 90,
					["altclasses"] = 0,
				},
				[39294] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[47242] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45259] = {
					["classes"] = 16,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[45679] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[39246] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45451] = {
					["classes"] = 1368,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45515] = {
					["classes"] = 1368,
					["points"] = 40,
					["altclasses"] = 128,
				},
				[41927] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45643] = {
					["classes"] = 1314,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[45707] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40570] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30237] = {
					["classes"] = 1092,
					["points"] = 95,
					["altclasses"] = 0,
				},
				[39758] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39408] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[46027] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41997] = {
					["classes"] = 8,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46155] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45419] = {
					["classes"] = 8,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39228] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46347] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40270] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[40334] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40398] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[30246] = {
					["classes"] = 1092,
					["points"] = 80,
					["altclasses"] = 0,
				},
				[50761] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 512,
				},
				[25420] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45700] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 2,
				},
				[39495] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51017] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[47043] = {
					["classes"] = 1584,
					["points"] = 50,
					["altclasses"] = 134,
				},
				[47051] = {
					["classes"] = 328,
					["points"] = 75,
					["altclasses"] = 1040,
				},
				[47115] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46339] = {
					["classes"] = 548,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46019] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[45260] = {
					["classes"] = 1024,
					["points"] = 65,
					["altclasses"] = 144,
				},
				[45324] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[39247] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[39311] = {
					["classes"] = 1104,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[29762] = {
					["classes"] = 776,
					["points"] = 60,
					["altclasses"] = 0,
				},
				[47627] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45644] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47755] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47184] = {
					["classes"] = 528,
					["points"] = 75,
					["altclasses"] = 134,
				},
				[47933] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[49994] = {
					["classes"] = 328,
					["points"] = 85,
					["altclasses"] = 1040,
				},
				[45399] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46210] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30245] = {
					["classes"] = 176,
					["points"] = 80,
					["altclasses"] = 0,
				},
				[30250] = {
					["classes"] = 776,
					["points"] = 80,
					["altclasses"] = 0,
				},
				[41668] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45698] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46348] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40271] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 1288,
				},
				[40335] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 264,
				},
				[40399] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40463] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50762] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[40591] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45697] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47679] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40783] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40847] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47052] = {
					["classes"] = 134,
					["points"] = 75,
					["altclasses"] = 0,
				},
				[47116] = {
					["classes"] = 1158,
					["points"] = 50,
					["altclasses"] = 0,
				},
				[45133] = {
					["classes"] = 1368,
					["points"] = 40,
					["altclasses"] = 128,
				},
				[46144] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45261] = {
					["classes"] = 548,
					["points"] = 80,
					["altclasses"] = 0,
				},
				[41231] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49483] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45453] = {
					["classes"] = 1056,
					["points"] = 65,
					["altclasses"] = 528,
				},
				[49322] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49982] = {
					["classes"] = 560,
					["points"] = 60,
					["altclasses"] = 1356,
				},
				[45645] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45709] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[39632] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47611] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47948] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49491] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39252] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1024,
				},
				[48603] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46132] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40080] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41958] = {
					["classes"] = 256,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40208] = {
					["classes"] = 514,
					["points"] = 0,
					["altclasses"] = 132,
				},
				[40272] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[40336] = {
					["classes"] = 392,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40400] = {
					["classes"] = 132,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47742] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[39234] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40592] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51132] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40720] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40784] = {
					["classes"] = 2,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47919] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 528,
				},
				[47053] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[40976] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45134] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47741] = {
					["classes"] = 544,
					["points"] = 0,
					["altclasses"] = 4,
				},
				[45262] = {
					["classes"] = 132,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45326] = {
					["classes"] = 1158,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[39249] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45454] = {
					["classes"] = 528,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[39295] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 1288,
				},
				[45646] = {
					["classes"] = 1314,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41076] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47956] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[42006] = {
					["classes"] = 8,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39761] = {
					["classes"] = 1056,
					["points"] = 0,
					["altclasses"] = 662,
				},
				[49949] = {
					["classes"] = 1718,
					["points"] = 60,
					["altclasses"] = 0,
				},
				[48077] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45332] = {
					["classes"] = 1368,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[32298] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[30283] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39530] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50444] = {
					["classes"] = 4,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40273] = {
					["classes"] = 1352,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[40337] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40401] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 16,
				},
				[47955] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50764] = {
					["classes"] = 1584,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[47917] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49977] = {
					["classes"] = 1496,
					["points"] = 60,
					["altclasses"] = 0,
				},
				[52025] = {
					["classes"] = 1314,
					["points"] = 120,
					["altclasses"] = 0,
				},
				[47951] = {
					["classes"] = 646,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46990] = {
					["classes"] = 16,
					["points"] = 65,
					["altclasses"] = 128,
				},
				[47054] = {
					["classes"] = 1368,
					["points"] = 50,
					["altclasses"] = 128,
				},
				[50790] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47182] = {
					["classes"] = 1368,
					["points"] = 50,
					["altclasses"] = 128,
				},
				[50784] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[45263] = {
					["classes"] = 1718,
					["points"] = 40,
					["altclasses"] = 0,
				},
				[45327] = {
					["classes"] = 512,
					["points"] = 80,
					["altclasses"] = 36,
				},
				[39250] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[32752] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[41235] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45647] = {
					["classes"] = 200,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45711] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[39634] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49952] = {
					["classes"] = 528,
					["points"] = 85,
					["altclasses"] = 134,
				},
				[47950] = {
					["classes"] = 512,
					["points"] = 0,
					["altclasses"] = 36,
				},
				[50061] = {
					["classes"] = 1232,
					["points"] = 60,
					["altclasses"] = 264,
				},
				[46031] = {
					["classes"] = 48,
					["points"] = 0,
					["altclasses"] = 518,
				},
				[49960] = {
					["classes"] = 134,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[42065] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46052] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45330] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40210] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40274] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40338] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 1288,
				},
				[40402] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50034] = {
					["classes"] = 512,
					["points"] = 100,
					["altclasses"] = 36,
				},
				[50782] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[47976] = {
					["classes"] = 128,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50774] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[47952] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51021] = {
					["classes"] = 32,
					["points"] = 0,
					["altclasses"] = 646,
				},
				[49968] = {
					["classes"] = 1368,
					["points"] = 60,
					["altclasses"] = 0,
				},
				[47055] = {
					["classes"] = 1024,
					["points"] = 0,
					["altclasses"] = 144,
				},
				[47983] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47183] = {
					["classes"] = 134,
					["points"] = 50,
					["altclasses"] = 1584,
				},
				[49294] = {
					["classes"] = 2047,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45264] = {
					["classes"] = 134,
					["points"] = 65,
					["altclasses"] = 0,
				},
				[49964] = {
					["classes"] = 134,
					["points"] = 85,
					["altclasses"] = 0,
				},
				[39251] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[45456] = {
					["classes"] = 1584,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[39379] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[45648] = {
					["classes"] = 532,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45712] = {
					["classes"] = 134,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39141] = {
					["classes"] = 1158,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[21904] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[39763] = {
					["classes"] = 1040,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50062] = {
					["classes"] = 328,
					["points"] = 85,
					["altclasses"] = 1040,
				},
				[48079] = {
					["classes"] = 64,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[46096] = {
					["classes"] = 1496,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[49331] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[47193] = {
					["classes"] = 1232,
					["points"] = 50,
					["altclasses"] = 0,
				},
				[47656] = {
					["classes"] = 0,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[51365] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[40275] = {
					["classes"] = 528,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[40339] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40403] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[45423] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				},
				[40531] = {
					["classes"] = 1718,
					["points"] = 0,
					["altclasses"] = 0,
				},
				[50025] = {
					["classes"] = 1584,
					["points"] = 0,
					["altclasses"] = 134,
				},
				[50030] = {
					["classes"] = 16,
					["points"] = 0,
					["altclasses"] = 128,
				},
				[49234] = {
					["classes"] = 328,
					["points"] = 0,
					["altclasses"] = 1040,
				}
}