<?php
header('Content-Type: text/html; charset=utf-8');  
define('EQDKP_INC', true);
define('IN_ADMIN', true);
define('PLUGIN', 'ctrt');

$eqdkp_root_path = './../../';
$root_path = './../../../';
$admin_path = $eqdkp_root_path . "admin/index.php?s=/";
require('Morgfunc2.php');

function CommonOutput() {
	global $data, $table_prefix, $events, $poolname, $eventlist, $aliaslist, $rankidvalue, $rankids;
	if ($aliaslist) {
		//echo "Aliases";
		$data .= "Aliases = {\n\t\t";
		$c = 0;
		foreach ($aliaslist as $alias=>$member) {
			if ($c > 0) $data .= ",\n\t\t";
			//$alias = utf8_encode($alias);
			//$member = utf8_encode($member);
			$data .= "[\"$alias\"] = \"$member\"";
			$c++;
		}
	} else $data .= "Aliases = {";
	if (!empty($eventlist)) {
		//echo "Events";
		$data .= "\n\t},\n\tEvents = {\n\t\t";
		$c = 0;
		foreach ($eventlist as $event => $eventdata) {
			if (empty($events) or $events[$event]['pool'] == $poolname) {
				//$event = utf8_encode($event);
				if ($c > 0) $data .= ",\n\t\t";
				$data .= "[\"$event\"] = {id = {$eventdata['event_id']},value = {$eventdata['event_value']}}";
				$c++;
			}
		}
	} else $data .= "\n\t},\n\tEvents = {";
	if (!empty($rankids) and $rankidvalue == "2") {
		//echo "Ranks";
		$data .= "\n\t},\n\tRanks = {\n\t\t";
		$c = 1;
		foreach ($rankids as $id => $rank) {
			if (empty($events) or $events[$event]['pool'] == $poolname) {
				//$event = utf8_encode($event);
				if ($c > 1) $data .= ",\n\t\t";
				$data .= "[\"$c\"] = \"$rank\"";
				$c++;
			}
		}
	} 
	$data .= "\n\t},";
	$data .= "\n}\n";
	$SaveLoc = 'DKPInfo.lua';
	if (is_writable($SaveLoc)) {
		if (!$handle = fopen($SaveLoc, 'w')) {
       		echo "Cannot open file ($SaveLoc)";
       		exit;
   		} else //echo "opened file $SaveLoc";
   		if (mb_detect_encoding($data, "auto", true) != "UTF-8") { 
			if (fwrite($handle, utf8_encode($data)) === FALSE) {
       			//echo "Cannot write to file ($SaveLoc)";
			exit;
			} //else echo "Wrote to file $SaveLoc";
		} else {
			if (fwrite($handle, $data) === FALSE) {
       			//echo "Cannot write to file ($SaveLoc)";
			exit;
			} //else echo "Wrote to file $SaveLoc";
		}
		fclose($handle);
	} else echo "The file $SaveLoc is not writable";
}
	
function FetchAliasSimple($eqdkp, $table_prefix, $link) {
	if (mysql_select_db($eqdkp, $link)) {
		$result = mysql_query("SELECT alias_id, alias_name, alias_member_id, member_name, member_id
    					FROM " . $table_prefix . 'ctrt_aliases' . ", " . $table_prefix . 'members' . 
    					" WHERE member_id = alias_member_id");
    	$temp = array();
	if ($result) {
		while ($row = mysql_fetch_array($result)) {
			$temp[$row["alias_name"]] = $row["member_name"];
			}
		}
		return $temp;
	} else mysql_error();
}
	
function FetchAllRanks($eqdkp, $table_prefix, $link) {
	if (mysql_select_db($eqdkp, $link)) {
		$result = mysql_query("SELECT rank_id, rank_name FROM " . $table_prefix . 'member_ranks');
    	$temp = array();
	if ($result) {
		while ($row = mysql_fetch_array($result)) {
			$rankid = $row["rank_id"];
			if ($rankid != 0) $temp[$rankid] = $row["rank_name"];
			}
		}
		return $temp;
	} else mysql_error();
}

$retrieve = $_REQUEST['retrieve'];
$data = '';
$timezones = array('Pacific'=>'America/Vancouver', 'Eastern'=>'America/New_York','Central'=>'America/Regina','Mountain'=>'America/Phoenix','AEST'=>'Australia/Melbourne', 'CET'=>'Europe/Berlin');
$php_version =  phpversion();
if ($retrieve) {
	//echo "Retrieved...";
	$eqDKP = $_REQUEST['eqDKP'];
	$DBName = $_REQUEST['DBName'];
	$tzone = $_REQUEST['tzone'];
	$rankidvalue = $_REQUEST['rankidvalue'];
	$rankidonly = $_REQUEST['rankidonly'];
	for ($c = 1; $c <= 5; $c++) {
		setcookie("DKPcook$c", $eqDKP[$c], time()+3600*24*365);
		setcookie("DBNamecook$c", $DBName[$c], time()+3600*24*365);
	}
	setcookie("TZonecook", $tzone, time()+3600*24*365);
	setcookie("rankidvaluecook", $rankidvalue, time()+3600*24*365);
	setcookie("rankidonlycook", $rankidonly, time()+3600*24*365);
	$DKP = array();
	$c = 1;
	while (!empty($eqDKP[$c])) {
		$DKP[$c] = $eqDKP[$c];
		$c++;
	}
	$dkpnum = 1;
	if ($tzone and  $php_version > 5)  date_default_timezone_set($timezones[$tzone]);
	foreach ($DKP as $i => $pool) {
		//echo $pool;
		if ($pool == "-") {
			$pool = "";
			$root_path = './../../';
		}
		require($root_path . $pool . '/config.php');
		$link = CreateLink();
		define('CTRT_ALIASES_TABLE', ($table_prefix . 'ctrt_aliases'));
		if (!mysql_select_db($dbname, $link)) {
			die('Could not connect: ' . $dbname . mysql_error());
		} //else echo "Connected " . $dbname;
		$events = array();
		$pools = array();
		$eventlist = FetchAllEvents($dbname, $table_prefix, $link);
		$aliaslist = FetchAliasSimple($dbname, $table_prefix, $link);
		$classids = FetchAllClasses($dbname, $table_prefix, 1, $link);
		if ($rankidvalue != 1) $rankids = FetchAllRanks($dbname, $table_prefix, $link);
		$eqdkpplus = mysql_query("SELECT * FROM " . $table_prefix . "plus_config WHERE config_name = 'pk_multidkp'");
		if ($eqdkpplus) {
			//echo "plus";
			$multipool = mysql_fetch_array($eqdkpplus);
			$singlepool = 0;
			if ($multipool['config_value'] == 1) {
				$result = mysql_query("SELECT * FROM " . $table_prefix . 'multidkp');
				while ($row = mysql_fetch_array($result)) {
					$pools[$row['multidkp_id']] = $row['multidkp_name'];
				}
				$result = mysql_query("SELECT * FROM " . $table_prefix . 'multidkp2event');
				while ($row = mysql_fetch_array($result)) {
					$events[$row['multidkp2event_eventname']] = array(	'pool'=>$pools[$row['multidkp2event_multi_id']], 
												'value'=>$eventlist[$row['multidkp2event_eventname']]['event_value']);
				}
			} else {
				if (!$DBName[1]) $DBName[1] = "DKP";
				$pools[1] = $DBName[1];
				$singlepool = true;
			}
			foreach ($pools as $pluspoolnum => $poolname) {
				$data .= "MorgDKP2_DKP$dkpnum = {\n\tTimestamp = " . strftime("%Y%m%d%H%M") . ",\n\tPool = \"$poolname\",\n\teqdkpsite = \"$dbname\",\n\tprefix = \"$table_prefix\",\n\tPoints = {\n\t\t"; 
				$result = mysql_query("SELECT * FROM " . $table_prefix . 'members' . " ORDER BY member_name");
				$added = 0;
				while ($row = mysql_fetch_array($result)) {
					if ($added) $data .= ",\n\t\t";
					$member = $row['member_name'];
					$sql = "SELECT " . $table_prefix . 'raids' .".raid_name, SUM(raid_value) FROM " . 
						$table_prefix . 'raid_attendees' . " LEFT JOIN " . $table_prefix . 'raids' . " ON ". $table_prefix . 'raid_attendees' . 
						".raid_id=" . $table_prefix . 'raids' . ".raid_id WHERE ". $table_prefix . 'raid_attendees' . ".member_name = '" .
						$member . "' GROUP by " . $table_prefix . 'raids' . ".raid_name";
					$earnedresult = mysql_query($sql);
					$earned = 0;
					while ($earnedrow = mysql_fetch_array($earnedresult)) {
						if ($singlepool or $events[$earnedrow['raid_name']]['pool'] == $poolname) $earned += $earnedrow[1];
					}
					$sql = "SELECT ". $table_prefix . 'raids' . ".raid_name, SUM(". $table_prefix . 'items' .".item_value) FROM " .
						$table_prefix . 'items' . "  LEFT JOIN " . $table_prefix . 'raids' . " ON " . $table_prefix . 'items' . ".raid_id=" .
						$table_prefix . 'raids' . ".raid_id WHERE " . $table_prefix . 'items' . ".item_buyer = '" . $member .
						"' GROUP by " . $table_prefix . 'raids' . ".raid_name;";
					$spentresult = mysql_query($sql);
					$spent = 0;
					while ($spentrow = mysql_fetch_array($spentresult)) {
						if ($singlepool or $events[$spentrow['raid_name']]['pool'] == $poolname) $spent += $spentrow[1];
					}
					$adjust = 0;
					$sql = "SELECT adjustment_reason, adjustment_value, raid_name FROM " . $table_prefix . 'adjustments' . 
						" WHERE member_name = '" . $member . "';";
					$adjresult = mysql_query($sql);
					while ($adjrow = mysql_fetch_array($adjresult)) {
						if ($singlepool or $events[$adjrow['raid_name']]['pool'] == $poolname) $adjust += $adjrow['adjustment_value'];
					}
					$balance = $earned - $spent + $adjust;
					$added = 0;
					if (!isset($aliaslist) or !$aliaslist[$member]) {
						//echo $member;
						$class = $classids[$row['member_class_id']];
						//$class = str_replace (" ", "", $classid);
						$currentrankid = $rankids[$row['member_rank_id']];
						if ($rankidvalue != "3" or ($rankidvalue == "3" and $currentrankid == $rankidonly)) {
							$data .= "[\"$member\"] = {earn = $earned,spent = $spent,adj = $adjust,bal = $balance,class = \"$class\"";
							if ($rankidvalue == "2") {
								if ($currentrankid) {
									$data .= ",rank = \"$currentrankid\"";
								} else {
									$data .= ",rank = \"NONE\"";
								}
							}
							$data .= "}";
							$added = true;
						}
					}
				}
				$data .= "\n\t},\n\t";
				$dkpnum++;
				CommonOutput();
			}
		} else {
			//echo "Normal";
			$data .= "MorgDKP2_DKP$dkpnum = {\n\tTimestamp = " . strftime("%Y%m%d%H%M") . ",\n\tPool = \"$DBName[$i]\",\n\teqdkpsite = \"$dbname\",\n\tprefix = \"$table_prefix\",\n\tPoints = {\n\t\t"; 
			$result = mysql_query("SELECT * FROM " . $table_prefix . 'members' . " ORDER BY member_name");
			$added = 0;
			while ($row = mysql_fetch_array($result)) {
				if ($added) $data .= ",\n\t\t";
				$balance = $row['member_earned'] - $row['member_spent'] + $row['member_adjustment'];
				$added = 0;
				$member = $row['member_name'];
				if (!isset($aliaslist) or !$aliaslist[$member]) {
					//echo "H" . $rankidvalue;
					$class = $classids[$row['member_class_id']];
					//$class = str_replace (" ", "", $classid);
					$currentrankid = $rankids[$row['member_rank_id']];
					if ($rankidvalue != "3" or ($rankidvalue == "3" and $currentrankid == $rankidonly)) {
						$data .= "[\"$member\"] = {earn = {$row['member_earned']},spent = {$row['member_spent']},adj = {$row['member_adjustment']},bal = $balance,class = \"$class\"";
						if ($rankidvalue == "2") {
							if ($currentrankid) {
								$data .= ",rank = \"$currentrankid\"";
							} else {
								$data .= ",rank = \"NONE\"";
							}
						}
						$data .= "}";
						$added = true;
					}
				}
			}
			$data .= "\n\t},\n\t";
			$dkpnum++;
			CommonOutput();
		}
	}
}
?>


<html>
<head>
<style type="text/css">
h1 {text-align: right; margin-right: 50px; font-size: 12px}
</style>
</head>
<body style="font-family: Arial; font-size: 16px; background-color: #101030; color: #FDFDFD; padding-left: 50px; padding-top: 20px;">
<form method="post">
<input type="hidden" name="retrieve" value="1">
<h1><a href="<?php echo $admin_path?>" target="_self" style="color: #FDFDFD;">Return to eqDKP Admin</a></h1>
<b><u>MorgDKP2 Export v3.0</b></u>
<br>
<br>
<?php if ($php_version > 5) {?>
Please select the timezone of your WOW server:
	<?php if (isset($_COOKIE['TZonecook'])) { ?>
		<input type="radio" name="tzone" checked="yes" value="<?php echo $_COOKIE['TZonecook']?>"><?php echo $_COOKIE['TZonecook']?>
	<?php }
	foreach ($timezones as $tzonename => $string) {
		if (!isset($_COOKIE['TZonecook']) or $tzonename != $_COOKIE['TZonecook']) {?>
			<input type="radio" name="tzone" value="<?php echo $tzonename?>"><?php echo $tzonename?> 
		<?php  }
	}?>
<br>No selection will use the timezone set on your website which may or may not be accurate.<br><br>
<?php }?>
Export member ranks?
<input type="radio" name="rankidvalue" <?php if ($_COOKIE['rankidvaluecook'] == "1") echo "checked ";?> value="1">Ignore ranks<input type="radio" name="rankidvalue" <?php if ($_COOKIE['rankidvaluecook'] == "2") echo "checked ";?> value="2">Use all ranks<input type="radio" name="rankidvalue" <?php if ($_COOKIE['rankidvaluecook'] == "3") echo "checked ";?> value="3">Only export: <input name="rankidonly" value="<?php echo $_COOKIE['rankidonlycook']?>">
<br>
<br>
Please enter the directory names of up to 5 eqDKP installs (pools) to download.<br>
Example: http://sodalityoftheconstant.com/<b>aqdkp</b>/listmembers.php? (ie enter aqdkp and AQ40 below)<br>
<b><u>NOTE:</b></u> eqdkp+ users only need to enter the directory name.  Pool names will be the same as you set up on your website IF you are using multiple pools.  All pools will be done automatically.<br>
<b><u>NOTE2:</b></u> If you are using a eqdkp server in the root directory enter '-' for the directory name.<br><br>
1. <input name="eqDKP[1]" value="<?php echo $_COOKIE['DKPcook1']?>">&nbsp;&nbsp;&nbsp;In Game Database Name =&nbsp;<input name="DBName[1]" value="<?php echo $_COOKIE['DBNamecook1']?>"><br>
2. <input name="eqDKP[2]" value="<?php echo $_COOKIE['DKPcook2']?>">&nbsp;&nbsp;&nbsp;In Game Database Name =&nbsp;<input name="DBName[2]" value="<?php echo $_COOKIE['DBNamecook2']?>"><br>
3. <input name="eqDKP[3]" value="<?php echo $_COOKIE['DKPcook3']?>">&nbsp;&nbsp;&nbsp;In Game Database Name =&nbsp;<input name="DBName[3]" value="<?php echo $_COOKIE['DBNamecook3']?>"><br>
4. <input name="eqDKP[4]" value="<?php echo $_COOKIE['DKPcook4']?>">&nbsp;&nbsp;&nbsp;In Game Database Name =&nbsp;<input name="DBName[4]" value="<?php echo $_COOKIE['DBNamecook4']?>"><br>
5. <input name="eqDKP[5]" value="<?php echo $_COOKIE['DKPcook5']?>">&nbsp;&nbsp;&nbsp;In Game Database Name =&nbsp;<input name="DBName[5]" value="<?php echo $_COOKIE['DBNamecook5']?>">
<br>
<br>
<br><textarea style="width: 1000px; height: 140px;" name="mydata" onClick="select();"><?php echo $data ?></textarea>
<br>
<br>
<input type="submit" value="Export EQdkp Data"><br>
<br>
<br><a href="DKPInfo.lua" target="_self" style="color: #FDFDFD; margin-left: 50px; font-size: 18px">Click or right-click this link and save to WOW/Interface/Addons/MorgDKP2</a>
</form>
</body>
</html>