<?php
header('Content-Type: text/html; charset=utf-8');  
require('./../../config.php');
	
function xmlstringtoarray($xml) {
	$return = array(); 
	$stack = array();
	$list = array();
	preg_match_all("/<(.*?)>/", $xml, $opentag);
	preg_match_all("/>(.*?)</", $xml, $data);
	
	foreach($opentag[1] as $tagnum => $tagname) {
		if (preg_match("/\//", $tagname)) {
			if (preg_match("/\/key/", $tagname)) $tagname = preg_replace("/key/", "", $tagname);
			$list[] = array('tag'=>$tagname, 'data'=>'', 'status'=>"closed");
		} else {
			if (preg_match("/key/", $tagname)) $tagname = preg_replace("/key/", "", $tagname);
			if ($data[1][$tagnum] != '') {
				$list[] = array('tag'=>$tagname, 'data'=>$data[1][$tagnum], 'status'=>"complete");
			} else {
				$list[] = array('tag'=>$tagname, 'data'=>'', 'status'=>"open");
			}
		}
	}
	
	$lastclosed = "";
	foreach($list as $val) {
		if($val['status'] == "open") {
			array_push($stack, $val['tag']);
		} elseif($val['status'] == "closed") {
			if ($lastclosed != $val['tag']) {
				array_pop($stack);
				$lastclosed = "/" . $val['tag'];
			}
		} elseif($val['status'] == "complete") {
			array_push($stack, $val['tag']);
			setArrayValue($return, $stack, $val['data']);
			array_pop($stack);
			$lastclosed = "/" . $val['tag'];
		}
	}
	return $return;
}

function setArrayValue(&$array, $stack, $value) {
	if ($stack) {
		$key = array_shift($stack);
		setArrayValue($array[$key], $stack, $value);
		return $array;
	} else {
		$array = $value;
	}
}

function CreateLink() {
	global $dbhost, $dbuser, $dbpass;
	
	$link = mysql_connect($dbhost, $dbuser, $dbpass);
	if (!$link) die('Could not connect: ' . mysql_error());
	if (function_exists('mysql_set_charset')) {
		mysql_set_charset('utf8',$link);
	} else {
		 //mysql_query('SET NAMES utf8', $link);
	}
	return $link;
}

function FetchAliases($eqdkp, $table_prefix, $name) {
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$result = mysql_query("SELECT alias_id, alias_name, alias_member_id, member_name, member_id
    					FROM " . $table_prefix . 'ctrt_aliases' . ", " . $table_prefix . 'members' . 
    					" WHERE member_id = alias_member_id AND member_name = '$name'");
    		$temp = array();
		if ($result) {
			while ($row = mysql_fetch_array($result)) {
				$temp[] = array("alias_id"=>$row["alias_id"],
	    			            	"alias_name"=>stripslashes($row["alias_name"]),
						"alias_member_id"=>$row["alias_member_id"],
						"member_name"=>stripslashes($row["member_name"]),
						"member_id"=>$row["member_id"]);
			}
		}
		return $temp;
	} else mysql_error();
}

function FetchAllAliases($eqdkp, $table_prefix) {
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$result = mysql_query("SELECT alias_id, alias_name, alias_member_id, member_name, member_id
    					FROM " . $table_prefix . 'ctrt_aliases' . ", " . $table_prefix . 'members' . 
    					" WHERE member_id = alias_member_id");
    	$temp = array();
		if ($result) {
			while ($row = mysql_fetch_array($result)) {
				$temp[] = array("alias_id"=>$row["alias_id"],
	    					"alias_name"=>stripslashes($row["alias_name"]),
						"alias_member_id"=>$row["alias_member_id"],
						"member_name"=>stripslashes($row["member_name"]),
						"member_id"=>$row["member_id"]);
			}
		}
		return $temp;
	} else mysql_error();
}

function CreateAliasDB($eqdkp, $table_prefix) {
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$result = mysql_query("CREATE TABLE IF NOT EXISTS `". $table_prefix . 'ctrt_aliases' . "` (
						`alias_id` smallint unsigned NOT NULL auto_increment,
						`alias_member_id` mediumint NOT NULL,
						`alias_name` varchar(50) NOT NULL,
						PRIMARY KEY  (`alias_id`));");
		if ($result) return true;
		return false;
	} else mysql_error();
}

function CheckAlias($names, $eqdkp, $table_prefix) {
	$aliases = FetchAllAliases($eqdkp, $table_prefix);
	if (empty($aliases) || empty($names) ) return $names;
	foreach ($names as $num => $alt) {
		$alt = rtrim($alt);
		$alt = ucwords($alt);
		foreach ($aliases as $alias) {
			if ($alt == $alias['alias_name']) {
				$names[$num] = $alias['member_name'];
				break;
			}
		}
	}
	return $names;
}

function FetchMember($eqdkp, $table_prefix, $name) {
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$result = mysql_query("SELECT member_name, member_id FROM " . $table_prefix . 'members' . " WHERE member_name = '$name'")
    					or  mysql_error();
    	while ($row = mysql_fetch_array($result)) {
    		$temp = $row['member_id'];
    	}
    	return $temp;
	} else mysql_error();
}

function FetchAllMembers($eqdkp, $table_prefix) {
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$result = mysql_query("SELECT * FROM " . $table_prefix . 'members' . " ORDER BY member_name")
    					or  mysql_error();
    	while ($row = mysql_fetch_array($result)) {
    		$temp[stripslashes($row['member_name'])] = array('member_id'=>$row['member_id'],
    								'member_earned'=>$row['member_earned'],
    								'member_spent'=>$row['member_spent'],
    								'member_adjustment'=>$row['member_adjustment'],
    								'member_status'=>$row['member_status'],
    								'member_firstraid'=>$row['member_firstraid'],
    								'member_lastraid'=>$row['member_lastraid'],
    								'member_raidcount'=>$row['member_raidcount'],
    								'member_level'=>$row['member_level'],
    								'member_race_id'=>$row['member_race_id'],
    								'member_class_id'=>$row['member_class_id'],
    								'member_rank_id'=>$row['member_rank_id']);
    	}		
    	return $temp;
	} else mysql_error();
}

function FetchAllEvents($eqdkp, $table_prefix) {
	$link = CreateLink();
	$temp = array();
	if (mysql_select_db($eqdkp, $link)) {
		$result = mysql_query("SELECT event_id, event_name, event_value FROM " . $table_prefix . 'events' . " ORDER BY event_name")
    						or  mysql_error();
    	while ($row = mysql_fetch_array($result)) {
    		$temp[stripslashes($row['event_name'])] = array('event_id'=>$row['event_id'], 'event_value'=>$row['event_value'], 'event_name'=>$row['event_name']);
    	}
    	return $temp;
	} else mysql_error();
}

function FetchAllRaces($eqdkp, $table_prefix) {
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$result = mysql_query("SELECT race_id, race_name FROM " . $table_prefix . 'races' )
    					or  mysql_error();
    	while ($row = mysql_fetch_array($result)) {
    		$temp[$row['race_name']] = $row['race_id'];
    	}
    	return $temp;
	} else mysql_error();
}

function FetchAllClasses($eqdkp, $table_prefix, $flag) {
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$result = mysql_query("SELECT class_id, class_name FROM " . $table_prefix . 'classes' )
    					or  mysql_error();
    	while ($row = mysql_fetch_array($result)) {
    		if ($flag) {
    			$temp[$row['class_id']] = $row['class_name'];
    		} else $temp[$row['class_name']] = $row['class_id'];
    	}
    	return $temp;
	} else mysql_error();
}

function AddNEWMember($membername, $otherdata, $data, $eqdkp, $table_prefix) {
	$user = $GLOBALS['DKPUSER'];
	$data['member_earned'] = '0';
	$data['member_spent'] = '0';
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$sql = "INSERT INTO " . $table_prefix . 'members' . " (" . join(',', array_keys($data)) . ") VALUES (" . join(',', array_values($data)) . ")";
    		//echo $sql;
		$result = mysql_query($sql);
    		if (!$result) {
    			echo "!addnew" .  mysql_error();
		} else {
			$log_action = array('header' => '{L_ACTION_MEMBER_ADDED}',
					'{L_NAME}' => addslashes($membername),
					'{L_EARNED}' => '0',
					'{L_SPENT}' => '0',
					'{L_ADJUSTMENT}' => $data['member_adjustment'],
					'{L_LEVEL}' => $data['member_level'],
					'{L_RACE}' => $otherdata['race'],
					'{L_CLASS}' => $otherdata['class'],
					'{L_ADDED_BY}' => addslashes($user));
			LogAction($eqdkp, $table_prefix, $log_action);
			return true;
		}
	} else echo mysql_error();
	return false;
}

function UpdateEvent($eventname, $olddata, $eventdata, $eqdkp, $table_prefix) {
	$newval = $eventdata['value'];
	$eventid = $olddata['event_id'];
	$user = $GLOBALS['DKPUSER'];
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$sql = "UPDATE " . $table_prefix . 'events' . " SET event_name = '" . addslashes($eventname) . "', event_value = $newval, event_updated_by = '" 
				. addslashes($user) . "' WHERE event_id = '$eventid'";
		//echo $sql;
		$result = mysql_query($sql);
    		if (!$result) {
    			echo "!upevent" .  mysql_error();
		} else {
			$log_action = array('header' => '{L_ACTION_EVENT_UPDATED}',
					'id' => $eventid,
					'{L_NAME_BEFORE}' => addslashes($olddata['event_name']),
					'{L_VALUE_BEFORE}' => $olddata['event_value'],
					'{L_NAME_AFTER}' => addslashes($eventname),
					'{L_VALUE_AFTER}' => $newval,
					'{L_UPDATED_BY}' => addslashes($user));
			LogAction($eqdkp, $table_prefix, $log_action);
			return true;
		}
	} else echo mysql_error();
	return false;
}

function CreateEvent($eventname, $eventdata, $eqdkp, $table_prefix) {
	$user = $GLOBALS['DKPUSER'];
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$sql = "INSERT INTO " . $table_prefix . 'events' . " (event_name, event_value, event_added_by) 
					VALUES ('" . addslashes($eventname) . "','" . $eventdata['value'] . "','" . addslashes($user) . "')";
    		//echo $sql;
		$result = mysql_query($sql);
    		if (!$result) {
    			echo "!createevent" .  mysql_error();
		} else {
			$log_action = array('header' => '{L_ACTION_EVENT_ADDED}',
					'id' => mysql_insert_id(),
					'{L_NAME}' => addslashes($eventname),
					'{L_VALUE}' => $eventdata['value'],
					'{L_ADDED_BY}' => addslashes($user));
			LogAction($eqdkp, $table_prefix, $log_action);
			return true;
		}
	} else echo mysql_error();
	return false;
}

function IsMulti($eqdkp, $table_prefix) {
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$sql = "SHOW TABLES FROM $eqdkp LIKE '" . $table_prefix . "plus_config'";
		//echo $sql;
		$result = mysql_query($sql);
		if (empty($result)) return false;
		$row = mysql_fetch_array($result);
		if ($row) return true;
	}
	return false;
}

function FoundEqDKPPlus($eqdkp, $table_prefix) {
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$sql = "SELECT * FROM " . $table_prefix . "plus_config WHERE config_name = 'pk_multidkp'";
		//echo $sql;
		$result = mysql_query($sql);
		if ($result) return true;
	}
	return false;
}

function AddMultiAdjustment($name, $change, $eqdkp, $table_prefix, $key) {
	$user = $GLOBALS['DKPUSER'];
	$time = time();
	$members = FetchAllMembers($eqdkp, $table_prefix);
	$name = rtrim($name);
	if (!$members[$name]) {
		$newmember = array(	'member_name'=>"'" . addslashes($name) . "'",
					'member_class_id'=>'0',
					'member_race_id'=>'0');
		AddNEWMember($name, nil, $newmember, $eqdkp, $table_prefix);
	}
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$sql = "UPDATE " . $table_prefix . 'members' . " SET member_adjustment = member_adjustment + " . $change['value'] . " WHERE member_name = '$name'";
		//echo $sql;
		$result = mysql_query($sql);
    		if (!$result) echo "!addmultiupdatemember" .  mysql_error();
		if (IsMulti($eqdkp, $table_prefix)) {
			$sql = "INSERT INTO " . $table_prefix . 'adjustments' . " (adjustment_value, adjustment_date, member_name, adjustment_reason, adjustment_added_by, adjustment_group_key, raid_name)
					 VALUES ('" . $change['value'] . "','$time','$name','" . addslashes($change['event']) . "','$user','$key','" . addslashes($change['event']) . "')";
		} else {
			$sql = "INSERT INTO " . $table_prefix . 'adjustments' . " (adjustment_value, adjustment_date, member_name, adjustment_reason, adjustment_added_by, adjustment_group_key)
					 VALUES ('" . $change['value'] . "','$time','$name','" . addslashes($change['event']) . "','$user','$key')";
		}
    		//echo $sql;
		$result = mysql_query($sql);
    		if (!$result) {
    			echo "!addmultiadj" .  mysql_error();
    			return false;
    		}
		return true;
	} else echo mysql_error();
	return false;
}
	
function UpdateMember($membername, $olddata, $change, $eqdkp, $table_prefix, $report) {
	$user = $GLOBALS['DKPUSER'];
	$listdata = array();
	foreach ($change as $key => $value) {
		//if ($value != '' and $olddata[$key] != $value) $listdata[] = $key . '=' . $value;
		if ($value != '' and $olddata[$key] != $value) $listdata[] = $key . "='" . str_replace(",",".",$value)."'";
	}
	if (empty($listdata)) return;
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$sql = "UPDATE " . $table_prefix . 'members' . " SET " . join(',', $listdata) . " WHERE member_name = '" . addslashes($membername) . "'";
		//echo $sql;
		$result = mysql_query($sql);
    		if (!$result) {
    			echo "!updatemem" . mysql_error();
    		} else {
    			if ($report) {
				$log_action = array('header' => '{L_ACTION_MEMBER_UPDATED}',
						'{L_NAME_BEFORE}' => addslashes($membername),
						'{L_EARNED_BEFORE}' => $olddata['member_earned'],
						'{L_SPENT_BEFORE}' => $olddata['member_spent'],
						'{L_ADJUSTMENT_BEFORE}' => $olddata['member_adjustment'],
						'{L_LEVEL_BEFORE}' => $olddata['member_level'],
						'{L_RACE_BEFORE}' => $olddata['member_race_id'],
						'{L_CLASS_BEFORE}' => $olddata['member_class_id'],
						'{L_NAME_AFTER}' => addslashes($membername),
						'{L_EARNED_AFTER}' => !empty($change['member_earned']) ? $change['member_earned'] : $olddata['member_earned'],
						'{L_SPENT_AFTER}' =>  !empty($change['member_spent']) ? $change['member_spent'] : $olddata['member_spent'],
						'{L_ADJUSTMENT_AFTER}' => !empty($change['member_adjustment']) ? $change['member_adjustment'] : $olddata['member_adjustment'],
						'{L_LEVEL_AFTER}' => !empty($change['member_level']) ? $change['member_level'] : $olddata['member_level'],
						'{L_RACE_AFTER}' => !empty($change['member_race_id']) ? $change['member_race_id'] : $olddata['member_race_id'],
						'{L_CLASS_AFTER}' => !empty($change['member_class_id']) ? $change['member_class_id'] : $olddata['member_class_id'],
						'{L_UPDATED_BY}' => addslashes($user));
				LogAction($eqdkp, $table_prefix, $log_action);
			}
			return true;
		}
	} else echo mysql_error();
	return false;
}

function CreateRaid($raid, $zonedata, $eventdata, $eqdkp, $table_prefix) {
	$user = $GLOBALS['DKPUSER'];
	$raiddate = $raid['time'];
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$sql = "INSERT INTO " . $table_prefix . 'raids' . " (raid_name, raid_date, raid_note, raid_value, raid_added_by) 
								VALUES ('" . addslashes($raid['name']) . "','$raiddate','" . addslashes($raid['note']) . "','" 
								. $raid['value'] . "','" . addslashes($user) . "')";
    		//echo $sql;
		$result = mysql_query($sql);
    		if (!$result) {
    			echo "!createraid" .  mysql_error();
		} else {
			$raidid = mysql_insert_id();
			$log_action = array('header' => '{L_ACTION_RAID_ADDED}',
					'id' => $raidid,
					'{L_EVENT}' => addslashes($raid['name']),
					'{L_ATTENDEES}' => implode(", ", $raid['attendees']),
					'{L_NOTE}' => addslashes($raid['note']),
					'{L_VALUE}' => $raid['value'],
					'{L_ADDED_BY}' => addslashes($user));
			LogAction($eqdkp, $table_prefix, $log_action);
			return $raidid;
		}
	} else echo mysql_error();
	return false;
}

function AddRaidAttendees($raidid, $memberdata, $attendees, $eqdkp, $table_prefix) {
	$user = $GLOBALS['DKPUSER'];
	$values = array();
	foreach ($attendees as $name) {
		$name =rtrim($name);
		$values[] = "('" . $raidid . "','" . addslashes($name) . "')";
	}
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$sql = "INSERT INTO " . $table_prefix . 'raid_attendees' . " (raid_id, member_name) VALUES " . implode(', ', $values);
    		//echo $sql;
		$result =  mysql_query($sql);
    		if (!$result) echo "!addraidattendees" . mysql_error();
	} else echo mysql_error();
}

function AddRaidItem($raid_id, $loot, $eqdkp, $table_prefix) {
	$user = $GLOBALS['DKPUSER'];
	$loottime = $loot['Time'];
	$groupkey = gen_group_key($loot['ItemName'], $loottime, $raid_id);
	$loot['ItemName'] = addslashes($loot['ItemName']);
	$loot['Player'] = addslashes($loot['Player']);
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		if (FoundEqDKPPlus($eqdkp, $table_prefix)) {
			$sql = "INSERT INTO " . $table_prefix . 'items' . " (item_name, item_buyer, raid_id, item_value, game_itemid, item_date, item_added_by, item_group_key)
				 VALUES ('" . rtrim($loot['ItemName']) . "','" . rtrim($loot['Player']) . "','$raid_id','" . $loot['Costs'] . "','" . $loot['ID'] .
					"','$loottime','$user','$groupkey')";
		} else {
			$sql = "INSERT INTO " . $table_prefix . 'items' . " (item_name, item_buyer, raid_id, item_value, item_date, item_added_by, item_group_key)
				 VALUES ('" . rtrim($loot['ItemName']) . "','" . rtrim($loot['Player']) . "','$raid_id','" . $loot['Costs'] . 
					"','$loottime','$user','$groupkey')";
		}
    		//echo $sql;
		$result = mysql_query($sql);
    		if (!$result) {
    			echo "!addraiditem" . mysql_error();
    		} else {
    			$log_action = array('header' => '{L_ACTION_ITEM_ADDED}',
    					'{L_NAME}' => addslashes($loot['ItemName']),
    					'{L_BUYERS}' => addslashes($loot['Player']),
    					'{L_RAID_ID}' => $raid_id,
    					'{L_VALUE}' => $loot['Costs'],
    					'{L_ADDED_BY}' => addslashes($user));
			LogAction($eqdkp, $table_prefix, $log_action);
			return true;
		}
	} else echo mysql_error();
	return false;
}
	
function LogAction($eqdkp, $table_prefix, $log_action) {
	$user = addslashes($GLOBALS['USERID']);
	$str_action = "\$log_action = array(";
	foreach ( $log_action as $k => $v )
        {
            $str_action .= "'" . $k . "' => '" . $v . "',";
        }
	$action = substr($str_action, 0, strlen($str_action)- 1) . ");";
	$action = addslashes($action);
	$link = CreateLink();
	if (mysql_select_db($eqdkp, $link)) {
		$sql = "INSERT INTO " . $table_prefix . 'logs' . " (log_date, log_type, log_action, log_ipaddress, log_sid, log_result, admin_id) 
			VALUES ('" . time() . "','" . $log_action['header'] . "','$action','" . $_SERVER['REMOTE_ADDR'] . "','" 
			. session_id() . "','{L_SUCCESS}','$user')";
      		//echo $sql;
      		$result = mysql_query($sql);
    		if (!$result) echo "!LOG" .  mysql_error();
	} else echo mysql_error();
}

function Arraydiff($arr1, $arr2) {
	$diff = array_diff_assoc($arr1, $arr2);
	foreach ($diff as $key => $value) {
		$arr2[$key] = $value;
	}
	return $arr2;
}

function array_merge_keys($arr1, $arr2) {
    foreach($arr2 as $k=>$v) {
        if (!array_key_exists($k, $arr1)) { 
            $arr1[$k]=$v;
        }
        else { 
            if (is_array($v)) { 
                $arr1[$k]=array_merge_keys($arr1[$k], $arr2[$k]);
            }
        }
    }
    return $arr1;
}

function stripslashes_deep($value)
{
    $value = is_array($value) ?
                array_map('stripslashes_deep', $value) :
                stripslashes($value);

    return $value;
}

function gen_group_key($part1, $part2, $part3) {
	// Normalize data
	$part1 = htmlspecialchars(stripslashes($part1));
	$part2 = htmlspecialchars(stripslashes($part2));
	$part3 = htmlspecialchars(stripslashes($part3));
        
	// Get the first 10-11 digits of each md5 hash
	$part1 = substr(md5($part1), 0, 10);
	$part2 = substr(md5($part2), 0, 11);
	$part3 = substr(md5($part3), 0, 11);
        
	// Group the hashes together and create a new hash based on uniqid()
	$group_key = $part1 . $part2 . $part3;
	$group_key = md5(uniqid($group_key));
	return $group_key;
}

function CheckRace($member) {
	if ($member['race'] == "NightElf") $member['race'] = "Night Elf";
	elseif ($member['race'] == "BloodElf") $member['race'] = "Blood Elf";
	return $member;
}

function Restorespecial_deep($value) {
	 $value = is_array($value) ?
                array_map('Restorespecial_deep', $value) :
                Restorespecial($value);

    return $value;
}

?>