<?php
header('Content-Type: text/html; charset=utf-8');  
?>

<html>
<body style="font-family: Arial; font-size: 16px; background-color: #101030; color: #FDFDFD; padding-left: 50px; padding-top: 20px;">
<form action="Morgaction.php" method="post" name="[object]">
<b><u>MorgDKP2 Import v3.0</b></u>
<br>
<br>
Please copy the data string from MorgDKP2 into the box below and click parse.<br>
<br>
<br>
<br><textarea style="width: 800px; height: 400px;" name="data" ></textarea>
<br>
<br>
<input type="submit" value="Parse MorgDKP2 Data"><br>
</form>
</body>
</html>