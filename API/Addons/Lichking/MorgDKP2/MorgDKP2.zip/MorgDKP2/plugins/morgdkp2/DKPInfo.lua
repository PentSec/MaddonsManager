﻿MorgDKP2_DKP1 = {
	Timestamp = 221020081551,
	Pool = "Northrend",
	eqdkpsite = "aqdkp",
	prefix = "eqdkp_",
	Points = {
		["Morgalm"] = {earn = 2967.00,spent = 1600.00,adj = -2.00,bal = 1365,class = "Paladin"}
		
	},
	Aliases = {
		["Mogha"] = "Morgalm"
		
	},
	Events = {
		["Illidan Stormrage"] = {id = 93,value = 3.00}
		
	},
}
