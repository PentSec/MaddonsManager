<?php

$lang['morgexport'] = "Export Standings";
$lang['morgimport'] = "Import Raids";
$lang['morgdkp2_adminmenu_title'] = "MorgDKP2";

?>
