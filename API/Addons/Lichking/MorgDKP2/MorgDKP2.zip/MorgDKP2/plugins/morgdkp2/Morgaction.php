<?php
header('Content-Type: text/html; charset=utf-8');  
session_start(); 
define('EQDKP_INC', true);
define('IN_ADMIN', true);
define('PLUGIN', 'ctrt');

$eqdkp_root_path = './../../';
$admin_path = $eqdkp_root_path . "admin/index.php?s=/";
require($eqdkp_root_path . 'config.php');
require($eqdkp_root_path . 'common.php');
require('Morgfunc2.php');

function Addaliases($aliases) {
	global $Switches, $newalts;
	if (!empty($aliases)) {
		foreach ($aliases as $table) {
			$main = $table['main'];
			$alt = $table['alt'];
			$memberid = FetchMember($table['eqdkp'], $table['prefix'], $main);
			if ($memberid) {
				$currentaliases = FetchAliases($table['eqdkp'], $table['prefix'], $main);
				$exists = false;
				foreach ($currentaliases as $aliasdata) {
					if ($aliasdata['alias_name'] == $alt) $exists = true;
				}
				if (!$exists) { 
					$newalts[] = array('alt'=>$alt, 'main'=>$main, 'eqdkp'=>$table['eqdkp'], 'pool'=>$table['pool'], 'prefix'=>$table['prefix'], 'id'=>$memberid, 'action'=>$table['action']);
					$Switches['alias'] = true;
				} else {
					$newalts[] = array('alt'=>$alt, 'main'=>$main, 'eqdkp'=>$table['eqdkp'], 'pool'=>$table['pool'], 'prefix'=>$table['prefix'], 'id'=>$memberid, 'action'=>'ALIAS EXISTS!');
					$Switches['alias'] = true;
				} 
			} else {
				$newalts[] = array('alt'=>$alt, 'main'=>$main, 'eqdkp'=>$table['eqdkp'], 'pool'=>$table['pool'], 'prefix'=>$table['prefix'], 'id'=>$memberid, 'action'=>'NO MAIN!');
				$Switches['alias'] = true;
			}
		}
	}
	if (!empty($newalts)) $_SESSION['passalts'] = $newalts;
}

function ChangeDKP($changes) {
	global $needchanged, $Switches;
	if (!empty($changes)) {
		foreach ($changes as $change) {
			$name = $change['name'];
			$members = array();            
            		foreach ($change['members'] as $memberkey => $member) {
                		$members[$memberkey] = $member;
            		}
			$members = CheckAlias($members, $change['eqdkp'], $change['prefix']);
            		$needchanged[] = array('addtype'=>$change['addtype'], 'name'=>$name, 'value'=>$change['value'], 'eqdkp'=>$change['eqdkp'], 'pool'=>$change['pool'], 'prefix'=>$change['prefix'], 'event'=>$change['event'], 'members'=>$members);
		}
	}
	if (!empty($needchanged)) {
		$_SESSION['dkpchange'] = $needchanged;
		$Switches['dkpchange'] = true;
	}
}
		
function Addraids($raids) {
	global $RAID, $Switches;
	$i = 0;
	if (!empty($raids)) {
		foreach ($raids as $raid) {
			$RAID[$i]['zone'] = $raid['zone'];
			$RAID[$i]['date'] = $raid['date'];
			$RAID[$i]['eqdkp'] = $raid['eqdkp'];
			$RAID[$i]['pool'] = $raid['pool'];
			$RAID[$i]['prefix'] = $raid['prefix'];
			foreach ($raid['Attendees'] as $attend) {
				$name = $attend['name'];
				$RAID[$i]['attendees'][$name] = array('race'=>$attend['race'], 'class'=>$attend['class'], 'level'=>$attend['level']);
			}
			$eventindex = 0;
			$webevents = FetchAllEvents($raid['eqdkp'], $raid['prefix']);
			if (isset($raid['Bosskills'])) {
				foreach ($raid['Bosskills'] as $boss) {
					$bossname = $boss['name'];
					$bossnote = $boss['note'];
					$attend = $boss['attendees'];
					$attend = CheckAlias($attend, $raid['eqdkp'], $raid['prefix']);
					if (!empty($attend)) {
					 	asort($attend);
						$attend = array_unique($attend);
						$RAID[$i]['events'][$eventindex] = array('name'=>$bossname, 'note'=>$bossnote,'value'=>$boss['value'], 'time'=>$boss['time'], 'attendees'=>$attend, 'trash'=>$boss['trash'], 'index'=>$eventindex);
						$eventindex++;
					}
				}
			}
			$trashdone = false;
			if (isset($RAID[$i]['events'])) {
				foreach ($RAID[$i]['events'] as $event) {
					$trashcounter = 0;
					$lootnumber = 0;
					if (isset($raid['Loot'])) {
						foreach ($raid['Loot'] as $loot) {
							if ($event['note'] == $loot['Boss']) {
								$index = $event['index'];
								$isalias = CheckAlias(array('0' => $loot['Player']), $raid['eqdkp'], $raid['prefix']);
								$loot['Player'] = $isalias[0];
								$RAID[$i]['loot'][$index][$lootnumber] = $loot;
								$lootnumber++;
							}
							if (!$trashdone and $loot['Boss'] == "Trash mob") {
								$isalias = CheckAlias(array('0' => $loot['Player']), $raid['eqdkp'], $raid['prefix']);
								$loot['Player'] = $isalias[0];
								$RAID[$i]['loot']['Trash mob'][$trashcounter] = $loot;
								$trashcounter++;
							}
						}
						$trashdone = true;
					}
				}	
				$i++;
			}
		}
		if (!empty($RAID)) {
			$_SESSION['RAID'] = $RAID;
			$Switches['raids'] = true;
		}
	}
}

$webversion = 3.0;
$retrieve = $_POST['data'];
global $Switches, $newalts, $needchanged, $RAID, $DKP;

$_SESSION['passalts'] = "";
$_SESSION['dkpchange'] = "";
$_SESSION['RAID'] = "";
$DKP = array();
$RAID = array();
$Switches = array();
$newalts = array();
$needchanged = array();
//echo "<pre>";
//print_r($retrieve);
//echo "</pre>";
$temp = xmlstringtoarray($retrieve);
$temp = stripslashes_deep($temp);
$DKP = $temp['MorgDKP2'];
//echo "<pre>";
//print_r($DKP);
//echo "</pre>";
if ($DKP['version'] != $webversion) {
	echo "Unable to update DKP! Please update your MorgDKP2 webscripts.";
} else {
	foreach ($DKP as $eventtype => $table) {
		switch ($eventtype) {
			case 'Aliases':
				Addaliases($table);
				break;
			case 'DKPChanges':
				ChangeDKP($table);
				break;
			case 'Raids':
				Addraids($table);
				break;
		}
	}
}

?>


<html>
<head>
<style type="text/css">
h1 {text-align: right; margin-right: 20px; font-size: 12px}
</style>
</head>
<body style="font-family: Arial; font-size: 16px; background-color: #101030; color: #FDFDFD; padding-left: 100px; padding-right: 100px; padding-top: 20px;">
<form action="Morgresults.php" method="post" name="[object]">
<h1><a href="<?php echo $admin_path?>" target="_self" style="color: #FDFDFD;">Return to eqDKP Admin</a></h1>
<b><u>MorgDKP2 Import v3.0</b></u>
<br>
<br>
<?php 
if (isset($Switches['dkpchange'])) { ?>
	<u><b>DKP adjustments to be added to Database:</u></b><br><br>
	<table border="1" cellpadding="12">
	<tr><td><strong>Member </strong></td><td><strong>Adjustment </strong></td><td><strong>Database </strong></td><td><strong>Pool </strong></td><td><strong>Event/Note </strong></td></tr>
	<?php foreach ($needchanged as $i => $changes) {
		if ($changes['addtype'] == "Group" ) {
			$changevalue[$i]['members'] = implode("\n", $changes['members']);?>
			<tr><td><textarea style="width: 150px; height: 100px;" name="changevalue[<?php echo $i?>][members]" ><?php echo $changevalue[$i]['members']?></textarea></td><td><input name="changevalue[<?php echo $i?>][value]" size="3" value="<?php echo $changes['value']?>"></td><td><?php echo $changes['eqdkp']?></td><td><?php echo $changes['pool']?></td><td><?php echo $changes['event']?></td></tr>
		<?php } else {?>
			<tr><td><input name="changevalue[<?php echo $i?>][members]" size="20" value="<?php echo $changes['name']?>"></td><td><input name="changevalue[<?php echo $i?>][value]" size="3" value="<?php echo $changes['value']?>"></td><td><?php echo $changes['eqdkp']?></td><td><?php echo $changes['pool']?></td><td><?php echo $changes['event']?></td></tr>
		<?php }
}?>
</table>
<hr>
<?php } 
if (isset($Switches['alias'])) { ?>
	<u><b>Alias changes to Database:</u></b><br><br>
	<table border="1" cellpadding="12">
	<tr><td><strong>Alt </strong></td><td><strong>Main </strong></td><td><strong>Database </strong></td><td><strong>Pool </strong></td><td><strong>Action </strong></td></tr>
	<?php foreach ($newalts as $i => $aliases) { ?>
		<tr><td><input name="altfield[<?php echo $i?>][alt]" value="<?php echo $aliases['alt']?>"></td><td><?php echo $aliases['main']?></td><td><?php echo $aliases['eqdkp']?></td><td><?php echo $aliases['pool']?></td><td><?php echo $aliases['action']?></td></tr>
	<?php }?>
	</table>
	<hr>
<?php } 
if (isset($Switches['raids'])) { ?>
	<u><b>Raids to be added to Database:</u></b>
	<br><br>
	<?php foreach ($RAID as $i => $raiddata) { ?>
		<b>Database: </b>&nbsp;&nbsp;<?php echo $raiddata['eqdkp']?><br>
		<b>Pool: </b>&nbsp;&nbsp;<?php echo $raiddata['pool']?><br><br>
		<b>Zone</b>&nbsp;&nbsp;&nbsp;&nbsp;<input name="raidfield[<?php echo $i?>][zone]" value="<?php echo $raiddata['zone']?>">&nbsp;&nbsp;&nbsp;&nbsp;Use 0-sum DKP&nbsp;&nbsp;<input type="checkbox" name="raidfield[<?php echo $i?>][zsum]"><br><br>
		<?php 
		foreach ($raiddata['events'] as $event => $eventdata) { ?>
			<b>Event</b>&nbsp;&nbsp;<input name="raidfield[<?php echo $i?>][events][<?php echo $event?>][name]" size="40" value="<?php echo $eventdata['name']?>"><br>
			<b>Note</b>&nbsp;&nbsp;&nbsp;&nbsp;<input name="raidfield[<?php echo $i?>][events][<?php echo $event?>][note]" size="40" value="<?php echo $eventdata['note']?>"><br>
			<b>Value</b>&nbsp;&nbsp;<input name="raidfield[<?php echo $i?>][events][<?php echo $event?>][value]" size="3" value="<?php echo $eventdata['value']?>"><br>
			<b>Time</b>&nbsp;&nbsp;&nbsp;<?php echo strftime("%Y/%m/%d %H:%M:%S", $eventdata['time'])?><br><br>
			<?php $raidfield[$i]['events'][$event]['attendees'] = implode("\n", $eventdata['attendees']);?>
			<b>Attendees</b><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<textarea style="width: 150px; height: 300px;" name="raidfield[<?php echo $i?>][events][<?php echo $event?>][attendees]"><?php echo $raidfield[$i]['events'][$event]['attendees'] ?></textarea><br>
			<?php 
			if ($raiddata['loot'][$eventdata['index']]) {
				foreach ($raiddata['loot'][$eventdata['index']] as $loot => $lootdata) { 
					$eventname = $eventdata['index']; ?>
					<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input name="raidfield[<?php echo $i?>][loot][<?php echo $eventname?>][<?php echo $loot?>][ItemName]" size="30" value="<?php echo $lootdata['ItemName']?>"><br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input name="raidfield[<?php echo $i?>][loot][<?php echo $eventname?>][<?php echo $loot?>][Costs]" size="30" value="<?php echo $lootdata['Costs']?>"><br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input name="raidfield[<?php echo $i?>][loot][<?php echo $eventname?>][<?php echo $loot?>][Player]" size="30" value="<?php echo $lootdata['Player']?>"><br>
				<?php }
			} 
			if ($raiddata['loot']['Trash mob'] and $eventdata['trash'] == 2) {?>
				<br>
				<?php 
				foreach ($raiddata['loot']['Trash mob'] as $tloot => $trashdata) { ?>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input name="raidfield[<?php echo $i?>][loot][Trash mob][<?php echo $tloot?>][ItemName]" size="30" value="<?php echo $trashdata['ItemName']?>"><br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input name="raidfield[<?php echo $i?>][loot][Trash mob][<?php echo $tloot?>][Costs]" size="30" value="<?php echo $trashdata['Costs']?>"><br>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input name="raidfield[<?php echo $i?>][loot][Trash mob][<?php echo $tloot?>][Player]" size="30" value="<?php echo $trashdata['Player']?>"><br><br>
				<?php }
			}?>
			<br>
			<hr>
		<?php } ?>
		<hr>
	<?php }
} ?> 
<br>
<br>
<input type="submit" value="Enter final data"><br>
<br>
<b><u>Note:</b></u> If you delete the run event all trash drops will be automatically moved to one of the other events that are listed.  If you don't want to record: 1) <b>Event</b> - delete it's name 2) <b>Item</b> - delete it's name or winner.
</form>
</body>
</html>