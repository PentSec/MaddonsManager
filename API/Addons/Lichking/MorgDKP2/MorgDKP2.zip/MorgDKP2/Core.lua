MorgDKP2 = LibStub("AceAddon-3.0"):NewAddon("MorgDKP2", "AceEvent-3.0", "AceConsole-3.0")

local L = LibStub("AceLocale-3.0"):GetLocale("MorgDKP2")
local C = LibStub("AceConfigDialog-3.0")
local CC = LibStub("AceConfigCmd-3.0")
local BZ = LibStub("LibBabble-Zone-3.0"):GetLookupTable()
local BB = LibStub("LibBabble-Boss-3.0"):GetLookupTable()

local mdkp = MorgDKP2
mdkp.morgbid2version = tonumber(GetAddOnMetadata("MorgBid2", "X-Revision")) 

mdkp.version = "MorgDKP2 " .. GetAddOnMetadata("MorgDKP2", "Version") 
mdkp.webversion = 3.0

mdkp:SetDefaultModuleState(false)

--static pops

--enable tracking triggers
local ZoneTriggers = {
	[BZ["Molten Core"]] = true,
	[BZ["Blackwing Lair"]] = true,
	[BZ["Zul'Gurub"]]= true,
	[BZ["Onyxia's Lair"]] = true,
	[BZ["Ruins of Ahn'Qiraj"]] = true,
	[BZ["Ahn'Qiraj"]] = true,
	[BZ["Naxxramas"]] = true,
	[BZ["Karazhan"]] = true,
	[BZ["Gruul's Lair"]] = true,
	[BZ["Magtheridon's Lair"]] = true,
	[BZ["Serpentshrine Cavern"]] = true,
	[BZ["Caverns of Time"]] = true,
	[BZ["Black Temple"]] = true,
	[BZ["Tempest Keep"]] = true,
	[BZ["Hyjal Summit"]] = true,
	[BZ["Alliance Base"]] = true,
	[BZ["Horde Encampment"]] = true,
	[BZ["Zul'Aman"]] = true,
	[BZ["Sunwell Plateau"]] = true,
	[L["World Boss"]] = true,
	[BZ["The Eye of Eternity"]] = true,
	[BZ["The Obsidian Sanctum"]] = true,
	[BZ["Vault of Archavon"]] = true,
	[BZ["Ulduar"]] = true,
	[BZ["Trial of the Crusader"]] = true,
	[BZ["Icecrown Citadel"]] = true,
	[BZ["The Ruby Sanctum"]] = true,
	--[BZ["The Deadmines"]] = true
}

--boss triggers
mdkp.ZoneBosses = {
	[BZ["Molten Core"]] = {BB["Lucifron"],
				BB["Magmadar"],
				BB["Gehennas"],
				BB["Garr"],
				BB["Baron Geddon"],
				BB["Shazzrah"],
				BB["Sulfuron Harbinger"],
				BB["Golemagg the Incinerator"],
				BB["Majordomo Executus"],
				BB["Ragnaros"]},
	[BZ["Blackwing Lair"]] = {BB["Razorgore the Untamed"],
				BB["Vaelastrasz the Corrupt"],
				BB["Broodlord Lashlayer"],
				BB["Firemaw"],
				BB["Ebonroc"],
				BB["Flamegor"],
				BB["Chromaggus"],
				BB["Nefarian"]},
	[BZ["Zul'Gurub"]] = {BB["High Priestess Jeklik"],
				BB["High Priest Venoxis"],
				BB["High Priestess Mar'li"],
				BB["High Priest Thekal"],
				BB["High Priestess Arlokk"],
				BB["Hakkar"],
				BB["Bloodlord Mandokir"],
				BB["Jin'do the Hexxer"],
				BB["Gahz'ranka"],
				BB["Hazza'rah"],
				BB["Gri'lek"],
				BB["Renataki"],
				BB["Wushoolay"]},
	[BZ["Ruins of Ahn'Qiraj"]] = {BB["Kurinnaxx"],
				BB["General Rajaxx"],
				BB["Ayamiss the Hunter"],
				BB["Buru the Gorger"],
				BB["Moam"],
				BB["Ossirian the Unscarred"]},
	[BZ["Ahn'Qiraj"]] = {BB["The Prophet Skeram"],
				BB["Fankriss the Unyielding"],
				BB["Battleguard Sartura"],
				BB["Princess Huhuran"],
				BB["Emperor Vek'lor"],
				BB["Emperor Vek'nilash"],
				BB["C'Thun"],
				BB["Vem"],
				BB["Princess Yauj"],
				BB["Lord Kri"],
				BB["Viscidus"],
				BB["Ouro"]},
	[BZ["Naxxramas"]] = {BB["Patchwerk"],
				BB["Grobbulus"],
				BB["Gluth"],
				BB["Thaddius"],
				BB["Instructor Razuvious"],
				BB["Gothik the Harvester"],
				BB["The Four Horsemen"],
				BB["Noth the Plaguebringer"],
				BB["Heigan the Unclean"],
				BB["Loatheb"],
				BB["Anub'Rekhan"],
				BB["Grand Widow Faerlina"],
				BB["Maexxna"],
				BB["Sapphiron"],
				BB["Kel'Thuzad"]},
	[BZ["Karazhan"]] = {BB["Attumen the Huntsman"],
				BB["Moroes"],
				BB["Maiden of Virtue"],
				BB["Netherspite"],
				BB["Nightbane"],
				BB["Prince Malchezaar"],
				BB["Shade of Aran"],
				BB["Terestian Illhoof"],
				BB["The Curator"],
				BB["Romulo & Julianne"],
				BB["The Big Bad Wolf"],
				BB["The Crone"],
				BB["Chess Event"],
				BB["Rokad the Ravager"],
				BB["Hyakiss the Lurker"],
				BB["Shadikith the Glider"]},
	[BZ["Serpentshrine Cavern"]] = {BB["Hydross the Unstable"],
				BB["Fathom-Lord Karathress"],
				BB["The Lurker Below"],
				BB["Morogrim Tidewalker"],
				BB["Leotheras the Blind"],
				BB["Lady Vashj"]},
	[BZ["Tempest Keep"]] = {BB["Al'ar"],
				BB["Void Reaver"],
				BB["High Astromancer Solarian"],
				BB["Kael'thas Sunstrider"]},
	[BZ["Hyjal Summit"]] = {BB["Rage Winterchill"],
				BB["Anetheron"],
				BB["Kaz'rogal"],
				BB["Azgalor"],
				BB["Archimonde"]},
	[BZ["Black Temple"]] = {BB["High Warlord Naj'entus"],
				BB["Supremus"],
				BB["Gurtogg Bloodboil"],
				BB["Teron Gorefiend"],
				BB["Shade of Akama"],
				BB["Reliquary of Souls"],
				BB["Mother Shahraz"],
				BB["Illidari Council"],
				BB["Illidan Stormrage"]},
	[BZ["Zul'Aman"]] = {BB["Akil'zon"],
				BB["Halazzi"],
				BB["Jan'alai"],
				BB["Hex Lord Malacrass"],
				BB["Nalorakk"],
				BB["Zul'jin"]},
	[L["World Boss"]] = {BB["Avalanchion"],
				BB["Azuregos"],
				BB["Baron Charr"],
				BB["Baron Kazum"],
				BB["Doom Lord Kazzak"],
				BB["Doomwalker"],
				BB["Emeriss"],
				BB["High Marshal Whirlaxis"],
				BB["Lethon"],
				BB["Lord Kazzak"],
				BB["Lord Skwol"],
				BB["Prince Skaldrenox"],
				BB["Princess Tempestria"],
				BB["Taerar"],
				BB["The Windreaver"],
				BB["Ysondre"]},
	[BZ["Onyxia's Lair"]] = {BB["Onyxia"]},
	[BZ["Gruul's Lair"]] = {BB["High King Maulgar"], BB["Gruul the Dragonkiller"]},
	[BZ["Magtheridon's Lair"]] = {BB["Magtheridon"]},
	[BZ["Sunwell Plateau"]]  = {BB["Kalecgos"],
				BB["Brutallus"],
				BB["Felmyst"],
				BB["The Eredar Twins"],
				BB["M'uru"],
				BB["Kil'jaeden"]},
	[BZ["The Eye of Eternity"]] = {BB["Malygos"]},
	[BZ["The Obsidian Sanctum"]] = {BB["Sartharion"],
					BB["Shadron"],
					BB["Tenebron"],
					BB["Vesperon"]},
	[BZ["Vault of Archavon"]] = {BB["Archavon the Stone Watcher"], BB["Emalon the Storm Watcher"], BB["Koralon the Flame Watcher"], BB["Toravon the Ice Watcher"]},
	[BZ["Ulduar"]] = {	BB["Flame Leviathan"],
				BB["Ignis the Furnace Master"],
				BB["Razorscale"],
				BB["XT-002 Deconstructor"],
				BB["The Iron Council"],
				BB["Kologarn"],
				BB["Auriaya"],
				BB["Hodir"],
				BB["Thorim"],
				BB["Freya"],
				BB["Mimiron"],
				BB["General Vezax"],
				BB["Yogg-Saron"],
				BB["Algalon the Observer"]},
	[BZ["Trial of the Crusader"]]  = {BB["The Beasts of Northrend"],
				BB["Lord Jaraxxus"],
				BB["Faction Champions"],
				BB["The Twin Val'kyr"],
				BB["Anub'arak"]},
	[BZ["Icecrown Citadel"]] = {BB["Lord Marrowgar"],
				BB["Lady Deathwhisper"],
				BB["Icecrown Gunship Battle"],
				BB["Deathbringer Saurfang"],
				BB["Festergut"],
				BB["Rotface"],
				BB["Professor Putricide"],
				BB["Blood Princes"],
				BB["Blood-Queen Lana'thel"],
				BB["Valithria Dreamwalker"],
				BB["Sindragosa"],
				BB["The Lich King"]},
	[BZ["The Ruby Sanctum"]] = {	BB["Halion"],
					BB["Saviana Ragefire"],
					BB["Baltharus the Warborn"],
					BB["General Zarithrian"]},
	
	--[BZ["The Deadmines"]]  = {BB["Rhahk'Zor"],
	--			BB["Sneed"],
	--			BB["Gilnid"],
	--			BB["Captain Greenskin"],
	--			BB["Mr. Smite"],
	--			BB["Edwin VanCleef"]},
}

mdkp.Classcolors = {}
	
mdkp.ClasscolorsDEC = {[L["ALL"]] = {r = 1, g = 1, b = 1}}
			
mdkp.orderedclasses = {[1] = "DRUID", [2] = "HUNTER", [3] = "MAGE", [4] = "PALADIN", [5] = "PRIEST", [6] = "ROGUE", [7] = "SHAMAN", [8] = "WARLOCK", [9] = "WARRIOR", [10] = "DEATHKNIGHT", [11] = L["ALL"]}
	
mdkp.Quality = {}

mdkp.Bits = { 	["DRUID"] 	= 	1024,
		["HUNTER"] 	= 	512,
		["MAGE"] 	=	256,
		["PALADIN"] 	= 	128,
		["PRIEST"] 	= 	64,
		["ROGUE"] 	= 	32,
		["SHAMAN"] 	= 	16,
		["WARLOCK"] 	= 	8,
		["WARRIOR"] 	= 	4,
		["DEATHKNIGHT"]	= 	2,
		[L["ALL"]] 	= 	2047
}

mdkp.guildstatustext = {[L["ONLINE"]] = {n = L["ONLINE"], r = 0, g = 1, b = 0},
			[L["OFFLINE"]] = {n = L["OFFLINE"], r = 1, g = 0, b = 0},
			[L["INRAID"]] = {n = L["INRAID"], r = 1, g = 1, b = 1},
			[L["xINRAIDx"]] = {n = L["xINRAIDx"], r = 1, g = 1, b = 0},
			[L["UNKNOWN"]] = {n = L["UNKNOWN"], r = 0.5, g = 0.5, b = 0.5},
			["<AFK>"] = {n = "<AFK>", r = 1, g = 1, b = 0},
			[L["WAIT"]] =  {n = L["WAIT"], r = 1, g = 1, b = 0},
			[L["xWAITx"]] =  {n = L["xWAITx"], r = 1, g = 0, b = 0}}

mdkp.bidwarconflicts = {"Random", "Relational", "Percent", "SKall", "TakeBid", "SKSotC"}

mdkp.chests = {
		[L["Dust Covered Chest"]] = BB["Chess Event"],
		[L["Cache of the Firelord"]] = BB["Majordomo Executus"],
		[L["Four Horsemen Chest"]] = BB["The Four Horsemen"],
		[L["Alexstrasza's Gift"]] = BB["Malygos"],
		[L["Cache of Living Stone"]] = BB["Kologarn"],
		[L["Cache of Innovation"]] = BB["Mimiron"],
		[L["Cache of Winter"]] = BB["Hodir"],
		[L["Cache of Storms"]] = BB["Thorim"],
		[L["Freya's Gift"]] = BB["Freya"],
		[L["Gift of the Observer"]] = BB["Algalon the Observer"]
}

mdkp.difftable = {[1] = "(10)", [2] = "(25)", [3] = "(10H)", [4] = "(25H)"}	

local fmt = string.format
local sub = string.sub
local tinsert = table.insert
local tsort   = table.sort
local tremove = table.remove
local tostring = tostring 
local lower = string.lower
local find = string.find
local len = string.len
local upper = string.upper
local band = bit.band
local bor = bit.bor
local bxor = bit.bxor
local Player = UnitName("player")
local dkpmodoptions = {}
local db	

local defaults = { 
	profile = {
   		alwaysloot = nil,
   		attemptmode = nil,
   		autozone = true,
   		bank = nil,
   		ctrtformat = nil,
   		currDKP = nil,
		custom = L["NEW"],
   		DBversion = 1.1,
   		devmode = nil,
		dewpoint = "RIGHT",
		disenchanter = Player,
   		dkpevents = true,
   		dkplistener = nil,
   		dkpstatustext = nil,
   		eqdkp = nil,
   		guildlaunch = nil,
   		guildlink = nil,
   		hints = true,
   		InRaid = nil,
   		ignore68 = nil,
   		ignoreunique = nil,
   		instancedifficulty = 1,
   		mbidcustom = nil,
   		mbidnag = nil,
   		mbidoffspec = true,
   		mbidupdating = true,
   		mlooter = Player,
   		multiPool = nil,
   		newdkp = 0,
   		newdkpname = "New Member DKP",
   		offspecamount = 15,
   		offspecmode = nil,
   		OneEvent = nil,
   		OneEventNote = nil,
   		quality = 4,
   		raid = nil,
   		raidend = L["PENDING"],
   		raidended = nil,
   		raidexport = L["PENDING"],
   		raidlink = true,
   		raidlist = {L["NONE"]},
   		raidmembers = {Player},
   		raidnum = 0,
   		raidstart = L["PENDING"],
   		sarthextra = nil,
   		showearned = true,
   		startrun = true,
   		takeamount = 25,
   		takemode = nil,
   		takepercent = nil,
		offspecpercent = nil,
   		usemorg = true,
   		useranks = {},
   		ranks = {},
   		editrank = nil,
   		NEED = L["NEED"],
   		TAKE = L["TAKE"],
   		OFFSPEC = L["OFFSPEC"],
   		PASS = L["PASS"],
   		dkpmodules = {
   				menu = {},
		},
   		modules = {
   			CoreModule = true,
   			LDBPlugin = true,
   			Tracker = true,
   			PointsDB = true,
   			Lootframe = true,
   			Waitlist = true,
   			Eventnaming = true,
   			RaidTracker = true,
   		},
   		moduleON = {},
   		items = { },
    		info = {},
    		media = {
    			font = "Friz Quadrata TT",
    			fontsize = 10,
    			border = "Blizzard Tooltip",
	    		background = "Blizzard Out of Control",
	    		scale = 1.2,
			backdropC = { .58, .58, .58, 1},
			borderC = { .96, .93, .26, .75},
			fontC = { 0, 0, 1},
    		},
    		raidlog = {
				playerinfo = { },
				join = { },
				leave = { },
				bosskills = { },
				loot = { }
		},
		lootbuffer = {},
		ignore = {	[14344] = true,
				[18562] = true,
				[20725] = true,
				[22448] = true,
				[22449] = true,
				[22450] = true,
				[29434] = true,
				[30311] = true,
				[30312] = true,
				[30313] = true,
				[30314] = true,
				[30316] = true,
				[30317] = true,
				[30318] = true,
				[30319] = true,
				[30320] = true,
				[32230] = true,
				[34057] = true,
				[40752] = true,
				[40753] = true,
				[45624] = true,
				[47241] = true,
				[49426] = true
		},
   	},
}
local options = {
	name = "MorgDKP2",
	handler = mdkp,
	type = "group",
	args = { 
		toggle = {
			type = "toggle",
			name = L["Toggle MorgDKP2"],
			desc = L["Toggle MorgDKP2"],
			get = function() return mdkp:GetCoreState() end,
			set = 	function(info, v) 
					if v then mdkp:ActivateCore(true) 
					else mdkp:DeActivateCore(true) end
				end,
			order = 5
		},
		autozone = {
			type = "toggle",
			name = L["Autozone"],
			desc = L["Automatically enable MorgDKP2 and start a raid when entering a trackable zone."],
			get = function() return mdkp.db.profile.autozone end,
			set = function(info, v) mdkp.db.profile.autozone = v end,
			disabled = function() return not mdkp:IsEnabled() end,
			order = 10
		},
		devmode = {
			type = "toggle",
			name = L["Developer mode"],
			desc = L["Developer mode"],
			get = function() return mdkp.db.profile.devmode end,
			set = function(info, v) mdkp.db.profile.devmode = v end,
			disabled = function() return not mdkp:IsEnabled() end,
			order = 15
		},
		clearraiddb = {
			type = "execute",
			name = L["Clear raid DB"],
			desc = L["Clear currently tracked raids."],
			func = function() mdkp:ClearRaidDB() end,
			disabled = function() return not mdkp:IsEnabled() end,
			order = 20
		},
		modules = {
			type = "group",
			name = L["Core Modules"],
			desc = L["Core Modules"],
			order = 200,
			args = {},
		},
		dkpmodules = {
			type = "group",
			name = L["DKP Modules"],
			desc = L["DKP Modules"],
			order = 500,
			args = {},
		},
	},
}


--addon initialization

function mdkp:OnInitialize()
	--saved variables and config options
	self.db = LibStub("AceDB-3.0"):New("MorgDKP2DB", defaults, "Default")
	options.args.profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db)
	options.args.profiles.order = 1000
		
	LibStub("AceConfig-3.0"):RegisterOptionsTable("MorgDKP2", options)
	self.optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("MorgDKP2", "MorgDKP2")
	
	self:RegisterChatCommand("mdkp2", "ChatCommand")
	self:RegisterChatCommand("morgdkp2", "ChatCommand")
	
end

function mdkp:OnEnable()
	self:debug("MorgDKP2 Enabled")
	
	db = mdkp.db.profile
	mdkp.dkpmenu = {}
	mdkp.dkpmenuconvert = {}
	mdkp.querytooltips = {}
	
	self:RegisterEvent("PLAYER_ENTERING_WORLD", "EnterWorld")
	self:RegisterEvent("CHAT_MSG_WHISPER", "WhisperHandler")
	
	--get DB/fubar plug to load independent of other modules states if it is enabled in opts
	if self.db.profile.modules.LDBPlugin then	
		local LDB = self:GetModule("LDBPlugin", true)
		if LDB then 
			LDB:Enable()
			self.db.profile.modules["LDBPlugin"] = true
		else 
			self.db.profile.modules["LDBPlugin"] = nil
		end
	end
	if self.db.profile.alwaysloot then	
		local loot = self:GetModule("Lootframe", true)
		if loot then 
			loot:Enable() 
		end
	end
	self:SetupModuleOptions()
	self.db.profile.moduleON["CoreModule"] = nil
	self:GetClassColors()
	self:FillQualities()
	self:addFilter()
end

function mdkp:OnDisable()
	self:debug("MorgDKP2 Disabled")
	self:DeActivateCore()
end

function mdkp:GetClassColors()
	for class, color in pairs(CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS) do
		mdkp:SetClassColors(class, color)
	end
	if CUSTOM_CLASS_COLORS then
		CUSTOM_CLASS_COLORS:RegisterCallback(function()
        		for class, color in pairs(CUSTOM_CLASS_COLORS) do
               			mdkp:SetClassColors(class, color)
          		end
          	end)
	end
end

function mdkp:SetClassColors(class, color)
	mdkp.ClasscolorsDEC[class] = {r = color.r, g = color.g, b = color.b}
	mdkp.Classcolors[class] = "|c00" .. fmt("%02x%02x%02x", color.r*255, color.g*255, color.b*255)
end

function mdkp:FillQualities()
	for i = 0, 6 do
  		local r, g, b, hex = GetItemQualityColor(i)
  		table.insert(mdkp.Quality, {n = getglobal("ITEM_QUALITY" .. i .. "_DESC"), r = r, g = g, b = b})
  	end
end

function mdkp:SetupModuleOptions()
	--insert modules options
	for k,v in self:IterateModules() do
		if v then
			local modoptions = v:GetOptions()
			local dkp = v:IsDKP()
			if modoptions then
				if dkp then 
					for prop, data in pairs(modoptions) do
						dkpmodoptions[prop] = data
					end
					local name, ref = v:GetName()
					table.insert(mdkp.dkpmenu, name) 
					mdkp.dkpmenuconvert[name] = ref
				else options.args.modules.args[v.moduleName] = modoptions end
				self:debug("Options " ..v.moduleName)
			end
		end
	end
	options.args.dkpmodules.args = dkpmodoptions
	table.insert(mdkp.dkpmenu, L["Boss Attempt Mode"])
	mdkp.dkpmenuconvert[L["Boss Attempt Mode"]] = "attemptmode"
end

function mdkp:EnableModules(on)
	--toggle users current modules
	for k,v in self:IterateModules() do
		if self.db.profile.modules[k] and v.modref ~= "LDBPlugin" then
			if on then 
				v:Enable()
				self:debug("Enabled " ..v.modName)
			else
				if v.modName ~= "Lootframe" or (v.modName == "Lootframe" and not mdkp.db.profile.alwaysloot) then
					v:Disable()
					self:debug("Disabled " ..v.modName)
				end
			end
		end
	end
end

function mdkp:ChatCommand(arg1)
	--handle chat command being non blank
	if not arg1 or arg1 == "" then 
		if not C.OpenFrames["MorgDKP2"] then C:Open("MorgDKP2") 
		else C:Close("MorgDKP2") end
	else CC:HandleCommand("mdkp2", "MorgDKP2", arg1:trim() ~= "help" and arg1 or "")
	end
end

function mdkp:debug(message)
	if self.db.profile.devmode then
		self:Print(message)
	end
end

function mdkp:out(message)
	if message then
		DEFAULT_CHAT_FRAME:AddMessage(message)
	end
end

function mdkp:EnterWorld()
	local tracker = mdkp:GetModule("Tracker", true)
	if self:IsTrackedZone() then
		if not db.InRaid and db.autozone and tracker then tracker:BeginRaid() end
	elseif not UnitIsGhost("player") and db.InRaid and db.autozone and not mdkp.querytooltips["listdkp"] and tracker then tracker:ShowEndRaidFrame() 
	end
end

function mdkp:IsTrackedZone()
	local ZoneName = GetInstanceInfo()
	mdkp:debug(ZoneName)
	if ZoneTriggers[ZoneName] then 
		if ZoneName == BZ["Alliance Base"] or ZoneName == BZ["Horde Encampment"] then ZoneName = BZ["Hyjal Summit"] end
		self.db.profile.menuzone = ZoneName
		self:ActivateCore()
		return true
	else
		self.db.profile.menuzone = L["World Boss"]
		if not UnitIsGhost("player") then self:DeActivateCore() end
	end
	return false
end

function mdkp:ActivateCore(force)
	local CoreState = self:GetCoreState()
	if force or (self.db.profile.autozone and not UnitIsGhost("player")) then
		if not CoreState then self:EnableModules(true) end
		self:ToggleLDBFuStatus(true)
	end
end

function mdkp:DeActivateCore(force)
	local CoreState = self:GetCoreState()
	if force or (self.db.profile.autozone and not UnitIsGhost("player") and not mdkp.querytooltips["listdkp"]) then 
		if mdkp.frames then
			if mdkp.frames["raidtracker"] and mdkp.frames["raidtracker"]:IsShown() then mdkp.frames["raidtracker"]:Hide() end
			if mdkp.frames["listdkp"] and mdkp.frames["listdkp"]:IsShown() then mdkp.frames["listdkp"]:Hide() end
			if mdkp.frames["version"] and mdkp.frames["version"]:IsShown() then mdkp.frames["version"]:Hide() end
		end
		if CoreState then self:EnableModules() end
		self:ToggleLDBFuStatus()
	end
end

function mdkp:RestartMorgDKP2()
	mdkp:DeActivateCore(true)
	mdkp:ActivateCore(true)
end

function mdkp:ToggleLDBFuStatus(ON)
	local LDB = self:GetModule("LDBPlugin", true)
	if ON then
		if LDB then LDB:ActivateCore() end
	else
		if LDB then LDB:DeActivateCore() end
	end
end

function mdkp:ClearRaidDB()
	local db = mdkp.db.profile
	db.raidlog = { }
	db.raidnum = 0
	db.lootbuffer = { }
	db.raidstart = L["PENDING"]
	db.raidend = L["PENDING"]
	db.raidexport = L["PENDING"]
	db.raidlog.dkpevents = {}
	db.raidlog.aliases = {}
	db.InRaid = nil
	self:out(L["Cleared current raid database."])
end

function mdkp:GetCoreState()
	local Core = mdkp:GetModule("CoreModule", true)
	return Core:IsEnabled()
end

function mdkp:WhisperHandler(_, txt, sender)
	txt = string.utf8upper(txt)
	local command = string.sub(txt, 1, 4)
	if command ~= "MBID" and command ~= "DKPL" then return end
	
	--get current state
	local Core = mdkp:GetModule("CoreModule", true)
	local active = Core:IsEnabled()
	if not active then 
		self:EnableModules(true) 
		self:ToggleLDBFuStatus(true)
	end
	Core:IncomingWhispers(command, sender, txt)
	
	--turn off if was off
	if not active then 
		self:EnableModules() 
		self:ToggleLDBFuStatus() 
	end
end

function mdkp:addFilter()
	ChatFrame_AddMessageEventFilter("CHAT_MSG_WHISPER", 	function(_, event, msg, player)
									txt = string.utf8upper(msg)
									local command = string.sub(txt, 1, 4)
									if command ~= "MBID" and command ~= "DKPL" then return nil end
									return true
								end
	)
end

