About:
- This is a skin for Button Facade that will add some custom button styles to the supported action bars.

Installation:
- Download the package.
- Extract the package to your "World of Warcraft\Interface\AddOns" directory.

This package and its contents are not to be duplicated, redistributed or included in any compilation without the permission of the author(s).