﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Inventory", "zhCN" )

if not L then return end

L["Heroic"] = "英雄模式"
L["Trash Mobs"] = "小怪掉落"

