Backport of the addon BiS-Tooltip for 3.3.5a https://www.curseforge.com/wow/addons/bis-tooltip
