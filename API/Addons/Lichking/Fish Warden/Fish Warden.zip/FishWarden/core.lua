﻿--GUID global.
FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b = {};

local FishWarden = FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b;

FishWarden.Locale = {};

FishWarden.FWVERSION = GetAddOnMetadata("FishWarden", "Version");

-- This is a list of the achievement ID numbers.
-- These MUST be "You must catch SPECIFIC fish/item" - i.e. it won't work with you need to fish from x pool etc..
-- Other achievements will be ignored, and may cause error - who knows
-- Achievements with special cases (i.e. returns 0 critera) have fishids put into SpcAchieveFilters
FishWarden.AchieveFilters =
    {
    726, -- Mr. Pinchy's Magical Crawdad Box
    878, -- One That Didn't Get Away
    1836, -- Old Crafty
    1837, -- Old Ironjaw
    2094, -- A Penny For Your Thoughts
    2095, -- Silver in the City
    1957, -- There's Gold In That There Fountain
    1958, -- I Smell A Giant Rat
    3218, -- Turtles All the Way Down
    };

-- This is a list of requirements for achievements which fail to work as implemented above (i.e. return 0 critera)
-- The list is done so that k = int(AchieveID), v = {fishid1, fishid2, ...} - i.e. v is an integer list, or a single int
FishWarden.SpcAchieveFilters =
    {
    [726] = 27388, -- Mr. Pinchy himself!
    [1836] = 34486,
    [1837] = 34484,
    [1958] = 43698,
    [3218] = 46109,
    };

-- This is a list of "Quest Fish" which are not marked as "Quest Items" in the game.
-- This list is not comprehensive, and only supplementary to checking for "Quest" item class. Format is k = int(FishID), v = true;
FishWarden.SpcQuestFilters =
    {
    [13757] = true, -- Lightning Eel
    [13890] = true, -- Plated Armorfish
    };

-- This is a list of generic filters.
-- The list is done so k = "NameOfSavedVar", v = {fishid1, fishid2, ...} - i.e. v is an integer list, or a single int
FishWarden.OtherFilters =
    {
    ["FilterMiscFishFeast"] = {41806, 41809, 41813},
    ["FilterMiscSTVContest"] = {19807, 19805, 19806, 19803},
    ["FilterMiscKaluakContest"] = 50289,
    ["FilterMiscContainers"] = {
        6356, --Battered Chest
        7973, --Big-mouth Clam
        35313, --Bloated Barbed Gill Trout
        6647, --Bloated Catfish
        35286, --Bloated Giant Sunfish
        45328, --Bloated Monsterbelly
        6645, --Bloated Mud Snapper
        13881, --Bloated Redgill
        13891, --Bloated Salmon
        45328, --Bloated Slippery Eel
        6643, --Bloated Smallfish
        8366, --Bloated Trout
        27513, --Curious Crate
        36781, --Darkwater Clam
        6351, --Dented Crate
        45909, --Giant Darkwater Clam
        13874, --Heavy Crate
        27481, --Heavy Supply Crate
        27511, --Inscribed Scrollcase
        21150, --Iron Bound Trunk
        13875, --Ironbound Locked Chest
        24476, --Jaggal Clam
        6307, --Message in a Bottle
        21228, --Mithril Bound Trunk
        44475, --Reinforced Crate
        6357, --Sealed Crate
        6353, --Small Chest
        6354, --Small Locked Chest
        6355, --Sturdy Locked Chest
        20708, --Tightly Sealed Trunk
        6352, --Waterlogged Crate
        21113, --Watertight Trunk
        },
    ["FilterMiscEquippable"] = {
        6292, --10 Pound Mud Snapper
        6294, --12 Pound Mud Snapper
        6295, --15 Pound Mud Snapper
        13901, --15 Pound Salmon
        13902, --18 Pound Salmon
        13903, --22 Pound Salmon
        13904, --25 Pound Salmon
        13905, --29 Pound Salmon
        6309, --17 Pound Catfish
        6310, --19 Pound Catfish
        6311, --22 Pound Catfish
        6363, --26 Pound Catfish
        6364, --32 Pound Catfish
        13885, --34 Pound Redgill
        13886, --37 Pound Redgill
        13882, --42 Pound Redgill
        13883, --45 Pound Redgill
        13884, --49 Pound Redgill
        13887, --52 Pound Redgill
        13914, --70 Pound Mightfish
        13915, --85 Pound Mightfish
        13916, --92 Pound Mightfish
        13917, --103 Pound Mightfish
        43659, --Bloodied Prison Shank
        6651, --Broken Wine Bottle
        44703, --Dark Herring
        6366, --Darkwood Fishing Pole
        44505, --Dustbringer
        27516, --Enormous Barbed Gill Trout
        27515, --Huge Spotted Feltail
        34486, --Old Crafty
        34484, --Old Ironjaw
        19808, --Rockhide Strongfish
        6360, --Steelscale Crushfish
        8350, --The 1 Ring
        },
    };

