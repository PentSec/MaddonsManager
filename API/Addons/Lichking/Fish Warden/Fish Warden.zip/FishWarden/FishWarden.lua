local FishWarden = FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b;

local MainFrame = FishWarden.GUI.MainFrame;
MainFrame:DoInit();
MainFrame:RegisterEvent("PLAYER_LOGIN");

local AchieveFrame = FishWarden.GUI.AchieveFrame;
local QualityFrame = FishWarden.GUI.QualityFrame;
local MiscFrame = FishWarden.GUI.MiscFrame;
local CustomFrame = FishWarden.GUI.CustomFrame;

SlashCmdList['FishWarden_GUI'] = FishWarden.GUI.MainFrame.Toggle;

_G['SLASH_FishWarden_GUI1'] = '/fishwarden';
_G['SLASH_FishWarden_GUI2'] = '/fward';

--[[
    Most of the tables used are cleared by setting each value to false when needed, instead of wiping the table
    This takes a little bit more CPU time; however, it saves on memory in the long run, and cuts down on garbage pile up
  ]]

-- This table will hold boolean variables, k = int(fishid), v = needtocatch
-- This is updated at loot time
FishWarden.AchieveFish = {};

-- This table will hold boolean variables, k = int(fishid), v = needtocatch
-- This is updated at loot time if the config changed at any point
-- OtherFish.Valid is not true when the list needs to be updated
FishWarden.OtherFish = {};

-- This table will hold boolean variables, k = int(fishid), v = needtocatch
-- This is updated at login, and if the Custom filter text changes (user presses 'Update')
FishWarden.CustomFish = {};

-- This table will a list of text strings to search against the item name
-- This is updated at login, and if the Custom filter text changes (user presses 'Update')
-- This table is wiped on Update
FishWarden.CustomText = {};

-- This table will be a boolean list, k = int(loot slot #), v = needtoloot
-- This is updated at LOOT_OPEN, and per LOOT_SLOT_CLEARED so FishWarden can know when it's safe to close the loot window
-- This table grows only as large as ever needed, and never shrinks or wipes
-- LootSlots.NumSlots reflects how many slots are in the current loot window
FishWarden.LootSlots = {};

function FishWarden:PLAYER_LOGIN()
    if (not FishWardenDB) then
        FishWardenDB = {};
    end

    FishWarden.CharName = (UnitName("player")) .. " - " .. (GetRealmName());
    if (FishWardenDB[FishWarden.CharName]) then
        FishWarden.Vars = FishWardenDB[FishWarden.CharName];
    else
        FishWardenDB[FishWarden.CharName] = {};
        FishWarden.Vars = FishWardenDB[FishWarden.CharName];
    end

    --Defaults
    if (FishWarden.Vars.Enable == nil) then FishWarden.Vars.Enable = true; end
    if (FishWarden.Vars.FilterMiscPriceVal == nil) then FishWarden.Vars.FilterMiscPriceVal = 10000; end
    if (not FishWarden.Vars.FilterAchieve) then
        FishWarden.Vars.FilterAchieve = {};
        for i, v in ipairs(FishWarden.AchieveFilters) do -- Transfer old variables to table.
            v = tonumber(v);
            if (v) then
                FishWarden.Vars.FilterAchieve[v] = FishWarden.Vars["FilterAchieve" .. v];
                FishWarden.Vars["FilterAchieve" .. v] = nil;
            end
        end
    end
    if (not FishWarden.Vars.FilterQuality) then
        FishWarden.Vars.FilterQuality = {};
        for i = 0, 7 do -- Transfer old variables to table.
            FishWarden.Vars.FilterQuality[i] = FishWarden.Vars["FilterQuality" .. i];
            FishWarden.Vars["FilterQuality" .. i] = nil;
        end
    end

    -- Check if we need to reset Auto Loot after a camp or reload
    if (FishWarden.Vars.HadAutoLoot) then
        SetCVar("autoLootDefault", "1", AUTO_LOOT_DEFAULT_TEXT);
        FishWarden.Vars.HadAutoLoot = false;
    end

    -- Actually start doing addon stuff now
    if (FishWarden.Vars.Enable) then
        MainFrame:RegisterEvent("LOOT_OPENED");
    end

    FishWarden.itQuest = (select(12, GetAuctionItemClasses()));
    FishWarden.FishingSpell = GetSpellInfo(7620);

    InterfaceOptions_AddCategory(MainFrame);
    AchieveFrame:DoInit();
    QualityFrame:DoInit();
    MiscFrame:DoInit();
    CustomFrame:DoInit();

    FishWarden:UpdateOtherFish();
    FishWarden:UpdateCustomFish();

    hooksecurefunc("TurnOrActionStart", FishWarden.TurnOrActionStart);
end

function FishWarden:SetEnable()
    FishWarden.Vars.Enable = not FishWarden.Vars.Enable;
    if (FishWarden.Vars.Enable) then
        if (not MainFrame:IsEventRegistered("LOOT_OPENED")) then
            MainFrame:RegisterEvent("LOOT_OPENED");
        end
    else
        if (MainFrame:IsEventRegistered("LOOT_OPENED")) then
            MainFrame:UnregisterEvent("LOOT_OPENED");
        end
    end
end

function FishWarden:SetAchieve(AchieveID)
    assert(AchieveID, "Bad call to SetAchieve.");
    AchieveID = tonumber(AchieveID);
    assert(AchieveID, "SetAchieve: Achievement ID could not be read as a number.");
    FishWarden.Vars.FilterAchieve[AchieveID] = not FishWarden.Vars.FilterAchieve[AchieveID];
end

function FishWarden:SetQuality(QualityID)
    assert(QualityID, "Bad call to SetQuality.");
    QualityID = tonumber(QualityID);
    assert(QualityID, "SetQuality: Quality ID was not a number.");
    FishWarden.Vars.FilterQuality[QualityID] = not FishWarden.Vars.FilterQuality[QualityID];
end

function FishWarden:UpdateCriteria()
    local curcount, curtype, curid, complete, _;
    for k, v in pairs(FishWarden.AchieveFish) do
        FishWarden.AchieveFish[k] = false;
    end

    for i, v in ipairs(FishWarden.AchieveFilters) do
        assert(v, "UpdateCriteria: Achievement Filter list is borked.");
        v = tonumber(v);
        assert(v, "UpdateCriteria: Achievement ID could not be read as a number.");
        complete = select(4, GetAchievementInfo(v));
        if (not complete and FishWarden.Vars.FilterAchieve[v]) then
            if (FishWarden.SpcAchieveFilters[v]) then
                local w = FishWarden.SpcAchieveFilters[v];
                if (type(w) == "number") then
                    FishWarden.AchieveFish[w] = true;
                elseif (type(w) == "table") then
                    for k, x in ipairs(w) do
                        FishWarden.AchieveFish[tonumber(x)] = true;
                    end
                else
                    assert(nil, "Invalid value type for Special Achievement Filter.")
                end
            else
                for j=1, GetAchievementNumCriteria(v) do
                    _, curtype, complete, _, _, _, _, curid = GetAchievementCriteriaInfo(v, j);
                    if (not complete and (curtype == 42 or curtype == 36)) then
                        FishWarden.AchieveFish[tonumber(curid)] = true;
                    end
                end
            end
        end
    end
end

function FishWarden:UpdateOtherFish()
    for k, v in pairs(FishWarden.OtherFish) do
        FishWarden.OtherFish[k] = false;
    end

    for k, v in pairs(FishWarden.OtherFilters) do
        if (FishWarden.Vars[k]) then
            if (type(v) == "number") then
                FishWarden.OtherFish[v] = true;
            elseif (type(v) == "table") then
                for i, w in pairs(v) do
                    FishWarden.OtherFish[tonumber(w)] = true;
                end
            else
                assert(nil, "OtherFilters list fail. Value is not a number or table.");
            end
        end
    end
    FishWarden.OtherFish.Valid = true;
end

function FishWarden:ProcessCustomFish(...)
    local token;
    for i = 1, select('#', ...) do
        token = select(i, ...);
        if (token) then token = strsplit("#", token, 2); end
        if (token) then token = strtrim(token, " \t\"[]"); end
        if (token and strlen(token) > 0) then
            if (tonumber(token)) then
                FishWarden.CustomFish[tonumber(token)] = true;
            else
                tinsert(FishWarden.CustomText, strlower(token));
            end
        end
    end
end

function FishWarden:UpdateCustomFish()
    local text = FishWarden.Vars.FilterCustomText;
    if (not text) then text = ""; end

    for k, v in pairs(FishWarden.CustomFish) do
        FishWarden.CustomFish[k] = false;
    end
    wipe(FishWarden.CustomText);

    FishWarden:ProcessCustomFish(strsplit(":\r\n", text));
end

function FishWarden:TakeLoot(slot)
    if (FishWarden.Vars.AutoCloseLoot and not MainFrame:IsEventRegistered("LOOT_SLOT_CLEARED")) then
        MainFrame:RegisterEvent("LOOT_SLOT_CLEARED");
        MainFrame:RegisterEvent("LOOT_CLOSED");
    end
    FishWarden.LootSlots[slot] = 1;
    LootSlot(slot);
end

local FISH_WARDEN_IGNORED = "|cffffffffFish Warden - " .. IGNORED .. ":|r";
function FishWarden:PrintIgnore()
    local firstignore;

    for i=1, FishWarden.LootSlots.NumSlots do
        if (FishWarden.LootSlots[i] == -1) then
            firstignore = i;
            break;
        end
    end

    if (firstignore) then
        print(FISH_WARDEN_IGNORED, FishWarden:ListIgnore(firstignore));
    end
end

function FishWarden:ListIgnore(curslot)
    if (curslot > FishWarden.LootSlots.NumSlots) then
        return;
    elseif (FishWarden.LootSlots[curslot] == -1) then
        return GetLootSlotLink(curslot), FishWarden:ListIgnore(curslot + 1);
    else
        return FishWarden:ListIgnore(curslot + 1);
    end
end

function FishWarden:CloseLoot()
    for i=1, FishWarden.LootSlots.NumSlots do
        if (FishWarden.LootSlots[i] == 1) then
            return;
        end
    end

    CloseLoot(); -- We reached the end of the list without finding an unlooted keeper
end

function FishWarden.TurnOrActionStart()
    local channel = UnitChannelInfo("player");
    if (FishWarden.Vars.Enable and channel == FishWarden.FishingSpell) then
        if (GetCVarBool("autoLootDefault")) then
            FishWarden.Vars.HadAutoLoot = true;
            SetCVar("autoLootDefault", "0", AUTO_LOOT_DEFAULT_TEXT);
        end
    elseif (FishWarden.Vars.HadAutoLoot) then
        SetCVar("autoLootDefault", "1", AUTO_LOOT_DEFAULT_TEXT);
        FishWarden.Vars.HadAutoLoot = false;
    end
end

function FishWarden:LOOT_OPENED(autolooting)
    if (not IsFishingLoot()) then
        return;
    end
    if (autolooting ~= 0) then
        FishWarden:Warn(FishWarden.Locale.AutoLootError, "Sound\\Creature\\GnomeSpiderTank\\GnomeSpiderTankDeath.wav");
        return;
    end

    FishWarden:UpdateCriteria();
--[[ Currently there's no easy way to see if we actually need to update achievement criteria.
     The code to step through each selected achievement to check if any new criteria has been completed
     would be more time consuming than just rebuilding the list each loot.
     To keep the memory usage down, the list never shrinks or wipes, the keys are integers, and the values are boolean
  ]]
    if (not FishWarden.OtherFish.Valid) then FishWarden:UpdateOtherFish(); end

    FishWarden.LootSlots.NumSlots = GetNumLootItems();
    local link, itemname, itemid, quality, itemtype, itemprice, _;
    for i=1, GetNumLootItems() do
        FishWarden.LootSlots[i] = -1;
        if (LootSlotIsCoin(i)) then
            FishWarden:TakeLoot(i); -- If can ever fish up coin (gold/silver/copper) currency just take it.
        elseif (LootSlotIsItem(i)) then
            link = GetLootSlotLink(i);
            if (link) then
                itemid = tonumber((select(2,strsplit(":", link))));
                _, itemname, _, quality = GetLootSlotInfo(i);
                itemtype, _, _, _, _, itemprice = select(6, GetItemInfo(itemid));
                if (FishWarden.Vars.FilterQuality[quality]) then FishWarden:TakeLoot(i);
                elseif (FishWarden.Vars.FilterMiscQuest and itemtype == FishWarden.itQuest) then FishWarden:TakeLoot(i);
                elseif (FishWarden.Vars.FilterMiscQuest and FishWarden.SpcQuestFilters[itemid]) then FishWarden:TakeLoot(i);
                elseif (FishWarden.Vars.FilterMiscPrice and itemprice and itemprice >= FishWarden.Vars.FilterMiscPriceVal) then
                    FishWarden:TakeLoot(i);
                elseif (FishWarden.AchieveFish[itemid]) then FishWarden:TakeLoot(i);
                elseif (FishWarden.OtherFish[itemid]) then FishWarden:TakeLoot(i);
                elseif (FishWarden.Vars.FilterCustomEnable and FishWarden.CustomFish[itemid]) then FishWarden:TakeLoot(i);
                elseif (FishWarden.Vars.FilterCustomEnable and itemname) then
                    itemname = strlower(itemname);
                    for j, v in ipairs(FishWarden.CustomText) do
                        if (v and strfind(itemname, v)) then FishWarden:TakeLoot(i); break; end
                    end
                end
            end
        end
    end

    if (FishWarden.Vars.AutoCloseLoot) then
        MainFrame:RegisterEvent("CHAT_MSG_ADDON"); -- We fire this immediately after LOOT_OPENED from fishing
        SendAddonMessage("Fish Warden", "RunCloseLoot", "WHISPER", (UnitName("player")));
    end
end

function FishWarden:CHAT_MSG_ADDON(prefix, message, channel, sender)
    -- Now every addon should've had a chance to process LOOT_OPENED, so let's see if we can close it
    if (prefix == "Fish Warden" and message == "RunCloseLoot" and channel == "WHISPER" and sender == (UnitName("player"))) then
        if (LootFrame:IsShown()) then
            FishWarden:PrintIgnore();
            FishWarden:CloseLoot();
        end
        MainFrame:UnregisterEvent("CHAT_MSG_ADDON");
    end
end

function FishWarden:LOOT_SLOT_CLEARED(slot)
    if (IsFishingLoot() and FishWarden.Vars.AutoCloseLoot) then
        assert(slot, "Event LOOT_SLOT_CLEARED called without a slot number.");
        assert(type(slot) == "number", "Event LOOT_SLOT_CLEARED called with invalid slot type.");
        FishWarden.LootSlots[slot] = 0;
        FishWarden:CloseLoot();
    else
        MainFrame:UnregisterEvent("LOOT_SLOT_CLEARED");
    end
end

function FishWarden:LOOT_CLOSED()
    if (MainFrame:IsEventRegistered("LOOT_SLOT_CLEARED")) then
        MainFrame:UnregisterEvent("LOOT_SLOT_CLEARED");
    end
    MainFrame:UnregisterEvent("LOOT_CLOSED");
end

local LastWarn = "";
local LastWarnTime = -2;
function FishWarden:Warn(msg, sound)
    if ((msg ~= LastWarn) or (GetTime() - 2 >= LastWarnTime)) then
        LastWarn = msg;
        LastWarnTime = GetTime();
        RaidNotice_AddMessage(RaidBossEmoteFrame, msg, ChatTypeInfo["RAID_WARNING"]);
        PlaySoundFile(sound);
    end
end

