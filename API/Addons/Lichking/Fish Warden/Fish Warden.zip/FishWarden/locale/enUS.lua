local FishWarden = FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b;

--Options
if (not FishWarden.Locale.AutoClose) then
    FishWarden.Locale.AutoClose = "Automatically release unwanted fish.";
end

--Filters
if (not FishWarden.Locale.Containers) then
    FishWarden.Locale.Containers = "Crates and Clams";
end
if (not FishWarden.Locale.STVContest) then
    FishWarden.Locale.STVContest = "Stranglethorn Fishing Extravaganza";
end
if (not FishWarden.Locale.KaluakContest) then
    FishWarden.Locale.KaluakContest = "Kalu'ak Fishing Derby";
end

--Help
if (not FishWarden.Locale.Help) then
    FishWarden.Locale.Help = "Browse the Fish Warden filter categories in the tree to the left. You have to press the '+' button to expand the \"Fish Warden\" tree. Check the filters you want enabled in each category. When you are fishing, right click the bobber normally. Fish Warden will automatically loot the fish which meet the criteria of any of your selected filters. Do not use with the in-game Auto Loot feature.";
end
if (not FishWarden.Locale.HelpCustom) then
    FishWarden.Locale.HelpCustom = "Enter a list of item names or item id numbers that you want to catch. Partial item names are acceptable. Separate each item with a colon (:) or a new line. Comment out a line with a pound sign (#). Press [%s] to save any changes. Press [%s] to revert the list to the last update.";
end

--Errors
if (not FishWarden.Locale.AutoLootError) then
    FishWarden.Locale.AutoLootError = "Fish Warden can not operate if you're using Auto Loot.";
end

