local FishWarden = FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b;

if (GetLocale() == "zhCN") then
    FishWarden.Locale.AutoClose = "自动释放不想要的鱼。";

    FishWarden.Locale.AutoLootError = "开启“自动拾取”不能使用 Fish Warden 功能。";

    FishWarden.Locale.Containers = "箱子与蚌壳";

    FishWarden.Locale.Help = "浏览左侧 Fish Warden 类别列表。点开“+”按钮展开“Fish Warden”列表。选择需要启动的类别过滤。当你钓鱼时，右击鱼漂，Fish Warden 将自动拾取所选过滤匹配的鱼类。请不要开启游戏中“自动拾取”功能。";

    FishWarden.Locale.HelpCustom = "输入想钓取的物品列表名称或物品 ID。物品名称简写可以使用。每个物品单独用冒号（:）或新的一行。注释此行使用井字符（#）。[%s] 保存修改。[%s] 复原上次更新列表。";

    FishWarden.Locale.KaluakContest = "卡鲁亚克钓鱼大赛";

    FishWarden.Locale.STVContest = "荆棘谷钓鱼大赛";
end

