local FishWarden = FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b;

if (GetLocale() == "deDE") then
    -- AutoClose = "";
    -- AutoLootError = "";
    -- Containers = "";
    -- Help = "";
    -- HelpCustom = "";
    FishWarden.Locale.KaluakContest = "Angelwettstreit der Kalu'ak";

    FishWarden.Locale.STVContest = "Anglerwettbewerb im Schlingendorntal";
end

