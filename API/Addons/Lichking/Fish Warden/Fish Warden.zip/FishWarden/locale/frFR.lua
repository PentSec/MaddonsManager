local FishWarden = FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b;

if (GetLocale() == "frFR") then
    FishWarden.Locale.AutoClose = "Relâche automatiquement les poissons non désirable";

    FishWarden.Locale.Containers = "Caisses et palourdes";

    FishWarden.Locale.STVContest = "Concours de pêche de Strangleronce";

    FishWarden.Locale.KaluakContest = "Le tournoi de pêche kalu'ak";

    FishWarden.Locale.Help = "Parcourir les filtres des catégories de Fish Warden dans l'arborescence à gauche. Vous devez appuyer sur le bouton '+' pour ouvrir la liste de \"Fish Warden\". Vérifiez les filtres que vous voulez activer dans chaque catégorie. Lorsque vous pêchez, un clic droit sur le bouchon. Fish Warden pêche automatiquement les poissons qui répondent aux critères de votre liste.";

    FishWarden.Locale.HelpCustom = "Entrez une liste de noms d'articles ou un numéro d'identification. Les noms des éléments partiels sont acceptables. Séparez chaque élément avec deux-points (:) ou une nouvelle ligne. Pour un commentaire sur une ligne avec un signe dièse (#). Appuyez sur [%s] pour enregistrer les modifications. Appuyez sur [%s] pour revenir sur la liste à la dernière mise à jour.";

    FishWarden.Locale.AutoLootError = "Fish Warden ne peut pas fonctionner si vous utilisez Auto Loot.";
end

