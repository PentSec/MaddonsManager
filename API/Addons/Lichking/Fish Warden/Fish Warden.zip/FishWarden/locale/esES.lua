local FishWarden = FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b;

if (GetLocale() == "esES") then
    -- AutoClose = "";
    -- AutoLootError = "";
    -- Containers = "";
    -- Help = "";
    -- HelpCustom = "";
    FishWarden.Locale.KaluakContest = "Competición de pesca Kalu'ak";

    FishWarden.Locale.STVContest = "Gran espectáculo de pesca de Tuercespina";
end

