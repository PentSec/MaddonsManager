local FishWarden = FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b;

if (GetLocale() == "koKR") then
    -- Help = "";
    -- HelpCustom = "";

    FishWarden.Locale.AutoClose = "자동으로 원치 않는 물고기를 제거합니다.";

    FishWarden.Locale.AutoLootError = "만약 당신이 자동 전리품 획득을 사용하고 있다면, Fish Warden은 비활성화 됩니다.";

    FishWarden.Locale.Containers = "나무상자와 조개";

    FishWarden.Locale.KaluakContest = "칼루아크 낚시 대회";

    FishWarden.Locale.STVContest = "가시덤블 골짜기 낚시 대회";
end

