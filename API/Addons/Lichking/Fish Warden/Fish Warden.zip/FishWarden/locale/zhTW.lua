local FishWarden = FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b;

if (GetLocale() == "zhTW") then
    FishWarden.Locale.AutoClose = "自動釋放不想要的魚。";

    FishWarden.Locale.AutoLootError = "開啟“自動拾取”不能使用 Fish Warden 功能。";

    FishWarden.Locale.Containers = "箱子與蚌殼";

    FishWarden.Locale.Help = "瀏覽左側 Fish Warden 類別列表。點開“+”按鈕展開“Fish Warden”列表。選擇需要啟動的類別過濾。當你釣魚時，右擊魚漂，Fish Warden 將自動拾取所選過濾匹配的魚類。請不要開啟遊戲中“自動拾取”功能。";

    FishWarden.Locale.HelpCustom = "輸入想釣取的物品列表名稱或物品 ID。物品名稱簡寫可以使用。每個物品單獨用冒號（:）或新的一行。註釋此行使用井字符（#）。 [%s] 保存修改。 [%s] 復原上次更新列表。";

    FishWarden.Locale.KaluakContest = "卡魯耶克釣魚大賽";

    FishWarden.Locale.STVContest = "荊棘谷釣魚競賽";
end

