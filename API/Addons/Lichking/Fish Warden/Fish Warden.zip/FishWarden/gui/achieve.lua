local FishWarden = FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b;

FishWarden.GUI.AchieveFrame = CreateFrame("Frame", "FishWardenAchievePanel", UIParent);

local MainFrame = FishWarden.GUI.MainFrame;
local AchieveFrame = FishWarden.GUI.AchieveFrame;

function AchieveFrame:DoInit()
    local checkwidth = 26;

    AchieveFrame.name = ACHIEVEMENTS;
    AchieveFrame.parent = MainFrame.name;
    InterfaceOptions_AddCategory(AchieveFrame);
    AchieveFrame:SetScript("OnShow", AchieveFrame.ShowHandler);
    
    AchieveFrame.iddTitle = AchieveFrame:CreateFontString("$parent_Title","ARTWORK","GameFontNormalLarge");
    AchieveFrame.iddTitle:SetPoint("TOPLEFT", AchieveFrame, "TOPLEFT", 13, -13);
    AchieveFrame.iddTitle:SetText(ACHIEVEMENTS);
    AchieveFrame.iddTitle:SetJustifyH("CENTER");

    local lastanchor = AchieveFrame.iddTitle;
    local curcheck;
    AchieveFrame.CheckList = {};
    for i, v in ipairs(FishWarden.AchieveFilters) do
        AchieveFrame.CheckList[i] = CreateFrame("CheckButton", "$parent_AchieveBtn" .. v,
                                                AchieveFrame, "UICheckButtonTemplate");
        curcheck = AchieveFrame.CheckList[i];
        curcheck:SetWidth(checkwidth);
        curcheck:SetHeight(checkwidth);
        curcheck:SetPoint("TOPLEFT", lastanchor, "BOTTOMLEFT", 0, 0);
        lastanchor = curcheck;
        curcheck.AchieveID = v;
        curcheck:SetScript("OnClick", AchieveFrame.OnClickAchieve);

        curcheck.iddText = getglobal(curcheck:GetName() .. 'Text');
        -- Note the redundant set of parantheses actually changes the return of 'select' from a list to a single value
        curcheck.iddText:SetText( (select(2, GetAchievementInfo(v))) );
        curcheck.iddText:SetJustifyH("LEFT");

        curcheck.iddClicker = CreateFrame("Button", "$parent_AchieveBtnClicker" .. v, AchieveFrame);
        curcheck.iddClicker:SetAllPoints(AchieveFrame.CheckList[i].iddText);
        curcheck.iddClicker.AchieveID = v;
        curcheck.iddClicker:SetScript("OnClick", AchieveFrame.OnClickAchieve);
        curcheck.iddClicker:SetScript("OnEnter", function ()
                AchieveFrame.CheckList[i]:LockHighlight();
                GameTooltip:SetOwner(AchieveFrame.CheckList[i].iddClicker, "ANCHOR_NONE");
                GameTooltip:SetPoint("TOPLEFT", AchieveFrame.CheckList[i].iddClicker, "TOPRIGHT");
                GameTooltip:ClearLines();
                GameTooltip:SetHyperlink(GetAchievementLink(v));
                GameTooltip:Show();
            end);
        curcheck.iddClicker:SetScript("OnLeave", function ()
                AchieveFrame.CheckList[i]:UnlockHighlight();
                GameTooltip:Hide();
            end);
    end
end

function AchieveFrame:refresh()
    for i, v in ipairs(AchieveFrame.CheckList) do
        v:SetChecked(FishWarden.Vars.FilterAchieve[v.AchieveID]);
    end
end

function AchieveFrame:ShowHandler(...)
    local maxwidth = AchieveFrame:GetWidth();
    if (maxwidth == 0) then maxwidth = 413; end

    AchieveFrame.iddTitle:SetWidth(maxwidth - 26);

    for i, v in ipairs(AchieveFrame.CheckList) do
        v.iddText:SetWidth( min(v.iddText:GetStringWidth(), maxwidth - v:GetWidth() - 26) );
    end
end

function AchieveFrame:OnClickAchieve(button)
    assert(self.AchieveID, "Invalid call to OnClickAchieve. No self.AchieveID");
    if (button == "LeftButton") then
        FishWarden:SetAchieve(self.AchieveID);
        AchieveFrame:refresh();
    end
end

