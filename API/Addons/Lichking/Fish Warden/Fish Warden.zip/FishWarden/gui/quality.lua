local FishWarden = FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b;

FishWarden.GUI.QualityFrame = CreateFrame("Frame", "FishWardenQualityPanel", UIParent);

local MainFrame = FishWarden.GUI.MainFrame;
local QualityFrame = FishWarden.GUI.QualityFrame;

function QualityFrame:DoInit()
    local checkwidth = 26;

    QualityFrame.name = QUALITY;
    QualityFrame.parent = MainFrame.name;
    InterfaceOptions_AddCategory(QualityFrame);
    QualityFrame:SetScript("OnShow", QualityFrame.ShowHandler);
    
    QualityFrame.iddTitle = QualityFrame:CreateFontString("$parent_Title","ARTWORK","GameFontNormalLarge");
    QualityFrame.iddTitle:SetPoint("TOPLEFT", QualityFrame, "TOPLEFT", 13, -13);
    QualityFrame.iddTitle:SetText(QUALITY);
    QualityFrame.iddTitle:SetJustifyH("CENTER");

    local lastanchor = QualityFrame.iddTitle;
    local curcheck;
    QualityFrame.CheckList = {};
    for i=0, 7 do
        QualityFrame.CheckList[i] = CreateFrame("CheckButton", "$parent_QualityBtn" .. i,
                                                QualityFrame, "UICheckButtonTemplate");
        curcheck = QualityFrame.CheckList[i];
        curcheck:SetWidth(checkwidth);
        curcheck:SetHeight(checkwidth);
        curcheck:SetPoint("TOPLEFT", lastanchor, "BOTTOMLEFT", 0, 0);
        lastanchor = curcheck;
        curcheck.QualityID = i;
        curcheck:SetScript("OnClick", QualityFrame.OnClickQuality);

        curcheck.iddText = getglobal(curcheck:GetName() .. 'Text');
        -- Note the redundant set of parantheses actually changes the return of 'select' from a list to a single value
        curcheck.iddText:SetText( (select(4, GetItemQualityColor(i))) ..
                                                getglobal("ITEM_QUALITY" .. i .. "_DESC") .. "|r");
        curcheck.iddText:SetJustifyH("LEFT");

        curcheck.iddClicker = CreateFrame("Button", "$parent_QualityBtnClicker" .. i, QualityFrame);
        curcheck.iddClicker:SetAllPoints(QualityFrame.CheckList[i].iddText);
        curcheck.iddClicker.QualityID = i;
        curcheck.iddClicker:SetScript("OnClick", QualityFrame.OnClickQuality);
        curcheck.iddClicker:SetScript("OnEnter", function ()
                QualityFrame.CheckList[i]:LockHighlight();
            end);
        curcheck.iddClicker:SetScript("OnLeave", function ()
                QualityFrame.CheckList[i]:UnlockHighlight();
            end);
    end
end

function QualityFrame:refresh()
    for i=0, #QualityFrame.CheckList do
        QualityFrame.CheckList[i]:SetChecked(FishWarden.Vars.FilterQuality[i]);
    end
end

function QualityFrame:ShowHandler(...)
    local maxwidth = QualityFrame:GetWidth();
    if (maxwidth == 0) then maxwidth = 413; end

    QualityFrame.iddTitle:SetWidth(maxwidth - 26);

    for i, v in ipairs(QualityFrame.CheckList) do
        v.iddText:SetWidth( min(v.iddText:GetStringWidth(), maxwidth - v:GetWidth() - 26) );
    end
end

function QualityFrame:OnClickQuality(button)
    assert(self.QualityID, "Invalid call to OnClickQuality. No self.QualityID");
    if (button == "LeftButton") then
        FishWarden:SetQuality(self.QualityID);
        QualityFrame:refresh();
    end
end

