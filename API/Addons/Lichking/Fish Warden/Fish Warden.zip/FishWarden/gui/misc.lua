local FishWarden = FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b;

FishWarden.GUI.MiscFrame = CreateFrame("Frame", "FishWardenMiscPanel", UIParent);

local MainFrame = FishWarden.GUI.MainFrame;
local MiscFrame = FishWarden.GUI.MiscFrame;

function MiscFrame:DoInit()
    local checkwidth = 26;

    MiscFrame.name = MISCELLANEOUS;
    MiscFrame.parent = MainFrame.name;
    InterfaceOptions_AddCategory(MiscFrame);
    MiscFrame:SetScript("OnShow", MiscFrame.ShowHandler);
    
    MiscFrame.iddTitle = MiscFrame:CreateFontString("$parent_Title","ARTWORK","GameFontNormalLarge");
    MiscFrame.iddTitle:SetPoint("TOPLEFT", MiscFrame, "TOPLEFT", 13, -13);
    MiscFrame.iddTitle:SetText(MISCELLANEOUS);
    MiscFrame.iddTitle:SetJustifyH("CENTER");

    MiscFrame.iddQuestBtn = MiscFrame:AddCheck(ITEM_BIND_QUEST, "$parent_QuestBtn", MiscFrame.OnClickQuest,
        MiscFrame.iddTitle, checkwidth);
    -- Note the redundant set of parantheses actually changes the return of 'select' from a list to a single value
    MiscFrame.iddFishFeastBtn = MiscFrame:AddCheck((GetSpellInfo(57426)), "$parent_FishFeastBtn",
        MiscFrame.OnClickFishFeast, MiscFrame.iddQuestBtn, checkwidth);
    MiscFrame.iddContainersBtn = MiscFrame:AddCheck(FishWarden.Locale.Containers, "$parent_ContainersBtn",
        MiscFrame.OnClickContainers, MiscFrame.iddFishFeastBtn, checkwidth);
    MiscFrame.iddEquippableBtn = MiscFrame:AddCheck(TUTORIAL_TITLE24, "$parent_EquippableBtn",
        MiscFrame.OnClickEquippable, MiscFrame.iddContainersBtn, checkwidth);
    MiscFrame.iddSTVContestBtn = MiscFrame:AddCheck(FishWarden.Locale.STVContest, "$parent_STVContestBtn",
        MiscFrame.OnClickSTVContest, MiscFrame.iddEquippableBtn, checkwidth);
    MiscFrame.iddKaluakContestBtn = MiscFrame:AddCheck(FishWarden.Locale.KaluakContest, "$parent_KaluakContestBtn",
        MiscFrame.OnClickKaluakContest, MiscFrame.iddSTVContestBtn, checkwidth);

    MiscFrame.iddPriceBtn = MiscFrame:AddCheck(SELL_PRICE .. " >= ", "$parent_PriceBtn", MiscFrame.OnClickPrice,
        MiscFrame.iddKaluakContestBtn, checkwidth);
    MiscFrame.iddPriceVal = CreateFrame("Frame", "$parent_PriceVal", MiscFrame, "MoneyInputFrameTemplate");
    MiscFrame.iddPriceVal:SetHeight(checkwidth);
    MiscFrame.iddPriceVal:SetPoint("LEFT", MiscFrame.iddPriceBtn.iddText, "RIGHT", 5, 0);
    MiscFrame.iddPriceVal:SetPoint("BOTTOM", MiscFrame.iddPriceBtn, "BOTTOM");
    MoneyInputFrame_SetCopper(MiscFrame.iddPriceVal, FishWarden.Vars.FilterMiscPriceVal);
    MoneyInputFrame_SetOnValueChangedFunc(MiscFrame.iddPriceVal, MiscFrame.OnChangePriceVal);
end

function MiscFrame:AddCheck(text, name, func, anchor, width)
    local btnFrame = CreateFrame("CheckButton", name, MiscFrame, "UICheckButtonTemplate");
    btnFrame:SetWidth(width);
    btnFrame:SetHeight(width);
    btnFrame:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, 0);
    btnFrame:SetScript("OnClick", func);

    btnFrame.iddText = getglobal(btnFrame:GetName() .. 'Text');
    btnFrame.iddText:SetText(text);
    btnFrame.iddText:SetJustifyH("LEFT");

    btnFrame.iddClicker = CreateFrame("Button", name .. "Clicker", MiscFrame);
    btnFrame.iddClicker:SetAllPoints(btnFrame.iddText);
    btnFrame.iddClicker:SetScript("OnClick", func);
    btnFrame.iddClicker:SetScript("OnEnter", function ()
                    btnFrame:LockHighlight();
            end);
    btnFrame.iddClicker:SetScript("OnLeave", function ()
                    btnFrame:UnlockHighlight();
            end);
    return btnFrame;
end

function MiscFrame:refresh()
    MiscFrame.iddQuestBtn:SetChecked(FishWarden.Vars.FilterMiscQuest);
    MiscFrame.iddFishFeastBtn:SetChecked(FishWarden.Vars.FilterMiscFishFeast);
    MiscFrame.iddContainersBtn:SetChecked(FishWarden.Vars.FilterMiscContainers);
    MiscFrame.iddEquippableBtn:SetChecked(FishWarden.Vars.FilterMiscEquippable);
    MiscFrame.iddSTVContestBtn:SetChecked(FishWarden.Vars.FilterMiscSTVContest);
    MiscFrame.iddKaluakContestBtn:SetChecked(FishWarden.Vars.FilterMiscKaluakContest);
    MiscFrame.iddPriceBtn:SetChecked(FishWarden.Vars.FilterMiscPrice);
end

function MiscFrame:ShowHandler(...)
    local maxwidth = MiscFrame:GetWidth();
    if (maxwidth == 0) then maxwidth = 413; end

    MiscFrame.iddTitle:SetWidth(maxwidth - 26);

    MiscFrame.iddPriceBtn.iddText:SetWidth( min(MiscFrame.iddPriceBtn.iddText:GetStringWidth(),
        maxwidth - MiscFrame.iddPriceBtn:GetWidth() - MiscFrame.iddPriceVal:GetWidth() - 26 - 5) );
    MiscFrame.iddQuestBtn.iddText:SetWidth( min(MiscFrame.iddQuestBtn.iddText:GetStringWidth(),
        maxwidth - MiscFrame.iddQuestBtn:GetWidth() - 26) );
    MiscFrame.iddFishFeastBtn.iddText:SetWidth( min(MiscFrame.iddFishFeastBtn.iddText:GetStringWidth(),
        maxwidth - MiscFrame.iddFishFeastBtn:GetWidth() - 26) );
    MiscFrame.iddContainersBtn.iddText:SetWidth( min(MiscFrame.iddContainersBtn.iddText:GetStringWidth(),
        maxwidth - MiscFrame.iddContainersBtn:GetWidth() - 26) );
    MiscFrame.iddEquippableBtn.iddText:SetWidth( min(MiscFrame.iddEquippableBtn.iddText:GetStringWidth(),
        maxwidth - MiscFrame.iddEquippableBtn:GetWidth() - 26) );
    MiscFrame.iddSTVContestBtn.iddText:SetWidth( min(MiscFrame.iddSTVContestBtn.iddText:GetStringWidth(),
        maxwidth - MiscFrame.iddSTVContestBtn:GetWidth() - 26) );
    MiscFrame.iddKaluakContestBtn.iddText:SetWidth( min(MiscFrame.iddKaluakContestBtn.iddText:GetStringWidth(),
        maxwidth - MiscFrame.iddKaluakContestBtn:GetWidth() - 26) );

    MoneyInputFrame_ResetMoney(MiscFrame.iddPriceVal);
    MoneyInputFrame_SetCopper(MiscFrame.iddPriceVal, FishWarden.Vars.FilterMiscPriceVal);
end

function MiscFrame:OnClickQuest(button)
    if (button == "LeftButton") then
        FishWarden.Vars.FilterMiscQuest = not FishWarden.Vars.FilterMiscQuest;
        MiscFrame:refresh();
    end
end

function MiscFrame:OnClickFishFeast(button)
    if (button == "LeftButton") then
        FishWarden.Vars.FilterMiscFishFeast = not FishWarden.Vars.FilterMiscFishFeast;
        FishWarden.OtherFish.Valid = false;
        MiscFrame:refresh();
    end
end

function MiscFrame:OnClickContainers(button)
    if (button == "LeftButton") then
        FishWarden.Vars.FilterMiscContainers = not FishWarden.Vars.FilterMiscContainers;
        FishWarden.OtherFish.Valid = false;
        MiscFrame:refresh();
    end
end

function MiscFrame:OnClickEquippable(button)
    if (button == "LeftButton") then
        FishWarden.Vars.FilterMiscEquippable = not FishWarden.Vars.FilterMiscEquippable;
        FishWarden.OtherFish.Valid = false;
        MiscFrame:refresh();
    end
end

function MiscFrame:OnClickSTVContest(button)
    if (button == "LeftButton") then
        FishWarden.Vars.FilterMiscSTVContest = not FishWarden.Vars.FilterMiscSTVContest;
        FishWarden.OtherFish.Valid = false;
        MiscFrame:refresh();
    end
end

function MiscFrame:OnClickKaluakContest(button)
    if (button == "LeftButton") then
        FishWarden.Vars.FilterMiscKaluakContest = not FishWarden.Vars.FilterMiscKaluakContest;
        FishWarden.OtherFish.Valid = false;
        MiscFrame:refresh();
    end
end

function MiscFrame:OnClickPrice(button)
    if (button == "LeftButton") then
        FishWarden.Vars.FilterMiscPrice = not FishWarden.Vars.FilterMiscPrice;
        MiscFrame:refresh();
    end
end

function MiscFrame.OnChangePriceVal()
    local amount = MoneyInputFrame_GetCopper(MiscFrame.iddPriceVal);
    if (not amount) then amount = 0; end
    FishWarden.Vars.FilterMiscPriceVal = amount;
end

