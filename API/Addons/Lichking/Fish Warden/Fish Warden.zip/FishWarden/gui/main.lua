local FishWarden = FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b;

FishWarden.GUI = {};
FishWarden.GUI.MainFrame = CreateFrame("Frame", "FishWardenPanel", UIParent);

local MainFrame = FishWarden.GUI.MainFrame;

function MainFrame:DoInit()
    local checkwidth = 26;

    MainFrame.name = "Fish Warden";
    MainFrame:SetScript("OnEvent", MainFrame.EventHandler);
    MainFrame:SetScript("OnShow", MainFrame.ShowHandler);
    
    MainFrame.iddTitle = MainFrame:CreateFontString("$parent_Title","ARTWORK","GameFontNormalLarge");
    MainFrame.iddTitle:SetPoint("TOPLEFT", MainFrame, "TOPLEFT", 13, -13);
    MainFrame.iddTitle:SetText("Fish Warden v" .. FishWarden.FWVERSION);
    MainFrame.iddTitle:SetJustifyH("CENTER");
    
    MainFrame.iddHelp = MainFrame:CreateFontString("$parent_Help","ARTWORK","GameFontNormal");
    MainFrame.iddHelp:SetPoint("TOPLEFT", MainFrame.iddTitle, "BOTTOMLEFT", 0, -8);
    MainFrame.iddHelp:SetText("|cffffffff    " .. FishWarden.Locale.Help .. "|r");
    MainFrame.iddHelp:SetJustifyH("LEFT");
    MainFrame.iddHelp:SetJustifyV("TOP");

    MainFrame.iddEnableBtn = MainFrame:AddCheck(ENABLE, "$parent_EnableBtn", MainFrame.OnClickEnable,
        MainFrame.iddHelp, 0, -8, checkwidth);
    MainFrame.iddAutoCloseBtn = MainFrame:AddCheck(FishWarden.Locale.AutoClose, "$parent_AutoCloseBtn",
        MainFrame.OnClickAutoClose, MainFrame.iddEnableBtn, 0, 0, checkwidth);
end

function MainFrame:AddCheck(text, name, func, anchor, xoff, yoff, width)
    local btnframe = CreateFrame("CheckButton", name, MainFrame, "UICheckButtonTemplate");
    btnframe:SetWidth(width);
    btnframe:SetHeight(width);
    btnframe:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", xoff, yoff);
    btnframe:SetScript("OnClick", func);

    btnframe.iddText = getglobal(btnframe:GetName() .. 'Text');
    btnframe.iddText:SetText(text);
    btnframe.iddText:SetJustifyH("LEFT");

    btnframe.iddClicker = CreateFrame("Button", name .. "Clicker", MainFrame);
    btnframe.iddClicker:SetAllPoints(btnframe.iddText);
    btnframe.iddClicker:SetScript("OnClick", func);
    btnframe.iddClicker:SetScript("OnEnter", function () btnframe:LockHighlight(); end);
    btnframe.iddClicker:SetScript("OnLeave", function () btnframe:UnlockHighlight(); end);
    return btnframe;
end

function MainFrame:refresh()
    MainFrame.iddEnableBtn:SetChecked(FishWarden.Vars.Enable);
    MainFrame.iddAutoCloseBtn:SetChecked(FishWarden.Vars.AutoCloseLoot);
end

function MainFrame:Toggle()
    if InterfaceOptionsFrame:IsVisible() then
        InterfaceOptionsFrame:Hide();
    else
        InterfaceOptionsFrame_OpenToCategory(MainFrame);
    end
end

function MainFrame:EventHandler(event, ...)
    if (FishWarden[event]) then
        FishWarden[event](self, ...);
    end
end

function MainFrame:ShowHandler(...)
    local maxwidth = MainFrame:GetWidth();
    if (maxwidth == 0) then maxwidth = 413; end

    MainFrame.iddTitle:SetWidth(maxwidth - 26);
    MainFrame.iddHelp:SetWidth(maxwidth - 26);

    MainFrame.iddEnableBtn.iddText:SetWidth(min(MainFrame.iddEnableBtn.iddText:GetStringWidth(),
        maxwidth - MainFrame.iddEnableBtn:GetWidth() - 26));
    MainFrame.iddAutoCloseBtn.iddText:SetWidth(min(MainFrame.iddAutoCloseBtn.iddText:GetStringWidth(),
        maxwidth - MainFrame.iddAutoCloseBtn:GetWidth() - 26));

    if (MainFrame.collapsed) then
        for k, v in pairs(InterfaceOptionsFrameAddOns.buttons) do
            if (v and v.element == MainFrame) then
                InterfaceOptionsListButton_ToggleSubCategories(v);
            end
        end
    end
end

function MainFrame:OnClickEnable(button)
    if (button == "LeftButton") then
        FishWarden:SetEnable();
        MainFrame.iddEnableBtn:SetChecked(FishWarden.Vars.Enable);
    end
end

function MainFrame:OnClickAutoClose(button)
    if (button == "LeftButton") then
        FishWarden.Vars.AutoCloseLoot = not FishWarden.Vars.AutoCloseLoot;
        MainFrame.iddAutoCloseBtn:SetChecked(FishWarden.Vars.AutoCloseLoot);
    end
end

