local FishWarden = FishWarden_79a6ca19_6666_4759_9b8f_a67708694e5b;

FishWarden.GUI.CustomFrame = CreateFrame("Frame", "FishWardenCustomPanel", UIParent);

local MainFrame = FishWarden.GUI.MainFrame;
local CustomFrame = FishWarden.GUI.CustomFrame;

function CustomFrame:DoInit()
    local checkwidth = 26;

    CustomFrame.name = CUSTOM;
    CustomFrame.parent = MainFrame.name;
    InterfaceOptions_AddCategory(CustomFrame);
    CustomFrame:SetScript("OnShow", CustomFrame.ShowHandler);
    CustomFrame:SetScript("OnHide", CustomFrame.HideHandler);

    CustomFrame.iddTitle = CustomFrame:CreateFontString("$parent_Title","ARTWORK","GameFontNormalLarge");
    CustomFrame.iddTitle:SetPoint("TOPLEFT", CustomFrame, "TOPLEFT", 13, -13);
    CustomFrame.iddTitle:SetText(CUSTOM);
    CustomFrame.iddTitle:SetJustifyH("CENTER");

    CustomFrame.iddHelp = CustomFrame:CreateFontString("$parent_Help","ARTWORK","GameFontNormal");
    CustomFrame.iddHelp:SetPoint("TOPLEFT", CustomFrame.iddTitle, "BOTTOMLEFT", 0, -8);
    CustomFrame.iddHelp:SetText("|cffffffff    " .. format(FishWarden.Locale.HelpCustom, UPDATE, CANCEL) .. "|r");
    CustomFrame.iddHelp:SetJustifyH("LEFT");
    CustomFrame.iddHelp:SetJustifyV("TOP");

    CustomFrame.iddEnableBtn = CustomFrame:AddCheck(ENABLE, "$parent_EnableBtn", CustomFrame.OnClickEnable,
                                                CustomFrame.iddHelp, checkwidth);

    CustomFrame.iddUpdateBtn = CreateFrame("Button", nil, CustomFrame, "UIPanelButtonTemplate");
    CustomFrame.iddUpdateBtn:SetPoint("BOTTOMLEFT", CustomFrame, "BOTTOMLEFT", 13, 13);
    CustomFrame.iddUpdateBtn:SetText(UPDATE);
    CustomFrame.iddUpdateBtn:SetScript("OnClick", CustomFrame.OnClickUpdate);

    CustomFrame.iddCancelBtn = CreateFrame("Button", nil, CustomFrame, "UIPanelButtonTemplate");
    CustomFrame.iddCancelBtn:SetPoint("TOPLEFT", CustomFrame.iddUpdateBtn, "TOPRIGHT", 5, 0);
    CustomFrame.iddCancelBtn:SetText(CANCEL);
    CustomFrame.iddCancelBtn:SetScript("OnClick", CustomFrame.OnClickCancel);

    CustomFrame.iddScrollFrame = CreateFrame("ScrollFrame", "$parent_Scroll", CustomFrame, "UIPanelScrollFrameTemplate");
    CustomFrame.iddScrollFrame:SetPoint("TOPLEFT", CustomFrame.iddEnableBtn, "BOTTOMLEFT", 9, -9);
    CustomFrame.iddScrollFrame:SetPoint("BOTTOMLEFT", CustomFrame.iddUpdateBtn, "TOPLEFT", 9, 14);

    CustomFrame.iddEditFrame = CreateFrame("EditBox", nil, CustomFrame);
    CustomFrame.iddEditFrame:SetMultiLine(true);
    CustomFrame.iddEditFrame:SetFontObject("GameFontWhiteSmall");
    CustomFrame.iddEditFrame:SetPoint("TOPLEFT", CustomFrame.iddScrollFrame);
    CustomFrame.iddEditFrame:SetScript("OnTextChanged", function (self)
            if (FishWarden.Vars.FilterCustomText == self:GetText()) then
                CustomFrame.iddUpdateBtn:Disable();
                CustomFrame.iddCancelBtn:Disable();
            else
                CustomFrame.iddUpdateBtn:Enable();
                CustomFrame.iddCancelBtn:Enable();
            end
            ScrollingEdit_OnTextChanged(self, CustomFrame.iddScrollFrame);
        end);
    CustomFrame.iddEditFrame:SetScript("OnCursorChanged", ScrollingEdit_OnCursorChanged);
    CustomFrame.iddEditFrame:SetScript("OnUpdate", function (self, elapsed)
            ScrollingEdit_OnUpdate(self, elapsed, CustomFrame.iddScrollFrame);
        end);

    CustomFrame.iddScrollFrame:SetScrollChild(CustomFrame.iddEditFrame);

    CustomFrame.iddScrollBackground = CreateFrame("Frame", nil, CustomFrame);
    CustomFrame.iddScrollBackground:SetPoint("TOPLEFT", CustomFrame.iddScrollFrame, "TOPLEFT", -9, 9);
    CustomFrame.iddScrollBackground:SetPoint("BOTTOMRIGHT", CustomFrame.iddScrollFrame, "BOTTOMRIGHT", 27, -9);
    CustomFrame.iddScrollBackground:SetBackdrop(
        {
            bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = "true", edgeSize = 16, tileSize = 16,
            insets = {left = "5", right = "5", top = "5", bottom = "5"}
        });
    CustomFrame.iddScrollBackground:SetBackdropBorderColor(TOOLTIP_DEFAULT_COLOR.r, TOOLTIP_DEFAULT_COLOR.g,
        TOOLTIP_DEFAULT_COLOR.b);
    CustomFrame.iddScrollBackground:SetBackdropColor(TOOLTIP_DEFAULT_BACKGROUND_COLOR.r,
        TOOLTIP_DEFAULT_BACKGROUND_COLOR.g, TOOLTIP_DEFAULT_BACKGROUND_COLOR.b);

    CustomFrame:Hide();

    CustomFrame.Old_ChatEdit_InsertLink = ChatEdit_InsertLink;
    ChatEdit_InsertLink = CustomFrame.InsertLink;

    CustomFrame.Old_IsOptionFrameOpen = IsOptionFrameOpen;
    IsOptionFrameOpen = CustomFrame.IsOptionFrameOpen;
end

function CustomFrame:AddCheck(text, name, func, anchor, width)
    local btnFrame = CreateFrame("CheckButton", name, CustomFrame, "UICheckButtonTemplate");
    btnFrame:SetWidth(width);
    btnFrame:SetHeight(width);
    btnFrame:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, 0);
    btnFrame:SetScript("OnClick", func);

    btnFrame.iddText = getglobal(btnFrame:GetName() .. 'Text');
    -- Note the redundant set of parantheses actually changes the return of 'select' from a list to a single value
    btnFrame.iddText:SetText(text);
    btnFrame.iddText:SetJustifyH("LEFT");

    btnFrame.iddClicker = CreateFrame("Button", name .. "Clicker", CustomFrame);
    btnFrame.iddClicker:SetAllPoints(btnFrame.iddText);
    btnFrame.iddClicker:SetScript("OnClick", func);
    btnFrame.iddClicker:SetScript("OnEnter", function ()
                    btnFrame:LockHighlight();
            end);
    btnFrame.iddClicker:SetScript("OnLeave", function ()
                    btnFrame:UnlockHighlight();
            end);
    return btnFrame;
end

function CustomFrame:refresh()
    CustomFrame.iddEnableBtn:SetChecked(FishWarden.Vars.FilterCustomEnable);
end

function CustomFrame:ShowHandler()
    local maxwidth = CustomFrame:GetWidth();
    if (maxwidth == 0) then maxwidth = 413; end
    local scrollwidth = getglobal(CustomFrame.iddScrollFrame:GetName() .. "ScrollBar"):GetWidth();
    if (scrollwidth == 0) then scrollwidth = 16; end

    if (not CustomFrame.Old_Strata) then
        CustomFrame.Old_Strata = InterfaceOptionsFrame:GetFrameStrata();
    end
    -- Don't do else here
    if (CustomFrame.Old_Strata) then
        InterfaceOptionsFrame:SetFrameStrata("MEDIUM");
        InterfaceOptionsFrame:Raise();
    end

    CustomFrame.iddTitle:SetWidth(maxwidth - 26);
    CustomFrame.iddHelp:SetWidth(maxwidth - 26);

    CustomFrame.iddEnableBtn.iddText:SetWidth( min(CustomFrame.iddEnableBtn.iddText:GetStringWidth(),
                                                maxwidth - CustomFrame.iddEnableBtn:GetWidth() - 26) );

    CustomFrame.iddUpdateBtn:SetWidth(CustomFrame.iddUpdateBtn:GetTextWidth() + 20);
    CustomFrame.iddUpdateBtn:SetHeight(CustomFrame.iddUpdateBtn:GetTextHeight() + 10);
    CustomFrame.iddCancelBtn:SetWidth(CustomFrame.iddCancelBtn:GetTextWidth() + 20);
    CustomFrame.iddCancelBtn:SetHeight(CustomFrame.iddCancelBtn:GetTextHeight() + 10);

    CustomFrame.iddScrollFrame:SetWidth(maxwidth - 22 - scrollwidth - 26);
    CustomFrame.iddScrollFrame:SetHeight(CustomFrame.iddScrollFrame:GetHeight());

    CustomFrame.iddEditFrame:SetWidth(maxwidth - 22 - scrollwidth - 26);
    CustomFrame.iddEditFrame:SetHeight(CustomFrame.iddScrollFrame:GetHeight());
end

function CustomFrame:HideHandler()
    -- We do this on Hide instead of show, so that a user clicking "Custom" while Custom frame is already shown doesn't wipe changes
    if (not FishWarden.Vars.FilterCustomText) then
        FishWarden.Vars.FilterCustomText = "";
    end

    CustomFrame.iddEditFrame:SetText(FishWarden.Vars.FilterCustomText);

    if (CustomFrame.Old_Strata) then
        InterfaceOptionsFrame:SetFrameStrata(CustomFrame.Old_Strata);
        CustomFrame.Old_Strata = false;
    end
end

function CustomFrame:OnClickEnable(button)
    if (button == "LeftButton") then
        FishWarden.Vars.FilterCustomEnable = not FishWarden.Vars.FilterCustomEnable;
        CustomFrame.iddEnableBtn:SetChecked(FishWarden.Vars.FilterCustomEnable);
    end
end

function CustomFrame:OnClickUpdate(button)
    if (button == "LeftButton") then
        FishWarden.Vars.FilterCustomText = CustomFrame.iddEditFrame:GetText();
        FishWarden.UpdateCustomFish();
        CustomFrame:refresh();
        CustomFrame.iddUpdateBtn:Disable();
        CustomFrame.iddCancelBtn:Disable();
    end
end

function CustomFrame:OnClickCancel(button)
    if (button == "LeftButton") then
        if (not FishWarden.Vars.FilterCustomText) then
            FishWarden.Vars.FilterCustomText = "";
        end
        CustomFrame.iddEditFrame:SetText(FishWarden.Vars.FilterCustomText);
        CustomFrame.iddUpdateBtn:Disable();
        CustomFrame.iddCancelBtn:Disable();
    end
end

function CustomFrame.InsertLink(text, ...)
    if (not CustomFrame.iddEditFrame:HasFocus() or not text) then
        return CustomFrame.Old_ChatEdit_InsertLink(text, ...);
    end

    local linktype, itemid = strsplit(":", text);
    if (not strfind(linktype, "Hitem")) then
        return CustomFrame.Old_ChatEdit_InsertLink(text, ...);
    end

    itemid = tonumber(itemid);
    if (not itemid) then
        return CustomFrame.Old_ChatEdit_InsertLink(text, ...);
    end

    local itemname = GetItemInfo("item:" .. itemid);
    if (not itemname) then
        return CustomFrame.Old_ChatEdit_InsertLink(text, ...);
    end

    local lastchar = CustomFrame.iddEditFrame:GetNumLetters();
    local curtext = CustomFrame.iddEditFrame:GetText();

    CustomFrame.iddEditFrame:SetCursorPosition(lastchar);
    if (lastchar > 0 and strbyte(curtext, lastchar) ~= 10) then
        CustomFrame.iddEditFrame:Insert("\n");
    end
    CustomFrame.iddEditFrame:Insert(itemid .. " # " .. itemname .. "\n");

    return true, select(2, CustomFrame.Old_ChatEdit_InsertLink(text, ...));
end

function CustomFrame.IsOptionFrameOpen(...)
    if (CustomFrame:IsShown()) then
        return false, select(2, CustomFrame.Old_IsOptionFrameOpen(...));
    else
        return CustomFrame.Old_IsOptionFrameOpen(...);
    end
end

