SSTemp = 0;
SSType = 0;

function ScourgeStrike_OnLoad()
	this:RegisterEvent("COMBAT_LOG_EVENT");
	setglobal("SHOW_COMBAT_TEXT",1);
	LoadAddOn("Blizzard_CombatText");
end

function ScourgeStrike_OnEvent(event, ...)

    if(event=="COMBAT_LOG_EVENT")then

        -- Return values
        local timestamp = arg1 or 0;
        local what = arg2 or 0;
        local source = arg3 or 0;
        local sourcen = arg4 or "Unknown";
        local sourcef = arg5 or 0;
        local dest = arg6 or 0;
        local destn = arg7 or "Unknown";
        local destf = arg8 or 0;
        local spellid = arg9 or 0;
        local spelln = arg10 or 0;
        local spells = arg11 or 0;
        local dmg = arg12 or 0;
        local overkill = arg13 or 0;
        local school = arg14 or 0;
        local resisted = arg15 or 0;
        local blocked = arg16 or 0;
        local absorbed = arg17 or 0;
        local critical = arg18 or 0;
        local glancing = arg19 or 0;
        local crushing = arg20 or 0;

    	if(arg4==UnitName("player"))then

			-- check Scourge Strike
            if(what=="SPELL_DAMAGE" and spellid==55271)then
                SSTemp = dmg;
                SSType = critical;

                local disease = 0;
				for i=1,40 do
					local name,_,_,_,_,_,_,_,_,_,debuffId= UnitDebuff("target",i,"PLAYER");
					if name then
						-- check if diseases are on the target from the player
						if(debuffId==55095 or debuffId==51735 or debuffId==55078)then
							disease = 1;
						end
					end
				end

				if(disease==0)then
					ScourgeStrike_Output(SSTemp, SSType);
					SSTemp = 0;
					SSType = 0;
				end

            end

			-- check Scourge Strike (Shadow)
            if(what=="SPELL_DAMAGE" and spellid==70890)then
                SSTemp = SSTemp + dmg;
                ScourgeStrike_Output(SSTemp, SSType);
                SSTemp = 0;
				SSType = 0;
            end

        end
    end
end

function ScourgeStrike_Output(dmg, crit)
	if(crit==0)then
		CombatText_AddMessage("Scourge Strike: "..dmg, CombatText_FountainScroll, 0.4, 0, 0.8, "sticky", nil);
	else
		CombatText_AddMessage("Scourge Strike: "..dmg, CombatText_FountainScroll, 0.4, 0, 0.8, "crit", nil);
	end
end