if  (GetLocale() == "esES") then
-- 
-- Regular expressions to match poison names
-- 
Poisoner_Patterns = {
	"Piedra de afilar %w+",
	"Contrapeso %w+",
	"Aceite de man�.*",
	"Aceite de zahor�.*",
	"Aceite de Escarcha",
	"Aceite de las Sombras",
        "Veneno .*" -- not a very good pattern, but without grouping...
};

--
-- Display strings
--

-- tooltip strings
-- error messages



end
