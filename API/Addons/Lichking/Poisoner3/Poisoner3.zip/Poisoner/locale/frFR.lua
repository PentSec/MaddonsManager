if  (GetLocale() == "frFR") then
-- 
-- Regular expressions to match poison names
-- 
Poisoner_Patterns = {
	"Pierre à aiguiser %w+",
	"Pierre de lest %w+",
	"Huile de mana.*",
	"Huile de sorcier.*",
	"Huile glaciale",
	"Huile des ténèbres",
        "Poison .*" -- not a very good pattern, but without grouping...
};

--
-- Display strings
--

-- tooltip strings
-- error messages



end
