if  (GetLocale() == "koKR") then
-- 
-- Regular expressions to match poison names
-- 
Poisoner_Patterns = {
	".* 숫돌",
	".*  무게추",
	".*마나 오일",
	".*마술사 오일",
	"냉기 오일",
	"암흑 오일",
        ".*독%s*([IVX]*)"
};

--
-- Display strings
--

-- tooltip strings
-- error messages



end
