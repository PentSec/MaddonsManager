if  (GetLocale() == "deDE") then
-- 
-- Regular expressions to match poison names
-- 
Poisoner_Patterns = {
	".*[Ww]etzstein",
	"%w+ Gewichtsstein",
	".*Manaöl",
	".*Zauberöl",
	"Frostöl",
	"Schattenöl",
        ".*[Gg]ift%s*([IVX]*)"
};

--
-- Display strings
--

-- tooltip strings
-- error messages



end
