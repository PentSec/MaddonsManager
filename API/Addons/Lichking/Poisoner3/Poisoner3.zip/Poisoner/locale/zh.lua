if  (GetLocale() == "zhCN" or GetLocale() == "zhTW") then
-- 
-- Regular expressions to match poison names
-- 
Poisoner_Patterns = {
	".*磨刀石",
	".*平衡石",
	".*法力之油",
	".*巫师之油",
	"冰霜之油",
	"暗影之油",
        ".*毒[药藥]%s*([IVX]*)"
};

--
-- Display strings
--

-- tooltip strings
-- error messages



end
