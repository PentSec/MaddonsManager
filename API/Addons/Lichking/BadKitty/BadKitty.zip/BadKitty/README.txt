BadKitty was written from scratch by Anatinus of Gul'dan as a one-stop-shop for Feral debuff watching.

For options, type /bk or /badkitty.

For a quick toggle, /bk toggle.

For quick locking/unlocking, type /bk lock.

Code within BadKittyWarnings.lua was originally the BadKittyWarnings mod by Ukrudt (agamaggan-eu).

current version: Release 1.11.2


