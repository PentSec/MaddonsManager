﻿-- TODO:
-- * create local recipe list per player
-- * unlink from tradeskill window (seperate close method)
-- * use recipes from all professions (maybe even alts)

ESL_NUMBUTTONS = 0;
ESL_ListAllButton = nil;
ESL_ListIndex = {}
ESL_TooltipSkillLink = {}
ESL_clickedRecipeInfo = {}
ESL_currentListY = 0;
-- *** Scanning functions ***

local selectedTradeSkillIndex
local subClasses, subClassID
local invSlots, invSlotID
local haveMats
local checkedOpening

local ProfessionSkill = {
	["Alchemy"] = "Alchemy",
	["Blacksmithing"] = "Blacksmithing",
	["Enchanting"] = "Enchanting",
	["Engineering"] = "Engineering",
	["Inscription"] = "Inscription",
	["Jewelcrafting"] = "Jewelcrafting",
	["Leatherworking"] = "Leatherworking",
	["Tailoring"] = "Tailoring",
	["Mining"] = "Smelting",
	["First Aid"] = "First Aid",
	["Cooking"] = "Cooking",
		
	-- german --
	["Bergbau"] = "Verhüttung",
	
	-- spanish --
	["Minería"] = "Fundición",
	
	-- french --
	["Minage"] = "Fondre",
	
	-- Русский --
	["Горное дело"] = "Выплавка металлов",
}

local DefaultCraftInfo = {
	["icon"] = "Interface\Icons\Trade_Engineering";
}

local function GetSubClassID()
	-- The purpose of this function is to get the subClassID in a UI independant way
	-- ie: without relying on UIDropDownMenu_GetSelectedID(TradeSkillSubClassDropDown), which uses a hardcoded frame name.
	
	if GetTradeSkillSubClassFilter(0) then		-- if "All Subclasses" is selected, GetTradeSkillSubClassFilter() will return 1 for all indexes, including 0
		return 1				-- thus return 1 as selected id	(as would be returned by UIDropDownMenu_GetSelectedID(TradeSkillSubClassDropDown))
	end

	local filter
	for i = 1, #subClasses do
	   filter = GetTradeSkillSubClassFilter(i)
	   if filter then
	      return i+1			-- ex: 3rd element of the subClasses array, but 4th in the dropdown due to "All Subclasses", so return i+1
	   end
	end
end

local function GetInvSlotID()
	-- The purpose of this function is to get the invSlotID in a UI independant way	(same as GetSubClassID)
	-- ie: without relying on UIDropDownMenu_GetSelectedID(TradeSkillInvSlotDropDown), which uses a hardcoded frame name.

	if GetTradeSkillInvSlotFilter(0) then		-- if "All Slots" is selected, GetTradeSkillInvSlotFilter() will return 1 for all indexes, including 0
		return 1				-- thus return 1 as selected id	(as would be returned by  UIDropDownMenu_GetSelectedID(TradeSkillInvSlotDropDown))
	end

	local filter
	for i = 1, #invSlots do
	   filter = GetTradeSkillInvSlotFilter(i)
	   if filter then
	      return i+1			-- ex: 3rd element of the invSlots array, but 4th in the dropdown due to "All Slots", so return i+1
	   end
	end
end

local function SaveActiveFilters()
	selectedTradeSkillIndex = GetTradeSkillSelectionIndex()
	
	subClasses = { GetTradeSkillSubClasses() }
	invSlots = { GetTradeSkillInvSlots() }
	subClassID = GetSubClassID()
	invSlotID = GetInvSlotID()
	
	-- Subclasses
	SetTradeSkillSubClassFilter(0, 1, 1)	-- this checks "All subclasses"
	if TradeSkillSubClassDropDown then
		UIDropDownMenu_SetSelectedID(TradeSkillSubClassDropDown, 1)
	end
	
	-- Inventory slots
	SetTradeSkillInvSlotFilter(0, 1, 1)		-- this checks "All slots"
	if TradeSkillInvSlotDropDown then
		UIDropDownMenu_SetSelectedID(TradeSkillInvSlotDropDown, 1)
	end
	
	-- Have Materials
	if TradeSkillFrameAvailableFilterCheckButton then
		haveMats = TradeSkillFrameAvailableFilterCheckButton:GetChecked()	-- nil or true
		TradeSkillFrameAvailableFilterCheckButton:SetChecked(false)
	end
	TradeSkillOnlyShowMakeable(false)
end

local function RestoreActiveFilters()
	-- Subclasses
	SetTradeSkillSubClassFilter(subClassID-1, 1, 1)	-- this checks the previously checked value
	
	local frame = TradeSkillSubClassDropDown
	if frame then	-- other addons might nil this frame (delayed load, etc..), so secure DDM calls
		local text = (subClassID == 1) and ALL_SUBCLASSES or subClasses[subClassID-1]
		UIDropDownMenu_SetSelectedID(frame, subClassID)
		UIDropDownMenu_SetText(frame, text);
	end
	
	subClassID = nil
	wipe(subClasses)
	subClasses = nil
	
	-- Inventory slots
	invSlotID = invSlotID or 1
	SetTradeSkillInvSlotFilter(invSlotID-1, 1, 1)	-- this checks the previously checked value
	
	frame = TradeSkillInvSlotDropDown
	if frame then
		local text = (invSlotID == 1) and ALL_INVENTORY_SLOTS or invSlots[invSlotID-1]
		UIDropDownMenu_SetSelectedID(frame, invSlotID)
		UIDropDownMenu_SetText(frame, text);
	end
	
	invSlotID = nil
	wipe(invSlots)
	invSlots = nil
	
	-- Have Materials
	if TradeSkillFrameAvailableFilterCheckButton then
		TradeSkillFrameAvailableFilterCheckButton:SetChecked(haveMats or false)
	end
	TradeSkillOnlyShowMakeable(haveMats or false)
	haveMats = nil
	
	SelectTradeSkill(selectedTradeSkillIndex)
	selectedTradeSkillIndex = nil
end

local headersState = {}

local function SaveHeaders()
	local headerCount = 0		-- use a counter to avoid being bound to header names, which might not be unique.
	
	for i = GetNumTradeSkills(), 1, -1 do		-- 1st pass, expand all categories
		local _, skillType, _, isExpanded  = GetTradeSkillInfo(i)
		 if (skillType == "header") then
			headerCount = headerCount + 1
			if not isExpanded then
				ExpandTradeSkillSubClass(i)
				headersState[headerCount] = true
			end
		end
	end
end

local function RestoreHeaders()
	local headerCount = 0
	for i = GetNumTradeSkills(), 1, -1 do
		local _, skillType  = GetTradeSkillInfo(i)
		if (skillType == "header") then
			headerCount = headerCount + 1
			if headersState[headerCount] then
				CollapseTradeSkillSubClass(i)
			end
		end
	end
	wipe(headersState)
end

local SkillTypeToColor = {
	["trivial"] = 0,		-- grey
	["easy"] = 1,			-- green
	["medium"] = 2,		-- yellow
	["optimal"] = 3,		-- orange
}

function FindToolIDs(...)
	if ( select("#", ...) == 0 ) then
		return "";
	end

	-- Takes input where odd items are the text and even items determine whether the arg should be colored or not
	local string="", toolName;
	toolName,_ = ...;
	if ( toolName ) then
		string = toolName;
	end
	
	for i=3, select("#", ...), 2 do
		toolName, _ = select(i, ...);
		string = string..", "..toolName;
	end

	return string;
end


local function ScanRecipes()
	
	local tradeskillName = GetTradeSkillLine()
	if not tradeskillName or tradeskillName == "UNKNOWN" then return end		-- may happen after a patch, or under extreme lag, so do not save anything to the db !

	local numTradeSkills = GetNumTradeSkills()
	if not numTradeSkills or numTradeSkills == 0 then 
		eprint("no trade skills found");
		return;
	end
	
	local skillName, skillType = GetTradeSkillInfo(1)	-- test the first line
	if skillType ~= "header" then 
		eprint("scan skipped");
		checkedOpening = false;
		return 
	end				-- skip scan if first line is not a header.
		
	--local char = addon.ThisCharacter
	--local profession = char.Professions[tradeskillName]
	local pname = UnitName("player");
	if ( ESL_CRAFTSDB==nil ) then	ESL_CRAFTSDB = {}; end
	if ( ESL_CRAFTSDB[ pname ] == nil ) then ESL_CRAFTSDB[ pname ] = {}; end
	if ( ESL_CRAFTSDB[ pname ][ tradeskillName ] == nil ) then ESL_CRAFTSDB[ pname ][ tradeskillName ] = {}; end 
	local crafts = ESL_CRAFTSDB[ pname ][ tradeskillName ];
	--wipe(crafts);

	if ( ESL_CRAFTSINFO[tradeskillName] == nil) then
		ESL_CRAFTSINFO[tradeskillName] = DefaultCraftInfo;
	end;
	ESL_CRAFTSINFO[tradeskillName]["icon"] = GetTradeSkillTexture();
	--eprint("setting icon of "..tradeskillName.." to "..ESL_CRAFTSINFO[tradeskillName]["icon"]);
	--profession.FullLink = select(2, GetSpellLink(tradeskillName))

	local NumCrafts = 0;
	local color, link, numReagents, serviceType;
	local minMade, maxMade;
	local reagentName, reagentTexture, reagentCount, reagentID
	local reagents = {};
	local toolName, hasTool, moreTools;
	

	for i = 1, numTradeSkills do
		--local skillName, skillType, numAvailable, isExpanded, altVerb = GetTradeSkillInfo( index );
		skillName, skillType,_,_,serviceType = GetTradeSkillInfo(i);
		minMade,maxMade = GetTradeSkillNumMade(i);
		numReagents = GetTradeSkillNumReagents(i);
		if skillType == "header" then
			crafts[i] = skillName or "";
		else
			link = GetTradeSkillItemLink(i);
			craftID = tonumber(link:match("enchant:(%d+)") or link:match("item:(%d+)"));		-- this actually extracts the spellID
			--eprint( link:gsub("|", "||") );
			-- handle reagents
			wipe(reagents);
			for r=1, numReagents, 1 do
				_,_, reagentCount = GetTradeSkillReagentInfo( i, r);
				link = GetTradeSkillReagentItemLink( i, r);
				--eprint("   -"..link:gsub("|", "||") );
				if (link) then
					reagentID = link:match("item:(%d+)");
				--else
					--eprint ("no link available for reagent "..r);
				end
				if (reagentID and reagentCount) then
					table.insert( reagents, reagentID.."x"..reagentCount);
				--else
					--eprint("craft "..craftID.." reagent "..r.." has no name or count");
				end
			end
			if (#reagents > 0) then
				crafts[craftID] = i.."|"..minMade.."|"..maxMade.."|"..SkillTypeToColor[skillType].."|"..table.concat( reagents, ";");
			--else
				--eprint("craft "..craftID.." has no reagents.");
			end
			-- handle tools
			--FindToolIDs(GetTradeSkillTools(i));
			--eprint(" found tools: "..FindToolIDs(GetTradeSkillTools(i)) );
			NumCrafts = NumCrafts + 1;
		end
	end
	
	ESL_CRAFTSDB[ pname ][ tradeskillName ] = crafts;
	checkedOpening = true;
	--profession.NumCrafts = NumCrafts
	
	--addon:SendMessage("DATASTORE_RECIPES_SCANNED", sender, tradeskillName)
	--eprint(NumCrafts.." recipes scanned for "..UnitName("player").." : "..tradeskillName);
end

local namefilter;
local function ScanTradeSkills()
	namefilter = GetTradeSkillItemNameFilter();
	SetTradeSkillItemNameFilter( "" );
	SaveActiveFilters()
	SaveHeaders()
	ScanRecipes()
	RestoreHeaders()
	RestoreActiveFilters()
	SetTradeSkillItemNameFilter( namefilter );
end

-- *** Bag Scanning functions ***

local function ScanContainer(bagID)
	--local Container = ContainerTypes[containerType]
	
	local bag;

	--if (ESL_BAGSDB[bagID] == nil) then ESL_BAGSDB[bagID]={}; end
	bag = {};--ESL_BAGSDB[bagID];
	wipe(bag);
	
	local link, count;
	local id = 0;
	
	for slotID = 1, GetContainerNumSlots(bagID) do
		_, count, _, _, _, _, link  = GetContainerItemInfo(bagID, slotID);
		count = tonumber(count);
		if link and count then
			id = tonumber(link:match("item:(%d+)"));
			if bag[id] then	bag[id] = bag[id] + count;
			else			bag[id] = count; end;
			--eprint("increased "..id.." by "..count.." to "..bag[id]);
		end
	end

	ESL_BAGSDB[bagID] = bag;
end

function ItemsInBags( itemID )
	local itemcount = 0;
	for bagID, bagitems in pairs(ESL_BAGSDB) do
		if (bagitems[itemID]) then 
			--eprint(" found "..bagitems[itemID].." of "..itemID.." in bag "..bagID);
			itemcount = itemcount + bagitems[itemID]; 
		end
	end
	return itemcount;
end

-- *** Events ***

function ESL_OnLoad( self )
	--eprint("Onload");
	self:RegisterEvent("VARIABLES_LOADED");
	self:RegisterEvent("TRADE_SKILL_SHOW");
	self:RegisterEvent("TRADE_SKILL_CLOSE");
	self:RegisterEvent("TRADE_SKILL_FILTER_UPDATE");	
	
	self:RegisterEvent("PLAYER_ENTERING_WORLD");
	
	self:RegisterForDrag("LeftButton");
	ESL_Reagent0Name:SetTextColor(YELLOW_FONT_COLOR.r, YELLOW_FONT_COLOR.g, YELLOW_FONT_COLOR.b);
	
	ESL_Frame:SetFrameStrata("FULLSCREEN_DIALOG")
	ESL_Frame_minimized:SetFrameStrata("FULLSCREEN_DIALOG")
end

local function OnBagUpdate( bag )
	--eprint("bag update "..bag);
	if (bag < 0 or bag >= 5) then return; end
	
	if (bag == 0) then					-- bag is 0 for both the keyring and the original backpack
		ScanContainer(KEYRING_CONTAINER)
	end
	ScanContainer(bag)
end

function ESL_Event(self, event, ...)
    if ( event == "VARIABLES_LOADED" ) then
		-- add "list all" button to tradeskill window
		CreateFrame( "Button", "ListAllButton", ESL_Frame, "ESL_ShowButton" );
		ESL_ListAllButton = CreateFrame( "Button", "ListAllButton", TradeSkillDetailScrollChildFrame, "ESL_ShowButton" );
		ESL_ListAllButton:SetPoint("LEFT", TradeSkillReagentLabel, "RIGHT", 2, 4 );
		ESL_ListAllButton:Show();
		--eprint("variables loaded event");
		-- manually update bags 0 to 4, then register the event, this avoids reacting to the flood of BAG_UPDATE events at login
		if (ESL_CRAFTSINFO==nil) then
			ESL_CRAFTSINFO = {};
		end
		ESL_CRAFTSINFO["default"] = DefaultCraftInfo;
		if (ESL_BAGSDB==nil) then 
			--eprint("made bag for "..UnitName("player"));
			ESL_BAGSDB = {}; 
		end;	
		wipe(ESL_BAGSDB);
		for bagID = 0, NUM_BAG_SLOTS do
			ScanContainer(bagID);
		end
		ScanContainer(KEYRING_CONTAINER);
		--addon:RegisterEvent("BAG_UPDATE", OnBagUpdate)
	elseif ( event == "TRADE_SKILL_SHOW" ) then
		--eprint("tradeskill frame opened");
		ESL_Frame:ClearAllPoints();
		ESL_Frame:SetPoint( "TOPLEFT", TradeSkillFrame, "TOPRIGHT", 8, 13);
		ESL_Frame:SetPoint( "BOTTOMRIGHT", TradeSkillFrame, "BOTTOMRIGHT", 280, -2);
		ScanTradeSkills();
		--ESL_Frame:Show();
	elseif ( event == "TRADE_SKILL_CLOSE" ) then
		--ESL_Frame:Hide();
	elseif ( event == "PLAYER_ENTERING_WORLD" ) then
		self:RegisterEvent("BAG_UPDATE");
		self:UnregisterEvent("PLAYER_ENTERING_WORLD");
	elseif ( event == "BAG_UPDATE" ) then
		--eprint("BAG_UPDATE");
		OnBagUpdate( ... );
		if (ESL_Frame:IsShown()) then
			ESL_UpdateCompleteList()
		end
	end
end

function GetProfessionSkill(profession)
	local skillName = ProfessionSkill[profession];
	if (skillName == nil) then 
		skillName = ESL_clickedRecipeInfo[4];
	end
	return skillName;
end

function ESL_ListButtonClicked()	
	if (ESL_Frame_minimized:IsVisible()) then
		ESL_Frame_minimized:ClearAllPoints();
		ESL_Frame_minimized:Hide();
	end
		
	local index = GetTradeSkillSelectionIndex();
	local skillName = GetTradeSkillInfo( index );
	local link = GetTradeSkillItemLink(index);
	ESL_clickedRecipeInfo = { skillName, GetTradeSkillIcon( index ), link, GetTradeSkillLine() };
	ESL_tradeskillbutton:SetAttribute("spell",GetProfessionSkill(ESL_clickedRecipeInfo[4]));
	ESL_tradeskillbutton:SetText("show "..GetProfessionSkill(ESL_clickedRecipeInfo[4]));
	
	ESL_Frame_minimizedIconFrameTexture:SetTexture(ESL_clickedRecipeInfo[2]);
	ESL_Frame_minimizedIconFrame:SetID(1);
	
	--eprint("opening : "..ProfessionSkill[ESL_clickedRecipeInfo[4]]); 
	ESL_UpdateCompleteList();
end
		
function ESL_UpdateCompleteList()
	if (not checkedOpening) then
		ScanTradeSkills();
	end;
	local link = ESL_clickedRecipeInfo[3];
	index = tonumber(link:match("enchant:(%d+)") or link:match("item:(%d+)"));
	
	--eprint("texture : "..GetTradeSkillTexture());
	--fill buttons with reagent content
	ESL_currentListY = - 8;
	ESL_SetSelection( index, 0, 1 );
	
	--set name of minimized window
	ESL_AddonNameMin:SetText( ESL_clickedRecipeInfo[1] );
	
	--hide non-used buttons 
	local reagent = _G["ESL_Reagent0"];
	for i=ESL_CURREAGENTNUM, ESL_NUMBUTTONS-1, 1 do
		_G["ESL_Reagent"..i]:Hide();
	end	
	ESL_Frame:Show();
	ESL_NUMBUTTONS = ESL_CURREAGENTNUM;
	local h;
	if (ESL_NUMBUTTONS > 7) then
		ESL_ScrollChildFrame:SetHeight( (reagent:GetHeight()+2) * ESL_NUMBUTTONS );
		ESL_ScrollFrame:EnableDrawLayer("BACKGROUND");
	else
		ESL_ScrollChildFrame:SetHeight( ESL_ScrollFrame:GetHeight()-10 );
		ESL_ScrollFrame:DisableDrawLayer("BACKGROUND");
	end
	--ESL_ScrollChildFrame:SetHeight( h );
	--ESL_ScrollChildFrame:SetHeight( max( (reagent:GetHeight()+2) * ESL_NUMBUTTONS, ESL_ScrollFrame:GetHeight()-10 ) );
end

function ESL_GetRecipeInfo( id )
	local recipe;
	local currentplayer = UnitName("player");
	local tsname = "";
	-- first check current player
	--eprint ("first checking player "..currentplayer);
	for tradeskillname, recipes in pairs(ESL_CRAFTSDB[ currentplayer ]) do
		--eprint("looking in "..tradeskillname);
		recipe = recipes[id];
		if (recipe) then 
			tsname = tradeskillname;
			--eprint("found recipe ["..id.."] in "..tsname);
			break; 
		end
	end
	
	if (recipe==nil) then --not found at current player, check others
		for playername, tradeskills in pairs( ESL_CRAFTSDB ) do
			if (playername ~= currentplayer) then
				for tradeskillname, recipes in pairs(ESL_CRAFTSDB[ playername ]) do
					--eprint("looking in "..tradeskillname.." from "..playername);
					recipe = recipes[id];
					if (recipe) then 
						tsname = tradeskillname;
						currentplayer = playername;
						--eprint("found recipe ["..id.."] in "..tsname);
						break; 
					end
				end
			end
			if (recipe) then break; end
		end
	end
	
	if (recipe==nil) then 
		--eprint( "recipe ["..id.."] not found")
		return nil;
	end
	
	--eprint("recipe found : "..string.gsub(recipe,"|"," | "));
	local listid, minMade, maxMade, skillType, r, serviceType = strsplit("|", recipe);
	local reagents = {};
	
	if (r==nil) then
	-- recipe has wrong format, prolly old data
		return nil;
	end
	
	for v in string.gmatch(r, "(%d+x%d+)") do table.insert( reagents, v ); end
	--eprint("skillinfo - "..r);
	return serviceType, minMade, maxMade, skillType, reagents, currentplayer, tsname, listid;
end
        
function ESL_GetCraftInfo(craft)
	info = DefaultCraftInfo;
	if (ESL_CRAFTSINFO[craft]~=nil) then
		for key,value in pairs(ESL_CRAFTSINFO[craft]) do
			info[key] = value;
		end
	end
	return info;
end
	
function ESL_SetSelection( id, reagentLevel, amountNeeded )
	if ( reagentLevel == 0 ) then
		ESL_CURREAGENTNUM = 0;
	end
	
	local serviceType, minMade, maxMade, skillType, reagents, recPlayer, recProf, recListNum = ESL_GetRecipeInfo( id );
	--eprint("prof : "..(recProf and recProf or "nil") );
	
	-- fill button content
	local reagent = _G["ESL_Reagent"..ESL_CURREAGENTNUM]
	--print ( "found "..reagent);
	if ( not reagent ) then
		-- if button not already present, create one
		reagent = CreateFrame( "Button", "ESL_Reagent"..ESL_CURREAGENTNUM, ESL_ScrollChildFrame, "ESL_ItemTemplate" );
		reagent:Show();
		ESL_NUMBUTTONS = ESL_NUMBUTTONS + 1;
	end

	-- check to if displaying tradeskill button
	tradeskillButton = _G["ESL_Reagent"..ESL_CURREAGENTNUM.."_TradeskillButton"];
	if (ESL_CheckButton:GetChecked() and recPlayer==UnitName("player") and recProf~=nil ) then
		tradeskillButton:Show();
		tradeskillButton:SetAttribute("spell",ProfessionSkill[recProf]);
		craftinfo = ESL_GetCraftInfo(recProf);
		--if (craftinfo~=nil) then
		--	for k,v in pairs(craftinfo) do
		--		eprint("craftinfo["..k.."] = "..v);
		--	end
		--end
		SetPortraitToTexture("ESL_Reagent"..ESL_CURREAGENTNUM.."_TradeskillButtonNormal", craftinfo["icon"]);
	else
		tradeskillButton:Hide();
	end
	
	-- retreive tradeskill info
	local reagentName, reagentLink, reagentTexture, playerReagentCount;
	if (reagentLevel>0) then
		reagentName, reagentLink,_,_,_,_,_,_,_,reagentTexture = GetItemInfo( id );
		playerReagentCount = ItemsInBags( tonumber(id) );
	else
		reagentName = ESL_clickedRecipeInfo[1];
		reagentTexture = ESL_clickedRecipeInfo[2];
		reagentLink = ESL_clickedRecipeInfo[3];
		playerReagentCount = 0;
	end

	local name = _G["ESL_Reagent"..ESL_CURREAGENTNUM.."Name"];
	local count = _G["ESL_Reagent"..ESL_CURREAGENTNUM.."Count"];
	if ( not reagentName or not reagentTexture ) then
		eprint("found no name or texture for "..id);
		reagent:Hide();
		return;
	end
	
	reagent:Show();
	SetItemButtonTexture(reagent, reagentTexture);
	name:SetText(reagentName);
	
	-- position button
	local reagentX = 8 + 24 * reagentLevel;
	if (ESL_CheckButton:GetChecked()) then reagentX = reagentX + 30; end
	reagent:SetPoint( "TOPLEFT", reagentX, ESL_currentListY );
						  -- - 8 - (reagent:GetHeight()+2) * ESL_CURREAGENTNUM );
	if (reagentLevel==0) then
		if (minMade==maxMade) then 
			if (minMade=="1") then
				count:SetText("");
			else
				count:SetText(minMade.." ");
			end
		else
			count:SetText(minMade.."-"..maxMade);
		end
	else
	-- Grayout items
		if ( playerReagentCount < amountNeeded ) then
			SetItemButtonTextureVertexColor(reagent, 0.5, 0.5, 0.5);
			name:SetTextColor(GRAY_FONT_COLOR.r, GRAY_FONT_COLOR.g, GRAY_FONT_COLOR.b);
			creatable = nil;
		else
			SetItemButtonTextureVertexColor(reagent, 1.0, 1.0, 1.0);
			name:SetTextColor(HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b);
			if ( playerReagentCount >= 100 ) then
				playerReagentCount = "*";
			end
		end
	
		count:SetText(playerReagentCount.." /"..amountNeeded);
	end
	
	ESL_currentListY = ESL_currentListY - (reagent:GetHeight()+2);	
	ESL_CURREAGENTNUM = ESL_CURREAGENTNUM + 1;
	reagent:SetID( ESL_CURREAGENTNUM );
	ESL_TooltipSkillLink[ESL_CURREAGENTNUM] = reagentLink;

	if (not reagents) then
		--eprint("no reagents found");
		ESL_ListIndex[ESL_CURREAGENTNUM] = nil;
		return;
	end
	--eprint("reagents found "..#reagents.." for recipe at "..recListNum.."["..id.."]");
	
	ESL_ListIndex[ESL_CURREAGENTNUM] = {recPlayer, recProf, recListNum};

	if ( playerReagentCount >= amountNeeded and reagentLevel > 0) then 
		return; 
	end -- got more than enough, no need to display subrecipe
	--local numReagents = GetTradeSkillNumReagents(id);
	
	if ( not ESL_CheckButton:GetChecked() and recProf ~= ESL_clickedRecipeInfo[4] ) then 
		--eprint("not showing subs of "..recProf);
		return; 
	end
	
	for k,reagentStr in pairs(reagents) do
	
		local reagentID, reagentCount = strsplit("x",reagentStr);
		reagentCount = tonumber( reagentCount );
		reagentID = tonumber( reagentID );
				
		--eprint("diving deeper for reagent "..reagentID.." ("..playerReagentCount.."//"..reagentCount..")");
		local numneeded = ceil((amountNeeded - playerReagentCount)/minMade);
		ESL_SetSelection( reagentID, reagentLevel+1, reagentCount*numneeded)
				
	end
end

function ESL_findtradeskill( reagentname )
	local skillName, skillType, numAvailable, isExpanded, altVerb;
	local numSkills = GetNumTradeSkills();
	for i=1, numSkills, 1 do
		skillName, skillType, numAvailable, isExpanded, altVerb = GetTradeSkillInfo(i);
		if ( reagentname == skillName ) then
			return i;
		end;
	end
end

function ESL_SetGameToolTip( self )
	local id = self:GetID();

	GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT");
	GameTooltip:SetHyperlink( ESL_TooltipSkillLink[id] );
	CursorUpdate(self);
end

function ESL_ClickReagent( self )
	local id = self:GetID();
	--eprint("clicked recipe "..self:GetID());
	local rec = ESL_ListIndex[id];
	
	if ( rec and rec[1] == UnitName("player") ) then
		--eprint ("clicked "..(rec[1] or ".")..", "..(rec[2] or ".")..", "..(rec[3] or "."));
		if ( rec[2] ~= GetTradeSkillLine()) then return end
		--	CloseTradeSkill();
		--	CastSpellByName( rec[2] );
		--end
		
		-- reset all tradeskill filters
		SetTradeSkillInvSlotFilter(0);
		SetTradeSkillItemLevelFilter(0, 5000);
		SetTradeSkillItemNameFilter("");
		SetTradeSkillSubClassFilter(0);
		
		local skillType, isExpanded;
		for i = GetNumTradeSkills(), 1, -1 do		-- 1st pass, expand all categories
			_, skillType, _, isExpanded  = GetTradeSkillInfo(i)
			if (skillType == "header" and not isExpanded) then
					ExpandTradeSkillSubClass(i)
			end
		end
		
		TradeSkillFrame_SetSelection( rec[3] );
		TradeSkillFrame_Update();
	end
end		

function ESL_OnToggleMinimize()
	if (ESL_Frame:IsVisible()) then
		ESL_Frame_minimized:Show();
		ESL_Frame:ClearAllPoints();
		ESL_Frame_minimized:ClearAllPoints();
		ESL_Frame_minimized:SetPoint("TOPRIGHT", ESL_Frame, -19, -10);
		ESL_Frame:Hide();
	else
		ESL_Frame:Show();
		ESL_Frame_minimized:ClearAllPoints();
		ESL_Frame:ClearAllPoints();
		ESL_Frame:SetPoint("TOPRIGHT", ESL_Frame_minimized, 19, 10);
		ESL_Frame_minimized:Hide();
	end
end		
				
function eprint( msg )
	--print("ESL: "..msg);
	DEFAULT_CHAT_FRAME:AddMessage("|cffaaaa44ESL|r: "..msg);
end
