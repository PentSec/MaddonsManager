
BINDING_HEADER_ButtonForge = "Button Forge";
_G["BINDING_NAME_CLICK BFToolbarToggle:LeftButton"] = "Button Forge";
