local L = LibStub("AceLocale-3.0"):NewLocale("OneRing3", "deDE")

if L then 
    --@non-debug@
    L["%s's KeyRing"] = "%ss Schlüsselbund"

    --@end-non-debug@
end
