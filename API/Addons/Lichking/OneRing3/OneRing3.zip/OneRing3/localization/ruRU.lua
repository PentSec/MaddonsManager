local L = LibStub("AceLocale-3.0"):NewLocale("OneRing3", "ruRU")

if L then 
    --@non-debug@
    L["%s's KeyRing"] = "Связка ключей |3-3(%s)"

    --@end-non-debug@
end
