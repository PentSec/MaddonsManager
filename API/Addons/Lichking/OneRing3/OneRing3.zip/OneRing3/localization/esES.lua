local L = LibStub("AceLocale-3.0"):NewLocale("OneRing3", "esES")

if L then 
    --@non-debug@
    L["%s's KeyRing"] = "Llavero"

    --@end-non-debug@
end
