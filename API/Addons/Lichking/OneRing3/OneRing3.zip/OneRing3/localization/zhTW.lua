local L = LibStub("AceLocale-3.0"):NewLocale("OneRing3", "zhTW")

if L then 
    --@non-debug@
    L["%s's KeyRing"] = "%s的鑰匙圈"

    --@end-non-debug@
end
