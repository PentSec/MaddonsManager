local L = LibStub("AceLocale-3.0"):NewLocale("OneRing3", "koKR")

if L then 
    --@non-debug@
    L["%s's KeyRing"] = "%s의 열쇠고리"

    --@end-non-debug@
end
