local L = LibStub("AceLocale-3.0"):NewLocale("OneRing3", "frFR")

if L then 
    --@non-debug@
    L["%s's KeyRing"] = "Trousseau de clés |2 %s"

    --@end-non-debug@
end
