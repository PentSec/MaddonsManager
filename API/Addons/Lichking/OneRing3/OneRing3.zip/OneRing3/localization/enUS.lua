local L = LibStub("AceLocale-3.0"):NewLocale("OneRing3", "enUS", true, true)

--@non-debug@
L["%s's KeyRing"] = true

--@end-non-debug@
