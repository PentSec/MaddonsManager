local L = LibStub("AceLocale-3.0"):NewLocale("OneRing3", "zhCN")

if L then 
    --@non-debug@
    L["%s's KeyRing"] = "%s的钥匙链"

    --@end-non-debug@
end
