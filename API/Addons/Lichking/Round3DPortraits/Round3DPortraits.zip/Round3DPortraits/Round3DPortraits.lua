local _G = _G
--local AddOn, ns = ...

local version, internalVersion, date, uiVersion = GetBuildInfo()

local Round3DPortraits = LibStub("AceAddon-3.0"):NewAddon("Round3DPortraits", "AceEvent-3.0")

_G.Round3DPortraits = Round3DPortraits

-- Localization stuff, but I'm a lazy bastard, so good luck.
--local L = ns.L

local MyConsole = LibStub("AceConsole-3.0")

local debuffTextureFiles = {
   Curse = "Interface\\AddOns\\Round3DPortraits\\Textures\\DecurseBadge",
   Disease = "Interface\\AddOns\\Round3DPortraits\\Textures\\DiseaseBadge",
   Magic = "Interface\\AddOns\\Round3DPortraits\\Textures\\DispelBadge",
   Poison = "Interface\\AddOns\\Round3DPortraits\\Textures\\PoisonBadge",
}
local vehicleTextureFiles = {
   Natural = "Interface\\AddOns\\Round3DPortraits\\Textures\\BlizzPortBorderOrganicVehicle",
   Mechanical = "Interface\\AddOns\\Round3DPortraits\\Textures\\BlizzPortBorderVehicle",
}

local isPirateDay
do
   local wd, month, day, year = CalendarGetDate()
   if month == 9 and day == 19 then
      print('Yarr!')
      isPirateDay = true
   else
      isPirateDay = nil
   end
end
   

-- These aren't updated for Cataclysm yet.
local ClassDispelAbilities = {}
if uiVersion < 40000 then
   ClassDispelAbilities = {
      DEATHKNIGHT = {
	 Curse = nil,
	 Disease = nil,
	 Magic = nil,
	 Poison = nil,
      },
      DRUID = {
	 Curse = 1,
	 Disease = nil,
	 Magic = nil,
	 Poison = 1,
      },
      HUNTER = {
	 Curse = nil,
	 Disease = nil,
	 Magic = nil,
	 Poison = nil,
      },
      MAGE = {
	 Curse = 1,
	 Disease = nil,
	 Magic = nil,
	 Poison = nil,
      },
      PALADIN = {
	 Curse = nil,
	 Disease = 1,
	 Magic = 1,
	 Poison = 1,
      },
      PRIEST = {
	 Curse = nil,
	 Disease = 1,
	 Magic = 1,
	 Poison = nil,
      },
      ROGUE = {
	 Curse = nil,
	 Disease = nil,
	 Magic = nil,
	 Poison = nil,
      },
      SHAMAN = {
	 Curse = nil,
	 Disease = 1,
	 Magic = nil,
	 Poison = 1,
      },
      WARLOCK = {
	 Curse = nil,
	 Disease = nil,
	 Magic = nil,
	 Poison = nil,
      },
      WARRIOR = {
	 Curse = nil,
	 Disease = nil,
	 Magic = nil,
	 Poison = nil,
      },
   }
else
   ClassDispelAbilities = {
      DEATHKNIGHT = {
	 Curse = nil,
	 Disease = nil,
	 Magic = nil,
	 Poison = nil,
      },
      DRUID = {
	 Curse = 1,
	 Disease = nil,
	 Magic = 1,
	 Poison = 1,
      },
      HUNTER = {
	 Curse = nil,
	 Disease = nil,
	 Magic = nil,
	 Poison = nil,
      },
      MAGE = {
	 Curse = 1,
	 Disease = nil,
	 Magic = nil,
	 Poison = nil,
      },
      PALADIN = {
	 Curse = nil,
	 Disease = 1,
	 Magic = 1,
	 Poison = 1,
      },
      PRIEST = {
	 Curse = nil,
	 Disease = 1,
	 Magic = 1,
	 Poison = nil,
      },
      ROGUE = {
	 Curse = nil,
	 Disease = nil,
	 Magic = nil,
	 Poison = nil,
      },
      SHAMAN = {
	 Curse = 1,
	 Disease = nil,
	 Magic = 1,
	 Poison = nil,
      },
      WARLOCK = {
	 Curse = nil,
	 Disease = nil,
	 Magic = nil,
	 Poison = nil,
      },
      WARRIOR = {
	 Curse = nil,
	 Disease = nil,
	 Magic = nil,
	 Poison = nil,
      },
   }
end
   

local PlayerR3DFrameScripts = {}
local TargetR3DFrameScripts = {}
local TargetR3DFrameScriptsNonSecure = {}
local R3DFrameScripts = {}
local R3DFrame = {}
local PlayerR3DFrame = {}

-- Utility functions for the options database
local getOpt, setOpt, pb4InUse

do
   function getOpt(info)
      local key = info[#info]
      --MyConsole:Print(key, "=", Round3DPortraits.db.profile[key])
      return Round3DPortraits.db.profile[key]
   end

   function setOpt(info, value)
      local key = info[#info]
      Round3DPortraits.db.profile[key] = value
      Round3DPortraits:Refresh()
   end

   function pb4InUse(info)
      if Round3DPortraits.db.profile.usePitbull then
	 return true
      end
      return false
   end
end


Round3DPortraits.options = {
   type = "group",
   args = {
      global = {
	 type = "group",
	 name = "Global Settings",
	 order = 1,
	 args = {
	    __header1 = {
	       type = "description",
	       name = "Options for setting portrait frame characteristics.",
	       order = 1,
	    },
	    __caveat = {
	       type = "description",
	       name = "Note: if you toggle the 'Use Pitbull4' option the portrait frames become immobile.  To move them just drag the Pitbull4 frames instead.",
	       order = 2,
	    },
	    show = {
	       name = "Show",
	       type = "toggle",
	       desc = "Show or hide the frames",
	       set = setOpt,
	       get = getOpt,
	       width = "half",
	       order = 10,
	    },
	    lockMovement = {
	       name = "Lock Frames",
	       type = "toggle",
	       desc = "Lock frames in position",
	       set = setOpt,
	       get = getOpt,
	       order = 11,
	       disabled = pb4InUse,
	    },
	    usePitbull = {
	       name = "Use PitBull4",
	       type = "toggle",
	       desc = "Use PitBull4 unit frames as parent of Round3DPortrait frames.  Meaningless without PitBull4 installed.",
	       set = setOpt,
	       get = getOpt,
	       order = 12,
	    },
	    setEliteTextures = {
	       name = "Fancy Elites",
	       type = "toggle",
	       desc = "Draw elite and rare dragons around appropriate portraits",
	       set = setOpt,
	       get = getOpt,
	       --width = "half",
	       order = 13,
	    },
	    --showBarTex = {
	    --   name = "Bar Textures",
	    --   type = "toggle",
	    --   desc = "Draw health/power bar overlay texture",
	    --   set = setOpt,
	    --   get = getOpt, 
	    --   order = 14,
	    --},
	    doRoundBorder = {
	       name = "Round all edges",
	       type = "toggle",
	       desc = "Draw border rounded on all sides of portrait, good for a portrait independent of any unit frame",
	       set = setOpt,
	       get = getOpt,
	       order = 15,
	    },
	    isClamped = {
	       name = "Clamp to screen",
	       type = "toggle",
	       desc = "Clamp frames to screen",
	       set = setOpt,
	       get = getOpt,
	       order = 16,
	    },
	    doVehicles = {
	       name = "Show vehicle textures",
	       type = "toggle",
	       desc = "Show fancy frame textures when player is in a vehicle",
	       set = setOpt,
	       get = getOpt,
	       order = 17,
	    },
	    dimensionsHeading = {
	       type = "header",
	       name = "Scale and placement",
	    },
	    scale = {
	       name = "Scale",
	       type = "range",
	       desc = "Scale of player and target frames",
	       min = 0.1, max = 3, step = 0.005,
	       get = getOpt,
	       set = setOpt,
	       order = 101,
	    },
	    shieldScale = {
	       name = "Level button scale",
	       type = "range",
	       desc = "Scale of level button on frames",
	       min = 0.4, max = 2, step = 0.05,
	       get = getOpt,
	       set = setOpt,
	       order = 102,
	    },
	    playerX = {
	       name = "Player x",
	       type = "range",
	       desc = "Offset from center of screen in the horizontal direction",
	       min = -840, max = 840, softMin = -200, softMax = 200, step = 0.5,
	       get = getOpt,
	       set = setOpt,
	       order = 103,
	       disabled = pb4InUse,
	    },
	    playerY = {
	       name = "Player y",
	       type = "range",
	       desc = "Offset from center of screen in the vertical direction",
	       min = -840, max = 840, softMin = -200, softMax = 200, step=0.5,
	       get = getOpt,
	       set = setOpt,
	       order = 104,
	       disabled = pb4InUse,
	    },
	    targetX = {
	       name = "Target x",
	       type = "range",
	       desc = "Offset from center of screen in the horizontal direction",
	       min = -840, max = 840, softMin = -200, softMax = 200, step=0.5,
	       get = getOpt,
	       set = setOpt,
	       order = 105,
	       disabled = pb4InUse,
	    },
	    targetY = {
	       name = "Target y",
	       type = "range",
	       desc = "Offset from center of screen in the vertical direction",
	       min = -840, max = 840, softMin = -200, softMax = 200, step=0.5,
	       get = getOpt,
	       set = setOpt,
	       order = 106,
	       disabled = pb4InUse,
	    },	    
	 },
      },
   },
}

local defaults = {
   profile = {
      setEliteTextures = true,
      show = true,
      lockMovement = false,
      usePitbull = false,
      showBarTex = false,
      doRoundBorder = true,
      isClamped = true,
      doVehicles = true,
      scale = 1.0,
      shieldScale = 0.9,
      playerX = -200,
      playerY = -150,
      targetX = 200,
      targetY = -150,
   },
}

function Round3DPortraits:OnInitialize()
   self.db = LibStub("AceDB-3.0"):New("Round3DPortraitsDB", defaults, true)
   self.db.RegisterCallback(self, "OnProfileChanged", "Refresh")
   self.db.RegisterCallback(self, "OnProfileCopied", "Refresh")
   self.db.RegisterCallback(self, "OnProfileReset", "Refresh")
   self.options.args.profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db)
   self.options.args.profiles.order = 100
end

function Round3DPortraits:OnEnable()
   LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable("Round3DPortraits", 
							 self.options, 
							 nil)
   local ACD = LibStub("AceConfigDialog-3.0")
   self.OptionsPanel = ACD:AddToBlizOptions(self.name, self.name, nil, "global")
   self.OptionsPanel.Profiles = ACD:AddToBlizOptions(self.name, "Profiles", 
						     self.name, "profiles")

   -- Register events
   Round3DPortraits:RegisterEvent("UNIT_MODEL_CHANGED")
   Round3DPortraits:RegisterEvent("PLAYER_TARGET_CHANGED")
   Round3DPortraits:RegisterEvent("PLAYER_ENTERING_WORLD")
   Round3DPortraits:RegisterEvent("PLAYER_UPDATE_RESTING")
   Round3DPortraits:RegisterEvent("PLAYER_REGEN_ENABLED")
   Round3DPortraits:RegisterEvent("PLAYER_REGEN_DISABLED")
   Round3DPortraits:RegisterEvent("PLAYER_LEVEL_UP")
   Round3DPortraits:RegisterEvent("UNIT_AURA")
   Round3DPortraits:RegisterEvent("PLAYER_FLAGS_CHANGED")
   Round3DPortraits:RegisterEvent("UNIT_ENTERED_VEHICLE")
   Round3DPortraits:RegisterEvent("UNIT_EXITING_VEHICLE")
   Round3DPortraits:RegisterEvent("UNIT_EXITED_VEHICLE")
   Round3DPortraits:RegisterEvent("PLAYER_TALENT_UPDATE")
   Round3DPortraits:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")

   -- Create frames
   Round3DPortraits.CreatePlayerFrames()
   Round3DPortraits.CreateTargetFrames()

end

function Round3DPortraits:CreatePlayerFrames()
   local frameDimension = 64
   Round3DPortraits.PlayerBaseFrame = CreateFrame("Button",
						  "PlayerRound3DPortrait",
						  UIParent,
						  "SecureUnitButtonTemplate")
   local frame = Round3DPortraits.PlayerBaseFrame
   frame:SetSize(frameDimension, frameDimension)
   frame:SetFrameLevel(10)
   frame:Hide()

   -- Artwork
   frame.bg = frame:CreateTexture("PlayerR3DBG", "BACKGROUND")
   frame.bg:SetSize(frameDimension, frameDimension)

   -- Model
   if isPirateDay then
      frame.model = CreateFrame("DressUpModel", "PlayerR3DModel", frame)
   else
      frame.model = CreateFrame("PlayerModel", "PlayerR3DModel", frame)
   end
   frame.model:EnableMouse(false)
   frame.model:SetSize(frameDimension*0.75, frameDimension*0.75)
   frame.hub = frame.model:CreateTexture("PlayerR3DHub", "ARTWORK")
   frame.hub:SetSize(frameDimension, frameDimension)

   frame.guid = UnitGUID("player")

   frame.prettyFrame = CreateFrame("Button", "PlayerR3DPretty", frame)
   frame.prettyFrame:EnableMouse(false)
   frame.prettyFrame:SetFrameLevel(frame.model:GetFrameLevel() + 1)
   frame.pretty = frame.prettyFrame:CreateTexture("PlayerR3DBorder", "OVERLAY")
   frame.pretty:SetSize(frameDimension*2, frameDimension*2)

   frame.vehFrame = CreateFrame("Button", "PlayerR3DVehicle", frame.prettyFrame)
   frame.vehFrame:EnableMouse(false)
   frame.vehFrame:SetFrameLevel(frame.prettyFrame:GetFrameLevel() + 1)
   frame.vehicle = frame.vehFrame:CreateTexture("PlayerR3DVehTex", "OVERLAY")
   frame.vehicle:SetSize(frameDimension*2, frameDimension*2)

   frame.badgeFrame = CreateFrame("Button", "PlayerR3DBadgeFrame", frame.vehFrame)
   frame.badgeFrame:EnableMouse(false)
   frame.badgeFrame:SetPoint("CENTER", frame, "CENTER", 0, 0)
   frame.badge = frame.badgeFrame:CreateTexture("PlayerR3DBadge", "OVERLAY")

   frame.fontFrame = CreateFrame("Button", "PlayerR3DLevelFontFrame", frame.badgeFrame)
   frame.fontFrame:EnableMouse(false)
   frame.fontFrame:SetPoint("CENTER", frame, "CENTER", 0, 0)
   frame.levelstr = frame.fontFrame:CreateFontString("PlayerLevelString", "OVERLAY")
   frame.levelstr:SetFont("Fonts\\FRIZQT__.TTF", 8)

   frame.shieldFrame = CreateFrame("Button", "PlayerR3DShieldFrame", frame.fontFrame)
   frame.shieldFrame:EnableMouse(false)
   frame.shield = frame.shieldFrame:CreateTexture("PlayerR3DShield", "OVERLAY")
   frame.shield:SetSize(28, 32)
   --frame.setHeight(32)

   frame.combatIcFrame = CreateFrame("Button", "PlayerR3DCombatIconFrame", frame.fontFrame)
   frame.combatIcFrame:EnableMouse(false)
   frame.combatIc = frame.combatIcFrame:CreateTexture("PlayerR3DCombatIcon", "OVERLAY")
   frame.combatIc:SetSize(23, 23)

   frame.dispelFrame = CreateFrame("Button", "PlayerR3DDispelFrame", frame.badgeFrame)
   frame.dispelFrame:EnableMouse(false)
   frame.dispelFrame:SetPoint("CENTER", frame.badgeFrame, "CENTER", 0, 0)
   frame.dispel = frame.dispelFrame:CreateTexture("PlayerR3DDispel", "OVERLAY")
   frame.dispelFrame:SetFrameLevel(frame.combatIcFrame:GetFrameLevel() + 1)

   for key, val in pairs(R3DFrameScripts) do
      frame:HookScript(key, val)
   end

   for key, val in pairs(PlayerR3DFrameScripts) do
      frame:HookScript(key, val)
   end

   for key, val in pairs(PlayerR3DFrame) do
      frame[key] = val
   end

   for key, val in pairs(R3DFrame) do
      frame[key] = val
   end

   local isClamped = Round3DPortraits.db.profile.isClamped
   if isClamped then
      frame:SetClampedToScreen(true)
   else
      frame:SetClampedToScreen(false)
   end

   frame:SetMovable(true)
   frame:RegisterForDrag("LeftButton")
   frame:RegisterForClicks("AnyUp")
   frame:SetAttribute("type1", "target")
   frame:SetAttribute("type2", "menu")
   frame:SetAttribute("unit", "player")
   frame:SetAttribute("toggleForVehicle", "true")

end

function Round3DPortraits:CreateTargetFrames()
   local frameDimension = 64
   Round3DPortraits.TargetBaseFrame = CreateFrame("Button",
						  "TargetRound3DPortrait",
						  UIParent,
						  "SecureUnitButtonTemplate")
   local frame = Round3DPortraits.TargetBaseFrame
   frame:SetSize(frameDimension, frameDimension)
   frame:SetFrameLevel(10)
   frame:Hide()

   frame.bg = frame:CreateTexture("TargetR3DBG", "BACKGROUND")
   frame.bg:SetSize(frameDimension, frameDimension)

   frame.model = CreateFrame("PlayerModel", "TargetR3DModel", frame)
   frame.model:EnableMouse(false)
   frame.model:SetSize(frameDimension*0.75, frameDimension*0.75)
   frame.hub = frame.model:CreateTexture("TargetR3DHub", "ARTWORK")
   frame.hub:SetSize(frameDimension, frameDimension)
   frame.portrait2d = frame.model:CreateTexture("TargetR3DFallback", "OVERLAY")
   frame.portrait2d:SetSize(frameDimension, frameDimension)

   frame.prettyFrame = CreateFrame("Button", "TargetR3DPretty", frame)
   frame.prettyFrame:EnableMouse(false)
   frame.prettyFrame:SetFrameLevel(frame.model:GetFrameLevel() + 1)
   frame.pretty = frame.prettyFrame:CreateTexture("TargetR3DBorder", "OVERLAY")
   frame.pretty:SetSize(frameDimension*2, frameDimension*2)

   frame.badgeFrame = CreateFrame("Button", "TargetR3DBadgeFrame", frame.prettyFrame)
   frame.badgeFrame:EnableMouse(false)
   frame.badgeFrame:SetPoint("CENTER", frame, "CENTER", 0, 0)
   frame.badge = frame.badgeFrame:CreateTexture("TargetR3DBadge", "OVERLAY")

   frame.fontFrame = CreateFrame("Button", "TargetR3DLevelFontFrame", frame.badgeFrame)
   frame.fontFrame:EnableMouse(false)
   frame.fontFrame:SetPoint("CENTER", frame, "CENTER", 0, 0)
   frame.levelstr = frame.fontFrame:CreateFontString("TargetLevelString", "OVERLAY")
   frame.levelstr:SetFont("Fonts\\FRIZQT__.TTF", 8)

   frame.shieldFrame = CreateFrame("Button", "TargetR3DShieldFrame", frame.fontFrame)
   frame.shieldFrame:EnableMouse(false)
   frame.shield = frame.shieldFrame:CreateTexture("TargetR3DShield", "OVERLAY")
   frame.shield:SetSize(18, 18)--width, height

   for key, val in pairs(R3DFrameScripts) do
      frame:HookScript(key, val)
   end

   for key, val in pairs(TargetR3DFrameScripts) do
      frame:HookScript(key, val)
   end

   for key, val in pairs(R3DFrame) do
      frame[key] = val
   end

   local isClamped = Round3DPortraits.db.profile.isClamped
   if isClamped then
      frame:SetClampedToScreen(true)
   else
      frame:SetClampedToScreen(false)
   end

   frame:SetMovable(true)
   frame:RegisterForDrag("LeftButton")
   frame:RegisterForClicks("AnyUp")
   frame:SetAttribute("type1", "target")
   frame:SetAttribute("type2", "menu")
   frame:SetAttribute("unit", "target")
   frame:SetAttribute("toggleForVehicle", "true")

end

function Round3DPortraits:DrawPlayerPortrait()

   --local junk, classt = UnitClass("player")
   --MyConsole:Print(classt)

   --local cda = ClassDispelAbilities[classt]
   --MyConsole:Print(cda.Curse, cda.Disease, cda.Magic, cda.Poison)

   local frame = Round3DPortraits.PlayerBaseFrame
   local show = Round3DPortraits.db.profile.show
   local xPos = Round3DPortraits.db.profile.playerX
   local yPos = Round3DPortraits.db.profile.playerY
   local scale = Round3DPortraits.db.profile.scale
   local shieldScale = Round3DPortraits.db.profile.shieldScale
   local doRoundBorder = Round3DPortraits.db.profile.doRoundBorder
   local usePitbull = Round3DPortraits.db.profile.usePitbull
   local PB4 = PitBull4
   --if PitBull4 then print("Found PitBull4") end
   local levformatstr, r, g, b, level = Round3DPortraits:MakeLevelText("player")

   -- Set all frame positions, textures, and formatted text
   frame:SetScale(scale)
   if PB4 and usePitbull then
      frame:ClearAllPoints()
      frame:SetPoint("RIGHT", PitBull4_Frames_player, "LEFT", 1.1, -0.5)
   else
      frame:ClearAllPoints()
      frame:SetPoint("CENTER", nil, "CENTER", xPos, yPos)
   end

   frame.badge:SetSize(shieldScale*32, shieldScale*32)
   frame.dispel:SetSize(shieldScale*32, shieldScale*32)
   frame.shield:SetSize(shieldScale*28, shieldScale*32)
   frame.combatIc:SetSize(shieldScale*23, shieldScale*23)

   frame.bg:SetTexture("Interface\\AddOns\\Round3DPortraits\\Textures\\ModelBack")
   frame.bg:SetPoint("CENTER", frame, "CENTER", 0, 0)
   frame.bg:SetVertexColor(1, 1, 1, 1)

   frame.model:SetPoint("CENTER", frame, "CENTER", 0, -1)

   frame.hub:SetTexture("Interface\\AddOns\\Round3DPortraits\\Textures\\CircleBorder")
   frame.hub:SetPoint("CENTER", frame, "CENTER", 0, 0)

   if not doRoundBorder then
      frame.pretty:SetTexture("Interface\\AddOns\\Round3DPortraits\\Textures\\BlizzPortBorder")
      frame.pretty:SetPoint("CENTER", frame, "CENTER", -4.5, -1.5)
   else
      frame.pretty:SetTexture("Interface\\AddOns\\Round3DPortraits\\Textures\\BlizzPortBorderFullRound")
      frame.pretty:SetPoint("CENTER", frame, "CENTER", -4.5, -1.5)
   end

   -- DEMO:
   --frame.vehicle:SetTexture("Interface\\AddOns\\Round3DPortraits\\Textures\\BlizzPortBorderOrganicVehicle")
   --frame.vehicle:SetPoint("CENTER", frame, "CENTER", -4.5, -1.5)

   frame.badge:SetTexture("Interface\\AddOns\\Round3DPortraits\\Textures\\LevelBadgePlayer")
   frame.badge:SetPoint("CENTER", frame, "CENTER", -22, -21.5)

   frame.levelstr:SetFormattedText(levformatstr, 240, 240, 210, level)
   --frame.levelstr:SetPoint("CENTER", frame, "CENTER", -21.5, -20.5)
   frame.levelstr:SetPoint("CENTER", frame.badge, "CENTER", 1, 1)

   frame.shield:SetTexture("Interface\\CharacterFrame\\UI-StateIcon")
   frame.shield:SetTexCoord(0., 0.5, 0., 0.499)
   --frame.shield:SetPoint("CENTER", frame, "CENTER", -21.5, -22.5)
   frame.shield:SetPoint("CENTER", frame.badge, "CENTER", 0.75, -1)

   frame.combatIc:SetTexture("Interface\\CharacterFrame\\UI-StateIcon")
   frame.combatIc:SetTexCoord(0.5, 1., 0., 0.499)
   --frame.combatIc:SetPoint("CENTER", frame, "CENTER", -20.75, -20)
   frame.combatIc:SetPoint("CENTER", frame.badge, "CENTER", 1.5, 1)

   if ( not IsResting() ) then
      frame.shield:Hide()
   end

   if (not InCombatLockdown() ) then
      frame.combatIc:Hide()
   else
      frame.shield:Hide()
      frame.combatIc:Show()
   end

   if show and not frame.isRegistered then
      frame:Show()
      --frame:SetAttribute("unit", "player")
      --frame:SetAttribute("toggleForVehicle", "true")
      RegisterUnitWatch(frame)
      frame.isRegistered = true
      _G.ClickCastFrames[frame] = true
   elseif frame.isRegistered and not show then
      UnregisterUnitWatch(frame)
      --frame:SetAttribute("unit", nil)
      frame:Hide()
      frame.isRegistered = nil
      _G.ClickCastFrames[frame] = nil
   end
   frame.model:SetUnit("player")
   if isPirateDay then
      frame.model:Undress()
      frame.model:TryOn(9636)
      frame.model:TryOn(6795)
      frame.model:TryOn(6835)
      frame.model:TryOn(6836)
      frame.model:TryOn(2955)
      frame.model:TryOn(3935)
   end
   frame.model:SetCamera(0)
end

function Round3DPortraits:DrawTargetPortrait()
   local frame = Round3DPortraits.TargetBaseFrame
   local show = Round3DPortraits.db.profile.show
   local xPos = Round3DPortraits.db.profile.targetX
   local yPos = Round3DPortraits.db.profile.targetY
   local scale = Round3DPortraits.db.profile.scale
   local shieldScale = Round3DPortraits.db.profile.shieldScale
   local setelite = Round3DPortraits.db.profile.setEliteTextures
   local doRoundBorder = Round3DPortraits.db.profile.doRoundBorder
   local levformatstr, r, g, b, level = Round3DPortraits:MakeLevelText("target")
   local elitestat = UnitClassification("target")
   local usePitbull = Round3DPortraits.db.profile.usePitbull
   local PB4 = PitBull4

   frame:SetScale(scale)

   local uiScale = UIParent:GetEffectiveScale()

   if PB4 and usePitbull then
      frame:ClearAllPoints()
      frame:SetPoint("LEFT", PitBull4_Frames_target, "RIGHT", -1.5, -1.75)
   else
      frame:ClearAllPoints()
      frame:SetPoint("CENTER", nil, "CENTER", xPos, yPos)
   end

   frame.badge:SetSize(shieldScale*32, shieldScale*32)
   frame.shield:SetSize(shieldScale*18, shieldScale*18)

   frame.bg:SetTexture("Interface\\AddOns\\Round3DPortraits\\Textures\\ModelBack")
   frame.bg:SetPoint("CENTER", frame, "CENTER", 0.5, 0)
   frame.bg:SetVertexColor(1, 1, 1, 1)

   frame.model:SetPoint("CENTER", frame, "CENTER", 0.5, -1)

   frame.hub:SetTexture("Interface\\AddOns\\Round3DPortraits\\Textures\\CircleBorder")
   frame.hub:SetPoint("CENTER", frame, "CENTER", 0.5, 0)

   local fileName, borderX, borderY
   if setelite and (elitestat == "elite" or (level == 99 and not UnitIsPlayer("target")) and setelite) then
      if not doRoundBorder then
	 fileName = "Interface\\AddOns\\Round3DPortraits\\Textures\\BlizzPortBorderElite"
      else
	 fileName = "Interface\\AddOns\\Round3DPortraits\\Textures\\BlizzPortBorderEliteFullRound"
      end
      borderX = 16.5
      borderY = -6.5
   elseif elitestat == "rare" and setelite then
      if not doRoundBorder then
	 fileName = "Interface\\AddOns\\Round3DPortraits\\Textures\\BlizzPortBorderRare"
      else
	 fileName = "Interface\\AddOns\\Round3DPortraits\\Textures\\BlizzPortBorderRareFullRound"
      end
      borderX = 16.5
      borderY = -6.5
   else
      if not doRoundBorder then
	 fileName = "Interface\\AddOns\\Round3DPortraits\\Textures\\BlizzPortBorderRight"
	 borderX = 4.5
	 borderY = -1.5
      else
	 fileName = "Interface\\AddOns\\Round3DPortraits\\Textures\\BlizzPortBorderFullRound"
	 borderX = -3.5
	 borderY = -1.5
      end
   end

   --MyConsole:Print(fileName)
   frame.pretty:SetTexture(fileName)
   frame.pretty:SetPoint("CENTER", frame, "CENTER", borderX, borderY)

   frame.badge:SetTexture("Interface\\AddOns\\Round3DPortraits\\Textures\\LevelBadgeTarget")
   frame.badge:SetPoint("CENTER", frame, "CENTER", 22, -22)---21.5)

   frame.levelstr:SetFormattedText(levformatstr, r, g, b, level)
   --frame.levelstr:SetPoint("CENTER", frame, "CENTER", 21.5, -20.5)
   frame.levelstr:SetPoint("CENTER", frame.badge, "CENTER", 0, 1)

   if ( level == 99 ) then
      frame.shield:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull")
      frame.levelstr:Hide()
   else
      frame.shield:SetTexture(0, 0, 0, 0)
      frame.levelstr:Show()
   end
   --frame.shield:SetPoint("CENTER", frame, "CENTER", 22.5, -20.5)
   frame.shield:SetPoint("CENTER", frame.badge, "CENTER", 0, 0)

   -- Register frame as a unit frame and as a click cast frame, if shown
   if show and not frame.isRegistered then
      frame:Show()
      --frame:SetAttribute("unit", "target")
      --frame:SetAttribute("toggleForVehicle", "true")
      RegisterUnitWatch(frame)
      frame.isRegistered = true
      _G.ClickCastFrames[frame] = true
   elseif frame.isRegistered and not show then
      UnregisterUnitWatch(frame)
      --frame:SetAttribute("unit", nil)
      frame:Hide()
      frame.isRegistered = nil
      _G.ClickCastFrames[frame] = nil
   end
   frame.portrait2d:SetPoint("CENTER", frame, "CENTER", 0, 0)

   if UnitIsPlayer("target") 
   and (UnitInParty("target") or UnitInRaid("target"))
   and not UnitIsVisible("target") then
      frame.model:ClearModel()
      SetPortraitTexture(frame.portrait2d, "target")
      frame.portrait2d:Show()
   else
      frame.model:SetUnit("target")
      frame.portrait2d:Hide()
   end
   frame.model:SetCamera(0)
end



-- Event handlers
function Round3DPortraits:UNIT_MODEL_CHANGED(junk, unitId)
   --MyConsole:Print("model")
   Round3DPortraits:Refresh()
end

function Round3DPortraits:UNIT_AURA(junk, unitId)
   if unitId == "player" then
      local frame = Round3DPortraits.PlayerBaseFrame
      local junk, classt = UnitClass("player")
      local abilities = ClassDispelAbilities[classt]
      --MyConsole:Print(abilities["Curse"], abilities["Disease"], abilities["Magic"], abilities["Poison"])
      local hasCurse, hasDisease, hasMagic, hasPoison = nil, nil, nil, nil
      local ndx = 1
      while true do
	 local name, rank, icon, count, dispelType = UnitDebuff("player", ndx)
	 --MyConsole:Print(ndx, dispelType)
	 if not name then
	    break
	 end
	 if dispelType == "Curse" then
	    hasCurse = dispelType
	 end
	 if dispelType == "Disease" then
	    hasDisease = dispelType
	 end
	 if dispelType == "Magic" then
	    hasMagic = dispelType
	    --hasDisease = "Disease"
	 end
	 if dispelType == "Poison" then
	    hasPoison = dispelType
	 end
	 ndx = ndx + 1
      end
      if abilities[hasCurse] then
	 --MyConsole:Print(debuffTextureFiles[hasCurse])
	 frame.dispel:SetTexture(debuffTextureFiles[hasCurse])
	 frame.shield:Hide()
      elseif abilities[hasDisease] then
	 --MyConsole:Print(debuffTextureFiles[hasDisease])
	 frame.dispel:SetTexture(debuffTextureFiles[hasDisease])
	 frame.shield:Hide()
      elseif abilities[hasMagic] then
	 --MyConsole:Print(debuffTextureFiles[hasMagic])
	 frame.dispel:SetTexture(debuffTextureFiles[hasMagic])
	 frame.shield:Hide()
      elseif abilities[hasPoison] then
	 --print(abilities[hasPoison])
	 --MyConsole:Print(debuffTextureFiles[hasPoison])
	 frame.dispel:SetTexture(debuffTextureFiles[hasPoison])
	 frame.shield:Hide()
      else
	 --MyConsole:Print("color: 0 0 0 0")
	 frame.dispel:SetTexture(0, 0, 0, 0)
	 if IsResting() then
	    frame.shield:Show()
	 end
      end
      frame.dispel:SetPoint("CENTER", frame.badge, "CENTER", 0, 0)
   end
end

function Round3DPortraits:PLAYER_FLAGS_CHANGED()
   if UnitIsAFK("player") then
      --Round3DPortraits.PlayerBaseFrame.model:SetA
      return
   end
end

function Round3DPortraits:PLAYER_TARGET_CHANGED()
   if ( UnitExists("target") and not InCombatLockdown()) then
      Round3DPortraits:DrawTargetPortrait()
      return
   end
   local frame = Round3DPortraits.TargetBaseFrame
   if not UnitIsVisible("target") then
      frame.model:ClearModel()
      SetPortraitTexture(frame.portrait2d, "target")
      frame.portrait2d:Show()
   else
      frame.model:SetUnit("target")
      frame.model:SetCamera(0)
      frame.portrait2d:Hide()
   end
end

function Round3DPortraits:PLAYER_ENTERING_WORLD()
   Round3DPortraits:DrawPlayerPortrait()
   Round3DPortraits:DrawTargetPortrait()
end

function Round3DPortraits:PLAYER_UPDATE_RESTING()
   if IsResting() then
      Round3DPortraits.PlayerBaseFrame.shield:Show()
   else
      Round3DPortraits.PlayerBaseFrame.shield:Hide()
   end
end

function Round3DPortraits:PLAYER_REGEN_DISABLED()
   local frame = Round3DPortraits.PlayerBaseFrame
   frame.combatIc:Show()
   frame.levelstr:Hide()
   frame.shield:Hide()
   --frame.model:SetCamera(0)
   --self.PlayerR3DFrame:PLAYER_REGEN_DISABLED()
   if frameThatsMoving then
      R3DFrameScripts.OnDragStop(frameThatsMoving)
   end
end
function Round3DPortraits:PLAYER_REGEN_ENABLED()
   local frame = Round3DPortraits.PlayerBaseFrame
   frame.combatIc:Hide()
   frame.levelstr:Show()
   --frame.model:SetCamera(0)
   if IsResting() then
      frame.shield:Show()
   else
      frame.shield:Hide()
   end
   --self:PLAYER_REGEN_ENABLED_MINE()
end

function Round3DPortraits:PLAYER_TALENT_UPDATE()
   --MyConsole:Print("Talent points changed")
   local junk = nil
end

function Round3DPortraits:ACTIVE_TALENT_GROUP_CHANGED()
   --MyConsole:Print("Switched specs")
   local junk = nil
end

function Round3DPortraits:PLAYER_LEVEL_UP(...)
   local event, levelstr = ...
   local levformatstr, r, g, b, level = Round3DPortraits:MakeLevelText("player")
   Round3DPortraits.PlayerBaseFrame.levelstr:SetFormattedText(levformatstr, 240, 240, 210, levelstr)
end

function Round3DPortraits:UNIT_ENTERED_VEHICLE(junk, unit)
   if unit ~= "player" then return end
   local frame = Round3DPortraits.PlayerBaseFrame
   local skin = UnitVehicleSkin("player")
   --MyConsole:Print("Texture", vehicleTextureFiles[skin])
   if UnitHasVehicleUI("player") and Round3DPortraits.db.profile.doVehicles then
      frame.vehicle:SetTexture(vehicleTextureFiles[skin])
      frame.vehicle:SetPoint("CENTER", frame, "CENTER", -4.5, -1.5)
      frame.model:SetUnit("vehicle")
      frame.model:SetCamera(0)
      frame.vehFrame:Show()
      frame.badgeFrame:Hide()
   else
      frame.vehicle:SetTexture(0, 0, 0, 0)
      frame.badgeFrame:Show()
   end
end

function Round3DPortraits:UNIT_EXITING_VEHICLE(junk, unit)
   if unit == "player" then
      local junk = nil
   end
end

function Round3DPortraits:UNIT_EXITED_VEHICLE()
   local frame = Round3DPortraits.PlayerBaseFrame
   if not UnitHasVehicleUI("player") then
      frame.model:SetUnit("player")
      frame.model:SetCamera(0)
      frame.vehicle:SetTexture(0, 0, 0, 0)
      frame.badgeFrame:Show()
   end
end

function Round3DPortraits:OnDisable()
   MyConsole:Print("Disable Round3DPortraits")
end

function Round3DPortraits:Refresh()
   --MyConsole:Print("Refresh")
   Round3DPortraits:DrawPlayerPortrait()
   if not Round3DPortraits.db.profile.doVehicles then
      Round3DPortraits.PlayerBaseFrame.vehFrame:Hide()
      Round3DPortraits.PlayerBaseFrame.badgeFrame:Show()
   end
   if (UnitExists("target")) then
      Round3DPortraits:DrawTargetPortrait()
   end

   if Round3DPortraits.db.profile["usePitbull"] and not Round3DPortraits.db.profile.lockMovement then
      Round3DPortraits.db.profile["lockMovement"] = true
      LibStub("AceConfigRegistry-3.0"):NotifyChange("Round3DPortraits")
   end
end

-- Utility
function Round3DPortraits:MakeLevelText(theUnit)
   local level = UnitLevel(theUnit)
   if level <= 0 then
      level = 99
   end
   local color = GetQuestDifficultyColor(level)
   return "|cff%02x%02x%02x%s", color.r*255, color.g*255, color.b*255, level
end

local frameThatsMoving = nil
function R3DFrameScripts:OnDragStart()
   local db = Round3DPortraits.db.profile
   --local frame = Round3DPortraits.PlayerBaseFrame
   if db.lockMovement or InCombatLockdown() then
      return
   end

   self:StartMoving()
   frameThatsMoving = self
end

function R3DFrameScripts:OnDragStop()
   if frameThatsMoving ~= self then return end
   frameThatsMoving = nil
   self:StopMovingOrSizing()

   -- I'm still having a hard time getting the repositioning right when syncing
   --  the position to the db after dragging the frame.
   local uiScale = UIParent:GetEffectiveScale()
   local scale = self:GetEffectiveScale() / uiScale
   local x, y = self:GetCenter()
   x, y = x*scale, y*scale
   x = x - GetScreenWidth()/2
   y = y - GetScreenHeight()/2

   if self == Round3DPortraits.PlayerBaseFrame then
      Round3DPortraits.db.profile["playerX"] = x/self:GetScale()
      Round3DPortraits.db.profile["playerY"] = y/self:GetScale()
      --print(Round3DPortraits.db.profile["playerX"], 
	--    Round3DPortraits.db.profile["playerY"])
   elseif self == Round3DPortraits.TargetBaseFrame then
      Round3DPortraits.db.profile["targetX"] = x/self:GetScale()
      Round3DPortraits.db.profile["targetY"] = y/self:GetScale()
   end

   LibStub("AceConfigRegistry-3.0"):NotifyChange("Round3DPortraits")

   Round3DPortraits:Refresh()
end

function R3DFrameScripts:OnMouseUp(button)
   if button == "LeftButton" then
      return R3DFrameScripts.OnDragStop(self)
   end
end

function PlayerR3DFrame:PLAYER_REGEN_DISABLED()
   --print("")
   local junk = nil
end

function PlayerR3DFrame:PLAYER_REGEN_ENABLED()
   --frame.combatIc:Hide()
   --frame.levelstr:Show()
   --if IsResting() then
   --   frame.shield:Show()
   --else
   --   frame.shield:Hide()
   --end
   --print("In function")
   local junk = nil
end

function PlayerR3DFrameScripts:OnEnter()
   if InCombatLockdown() then return end
   GameTooltip_SetDefaultAnchor(GameTooltip, self)
   GameTooltip:SetUnit("player")
   local r, g, b = GameTooltip_UnitColor("player")
   GameTooltipTextLeft1:SetTextColor(r, g, b)
   GameTooltip:Show()
   --Round3DPortraits:PositionTest()
end

function PlayerR3DFrameScripts:OnLeave()
   GameTooltip:Hide()
end

function TargetR3DFrameScripts:OnEnter()
   if InCombatLockdown() then return end
   GameTooltip_SetDefaultAnchor(GameTooltip, self)
   GameTooltip:SetUnit("target")
   local r, g, b = GameTooltip_UnitColor("target")
   GameTooltipTextLeft1:SetTextColor(r, g, b)
   GameTooltip:Show()
end

function TargetR3DFrameScriptsNonSecure:OnClick(button, isDown)
   --MyConsole:Print("OnClick", self, button, down)
   if button == "RightButton" and not isDown and not InCombatLockdown() then
      R3DFrame:menu("target")
   end
end

function TargetR3DFrameScripts:OnLeave()
   GameTooltip:Hide()
end


function R3DFrameScripts:OnShow()
   --Round3DPortraits:Refresh()
   Round3DPortraits.PlayerBaseFrame.model:SetCamera(0)
   if (UnitExists("target")) then
      Round3DPortraits.TargetBaseFrame.model:SetCamera(0)
   end
end

local Round3DPortraitsDropDown = CreateFrame("Frame", "Round3DPortraitsDropDown", UIParent, "UIDropDownMenuTemplate")
UnitPopupFrames[#UnitPopupFrames+1] = "Round3DPortraitsDropDown"

local function getMenuFromUnit(unit)
   
   if UnitIsUnit(unit, "player") then
      return "SELF"
   end
   
   -- I hope to implement vehicle switching at some point, not a huge priority
   if UnitIsUnit(unit, "vehicle") then
      return "VEHICLE"
   end
   
   if not UnitIsPlayer(unit) then
      return "TARGET"
   end

   return "PLAYER"
end

local menuUnit = nil
local function menuInitFunc()
   if not menuUnit then return end
   local menu = getMenuFromUnit(menuUnit)
   if menu then
      UnitPopup_ShowMenu(Round3DPortraitsDropDown, menu, menuUnit, nil, nil)
   end
end
UIDropDownMenu_Initialize(Round3DPortraitsDropDown, menuInitFunc, "MENU", nil)

function R3DFrame:menu(unit)
   menuUnit = unit
   ToggleDropDownMenu(1, nil, Round3DPortraitsDropDown, "cursor")
end


-- This function was for debugging, in here for reference
--  Creates a basic unit frame to test dragging, targeting, menu, etc.
function Round3DPortraits:FrameTest()
   Round3DPortraits.PlayerInteractionFrame = CreateFrame("Button", "PlayerR3DInteractionFrame", Round3DPortraits.PlayerBaseFrame, "SecureUnitButtonTemplate")
   local frame = Round3DPortraits.PlayerInteractionFrame
   frame:SetPoint("CENTER", nil, "CENTER", -200, -100)
   --frame:SetPoint("CENTER", Round3DPortraits.PlayerBaseFrame, "CENTER", 0, 0)
   frame:SetWidth(64)
   frame:SetHeight(64)
   frame:SetFrameLevel(20)

   --frame.texture = frame:CreateTexture("FrameTestTex", "BACKGROUND")
   --frame.texture:SetTexture("Interface\\Icons\\ACHIEVEMENT_BOSS_KINGYMIRON_01")
   --frame.texture:SetAllPoints()

   frame:SetMovable(true)
   frame:RegisterForDrag("LeftButton")
   frame:RegisterForClicks("AnyUp")
   frame:SetAttribute("*type1", "target")
   frame:SetAttribute("*type2", "menu")
   frame:SetAttribute("unit", "player")

   for key, val in pairs(R3DFrameScripts) do
      frame:HookScript(key, val)
   end
   for key, val in pairs(PlayerR3DFrameScripts) do
      frame:HookScript(key, val)
   end
   for key, val in pairs(PlayerR3DFrame) do
      frame[key] = val
   end
   for key, val in pairs(R3DFrame) do
      frame[key] = val
   end

   frame:SetAttribute("unit", "player")
   RegisterUnitWatch(frame)   

end

-- Another debugging function, still here but nothing calls it
function Round3DPortraits:PositionTest()
   local playX = Round3DPortraits.db.profile.playerX
   local playY = Round3DPortraits.db.profile.playerY
   local frame = Round3DPortraits.PlayerBaseFrame
   local uiScale = UIParent:GetEffectiveScale()
   local scale = frame:GetEffectiveScale() / uiScale
   local baseScale = frame:GetScale()
   local x, y = frame:GetCenter()
   MyConsole:Print("----")
   MyConsole:Print("DEBUG:", "UI Scale:", UIParent:GetEffectiveScale())
   MyConsole:Print("DEBUG:", "Frame eff scale:", frame:GetEffectiveScale())
   MyConsole:Print("DEBUG:", "Frame scale:", baseScale, scale)
   MyConsole:Print("DEBUG:", "Saved coords:", playX, playY)
   MyConsole:Print("DEBUG:", "GetCenter coords:", x, y)
   MyConsole:Print("DEBUG:", "Moved to center:", x-GetScreenWidth()/2, y-GetScreenHeight()/2)
   MyConsole:Print("DEBUG:", "Screen resolution", GetScreenWidth(), GetScreenHeight())
   x, y = x*scale, y*scale
   x = x - GetScreenWidth() / 2
   y = y - GetScreenHeight() / 2
   MyConsole:Print("DEBUG:", "Scaled:", x, y)
end