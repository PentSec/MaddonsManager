reports = {"","",""}
hs = 30;
Historys = {}
for i=hs,0, -1 do
Historys[i] = {"","","","",""}
end
result3 = {}
 for i=hs,0, -1 do
result3[i] = {""}
end

SLASH_ES1 = "/es"
SlashCmdList["ES"] = function(msg, editBox)
if msg == "show" then DragFrame1:Show();
elseif msg == "hide" then DragFrame1:Hide();
elseif msg == "report" then ReportChat(class);
else print("|cff0070DEList of commands:"); print("|cffFFF569/es show"); print("|cffFFF569/es hide"); print("|cffFFF569/es report"); 
end
end
--print("List of commands:|r /es show|r /es hide"]); 

function round(number, decimals)
    return (("%%.%df"):format(decimals)):format(number)
end

function ReportChat()
SendChatMessage("--------AVG: "..PlayerValueDbg().."-------");
SendChatMessage(UnitClass("target")..">>"..UnitName("target"));
SendChatMessage("2s - "..reports[1]);
SendChatMessage("3s - "..reports[2]);
SendChatMessage("YoloQ - "..reports[3]);
SendChatMessage("-----"..PlayerValue().."-----");
end 

function PlayerValueDbg()
	local r1 = reports[1];
	local r2 = reports[2];
	local r3 = reports[3];
	if r1 == "--" then r1 = 0;
	end
	if r2 == "--" then r2 = 0;
	end
	if r3 == "--" then r3 = 0;
	end
	value = (r1+r2+r3)/3;
	return round(value,0);
end

function PlayerValue()
	local r1 = reports[1];
	local r2 = reports[2];
	local r3 = reports[3];
	if r1 == "--" then r1 = 0;
	end
	if r2 == "--" then r2 = 0;
	end
	if r3 == "--" then r3 = 0;
	end
	value = (r1+r2+r3)/3;
	if value <= 1400 then return "%$^#!& noob";
	elseif value > 1400 and value <= 1600 then return "Professional noob";
	elseif value > 1600 and value <= 2000 then return "Not bad";
	elseif value > 2000 and value <= 2300 then return "Professional";
	elseif value > 2300 and value <= 2600 then return "Maybe gladiator";
	elseif value > 2600 and value <= 2800 then return "Gladiator";
	elseif value > 2800 then return "God of Warcraft";
	else return "N\A";
	end
end


function Colorcheck(class)
if class == "Death Knight" then strings = "|cffC41F3BDeath Knight";
elseif class == "Mage" then strings = "|cff69CCF0Mage";
elseif class == "Warlock" then strings = "|cff9482C9Warlock";
elseif class == "Priest" then strings = "|cffFFFFFFPriest";
elseif class == "Druid" then strings = "|cffFF7D0ADruid";
elseif class == "Shaman" then strings = "|cff0070DEShaman";
elseif class == "Rogue" then strings = "|cffFFF569Rogue";
elseif class == "Paladin" then strings = "|cffF58CBAPaladin";
elseif class == "Warrior" then strings = "|cffC79C6EWarrior";
elseif class == "Hunter" then strings = "|cffABD473Hunter";
end
return strings;
end

function ColorcheckName(class, name)
if class == "Death Knight" then strings = "|cffC41F3B"..name;
elseif class == "Mage" then strings = "|cff69CCF0"..name;
elseif class == "Warlock" then strings = "|cff9482C9"..name;
elseif class == "Priest" then strings = "|cffFFFFFF"..name;
elseif class == "Druid" then strings = "|cffFF7D0A"..name;
elseif class == "Shaman" then strings = "|cff0070DE"..name;
elseif class == "Rogue" then strings = "|cffFFF569"..name;
elseif class == "Paladin" then strings = "|cffF58CBA"..name;
elseif class == "Warrior" then strings = "|cffC79C6E"..name;
elseif class == "Hunter" then strings = "|cffABD473"..name;
end
return strings;
end

function CheckExists(name)
	exists = false;
	for i = hs,0, -1 do
		if Historys[i][1] == name then
			exists = true;
		end
	end
	return exists;
end

function GetExpx(unit)
	ClearAchievementComparisonUnit();
	SetAchievementComparisonUnit(unit); 
end

function CheckDniwe(data)
	local resultio;
	if data=="--" then
		resultio="dniwe";
	else
		resultio=data;
	end
	return resultio;
end

function PrintExpx(id)
	str = GetComparisonStatistic(id);
	return str;
end

function CollectData()
	local s2 = PrintExpx(370);
	local s3 = PrintExpx(595);
	local solo = PrintExpx(596);
	local classz = UnitClass("target");
	local namez = ColorcheckName(classz, UnitName("target"));

	checkedexists = CheckExists(namez);
	if checkedexists == false then
		--copy
		for i=hs,1, -1 do
		Historys[i][1] = Historys[i-1][1];
		Historys[i][2] = Historys[i-1][2];
		Historys[i][3] = Historys[i-1][3];
		Historys[i][4] = Historys[i-1][4];
		Historys[i][5] = Historys[i-1][5];
		end
		--copy
		Historys[0][1] = namez;
		Historys[0][2] = classz;
		Historys[0][3] = CheckDniwe(s2);
		Historys[0][4] = CheckDniwe(s3);
		Historys[0][5] = CheckDniwe(solo);

		for i=hs,0, -1 do
			result3[i][1] = "("..i..")|cff00FF96 2s:|r |cffff0000"..Historys[i][3].."|r |cff00FF963s:|r |cffff0000"..Historys[i][4].."|r |cff00FF96SQ:|r |cffff0000"..Historys[i][5].."|cff000000 "..Historys[i][1].."|r ".."|r|n";
		end
		local final = "";
		--final = result3[0][1]..result3[1][1]..result3[2][1]..result3[3][1]..result3[4][1]..result3[5][1]..result3[6][1]..result3[7][1]..result3[8][1]..result3[9][1]..result3[10][1]..result3[11][1]..result3[12][1]..result3[13][1]..result3[hs][1];
		for i=hs,0, -1 do
			final = strjoin("",result3[i][1],final);
		end
		txt2:SetText(final);
	end
end

function GetRawResultsz()
rawresultsz = {PrintExpx(370),PrintExpx(595),PrintExpx(596)}
return rawresultsz;
end

function GetResultsz()
rr = GetRawResultsz();
resultsz = "|cff00FF962v2: |r|cffff0000"..rr[1].."|r|n|cff00FF963v3: |r|cffff0000"..rr[2].."|r|n|cff00FF96Solo: |r|cffff0000"..rr[3].."|r"; 
reports = {rr[1], rr[2], rr[3]}
return resultsz;
end

-- function ExpShow:PLAYER_TARGET_CHANGED()
-- print(GetExpx(370));
-- end

-- 2v2 - 370
-- 3v3 - 595