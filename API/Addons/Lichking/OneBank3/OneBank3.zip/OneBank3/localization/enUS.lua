local L = LibStub("AceLocale-3.0"):NewLocale("OneBank3", "enUS", true, true)

--@non-debug@
L["Bank Bag"] = true
L["Fifth Bank Bag"] = true
L["First Bank Bag"] = true
L["Fourth Bank Bag"] = true
L["Second Bank Bag"] = true
L["Seventh Bank Bag"] = true
L["Sixth Bank Bag"] = true
L["Specific Bag Filters"] = true
L["%s's Bank Bags"] = true
L["Third Bank Bag"] = true
L["Toggles the display of your Fifth Bank Bag."] = true
L["Toggles the display of your First Bank Bag."] = true
L["Toggles the display of your Fourth Bank Bag."] = true
L["Toggles the display of your Second Bank Bag."] = true
L["Toggles the display of your Seventh Bank Bag."] = true
L["Toggles the display of your Sixth Bank Bag."] = true
L["Toggles the display of your Third Bank Bag."] = true

--@end-non-debug@
                                                                                              