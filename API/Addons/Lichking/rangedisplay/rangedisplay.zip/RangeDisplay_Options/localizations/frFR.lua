-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/range-display/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("RangeDisplay_Options", "frFR")
if not L then return end

L["Anchor to Mouse"] = "Accrocher à la souris"
L["Auto adjust"] = "Ajustement auto."
L["Auto hide"] = "Cacher auto."
L["Background Color"] = "Couleur du fond"
L["Background Texture"] = "Texture de fond"
L["Border Color"] = "Couleur de la bordure"
L["Border Texture"] = "Texture de la bordure"
L["Border Thickness"] = "Épaisseur de la bordure"
L["Color"] = "Couleur"
L["Enabled"] = "Activé"
L["Enemy only"] = "Ennemis seulement"
L["Font"] = "Police"
L["Font outline"] = "Epaisseur de police"
L["Font size"] = "Taille de police"
L["Frame's background color"] = "Couleur du fond de la frame"
L["Frame's border color"] = "Couleur de la bordure de la frame"
L["Frame strata"] = "Profondeur de la fenêtre"
L["Height"] = "Hauteur"
L["High"] = "Au dessus"
L["Locked"] = "Vérouillé"
L["Lock/Unlock display frame"] = "(Dé)Vérouille la fenêtre"
L["Low"] = "En dessous"
L["Medium"] = "Normal"
L["Mute"] = "Muet"
L["None"] = "Aucun"
L["Normal"] = "Normal"
L["Show range for enemy targets only"] = "Affiche la portée pour les ennemis seulement"
L["Show the maximum range only"] = "Montrer seulement la distance maximum"
L["Strata"] = "Profondeur"
L["Suffix"] = "Suffixe"
L["Text"] = "Texte"
L["The thickness of the border"] = "L'épaisseur de la bordure"
L["Thick"] = "Epais"
L["Toggle sound"] = "Activer/désactiver le son"
L["Warning Sound"] = "Son d'alerte"
L["Width"] = "Largeur"

