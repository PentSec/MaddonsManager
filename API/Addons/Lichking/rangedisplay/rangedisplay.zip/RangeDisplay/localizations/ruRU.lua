-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/range-display/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("RangeDisplay", "ruRU")
if not L then return end

L["|cffeda55fControl + Left Click|r to lock frames"] = "|cffeda55f[Control + Левый клик]|r фиксирует фрейм"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55f[Двигайте]|r для перемещения окна"
L["|cffeda55fLeft Click|r to lock/unlock frames"] = "|cffeda55f[Левый клик]|r фиксирует/освобождает фреймы"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55f[Правый клик]|r открывает окно настроек"
L["focus"] = "Фокус"
L["pet"] = "Питомец"
L["playertarget"] = "Цель"

