-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/range-display/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("RangeDisplay", "koKR")
if not L then return end

L["|cffeda55fControl + Left Click|r to lock frames"] = "|cffeda55fCtrl + 좌 클릭|r 창 잠금"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55f드래그|r 창 이동"
L["|cffeda55fLeft Click|r to lock/unlock frames"] = "|cffeda55f좌 클릭|r 창 잠금/이동"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55f우 클릭|r 설정 창 열기"
L["focus"] = "주시"
L["mouseover"] = "마우스를 올려 놓았을 때"
L["pet"] = "소환수"
L["playertarget"] = "대상"

