-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/range-display/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("RangeDisplay", "esES")
if not L then return end

L["|cffeda55fControl + Left Click|r to lock frames"] = " |cffeda55fControl + Clic Izquierdo|r para bloquear los marcos"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55fArrastrar|r para mover el marco"
L["|cffeda55fLeft Click|r to lock/unlock frames"] = " |cffeda55fClic Izquierdo|r para bloquear/desbloquear los marcos"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55fClic Derecho|r para abrir la ventana de configuración"
L["focus"] = "Foco"
L["pet"] = "Mascota"
L["playertarget"] = "Objetivo"

