-- Translate RCLootCouncil to your language at:
-- http://wow.curseforge.com/addons/rclootcouncil/localization/

local L = LibStub("AceLocale-3.0"):NewLocale("RCLootCouncil", "koKR")
if not L then return end

--@localization(locale="koKR", format="lua_additive_table", escape-non-ascii=true, same-key-is-true=true)@
