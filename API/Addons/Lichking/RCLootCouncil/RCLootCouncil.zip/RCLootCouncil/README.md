# RcLootCouncil-3.3.5a
RcLootCouncil for WotLK 3.3.5a

Latest version can always be downloaded with [THIS](https://github.com/broizter/RcLootCouncil-3.3.5a/releases/latest/download/RCLootCouncil.zip) link.
