**Current behaviour**: Tell me what happens in detail (Where, When, What, Why, Who)

**Expected behaviour**: Tell me what should happen instead

**Steps to reproduce the problem**:

1. 
2. 
3. 

**Include the ID for the npcs, items, quests, zones, instances**

You can research this on several pages like https://wowgaming.altervista.org/aowow/ or https://wowhead.com/

**Include Screenshots from the issue if necessary**