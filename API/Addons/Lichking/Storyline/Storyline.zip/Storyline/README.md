# WotLK-Storyline

**Backport of Storyline addon for WotLK 3.3.5a**

* <a href="https://github.com/shadovvs/WotLK-Storyline/releases">Releases</a>
* <a href="https://github.com/shadovvs/WotLK-Storyline/issues">Bug tracker</a>

Quest rewards:
<p align="left">
  <img width="60%" height="60%" src="http://i.imgur.com/CLbsZjH.jpg">
</p>

Quest in progress:
<p align="left">
  <img width="60%" height="60%" src="http://i.imgur.com/qJLSrsT.jpg">
</p>

Class trainer:
<p align="left">
  <img width="60%" height="60%" src="http://i.imgur.com/BkRHVPt.jpg">
</p>


Cataclysm version backported by Lanrutcon <br/>
https://community.atlantiss.eu/index.php?/topic/6137-backport-storyline/ <br/>
https://github.com/Lanrutcon/Backport-Storyline

WoD version (v1.1.1) created by EllypseCelweBelore and Kajisensei <br/>
https://wow.curseforge.com/addons/total-rp-3-storyline/
