--[[
Producer - a framework for World of Warcraft professions

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to:
	
Free Software Foundation, I.,
51 Franklin Street, Fifth Floor,
Boston, MA  02110-1301, USA.
--]]

local AL = LibStub('AceLocale-3.0')

do
	local L = AL:NewLocale('ProducerDefault', 'enUS', true)
	L['Alchemy'] = true
	L['Ammo Pouches'] = true
	L['Armor Enchantment'] = true
	L['Bags'] = true
	L['Bandages'] = true
	L['Blacksmithing'] = true
	L['Bullets'] = true
	L['Cloth Armor'] = true
	L['Cloth'] = true
	L['Coining'] = true
	L['Consumable'] = true
	L['Dagger'] = true
	L['Devices'] = true
	L['Elemental'] = true
	L['Elixir'] = true
	L['Embroidery'] = true
	L['Enchant'] = true
	L['Enchanting'] = true
	L['Explosive'] = true
	L['Fist Weapon'] = true
	L['Flask'] = true
	L['Food & Drinks'] = true
	L['Gem'] = true
	L['Gem Blue'] = true
	L['Gem Green'] = true
	L['Gem Meta'] = true
	L['Gem Orange'] = true
	L['Gem Purple'] = true
	L['Gem Red'] = true
	L['Gem Yellow'] = true
	L['Glyph Death Knight'] = true
	L['Glyph Druid'] = true
	L['Glyph Hunter'] = true
	L['Glyph Mage'] = true
	L['Glyph Paladin'] = true
	L['Glyph Priest'] = true
	L['Glyph Rogue'] = true
	L['Glyph Shaman'] = true
	L['Glyph Warlock'] = true
	L['Glyph Warrior'] = true
	L['Guns'] = true
	L['Holiday'] = true
	L['Inscribe'] = true
	L['Item Enhancement'] = true
	L['Jewelcrafting'] = true
	L['Junk'] = true
	L['Leather Armor'] = true
	L['Leather'] = true
	L['Mail Armor'] = true
	L['Metal & Stone'] = true
	L['Miscellaneous'] = true
	L['Mount'] = true
	L['One-Handed Axe'] = true
	L['One-Handed Mace'] = true
	L['One-Handed Sword'] = true
	L['Other'] = true
	L['Parts'] = true
	L['Plate Armor'] = true
	L['Polearm'] = true
	L['Potion'] = true
	L['Prismatic'] = true
	L['Quest'] = true
	L['Quiver'] = true
	L['Rework'] = true
	L['Scroll'] = true
	L['Shield'] = true
	L['Thrown'] = true
	L['Tinker'] = true
	L['Two-Handed Axe'] = true
	L['Two-Handed Mace'] = true
	L['Two-Handed Sword'] = true
	L['Wand'] = true
	L['Weapon Enchantment'] = true

	L['Default'] = true
end

do
	local L = AL:NewLocale('ProducerDefault', 'deDE')
	if L then 
		L['Alchemy'] = 'Alchemie'
		L['Ammo Pouches'] = 'Munitionsbeutel'
		L['Armor Enchantment'] = 'Rüstungsverzauberung'
		L['Bags'] = 'Behälter'
		L['Bandages'] = 'Verband'
		L['Blacksmithing'] = 'Schmiedekunst'
		L['Bullets'] = 'Kugeln'
		L['Cloth Armor'] = 'Stoffrüstung'
		L['Cloth'] = 'Stoff'
		L['Coining'] = 'Prägen'
		L['Consumable'] = 'Verbrauchbar'
		L['Dagger'] = 'Dolch'
		L['Devices'] = 'Geräte'
		L['Elemental'] = 'Elementar'
		L['Elixir'] = 'Elixier'
		L['Embroidery'] = 'Besticken'
		L['Enchant'] = 'Verzauberung'
		L['Enchanting'] = 'Verzauberkunst'
		L['Explosive'] = 'Sprengstoff'
		L['Fist Weapon'] = 'Fauswaffe'
		L['Flask'] = 'Fläschchen'
		L['Food & Drinks'] = 'Essen & Drinken'
		L['Gem'] = 'Juwel'
		L['Gem Blue'] = 'Juwel Blau'
		L['Gem Green'] = 'Juwel Grün'
		L['Gem Meta'] = 'Juwel Meta'
		L['Gem Orange'] = 'Juwel Orange'
		L['Gem Purple'] = 'Juwel Violett'
		L['Gem Red'] = 'Juwel Rot'
		L['Gem Yellow'] = 'Juwel Gelb'
		L['Glyph Death Knight'] = 'Glyphe Todesritter'
		L['Glyph Druid'] = 'Glyphe Druiden'
		L['Glyph Hunter'] = 'Glyphe Jäger'
		L['Glyph Mage'] = 'Glyphe Magier'
		L['Glyph Paladin'] = 'Glyphe Paladin'
		L['Glyph Priest'] = 'Glyphe Priester'
		L['Glyph Rogue'] = 'Glyphe Schurken'
		L['Glyph Shaman'] = 'Glyphe Schamanen'
		L['Glyph Warlock'] = 'Glyphe Hexenmeister'
		L['Glyph Warrior'] = 'Glyphe Krieger'
		L['Guns'] = 'Schusswaffen'
		L['Holiday'] = 'Festtag'
		L['Inscribe'] = 'Beschriften'
		L['Item Enhancement'] = 'Gegenstandsverbesserung'
		L['Jewelcrafting'] = 'Juwelenschleifen'
		L['Junk'] = 'Plunder'
		L['Leather Armor'] = 'Lederrüstung'
		L['Leather'] = 'Leder'
		L['Mail Armor'] = 'Schwere Rüstung'
		L['Metal & Stone'] = 'Metall & Stein'
		L['Miscellaneous'] = 'Verschiedenes'
		L['Mount'] = 'Reittier'
		L['One-Handed Axe'] = 'Einhandaxt'
		L['One-Handed Mace'] = 'Einhandstreitkolben'
		L['One-Handed Sword'] = 'Einhandschwert'
		L['Other'] = 'Sonstiges '
		L['Parts'] = 'Teile'
		L['Plate Armor'] = 'Platte'
		L['Polearm'] = 'Stangenwaffe'
		L['Potion'] = 'Trank'
		L['Prismatic'] = 'Prismatisch'
		L['Quest'] = 'Quest'
		L['Quiver'] = 'Köcher'
		L['Rework'] = 'Umarbeiten'
		L['Scroll'] = 'Rolle'
		L['Shield'] = 'Schild'
		L['Thrown'] = 'Wurfwaffe'
		L['Tinker'] = 'Basteln'
		L['Two-Handed Axe'] = 'Zweihandaxt'
		L['Two-Handed Mace'] = 'Zweihandstreitkolben'
		L['Two-Handed Sword'] = 'Zweihandschwert'
		L['Wand'] = 'Zauberstab'
		L['Weapon Enchantment'] = 'Waffenverzauberung'

--		L['Default'] = 'Vorgabe'
	end
end

do
	local L = AL:NewLocale('ProducerDefault', 'frFR') -- I need help on this translation
	if L then 
		-- Translated by Pettigrow, roumf
		L["Alchemy"] = "Alchimie"
		L["Ammo Pouches"] = "Gibernes de munitions"
		L["Armor Enchantment"] = "Enchantements d'armure"
		L["Bags"] = "Sacs"
		L["Bandages"] = "Bandages"
		L["Blacksmithing"] = "Forge"
		L["Bullets"] = "Balles"
		L["Cloth"] = "Tissu"
		L["Cloth Armor"] = "Armures en tissu"
		L["Coining"] = "Frapper la monnaie"
		L["Consumable"] = "Consommables"
		L["Dagger"] = "Dagues"
		L["Devices"] = "Equipements utilisables"
		L["Elemental"] = "Elémentaire"
		L["Elixir"] = "Élixirs"
		L["Embroidery"] = "Broderie"
		L["Enchant"] = "Enchanter"
		L["Enchanting"] = "Enchantements"
		L["Explosive"] = "Explosif"
		L["Fist Weapon"] = "Armes de pugilat"
		L["Flask"] = "Flacons"
		L["Food & Drinks"] = "Nourritures & boissons"
		L["Gem"] = "Gemmes"
		L["Gem Blue"] = "Gemmes bleue"
		L["Gem Green"] = "Gemmes vertes"
		L["Gem Meta"] = "Méta-gemmes"
		L["Gem Orange"] = "Gemmes oranges"
		L["Gem Purple"] = "Gemmes violettes"
		L["Gem Red"] = "Gemmes rouges"
		L["Gem Yellow"] = "Gemmes jaunes"
		L["Glyph Death Knight"] = "Glyphes de chevalier de la mort"
		L["Glyph Druid"] = "Glyphes de druide"
		L["Glyph Hunter"] = "Glyphes de chasseur"
		L["Glyph Mage"] = "Glyphes de mage"
		L["Glyph Paladin"] = "Glyphes de paladin"
		L["Glyph Priest"] = "Glyphes de prêtre"
		L["Glyph Rogue"] = "Glyphes de voleur"
		L["Glyph Shaman"] = "Glyphes de chaman"
		L["Glyph Warlock"] = "Glyphes de démoniste"
		L["Glyph Warrior"] = "Glyphes de guerrier"
		L["Guns"] = "Armes"
		L["Holiday"] = "Vacances"
		L["Inscribe"] = "Calligraphies"
		L["Item Enhancement"] = "Améliorations d'objet"
		L["Jewelcrafting"] = "Joaillerie"
		L["Junk"] = "Rebut"
		L["Leather"] = "Cuir"
		L["Leather Armor"] = "Armures en cuir"
		L["Mail Armor"] = "Armures en mailles"
		L["Metal & Stone"] = "Métal & pierre"
		L["Miscellaneous"] = "Divers"
		L["Mount"] = "Monture"
		L["One-Handed Axe"] = "Haches à une main"
		L["One-Handed Mace"] = "Masses à une main"
		L["One-Handed Sword"] = "Épées à une main"
		L["Other"] = "Autres"
		L["Parts"] = "Encres"
		L["Plate Armor"] = "Armures en plaques"
		L["Polearm"] = "Arme d'hast"
		L["Potion"] = "Potions"
		L["Prismatic"] = "Prismatiques"
		L["Quest"] = "Quête"
		L["Quiver"] = "Carquois"
		L["Rework"] = "Retravailler"
		L["Scroll"] = "Parchemins"
		L["Shield"] = "Bouclier"
		L["Thrown"] = "Armes de jet"
		L["Tinker"] = "Bricoler"
		L["Two-Handed Axe"] = "Haches à deux mains"
		L["Two-Handed Mace"] = "Masses à deux mains"
		L["Two-Handed Sword"] = "Épées à deux mains"
		L["Wand"] = "Baguettes"
		L["Weapon Enchantment"] = "Enchantements d'arme"

		L["Default"] = "Défaut"
	end
end

do
	local L = AL:NewLocale('ProducerDefault', 'esES') -- I need help on this translation
	if L then 
--		L['Default'] = true
	end
end

do
	local L = AL:NewLocale('ProducerDefault', 'esMX') -- I need help on this translation
	if L then 
	end
end

do
	local L = AL:NewLocale('ProducerDefault', 'ruRU') -- I need help on this translation
	if L then 
	-- Translated by StingerSoft
		L["Alchemy"] = "Алхимия"
		L["Ammo Pouches"] = "Подсумки"
		L["Armor Enchantment"] = "Зачаровывания брони"
		L["Bags"] = "Сумки"
		L["Bandages"] = "Бинты"
		L["Blacksmithing"] = "Кузнечное дело"
		L["Bullets"] = "Пули"
		L["Cloth"] = "Ткань"
		L["Cloth Armor"] = "Тканевые доспехи"
		L["Coining"] = "Монеты"
		L["Consumable"] = "Расходуемые"
		L["Dagger"] = "Кинжалs"
		L["Devices"] = "Устройства"
		L["Elemental"] = "Стихии"
		L["Elixir"] = "Эликсиры"
		L["Embroidery"] = "Вышивка"
		L["Enchant"] = "Чары"
		L["Enchanting"] = "Наложение чар"
		L["Explosive"] = "Взрывчатка"
		L["Fist Weapon"] = "Кистевое"
		L["Flask"] = "Фляги"
		L["Food & Drinks"] = "Еда и напитки"
		L["Gem"] = "Самоцветы"
		L["Gem Blue"] = "Самоцветы: синии"
		L["Gem Green"] = "Самоцветы: зеленые"
		L["Gem Meta"] = "Самоцветы: особые"
		L["Gem Orange"] = "Самоцветы: оранживые"
		L["Gem Purple"] = "Самоцветы: фиолетовые"
		L["Gem Red"] = "Самоцветы: красные"
		L["Gem Yellow"] = "Самоцветы: желтые"
		L["Glyph Death Knight"] = "Символы - Рыцаря смерти"
		L["Glyph Druid"] = "Символы - Друида"
		L["Glyph Hunter"] = "Символы - Охотника"
		L["Glyph Mage"] = "Символы - Мага"
		L["Glyph Paladin"] = "Символы - Паладина"
		L["Glyph Priest"] = "Символы - Жреца"
		L["Glyph Rogue"] = "Символы - Разбойника"
		L["Glyph Shaman"] = "Символы - Шамана"
		L["Glyph Warlock"] = "Символы - Чернокнижника"
		L["Glyph Warrior"] = "Символы - Война"
		L["Guns"] = "Ружья"
		L["Holiday"] = "Праздничные предметы"
		L["Inscribe"] = "Покрытые письменами"
		L["Item Enhancement"] = "Улучшения"
		L["Jewelcrafting"] = "Ювелирное дело"
		L["Junk"] = "Хлам"
		L["Leather"] = "Кожа"
		L["Leather Armor"] = "Кожаные доспехи"
		L["Mail Armor"] = "Кольчужные доспехи"
		L["Metal & Stone"] = "Металл и камни"
		L["Miscellaneous"] = "Разное"
		L["Mount"] = "Транспорт"
		L["One-Handed Axe"] = "Одноручные топоры"
		L["One-Handed Mace"] = "Одноручное дробящее"
		L["One-Handed Sword"] = "Одноручные мечи"
		L["Other"] = "Другое"
		L["Parts"] = "Детали"
		L["Plate Armor"] = "Латные доспехи"
		L["Polearm"] = "Древковое"
		L["Potion"] = "Зелье"
		L["Prismatic"] = "Самоцветы: радужные"
		L["Quest"] = "Задание"
		L["Quiver"] = "Амуниция"
		L["Rework"] = "Переработка"
		L["Scroll"] = "Свитки"
		L["Shield"] = "Щиты"
		L["Thrown"] = "Метательное"
		L["Tinker"] = "Аксессуары"
		L["Two-Handed Axe"] = "Двуручные топоры"
		L["Two-Handed Mace"] = "Двуручное дробящее"
		L["Two-Handed Sword"] = "Двуручные мечи"
		L["Wand"] = "Жезлы"
		L["Weapon Enchantment"] = "Чары для оружия"

		L["Default"] = "По умолчанию"
	end
end

do
	local L = AL:NewLocale('ProducerDefault', 'koKR') -- I need help on this translation
	if L then 
--		L['Default'] = true
	end
end

do
	local L = AL:NewLocale('ProducerDefault', 'zhCN') -- By CWOW二区四组PVE迷雾之海女圣徒
	if L then 
		L['Alchemy'] = "炼金术"
		L['Ammo Pouches'] = "弹药袋"
		L['Armor Enchantment'] = "护甲强化"
		L['Bags'] = "容器"
		L['Bandages'] = "绷带"
		L['Blacksmithing'] = "锻造"
		L['Bullets'] = "子弹"
		L['Cloth Armor'] = "布甲"
		L['Cloth'] = "布料"
		L['Coining'] = "雕饰"
		L['Consumable'] = "消耗品"
		L['Dagger'] = "匕首"
		L['Devices'] = "装置"
		L['Elemental'] = "元素"
		L['Elixir'] = "药剂"
		L['Embroidery'] = "刺绣"
		L['Enchant'] = "附魔"
		L['Enchanting'] = "附魔"
		L['Explosive'] = "爆炸物"
		L['Fist Weapon'] = "拳套"
		L['Flask'] = "合剂"
		L['Food & Drinks'] = "食物和饮料"
		L['Gem'] = "多彩"
		L['Gem Blue'] = "蓝色"
		L['Gem Green'] = "绿色"
		L['Gem Meta'] = "多彩"
		L['Gem Orange'] = "橙色"
		L['Gem Purple'] = "紫色"
		L['Gem Red'] = "红色"
		L['Gem Yellow'] = "黄色"
		L['Glyph Death Knight'] = "死亡骑士"
		L['Glyph Druid'] = "德鲁伊"
		L['Glyph Hunter'] = "猎人"
		L['Glyph Mage'] = "法师"
		L['Glyph Paladin'] = "圣骑士"
		L['Glyph Priest'] = "牧师"
		L['Glyph Rogue'] = "潜行者"
		L['Glyph Shaman'] = "萨满祭司"
		L['Glyph Warlock'] = "术士"
		L['Glyph Warrior'] = "战士"
		L['Guns'] = "枪械"
		L['Holiday'] = "节日"
		L['Inscribe'] = "铭文"
		L['Item Enhancement'] = "物品强化"
		L['Jewelcrafting'] = "珠宝加工"
		L['Junk'] = "垃圾"
		L['Leather Armor'] = "皮甲"
		L['Leather'] = "皮革"
		L['Mail Armor'] = "锁甲"
		L['Metal & Stone'] = "金属和矿石"
		L['Miscellaneous'] = "其它"
		L['Mount'] = "坐骑"
		L['One-Handed Axe'] = "单手斧"
		L['One-Handed Mace'] = "单手锤"
		L['One-Handed Sword'] = "单手剑"
		L['Other'] = "其它"
		L['Parts'] = "零件"
		L['Plate Armor'] = "板甲"
		L['Polearm'] = "长柄武器"
		L['Potion'] = "药水"
		L['Prismatic'] = "棱彩"
		L['Quest'] = "任务"
		L['Quiver'] = "箭袋"
		L['Rework'] = "修改"
		L['Scroll'] = "卷轴"
		L['Shield'] = "盾牌"
		L['Thrown'] = "投掷武器"
		L['Tinker'] = "制造"
		L['Two-Handed Axe'] = "双手斧"
		L['Two-Handed Mace'] = "双手锤"
		L['Two-Handed Sword'] = "双手剑"
		L['Wand'] = "魔杖"
		L['Weapon Enchantment'] = "武器强化"
		L['Default'] = "默认"
	end
end

do
	local L = AL:NewLocale('ProducerDefault', 'zhTW') -- I need help on this translation
	if L then 
--		L['Default'] = true
	end
end

local L = AL:GetLocale( 'ProducerDefault')
local Producer = LibStub( 'AceAddon-3.0'):GetAddon( 'Producer')
local mod = Producer:NewModule( L['Default'])

-- Producer.Default.Alchemy
mod:RegisterSelection( 'Alchemy', function()
	mod:AddData( 'Alchemy', L['Alchemy'],                        '-60893')
	mod:AddData( 'Alchemy', L['Elemental'],                      '-53784,-53783,-53782,-53781,-53780,-53779,-53777,-53776,-53775,-53774,-53773,-53771,-29688,-28585,-28584,-28583,-28582,-28581,-28580,-28569,-28568,-28567,-28566,-25146,-17566,-17565,-17564,-17563,-17562,-17561,-17560,-17559')
	mod:AddData( 'Alchemy', L['Elixir'],                         '-63732,-62410,-60367,-60366,-60365,-60357,-60356,-60355,-60354,-56519,-54220,-54218,-53898,-53848,-53847,-53842,-53841,-53840,-39639,-39638,-39637,-39636,-38960,-33741,-33740,-33738,-28578,-28570,-28558,-28557,-28556,-28553,-28552,-28549,-28545,-28544,-28543,-26277,-24368,-24365,-22808,-21923,-17573,-17571,-17557,-17555,-17554,-12609,-11478,-11477,-11476,-11472,-11468,-11467,-11466,-11465,-11461,-11460,-11450,-11449,-8240,-7845,-7183,-7179,-3453,-3451,-3450,-3230,-3188,-3177,-3176,-3171,-3170,-2334,-2333,-2329')
	mod:AddData( 'Alchemy', L['Flask'],                          '-67025,-62213,-54213,-53903,-53902,-53901,-53899,-42736,-28591,-28590,-28589,-28588,-28587,-17638,-17637,-17636,-17635')
	mod:AddData( 'Alchemy', L['Gem'],                            '-66664,-66663,-66662,-66660,-66659,-66658,-57427,-57425,-32766,-32765')
	mod:AddData( 'Alchemy', L['Metal & Stone'],                  '-60350,-17187,-11480,-11479')
	mod:AddData( 'Alchemy', L['Miscellaneous'],                  '-60405,-60403,-60396,-47050,-47049,-47048,-47046,-38070,-17632,-11459')
	mod:AddData( 'Alchemy', L['Other'],                          '-62409,-53812,-41503,-41502,-41501,-41500,-41458,-17551,-11473,-11451,-7837,-7836,-3454,-3449')
	mod:AddData( 'Alchemy', L['Parts'],                          '-11456')
	mod:AddData( 'Alchemy', L['Potion'],                         '-58871,-58868,-54222,-54221,-53942,-53939,-53938,-53937,-53936,-53905,-53904,-53900,-53895,-53839,-53838,-53837,-53836,-45061,-38962,-38961,-33733,-33732,-28586,-28579,-28577,-28576,-28575,-28573,-28572,-28571,-28565,-28564,-28563,-28562,-28555,-28554,-28551,-28550,-28546,-24367,-24366,-22732,-17634,-17580,-17578,-17577,-17576,-17575,-17574,-17572,-17570,-17556,-17553,-17552,-15833,-11464,-11458,-11457,-11453,-11452,-11448,-7841,-7259,-7258,-7257,-7256,-7255,-7181,-6624,-6618,-6617,-4942,-4508,-3452,-3448,-3447,-3175,-3174,-3173,-3172,-2337,-2335,-2332,-2331,-2330')
	mod:AddData( 'Alchemy', L['Quest'],                          '-24266')
end)

-- Producer.Default.Blacksmithing
mod:RegisterSelection( 'Blacksmithing', function()
	mod:AddData( 'Blacksmithing', L['Dagger'],                   '-63182,-56234,-55181,-55179,-29699,-29698,-29569,-23638,-16995,-15973,-15972,-10013,-8880,-6517,-3491,-3295')
	mod:AddData( 'Blacksmithing', L['Enchanting'],               '-55732,-32657,-32656,-32655,-20201,-14380,-14379,-7818')
	mod:AddData( 'Blacksmithing', L['Item Enhancement'],         '-62202,-56357,-55839,-55656,-42688,-29657,-16651,-9964,-9939,-7224,-7222,-7221')
	mod:AddData( 'Blacksmithing', L['Mail Armor'],               '-36256,-36130,-36124,-34530,-34529,-29663,-29658,-29649,-29648,-29556,-29553,-29552,-29551,-27590,-27589,-27588,-24138,-24137,-24136,-23629,-23628,-20873,-20872,-16746,-16728,-16725,-16661,-16659,-16656,-16654,-16650,-16648,-16645,-15293,-12260,-12259,-11643,-9966,-9961,-9957,-9937,-9931,-9916,-9820,-9818,-9814,-9813,-9811,-8367,-7817,-7223,-3515,-3513,-3511,-3508,-3507,-3506,-3505,-3504,-3503,-3502,-3501,-3336,-3334,-3333,-3331,-3330,-3328,-3325,-3324,-3323,-3321,-3319,-2675,-2673,-2672,-2670,-2668,-2667,-2666,-2664,-2663,-2662,-2661')
	mod:AddData( 'Blacksmithing', L['Metal & Stone'],            '-16639,-9920,-3337,-3326,-3320')
	mod:AddData( 'Blacksmithing', L['One-Handed Axe'],           '-55204,-36260,-36134,-36126,-34542,-34541,-29694,-29557,-21913,-20897,-16991,-16970,-16969,-9995,-9993,-3294,-2741,-2738')
	mod:AddData( 'Blacksmithing', L['One-Handed Mace'],          '-56280,-55371,-55370,-55201,-55182,-36262,-36136,-36128,-34546,-34545,-29700,-29696,-29558,-27830,-23650,-16993,-16984,-16983,-10009,-10003,-10001,-6518,-3297,-3296,-2740,-2737')
	mod:AddData( 'Blacksmithing', L['One-Handed Sword'],         '-59442,-55200,-55184,-55183,-55177,-43549,-36258,-36131,-36125,-34537,-34535,-29692,-29571,-27832,-23652,-20890,-16992,-16978,-10007,-10005,-9997,-3493,-3492,-2742,-2739')
	mod:AddData( 'Blacksmithing', L['Other'],                    '-59406,-59405,-34608,-34607,-32285,-32284,-29729,-29728,-29656,-29654,-22757,-19669,-19668,-19667,-19666,-16641,-16640,-9921,-9918,-3117,-3116,-3115,-2674,-2665,-2660')
	mod:AddData( 'Blacksmithing', L['Parts'],                    '-11454,-8768')
	mod:AddData( 'Blacksmithing', L['Plate Armor'],              '-70568,-70567,-70566,-70565,-70563,-70562,-67135,-67134,-67133,-67132,-67131,-67130,-67096,-67095,-67094,-67093,-67092,-67091,-63192,-63191,-63190,-63189,-63188,-63187,-61010,-61009,-61008,-59441,-59440,-59438,-59436,-56556,-56555,-56554,-56553,-56552,-56551,-56550,-56549,-55835,-55834,-55377,-55376,-55375,-55374,-55373,-55372,-55312,-55311,-55310,-55309,-55308,-55307,-55306,-55305,-55304,-55303,-55302,-55301,-55300,-55298,-55187,-55186,-55058,-55057,-55056,-55055,-55017,-55015,-54981,-54980,-54979,-54978,-54949,-54948,-54947,-54946,-54945,-54944,-54941,-54918,-54917,-54556,-54555,-54554,-54553,-54552,-54551,-52572,-52571,-52570,-52569,-52568,-52567,-46144,-46142,-46141,-46140,-42662,-41135,-41134,-41133,-41132,-40036,-40035,-40034,-40033,-38479,-38478,-38477,-38476,-38475,-38473,-36392,-36391,-36390,-36389,-36257,-36129,-36122,-34534,-34533,-29672,-29671,-29669,-29668,-29664,-29662,-29645,-29643,-29642,-29630,-29629,-29628,-29622,-29621,-29620,-29619,-29617,-29616,-29615,-29614,-29613,-29611,-29610,-29608,-29606,-29605,-29603,-29550,-29549,-29548,-29547,-29545,-28463,-28462,-28461,-28244,-28243,-28242,-27829,-27587,-27585,-24914,-24913,-24912,-24399,-24141,-24140,-24139,-23637,-23636,-23633,-23632,-20876,-20874,-16745,-16744,-16742,-16741,-16732,-16731,-16730,-16729,-16726,-16724,-16667,-16665,-16664,-16663,-16662,-16660,-16658,-16657,-16655,-16653,-16652,-16649,-16647,-16646,-16644,-16643,-16642,-15296,-15295,-9980,-9979,-9974,-9972,-9970,-9968,-9959,-9954,-9952,-9950,-9945,-9935,-9933,-9928,-9926')
	mod:AddData( 'Blacksmithing', L['Polearm'],                  '-23639,-10011')
	mod:AddData( 'Blacksmithing', L['Rework'],                   '-55641,-55628')
	mod:AddData( 'Blacksmithing', L['Shield'],                   '-56400,-55014,-55013,-54557,-54550,-27586')
	mod:AddData( 'Blacksmithing', L['Thrown'],                   '-55206,-55202,-34983,-34982,-34981,-34979')
	mod:AddData( 'Blacksmithing', L['Two-Handed Axe'],           '-55174,-36261,-36135,-34544,-34543,-29695,-29568,-23653,-16994,-16971,-15294,-9987,-3500,-3498,-3293')
	mod:AddData( 'Blacksmithing', L['Two-Handed Mace'],          '-55369,-55185,-43846,-36263,-36137,-34548,-34547,-29697,-29566,-21161,-16988,-16973,-15292,-9985,-7408,-3495,-3494')
	mod:AddData( 'Blacksmithing', L['Two-Handed Sword'],         '-55203,-36259,-36133,-34540,-34538,-29693,-29565,-16990,-16985,-10015,-9986,-9983,-3497,-3496,-3292')
end)

-- Producer.Default.Cooking
mod:RegisterSelection( 'Cooking', function()
	mod:AddData( 'Cooking', L['Food & Drinks'],                  '-66038,-66037,-66036,-66035,-66034,-65454,-64358,-64054,-62350,-62051,-62050,-62049,-62045,-62044,-58528,-58527,-58525,-58523,-58521,-58512,-58065,-57443,-57442,-57441,-57440,-57439,-57438,-57437,-57436,-57435,-57434,-57433,-57423,-57421,-53056,-46688,-46684,-45695,-45571,-45570,-45569,-45568,-45567,-45566,-45565,-45564,-45563,-45562,-45561,-45560,-45559,-45558,-45557,-45556,-45555,-45554,-45553,-45552,-45551,-45550,-45549,-45547,-45022,-44438,-43779,-43772,-43765,-43761,-43758,-43707,-42305,-42302,-42296,-38868,-38867,-37836,-36210,-33296,-33295,-33294,-33293,-33292,-33291,-33290,-33289,-33288,-33287,-33286,-33285,-33284,-33279,-33278,-33277,-33276,-28267,-25954,-25704,-25659,-24801,-24418,-22761,-22480,-21175,-21144,-21143,-20916,-20626,-18247,-18246,-18245,-18244,-18243,-18242,-18241,-18240,-18239,-18238,-15935,-15933,-15915,-15910,-15906,-15865,-15863,-15861,-15856,-15855,-15853,-13028,-9513,-8607,-8604,-8238,-7828,-7827,-7755,-7754,-7753,-7752,-7751,-7213,-6501,-6500,-6499,-6419,-6418,-6417,-6416,-6415,-6414,-6413,-6412,-4094,-3400,-3399,-3398,-3397,-3377,-3376,-3373,-3372,-3371,-3370,-2795,-2549,-2548,-2547,-2546,-2545,-2544,-2543,-2542,-2541,-2540,-2539,-2538')
end)

-- Producer.Default.Enchanting
mod:RegisterSelection( 'Enchanting', function()
	mod:AddData( 'Enchanting', L['Enchant'],                     '-71692,-64579,-64441,-63746,-62959,-62948,-62257,-62256,-60767,-60763,-60714,-60707,-60692,-60691,-60668,-60663,-60653,-60623,-60621,-60616,-60609,-60606,-59636,-59625,-59621,-59619,-47901,-47900,-47899,-47898,-47766,-47672,-47051,-46594,-46578,-44645,-44636,-44635,-44633,-44631,-44630,-44629,-44625,-44623,-44621,-44616,-44612,-44598,-44596,-44595,-44593,-44592,-44591,-44590,-44589,-44588,-44584,-44582,-44576,-44575,-44529,-44528,-44524,-44513,-44510,-44509,-44508,-44506,-44500,-44494,-44492,-44489,-44488,-44484,-44483,-44383,-42974,-42620,-34010,-34009,-34008,-34007,-34006,-34005,-34004,-34003,-34002,-34001,-33999,-33997,-33996,-33995,-33994,-33993,-33992,-33991,-33990,-28004,-28003,-27984,-27982,-27981,-27977,-27975,-27972,-27971,-27968,-27967,-27962,-27961,-27960,-27958,-27957,-27954,-27951,-27950,-27948,-27947,-27946,-27945,-27944,-27927,-27926,-27924,-27920,-27917,-27914,-27913,-27911,-27906,-27905,-27899,-27837,-25086,-25084,-25083,-25082,-25081,-25080,-25079,-25078,-25074,-25073,-25072,-23804,-23803,-23802,-23801,-23800,-23799,-22750,-22749,-21931,-20036,-20035,-20034,-20033,-20032,-20031,-20030,-20029,-20028,-20026,-20025,-20024,-20023,-20020,-20017,-20016,-20015,-20014,-20013,-20012,-20011,-20010,-20009,-20008,-13948,-13947,-13945,-13943,-13941,-13939,-13937,-13935,-13933,-13931,-13917,-13915,-13905,-13898,-13890,-13887,-13882,-13868,-13858,-13846,-13841,-13836,-13822,-13817,-13815,-13794,-13746,-13700,-13698,-13695,-13693,-13689,-13687,-13663,-13661,-13659,-13657,-13655,-13653,-13648,-13646,-13644,-13642,-13640,-13637,-13635,-13631,-13626,-13622,-13620,-13617,-13612,-13607,-13538,-13536,-13529,-13522,-13503,-13501,-13485,-13464,-13421,-13419,-13380,-13378,-7867,-7863,-7861,-7859,-7857,-7793,-7788,-7786,-7782,-7779,-7776,-7771,-7766,-7748,-7745,-7457,-7454,-7443,-7428,-7426,-7420,-7418')
	mod:AddData( 'Enchanting', L['Enchanting'],                  '-69412,-60619,-45765,-42615,-42613,-32667,-32665,-32664,-28022,-28019,-28016,-25130,-25129,-25128,-25127,-25126,-25125,-25124,-20051,-13702,-13628,-7795,-7421')
	mod:AddData( 'Enchanting', L['Leather'],                     '-17181')
	mod:AddData( 'Enchanting', L['Metal & Stone'],               '-17180')
	mod:AddData( 'Enchanting', L['Other'],                       '-15596')
	mod:AddData( 'Enchanting', L['Prismatic'],                   '-28028,-28027')
	mod:AddData( 'Enchanting', L['Wand'],                        '-14810,-14809,-14807,-14293')
end)

-- Producer.Default.Engineering
mod:RegisterSelection( 'Engineering', function()
	mod:AddData( 'Engineering', L['Bags'],                       '-30349,-30348')
	mod:AddData( 'Engineering', L['Blacksmithing'],              '-12895')
	mod:AddData( 'Engineering', L['Bullets'],                    '-72952,-56474,-30346,-19800,-12621,-12596,-3947,-3930,-3920')
	mod:AddData( 'Engineering', L['Cloth Armor'],                '-56484,-56465,-46697,-46111,-46108,-41321,-41320,-30574,-30570,-30565,-30318,-30317,-24356,-19825,-19794,-12907,-12905,-12897,-12758,-12718,-12622,-12618,-12617,-12616,-12615,-12607,-12594,-12587,-8895,-3966,-3956,-3940,-3934')
	mod:AddData( 'Engineering', L['Devices'],                    '-68067,-67326,-63770,-63765,-61471,-56478,-56477,-56476,-56472,-56470,-56463,-56462,-56461,-56459,-55252,-44391,-30573,-30561,-30549,-30548,-30337,-30334,-30332,-30329,-28327,-23129,-23096,-23078,-22793,-22704,-21940,-19814,-19567,-15255,-12620,-12597,-9273,-9271,-6458,-3979,-3978,-3977,-3968,-3965,-3963,-3960,-3959,-3957,-3955,-3944,-3932')
	mod:AddData( 'Engineering', L['Explosive'],                  '-56514,-56468,-56460,-39973,-30568,-30560,-30558,-30547,-30311,-30310,-23080,-23070,-23069,-19831,-19799,-19790,-12760,-12754,-12619,-12603,-12586,-8339,-8243,-3972,-3967,-3962,-3950,-3946,-3941,-3937,-3933,-3931,-3923,-3919')
	mod:AddData( 'Engineering', L['Guns'],                       '-60874,-56479,-54353,-41307,-30315,-30314,-30313,-30312,-22795,-19833,-19796,-19792,-12614,-12595,-3954,-3949,-3939,-3936,-3925')
	mod:AddData( 'Engineering', L['Holiday'],                    '-26443,-26442,-26428,-26427,-26426,-26425,-26424,-26423,-26422,-26421,-26420,-26418,-26417,-26416,-12715')
	mod:AddData( 'Engineering', L['Junk'],                       '-8334')
	mod:AddData( 'Engineering', L['Leather Armor'],              '-61481,-56486,-56481,-46116,-46109,-46106,-41319,-41318,-41317,-30575,-30556,-30325,-30316,-24357,-12903')
	mod:AddData( 'Engineering', L['Mail Armor'],                 '-61482,-56574,-56487,-46113,-46112,-46110,-41316,-41315,-41314,-30566,-12717')
	mod:AddData( 'Engineering', L['Miscellaneous'],              '-72953,-67920,-67790,-63750,-56475,-56473,-56469,-56467,-56466,-36955,-36954,-30569,-30563,-23489,-23486,-23082,-23081,-23079,-23077,-19830,-13240,-12908,-12906,-12902,-12899,-12759,-12755,-12716,-12624,-9269,-7430,-3971,-3969,-3952')
	mod:AddData( 'Engineering', L['Mount'],                      '-60867,-60866,-44157,-44155')
	mod:AddData( 'Engineering', L['Other'],                      '-43676,-32814,-30347,-30344,-30342,-30341,-26011,-23507,-23068,-23067,-23066,-19819,-19793,-15633,-15628,-3928')
	mod:AddData( 'Engineering', L['Parts'],                      '-56471,-56464,-56349,-53281,-39971,-39895,-30309,-30308,-30307,-30306,-30305,-30304,-30303,-23071,-19815,-19795,-19791,-19788,-12599,-12591,-12590,-12589,-12585,-12584,-3973,-3961,-3958,-3953,-3945,-3942,-3938,-3929,-3926,-3924,-3922,-3918')
	mod:AddData( 'Engineering', L['Plate Armor'],                '-62271,-61483,-56483,-56480,-46115,-46114,-46107,-41312,-41311,-40274')
	mod:AddData( 'Engineering', L['Potion'],                     '-30552,-30551')
	mod:AddData( 'Engineering', L['Shield'],                     '-22797')
	mod:AddData( 'Engineering', L['Tinker'],                     '-67839,-55016,-55002,-54999,-54998,-54793,-54736')
end)

-- Producer.Default.First Aid
mod:RegisterSelection( 'First Aid', function()
	mod:AddData( 'First Aid', L['Bandages'],                     '-45546,-45545,-27033,-27032,-18630,-18629,-10841,-10840,-7929,-7928,-3278,-3277,-3276,-3275')
	mod:AddData( 'First Aid', L['Other'],                        '-23787,-7935,-7934')
end)

-- Producer.Default.Inscription
mod:RegisterSelection( 'Inscription', function()
	mod:AddData( 'Inscription', L['Enchanting'],                 '-59501,-59500,-59499,-59488,-52840,-52739')
	mod:AddData( 'Inscription', L['Glyph Death Knight'],         '-64300,-64299,-64298,-64297,-64267,-64266,-59340,-59339,-59338,-57230,-57229,-57228,-57227,-57226,-57225,-57224,-57223,-57222,-57221,-57220,-57219,-57218,-57217,-57216,-57215,-57214,-57213,-57212,-57211,-57210,-57209,-57208,-57207')
	mod:AddData( 'Inscription', L['Glyph Druid'],                '-71015,-67600,-65245,-64313,-64307,-64270,-64268,-64258,-64256,-62162,-59315,-58296,-58289,-58288,-58287,-58286,-56965,-56963,-56961,-56960,-56959,-56958,-56957,-56956,-56955,-56954,-56953,-56952,-56951,-56950,-56949,-56948,-56947,-56946,-56945,-56944,-56943,-48121')
	mod:AddData( 'Inscription', L['Glyph Hunter'],               '-64304,-64273,-64271,-64253,-64249,-64246,-58302,-58301,-58300,-58299,-58298,-58297,-57014,-57013,-57012,-57011,-57010,-57009,-57008,-57007,-57006,-57005,-57004,-57003,-57002,-57001,-57000,-56999,-56998,-56997,-56996,-56995,-56994')
	mod:AddData( 'Inscription', L['Glyph Mage'],                 '-64314,-64276,-64275,-64274,-64257,-61677,-58310,-58308,-58307,-58306,-58305,-58303,-57719,-56991,-56990,-56989,-56988,-56987,-56986,-56985,-56984,-56983,-56982,-56981,-56980,-56979,-56978,-56977,-56976,-56975,-56974,-56973,-56972,-56971,-56968')
	mod:AddData( 'Inscription', L['Glyph Paladin'],              '-64308,-64305,-64279,-64278,-64277,-64254,-64251,-59561,-59560,-59559,-58316,-58315,-58314,-58313,-58312,-58311,-57036,-57035,-57034,-57033,-57032,-57031,-57030,-57029,-57028,-57027,-57026,-57025,-57024,-57023,-57022,-57021,-57020,-57019')
	mod:AddData( 'Inscription', L['Glyph Priest'],               '-64309,-64283,-64282,-64281,-64280,-64259,-58322,-58321,-58320,-58319,-58318,-58317,-57202,-57201,-57200,-57199,-57198,-57197,-57196,-57195,-57194,-57193,-57192,-57191,-57190,-57189,-57188,-57187,-57186,-57185,-57184,-57183,-57181')
	mod:AddData( 'Inscription', L['Glyph Rogue'],                '-64315,-64310,-64303,-64286,-64285,-64284,-64260,-58328,-58327,-58326,-58325,-58324,-58323,-57133,-57132,-57131,-57130,-57129,-57128,-57127,-57126,-57125,-57124,-57123,-57122,-57121,-57120,-57119,-57117,-57116,-57115,-57114,-57113,-57112')
	mod:AddData( 'Inscription', L['Glyph Shaman'],               '-64316,-64289,-64288,-64287,-64262,-64261,-64247,-59326,-58333,-58332,-58331,-58330,-58329,-57253,-57252,-57251,-57250,-57249,-57248,-57247,-57246,-57245,-57244,-57243,-57242,-57241,-57240,-57239,-57238,-57237,-57236,-57235,-57234,-57233,-57232')
	mod:AddData( 'Inscription', L['Glyph Warlock'],              '-71102,-64318,-64317,-64311,-64294,-64291,-64250,-64248,-58341,-58340,-58339,-58338,-58337,-58336,-57277,-57276,-57275,-57274,-57273,-57272,-57271,-57270,-57269,-57268,-57267,-57266,-57265,-57264,-57263,-57262,-57261,-57260,-57259,-57258,-57257')
	mod:AddData( 'Inscription', L['Glyph Warrior'],              '-68166,-64312,-64302,-64296,-64295,-64255,-64252,-58347,-58346,-58345,-58344,-58343,-58342,-57172,-57170,-57169,-57168,-57167,-57166,-57165,-57164,-57163,-57162,-57161,-57160,-57159,-57158,-57157,-57156,-57155,-57154,-57153,-57152,-57151')
	mod:AddData( 'Inscription', L['Inscribe'],                   '-61288,-61177,-61120,-61119,-61118,-61117')
	mod:AddData( 'Inscription', L['Miscellaneous'],              '-64053,-64051,-59498,-59497,-59496,-59495,-59494,-59493,-59490,-59489,-59486,-59484,-59478,-59475,-58565')
	mod:AddData( 'Inscription', L['Other'],                      '-59504,-59503,-59502,-59491,-59487,-59480,-59387,-48247')
	mod:AddData( 'Inscription', L['Parts'],                      '-71101,-57716,-57715,-57714,-57713,-57712,-57711,-57710,-57709,-57708,-57707,-57706,-57704,-57703,-53462,-52843,-52738')
	mod:AddData( 'Inscription', L['Scroll'],                     '-69385,-60337,-60336,-58491,-58490,-58489,-58488,-58487,-58486,-58485,-58484,-58483,-58482,-58481,-58480,-58478,-58476,-58473,-58472,-50620,-50619,-50618,-50617,-50616,-50614,-50612,-50611,-50610,-50609,-50608,-50607,-50606,-50605,-50604,-50603,-50602,-50601,-50600,-50599,-50598,-48248,-48116,-48114,-45382')
end)

-- Producer.Default.Jewelcrafting
mod:RegisterSelection( 'Jewelcrafting', function()
	mod:AddData( 'Jewelcrafting', L['Cloth Armor'],              '-41418,-31078,-31077,-26920,-26906,-26878,-25321')
	mod:AddData( 'Jewelcrafting', L['Consumable'],               '-62242,-47280,-32809,-32808,-32807,-32801,-32259')
	mod:AddData( 'Jewelcrafting', L['Fist Weapon'],              '-25612')
	mod:AddData( 'Jewelcrafting', L['Gem Blue'],                 '-66500,-66499,-66498,-66497,-56088,-56087,-56086,-56077,-53955,-53954,-53953,-53952,-53943,-53941,-53940,-53934,-42590,-39718,-39717,-39716,-39715,-31149,-31095,-31094,-31092,-28957,-28955,-28953,-28950')
	mod:AddData( 'Jewelcrafting', L['Gem Green'],                '-66445,-66444,-66443,-66442,-66441,-66440,-66439,-66438,-66437,-66436,-66435,-66434,-66433,-66432,-66431,-66430,-66429,-66428,-66338,-54014,-54013,-54012,-54011,-54010,-54009,-54008,-54007,-54006,-54005,-54004,-54003,-54002,-54001,-54000,-53998,-53997,-53996,-53995,-53933,-53932,-53931,-53930,-53929,-53928,-53927,-53926,-53925,-53924,-53923,-53922,-53921,-53920,-53919,-53918,-53917,-53916,-53894,-47054,-47053,-46405,-43493,-39742,-39741,-39740,-39739,-31113,-31112,-31111,-31110,-28924,-28918,-28917,-28916')
	mod:AddData( 'Jewelcrafting', L['Gem Meta'],                 '-55407,-55405,-55404,-55403,-55402,-55401,-55400,-55399,-55398,-55397,-55396,-55395,-55394,-55393,-55392,-55390,-55389,-55388,-55387,-55386,-55384,-46601,-46597,-44794,-39963,-39961,-32874,-32873,-32872,-32871,-32870,-32869,-32868,-32867,-32866')
	mod:AddData( 'Jewelcrafting', L['Gem Orange'],               '-66587,-66586,-66585,-66584,-66583,-66582,-66581,-66580,-66579,-66578,-66577,-66576,-66575,-66574,-66573,-66572,-66571,-66570,-66569,-66568,-66567,-66566,-54023,-54019,-53994,-53993,-53992,-53991,-53990,-53989,-53988,-53987,-53986,-53985,-53984,-53983,-53982,-53981,-53980,-53979,-53978,-53977,-53976,-53975,-53893,-53892,-53891,-53890,-53889,-53888,-53887,-53886,-53885,-53884,-53883,-53882,-53881,-53880,-53879,-53878,-53877,-53876,-53875,-53874,-53873,-53872,-47055,-46404,-39738,-39737,-39736,-39735,-39734,-39733,-39471,-39470,-39467,-39466,-31109,-31108,-31107,-31106,-28915,-28914,-28912,-28910')
	mod:AddData( 'Jewelcrafting', L['Gem Purple'],               '-66565,-66564,-66563,-66562,-66561,-66560,-66559,-66558,-66557,-66556,-66555,-66554,-66553,-53974,-53973,-53972,-53971,-53970,-53969,-53968,-53967,-53966,-53965,-53964,-53963,-53962,-53871,-53870,-53869,-53868,-53867,-53866,-53865,-53864,-53863,-53862,-53861,-53860,-53859,-48789,-46803,-41429,-41420,-39732,-39731,-39730,-39729,-39728,-39727,-39463,-39462,-39458,-39455,-31105,-31104,-31103,-31102,-28936,-28933,-28927,-28925')
	mod:AddData( 'Jewelcrafting', L['Gem Red'],                  '-66453,-66452,-66451,-66450,-66449,-66448,-66447,-66446,-56081,-56076,-56056,-56055,-56054,-56053,-56052,-56049,-54017,-53951,-53950,-53949,-53948,-53947,-53946,-53945,-53845,-53844,-53843,-53835,-53834,-53832,-53831,-53830,-42589,-42588,-42558,-39714,-39713,-39712,-39711,-39710,-39706,-39705,-34590,-31091,-31090,-31089,-31088,-31087,-31085,-31084,-28907,-28906,-28905,-28903')
	mod:AddData( 'Jewelcrafting', L['Gem Yellow'],               '-66506,-66505,-66504,-66503,-66502,-66501,-56089,-56085,-56084,-56083,-56079,-56074,-53961,-53960,-53959,-53958,-53957,-53956,-53857,-53856,-53855,-53854,-53853,-53852,-47056,-46403,-42593,-42592,-42591,-39725,-39724,-39723,-39722,-39721,-39720,-39719,-39452,-39451,-34069,-31101,-31100,-31099,-31098,-31097,-31096,-28948,-28947,-28944,-28938')
	mod:AddData( 'Jewelcrafting', L['Jewelcrafting'],            '-38068,-26880,-25615,-25278,-25255')
	mod:AddData( 'Jewelcrafting', L['Miscellaneous'],            '-64728,-64727,-64726,-64725,-63743,-59759,-58954,-58507,-58492,-58150,-58149,-58148,-58147,-58146,-58145,-58144,-58143,-58142,-58141,-56501,-56500,-56499,-56498,-56497,-56496,-56203,-56202,-56201,-56199,-56197,-56196,-56195,-56194,-56193,-46779,-46778,-46777,-46776,-46775,-46127,-46126,-46125,-46124,-46123,-46122,-41415,-41414,-40514,-38504,-38503,-38175,-37855,-37818,-36526,-36525,-36524,-36523,-34961,-34960,-34959,-34955,-32179,-32178,-31083,-31082,-31081,-31080,-31079,-31076,-31072,-31071,-31070,-31068,-31067,-31066,-31065,-31064,-31063,-31062,-31061,-31060,-31058,-31057,-31056,-31055,-31054,-31053,-31052,-31051,-31050,-31049,-31048,-26928,-26927,-26926,-26925,-26918,-26916,-26915,-26914,-26912,-26911,-26910,-26909,-26908,-26907,-26903,-26902,-26900,-26897,-26896,-26887,-26885,-26883,-26882,-26881,-26876,-26875,-26874,-26873,-26872,-25622,-25621,-25620,-25619,-25618,-25617,-25613,-25610,-25498,-25493,-25490,-25339,-25323,-25320,-25318,-25317,-25305,-25287,-25284,-25283,-25280')
	mod:AddData( 'Jewelcrafting', L['Other'],                    '-56208,-56206,-56205')
	mod:AddData( 'Jewelcrafting', L['Prismatic'],                '-68253,-62941,-56531,-56530')
end)

-- Producer.Default.Leatherworking
mod:RegisterSelection( 'Leatherworking', function()
	mod:AddData( 'Leatherworking', L['Ammo Pouches'],            '-60645,-44768,-44343,-14932,-9194,-9062')
	mod:AddData( 'Leatherworking', L['Bags'],                    '-60643,-50971,-50970,-45117,-45100,-35530,-5244')
	mod:AddData( 'Leatherworking', L['Cloth Armor'],             '-60640,-60637,-60631,-55199,-44953,-42546,-22928,-22927,-22926,-19093,-10574,-10562,-9198,-9070,-9058,-7953,-7153,-3760,-2168,-2162,-2159')
	mod:AddData( 'Leatherworking', L['Coining'],                 '-60584,-60583,-57701,-57699,-57696,-57694,-57692,-57691,-57690,-57683')
	mod:AddData( 'Leatherworking', L['Enchant'],                 '-32461')
	mod:AddData( 'Leatherworking', L['Item Enhancement'],        '-62448,-50967,-50966,-50965,-50964,-50963,-50962,-44970,-44770,-35557,-35555,-35554,-35549,-35524,-35523,-35522,-35521,-35520,-32482,-32458,-32457,-32456,-22727,-19058,-10487,-3780,-2165,-2152')
	mod:AddData( 'Leatherworking', L['Leather'],                 '-64661,-50936,-32455,-32454,-22331,-20650,-20649,-20648,-19047,-10482,-3818,-3817,-3816,-2881')
	mod:AddData( 'Leatherworking', L['Leather Armor'],           '-70557,-70556,-70555,-70554,-67142,-67141,-67140,-67139,-67087,-67086,-67085,-67084,-63201,-63200,-63199,-63198,-62177,-62176,-60998,-60997,-60996,-60761,-60760,-60759,-60758,-60727,-60725,-60723,-60721,-60720,-60718,-60716,-60715,-60712,-60711,-60706,-60705,-60704,-60703,-60702,-60697,-60671,-60669,-60666,-60665,-60660,-60620,-60613,-60611,-60608,-60607,-55243,-51572,-51571,-51570,-51569,-51568,-50949,-50948,-50947,-50946,-50945,-50944,-50943,-50942,-50941,-50940,-50939,-50938,-46138,-46136,-46134,-46132,-42731,-41160,-41158,-41157,-41156,-40006,-40005,-40004,-40003,-36357,-36355,-36351,-36349,-36078,-36077,-36075,-36074,-35591,-35590,-35589,-35588,-35587,-35585,-35563,-35562,-35561,-35560,-35559,-35558,-35537,-35536,-35535,-35534,-35533,-35532,-32497,-32496,-32495,-32494,-32493,-32490,-32489,-32485,-32481,-32480,-32479,-32478,-32473,-32472,-32471,-32470,-28474,-28473,-28472,-28221,-28220,-28219,-26279,-24940,-24125,-24124,-24123,-24122,-24121,-23710,-23709,-23707,-23706,-23705,-23704,-23703,-23399,-22922,-22921,-22711,-21943,-20854,-20853,-19104,-19103,-19102,-19101,-19098,-19097,-19095,-19092,-19091,-19090,-19087,-19086,-19084,-19083,-19082,-19081,-19080,-19079,-19078,-19076,-19074,-19073,-19072,-19071,-19068,-19067,-19066,-19065,-19063,-19062,-19061,-19059,-19055,-19053,-19052,-19049,-10647,-10632,-10630,-10621,-10572,-10566,-10560,-10558,-10548,-10546,-10544,-10531,-10529,-10520,-10516,-10507,-10499,-10490,-9208,-9207,-9206,-9202,-9201,-9197,-9196,-9195,-9149,-9148,-9147,-9146,-9145,-9074,-9072,-9068,-9065,-9064,-9059,-8322,-7955,-7954,-7156,-7151,-7149,-7147,-7135,-7133,-7126,-6705,-6704,-6703,-6702,-6661,-4097,-4096,-3779,-3778,-3777,-3776,-3775,-3774,-3773,-3772,-3771,-3770,-3769,-3768,-3767,-3766,-3765,-3764,-3763,-3762,-3761,-3759,-3756,-3753,-2169,-2167,-2166,-2164,-2163,-2161,-2160,-2158,-2153,-2149')
	mod:AddData( 'Leatherworking', L['Mail Armor'],              '-70561,-70560,-70559,-70558,-67143,-67138,-67137,-67136,-67083,-67082,-67081,-67080,-63197,-63196,-63195,-63194,-61002,-61000,-60999,-60757,-60756,-60755,-60754,-60752,-60751,-60750,-60749,-60748,-60747,-60746,-60743,-60737,-60735,-60734,-60732,-60731,-60730,-60729,-60728,-60658,-60655,-60652,-60651,-60649,-60630,-60629,-60627,-60624,-60622,-60605,-60604,-60601,-60600,-60599,-52733,-50961,-50960,-50959,-50958,-50957,-50956,-50955,-50954,-50953,-50952,-50951,-50950,-46139,-46137,-46135,-46133,-41164,-41163,-41162,-41161,-40002,-40001,-39997,-36359,-36358,-36353,-36352,-36079,-36076,-35584,-35582,-35580,-35577,-35576,-35575,-35574,-35573,-35572,-35568,-35567,-35564,-35531,-35529,-35528,-35527,-35526,-35525,-32503,-32502,-32501,-32500,-32499,-32498,-32488,-32487,-32469,-32468,-32467,-32466,-32465,-32464,-32463,-32462,-28224,-28223,-28222,-24851,-24850,-24849,-24848,-24847,-24846,-24703,-24655,-24654,-23708,-22923,-20855,-19107,-19100,-19094,-19089,-19088,-19085,-19077,-19075,-19070,-19064,-19060,-19054,-19051,-19050,-19048,-10650,-10619,-10570,-10568,-10564,-10556,-10554,-10552,-10542,-10533,-10525,-10518,-10511,-10509')
	mod:AddData( 'Leatherworking', L['Other'],                   '-69388,-69386,-35544,-35543,-35540,-35539,-35538,-23190')
	mod:AddData( 'Leatherworking', L['Quest'],                   '-22815')
	mod:AddData( 'Leatherworking', L['Quiver'],                  '-60647,-44359,-44344,-14930,-9193,-9060')
end)

-- Producer.Default.Runeforge
mod:RegisterSelection( 'Runeforge', function()
	mod:AddData( 'Runeforge', L['Coining'],                      '-62158,-54447,-54446,-53344,-53343,-53342,-53341,-53331,-53323')
end)

-- Producer.Default.Smelting
mod:RegisterSelection( 'Smelting', function()
	mod:AddData( 'Smelting', L['Elemental'],                     '-35751,-35750')
	mod:AddData( 'Smelting', L['Metal & Stone'],                 '-70524,-55211,-55208,-49258,-49252,-46353,-29686,-29361,-29360,-29359,-29358,-29356,-22967,-16153,-14891,-10098,-10097,-3569,-3308,-3307,-3304,-2659,-2658,-2657')
end)

-- Producer.Default.Tailoring
mod:RegisterSelection( 'Tailoring', function()
	mod:AddData( 'Tailoring', L['Bags'],                         '-63924,-56007,-56006,-56005,-56004,-50194,-31459,-27725,-27724,-27660,-27659,-27658,-26763,-26759,-26755,-26749,-26746,-26087,-26086,-26085,-18455,-18445,-18405,-12079,-12065,-6695,-6693,-6688,-6686,-3813,-3758,-3757,-3755')
	mod:AddData( 'Tailoring', L['Cloth'],                        '-56003,-56002,-56001,-55900,-55899,-36686,-31373,-26751,-26750,-26747,-26745,-18560,-18401,-3865,-3839,-2964,-2963')
	mod:AddData( 'Tailoring', L['Cloth Armor'],                  '-70553,-70552,-70551,-70550,-67147,-67146,-67145,-67144,-67079,-67066,-67065,-67064,-64730,-64729,-63742,-63206,-63205,-63204,-63203,-60994,-60993,-60990,-59589,-59588,-59587,-59586,-59585,-59584,-59583,-59582,-56048,-56031,-56030,-56029,-56028,-56027,-56026,-56025,-56024,-56023,-56022,-56021,-56020,-56019,-56018,-56017,-56016,-56015,-56014,-55943,-55941,-55925,-55924,-55923,-55922,-55921,-55920,-55919,-55914,-55913,-55911,-55910,-55908,-55907,-55906,-55904,-55903,-55902,-55901,-50647,-50644,-49677,-46131,-46130,-46129,-46128,-44958,-44950,-41208,-41207,-41206,-41205,-40060,-40024,-40023,-40021,-40020,-37884,-37883,-37882,-37873,-36668,-36667,-36665,-36318,-36317,-36316,-36315,-31456,-31455,-31454,-31453,-31452,-31451,-31450,-31449,-31448,-31444,-31443,-31442,-31441,-31440,-31438,-31437,-31435,-31434,-28482,-28481,-28480,-28210,-28209,-28208,-28207,-28205,-26784,-26783,-26782,-26781,-26780,-26779,-26778,-26777,-26776,-26775,-26774,-26773,-26772,-26771,-26770,-26765,-26764,-26762,-26761,-26760,-26758,-26757,-26756,-26754,-26753,-26752,-26403,-24903,-24902,-24901,-24093,-24092,-24091,-23667,-23666,-23665,-23664,-23663,-23662,-22902,-22870,-22869,-22868,-22867,-22866,-22759,-20849,-20848,-19435,-18458,-18457,-18456,-18454,-18453,-18452,-18451,-18450,-18449,-18448,-18447,-18446,-18444,-18442,-18441,-18440,-18439,-18438,-18437,-18436,-18434,-18424,-18423,-18422,-18421,-18420,-18419,-18418,-18417,-18416,-18415,-18414,-18413,-18412,-18411,-18410,-18409,-18408,-18407,-18406,-18404,-18403,-18402,-12093,-12092,-12091,-12089,-12088,-12086,-12084,-12082,-12081,-12078,-12076,-12074,-12073,-12072,-12071,-12070,-12069,-12067,-12066,-12060,-12059,-12056,-12055,-12053,-12052,-12050,-12049,-12048,-12047,-12046,-12045,-12044,-8804,-8802,-8799,-8797,-8795,-8793,-8791,-8789,-8786,-8784,-8782,-8780,-8776,-8774,-8772,-8770,-8766,-8764,-8762,-8760,-8758,-7643,-7639,-7633,-7630,-7629,-7624,-7623,-6692,-6690,-6521,-3914,-3868,-3864,-3863,-3862,-3861,-3860,-3859,-3858,-3857,-3856,-3855,-3854,-3852,-3851,-3850,-3849,-3848,-3847,-3845,-3844,-3843,-3842,-3841,-3840,-2403,-2402,-2401,-2399,-2397,-2395,-2389,-2387,-2386,-2385')
	mod:AddData( 'Tailoring', L['Embroidery'],                   '-56039,-56034,-55777,-55769,-55642')
	mod:AddData( 'Tailoring', L['Item Enhancement'],             '-56011,-56010,-56009,-56008,-31433,-31432,-31431,-31430')
	mod:AddData( 'Tailoring', L['Miscellaneous'],                '-56000,-55999,-55998,-55997,-55996,-55995,-55994,-55993,-26407,-21945,-12085,-12080,-12077,-12075,-12064,-12061,-8489,-8483,-8467,-8465,-7893,-7892,-3915,-3873,-3872,-3871,-3870,-3869,-3866,-2406,-2396,-2394,-2393,-2392')
	mod:AddData( 'Tailoring', L['Mount'],                        '-60971,-60969')
	mod:AddData( 'Tailoring', L['Other'],                        '-55898,-31460')
	mod:AddData( 'Tailoring', L['Quest'],                        '-22813')
end)
