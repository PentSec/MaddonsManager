local L = LibStub("AceLocale-3.0"):NewLocale("KuiNameplates", "ruRU", false)
if not L then return end