local L = LibStub("AceLocale-3.0"):NewLocale("KuiNameplates", "esMX", false)
if not L then return end