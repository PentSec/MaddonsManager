local L = LibStub("AceLocale-3.0"):NewLocale("KuiNameplates", "koKR", false)
if not L then return end