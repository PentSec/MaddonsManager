local encounters = HudMap:GetModule("Encounters")
local HudMap = _G.HudMap
local UnitName, UnitIsDead = _G.UnitName, _G.UnitIsDead
local parent = HudMap
local L = LibStub("AceLocale-3.0"):GetLocale("HudMap")
local SN = parent.SN

local function register(e)
	encounters:RegisterEncounterMarker(e)
	return e
end

local function free(e)
	if e then e:Free() end
	return nil
end

-- TODO: Mark void zone radii/durations
local xt = {
	name = L["XT-002 Deconstructor"],
	options = {
		searingLight = SN[65598],
		gravityBomb = SN[63024]		
	},
	defaults = {
		searingLightColor = {r = 1, g = 0.8, b = 0.13, a = 0.6},
		gravityBombColor = {r = 0.1, g = 0.4, b = 1, a = 0.6}
	},
	SPELL_AURA_APPLIED = function(self, spellID, sourceName, destName, sourceGUID, destGUID)
		-- Light bomb
		if (spellID == 63018 or spellID == 65121) and self:Option("searingLightEnabled") then
			local r, g, b, a = self:Option("searingLightColor")
			register(HudMap:PlaceRangeMarkerOnPartyMember("timer", destName, 10, 9, 1, 0.8, 0.13, 1):Appear():Rotate(360, 9):SetLabel(destName))
		elseif (spellID == 63024 or spellID == 64234) and self:Option("gravityBombEnabled") then
			local r, g, b, a = self:Option("gravityBombColor")
			register(HudMap:PlaceRangeMarkerOnPartyMember("timer", destName, 12, 9, 0.1, 0.4, 1, 0.6):Appear():Rotate(360, 9):SetLabel(destName))
		end
	end
}

local vezax = {
	name = L["General Vexaz"],
	options = {
		crash = SN[60835],
	},
	defaults = {
		crashColor = {r = 0.1, g = 0.4, b = 1, a = 0.6}
	},
	crash = function()
		local crashTarget = encounters:GetMobTarget(33271)
		if crashTarget then
			local x, y = HudMap:GetUnitPosition(crashTarget)
			local r, g, b, a = self:Option("crashColor")
			HudMap:PlaceRangeMarker("timer", x, y, 10, 5, r, g, b, a):Appear():Rotate(360, 5)
		end
	end,
	SPELL_CAST_SUCCESS = function(self, spellID, sourceName, destName, sourceGUID, destGUID)
		if (spellID == 60835 or spellID == 62660) and self:Option("crashEnabled") then
			encounters:Delay(self.crash, 0.1)
		end
	end
}

encounters:RegisterModule(L["Ulduar"], xt, vezax)