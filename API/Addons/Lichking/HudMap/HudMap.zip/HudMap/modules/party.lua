local modName = "Party & Raid"
local parent = HudMap
local L = LibStub("AceLocale-3.0"):GetLocale("HudMap")
local mod = HudMap:NewModule(modName, "AceEvent-3.0")

--[[ Default upvals 
     This has a slight performance benefit, but upvalling these also makes it easier to spot leaked globals. ]]--
local _G = _G.getfenv(0)
local wipe, type, pairs, tinsert, tremove, tonumber = _G.wipe, _G.type, _G.pairs, _G.tinsert, _G.tremove, _G.tonumber
local math, math_abs, math_pow, math_sqrt, math_sin, math_cos, math_atan2 = _G.math, _G.math.abs, _G.math.pow, _G.math.sqrt, _G.math.sin, _G.math.cos, _G.math.atan2
local error, rawset, rawget, print = _G.error, _G.rawset, _G.rawget, _G.print
local tonumber, tostring = _G.tonumber, _G.tostring
local getmetatable, setmetatable, pairs, ipairs, select, unpack = _G.getmetatable, _G.setmetatable, _G.pairs, _G.ipairs, _G.select, _G.unpack
--[[ -------------- ]]--

local db
local group = parent.group
local currentTarget, highlight

local frame = CreateFrame("Frame")
local partyMembers = {}
local targetArrows = {}
local highlight

local free = parent.free

local options = {
	type = "group",
	name = L["Party & Raid"],
	args = {
		enable = {
			type = "toggle",
			name = L["Enable Party & Raid Dots"],
			order = 100,
			get = function()
				return db.enable
			end,
			set = function(info, v)
				db.enable = v
				local r = v and mod:Enable() or mod:Disable()
			end
		},
		showSpells = {
			type = "toggle",
			name = L["Show Spellcasts"],
			order = 110,
			get = function()
				return db.showSpells
			end,
			set = function(info, v)
				db.showSpells = v
			end
		},
		showSpellTargets = {
			type = "toggle",
			name = L["Show Spell Targets"],
			order = 111,
			get = function()
				return db.showSpellTargets
			end,
			set = function(info, v)
				db.showSpellTargets = v
			end
		},
		arrowToTarget = {
			type = "toggle",
			name = L["Arrow To Target"],
			order = 109,
			get = function()
				return db.arrowToTarget
			end,
			set = function(info, v)
				db.arrowToTarget = v
			end
		},
		dotSize = {
			type = "range",
			name = L["Dot Size"],
			order = 120,
			min = 4,
			max = 50,
			step = 1,
			bigStep = 1,
			get = function()
				return db.iconSize
			end,
			set = function(info, v)
				db.iconSize = v
				for k, dot in pairs(partyMembers) do
					dot:SetSize(v .. "px")
				end
				if highlight then
					highlight:SetSize((v+5) .. "px")
				end
			end
		},
		targetLabel = {
			type = "toggle",
			name = L["Target Name"],
			order = 125,
			get = function() return db.targetLabel end,
			set = function(info, v)
				db.targetLabel = v
				mod:PLAYER_TARGET_CHANGED()
			end
		},
		highlightTarget = {
			type = "toggle",
			name = L["Highlight Target"],
			order = 127,
			get = function() return db.highlightTarget end,
			set = function(info, v)
				db.highlightTarget = v
				mod:PLAYER_TARGET_CHANGED()
			end		
		}
	}
}

local defaults = {
	profile = {
		enable = true,
		showSpells = false,
		showSpellTargets = false,
		arrowToTarget = false,
		iconSize = 13,
		targetLabel = false,
		highlightTarget = true
	}
}

local classLookup = setmetatable({}, {__index = function(t, k)
	local _, c = UnitClass(k)
	if c then
		rawset(t, k, c)
		return c
	end
	return nil
end})

local SN = parent.SN

local spellMap = {
	-- Paladin
	[48825] = "healer",		-- Holy Shock
	[53562] = "healer",		-- Beacon of Light
	[48952] = "tank",			-- Holy Shield
	[35395] = "dps",			-- Crusader Strike
	
	-- Priest
	[53077] = "healer",		-- Penance
	[48089] = "healer",		-- Circle of Healing
	[15473] = "dps",			-- Shadowform
	[65490] = "dps",			-- Vampiric Touch
	
	-- Druid
	[53251] = "healer",		-- Wild Growth
	[33891] = "healer",		-- Tree of Life
	[48441] = "healer",		-- Rejuv
	[6807]  = "tank",			-- Maul
	[9634]  = "tank",			-- Bear Form
	[48562] = "tank",			-- Swipe
	[48572] = "dps",			-- Shred
	[48468] = "dps",			-- Insect Swarm
	[24858] = "dps",			-- Moonkin Form
	[768]   = "dps", 			-- Cat Form
	[48465] = "dps",			-- Starfire
	
	-- Death Knight
	[48263] = "tank",			-- Frost presence
	[48266] = "dps",			-- Blood presence
	[48265] = "dps",			-- Unholy presence
	
	-- Warrior
	[71]    = "tank",			-- Defensive Stance
	[57823] = "tank",			-- Revenge
	[47486] = "dps",			-- Mortal Strike
	[23881] = "dps",			-- Bloodthirst
	
	-- Shaman
	[61301] = "healer",   -- Riptide
	[49284] = "healer",   -- Earth Shield
	[57722] = "dps",   		-- Totem of Wrath
	[17364] = "dps",   		-- Stormstrike
	[59159] = "dps"
}

local bestGuess = {
	DEATHKNIGHT = function(unit)
		if UnitAura(unit, SN[48263]) then return "tank" end
		if UnitAura(unit, SN[48266]) then return "dps" end
		if UnitAura(unit, SN[48265]) then return "dps" end
	end,
	DRUID = function(unit)
		if UnitAura(unit, SN[9634])  then return "tank" end
		if UnitAura(unit, SN[768])   then return "dps" end
		if UnitAura(unit, SN[24858]) then return "dps" end
		if UnitAura(unit, SN[33891]) then return "healer" end
		return "dps"
	end,
	MAGE = "dps",
	HUNTER = "dps",	
	PALADIN = function(unit)
		if UnitLevel(unit) == 80 and UnitManaMax(unit) > 15000 then return "healer" end
		if UnitAura(unit, SN[25780]) then return "tank" end
		return "dps"
	end,
	PRIEST = function(unit)
		if UnitAura(unit, SN[15473]) then return "dps" end
		return "healer"
	end,
	ROGUE = "dps",
	SHAMAN = "dps",
	WARLOCK = "dps",
	WARRIOR = function(unit)
		if UnitLevel(unit) == 80 and UnitHealthMax(unit) > 40000 then return "tank" end
		return "dps"
	end
}

local spellNameMap = {}
for k, v in pairs(spellMap) do
	spellNameMap[SN[k]] = v
end

local UnitIsMappable = HudMap.UnitIsMappable

function mod:UpdatePartyUnit(unit)
	local n = UnitName(unit)
	if not n then return end
	if not UnitIsMappable(unit) and partyMembers[n] then
		partyMembers[n] = free(partyMembers[n], self, n)
	elseif UnitIsMappable(unit) and (not partyMembers[n] or partyMembers[n].freed) then
		local cl = RAID_CLASS_COLORS[classLookup[n]]
		if cl then
			local _, uc = UnitClass(unit)
			local r, g , b, a = cl.r, cl.g, cl.b, 1
			r = r + ((1-r) / 5)
			g = g + ((1-g) / 5)
			b = b + ((1-b) / 5)
			local guess = bestGuess[uc]
			if type(guess) == "function" then guess = guess(unit) end
			local c = parent:PlaceRangeMarkerOnPartyMember(guess or "party", n, db.iconSize .. "px", nil, r, g, b, a, "BLEND"):Identify(self, n)
			c.RegisterCallback(self, "Free", "FreeDot")
			partyMembers[n] = c
		end
	end
end

function mod:FreeDot(dot)
	if dot.follow then
		partyMembers[dot.follow] = nil
	end
end

function mod:UpdateParty()
	for index, unit in group() do
		self:UpdatePartyUnit(unit)
	end
	for name, dot in pairs(partyMembers) do
		if not UnitIsMappable(name) or dot.freed then
			partyMembers[name] = free(dot, self, name)
		end
	end
end

local throttle = 10
local counter = 0
local function update(self, t)
	counter = counter + t
	if counter > throttle then
		counter = counter - throttle
		mod:UpdateParty()
	end
end

function mod:OnInitialize()
	self.db = parent.db:RegisterNamespace(modName, defaults)
	db = self.db.profile
	local dbt = {OnProfileChanged = function(s) db = self.db.profile; self:Disable(); self:Enable() end}
	self.db.RegisterCallback(dbt, "OnProfileChanged")
	self.db.RegisterCallback(dbt, "OnProfileReset", "OnProfileChanged")
	self.db.RegisterCallback(dbt, "OnProfileCopied", "OnProfileChanged")
	parent:RegisterModuleOptions(modName, options, modName)
	self:SetEnabledState(db.enable)
end

function mod:OnEnable()
	frame:SetScript("OnUpdate", update)
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	self:RegisterEvent("UNIT_TARGET")
	self:RegisterEvent("PLAYER_TARGET_CHANGED")
	self:RegisterEvent("RAID_ROSTER_UPDATE", "UpdateParty")
	self:RegisterEvent("PARTY_MEMBERS_CHANGED", "UpdateParty")
	self:UpdateParty()
end

function mod:OnDisable()
	frame:SetScript("OnUpdate", nil)
	for k, v in pairs(partyMembers) do
		free(v, self, k)
	end
end

local roles = {}
local playerName
local function validUnit(unit)
	return unit and (partyMembers[unit] or UnitIsUnit(unit, "player")) and UnitIsMappable(unit, true)
end

function mod:COMBAT_LOG_EVENT_UNFILTERED(ev, timestamp, event, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellID, spellName, ...)
	if spellNameMap[spellName] and partyMembers[sourceName] and roles[sourceName] ~= spellNameMap[spellName] then
		partyMembers[sourceName]:SetTexture(spellNameMap[spellName], "BLEND")
		roles[sourceName] = spellNameMap[spellName]
	end
	
	if event == "SPELL_CAST_START" or event == "SPELL_CAST_SUCCESS" or event == "SPELL_HEAL" then
		if db.showSpells and sourceName then
			local dot = partyMembers[sourceName] 
			if dot then
				local _, _, icon = GetSpellInfo(spellID)
				dot:SetTexture(icon)
				dot.texture:SetVertexColor(1,1,1,1)
			end
		end
		if db.showSpellTargets and sourceName and destName then
			if validUnit(destName) and parent:UnitDistance(sourceName, destName) <= 50 then
				local edge = parent:AddEdge(0.5, 1, 0.5, 0.7, 1, sourceName, destName)				
				if partyMembers[sourceName] then partyMembers[sourceName]:AttachEdge(edge) end
				if partyMembers[destName] then partyMembers[destName]:AttachEdge(edge) end
			end
		end
	end
end

function mod:PLAYER_TARGET_CHANGED()
	self:UNIT_TARGET(nil, "player")
	local n = UnitName("target")
	if currentTarget then currentTarget:SetLabel("") end
	if partyMembers[n] then
		currentTarget = partyMembers[n]
		if db.targetLabel then
			currentTarget:SetLabel(n, "BOTTOM", "TOP", nil, nil, nil, nil, 0, 5)
		end
	
		if db.highlightTarget then
			free(highlight, self, "highlight")
			highlight = parent:PlaceRangeMarkerOnPartyMember([[Interface\BUTTONS\IconBorder-GlowRing.blp]], n, (db.iconSize + 5).. "px", nil, 1, 0.8, 0, 1, "ADD"):Pulse(1.3, 0.4):Appear():Identify(self, "highlight")
			highlight.RegisterCallback(self, "Free", "FreeHighlight")
		end
	else
		free(highlight, self, "highlight")
	end
end

function mod:FreeHighlight(self)
	highlight = nil
end

function mod:UNIT_TARGET(event, unit)
	if not db.arrowToTarget then return end
	local n = UnitName(unit)
	if validUnit(n) then
		if targetArrows[n] then targetArrows[n] = targetArrows[n]:Free() end
		
		local t = UnitName(unit .. "target")
		if t and validUnit(t) and parent:UnitDistance(unit, t) <= 50 then
			local edge = parent:AddEdge(1, 1, 1, 0.4, nil, unit, t)
			targetArrows[n] = edge
			if partyMembers[n] then partyMembers[n]:AttachEdge(edge) end
			if partyMembers[t] then partyMembers[t]:AttachEdge(edge) end
		end		
	end
end