function WarlockReminder_OnLoad(self)
	if ( UnitClass("player") == "Warlock" and UnitLevel("player") == 80 ) then
		self:RegisterEvent("UNIT_HEALTH");
		self:RegisterEvent("PLAYER_TARGET_CHANGED");
	end
end

local function UnitHasBuff(unit, buff)
    for i=1, 40 do
         if ( UnitBuff(unit, i) == buff ) then
              return true
         end
    end
end

function WarlockReminder_OnEvent(event)

	--if ( event == "PLAYER_TARGET_CHANGED" ) then
	if ( event == "PLAYER_TARGET_CHANGED" or event == "UNIT_HEALTH" and arg1 == "player" ) then -- Changed 10-02-2009

		if (	not UnitExists("pet") and
			not IsMounted("player") ) then
				UIErrorsFrame:AddMessage("* Missing a Pet! *", 0.0, 1.0, 0.0, 5.0)
		end

		if (	UnitHealth("player") > 0 and
			not UnitHasBuff("player", "Fel Armor") and
			not UnitHasBuff("player", "Demon Armor") ) then
				UIErrorsFrame:AddMessage("* Missing Fel/Demon Armor! *", 0.0, 1.0, 0.0, 5.0)
		end

		if (	GetWeaponEnchantInfo() ~= 1 and IsInInstance() or
			GetWeaponEnchantInfo() ~= 1 and UnitIsEnemy("player", "target") ) then
				UIErrorsFrame:AddMessage("* Missing Spellstone or Firestone! *", 0.0, 1.0, 0.0, 5.0)
		end

		if ( 	UnitLevel("target") < 0 and
			UnitHealth("target") * 100 / UnitHealthMax("target") > 98 and
			not UnitHasBuff("player", "Well Fed") ) then
				UIErrorsFrame:AddMessage("* Missing Well Fed! *", 0.0, 1.0, 0.0, 5.0)
		end

		if ( 	UnitLevel("target") < 0 and
			UnitHealth("target") * 100 / UnitHealthMax("target") > 98 and
			not UnitHasBuff("player", "Life Tap") ) then
				UIErrorsFrame:AddMessage("* Life Tap! *", 0.0, 1.0, 0.0, 5.0)
		end

		if ( 	UnitLevel("target") < 0 and
			UnitHealth("target") * 100 / UnitHealthMax("target") > 98 and
			not UnitHasBuff("player", "Flask of Pure Death") and
			not UnitHasBuff("player", "Flask of the Frost Wyrm") and
			not UnitHasBuff("player", "Major Shadow Power") and
			not UnitHasBuff("player", "Spellpower Elixir") ) then
				UIErrorsFrame:AddMessage("* Missing Flask or Elixir! *", 0.0, 1.0, 0.0, 5.0)
		end

	end
end


-- UnitAffectingCombat("player") == nil

		--if ( UnitCreatureFamily("pet") == "Felhunter" and not UnitHasBuff("player", "Grand Spellstone") ) then
		--	UIErrorsFrame:AddMessage("Use Spellstone", 0.0, 1.0, 0.0, 5.0)
		--end

		--if ( UnitCreatureFamily("pet") == "Imp" and not UnitHasBuff("player", "Grand Firestone") ) then
		--	UIErrorsFrame:AddMessage("Use Firestone", 0.0, 1.0, 0.0, 5.0)
		--end