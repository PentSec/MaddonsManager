--[[
Mage Fever Sound Files

To play a sound file on a proc, simply add the .mp3 file to the sound folder under Mage Fever with it's respective name.
Only those added will be played, and any missing files will be ignored.  

Use the following naming convention:
-Fingers of Frost = fingersoffrost.mp3
-Brain Freeze = brainfreeze.mp3
-Hot Streak = hotstreak.mp3
-Missile Barrage = missilebarrage.mp3
-Fire Starter = firestarter.mp3
-Clear Casting = clearcasting.mp3
-Impact = impact.mp3
-Firey Payback = fireypayback.mp3





]]--












