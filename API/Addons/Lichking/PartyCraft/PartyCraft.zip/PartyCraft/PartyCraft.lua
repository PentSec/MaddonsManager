local a = CreateFrame("Frame", nil, UIParent)
a.reset = CreateFrame("Button", nil, a, "UIPanelButtonTemplate")
a.reset:SetText(RESET)
a.reset:SetHeight(15)
a:SetBackdrop({
	bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
	edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",
	tileSize=32,
	tile=true,
	insets={
		top=12,
		bottom=12,
		right=12,
		left=12,
	},
})
a:SetSize(150, 95)
a:Hide()
a.header = CreateFrame("Button", nil, a)
a.header:SetNormalTexture("Interface\\DialogFrame\\UI-DialogBox-Header")
a:SetPoint("TOP", a.header, "TOP", 0, -6)
a.header:SetSize(100, 34)
a.header.text = a.header:CreateFontString()
a.header.text:SetPoint("TOP",0,-7)
a.header.text:SetFont("Fonts\\FRIZQT__.TTF", 8, "")
a.header.text:SetText("PartyCraft")
a.header:SetScript("OnMouseDown", function(self)
	if not InCombatLockdown() then
		self:StartMoving()
	end
end)
a.header:SetScript("OnMouseUp", function(self)
	self:StopMovingOrSizing()
	PartyCraft_Data.point, _, PartyCraft_Data.relative, PartyCraft_Data.x, PartyCraft_Data.y = self:GetPoint()
end)
a.header:SetMovable(true)
a.text = a:CreateFontString()
a.text:SetFont("Fonts\\FRIZQT__.TTF", 8, "")
a.text:SetTextColor(1,1,1)
a.text:SetPoint("TOPLEFT", 15, -15)
a.text:SetJustifyH("LEFT")
local itemtable = {}
a.reset:SetScript("OnClick", function()
	table.wipe(itemtable)
	a:Update()
end)
a:SetScript("OnShow", function(self) self:Update() end)
local strmatch_multi, strmatch_single = (string.gsub((string.gsub(CREATED_ITEM_MULTIPLE, "%%s","(%.+)")),"%%d","(%%d+)")), (string.gsub(CREATED_ITEM, "%%s","(%.+)"))
function a:Update()
	local text = ""
	for playername, data in pairs(itemtable) do
		text = text..(strlen(text) > 0 and "\n" or "").."\124cffffcc00"..playername.."\124r"
		for itemlink, num in pairs(data) do
			text = text.."\n  "..itemlink.."x"..num
		end
	end
	self.text:SetText(text)
	local strheight, strwidth = self.text:GetStringHeight(), math.max(120, self.text:GetStringWidth())
	self:SetHeight(strheight+50) --30+5+15
	self:SetWidth(strwidth+30)
end
a.reset:SetPoint("BOTTOMLEFT", 15, 15)
a.reset:SetPoint("BOTTOMRIGHT", -15, 15)
a:RegisterEvent("CHAT_MSG_LOOT")
a:RegisterEvent("ADDON_LOADED")
a:SetScript("OnEvent", function(self, event, msg)
	if event == "ADDON_LOADED" then
		if msg == "PartyCraft" then
			if PartyCraft_Data then
				self.header:SetPoint(PartyCraft_Data.point, UIParent, PartyCraft_Data.relative, PartyCraft_Data.x, PartyCraft_Data.y)
			else
				self.header:SetPoint("CENTER",UIParent,"CENTER")
				PartyCraft_Data = {}
			end
		end
		return
	end
	local name, item, num = string.match(msg, strmatch_multi)
	if not name then
		name, item= string.match(msg, strmatch_single)
		num=1
	end
	if name then
		itemtable[name] = itemtable[name] or {}
		itemtable[name][item] = (itemtable[name][item] or 0) + num
		self:Update()
	end
end)
SlashCmdList["PARTYCRAFT"]=function() a[a:IsShown() and "Hide" or "Show"](a) end
SLASH_PARTYCRAFT1 = "/pc"
SLASH_PARTYCRAFT2 = "/partycraft"