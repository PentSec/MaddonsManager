-- Warrior

Raven.classConditions.WARRIOR = {}