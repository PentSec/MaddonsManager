﻿
if ( GetLocale() == "deDE" ) then
	DotTracker_DEATHKNIGHT_DotA = "Frostfieber";
	DotTracker_DEATHKNIGHT_DotB = "Blutseuche";

	DotTracker_DRUID_DotA = "Mondfeuer";
	DotTracker_DRUID_DotB = "Feenfeuer";
	DotTracker_DRUID_DotBFeral = "Feenfeuer (Tiergestalt)";
	DotTracker_DRUID_DotC = "Insektenschwarm";

	DotTracker_HUNTER_DotAScorpid = "Skorpidstich";
	DotTracker_HUNTER_DotAViper = "Vipernbiss";
	DotTracker_HUNTER_DotASerpent = "Schlangenbiss";

	DotTracker_PALADIN_DotA = "Richturteil";
	DotTracker_PALADIN_DotALight = "Richturteil des Lichts";
	DotTracker_PALADIN_DotAWisdom = "Richturteil der Weisheit";
	DotTracker_PALADIN_DotAJustice = "Richturteil der Gerechtigkeit";

	DotTracker_PRIEST_DotA = "Verschlingende Seuche";
	DotTracker_PRIEST_DotB = "Vampirberührung";
	DotTracker_PRIEST_DotC = "Schattenwort: Schmerz";

	DotTracker_SHAMAN_DotA = "Flammenschock";

	DotTracker_WARLOCK_DotA = "Verderbnis";
	DotTracker_WARLOCK_DotB = "Feuerbrand";

	DotTracker_WARLOCK_DotC = "Fluch";
	DotTracker_WARLOCK_DotCAgony = "Fluch der Pein";
	DotTracker_WARLOCK_DotCDoom = "Fluch der Verdammnis";
	DotTracker_WARLOCK_DotCElements = "Fluch der Elemente";
	DotTracker_WARLOCK_DotCTongues = "Fluch der Sprachen";
	DotTracker_WARLOCK_DotCWeakness = "Fluch der Schwäche";
	DotTracker_WARLOCK_DotCExhaustion = "Fluch der Erschöpfung";

	DotTracker_WARRIOR_DotA = "Verwunden";
	DotTracker_WARRIOR_DotB = "Rüstung zerreißen";
	DotTracker_WARRIOR_DotBSunder = "Rüstung zerreißen";
end