function DotTracker_Options_Toggle()
    if ( DotTracker_Options_Frame:IsShown() ) then
        DotTracker_Options_Frame:Hide();
		DotTracker_Options.help = false;
		DotTracker_DotA_Frame:Hide();
		DotTracker_DotB_Frame:Hide();
		DotTracker_DotC_Frame:Hide();
    else
        DotTracker_Options_Frame:Show();
		DotTracker_Options.help = true;
    end
	DotTracker_StoreSpec(DotTracker_Dots.spec);
end


function DotTracker_SetupSlider(self, text, myMin, myMax, step)
    getglobal(self:GetName().."Text") :SetText(text);
    getglobal(self:GetName().."Low") :SetText(myMin);
    getglobal(self:GetName().."High") :SetText(myMax);
    self:SetMinMaxValues(myMin, myMax);
    self:SetValueStep(step);
end


function DotTracker_Options_Init()
    DotTracker_Options_Frame_LockBox:SetChecked(DotTracker_Options.lock);
    DotTracker_Options_Frame_DotA:SetChecked(DotTracker_Setting.showDotA);
    DotTracker_Options_Frame_DotB:SetChecked(DotTracker_Setting.showDotB);
    DotTracker_Options_Frame_DotC:SetChecked(DotTracker_Setting.showDotC);
    DotTracker_Options_Frame_TextA:SetText(DotTracker_Dots.textA);
    DotTracker_Options_Frame_TextB:SetText(DotTracker_Dots.textB);
    DotTracker_Options_Frame_TextC:SetText(DotTracker_Dots.textC);
	DotTracker_WidthType_Menu_Logic();
    DotTracker_Options_Frame_MinWidthSlider:SetValue(DotTracker_Options.minWidth);
	DoTracker_Option_EditBox_Update();

    DotTracker_Options_Frame_RemderSliderA:SetValue(DotTracker_Setting.reminderDotA);
    DotTracker_Options_Frame_RemderSliderB:SetValue(DotTracker_Setting.reminderDotB);
    DotTracker_Options_Frame_RemderSliderC:SetValue(DotTracker_Setting.reminderDotC);

    DotTracker_Options_Frame_LevelSliderA:SetValue(DotTracker_Setting.minLevelDotA);
    DotTracker_Options_Frame_LevelSliderB:SetValue(DotTracker_Setting.minLevelDotB);
    DotTracker_Options_Frame_LevelSliderC:SetValue(DotTracker_Setting.minLevelDotC);

    DotTracker_Options_Frame_TextBox:SetChecked(DotTracker_Options.text);
    DotTracker_Options_Frame_ReminderFadeUp:SetChecked(DotTracker_Options.reminderFadeUp);
    DotTracker_Options_Frame_ShowInVehicle:SetChecked(DotTracker_Options.showInVehicle);
    DotTracker_Options_Frame_StanceCheck:SetChecked(DotTracker_Options.stanceCheck);
end


function DotTracker_WidthType_Menu_Logic()
	DotTracker_Frame_Size();
    DotTracker_Options_Frame_WidthTypeA:SetChecked(false);
    DotTracker_Options_Frame_WidthTypeB:SetChecked(false);
    DotTracker_Options_Frame_WidthTypeC:SetChecked(false);
    DotTracker_Options_Frame_WidthTypeD:SetChecked(false);

	if ( DotTracker_Options.widthType == 0 ) then
		DotTracker_Options_Frame_WidthTypeA:SetChecked(true);
	elseif ( DotTracker_Options.widthType == 1 ) then
		DotTracker_Options_Frame_WidthTypeB:SetChecked(true);
	elseif ( DotTracker_Options.widthType == 2 ) then
		DotTracker_Options_Frame_WidthTypeC:SetChecked(true);
	elseif ( DotTracker_Options.widthType == 3 ) then
		DotTracker_Options_Frame_WidthTypeD:SetChecked(true);
	end
end


function DoTracker_Option_EditBox_Update()
	local textA, textB, textC;
	
	textA = string.format("Reminder: %ds", DotTracker_Setting.reminderDotA);
	textB = string.format("Reminder: %ds", DotTracker_Setting.reminderDotB);
	textC = string.format("Reminder: %ds", DotTracker_Setting.reminderDotC);

    DotTracker_Options_Frame_RemderSliderAText:SetText(textA);
    DotTracker_Options_Frame_RemderSliderBText:SetText(textB);
    DotTracker_Options_Frame_RemderSliderCText:SetText(textC);

	if ( DotTracker_Setting.minLevelDotA == -1 ) then
		textA = "Min Lvl: Raid Boss";
	else
		textA = string.format("Min Lvl: %d", DotTracker_Setting.minLevelDotA);
	end

	if ( DotTracker_Setting.minLevelDotB == -1 ) then
		textB = "Min Lvl: Raid Boss";
	else
		textB = string.format("Min Lvl: %d", DotTracker_Setting.minLevelDotB);
	end

	if ( DotTracker_Setting.minLevelDotC == -1 ) then
		textC = "Min Lvl: Raid Boss";
	else
		textC = string.format("Min Lvl: %d", DotTracker_Setting.minLevelDotC);
	end

    DotTracker_Options_Frame_LevelSliderAText:SetText(textA);
    DotTracker_Options_Frame_LevelSliderBText:SetText(textB);
    DotTracker_Options_Frame_LevelSliderCText:SetText(textC);
end


function DotTracker_Frame_Size()
	local textLengthA = 0;
	local textLengthB = 0;
	local textLengthC = 0;

	local frameWidthA = 0;
	local frameWidthB = 0;
	local frameWidthC = 0;

	if ( DotTracker_Options.widthType == 0 ) then
		if ( DotTracker_Options.text == true ) then
			if ( DotTracker_Dots.class == "DEATHKNIGHT" ) then
				if ( DotTracker_Setting.reminderDotA == 0 ) then
					frameWidthA = 122;
				else
					frameWidthA = 160;
				end
				if ( DotTracker_Setting.reminderDotB == 0 ) then
					frameWidthB = 140;
				else
					frameWidthB = 170;
				end
			elseif ( DotTracker_Dots.class == "DRUID" ) then
				if ( DotTracker_Setting.reminderDotA == 0 ) then
					frameWidthA = 115;
				else
					frameWidthA = 148;
				end
				if ( DotTracker_Setting.reminderDotB == 0 ) then
					frameWidthB = 120;
				else
					frameWidthB = 160;
				end
				if ( DotTracker_Setting.reminderDotC == 0 ) then
					frameWidthC = 138;
				else
					frameWidthC = 174;
				end
			elseif ( DotTracker_Dots.class == "HUNTER" ) then
				if ( DotTracker_Setting.reminderDotA == 0 ) then
					frameWidthA = 90;
				else
					frameWidthA = 122;
				end
			elseif ( DotTracker_Dots.class == "PALADIN" ) then
				if ( DotTracker_Setting.reminderDotA == 0 ) then
					frameWidthA = 122;
				else
					frameWidthA = 158;
				end
			elseif ( DotTracker_Dots.class == "PRIEST" ) then
				if ( DotTracker_Setting.reminderDotA == 0 ) then
					frameWidthA = 166;
				else
					frameWidthA = 198;
				end
				if ( DotTracker_Setting.reminderDotB == 0 ) then
					frameWidthB = 152;
				else
					frameWidthB = 186;
				end
				if ( DotTracker_Setting.reminderDotC == 0 ) then
					frameWidthC = 175;
				else
					frameWidthC = 210;
				end
			elseif ( DotTracker_Dots.class == "SHAMAN" ) then
				if ( DotTracker_Setting.reminderDotA == 0 ) then
					frameWidthA = 134;
				else
					frameWidthA = 168;
				end
			elseif ( DotTracker_Dots.class == "WARLOCK" ) then
				if ( DotTracker_Setting.reminderDotA == 0 ) then
					frameWidthA = 124;
				else
					frameWidthA = 160;
				end
				if ( DotTracker_Setting.reminderDotB == 0 ) then
					frameWidthB = 116;
				else
					frameWidthB = 150;
				end
				if ( DotTracker_Setting.reminderDotC == 0 ) then
					frameWidthC = 92;
				else
					frameWidthC = 134;
				end
			elseif ( DotTracker_Dots.class == "WARRIOR" ) then
				if ( DotTracker_Setting.reminderDotA == 0 ) then
					frameWidthA = 90;
				else
					frameWidthA = 122;
				end
				if ( DotTracker_Setting.reminderDotB == 0 ) then
					frameWidthB = 110;
				else
					frameWidthB = 145;
				end
			end
		else
			frameWidthA = 50;
			frameWidthB = 50;
			frameWidthC = 50;
		end
	elseif ( DotTracker_Options.widthType == 2 ) then
		if ( DotTracker_Options.text == true ) then
			if ( DotTracker_Setting.reminderDotA > 0 ) then
				textLengthA = 7;
			end
			if ( DotTracker_Setting.reminderDotB > 0 ) then
				textLengthB = 7;
			end
			if ( DotTracker_Setting.reminderDotC > 0 ) then
				textLengthC = 7;
			end
			if ( DotTracker_Dots.class == "DEATHKNIGHT" ) then
				textLengthA = textLengthA + string.len(DotTracker_DEATHKNIGHT_DotA);
				textLengthB = textLengthB + string.len(DotTracker_DEATHKNIGHT_DotB);
			elseif ( DotTracker_Dots.class == "DRUID" ) then
				textLengthA = textLengthA + string.len(DotTracker_DRUID_DotA);
				textLengthB = textLengthB + string.len(DotTracker_DRUID_DotB);
				textLengthC = textLengthC + string.len(DotTracker_DRUID_DotC);
			elseif ( DotTracker_Dots.class == "HUNTER" ) then
				textLengthA = textLengthA + string.len(DotTracker_HUNTER_DotA);
			elseif ( DotTracker_Dots.class == "PALADIN" ) then
				textLengthA = textLengthA + string.len(DotTracker_PALADIN_DotA);
			elseif ( DotTracker_Dots.class == "PRIEST" ) then
				textLengthA = textLengthA + string.len(DotTracker_PRIEST_DotA);
				textLengthB = textLengthB + string.len(DotTracker_PRIEST_DotB);
				textLengthC = textLengthC + string.len(DotTracker_PRIEST_DotC);
			elseif ( DotTracker_Dots.class == "SHAMAN" ) then
				textLengthA = textLengthA + string.len(DotTracker_SHAMAN_DotA);
			elseif ( DotTracker_Dots.class == "WARLOCK" ) then
				textLengthA = textLengthA + string.len(DotTracker_WARLOCK_DotA);
				textLengthB = textLengthB + string.len(DotTracker_WARLOCK_DotB);
				textLengthC = textLengthC + string.len(DotTracker_WARLOCK_DotC);
			elseif ( DotTracker_Dots.class == "WARRIOR" ) then
				textLengthA = textLengthA + string.len(DotTracker_WARRIOR_DotA);
				textLengthB = textLengthB + string.len(DotTracker_WARRIOR_DotB);
			end
			frameWidthA = DotTracker_String_To_Frame(textLengthA);
			frameWidthB = DotTracker_String_To_Frame(textLengthB);
			frameWidthC = DotTracker_String_To_Frame(textLengthC);
		else
			frameWidthA = 50;
			frameWidthB = 50;
			frameWidthC = 50;
		end
	else
		if ( DotTracker_Dots.class == "DEATHKNIGHT" ) then
			frameWidthA = 170;
			frameWidthB = 170;
		elseif ( DotTracker_Dots.class == "DRUID" ) then
			frameWidthA = 174;
			frameWidthB = 174;
			frameWidthC = 174;
		elseif ( DotTracker_Dots.class == "HUNTER" ) then
			frameWidthA = 122;
		elseif ( DotTracker_Dots.class == "PALADIN" ) then
			frameWidthA = 158;
		elseif ( DotTracker_Dots.class == "PRIEST" ) then
			frameWidthA = 210;
			frameWidthB = 210;
			frameWidthC = 210;
		elseif ( DotTracker_Dots.class == "SHAMAN" ) then
			frameWidthA = 168;
		elseif ( DotTracker_Dots.class == "WARLOCK" ) then
			frameWidthA = 160;
			frameWidthB = 160;
			frameWidthC = 160;
		elseif ( DotTracker_Dots.class == "WARRIOR" ) then
			frameWidthA = 145;
			frameWidthB = 145;
		end
	end

	if ( DotTracker_Options.minWidth > frameWidthA ) then
		frameWidthA = DotTracker_Options.minWidth;
	end
	if ( DotTracker_Options.minWidth > frameWidthB ) then
		frameWidthB = DotTracker_Options.minWidth;
	end
	if ( DotTracker_Options.minWidth > frameWidthC ) then
		frameWidthC = DotTracker_Options.minWidth;
	end

	DotTracker_DotA_Frame:SetWidth(frameWidthA);
	DotTracker_DotB_Frame:SetWidth(frameWidthB);
	DotTracker_DotC_Frame:SetWidth(frameWidthC);

	if ( DotTracker_Options.widthType == 1 ) then
		DotTracker_DotA_Frame:SetWidth(50);
		DotTracker_DotB_Frame:SetWidth(50);
		DotTracker_DotC_Frame:SetWidth(50);

	end

	DotTracker_DotA_Frame:SetHeight(50);
	DotTracker_DotB_Frame:SetHeight(50);
	DotTracker_DotC_Frame:SetHeight(50);
end


function DotTracker_String_To_Frame(stringLength)
	local frameWidth = 0;
		
	frameWidth = 50 + (stringLength * 8);

	return frameWidth;
end


