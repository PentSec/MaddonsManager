function DotTracker_SlashCommand(msg)
    msg = string.lower(msg);
    local args = {};
	local text;
    for word in string.gmatch(msg, "[^%s]+") do
        table.insert(args, word);
    end
    if ( args[1] ) then
        if ( args[1] == "vis" ) then
            DotTracker_Toggle();
        elseif ( args[1] == "lock" ) then
            DotTracker_Options.lock = not DotTracker_Options.lock;
        elseif ( args[1] == "tooltip" ) then
            DotTracker_Options.tooltip = not DotTracker_Options.tooltip;
        elseif ( args[1] == "alpha" ) then
            local alpha = tonumber(args[2])
            if  ( alpha and alpha >= 0 and alpha <= 1 ) then
                DotTracker_Options.alpha = alpha;
                DotTracker_Frame:SetAlpha(alpha);
            else
                DotTracker_Messgae(DotTRACKER_OPTIONS_ALPHAWRONG);
            end
        elseif ( args[1] == "set" ) then
            local DotToggle = tonumber(args[2])
            if ( DotToggle ) then
				if ( DotToggle == 0 ) then
					if ( DotTracker_Setting.combatOnly == true ) then
						DotTracker_Setting.combatOnly = false;
					else
						DotTracker_Setting.combatOnly = true;
					end
				elseif ( DotToggle == 1 ) then
					if ( DotTracker_Setting.showDotA == true ) then
						DotTracker_Setting.showDotA = false;
						DotTracker_DotA_Frame:Hide();
					else
						DotTracker_Setting.showDotA = true;
					end
				elseif ( DotToggle == 2 ) then
					if ( DotTracker_Setting.showDotB == true ) then
						DotTracker_Setting.showDotB = false;
						DotTracker_DotB_Frame:Hide();
					else
						DotTracker_Setting.showDotB = true;
					end
				elseif ( DotToggle == 3 ) then
					if ( DotTracker_Setting.showDotC == true ) then
						DotTracker_Setting.showDotC = false;
						DotTracker_DotC_Frame:Hide();
					else
						DotTracker_Setting.showDotC = true;
					end
				end
            end
			text = string.format("0 - "..DotTracker_COMBATONLY);
			if ( DotTracker_Setting.combatOnly == true ) then
				text = string.format(text.."on");
			else
				text = string.format(text..OFF);
			end
			DotTracker_Message(text);
			DotTracker_ClassShow();
        elseif ( args[1] == "rem" ) then
            local DotToggle = tonumber(args[2])
			local DotToggleRemind = tonumber(args[3])
            if ( DotToggle and DotToggleRemind ) then
				if ( DotToggle == 1 ) then
					DotTracker_Setting.reminderDotA = DotToggleRemind;
				elseif ( DotToggle == 2 ) then
					DotTracker_Setting.reminderDotB = DotToggleRemind;
				elseif ( DotToggle == 3 ) then
					DotTracker_Setting.reminderDotC = DotToggleRemind;
				end
				DotTracker_Frame_Size();
            end
			text = string.format("0 - "..DotTracker_COMBATONLY);
			if ( DotTracker_Setting.combatOnly == true ) then
				text = string.format(text.."on");
			else
				text = string.format(text..OFF);
			end
			DotTracker_Message(text);
			DotTracker_ClassShow();
			DoTracker_Option_EditBox_Update();
        elseif ( args[1] == "width" ) then
            DotTracker_Options.widthType = tonumber(args[2]);
			DotTracker_Message(string.format("width <#> - %d - "..DotTracker_OPTIONS_WIDTH, DotTracker_Options.widthType));
			DotTracker_WidthType_Menu_Logic();
        elseif ( args[1] == "minw" ) then
            DotTracker_Options.minWidth = tonumber(args[2]);
			if ( DotTracker_Options.minWidth < 50 ) then
				DotTracker_Options.minWidth = 50;
			end
			DotTracker_Message(string.format("minw <#> - %d - "..DotTracker_OPTIONS_MINWIDTH, DotTracker_Options.minWidth));
			DotTracker_Frame_Size();
        elseif ( args[1] == "text" ) then
			if ( DotTracker_Options.text == true ) then
	            DotTracker_Options.text = false;
			else
				DotTracker_Options.text = true;
			end
			DotTracker_Frame_Size();
        elseif ( args[1] == "fade" ) then
			if ( DotTracker_Options.reminderFadeUp == true ) then
	            DotTracker_Options.reminderFadeUp = false;
			else
				DotTracker_Options.reminderFadeUp = true;
			end
			DotTracker_Frame_Size();
        elseif ( args[1] == "veh" ) then
			if ( DotTracker_Options.showInVehicle == true ) then
	            DotTracker_Options.showInVehicle = false;
			else
				DotTracker_Options.showInVehicle = true;
			end
			DotTracker_Frame_Size();
        elseif ( args[1] == "stance" ) then
			if ( DotTracker_Options.stanceCheck == true ) then
	            DotTracker_Options.stanceCheck = false;
			else
				DotTracker_Options.stanceCheck = true;
			end
        elseif ( args[1] == "lvl" ) then
            local DotToggle = tonumber(args[2])
			local DotToggleValue = tonumber(args[3])
            if ( DotToggle and DotToggleValue ) then
				if ( DotToggle == 1 ) then
					DotTracker_Setting.minLevelDotA = DotToggleValue;
				elseif ( DotToggle == 2 ) then
					DotTracker_Setting.minLevelDotB = DotToggleValue;
				elseif ( DotToggle == 3 ) then
					DotTracker_Setting.minLevelDotC = DotToggleValue;
				end
            end
			text = string.format("0 - "..DotTracker_COMBATONLY);
			if ( DotTracker_Setting.combatOnly == true ) then
				text = string.format(text.."on");
			else
				text = string.format(text..OFF);
			end
			DotTracker_Message(text);
			DotTracker_ClassShow();
			DoTracker_Option_EditBox_Update();
        elseif ( args[1] == "test" ) then
            DotTracker_test = tonumber(args[2]);
			DotTracker_Frame_Size();
			DotTracker_Message(string.format("test - %d", DotTracker_test));
        elseif ( args[1] == "help" ) then
			DotTracker_Message(DotTRACKER_USAGE);
			DotTracker_Message("vis - "..DotTRACKER_OPTIONS_VIS);
			DotTracker_Message("lock - "..DotTRACKER_OPTIONS_LOCK);
			DotTracker_Message("tooltip - "..DotTRACKER_OPTIONS_TOOLTIP);
			DotTracker_Message("alpha <#> - "..DotTRACKER_OPTIONS_ALPHA);
			DotTracker_Message(string.format("width <#> - %d - "..DotTracker_OPTIONS_WIDTH, DotTracker_Options.widthType));
			DotTracker_Message(string.format("minw <#> - %d - "..DotTracker_OPTIONS_MINWIDTH, DotTracker_Options.minWidth));
			if ( DotTracker_Options.stanceCheck == true ) then
			    DotTracker_Message("stance - "..DotTracker_OPTIONS_STANCE_CHECK.." - on");
			else
			    DotTracker_Message("stance - "..DotTracker_OPTIONS_STANCE_CHECK.." - "..OFF);
			end
			if ( DotTracker_Options.showInVehicle == true ) then
			    DotTracker_Message("veh - "..DotTracker_OPTIONS_SHOW_IN_VEHICLE.." - on");
			else
			    DotTracker_Message("veh - "..DotTracker_OPTIONS_SHOW_IN_VEHICLE.." - "..OFF);
			end
			if ( DotTracker_Options.reminderFadeUp == true ) then
			    DotTracker_Message("fade - "..DotTracker_OPTIONS_REMINDER_FADE_UP.." - on");
			else
			    DotTracker_Message("fade - "..DotTracker_OPTIONS_REMINDER_FADE_UP.." - "..OFF);
			end
			if ( DotTracker_Options.text == true ) then
			    DotTracker_Message("text - "..DotTracker_OPTIONS_TEXT.." - on");
			else
			    DotTracker_Message("text - "..DotTracker_OPTIONS_TEXT.." - "..OFF);
			end
			DotTracker_Message("set <#> - "..DotTRACKER_OPTIONS_SET);
			DotTracker_Message("rem <#> <#> - "..DotTRACKER_OPTIONS_REM);
			DotTracker_Message("lvl <#> <#> - "..DotTRACKER_OPTIONS_LVL);
		else
		    DotTracker_Message(DotTRACKER_NOCOMMAND);
		end
		if ( DotTracker_Options_Frame:IsShown() ) then
		    DotTracker_Options_Init();
		end
    else
		DotTracker_Options_Toggle();
    end
end


function DotTracker_ShowSetting(dot, num, name)
	local text, showDot, remindDot, levelDot;

	if ( dot == "A" ) then
		showDot = DotTracker_Setting.showDotA;
		remindDot = DotTracker_Setting.reminderDotA;
		levelDot = DotTracker_Setting.minLevelDotA;
	elseif ( dot == "B" ) then
		showDot = DotTracker_Setting.showDotB;
		remindDot = DotTracker_Setting.reminderDotB;
		levelDot = DotTracker_Setting.minLevelDotB;
	elseif ( dot == "C" ) then
		showDot = DotTracker_Setting.showDotC;
		remindDot = DotTracker_Setting.reminderDotC;
		levelDot = DotTracker_Setting.minLevelDotC;
	end

	text = string.format(num.." - "..name);

	if ( showDot == true ) then
		text = string.format(text.." - on");
	else
		text = string.format(text.." - "..OFF);
	end
	text = string.format(text..", Reminder: %ds", remindDot);
	text = string.format(text..", Min Level: %d", levelDot);
	if ( levelDot == -1 ) then
		text = string.format(text.." <Boss only>");
	end

	return text;
end


function DotTracker_DeathKnightShow()
	local text;

	text = DotTracker_ShowSetting("A", "1", DotTracker_DEATHKNIGHT_DotA);
	DotTracker_Message(text);

	text = DotTracker_ShowSetting("B", "2", DotTracker_DEATHKNIGHT_DotB);
	DotTracker_Message(text);

end


function DotTracker_DruidShow()
	local text;

	text = DotTracker_ShowSetting("A", "1", DotTracker_DRUID_DotA);
	DotTracker_Message(text);

	text = DotTracker_ShowSetting("B", "2", DotTracker_DRUID_DotB);
	DotTracker_Message(text);

	text = DotTracker_ShowSetting("C", "3", DotTracker_DRUID_DotC);
	DotTracker_Message(text);

end


function DotTracker_HunterShow()
	local text;

	text = DotTracker_ShowSetting("A", "1", DotTracker_HUNTER_DotA);
	DotTracker_Message(text);
end


function DotTracker_PaladinShow()
	local text;

	text = DotTracker_ShowSetting("A", "1", DotTracker_PALADIN_DotA);
	DotTracker_Message(text);
end


function DotTracker_PriestShow()
	local text;

	text = DotTracker_ShowSetting("A", "1", DotTracker_PRIEST_DotA);
	DotTracker_Message(text);

	text = DotTracker_ShowSetting("B", "2", DotTracker_PRIEST_DotB);
	DotTracker_Message(text);

	text = DotTracker_ShowSetting("C", "3", DotTracker_PRIEST_DotC);
	DotTracker_Message(text);

end


function DotTracker_ShamanShow()
	local text;

	text = DotTracker_ShowSetting("A", "1", DotTracker_SHAMAN_DotA);
	DotTracker_Message(text);
end


function DotTracker_WarlockShow()
	local text;

	text = DotTracker_ShowSetting("A", "1", DotTracker_WARLOCK_DotA);
	DotTracker_Message(text);

	text = DotTracker_ShowSetting("B", "2", DotTracker_WARLOCK_DotB);
	DotTracker_Message(text);

	text = DotTracker_ShowSetting("C", "3", DotTracker_WARLOCK_DotC);
	DotTracker_Message(text);

end


function DotTracker_WarriorShow()
	local text;

	text = DotTracker_ShowSetting("A", "1", DotTracker_WARRIOR_DotA);
	DotTracker_Message(text);

	text = DotTracker_ShowSetting("B", "2", DotTracker_WARRIOR_DotB);
	DotTracker_Message(text);

end
