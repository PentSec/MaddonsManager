
if ( GetLocale() == "esES" ) then
	DotTracker_DEATHKNIGHT_DotA = "Fiebre de Escarcha";
	DotTracker_DEATHKNIGHT_DotB = "Peste de sangre";

	DotTracker_DRUID_DotA = "Fuego lunar";
	DotTracker_DRUID_DotB = "Fuego fe�rico";
	DotTracker_DRUID_DotBFeral = "Fuego fe�rico (feral)";
	DotTracker_DRUID_DotC = "Enjambre de insectos";

	DotTracker_HUNTER_DotA = "Picadura";	
	DotTracker_HUNTER_DotAScorpid = "Picadura de esc�rpido";
	DotTracker_HUNTER_DotAViper = "Picadura de v�bora";
	DotTracker_HUNTER_DotASerpent = "Picadura de serpiente";

	DotTracker_PALADIN_DotA = "Sentencia";
	DotTracker_PALADIN_DotALight = "Sentencia de Luz";
	DotTracker_PALADIN_DotAWisdom = "Sentencia de sabidur�a";
	DotTracker_PALADIN_DotAJustice = "Sentencia de justicia";

	DotTracker_PRIEST_DotA = "Peste devoradora";
	DotTracker_PRIEST_DotB = "Toque vamp�rico";
	DotTracker_PRIEST_DotC = "Palabra de las Sombras: dolor";

	DotTracker_SHAMAN_DotA = "Choque de llamas";

	DotTracker_WARLOCK_DotA = "Verderbnis";
	DotTracker_WARLOCK_DotB = "Inmolar";

	DotTracker_WARLOCK_DotC = "Maldici�n";
	DotTracker_WARLOCK_DotCAgony = "Maldici�n de agon�a";
	DotTracker_WARLOCK_DotCDoom = "Maldici�n de la fatalidad";
	DotTracker_WARLOCK_DotCElements = "Maldici�n de los Elementos";
	DotTracker_WARLOCK_DotCTongues = "Maldici�n de las lenguas";
	DotTracker_WARLOCK_DotCWeakness = "Maldici�n de debilidad";
	DotTracker_WARLOCK_DotCExhaustion = "Maldici�n de agotamiento";

	DotTracker_WARRIOR_DotA = "Desgarrar";
	DotTracker_WARRIOR_DotB = "armadura";
	DotTracker_WARRIOR_DotBSunder = "Hender armadura";
end