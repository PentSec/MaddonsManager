function DotTracker_Init_Display()
	local junk;

	junk, DotTracker_Dots.class = UnitClass("player");

    if ( not DotTracker_Options.show ) then
        DotTracker_Frame:Hide();
    end
	DotTracker_Options.help = false;
    DotTracker_Frame:SetAlpha(DotTracker_Options.alpha);
	
	DotTracker_New_Version();

	if ( DotTracker_Dots.class == "HUNTER" ) then
		DotTracker_Dots.last_curse_icon = "Interface\\Icons\\Ability_hunter_quickshot";
	elseif ( DotTracker_Dots.class == "PALADIN" ) then
		DotTracker_Dots.last_curse_icon = "Interface\\Icons\\Spell_holy_righteousfury";
	elseif ( DotTracker_Dots.class == "WARLOCK" ) then
		DotTracker_Dots.last_curse_icon = "Interface\\Icons\\Spell_shadow_curseofsargeras";
	end

	DotTracker_Dots.stance = GetShapeshiftForm();
	DotTracker_Dots.spec = GetActiveTalentGroup(false, false);
	DotTracker_ChangeSpec();

	DotTracker_Frame_Size();
	DotTracker_InitReminders();
end


function DotTracker_OnUpdate(self, elapsed)
    local text, classCheck, spec;
	classCheck = false;
	spec = GetActiveTalentGroup(false, false);
	if ( spec == DotTracker_Dots.spec ) then
	else
		DotTracker_Dots.spec = spec;
		DotTracker_ChangeSpec();
	end
	if ( DotTracker_Options.stanceCheck == true ) then
		DotTracker_Dots.stance = GetShapeshiftForm();
	end
	if ( DotTracker_Options.help ) then
		DotTracker_Show_All_DoTs();
	else
		if ( DotTracker_Setting.combatOnly == true ) then
			if ( UnitAffectingCombat("player") == 1 ) then
				classCheck = true;
			end
		else
			classCheck = true;
		end
		if ( DotTracker_Options.showInVehicle == false ) then
			if ( UnitInVehicle("player") == 1 ) then
				classCheck = false;
			end
		end
		if ( UnitCanAttack("player", "target") == nil ) then
			classCheck = false;
		end
		if ( classCheck == true ) then
			DotTracker_ClassCheck();
		else
			DotTracker_DotA_Frame:Hide();
			DotTracker_DotB_Frame:Hide();
			DotTracker_DotC_Frame:Hide();
		end
	end
end


function DotTracker_OnLoad(self)
    SLASH_DotTRACKER1 = "/Dott";
    SlashCmdList["DotTRACKER"] = DotTracker_SlashCommand;
    self:RegisterEvent("VARIABLES_LOADED");
end


function DotTracker_Toggle()
    if ( DotTracker_Frame:IsShown() ) then
        DotTracker_Frame:Hide();
    else
        DotTracker_Frame:Show();
    end
end


function DotTracker_Message(msg)
    DEFAULT_CHAT_FRAME:AddMessage("[DotTracker] "..msg);
end


function DotTracker_OnEnter(self)
    if ( DotTracker_Options.tooltip ) then
        GameTooltip_SetDefaultAnchor(GameTooltip, self);
        GameTooltip:SetText(DotTRACKER_TOOLTIP_TITLE);
        GameTooltip:AddLine(DotTRACKER_TOOLTIP_SUBTITLE);
        if ( DotTracker_Options.lock ) then
            GameTooltip:AddLine(DotTRACKER_TOOLTIP_LOCKED);
        else
            GameTooltip:AddLine(DotTRACKER_TOOLTIP_LEFTCLICK);
        end
        GameTooltip:AddLine(DotTRACKER_TOOLTIP_RIGHTCLICK);
        GameTooltipTextLeft1:SetTextColor(1, 1, 1);
        GameTooltipTextLeft2:SetTextColor(1, 1, 1);
        GameTooltip:Show()
    end
end


function DotTracker_OnEvent(self, event, ...)
    if ( event == "VARIABLES_LOADED" ) then
        DotTracker_Init_Display();
    end
end


