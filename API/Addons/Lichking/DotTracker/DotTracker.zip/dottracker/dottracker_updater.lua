function DotTracker_New_Version()
	if ( DotTracker_Options.version == nil ) then
		DotTracker_Options.version = 0.1;
	end
	if ( DotTracker_Options.version < 1.67 ) then
		DotTracker_Options.text = true;
		DotTracker_Options.widthType = 0;
	end
	if ( DotTracker_Options.version < 1.70 ) then
		DotTracker_Options.minWidth = 50;
	end
	if ( DotTracker_Options.version < 1.71 ) then
		DotTracker_Setting.minLevelDotA = 0;
		DotTracker_Setting.minLevelDotB = 0;
		DotTracker_Setting.minLevelDotC = 0;
	end
	if ( DotTracker_Options.version < 1.79 ) then
		DotTracker_Options.reminderFadeUp = false;
	end
	if ( DotTracker_Options.version < 1.81 ) then
		DotTracker_Options.showInVehicle = false;
	end
	if ( DotTracker_Options.version < 1.83 ) then
		DotTracker_Options.stanceCheck = false;
		DotTracker_StoreSpec(1);
		DotTracker_StoreSpec(2);
	end
	DotTracker_Options.version = DOTTRACKER_VERSION;
end


