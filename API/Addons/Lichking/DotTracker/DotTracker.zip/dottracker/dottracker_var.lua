DOTTRACKER_VERSION = 1.87;

DotTracker_Options = {
	version,
    show = true,
    lock = false,
    tooltip = true,
    alpha = 1,
	help = false,

	widthType = 1,
	text = true,
	minWidth = 50,
	reminderFadeUp = false,
	showInVehicle = false,
	stanceCheck = false
};

DotTracker_Setting = {
	showDotA = true,
	showDotB = true,
	showDotC = true,
	combatOnly = true,
	reminderDotA = 0,
	reminderDotB = 0, 
	reminderDotC = 0,
	minLevelDotA = 0,
	minLevelDotB = 0,
	minLevelDotC = 0
};

DotTracker_Dots = {
	last_curse_icon = "Interface\\Icons\\Spell_shadow_curseofsargeras",
	class,
	textA,
	textB,
	textC,
	remTextA,
	remTextB,
	remTextC,
	lvlTextA,
	lvlTextB,
	lvlTextC,
	stance,
	spec
};

DotTracker_test = 100;

DotTracker_SpecA = {
	widthType = 1,
	text = true,
	minWidth = 50,
	reminderFadeUp = false,
	showInVehicle = false,
	showDotA = true,
	showDotB = true,
	showDotC = true,
	combatOnly = true,
	reminderDotA = 0,
	reminderDotB = 0, 
	reminderDotC = 0,
	minLevelDotA = 0,
	minLevelDotB = 0,
	minLevelDotC = 0,
	stanceCheck = true
};

DotTracker_SpecB = {
	widthType = 1,
	text = true,
	minWidth = 50,
	reminderFadeUp = false,
	showInVehicle = false,
	showDotA = true,
	showDotB = true,
	showDotC = true,
	combatOnly = true,
	reminderDotA = 0,
	reminderDotB = 0, 
	reminderDotC = 0,
	minLevelDotA = 0,
	minLevelDotB = 0,
	minLevelDotC = 0,
	stanceCheck = true
};