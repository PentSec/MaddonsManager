DotTRACKER_ALPHA_WRONG = "Alpha must be between 0 and 1";
DotTRACKER_NOCOMMAND = "That's not an option, type \"/Dott\" for help";
DotTRACKER_USAGE = "Usage: /Dott <option>";

DotTRACKER_OPTIONS_VIS = "Toggle the class window";
DotTRACKER_OPTIONS_LOCK = "Toggle the Lock for all DotTracker windows";
DotTRACKER_OPTIONS_TOOLTIP = "Toggle the tooltip display";
DotTRACKER_OPTIONS_ALPHA = "Set the transparency of the window";

DotTRACKER_TOOLTIP_TITLE = "DotTracker";
DotTRACKER_TOOLTIP_SUBTITLE = "Track temp Dots";
DotTRACKER_TOOLTIP_LOCKED = "Lock";
DotTRACKER_TOOLTIP_LEFTCLICK = "Left-click to move this window.";
DotTRACKER_TOOLTIP_RIGHTCLICK = "Right-click to toggle the setting panel.";

DotTRACKER_OPTIONS_TITLE = "DotTracker Setting Panel";
DotTRACKER_OPTIONS_LEFTCLICK = "Left-click and drag to move this window.";
DotTRACKER_OPTIONS_ALPHALABEL = "Alpha";
DotTRACKER_OPTIONS_DONE = "Done";
DotTRACKER_OPTIONS_SET = "Toggle on/off the Dots to track.";
DotTRACKER_OPTIONS_REM = "Reminder: <buffNumber> <timeInSec>";
DotTracker_OPTIONS_WIDTH = "0: Min, 1: Icon only, 2: Auto, 3: Constant";
DotTracker_OPTIONS_WIDTHA = "0: Min";
DotTracker_OPTIONS_WIDTHB = "1: Icon only";
DotTracker_OPTIONS_WIDTHC = "2: Auto";
DotTracker_OPTIONS_WIDTHD = "3: Constant";
DotTracker_OPTIONS_WIDTHTYPE = "Width Type";

DotTracker_OPTIONS_TEXT = "Text";
DotTracker_OPTIONS_MINWIDTH = "Min Width of the Frame.";
DotTRACKER_OPTIONS_LVL = "Min Level: <buffNumber> <minLevelToShow>, -1 = boss only";

DotTracker_OPTIONS_REMINDER = "Reminder";
DotTracker_OPTIONS_REMINDER_FADE_UP = "Reminder Fade up";

DotTracker_OPTIONS_SHOW_IN_VEHICLE = "Show in Vehicle";
DotTracker_OPTIONS_STANCE_CHECK = "Stance Check";

DotTracker_COMBATONLY = "Display only during combat - ";

DotTracker_DEATHKNIGHT_DotA = "Frost Fever";
DotTracker_DEATHKNIGHT_DotB = "Blood Plague";

DotTracker_DRUID_DotA = "Moonfire";
DotTracker_DRUID_DotB = "Faerie Fire";
DotTracker_DRUID_DotBFeral = "Faerie Fire (Feral)";
DotTracker_DRUID_DotC = "Insect Swarm";

DotTracker_HUNTER_DotA = "Sting";
DotTracker_HUNTER_DotAScorpid = "Scorpid Sting";
DotTracker_HUNTER_DotAViper = "Viper Sting";
DotTracker_HUNTER_DotASerpent = "Serpent Sting";

DotTracker_PALADIN_DotA = "Judgement";
DotTracker_PALADIN_DotALight = "Judgement of Light";
DotTracker_PALADIN_DotAWisdom = "Judgement of Wisdom";
DotTracker_PALADIN_DotAJustice = "Judgement of Justice";

DotTracker_PRIEST_DotA = "Devouring Plague";
DotTracker_PRIEST_DotB = "Vampiric Touch";
DotTracker_PRIEST_DotC = "Shadow Word: Pain";

DotTracker_SHAMAN_DotA = "Flame Shock";

DotTracker_WARLOCK_DotA = "Corruption";
DotTracker_WARLOCK_DotB = "Immolate";
DotTracker_WARLOCK_DotC = "Curse";
DotTracker_WARLOCK_DotCAgony = "Curse of Agony";
DotTracker_WARLOCK_DotCDoom = "Curse of Doom";
DotTracker_WARLOCK_DotCElements = "Curse of the Elements";
DotTracker_WARLOCK_DotCTongues = "Curse of Tongues";
DotTracker_WARLOCK_DotCWeakness = "Curse of Weakness";
DotTracker_WARLOCK_DotCExhaustion = "Curse of Exhaustion";

DotTracker_WARRIOR_DotA = "Rend";
DotTracker_WARRIOR_DotB = "Sunder";
DotTracker_WARRIOR_DotBSunder = "Sunder Armor";
