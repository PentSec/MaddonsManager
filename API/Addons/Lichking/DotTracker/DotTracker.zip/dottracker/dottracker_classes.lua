function DotTracker_ClassShow()
	if ( DotTracker_Dots.class == "DEATHKNIGHT" ) then
		DotTracker_DeathKnightShow();
	elseif ( DotTracker_Dots.class == "DRUID" ) then
		DotTracker_DruidShow();
	elseif ( DotTracker_Dots.class == "HUNTER" ) then
		DotTracker_HunterShow();
	elseif ( DotTracker_Dots.class == "PALADIN" ) then
		DotTracker_PaladinShow();
	elseif ( DotTracker_Dots.class == "PRIEST" ) then
		DotTracker_PriestShow();
	elseif ( DotTracker_Dots.class == "SHAMAN" ) then
		DotTracker_ShamanShow();
	elseif ( DotTracker_Dots.class == "WARLOCK" ) then
		DotTracker_WarlockShow();
	elseif ( DotTracker_Dots.class == "WARRIOR" ) then
		DotTracker_WarriorShow();
	end
end


function DotTracker_ClassCheck()
	if ( DotTracker_Dots.class == "DEATHKNIGHT" ) then
		DotTracker_DeathKnightCheck();
	elseif ( DotTracker_Dots.class == "DRUID" ) then
		DotTracker_DruidCheck();
	elseif ( DotTracker_Dots.class == "HUNTER" ) then
		DotTracker_HunterCheck();
	elseif ( DotTracker_Dots.class == "PALADIN" ) then
		DotTracker_PaladinCheck();
	elseif ( DotTracker_Dots.class == "PRIEST" ) then
		DotTracker_PriestCheck();
	elseif ( DotTracker_Dots.class == "SHAMAN" ) then
		DotTracker_ShamanCheck();
	elseif ( DotTracker_Dots.class == "WARLOCK" ) then
		DotTracker_WarlockCheck();
	elseif ( DotTracker_Dots.class == "WARRIOR" ) then
		DotTracker_WarriorCheck();
	end
end


function DotTracker_Show_All_DoTs()
	if ( DotTracker_Dots.class == "DEATHKNIGHT" ) then
		DotTracker_DotA_Frame:Show();
		DotTracker_DotB_Frame:Show();
	elseif ( DotTracker_Dots.class == "DRUID" ) then
		DotTracker_DotA_Frame:Show();
		DotTracker_DotB_Frame:Show();
		DotTracker_DotC_Frame:Show();
	elseif ( DotTracker_Dots.class == "HUNTER" ) then
		DotTracker_DotA_Frame:Show();
	elseif ( DotTracker_Dots.class == "PALADIN" ) then
		DotTracker_DotA_Frame:Show();
	elseif ( DotTracker_Dots.class == "PRIEST" ) then
		DotTracker_DotA_Frame:Show();
		DotTracker_DotB_Frame:Show();
		DotTracker_DotC_Frame:Show();
	elseif ( DotTracker_Dots.class == "SHAMAN" ) then
		DotTracker_DotA_Frame:Show();
	elseif ( DotTracker_Dots.class == "WARLOCK" ) then
		DotTracker_DotA_Frame:Show();
		DotTracker_DotB_Frame:Show();
		DotTracker_DotC_Frame:Show();
	elseif ( DotTracker_Dots.class == "WARRIOR" ) then
		DotTracker_DotA_Frame:Show();
		DotTracker_DotB_Frame:Show();
	end
end


function DotTracker_InitReminders()
	local iconA = "Interface\\Icons\\Spell_deathknight_frostfever";
	local iconB = "Interface\\Icons\\Spell_deathknight_frostfever";
	local iconC = "Interface\\Icons\\Spell_deathknight_frostfever";

	DotTracker_Dots.textA = " ";
	DotTracker_Dots.textB = " ";
	DotTracker_Dots.textC = " ";

	if ( DotTracker_Dots.class == "DEATHKNIGHT" ) then
		DotTracker_Dots.textA = DotTracker_DEATHKNIGHT_DotA;
		iconA = "Interface\\Icons\\Spell_deathknight_frostfever";
		DotTracker_Dots.textB = DotTracker_DEATHKNIGHT_DotB;
		iconB = "Interface\\Icons\\Spell_deathknight_bloodplague";
		
	elseif ( DotTracker_Dots.class == "DRUID" ) then
		DotTracker_Dots.textA = DotTracker_DRUID_DotA;
		iconA = "Interface\\Icons\\Spell_nature_starfall";
		DotTracker_Dots.textB = DotTracker_DRUID_DotB;
		iconB = "Interface\\Icons\\Spell_nature_faeriefire";
		DotTracker_Dots.textC = DotTracker_DRUID_DotC;
		iconC = "Interface\\Icons\\Spell_nature_insectswarm";
	
	elseif ( DotTracker_Dots.class == "HUNTER" ) then
		DotTracker_Dots.textA = DotTracker_HUNTER_DotA;
		iconA = DotTracker_Dots.last_curse_icon;
	
	elseif ( DotTracker_Dots.class == "PALADIN" ) then
		DotTracker_Dots.textA = DotTracker_PALADIN_DotA;
		iconA = DotTracker_Dots.last_curse_icon;
	
	elseif ( DotTracker_Dots.class == "PRIEST" ) then
		DotTracker_Dots.textA = DotTracker_PRIEST_DotA;
		iconA = "Interface\\Icons\\Spell_shadow_devouringplague";
		DotTracker_Dots.textB = DotTracker_PRIEST_DotB;
		iconB = "Interface\\Icons\\Spell_holy_stoicism";
		DotTracker_Dots.textC = DotTracker_PRIEST_DotC;
		iconC = "Interface\\Icons\\Spell_shadow_shadowwordpain";

	elseif ( DotTracker_Dots.class == "SHAMAN" ) then
		DotTracker_Dots.textA = DotTracker_SHAMAN_DotA;
		iconA = "Interface\\Icons\\Spell_fire_flameshock";

	elseif ( DotTracker_Dots.class == "WARLOCK" ) then
		DotTracker_Dots.textA = DotTracker_WARLOCK_DotA;
		iconA = "Interface\\Icons\\Spell_shadow_abominationexplosion";
		DotTracker_Dots.textB = DotTracker_WARLOCK_DotB;
		iconB = "Interface\\Icons\\Spell_fire_immolation";
		DotTracker_Dots.textC = DotTracker_WARLOCK_DotC;
		iconC = DotTracker_Dots.last_curse_icon;
		
	elseif ( DotTracker_Dots.class == "WARRIOR" ) then
		DotTracker_Dots.textA = DotTracker_WARRIOR_DotA;
		iconA = "Interface\\Icons\\Ability_gouge";
		DotTracker_Dots.textB = DotTracker_WARRIOR_DotB;
		iconB = "Interface\\Icons\\Ability_warrior_sunder";
		
	end

	DotTracker_DotA_Frame_Text:SetText(DotTracker_Dots.textA);
	DotTracker_DotA_Frame_Icon:SetTexture(iconA);			
	DotTracker_DotB_Frame_Text:SetText(DotTracker_Dots.textB);
	DotTracker_DotB_Frame_Icon:SetTexture(iconB);			
	DotTracker_DotC_Frame_Text:SetText(DotTracker_Dots.textC);
	DotTracker_DotC_Frame_Icon:SetTexture(iconC);			
end
