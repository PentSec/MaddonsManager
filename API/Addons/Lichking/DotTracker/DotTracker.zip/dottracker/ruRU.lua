if ( GetLocale() == "ruRU" ) then
DotTRACKER_ALPHA_WRONG = "Прозрачность должна быть между 0 и 1";
DotTRACKER_NOCOMMAND = "Это не параметр настроек, для справки, введите \"/Dott\"";
DotTRACKER_USAGE = "Использование: /Dott <option>";

DotTRACKER_OPTIONS_VIS = "Переключение классового окна";
DotTRACKER_OPTIONS_LOCK = "Переключение блокировки всех окон DotTracker'а";
DotTRACKER_OPTIONS_TOOLTIP = "Переключение отображения подсказки";
DotTRACKER_OPTIONS_ALPHA = "Установка прозрачности окна";

DotTRACKER_TOOLTIP_TITLE = "DotTracker";
DotTRACKER_TOOLTIP_SUBTITLE = "Отслеживание ДоТов";
DotTRACKER_TOOLTIP_LOCKED = "Закрепить";
DotTRACKER_TOOLTIP_LEFTCLICK = "[Левый-Клик] - перемещение окна.";
DotTRACKER_TOOLTIP_RIGHTCLICK = "[Правый-Клик] - переключение панели настроек.";

DotTRACKER_OPTIONS_TITLE = "Панель настроек DotTracker";
DotTRACKER_OPTIONS_LEFTCLICK = "[Левый-Клик+движение] - перемещение окна.";
DotTRACKER_OPTIONS_ALPHALABEL = "Прозрачность";
DotTRACKER_OPTIONS_DONE = "Готово";
DotTRACKER_OPTIONS_SET = "Вкл/выкл отстежывание ДоТов.";
DotTRACKER_OPTIONS_REM = "Напоминание: <buffNumber> <timeInSec>";
DotTracker_OPTIONS_WIDTH = "0: Мин, 1: Только иконка, 2: Авто, 3: Constant";
DotTracker_OPTIONS_WIDTHA = "0: Мин";
DotTracker_OPTIONS_WIDTHB = "1: Только иконка";
DotTracker_OPTIONS_WIDTHC = "2: Авто";
DotTracker_OPTIONS_WIDTHD = "3: Неизменный";
DotTracker_OPTIONS_WIDTHTYPE = "Тип ширины";

DotTracker_OPTIONS_TEXT = "Текст";
DotTracker_OPTIONS_MINWIDTH = "Мин ширина фрейма.";
DotTRACKER_OPTIONS_LVL = "Мин уровень: <buffNumber> <minLevelToShow>, -1 = только для босса";

DotTracker_OPTIONS_REMINDER = "Напоминание";
DotTracker_OPTIONS_REMINDER_FADE_UP = "Плавное появленияе напоминания";

DotTracker_OPTIONS_SHOW_IN_VEHICLE = "Показать в транспорте";
DotTracker_OPTIONS_STANCE_CHECK = "Проверка стойки";

DotTracker_COMBATONLY = "Показывать только в течении боя - ";

DotTracker_DEATHKNIGHT_DotA = "Озноб";
DotTracker_DEATHKNIGHT_DotB = "Кровавая чума";

DotTracker_DRUID_DotA = "Лунный огонь";
DotTracker_DRUID_DotB = "Волшебный огонь";
DotTracker_DRUID_DotBFeral = "Волшебный огонь (зверь)";
DotTracker_DRUID_DotC = "Рой насекомых";

DotTracker_HUNTER_DotA = "Укус";
DotTracker_HUNTER_DotAScorpid = "Укус скорпида";
DotTracker_HUNTER_DotAViper = "Укус гадюки";
DotTracker_HUNTER_DotASerpent = "Укус змеи";

DotTracker_PALADIN_DotA = "Правосудие";
DotTracker_PALADIN_DotALight = "Правосудие света";
DotTracker_PALADIN_DotAWisdom = "Правосудие мудрости";
DotTracker_PALADIN_DotAJustice = "Правосудие справедливости";

DotTracker_PRIEST_DotA = "Всепожирающая чума";
DotTracker_PRIEST_DotB = "Прикосновение вампира";
DotTracker_PRIEST_DotC = "Слово Тьмы: Боль";

DotTracker_SHAMAN_DotA = "Огненный шок";

DotTracker_WARLOCK_DotA = "Порча";
DotTracker_WARLOCK_DotB = "Жертвенный огонь";
DotTracker_WARLOCK_DotC = "Проклятие";
DotTracker_WARLOCK_DotCAgony = "Проклятие агонии";
DotTracker_WARLOCK_DotCDoom = "Проклятие рока";
DotTracker_WARLOCK_DotCElements = "Проклятие стихий";
DotTracker_WARLOCK_DotCTongues = "Проклятие косноязычия";
DotTracker_WARLOCK_DotCWeakness = "Проклятие слабости";
DotTracker_WARLOCK_DotCExhaustion = "Проклятие изнеможения";

DotTracker_WARRIOR_DotA = "Кровопускание";
DotTracker_WARRIOR_DotB = "Раскол";
DotTracker_WARRIOR_DotBSunder = "Раскол брони";
end