
if ( GetLocale() == "frFR" ) then
	DotTracker_DEATHKNIGHT_DotA = "Fi�vre de givre";
	DotTracker_DEATHKNIGHT_DotB = "Peste de sang";

	DotTracker_DRUID_DotA = "Eclat lunaire";
	DotTracker_DRUID_DotB = "Lucioles";
	DotTracker_DRUID_DotBFeral = "Lucioles (farouche)";
	DotTracker_DRUID_DotC = "Essaim d'insectes";

	DotTracker_HUNTER_DotA = "Morsure";	
	DotTracker_HUNTER_DotAScorpid = "Piq�re de scorpide";
	DotTracker_HUNTER_DotAViper = "Morsure de vip�re";
	DotTracker_HUNTER_DotASerpent = "Morsure de serpent";

	DotTracker_PALADIN_DotA = "Jugement";
	DotTracker_PALADIN_DotALight = "Jugement de lumi�re";
	DotTracker_PALADIN_DotAWisdom = "Jugement de sagesse";
	DotTracker_PALADIN_DotAJustice = "Jugement de justice";

	DotTracker_PRIEST_DotA = "Peste d�vorante";
	DotTracker_PRIEST_DotB = "Toucher vampirique";
	DotTracker_PRIEST_DotC = "Mot de l'ombre : Douleur";

	DotTracker_SHAMAN_DotA = "Horion de flammes";

	DotTracker_WARLOCK_DotA = "Corruption";
	DotTracker_WARLOCK_DotB = "Immolation";

	DotTracker_WARLOCK_DotC = "Mal�diction";
	DotTracker_WARLOCK_DotCAgony = "Mal�diction d'agonie";
	DotTracker_WARLOCK_DotCDoom = "Mal�diction funeste";
	DotTracker_WARLOCK_DotCElements = "Mal�diction des �l�ments";
	DotTracker_WARLOCK_DotCTongues = "Mal�diction des langages";
	DotTracker_WARLOCK_DotCWeakness = "Mal�diction de faiblesse";
	DotTracker_WARLOCK_DotCExhaustion = "Mal�diction d'�puisement";

	DotTracker_WARRIOR_DotA = "Pourfendre";
	DotTracker_WARRIOR_DotB = "armure";
	DotTracker_WARRIOR_DotBSunder = "Fracasser armure";
end