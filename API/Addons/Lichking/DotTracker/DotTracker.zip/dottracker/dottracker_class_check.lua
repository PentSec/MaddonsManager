function DotTracker_PreCheck(dot, targetLevel)
	local show, minLevel;

	if ( dot == "A" ) then
		show = DotTracker_Setting.showDotA;
		minLevel = DotTracker_Setting.minLevelDotA;
	elseif ( dot == "B" ) then
		show = DotTracker_Setting.showDotB;
		minLevel = DotTracker_Setting.minLevelDotB;
	elseif ( dot == "C" ) then
		show = DotTracker_Setting.showDotC;
		minLevel = DotTracker_Setting.minLevelDotC;
	end

	if ( targetLevel > -1 ) then
		if ( targetLevel < minLevel ) then
			show = false;
		end
		if ( minLevel == -1 ) then
			show = false;
		end
	end

	return show;
end


function DotTracker_ReminderCheck(text, reminderDot, expires, duration)
	local displayDot, alpha, timeleft;

	displayDot = false;
	timeleft = expires - GetTime();
	alpha = 1;

	if ( reminderDot > duration ) then
		reminderDot = duration;
	end

	if ( reminderDot > timeleft ) then
		displayDot = true;
		text = string.format(text.." - %ds", timeleft);
		if ( DotTracker_Options.reminderFadeUp == true ) then
			alpha = 1 - (1 / (reminderDot / timeleft));
		end
	end

	if ( alpha > 1 ) then
		alpha = 1;
	elseif ( alpha < 0 ) then
		alpha = 0;
	end
	return displayDot, alpha, text, reminderDot;
end


function DotTracker_DeathKnightCheck()
	local name, rank, icon, count, dispeltype, duration, expires, caster, isStealable;
	local text, displayDot, timeleft, show, targetLevel, alpha;

	targetLevel = UnitLevel("target");
	alpha = 1;

	show = DotTracker_PreCheck("A", targetLevel);
	if ( show == true ) then
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_DEATHKNIGHT_DotA);
		text = DotTracker_DEATHKNIGHT_DotA;
		if ( count == nil ) then
			displayDot = true;			
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotA = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotA, expires, duration);
			else
				displayDot = true;
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotA_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotA_Frame_Text:SetText(text);
			else
				DotTracker_DotA_Frame_Text:SetText(" ");
			end
			DotTracker_DotA_Frame:SetAlpha(alpha);			
		else
			DotTracker_DotA_Frame:Hide();
		end
	end

	alpha = 1
	show = DotTracker_PreCheck("B", targetLevel);
	if ( show == true ) then
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_DEATHKNIGHT_DotB);
		text = DotTracker_DEATHKNIGHT_DotB;
		if ( count == nil ) then
			displayDot = true;			
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotB = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotB, expires, duration);
			else
				displayDot = true;
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotB_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotB_Frame_Text:SetText(text);
			else
				DotTracker_DotB_Frame_Text:SetText(" ");
			end
			DotTracker_DotB_Frame:SetAlpha(alpha);			
		else
			DotTracker_DotB_Frame:Hide();
		end
	end
end


function DotTracker_DruidCheck()
	local name, rank, icon, count, dispeltype, duration, expires, caster, isStealable;
	local text, displayDot, timeleft, show, targetLevel, alpha;

	targetLevel = UnitLevel("target");
	alpha = 1;

	show = DotTracker_PreCheck("A", targetLevel);
	if ( show == true ) then
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_DRUID_DotA);
		text = DotTracker_DRUID_DotA;
		if ( count == nil ) then
			displayDot = true;			
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotA = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotA, expires, duration);
			else
				displayDot = true;
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotA_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotA_Frame_Text:SetText(text);
			else
				DotTracker_DotA_Frame_Text:SetText(" ");
			end
			DotTracker_DotA_Frame:SetAlpha(alpha);			
		else
			DotTracker_DotA_Frame:Hide();
		end
	end

	alpha = 1;
	show = DotTracker_PreCheck("B", targetLevel);
	if ( show == true ) then
		displayDot = true;
		text = DotTracker_DRUID_DotB;
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_DRUID_DotB);
		if ( count == nil ) then
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotB = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotB, expires, duration);
			end
		end
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_DRUID_DotBFeral);
		if ( count == nil ) then
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotB = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotB, expires, duration);
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotB_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotB_Frame_Text:SetText(text);
			else
				DotTracker_DotB_Frame_Text:SetText(" ");
			end
			DotTracker_DotB_Frame:SetAlpha(alpha);		
		else
			DotTracker_DotB_Frame:Hide();
		end
	end

	alpha = 1;
	show = DotTracker_PreCheck("C", targetLevel);
	if ( show == true ) then
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_DRUID_DotC);
		text = DotTracker_DRUID_DotC;
		if ( count == nil ) then
			displayDot = true;			
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotC = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotC, expires, duration);
			else
				displayDot = true;
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotC_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotC_Frame_Text:SetText(text);
			else
				DotTracker_DotC_Frame_Text:SetText(" ");
			end
			DotTracker_DotC_Frame:SetAlpha(alpha);			
		else
			DotTracker_DotC_Frame:Hide();
		end
	end
end


function DotTracker_HunterCheck()
	local name, rank, icon, count, dispeltype, duration, expires, caster, isStealable;
	local text, displayDot, timeleft, show, targetLevel, alpha;

	targetLevel = UnitLevel("target");
	alpha = 1;

	show = DotTracker_PreCheck("A", targetLevel);
	if ( show == true ) then
		displayDot = true;
		text = DotTracker_HUNTER_DotA;
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_HUNTER_DotAScorpid);
		if ( count == nil ) then
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotA = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotA, expires, duration);
			end
		end
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_HUNTER_DotAViper);
		if ( count == nil ) then
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotA = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotA, expires, duration);
			end
		end
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_HUNTER_DotASerpent);
		if ( count == nil ) then
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotA = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotA, expires, duration);
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotA_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotA_Frame_Text:SetText(text);
			else
				DotTracker_DotA_Frame_Text:SetText(" ");
			end
			DotTracker_DotA_Frame_Icon:SetTexture(DotTracker_Dots.last_curse_icon);
			DotTracker_DotA_Frame:SetAlpha(alpha);
		else
			DotTracker_DotA_Frame:Hide();
		end
	end
end


function DotTracker_PaladinCheck()
	local name, rank, icon, count, dispeltype, duration, expires, caster, isStealable;
	local text, displayDot, timeleft, show, targetLevel, alpha;

	targetLevel = UnitLevel("target");
	alpha = 1;

	show = DotTracker_PreCheck("A", targetLevel);
	if ( show == true ) then
		displayDot = true;
		text = DotTracker_PALADIN_DotA;
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_PALADIN_DotALight);
		if ( count == nil ) then
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotA = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotA, expires, duration);
			end
		end
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_PALADIN_DotAWisdom);
		if ( count == nil ) then
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotA = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotA, expires, duration);
			end
		end
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_PALADIN_DotAJustice);
		if ( count == nil ) then
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotA = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotA, expires, duration);
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotA_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotA_Frame_Text:SetText(text);
			else
				DotTracker_DotA_Frame_Text:SetText(" ");
			end
			DotTracker_DotA_Frame_Icon:SetTexture(DotTracker_Dots.last_curse_icon);
			DotTracker_DotA_Frame:SetAlpha(alpha);			
		else
			DotTracker_DotA_Frame:Hide();
		end
	end
end


function DotTracker_PriestCheck()
	local name, rank, icon, count, dispeltype, duration, expires, caster, isStealable;
	local text, displayDot, timeleft, show, targetLevel, alpha;

	targetLevel = UnitLevel("target");
	alpha = 1;

	show = DotTracker_PreCheck("A", targetLevel);
	if ( show == true ) then
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_PRIEST_DotA);
		text = DotTracker_PRIEST_DotA;
		if ( count == nil ) then
			displayDot = true;			
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotA = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotA, expires, duration);
			else
				displayDot = true;
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotA_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotA_Frame_Text:SetText(text);
			else
				DotTracker_DotA_Frame_Text:SetText(" ");
			end
			DotTracker_DotA_Frame:SetAlpha(alpha);			
		else
			DotTracker_DotA_Frame:Hide();
		end
	end

	alpha = 1;
	show = DotTracker_PreCheck("B", targetLevel);
	if ( show == true ) then
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_PRIEST_DotB);
		text = DotTracker_PRIEST_DotB;
		if ( count == nil ) then
			displayDot = true;			
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotB = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotB, expires, duration);
			else
				displayDot = true;
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotB_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotB_Frame_Text:SetText(text);
			else
				DotTracker_DotB_Frame_Text:SetText(" ");
			end
			DotTracker_DotB_Frame:SetAlpha(alpha);		
		else
			DotTracker_DotB_Frame:Hide();
		end
	end

	alpha = 1;
	show = DotTracker_PreCheck("C", targetLevel);
	if ( show == true ) then
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_PRIEST_DotC);
		text = DotTracker_PRIEST_DotC;
		if ( count == nil ) then
			displayDot = true;			
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotC = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotC, expires, duration);
			else
				displayDot = true;
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotC_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotC_Frame_Text:SetText(text);
			else
				DotTracker_DotC_Frame_Text:SetText(" ");
			end
			DotTracker_DotC_Frame:SetAlpha(alpha);
		else
			DotTracker_DotC_Frame:Hide();
		end
	end
end


function DotTracker_ShamanCheck()
	local name, rank, icon, count, dispeltype, duration, expires, caster, isStealable;
	local text, displayDot, timeleft, show, targetLevel, alpha;

	targetLevel = UnitLevel("target");
	alpha = 1;

	show = DotTracker_PreCheck("A", targetLevel);
	if ( show == true ) then
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_SHAMAN_DotA);
		text = DotTracker_SHAMAN_DotA;
		if ( count == nil ) then
			displayDot = true;			
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotA = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotA, expires, duration);
			else
				displayDot = true;
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotA_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotA_Frame_Text:SetText(text);
			else
				DotTracker_DotA_Frame_Text:SetText(" ");
			end
			DotTracker_DotA_Frame:SetAlpha(alpha);
		else
			DotTracker_DotA_Frame:Hide();
		end
	end
end


function DotTracker_WarlockCheck()
	local name, rank, icon, count, dispeltype, duration, expires, caster, isStealable;
	local text, displayDot, timeleft, show, targetLevel, alpha;

	targetLevel = UnitLevel("target");
	alpha = 1;

	show = DotTracker_PreCheck("A", targetLevel);
	if ( show == true ) then
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_WARLOCK_DotA);
		text = DotTracker_WARLOCK_DotA;
		if ( count == nil ) then
			displayDot = true;			
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotA = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotA, expires, duration);
			else
				displayDot = true;
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotA_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotA_Frame_Text:SetText(text);
			else
				DotTracker_DotA_Frame_Text:SetText(" ");
			end
			DotTracker_DotA_Frame:SetAlpha(alpha);		
		else
			DotTracker_DotA_Frame:Hide();
		end
	end

	alpha = 1;
	show = DotTracker_PreCheck("B", targetLevel);
	if ( show == true ) then
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_WARLOCK_DotB);
		text = DotTracker_WARLOCK_DotB;
		if ( count == nil ) then
			displayDot = true;			
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotB = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotB, expires, duration);
			else
				displayDot = true;
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotB_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotB_Frame_Text:SetText(text);
			else
				DotTracker_DotB_Frame_Text:SetText(" ");
			end
			DotTracker_DotB_Frame:SetAlpha(alpha);			
		else
			DotTracker_DotB_Frame:Hide();
		end
	end

	alpha = 1;
	show = DotTracker_PreCheck("C", targetLevel);
	if ( show == true ) then
		displayDot = true;
		text = DotTracker_WARLOCK_DotC;
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_WARLOCK_DotCAgony);
		if ( count == nil ) then
		else
			if ( caster == "player" ) then
				DotTracker_Dots.last_curse_icon = "Interface\\Icons\\Spell_shadow_curseofsargeras";
				displayDot, alpha, text, DotTracker_Setting.reminderDotC = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotC, expires, duration);
			end
		end
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_WARLOCK_DotCDoom);
		if ( count == nil ) then
		else
			if ( caster == "player" ) then
				displayDot = false;
				DotTracker_Dots.last_curse_icon = "Interface\\Icons\\Spell_shadow_auraofdarkness";
			end
		end
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_WARLOCK_DotCElements);
		if ( count == nil ) then
		else
			if ( caster == "player" ) then
				DotTracker_Dots.last_curse_icon = "Interface\\Icons\\Spell_shadow_chilltouch";
				displayDot, alpha, text, DotTracker_Setting.reminderDotC = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotC, expires, duration);
			end
		end
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_WARLOCK_DotCTongues);
		if ( count == nil ) then
		else
			if ( caster == "player" ) then
				DotTracker_Dots.last_curse_icon = "Interface\\Icons\\Spell_shadow_curseoftounges";
				displayDot, alpha, text, DotTracker_Setting.reminderDotC = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotC, expires, duration);
			end
		end
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_WARLOCK_DotCWeakness);
		if ( count == nil ) then
		else
			if ( caster == "player" ) then
				DotTracker_Dots.last_curse_icon = "Interface\\Icons\\Spell_shadow_curseofmannoroth";
				displayDot, alpha, text, DotTracker_Setting.reminderDotC = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotC, expires, duration);
			end
		end
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_WARLOCK_DotCExhaustion);
		if ( count == nil ) then
		else
			if ( caster == "player" ) then
				DotTracker_Dots.last_curse_icon = "Interface\\Icons\\Spell_shadow_grimward";
				displayDot, alpha, text, DotTracker_Setting.reminderDotC = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotC, expires, duration);
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotC_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotC_Frame_Text:SetText(text);
			else
				DotTracker_DotC_Frame_Text:SetText(" ");
			end
			DotTracker_DotC_Frame_Icon:SetTexture(DotTracker_Dots.last_curse_icon);	
			DotTracker_DotC_Frame:SetAlpha(alpha);		
		else
			DotTracker_DotC_Frame:Hide();
		end
	end
end


function DotTracker_WarriorCheck()
	local name, rank, icon, count, dispeltype, duration, expires, caster, isStealable;
	local text, sunderNeeded, displayDot, timeleft, show, targetLevel, alpha;

	targetLevel = UnitLevel("target");
	alpha = 1;

	show = DotTracker_PreCheck("A", targetLevel);
	if ( DotTracker_Options.stanceCheck == true ) then
		if ( DotTracker_Dots.stance == 3 ) then
			show = false;
		end
	end
	if ( show == true ) then
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_WARRIOR_DotA);
		text = DotTracker_WARRIOR_DotA;
		if ( count == nil ) then
			displayDot = true;			
		else
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotA = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotA, expires, duration);
			else
				displayDot = true;
			end
		end
		if ( displayDot == true ) then
			DotTracker_DotA_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotA_Frame_Text:SetText(text);
			else
				DotTracker_DotA_Frame_Text:SetText(" ");
			end
			DotTracker_DotA_Frame:SetAlpha(alpha);		
		else
			DotTracker_DotA_Frame:Hide();
		end
	end

	alpha = 1;

	show = DotTracker_PreCheck("B", targetLevel);
	if ( show == true ) then
		name, rank, icon, count, dispeltype, duration, expires, caster, isStealable = UnitDebuff("target", DotTracker_WARRIOR_DotBSunder);
		if ( count == nil ) then
			displayDot = true;
			text = string.format("5 "..DotTracker_WARRIOR_DotB);
		elseif ( count < 5 ) then
			displayDot = true;
			sunderNeeded = 5 - count;
			text = string.format("%d "..DotTracker_WARRIOR_DotB, sunderNeeded);
			if ( caster == "player" ) then
				timeleft = expires - GetTime();
				if ( DotTracker_Setting.reminderDotB > timeleft ) then
					text = string.format(text.." - %ds", timeleft);
					displayDot = true;
				end
			end
		else
			text = DotTracker_WARRIOR_DotB;
			if ( caster == "player" ) then
				displayDot, alpha, text, DotTracker_Setting.reminderDotB = DotTracker_ReminderCheck(text, DotTracker_Setting.reminderDotB, expires, duration);
			end
		end

		if ( displayDot == true ) then
			DotTracker_DotB_Frame:Show();
			if ( DotTracker_Options.text == true ) then
				DotTracker_DotB_Frame_Text:SetText(text);
			else
				DotTracker_DotB_Frame_Text:SetText(" ");
			end
			DotTracker_DotB_Frame:SetAlpha(alpha);		
		else
			DotTracker_DotB_Frame:Hide();
		end
	end
end


