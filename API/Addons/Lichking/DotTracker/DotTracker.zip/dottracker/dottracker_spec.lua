function DotTracker_ChangeSpec()
	if ( DotTracker_Dots.spec == 1 ) then
		DotTracker_Options.widthType = DotTracker_SpecA.widthType;
		DotTracker_Options.text = DotTracker_SpecA.text;
		DotTracker_Options.minWidth = DotTracker_SpecA.minWidth;
		DotTracker_Options.reminderFadeUp = DotTracker_SpecA.reminderFadeUp;
		DotTracker_Options.showInVehicle = DotTracker_SpecA.showInVehicle;
		DotTracker_Options.stanceCheck = DotTracker_SpecA.stanceCheck;

		DotTracker_Setting.showDotA = DotTracker_SpecA.showDotA;
		DotTracker_Setting.showDotB = DotTracker_SpecA.showDotB;
		DotTracker_Setting.showDotC = DotTracker_SpecA.showDotC;
		DotTracker_Setting.combatOnly = DotTracker_SpecA.combatOnly;
		DotTracker_Setting.reminderDotA = DotTracker_SpecA.reminderDotA;
		DotTracker_Setting.reminderDotB = DotTracker_SpecA.reminderDotB;
		DotTracker_Setting.reminderDotC = DotTracker_SpecA.reminderDotC;
		DotTracker_Setting.minLevelDotA = DotTracker_SpecA.minLevelDotA;
		DotTracker_Setting.minLevelDotB = DotTracker_SpecA.minLevelDotB;
		DotTracker_Setting.minLevelDotC = DotTracker_SpecA.minLevelDotC;

	elseif ( DotTracker_Dots.spec == 2 ) then
		DotTracker_Options.widthType = DotTracker_SpecB.widthType;
		DotTracker_Options.text = DotTracker_SpecB.text;
		DotTracker_Options.minWidth = DotTracker_SpecB.minWidth;
		DotTracker_Options.reminderFadeUp = DotTracker_SpecB.reminderFadeUp;
		DotTracker_Options.showInVehicle = DotTracker_SpecB.showInVehicle;
		DotTracker_Options.stanceCheck = DotTracker_SpecB.stanceCheck;

		DotTracker_Setting.showDotA = DotTracker_SpecB.showDotA;
		DotTracker_Setting.showDotB = DotTracker_SpecB.showDotB;
		DotTracker_Setting.showDotC = DotTracker_SpecB.showDotC;
		DotTracker_Setting.combatOnly = DotTracker_SpecB.combatOnly;
		DotTracker_Setting.reminderDotA = DotTracker_SpecB.reminderDotA;
		DotTracker_Setting.reminderDotB = DotTracker_SpecB.reminderDotB;
		DotTracker_Setting.reminderDotC = DotTracker_SpecB.reminderDotC;
		DotTracker_Setting.minLevelDotA = DotTracker_SpecB.minLevelDotA;
		DotTracker_Setting.minLevelDotB = DotTracker_SpecB.minLevelDotB;
		DotTracker_Setting.minLevelDotC = DotTracker_SpecB.minLevelDotC;
	end
	DotTracker_Frame_Size();
end


function DotTracker_StoreSpec(spec)
	if ( spec == 1 ) then
		DotTracker_SpecA.widthType = DotTracker_Options.widthType;
		DotTracker_SpecA.text = DotTracker_Options.text;
		DotTracker_SpecA.minWidth = DotTracker_Options.minWidth;
		DotTracker_SpecA.reminderFadeUp = DotTracker_Options.reminderFadeUp;
		DotTracker_SpecA.showInVehicle = DotTracker_Options.showInVehicle;
		DotTracker_SpecA.stanceCheck = DotTracker_Options.stanceCheck;

		DotTracker_SpecA.showDotA = DotTracker_Setting.showDotA;
		DotTracker_SpecA.showDotB = DotTracker_Setting.showDotB;
		DotTracker_SpecA.showDotC = DotTracker_Setting.showDotC;
		DotTracker_SpecA.combatOnly = DotTracker_Setting.combatOnly;
		DotTracker_SpecA.reminderDotA = DotTracker_Setting.reminderDotA;
		DotTracker_SpecA.reminderDotB = DotTracker_Setting.reminderDotB;
		DotTracker_SpecA.reminderDotC = DotTracker_Setting.reminderDotC;
		DotTracker_SpecA.minLevelDotA = DotTracker_Setting.minLevelDotA;
		DotTracker_SpecA.minLevelDotB = DotTracker_Setting.minLevelDotB;
		DotTracker_SpecA.minLevelDotC = DotTracker_Setting.minLevelDotC;

	elseif ( spec == 2 ) then
		DotTracker_SpecB.widthType = DotTracker_Options.widthType;
		DotTracker_SpecB.text = DotTracker_Options.text;
		DotTracker_SpecB.minWidth = DotTracker_Options.minWidth;
		DotTracker_SpecB.reminderFadeUp = DotTracker_Options.reminderFadeUp;
		DotTracker_SpecB.showInVehicle = DotTracker_Options.showInVehicle;
		DotTracker_SpecB.stanceCheck = DotTracker_Options.stanceCheck;

		DotTracker_SpecB.showDotA = DotTracker_Setting.showDotA;
		DotTracker_SpecB.showDotB = DotTracker_Setting.showDotB;
		DotTracker_SpecB.showDotC = DotTracker_Setting.showDotC;
		DotTracker_SpecB.combatOnly = DotTracker_Setting.combatOnly;
		DotTracker_SpecB.reminderDotA = DotTracker_Setting.reminderDotA;
		DotTracker_SpecB.reminderDotB = DotTracker_Setting.reminderDotB;
		DotTracker_SpecB.reminderDotC = DotTracker_Setting.reminderDotC;
		DotTracker_SpecB.minLevelDotA = DotTracker_Setting.minLevelDotA;
		DotTracker_SpecB.minLevelDotB = DotTracker_Setting.minLevelDotB;
		DotTracker_SpecB.minLevelDotC = DotTracker_Setting.minLevelDotC;
	end
end