AptusAuraFrames = LibStub("AceAddon-3.0"):NewAddon("AptusAuraFrames", "AceConsole-3.0", "AceEvent-3.0")


aaf_options = {}
local groups;
local dontsavedamit
local aaf_positions;
local class = select(2, UnitClass("player"));
local name = UnitName('player');
local classcolor = RAID_CLASS_COLORS[class];
local active = {}
AptusAuraFrames.bars = {}
AptusAuraFrames.frames = {}

local timer, Update;

local defaults = {
	profile = {
	}
}

-- local defaults = {
    -- profile = {
		-- frames = {
		local frames = {
			{
				timers = true,
				name = "Player Buffs",
				GrowthDirection = "LEFT",
				LineGrowth = "DOWN",
				Padding = 4,  
				LinePadding = 4,
				Mode = "ICON", 
				ModeNum = 1,
				BuffsPerRow = 8, 
				size = 20,
				scale = 1.2,
				unitId = 'player',
				unitIdNum = 1,
				caster = 'all',
				filter = 'BUFF',
				NumBars = 16,
				timer = {
					point = "TOP",
					relativePoint = "BOTTOM",
					offsetX = "0",
					offsetY = "0",
				},
				counts = true,
				count = {
					point = "TOP",
					relativePoint = "BOTTOM",
					offsetX = "7",
					offsetY = "9",
				},
				sortby = 'INDEX'
			},
			{
				name = "Player Debuffs",
				GrowthDirection = "LEFT",
				LineGrowth = "DOWN",
				Padding = 4,
				LinePadding = 4,
				Mode = "ICON",
				ModeNum = 1,
				BuffsPerRow = 8,
				size = 20,
				scale = 1.2,
				unitId = 'player',
				unitIdNum = 1,
				caster = 'all',
				filter = 'DEBUFF',
				NumBars = 12,
				timer = {
					point = "TOP",
					relativePoint = "BOTTOM",
					offsetX = "0",
					offsetY = "0",
				},
				counts = true,
				count = {
					point = "TOP",
					relativePoint = "BOTTOM",
					offsetX = "7",
					offsetY = "9",
				},
				sortby = 'INDEX'
			},
			{
				name = "My Debuffs on Target",
				GrowthDirection = "LEFT",
				LineGrowth = "DOWN",
				Padding = 4,
				LinePadding = 4,
				Mode = "ICON",
				ModeNum = 1,
				size = 20,
				scale = 1.2,
				unitId = 'target',
				unitIdNum = 2,
				caster = 'player',
				filter = 'DEBUFF',
				NumBars = 5,
				timer = {
					point = "TOP",
					relativePoint = "BOTTOM",
					offsetX = "0",
					offsetY = "0",
				},
				counts = true,
				count = {
					point = "TOP",
					relativePoint = "BOTTOM",
					offsetX = "7",
					offsetY = "9",
				},
				sortby = 'INDEX'
			},
			{
				name = "Target Buffs",
				GrowthDirection = "LEFT",
				LineGrowth = "DOWN",
				Padding = 4,
				LinePadding = 4,
				Mode = "ICON",
				ModeNum = 1,
				NumBars = 9,
				size = 20,
				scale = 0.9,
				unitId = 'target',
				unitIdNum = 2,
				caster = 'all', 
				filter = 'BUFF',
				timer = {
					point = "TOP",
					relativePoint = "BOTTOM",
					offsetX = "0",
					offsetY = "0",
				},
				counts = true,
				count = {
					point = "TOP",
					relativePoint = "BOTTOM",
					offsetX = "7",
					offsetY = "9",
				},
				sortby = 'INDEX'
			},
			{
				name = "Pet Buffs",
				GrowthDirection = "RIGHT",
				LineGrowth = "DOWN",
				Padding = 4,
				LinePadding = 4,
				Mode = "ICON",
				ModeNum = 1,
				size = 20,
				scale = 0.9,
				unitId = 'pet',
				unitIdNum = 4,
				caster = 'all',
				filter = 'BUFF',
				NumBars = 9,
				Blacklist = {
					"Heroic Presence",
					"Spirit Bond",
					"Kindred Spirits",
					"Ferocious Inspiration",
				},
				timer = {
					point = "TOP",
					relativePoint = "BOTTOM",
					offsetX = "0",
					offsetY = "0",
				},
				counts = true,
				count = {
					point = "TOP",
					relativePoint = "BOTTOM",
					offsetX = "7",
					offsetY = "9",
				},
				sortby = 'INDEX'
			},
			{
				name = "Pet Debuffs",
				GrowthDirection = "RIGHT",
				LineGrowth = "DOWN",
				Padding = 4,
				LinePadding = 4,
				Mode = "ICON",
				ModeNum = 1,
				size = 20,
				scale = 0.9,
				unitId = 'pet',
				unitIdNum = 4,
				caster = 'all',
				filter = 'DEBUFF',
				NumBars = 6,
				timer = {
					point = "TOP",
					relativePoint = "BOTTOM",
					offsetX = "0",
					offsetY = "0",
				},
				counts = true,
				count = {
					point = "TOP",
					relativePoint = "BOTTOM",
					offsetX = "7",
					offsetY = "9",
				},
				sortby = 'INDEX'
			}
		}
	-- }
-- }

function AptusAuraFrames:OnInitialize()
	-- local AceGUI = LibStub("AceGUI-3.0")
	AptusAuraFrames.db = LibStub("AceDB-3.0"):New("aAFDB", defaults)
	if not AptusAuraFrames['db']['profile']['frames'] then
		AptusAuraFrames['db']['profile']['frames'] = frames
	end
	UpdateOptions()
	LibStub("AceConfig-3.0"):RegisterOptionsTable("AptusAuraFrames", aaf_options, {"AptusAuraFrames"})
	self:RegisterChatCommand("aaf", "ChatCommand")
	-- self:RegisterChatCommand("print", "Print")
	self.optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("AptusAuraFrames", "AptusAuraFrames")
	self.db.RegisterCallback(self, "OnProfileChanged", function() dontsavedamit = true ReloadUI() end)
	self.db.RegisterCallback(self, "OnProfileCopied", function() dontsavedamit = true ReloadUI() end)
	self.db.RegisterCallback(self, "OnProfileReset", function() dontsavedamit = true ReloadUI() end)
end

function UpdateOptions()
	wipe(aaf_options)
	aaf_options.name = "AptusAuraFrames"
	aaf_options.childGroups = "tree"
	aaf_options.handler = AptusAuraFrames
	aaf_options.type = 'group'
	aaf_options.args = {}
	
	local args = {}
	
	args.NewBar = {}
	args.NewBar.name = "New Bar"
	args.NewBar.type = 'input'
	args.NewBar.set = function(info, key) AptusAuraFrames:NewBar(key) end
	args.NewBar.width = 'half'
	
	for a,v in pairs(AptusAuraFrames['db']['profile']['frames']) do
		-- local a = v.name
		args['Bar'..a] = {}
		args['Bar'..a].name = v.name
		args['Bar'..a].order = 2
		args['Bar'..a].type = 'group'
		args['Bar'..a].args = {}
		
		args['Bar'..a].args.General = {}
		args['Bar'..a].args.General.name = 'General'
		args['Bar'..a].args.General.order = 2
		args['Bar'..a].args.General.type = 'header'
		
		args['Bar'..a].args.Delete = {}
		args['Bar'..a].args.Delete.name = 'Delete'
		args['Bar'..a].args.Delete.desc = 'Delete this bar'
		args['Bar'..a].args.Delete.order = 1
		args['Bar'..a].args.Delete.type = 'execute'
		args['Bar'..a].args.Delete.confirm = true
		args['Bar'..a].args.Delete.confirmText = 'Are you sure?'
		args['Bar'..a].args.Delete.func = function()
			for k,val in pairs(AptusAuraFrames.frames) do
				-- print(v.name, val.name)
				if v.name == val.name then
					val:Hide()
					val:UnregisterEvent("UNIT_AURA");
					val:UnregisterEvent("PLAYER_REGEN_ENABLED")
					val:UnregisterEvent("PLAYER_REGEN_DISABLED")
					val:UnregisterEvent("PLAYER_TARGET_CHANGED");
					val:UnregisterEvent("PLAYER_ENTERING_WORLD");
					val.name = nil
				end
			end
			table.remove(AptusAuraFrames['db']['profile']['frames'], a) 
			UpdateOptions()  
		end
		
		args['Bar'..a].args.FrameUnit = {}
		args['Bar'..a].args.FrameUnit.name = 'Frame Unit'
		args['Bar'..a].args.FrameUnit.type = 'select'
		args['Bar'..a].args.FrameUnit.style = 'radio'
		args['Bar'..a].args.FrameUnit.order = 3
		args['Bar'..a].args.FrameUnit.width = 'half'
		args['Bar'..a].args.FrameUnit.values = { 'player', 'target', 'focus', 'pet' }
		args['Bar'..a].args.FrameUnit.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['unitIdNum'] end
		args['Bar'..a].args.FrameUnit.set = function(info,key) AptusAuraFrames['db']['profile']['frames'][a]['unitId'] = args['Bar'..a]['args']['FrameUnit']['values'][key] AptusAuraFrames['db']['profile']['frames'][a]['unitIdNum'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.Mode = {}
		args['Bar'..a].args.Mode.name = 'Mode'
		args['Bar'..a].args.Mode.type = 'select'
		args['Bar'..a].args.Mode.style = 'radio'
		args['Bar'..a].args.Mode.order = 4
		args['Bar'..a].args.Mode.width = 'half'
		args['Bar'..a].args.Mode.values = { 'ICON' }
		args['Bar'..a].args.Mode.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['ModeNum'] end
		args['Bar'..a].args.Mode.set = function(info,key) AptusAuraFrames['db']['profile']['frames'][a]['ModeNum'] = key AptusAuraFrames['db']['profile']['frames'][a]['Mode'] = args['Bar'..a]['args']['Mode']['values'][key] UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.sortby = {}
		args['Bar'..a].args.sortby.name = 'Sort By'
		args['Bar'..a].args.sortby.type = 'select'
		args['Bar'..a].args.sortby.style = 'radio'
		args['Bar'..a].args.sortby.order = 6
		args['Bar'..a].args.sortby.width = 'half'
		args['Bar'..a].args.sortby.values = { 'INDEX', 'DURATION' }
		args['Bar'..a].args.sortby.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['sortbyNum'] end
		args['Bar'..a].args.sortby.set = function(info,key) AptusAuraFrames['db']['profile']['frames'][a]['sortbyNum'] = key AptusAuraFrames['db']['profile']['frames'][a]['sortby'] = args['Bar'..a]['args']['sortby']['values'][key] UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.Reverse = {}
		args['Bar'..a].args.Reverse.type = 'toggle'
		args['Bar'..a].args.Reverse.name = 'Reverse'
		args['Bar'..a].args.Reverse.order = 7
		args['Bar'..a].args.Reverse.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['Reverse'] end
		args['Bar'..a].args.Reverse.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['Reverse'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.Filter = {}
		args['Bar'..a].args.Filter.name = 'Aura Type'
		args['Bar'..a].args.Filter.type = 'select'
		args['Bar'..a].args.Filter.style = 'radio'
		args['Bar'..a].args.Filter.order = 5
		args['Bar'..a].args.Filter.width = 'half'
		args['Bar'..a].args.Filter.values = { 'BUFF', 'DEBUFF' }
		args['Bar'..a].args.Filter.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['filterNum'] end
		args['Bar'..a].args.Filter.set = function(info,key) AptusAuraFrames['db']['profile']['frames'][a]['filterNum'] = key AptusAuraFrames['db']['profile']['frames'][a]['filter'] = args['Bar'..a]['args']['Filter']['values'][key] UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.Break1 = {}
		args['Bar'..a].args.Break1.order = 10
		args['Bar'..a].args.Break1.type = 'header'
		args['Bar'..a].args.Break1.name = 'Layout'
		
		args['Bar'..a].args.NumBars = {}
		args['Bar'..a].args.NumBars.name = "# of Auras"
		args['Bar'..a].args.NumBars.type = 'input'
		args['Bar'..a].args.NumBars.pattern = '%d+'
		args['Bar'..a].args.NumBars.multiline = false
		args['Bar'..a].args.NumBars.width = 'half'
		args['Bar'..a].args.NumBars.order = 11
		args['Bar'..a].args.NumBars.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['NumBars'] end
		args['Bar'..a].args.NumBars.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['NumBars'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.Padding = {}
		args['Bar'..a].args.Padding.name = "Padding"
		args['Bar'..a].args.Padding.type = 'input'
		args['Bar'..a].args.Padding.pattern = '%d+'
		args['Bar'..a].args.Padding.multiline = false
		args['Bar'..a].args.Padding.width = 'half'
		args['Bar'..a].args.Padding.order = 12
		args['Bar'..a].args.Padding.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['Padding'] end
		args['Bar'..a].args.Padding.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['Padding'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.LinePadding = {}
		args['Bar'..a].args.LinePadding.name = "Row Padding"
		args['Bar'..a].args.LinePadding.type = 'input'
		args['Bar'..a].args.LinePadding.pattern = '%d+'
		args['Bar'..a].args.LinePadding.multiline = false
		args['Bar'..a].args.LinePadding.width = 'half'
		args['Bar'..a].args.LinePadding.order = 13
		args['Bar'..a].args.LinePadding.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['LinePadding'] end
		args['Bar'..a].args.LinePadding.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['LinePadding'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.size = {}
		args['Bar'..a].args.size.name = "Size"
		args['Bar'..a].args.size.type = 'input'
		args['Bar'..a].args.size.pattern = '%d+'
		args['Bar'..a].args.size.multiline = false
		args['Bar'..a].args.size.width = 'half'
		args['Bar'..a].args.size.order = 14
		args['Bar'..a].args.size.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['size'] end
		args['Bar'..a].args.size.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['size'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.scale = {}
		args['Bar'..a].args.scale.name = "Scale"
		args['Bar'..a].args.scale.type = 'input'
		args['Bar'..a].args.scale.pattern = '%d+'
		args['Bar'..a].args.scale.multiline = false
		args['Bar'..a].args.scale.width = 'half'
		args['Bar'..a].args.scale.order = 15
		args['Bar'..a].args.scale.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['scale']  end
		args['Bar'..a].args.scale.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['scale'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.GrowthDirection = {}
		args['Bar'..a].args.GrowthDirection.width = 'half'
		args['Bar'..a].args.GrowthDirection.name = 'Growth Direction'
		args['Bar'..a].args.GrowthDirection.type = 'select'
		args['Bar'..a].args.GrowthDirection.style = 'radio'
		args['Bar'..a].args.GrowthDirection.order = 16
		args['Bar'..a].args.GrowthDirection.values = { 'UP', 'DOWN', 'LEFT', 'RIGHT' }
		args['Bar'..a].args.GrowthDirection.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['GrowthDirectionNum'] end
		args['Bar'..a].args.GrowthDirection.set = function(info,key) AptusAuraFrames['db']['profile']['frames'][a]['GrowthDirectionNum'] = key AptusAuraFrames['db']['profile']['frames'][a]['GrowthDirection'] = args['Bar'..a]['args']['GrowthDirection']['values'][key] UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.LineGrowth = {}
		args['Bar'..a].args.LineGrowth.width = 'half'
		args['Bar'..a].args.LineGrowth.name = 'Line Direction'
		args['Bar'..a].args.LineGrowth.type = 'select'
		args['Bar'..a].args.LineGrowth.style = 'radio'
		args['Bar'..a].args.LineGrowth.order = 17
		args['Bar'..a].args.LineGrowth.values = { 'UP', 'DOWN', 'LEFT', 'RIGHT' }
		if AptusAuraFrames['db']['profile']['frames'][a]['GrowthDirection'] == 'UP' or AptusAuraFrames['db']['profile']['frames'][a]['GrowthDirection'] == 'DOWN' then
			args['Bar'..a].args.LineGrowth.values = { 'LEFT', 'RIGHT' }
		else
			args['Bar'..a].args.LineGrowth.values = { 'UP', 'DOWN'}
		end
		args['Bar'..a].args.LineGrowth.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['LineDirectionNum'] end
		args['Bar'..a].args.LineGrowth.set = function(info,key) AptusAuraFrames['db']['profile']['frames'][a]['LineDirectionNum'] = key AptusAuraFrames['db']['profile']['frames'][a]['LineGrowth'] = args['Bar'..a]['args']['LineGrowth']['values'][key] UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.BuffsPerRow = {}
		args['Bar'..a].args.BuffsPerRow.min = 0
		args['Bar'..a].args.BuffsPerRow.max = tonumber(AptusAuraFrames['db']['profile']['frames'][a]['NumBars']) or 10
		args['Bar'..a].args.BuffsPerRow.step = 1
		args['Bar'..a].args.BuffsPerRow.name = "Buffs per Row"
		args['Bar'..a].args.BuffsPerRow.type = 'range'
		-- args['Bar'..a].args.BuffsPerRow.width = 'half'
		args['Bar'..a].args.BuffsPerRow.order = 18
		args['Bar'..a].args.BuffsPerRow.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['BuffsPerRow'] end
		args['Bar'..a].args.BuffsPerRow.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['BuffsPerRow'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.Break2 = {}
		args['Bar'..a].args.Break2.order = 20
		args['Bar'..a].args.Break2.type = 'header'
		args['Bar'..a].args.Break2.name = 'Timers'
		
		args['Bar'..a].args.Timers = {}
		args['Bar'..a].args.Timers.type = 'toggle'
		args['Bar'..a].args.Timers.name = 'Timers'
		args['Bar'..a].args.Timers.order = 21
		args['Bar'..a].args.Timers.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['timers'] end
		args['Bar'..a].args.Timers.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['timers'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		if AptusAuraFrames['db']['profile']['frames'][a]['timers'] == false then
			AptusAuraFrames['db']['profile']['frames'][a]['disabled'] = true
		elseif not AptusAuraFrames['db']['profile']['frames'][a]['timers'] then
			AptusAuraFrames['db']['profile']['frames'][a]['timers'] = false
			AptusAuraFrames['db']['profile']['frames'][a]['disabled'] = true
		else
			AptusAuraFrames['db']['profile']['frames'][a]['disabled'] = false
		end
		
		args['Bar'..a].args.point = {}
		args['Bar'..a].args.point.name = 'Anchor Point'
		args['Bar'..a].args.point.type = 'select'
		args['Bar'..a].args.point.style = 'radio'
		args['Bar'..a].args.point.width = 'half'
		args['Bar'..a].args.point.disabled = AptusAuraFrames['db']['profile']['frames'][a]['disabled']
		args['Bar'..a].args.point.order = 22
		args['Bar'..a].args.point.values = { 'TOP', 'BOTTOM', 'LEFT', 'RIGHT' }
		args['Bar'..a].args.point.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['pointNum'] end
		args['Bar'..a].args.point.set = function(info,key) AptusAuraFrames['db']['profile']['frames'][a]['timer']['point'] = args['Bar'..a]['args']['point']['values'][key] AptusAuraFrames['db']['profile']['frames'][a]['pointNum'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end

		args['Bar'..a].args.relativePoint = {}
		args['Bar'..a].args.relativePoint.name = 'Relative Point'
		args['Bar'..a].args.relativePoint.type = 'select'
		args['Bar'..a].args.relativePoint.width = 'half'
		args['Bar'..a].args.relativePoint.style = 'radio'
		args['Bar'..a].args.relativePoint.order = 23
		args['Bar'..a].args.relativePoint.disabled = AptusAuraFrames['db']['profile']['frames'][a]['disabled']
		args['Bar'..a].args.relativePoint.values = { 'TOP', 'BOTTOM', 'LEFT', 'RIGHT' }
		args['Bar'..a].args.relativePoint.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['relativePointNum'] end
		args['Bar'..a].args.relativePoint.set = function(info,key) AptusAuraFrames['db']['profile']['frames'][a]['timer']['relativePoint'] = args['Bar'..a]['args']['relativePoint']['values'][key] AptusAuraFrames['db']['profile']['frames'][a]['relativePointNum'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.offsetX = {}
		args['Bar'..a].args.offsetX.name = "X Offset"
		args['Bar'..a].args.offsetX.type = 'input'
		args['Bar'..a].args.offsetX.pattern = '%d+'
		args['Bar'..a].args.offsetX.multiline = false
		args['Bar'..a].args.offsetX.width = 'half'
		args['Bar'..a].args.offsetX.order = 24
		args['Bar'..a].args.offsetX.disabled = AptusAuraFrames['db']['profile']['frames'][a]['disabled']
		args['Bar'..a].args.offsetX.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['timer']['offsetX'] end
		args['Bar'..a].args.offsetX.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['timer']['offsetX'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.offsetY = {}
		args['Bar'..a].args.offsetY.name = "Y Offset"
		args['Bar'..a].args.offsetY.type = 'input'
		args['Bar'..a].args.offsetY.pattern = '%d+'
		args['Bar'..a].args.offsetY.multiline = false
		args['Bar'..a].args.offsetY.width = 'half'
		args['Bar'..a].args.offsetY.order = 24
		args['Bar'..a].args.offsetY.disabled = AptusAuraFrames['db']['profile']['frames'][a]['disabled']
		args['Bar'..a].args.offsetY.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['timer']['offsetY'] end
		args['Bar'..a].args.offsetY.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['timer']['offsetY'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.size = {}
		args['Bar'..a].args.size.name = "Size"
		args['Bar'..a].args.size.type = 'input'
		args['Bar'..a].args.size.pattern = '%d+'
		args['Bar'..a].args.size.multiline = false
		args['Bar'..a].args.size.width = 'half'
		args['Bar'..a].args.size.order = 24
		args['Bar'..a].args.size.disabled = AptusAuraFrames['db']['profile']['frames'][a]['disabled']
		args['Bar'..a].args.size.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['timer']['size'] end
		args['Bar'..a].args.size.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['timer']['size'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.Break3 = {}
		args['Bar'..a].args.Break3.order = 30
		args['Bar'..a].args.Break3.type = 'header'
		args['Bar'..a].args.Break3.name = 'Charges'
		
		args['Bar'..a].args.Count = {}
		args['Bar'..a].args.Count.type = 'toggle'
		args['Bar'..a].args.Count.name = 'Charges'
		args['Bar'..a].args.Count.order = 31
		args['Bar'..a].args.Count.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['counts'] end
		args['Bar'..a].args.Count.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['counts'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		if AptusAuraFrames['db']['profile']['frames'][a]['counts'] == false then
			AptusAuraFrames['db']['profile']['frames'][a]['cdisabled'] = true
		elseif not AptusAuraFrames['db']['profile']['frames'][a]['counts'] then
			AptusAuraFrames['db']['profile']['frames'][a]['counts'] = false
			AptusAuraFrames['db']['profile']['frames'][a]['cdisabled'] = true
		else
			AptusAuraFrames['db']['profile']['frames'][a]['cdisabled'] = false
		end
		
		args['Bar'..a].args.Cpoint = {}
		args['Bar'..a].args.Cpoint.name = 'Anchor Point'
		args['Bar'..a].args.Cpoint.type = 'select'
		args['Bar'..a].args.Cpoint.style = 'radio'
		args['Bar'..a].args.Cpoint.width = 'half'
		args['Bar'..a].args.Cpoint.disabled = AptusAuraFrames['db']['profile']['frames'][a]['cdisabled']
		args['Bar'..a].args.Cpoint.order = 32
		args['Bar'..a].args.Cpoint.values = { 'TOP', 'BOTTOM', 'LEFT', 'RIGHT' }
		args['Bar'..a].args.Cpoint.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['CpointNum'] end
		args['Bar'..a].args.Cpoint.set = function(info,key) AptusAuraFrames['db']['profile']['frames'][a]['count']['point'] = args['Bar'..a]['args']['point']['values'][key] AptusAuraFrames['db']['profile']['frames'][a]['CpointNum'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end

		args['Bar'..a].args.CrelativePoint = {}
		args['Bar'..a].args.CrelativePoint.name = 'Relative Point'
		args['Bar'..a].args.CrelativePoint.type = 'select'
		args['Bar'..a].args.CrelativePoint.width = 'half'
		args['Bar'..a].args.CrelativePoint.style = 'radio'
		args['Bar'..a].args.CrelativePoint.order = 33
		args['Bar'..a].args.CrelativePoint.disabled = AptusAuraFrames['db']['profile']['frames'][a]['cdisabled']
		args['Bar'..a].args.CrelativePoint.values = { 'TOP', 'BOTTOM', 'LEFT', 'RIGHT' }
		args['Bar'..a].args.CrelativePoint.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['CrelativePointNum'] end
		args['Bar'..a].args.CrelativePoint.set = function(info,key) AptusAuraFrames['db']['profile']['frames'][a]['count']['relativePoint'] = args['Bar'..a]['args']['relativePoint']['values'][key] AptusAuraFrames['db']['profile']['frames'][a]['CrelativePointNum'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.CoffsetX = {}
		args['Bar'..a].args.CoffsetX.name = "X Offset"
		args['Bar'..a].args.CoffsetX.type = 'input'
		args['Bar'..a].args.CoffsetX.pattern = '%d+'
		args['Bar'..a].args.CoffsetX.multiline = false
		args['Bar'..a].args.CoffsetX.width = 'half'
		args['Bar'..a].args.CoffsetX.order = 34
		args['Bar'..a].args.CoffsetX.disabled = AptusAuraFrames['db']['profile']['frames'][a]['cdisabled']
		args['Bar'..a].args.CoffsetX.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['count']['offsetX'] end
		args['Bar'..a].args.CoffsetX.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['count']['offsetX'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.CoffsetY = {}
		args['Bar'..a].args.CoffsetY.name = "Y Offset"
		args['Bar'..a].args.CoffsetY.type = 'input'
		args['Bar'..a].args.CoffsetY.pattern = '%d+'
		args['Bar'..a].args.CoffsetY.multiline = false
		args['Bar'..a].args.CoffsetY.width = 'half'
		args['Bar'..a].args.CoffsetY.order = 35
		args['Bar'..a].args.CoffsetY.disabled = AptusAuraFrames['db']['profile']['frames'][a]['cdisabled']
		args['Bar'..a].args.CoffsetY.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['count']['offsetY'] end
		args['Bar'..a].args.CoffsetY.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['count']['offsetY'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
		
		args['Bar'..a].args.Csize = {}
		args['Bar'..a].args.Csize.name = "Size"
		args['Bar'..a].args.Csize.type = 'input'
		args['Bar'..a].args.Csize.pattern = '%d+'
		args['Bar'..a].args.Csize.multiline = false
		args['Bar'..a].args.Csize.width = 'half'
		args['Bar'..a].args.Csize.order = 36
		args['Bar'..a].args.Csize.disabled = AptusAuraFrames['db']['profile']['frames'][a]['cdisabled']
		args['Bar'..a].args.Csize.get = function(info) return AptusAuraFrames['db']['profile']['frames'][a]['count']['size'] end
		args['Bar'..a].args.Csize.set = function(info, key) AptusAuraFrames['db']['profile']['frames'][a]['count']['size'] = key UpdateOptions() AptusAuraFrames:UpdateBars(a) end
	
		local disabled;
		
		if AptusAuraFrames['db']['profile']['frames'][a]['Blacklist'] and AptusAuraFrames['db']['profile']['frames'][a]['Blacklist'][1] then
			disabled = true
		else
			disabled = false
		end
	
		args['Bar'..a].args.Break4 = {}
		args['Bar'..a].args.Break4.order = 40
		args['Bar'..a].args.Break4.type = 'header'
		args['Bar'..a].args.Break4.name = 'Whitelist'
		
		args['Bar'..a].args.WhitelistInput = {}
		args['Bar'..a].args.WhitelistInput.name = "Whitelist Input"
		args['Bar'..a].args.WhitelistInput.type = 'input'
		-- args['Bar'..a].args.WhitelistInput.pattern = '%d+'
		args['Bar'..a].args.WhitelistInput.multiline = false
		-- args['Bar'..a].args.WhitelistInput.width = 'half'
		args['Bar'..a].args.WhitelistInput.order = 41
		args['Bar'..a].args.WhitelistInput.disabled = disabled
		args['Bar'..a].args.WhitelistInput.get = function(info) return nil end --=AptusAuraFrames['db']['profile']['frames'][a]['Whitelist'] end
		args['Bar'..a].args.WhitelistInput.set = function(info, key) 
			if AptusAuraFrames['db']['profile']['frames'][a]['Whitelist'] then
				tinsert(AptusAuraFrames['db']['profile']['frames'][a]['Whitelist'], key)
			else
				AptusAuraFrames['db']['profile']['frames'][a]['Whitelist'] = {}
				tinsert(AptusAuraFrames['db']['profile']['frames'][a]['Whitelist'], key)
			end
			UpdateOptions()
			AptusAuraFrames:UpdateBars(a) 
		end
		
		if AptusAuraFrames['db']['profile']['frames'][a]['Whitelist'] and AptusAuraFrames['db']['profile']['frames'][a]['Whitelist'][1] then
			args['Bar'..a].args.Whitelist = {}
			args['Bar'..a].args.Whitelist.name = 'Whitelist'
			args['Bar'..a].args.Whitelist.type = 'select'
			-- args['Bar'..a].args.Whitelist.width = 'half'
			args['Bar'..a].args.Whitelist.style = 'radio'
			args['Bar'..a].args.Whitelist.order = 42
			args['Bar'..a].args.Whitelist.disabled = disabled
			args['Bar'..a].args.Whitelist.values = AptusAuraFrames['db']['profile']['frames'][a]['Whitelist']
			args['Bar'..a].args.Whitelist.get = function(info) return nil end
			args['Bar'..a].args.Whitelist.set = function(info,key)
				tremove(AptusAuraFrames['db']['profile']['frames'][a]['Whitelist'], key)
				if AptusAuraFrames['db']['profile']['frames'][a]['Whitelist'][1] == nil then
					AptusAuraFrames['db']['profile']['frames'][a]['Whitelist'] = nil
				end
				UpdateOptions()
				AptusAuraFrames:UpdateBars(a) 
			end
		end	
	
		if AptusAuraFrames['db']['profile']['frames'][a]['Whitelist'] and AptusAuraFrames['db']['profile']['frames'][a]['Whitelist'][1] then
			disabled = true
		else
			disabled = false
		end
		
		args['Bar'..a].args.Break5 = {}
		args['Bar'..a].args.Break5.order = 45
		args['Bar'..a].args.Break5.type = 'header'
		args['Bar'..a].args.Break5.name = 'Blacklist'
		
		args['Bar'..a].args.BlacklistInput = {}
		args['Bar'..a].args.BlacklistInput.name = "Blacklist Input"
		args['Bar'..a].args.BlacklistInput.type = 'input'
		-- args['Bar'..a].args.BlacklistInput.pattern = '%d+'
		args['Bar'..a].args.BlacklistInput.multiline = false
		-- args['Bar'..a].args.BlacklistInput.width = 'half'
		args['Bar'..a].args.BlacklistInput.order = 46
		args['Bar'..a].args.BlacklistInput.disabled = disabled
		args['Bar'..a].args.BlacklistInput.get = function(info) return nil end --=AptusAuraFrames['db']['profile']['frames'][a]['Blacklist'] end
		args['Bar'..a].args.BlacklistInput.set = function(info, key) 
			if AptusAuraFrames['db']['profile']['frames'][a]['Blacklist'] then
				tinsert(AptusAuraFrames['db']['profile']['frames'][a]['Blacklist'], key)
			else
				AptusAuraFrames['db']['profile']['frames'][a]['Blacklist'] = {}
				tinsert(AptusAuraFrames['db']['profile']['frames'][a]['Blacklist'], key)
			end
			UpdateOptions()
			AptusAuraFrames:UpdateBars(a) 
		end
		
		if AptusAuraFrames['db']['profile']['frames'][a]['Blacklist'] and AptusAuraFrames['db']['profile']['frames'][a]['Blacklist'][1] then
			args['Bar'..a].args.Blacklist = {}
			args['Bar'..a].args.Blacklist.name = 'Blacklist'
			args['Bar'..a].args.Blacklist.type = 'select'
			-- args['Bar'..a].args.Blacklist.width = 'half'
			args['Bar'..a].args.Blacklist.style = 'radio'
			args['Bar'..a].args.Blacklist.order = 47
			args['Bar'..a].args.Blacklist.disabled = disabled
			args['Bar'..a].args.Blacklist.values = AptusAuraFrames['db']['profile']['frames'][a]['Blacklist']
			args['Bar'..a].args.Blacklist.get = function(info) return nil end
			args['Bar'..a].args.Blacklist.set = function(info,key)
				tremove(AptusAuraFrames['db']['profile']['frames'][a]['Blacklist'], key)
				if AptusAuraFrames['db']['profile']['frames'][a]['Blacklist'][1] == nil then
					AptusAuraFrames['db']['profile']['frames'][a]['Blacklist'] = nil
				end
				UpdateOptions()
				AptusAuraFrames:UpdateBars(a) 
			end
		end	
	end
	
	
	
	aaf_options.args = args
	aaf_options.args.profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(AptusAuraFrames.db)
	aaf_options.args.profiles.order = 100
	LibStub("AceConfig-3.0"):RegisterOptionsTable("AptusAuraFrames", aaf_options, {"AptusAuraFrames"})
end

function AptusAuraFrames:UpdateBars(i)
	local data = AptusAuraFrames['db']['profile']['frames'][i]
	local frame;
	if data == nil then
		for k,v in pairs(AptusAuraFrames.bars[i]) do
			if not InCombatLockdown() then
				v:Hide()
			end
			v.bar:Hide()
		end
	end
-- if data and data.Secure ~= true and data.Secure ~= 1 then
	local groups = AptusAuraFrames['db']['profile']['frames']
	local k = groups[i]
	for k,v in pairs(AptusAuraFrames.frames) do
		if data.name == v.name then
			frame = v
		end
	end
	if frame == nil then
		frame = CreateFrame("Frame", "aAFAnchor"..#AptusAuraFrames['frames']+1, UIParent);
		if ( not AptusAuraFrames.bars[#AptusAuraFrames['frames']+1] ) then
			AptusAuraFrames.bars[#AptusAuraFrames['frames']+1] = {};
			-- fullbars[i] = {};
		end
	end
	frame.Id = i;
	-- frame.barId = #AptusAuraFrames['frames']+1
	frame.GrowthDirection = data.GrowthDirection or "LEFT";
	frame.LineGrowth = data.LineGrowth or "DOWN"
	frame.Padding = data.Padding or 3;
	frame.LinePadding = data.LinePadding or 3;
	frame.Mode = data.Mode or "ICON";
	frame.BuffsPerRow = data.BuffsPerRow or nil
	frame.TimerType = data.TimerType or 1
	frame:SetWidth(k and k.size or 100);
	frame:SetHeight(k and k.size or 20)
	frame.name = k.name
	
	local self = frame
	local row = 1
	local numonrow = 0
	for a=1, k['NumBars'] do
		local bar;
		local uBar;
		if not AptusAuraFrames.bars[frame.barId][a] then
			-- bar = CreateFrame("Frame", "aAFAnchor"..(frame.barId).."Frame"..a, frame);
			bar = CreateFrame("Button", "aAFAnchor"..(#AptusAuraFrames['frames']+1).."Frame"..a, frame, "SecureActionButtonTemplate");
			bar:RegisterForClicks("RightButtonUp")	
			bar:SetAttribute("type", "cancelaura" )
			bar:SetAttribute("unit", "player")
			if not k['WeaponEnchant'] then
				bar:SetAttribute("index", a)
			else
				bar:SetAttribute("target-slot", a)
			end
			
			uBar = CreateFrame("FRAME", "aAFAnchor"..(#AptusAuraFrames['frames']+1)..'FrameUnderlay'..a, frame)
			uBar:SetAllPoints(bar)
			bar['bar'] = uBar
			uBar['bar'] = bar
			uBar:EnableMouse(true)
		else
			bar = AptusAuraFrames.bars[frame.barId][a]
			uBar = bar.bar
		end
		bar:EnableMouse(1)
		bar:SetScript("OnMouseDown", function(self)
			if ( IsShiftKeyDown() and IsAltKeyDown() ) then
				self:GetParent():StartMoving();
			end
		end);
		bar:SetScript("OnMouseUp", function(self)
			self:GetParent():StopMovingOrSizing();
			self:GetParent():SetUserPlaced(false)
		end);
		
		bar:SetWidth(k['size']);
		bar:SetHeight(k['size']);
		bar:SetScale(k['scale']);
		
		numonrow = numonrow + 1
		
		bar:ClearAllPoints()
		
		if ( a == 1 ) then

			-- If this is the first frame
			if ( self.GrowthDirection == "UP" ) then
				bar:SetPoint("BOTTOM", self);
			elseif ( self.GrowthDirection == "RIGHT" ) then
				bar:SetPoint("LEFT", self);
			elseif ( self.GrowthDirection == "LEFT" ) then
				bar:SetPoint("RIGHT", self);
			else
				bar:SetPoint("TOP", self);
			end
			
			-- If not first frame and we've reached the end of a row
		elseif self.BuffsPerRow ~= nil and (numonrow == (self.BuffsPerRow)+1) then
			if ( self.GrowthDirection == "UP" ) then
				if ( self.LineGrowth == "LEFT" ) then
					bar:SetPoint("RIGHT", AptusAuraFrames.bars[frame.barId][a-self.BuffsPerRow], "LEFT", -self.LinePadding, 0);
				else
					bar:SetPoint("LEFT", AptusAuraFrames.bars[frame.barId][a-self.BuffsPerRow], "RIGHT", self.LinePadding, 0);
				end
			elseif ( self.GrowthDirection == "RIGHT" ) then
				if ( self.LineGrowth == "UP" ) then
					bar:SetPoint("BOTTOM", AptusAuraFrames.bars[frame.barId][a-self.BuffsPerRow], "TOP", 0, self.LinePadding);
				else
					bar:SetPoint("TOP", AptusAuraFrames.bars[frame.barId][a-self.BuffsPerRow], "BOTTOM", 0, -self.LinePadding);
				end
			elseif ( self.GrowthDirection == "LEFT" ) then
				if ( self.LineGrowth == "UP" ) then
					bar:SetPoint("BOTTOM", AptusAuraFrames.bars[frame.barId][a-self.BuffsPerRow], "TOP", 0, self.LinePadding);
				else
				-- print(self.LineGrowth)
					bar:SetPoint("TOP", AptusAuraFrames.bars[frame.barId][a-self.BuffsPerRow], "BOTTOM", 0, -self.LinePadding);
				end
			else
				if ( self.LineGrowth == "LEFT" ) then
					bar:SetPoint("RIGHT", AptusAuraFrames.bars[frame.barId][a-self.BuffsPerRow], "LEFT", -self.LinePadding, 0);
				else
					bar:SetPoint("LEFT", AptusAuraFrames.bars[frame.barId][a-self.BuffsPerRow], "RIGHT", self.LinePadding, 0);
				end
			end
			numonrow = 1
			row = row+1
		elseif	self.BuffsPerRow ~= nil and (numonrow > (self.BuffsPerRow)+1) then
			if ( self.GrowthDirection == "UP" ) then
				bar:SetPoint("BOTTOM", AptusAuraFrames.bars[frame.barId][a-1], "TOP", 0, self.Padding);
			elseif ( self.GrowthDirection == "RIGHT" ) then
				bar:SetPoint("LEFT", AptusAuraFrames.bars[frame.barId][a-1], "RIGHT", self.Mode == "ICON" and self.Padding or k[barWidth+self.Padding], 0);
			elseif ( self.GrowthDirection == "LEFT" ) then
				bar:SetPoint("RIGHT", AptusAuraFrames.bars[frame.barId][a-1], "LEFT", self.Mode == "ICON" and -(self.Padding) or -(k['barWidth']+self.Padding), 0);
			else
				bar:SetPoint("TOP", AptusAuraFrames.bars[frame.barId][a-1], "BOTTOM", 0, -self.Padding);
			end
		else
			if ( self.GrowthDirection == "UP" ) then
				bar:SetPoint("BOTTOM", AptusAuraFrames.bars[frame.barId][a-1], "TOP", 0, self.Padding);
			elseif ( self.GrowthDirection == "RIGHT" ) then
				bar:SetPoint("LEFT", AptusAuraFrames.bars[frame.barId][a-1], "RIGHT", self.Mode == "ICON" and self.Padding or k[barWidth+self.Padding], 0);
			elseif ( self.GrowthDirection == "LEFT" ) then
				bar:SetPoint("RIGHT", AptusAuraFrames.bars[frame.barId][a-1], "LEFT", self.Mode == "ICON" and -(self.Padding) or -(k['barWidth']+self.Padding), 0);
			else
				bar:SetPoint("TOP", AptusAuraFrames.bars[frame.barId][a-1], "BOTTOM", 0, -self.Padding);
			end
		end
		if ( self.Mode == "ICON" ) then
			if not bar.icon then
				bar.icon = uBar:CreateTexture("$parentIcon", "BACKGROUND");
			end
			bar.icon:SetAllPoints();
			bar.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93);
					
			if not bar.cooldown then
				bar.cooldown = CreateFrame("Cooldown", nil, uBar, "CooldownFrameTemplate");
			end
			bar.cooldown:SetAllPoints();
			bar.cooldown:SetReverse();
			
			if not bar.overlay then
				bar.overlay = uBar:CreateTexture(nil, "ARTWORK");
			end
			bar.overlay:SetTexture("Interface\\AddOns\\AptusAuraFrames\\Textures\\border");
			bar.overlay:SetPoint("TOPLEFT", -3, 3);
			bar.overlay:SetPoint("BOTTOMRIGHT", 3, -3);
			bar.overlay:SetVertexColor(0.25, 0.25, 0.25);
			bar.shouldshow = true
			
			if not bar.count then
				bar.count = uBar:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall");
			end
			if data.count then
				path, size, flags = bar.count:GetFont()
				point = data['count']['point'] or "TOP"
				relativePoint = data['count']['relativePoint'] or "BOTTOM"
				ofsx = data['count']['offsetX'] or 0
				ofsy = data['count']['offsetY'] or 0
				-- print(ofsy)
				size = data['count']['size'] or size
				path = data['count']['fontpath'] or path
				flags = data['count']['flags'] or flags
			else
				point, relativePoint, ofsx, ofsy =  "BOTTOM", bar, "BOTTOM", 0, -35
				path, size, flags = bar.time:GetFont()
				size = 10
			end
			bar.count:SetJustifyH("RIGHT");
			bar.count:SetFont(path, size, flags)
			bar.count:ClearAllPoints()
			bar.count:SetPoint(point, bar, relativePoint, ofsx, ofsy);
			
			if not bar.time then
				bar.time = uBar:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall");
			end
			local point, relativePoint, ofsx, ofsy, size, path, flags;
			if data.timer then
				path, size, flags = bar.time:GetFont()
				point = data['timer']['point'] or "TOP"
				relativePoint = data['timer']['relativePoint'] or "BOTTOM"
				ofsx = data['timer']['offsetX'] or 0
				ofsy = data['timer']['offsetY'] or 0
				size = data['timer']['size'] or size
				path = data['timer']['fontpath'] or path
				flags = data['timer']['flags'] or flags
			else
				point, relativePoint, ofsx, ofsy =  "BOTTOM", bar, "BOTTOM", 0, -35
				path, size, flags = bar.time:GetFont()
				size = 10
			end
			bar.time:SetFont(path, size, flags)
			bar.time:ClearAllPoints()
			bar.time:SetPoint(point, bar, relativePoint, ofsx, ofsy);
			bar.time:Show()
		-- else
			-- bar.icon = bar:CreateTexture(nil, "BACKGROUND");
			-- bar.icon:SetAllPoints();
			-- bar.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93);
					
			-- bar.count = bar:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall");
			-- bar.count:SetPoint("BOTTOMRIGHT");
			-- bar.count:SetJustifyH("RIGHT");
					
			-- bar.statusbar = CreateFrame("StatusBar", nil, bar);
			-- if ( configmode ) then
				-- bar.statusbar:SetFrameStrata("BACKGROUND");
			-- end
			-- bar.statusbar:SetWidth(groups[i]['barWidth'] or 200);
			-- bar.statusbar:SetHeight(groups[i]['size']);
			-- bar.statusbar:SetStatusBarTexture("Interface\\AddOns\\aAF\\Textures\\statusbar");
			-- bar.statusbar:SetStatusBarColor(0.4, 0.4, 0.4, 1);
			-- bar.statusbar:SetPoint("LEFT", bar, "RIGHT");
			-- bar.statusbar:SetMinMaxValues(0, 1);
			-- bar.statusbar:SetValue(0);
			-- bar.statusbar.background = bar.statusbar:CreateTexture(nil, "BACKGROUND");
			-- bar.statusbar.background:SetAllPoints(bar.statusbar);
			-- bar.statusbar.background:SetTexture("Interface\\AddOns\\aAF\\Textures\\statusbar");
			-- bar.statusbar.background:SetVertexColor(classcolor.r, classcolor.g, classcolor.b, 0.7);
			
			-- bar.time = bar.statusbar:CreateFontString(nil, "ARTWORK", "GameFontHighlightRight");
			-- bar.time:SetPoint("RIGHT", bar.statusbar, -2, 1);
					
			-- bar.spellname = bar.statusbar:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall");
			-- bar.spellname:SetPoint("LEFT", bar.statusbar, 2, 1);
			-- bar.spellname:SetPoint("RIGHT", bar.time, "LEFT");
			-- bar.spellname:SetJustifyH("CENTER");
			-- bar:Hide()
		end
		if not AptusAuraFrames.bars[frame.barId][a] then
			tinsert(AptusAuraFrames.bars[frame.barId], bar);
		end
	end
	if not AptusAuraFrames.frames[frame.barId] then
		tinsert(AptusAuraFrames.frames, frame)
	end
	if #AptusAuraFrames.bars[frame.barId] >  tonumber(k['NumBars']) then
		for a,b in pairs(AptusAuraFrames.bars) do
			if a > tonumber(k['NumBars']) then
				AptusAuraFrames.bars[frame.barId][a].show = false
			end
		end
	end
	AptusAuraFrames_OnEvent(frame, "PLAYER_TARGET_CHANGED")
-- end
end
		
		

function AptusAuraFrames:NewBar(key)
	bar = {
		timers = true,
		name = key,
		GrowthDirection = "LEFT",
		LineGrowth = "DOWN",
		Padding = 4,  
		LinePadding = 4,
		Mode = "ICON", 
		ModeNum = 1,
		BuffsPerRow = 8, 
		size = 20,
		scale = 1.2,
		unitId = 'player',
		unitIdNum = 1,
		caster = 'all',
		filter = 'BUFF',
		NumBars = 16,
		timer = {
			point = "TOP",
			relativePoint = "BOTTOM",
			offsetX = "0",
			offsetY = "0",
		},
		counts = true,
		count = {
			point = "TOP",
			relativePoint = "BOTTOM",
			offsetX = "7",
			offsetY = "9",
		},
		sortby = 'INDEX'
	}
	table.insert(AptusAuraFrames['db']['profile']['frames'], bar)
	-- ReloadUI()
	AptusAuraFrames:CreateBars()
	UpdateOptions()
end

function AptusAuraFrames:OnEnable()
	BuffFrame:Hide()
	BuffFrame:HookScript("OnShow", function(self) self:Hide() end)
	TemporaryEnchantFrame:SetMovable(1)
	TempEnchant1:SetScript("OnMouseDown", function(self) if ( IsShiftKeyDown() and IsAltKeyDown() ) then self:GetParent():StartMoving() end end)
	TempEnchant1:SetScript("OnMouseUp", function(self) self:GetParent():StopMovingOrSizing() end)
	TempEnchant2:SetScript("OnMouseDown", function(self) if ( IsShiftKeyDown() and IsAltKeyDown() ) then self:GetParent():StartMoving() end end)
	TempEnchant2:SetScript("OnMouseUp", function(self) self:GetParent():StopMovingOrSizing() end)
	AptusAuraFrames:CreateBars()
	if AptusAuraFrames['db']['profile']['aAF_Profiles'] and AptusAuraFrames['db']['profile']['aAF_Profiles']['positions'] then
		for k,v in pairs(AptusAuraFrames['db']['profile']['aAF_Profiles']['positions'])do
			for index, value in pairs(AptusAuraFrames.bars) do
				for i, bar in pairs(value) do
					local frame = bar:GetParent()
					local name = bar:GetParent()['name']
					if name == k then
						frame:ClearAllPoints()
						frame:SetPoint(v[1], UIParent, v[2], v[3], v[4])
					end
				end
			end
		end
	end
end

function AptusAuraFrames:OnDisable()
end

function AptusAuraFrames:CreateBars()
	-- return
	if AptusAuraFrames['db']['profile']['aAF_Profiles'] and AptusAuraFrames['db']['profile']['aAF_Profiles'] then
		if AptusAuraFrames['db']['profile']['aAF_Profiles']['positions'] then
			positions = AptusAuraFrames['db']['profile']['aAF_Profiles']['positions']
		end
	end

	groups = AptusAuraFrames['db']['profile']['frames']
	
	if groups then
		local data, frame;
		for i,k in pairs(groups) do
			data = groups[i];
			local eh = nil
			
			for key, val in pairs(AptusAuraFrames.frames) do
				if val.name == k.name then
					eh = true
					break
				end
			end

			if eh ~= true then
				frame = CreateFrame("Frame", "aAFAnchor"..#AptusAuraFrames['frames']+1, UIParent);
				frame:SetFrameLevel(20)
				frame.Id = i;
				frame.barId = #AptusAuraFrames['frames']+1;
				frame.GrowthDirection = data.GrowthDirection or "LEFT";
				frame.LineGrowth = data.LineGrowth or "DOWN"
				frame.Padding = data.Padding or 3;
				frame.LinePadding = data.LinePadding or 3;
				frame.Mode = data.Mode or "ICON";
				frame.BuffsPerRow = data.BuffsPerRow or nil
				frame.TimerType = data.TimerType or 1
				frame:SetWidth(k and k.size or 100);
				frame:SetHeight(k and k.size or 20);
				frame:SetPoint("CENTER");
				frame:SetMovable(1);
				frame:EnableMouse(0);
				frame:RegisterForDrag("LeftButton");
				frame:SetUserPlaced(false)
				frame:SetScript("OnDragStart", function(self)
					if ( IsShiftKeyDown() and IsAltKeyDown() ) then
						self:StartMoving();
					end
				end);
				frame:SetScript("OnDragStop", function(self)
					self:StopMovingOrSizing();
				end);
				
				frame.name = k.name
				
				-- for j=1, #groups[i], 1 do
					-- data = groups[i][j];
					-- if ( data.filter == "CD" ) then
						-- frame:RegisterEvent("SPELL_UPDATE_COOLDOWN");
						-- break;
					-- end
				-- end
				if i == 1 then
					frame:RegisterEvent("PLAYER_LOGOUT")
				end
				frame:RegisterEvent("PLAYER_REGEN_ENABLED")
				frame:RegisterEvent("PLAYER_REGEN_DISABLED")
				frame:RegisterEvent("UNIT_AURA");
				frame:RegisterEvent("PLAYER_TARGET_CHANGED");
				frame:RegisterEvent("PLAYER_ENTERING_WORLD");
				frame:SetScript("OnEvent", AptusAuraFrames_OnEvent);
				
				if ( not AptusAuraFrames.bars[#AptusAuraFrames['frames']+1] ) then
					AptusAuraFrames.bars[#AptusAuraFrames['frames']+1] = {};
					-- fullbars[i] = {};
				end
				local self = frame
				local row = 1
				local numonrow = 0
				-- if groups[i]['WeaponEnchant'] == true then
					-- TemporaryEnchantFrame:Hide()
					-- TemporaryEnchantFrame:HookScript("OnShow", function(self) self:Hide() end)
				-- end

				-- Setup aura AptusAuraFrames.bars
				for a=1, k['NumBars'] do
					bar = CreateFrame("Button", "aAFAnchor"..(#AptusAuraFrames['frames']+1).."Frame"..a, frame, "SecureActionButtonTemplate");
					bar:RegisterForClicks("RightButtonUp")	
					bar:SetAttribute("type", "cancelaura" )
					bar:SetAttribute("unit", "player")
					if not k['WeaponEnchant'] then
						bar:SetAttribute("index", a)
					else
						bar:SetAttribute("target-slot", a)
					end
					
					uBar = CreateFrame("FRAME", "aAFAnchor"..(#AptusAuraFrames['frames']+1)..'FrameUnderlay'..a, frame)
					uBar:SetAllPoints(bar)
					bar['bar'] = uBar
					uBar['bar'] = bar
					uBar:EnableMouse(true)
					
					-- Set moving scripts
					bar:SetScript("OnMouseDown", function(self)
						if ( IsShiftKeyDown() and IsAltKeyDown() ) then
							self:GetParent():StartMoving();
						end
					end);
					bar:SetScript("OnMouseUp", function(self)
						self:GetParent():StopMovingOrSizing();
						self:GetParent():SetUserPlaced(false)
					end);
					
					bar:SetWidth(k['size']);
					bar:SetHeight(k['size']);
					bar.shouldshow = true
					bar:SetScale(k['scale']);
					
					numonrow = numonrow + 1
					
					if ( a == 1 ) then
						
						-- If this is the first frame
						if ( self.GrowthDirection == "UP" ) then
							bar:SetPoint("BOTTOM", self);
						elseif ( self.GrowthDirection == "RIGHT" ) then
							bar:SetPoint("LEFT", self);
						elseif ( self.GrowthDirection == "LEFT" ) then
							bar:SetPoint("RIGHT", self);
						else
							bar:SetPoint("TOP", self);
						end
						
						-- If not first frame and we've reached the end of a row
					elseif self.BuffsPerRow ~= nil and (numonrow == (self.BuffsPerRow)+1) then
						if ( self.GrowthDirection == "UP" ) then
							if ( self.LineGrowth == "LEFT" ) then
								bar:SetPoint("RIGHT", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-self.BuffsPerRow], "LEFT", -self.LinePadding, 0);
							else
								bar:SetPoint("LEFT", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-self.BuffsPerRow], "RIGHT", self.LinePadding, 0);
							end
						elseif ( self.GrowthDirection == "RIGHT" ) then
							if ( self.LineGrowth == "UP" ) then
								bar:SetPoint("BOTTOM", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-self.BuffsPerRow], "TOP", 0, self.LinePadding);
							else
								bar:SetPoint("TOP", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-self.BuffsPerRow], "BOTTOM", 0, -self.LinePadding);
							end
						elseif ( self.GrowthDirection == "LEFT" ) then
							if ( self.LineGrowth == "UP" ) then
								bar:SetPoint("BOTTOM", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-self.BuffsPerRow], "TOP", 0, self.LinePadding);
							else
								bar:SetPoint("TOP", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-self.BuffsPerRow], "BOTTOM", 0, -self.LinePadding);
							end
						else
							if ( self.LineGrowth == "LEFT" ) then
								bar:SetPoint("RIGHT", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-self.BuffsPerRow], "LEFT", -self.LinePadding, 0);
							else
								bar:SetPoint("LEFT", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-self.BuffsPerRow], "RIGHT", self.LinePadding, 0);
							end
						end
						numonrow = 1
						row = row+1
					elseif	self.BuffsPerRow ~= nil and (numonrow > (self.BuffsPerRow)+1) then
						if ( self.GrowthDirection == "UP" ) then
							bar:SetPoint("BOTTOM", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-1], "TOP", 0, self.Padding);
						elseif ( self.GrowthDirection == "RIGHT" ) then
							bar:SetPoint("LEFT", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-1], "RIGHT", self.Mode == "ICON" and self.Padding or k[barWidth+self.Padding], 0);
						elseif ( self.GrowthDirection == "LEFT" ) then
							bar:SetPoint("RIGHT", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-1], "LEFT", self.Mode == "ICON" and -(self.Padding) or -(k['barWidth']+self.Padding), 0);
						else
							bar:SetPoint("TOP", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-1], "BOTTOM", 0, -self.Padding);
						end
					else
						if ( self.GrowthDirection == "UP" ) then
							bar:SetPoint("BOTTOM", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-1], "TOP", 0, self.Padding);
						elseif ( self.GrowthDirection == "RIGHT" ) then
							bar:SetPoint("LEFT", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-1], "RIGHT", self.Mode == "ICON" and self.Padding or k[barWidth+self.Padding], 0);
						elseif ( self.GrowthDirection == "LEFT" ) then
							bar:SetPoint("RIGHT", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-1], "LEFT", self.Mode == "ICON" and -(self.Padding) or -(k['barWidth']+self.Padding), 0);
						else
							bar:SetPoint("TOP", AptusAuraFrames.bars[#AptusAuraFrames['frames']+1][a-1], "BOTTOM", 0, -self.Padding);
						end
					end
					if ( self.Mode == "ICON" ) then
						bar.icon = uBar:CreateTexture("$parentIcon", "BACKGROUND");
						bar.icon:SetAllPoints();
						bar.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93);
								
						bar.cooldown = CreateFrame("Cooldown", nil, uBar, "CooldownFrameTemplate");
						bar.cooldown:SetAllPoints();
						bar.cooldown:SetReverse();
						
						bar.overlay = uBar:CreateTexture(nil, "ARTWORK");
						bar.overlay:SetTexture("Interface\\AddOns\\AptusAuraFrames\\Textures\\border");
						-- bar.overlay:SetFrameLevel(1)
						bar.overlay:SetPoint("TOPLEFT", -3, 3);
						bar.overlay:SetPoint("BOTTOMRIGHT", 3, -3);
						bar.overlay:SetVertexColor(0.25, 0.25, 0.25);
						
						bar.count = uBar:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall");
						-- bar.count:SetFrameLevel(2)
						if data.count then
							path, size, flags = bar.count:GetFont()
							point = data['count']['point'] or "TOP"
							relativePoint = data['count']['relativePoint'] or "BOTTOM"
							ofsx = data['count']['offsetX'] or 0
							ofsy = data['count']['offsetY'] or 0
							size = data['count']['size'] or size
							path = data['count']['fontpath'] or path
							flags = data['count']['flags'] or flags
						else
							point, relativePoint, ofsx, ofsy =  "BOTTOM", bar, "BOTTOM", 0, -35
							path, size, flags = bar.time:GetFont()
							size = 10
						end
						bar.count:SetJustifyH("RIGHT");
						bar.count:SetFont(path, size, flags)
						bar.count:ClearAllPoints()
						bar.count:SetPoint(point, bar, relativePoint, ofsx, ofsy);
						bar.count:SetJustifyH("RIGHT");
						
						bar.time = uBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall");
						local point, relativePoint, ofsx, ofsy, size, path, flags;
						if data.timer then
							path, size, flags = bar.time:GetFont()
							point = data['timer']['point'] or "TOP"
							relativePoint = data['timer']['relativePoint'] or "BOTTOM"
							ofsx = data['timer']['offsetX'] or 0
							ofsy = data['timer']['offsetY'] or 0
							size = data['timer']['size'] or size
							path = data['timer']['fontpath'] or path
							flags = data['timer']['flags'] or flags
						else
							point, relativePoint, ofsx, ofsy =  "BOTTOM", bar, "BOTTOM", 0, -35
							path, size, flags = bar.time:GetFont()
							size = 10
						end
						bar.time:SetFont(path, size, flags)
						bar.time:ClearAllPoints()
						bar.time:SetPoint(point, bar, relativePoint, ofsx, ofsy);
						bar.time:Show()
					-- else
						-- bar.icon = bar:CreateTexture(nil, "BACKGROUND");
						-- bar.icon:SetAllPoints();
						-- bar.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93);
								
						-- bar.count = bar:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall");
						-- bar.count:SetPoint("BOTTOMRIGHT");
						-- bar.count:SetJustifyH("RIGHT");
								
						-- bar.statusbar = CreateFrame("StatusBar", nil, bar);
						-- if ( configmode ) then
							-- bar.statusbar:SetFrameStrata("BACKGROUND");
						-- end
						-- bar.statusbar:SetWidth(groups[i]['barWidth'] or 200);
						-- bar.statusbar:SetHeight(groups[i]['size']);
						-- bar.statusbar:SetStatusBarTexture("Interface\\AddOns\\aAF\\Textures\\statusbar");
						-- bar.statusbar:SetStatusBarColor(0.4, 0.4, 0.4, 1);
						-- bar.statusbar:SetPoint("LEFT", bar, "RIGHT");
						-- bar.statusbar:SetMinMaxValues(0, 1);
						-- bar.statusbar:SetValue(0);
						-- bar.statusbar.background = bar.statusbar:CreateTexture(nil, "BACKGROUND");
						-- bar.statusbar.background:SetAllPoints(bar.statusbar);
						-- bar.statusbar.background:SetTexture("Interface\\AddOns\\aAF\\Textures\\statusbar");
						-- bar.statusbar.background:SetVertexColor(classcolor.r, classcolor.g, classcolor.b, 0.7);
						
						-- bar.time = bar.statusbar:CreateFontString(nil, "ARTWORK", "GameFontHighlightRight");
						-- bar.time:SetPoint("RIGHT", bar.statusbar, -2, 1);
								
						-- bar.spellname = bar.statusbar:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall");
						-- bar.spellname:SetPoint("LEFT", bar.statusbar, 2, 1);
						-- bar.spellname:SetPoint("RIGHT", bar.time, "LEFT");
						-- bar.spellname:SetJustifyH("CENTER");
						-- bar:Hide()
					end
							
					tinsert(AptusAuraFrames.bars[#AptusAuraFrames['frames']+1], bar);
					-- tinsert(fullbars[i], bar);
				end
				if not AptusAuraFrames.frames[#AptusAuraFrames['frames']+1] then
					tinsert(AptusAuraFrames.frames, frame)
				end
			end
		end
	end
end

local function compare(comp1, comp2)
	if comp1 and comp2 then
		-- print(comp1.duration, comp2.duration)
		if comp1.expirationTime and comp2.expirationTime then
			if comp1.expirationTime < comp2.expirationTime then
				-- print(comp1.expirationTime, ' < ', comp2.expirationTime)
				return true
			else
				-- print(comp1.expirationTime, ' > ', comp2.expirationTime)
				return false
			end
		elseif comp1.expirationTime and not comp2.expirationTime then
			print('no comp2.duration')
			return false
		elseif comp2.expirationTime and not comp1.expirationTime then
			print('no comp1.duration')
			return false
		else
			print('lolwat, how did this happen')
		end
	elseif comp1 and not comp2 then
		print('no comp2')
		return false
	elseif comp2 and not comp1 then
		print('no comp1')
		return true
	else 
		print('this makes no sense')
		return false
	end
end

local function reverse(oldtable)
   local newtable = {}
   for  k,v in pairs(oldtable) do
	  newtable[#oldtable+1-k] = v
   end
   return newtable
end

function AptusAuraFrames_OnEvent(self, event, ...)
	local unit = ...;
	local id = self.Id;
	local stuff = AptusAuraFrames['db']['profile']['frames'][id]
	-- print(id)
	if stuff and (( stuff.unitId == unit) or (  event == "PLAYER_TARGET_CHANGED" or event == "PLAYER_ENTERING_WORLD" or event == "SPELL_UPDATE_COOLDOWN" )) then 
		if (self:GetScript('OnEvent') ~= nil) then
			local name, rank, icon, count, debuffType, duration, expirationTime, caster, isStealable, buffindex;
			local auras = {}
			local debuff = nil;
			if ( not active[id] ) then
				active[id] = {};
			end
			wipe(active[id])
			if not stuff['NumBars'] then
				stuff['NumBars'] = 10
			end
			if not stuff['WeaponEnchant'] then
				data = stuff;
				for i=1, stuff['NumBars'], 1 do
					-- print(data.filter)
					if ( data.filter == "BUFF" ) then
						name, rank, icon, count, debuffType, duration, expirationTime, caster, isStealable = UnitBuff(data.unitId, i);
					elseif ( data.filter == "DEBUFF" ) then
						name, rank, icon, count, debuffType, duration, expirationTime, caster, isStealable = UnitDebuff(data.unitId, i);
					end
					buffindex = i
					if name then
						auras[i] = {name=name,buffindex = buffindex, rank=rank, icon=icon, count=count, debuffType=debuffType, duration=duration, expirationTime=expirationTime, caster=caster, isStealable=isStealable}
					else
						auras[i] = nil
					end
				end
				if stuff.sortby == 'DURATION'  then
					table.sort(auras, compare)
				end
				if stuff.Reverse == true then
					auras = reverse(auras)
				end
				for i,v in pairs(auras) do 
					if stuff['Blacklist'] then
						for a,b in pairs(stuff['Blacklist']) do
							if b == v.name or (v.name ~= nil and b == strlower(v.name)) then 
								v.name = nil
							elseif b == 'auras' then
								-- print(b.duration)
								if v.duration == 0 then
									v.name = nil
								end
							elseif string.find(b, 'duration') then
								if string.find(b, '<') then
									if v.duration < tonumber(string.match(b, '%d+')) then
										v.name = nil
									end
								elseif string.find(b, '>') then
									if v.duration > tonumber(string.match(b, '%d+')) then
										v.name = nil
									end
								end
							elseif string.find(b, 'remaining') then
								if string.find(b, '<') then
									if v.expirationTime - GetTime() < tonumber(string.match(b, '%d+')) then
										v.name = nil
									end
								elseif string.find(b, '>') then
									if v.expirationTime - GetTime() > tonumber(string.match(b, '%d+')) then
										v.name = nil
									end
								end
							end
						end
					elseif stuff['Whitelist'] then
						if not stuff['Whitelist'][1] then
							stuff['Whitelist'] = nil
						else
							local count = 0
							for a,b in pairs(stuff['Whitelist']) do
								if b == v.name or (v.name ~= nil and b == strlower(v.name)) then
									break
								elseif b == 'auras' and v.duration == 0 then
									break
								else
									count = count+1
								end
								if count == #stuff['Whitelist'] then
									v.name = nil
								end
							end
						end
					end
					if ( ( v.name and ( v.caster == data.caster or data.caster == "all" ) ) ) then
						-- print(v.name)
						table.insert(active[id], {buffindex = v.buffindex, spellName = v.name, data = data, caster = v.caster, icon = v.icon, count = v.count, duration = v.duration, expirationTime = v.expirationTime or start });
					end
				end
			end
			aAF_Update(self);
		end
	end
	if event == "PLAYER_LOGOUT" and dontsavedamit ~= true then
		-- if not AptusAuraFrames['db']['profile']['aAF_Profiles'] then
			AptusAuraFrames['db']['profile']['aAF_Profiles'] = {}
		-- end
		-- if AptusAuraFrames['db']['profile']['aAF_Profiles'] == nil then
			AptusAuraFrames['db']['profile']['aAF_Profiles'] = {}
		-- end	
		-- if AptusAuraFrames['db']['profile']['aAF_Profiles']['positions'] == nil then
		 	AptusAuraFrames['db']['profile']['aAF_Profiles']['positions'] = {}
			wipe(AptusAuraFrames['db']['profile']['aAF_Profiles']['positions'])
		-- end
		-- if wat == true then
			-- AptusAuraFrames['db']['profile']['aAF_Profiles']['positions'] = aaf_positions
		-- else
		for index, frame in pairs(AptusAuraFrames.bars) do
			AptusAuraFrames['db']['profile']['aAF_Profiles']['positions'][frame[1]:GetParent()['name']] = {}
			wipe(AptusAuraFrames['db']['profile']['aAF_Profiles']['positions'][frame[1]:GetParent()['name']])
			local pointtable = AptusAuraFrames['db']['profile']['aAF_Profiles']['positions'][frame[1]:GetParent()['name']]
			local p, loluiparent, rp, ofsx, ofsy = frame[1]:GetParent():GetPoint()
			table.insert(pointtable, p)
			table.insert(pointtable, rp)
			table.insert(pointtable, ofsx)
			table.insert(pointtable, ofsy)
		end
		-- end
		
		return
	elseif event == "PLAYER_REGEN_ENABLED" then
		AptusAuraFrames_PLAYER_REGEN_ENABLED(self)
	elseif event == "PLAYER_REGEN_DISABLED" then
		AptusAuraFrames_PLAYER_REGEN_DISABLED(self)
	end
end

function aAF_Update(self)
	-- print(self.Id)
	local id = self.Id;
	local barId = self.barId
	if ( not AptusAuraFrames.bars[barId] ) then
		AptusAuraFrames.bars[barId] = {};
	end
	for index, value in ipairs(AptusAuraFrames.bars[barId]) do
		-- value:Hide();
		if not InCombatLockdown() then
			value:Hide()
		end
		value.bar:Hide()
		value.time:SetText(nil)
	end
	local bar;
	local uBar;
	for index, value in ipairs(active[id]) do
		bar = AptusAuraFrames.bars[barId][index];
		uBar = bar.bar
		activeid = active
		-- print(value.buffindex)
		if not InCombatLockdown() then
			bar:SetAttribute('index', value.buffindex)
		end
		bar.unitId = value.data.unitId
		bar.filter = value.data.filter
		bar.WeaponEnchant = value.data.WeaponEnchant
		bar.buffindex = value.buffindex;
		bar.icon:SetTexture(value.icon);
		bar.caster = value.caster
		bar.expirationTime = value.expirationTime or 0
		-- print(bar.expirationTime)
		bar.duration = value.duration or 0
		-- print(bar.duration)
		if value.count and value.count <= 1 then value.count = nil end
		bar.count:SetText(value.count or "");
		bar.slot = value.slot
		if ( self.Mode == "BAR" ) then
			bar.spellname:SetText(value.data.displayName or value.data.spellName);
		end
		if not bar:GetScript('OnEnter') then
			bar:SetScript("OnEnter", (function(self)
				GameTooltip:SetOwner(self, ANCHOR_BOTTOMLEFT, -3, -3)
				-- print(self.buffindex)
				if self.WeaponEnchant == true then
					local hasItem, hasCooldown, repairCost =  GameTooltip:SetInventoryItem("player",self.slot)
				elseif self.filter == 'BUFF' then
					GameTooltip:SetUnitBuff(self.unitId, self.buffindex)
				else
					GameTooltip:SetUnitDebuff(self.unitId, self.buffindex)
				end
				GameTooltip:Show()
				-- print(UnitName(self.caster))
				if self.caster then
					GameTooltip:AddLine(UnitName(self.caster))
					GameTooltip:Show()
					-- print(self.caster)
				end	
			end))
			bar:SetScript("OnLeave", (function()
				GameTooltip:ClearLines()
				GameTooltip:Hide()
			end))
		end
		if not uBar:GetScript('OnEnter') then
			uBar:SetScript("OnEnter", (function(self)
				GameTooltip:SetOwner(self, ANCHOR_BOTTOMLEFT, -3, -3)
				-- print(self.buffindex)
				if self.bar.WeaponEnchant == true then
					local hasItem, hasCooldown, repairCost =  GameTooltip:SetInventoryItem("player",self.bar.slot)
				elseif self.bar.filter == 'BUFF' then
					GameTooltip:SetUnitBuff(self.bar.unitId, self.bar.buffindex)
				else
					GameTooltip:SetUnitDebuff(self.bar.unitId, self.bar.buffindex)
				end
				GameTooltip:Show()
				-- print(UnitName(self.caster))
				if self.bar.caster then
					GameTooltip:AddLine(UnitName(self.bar.caster))
					GameTooltip:Show()
					-- print(self.caster)
				end	
			end))
			uBar:SetScript("OnLeave", (function()
				GameTooltip:ClearLines()
				GameTooltip:Hide()
			end))
		end
		if ( bar.duration > 0 ) then
			if ( self.Mode == "ICON" ) then
				CooldownFrame_SetTimer(bar.cooldown, value.data.filter == "CD" and value.expirationTime or value.expirationTime-value.duration, value.duration, 1);
				if value.data.timers == true or value.data.timers == 1 then
					if not bar:GetScript("OnUpdate") then
						bar.last = 0
						AptusAuraFrames.bars[barId][1]:SetScript("OnUpdate", UpdateTimes);
					end
				end
			-- else
				-- bar.statusbar:SetMinMaxValues(0, value.duration);
				-- bar.duration = value.duration;
				-- bar.filter = value.data.filter;
				-- print(bar.expirationTime, bar.duration, bar.filter)
				-- bar:SetScript("OnUpdate", OnUpdate);
			end
		else
			if ( self.Mode == "ICON" ) then
				bar.expirationTime = 0;
				bar.duration = 0;
				-- bar.timer = 0;
				bar.cooldown:Hide();
				-- bar.time:SetText("");
			else
				bar.statusbar:SetMinMaxValues(0, 1);
				bar.statusbar:SetValue(1);
				bar.time:SetText("");
				-- bar:SetScript("OnUpdate", nil);
			end
		end
		if  value.data.timers == true or value.data.timers == 1 then
			-- print(bar.duration)
			UpdateTimes(AptusAuraFrames.bars[barId][1], 0.2)
		end
		if bar.shouldshow == true then
			if not InCombatLockdown() then
				bar:Show()
			end
			bar.bar:Show()
		end
	end
end

function UpdateTimes(self, elapsed)
	local id = self:GetParent()['Id']
	local barId = self:GetParent()['barId']
	local frame = self:GetParent()
	-- print(id)
	-- local frame = AptusAuraFrames.bars[id]
	if self.last then
		self.last = self.last+elapsed
	else
		self.last = 0.0
	end
	if self.last > 0.2 then
		-- print(elapsed)
		self.last = 0
		self.terminator = 0
		for a, value in pairs(AptusAuraFrames.bars[barId]) do
			if value.expirationTime then
				local timer = value.expirationTime-GetTime();
				-- print(value.expirationTime, timer)
				if timer >= 0 then
					if frame.TimerType == 1 then
						value.time:SetFormattedText(SecondsToTimeAbbrev(timer));
					end
					self.terminator = 1
					-- AptusAuraFrames_OnEvent(self:GetParent(), "PLAYER_TARGET_CHANGED");
				else 
					-- self.terminator = self.terminator+1
					value.duration = 0;
					-- bar.timer = 0;
					value.time:SetText("")
					-- value.expirationTime = 0
				end
			end
		end
		if self.terminator == 0 then
			self:SetScript('OnUpdate', nil)
		end
	end
end

function AptusAuraFrames:ChatCommand(input)
	-- Called when a chat command is input with /aaf
	input = strlower(input)
    if not input or input:trim() == "" then
		UpdateOptions()
        InterfaceOptionsFrame_OpenToCategory(self.optionsFrame)
    elseif ( input == 'move' ) then
		for key,bar in pairs(AptusAuraFrames.bars) do
			if (bar[1]:GetParent()):GetScript('OnEvent') then 
				(bar[1]:GetParent()):SetScript("OnEvent", nil)
				if key == 1 then
					print('Entering Configuration Mode')
				end
			else
				(bar[1]:GetParent()):SetScript("OnEvent", AptusAuraFrames_OnEvent)
				if key == 1 then
					print('Leaving Configuration Mode')
				end
			end
			for index,buff in pairs(bar) do
				buff['icon']:SetTexture('Interface\\Icons\\Inv_misc_screwdriver_01')
				if buff.shouldshow == true then
					if not InCombatLockdown() then
						buff:Show()
					end
					buff.bar:Show()
				end
				if not (bar[1]:GetParent()):GetScript('OnEvent') then
					if index ~= 1 then
						buff:SetScript("OnEnter", nil)
						buff.bar:SetScript("OnEnter", nil)
					else
						buff.bar:SetScript("OnEnter", (function()
							GameTooltip:SetOwner(buff.bar, ANCHOR_BOTTOMLEFT, -3, -3)
							GameTooltip:SetText((buff:GetParent()).name)
							GameTooltip:Show()
						end))
						buff:SetScript("OnLeave", (function()
							GameTooltip:Hide()
						end))
						buff:SetScript("OnEnter", (function()
							GameTooltip:SetOwner(buff, ANCHOR_BOTTOMLEFT, -3, -3)
							GameTooltip:SetText((buff:GetParent()).name)
							GameTooltip:Show()
						end))
						buff:SetScript("OnLeave", (function()
							GameTooltip:Hide()
						end))
					end
				else
					buff:SetScript("OnEnter", nil)
					buff.bar:SetScript("OnEnter", nil)
				end
			end	
			if (bar[1]:GetParent()):GetScript('OnEvent') then
				self = (bar[1]:GetParent())
				AptusAuraFrames_OnEvent(self, "PLAYER_TARGET_CHANGED");
			end
		end
	end
end

function AptusAuraFrames_PLAYER_REGEN_DISABLED(self)
	local id = self.Id;
	local barId = self.barId
	for index, value in ipairs(AptusAuraFrames.bars[barId]) do
		value:Hide()
	end
	-- print('In Combat')
end

function AptusAuraFrames_PLAYER_REGEN_ENABLED(self)
	local id = self.Id;
	local barId = self.barId
	AptusAuraFrames_OnEvent(self, "PLAYER_TARGET_CHANGED");
	-- print('Leaving Combat')
end
