Config = {}

-- Modify MarginTop value to move widget from top of the screen (higher value = lower on screen)
Config.MarginTop = 0

-- Modify MarginRight value to move widget from right of the screen (higher value = more to the left of the screen)
Config.MarginRight = 0