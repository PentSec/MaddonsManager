-- This file is script-generated and should not be manually edited. 
-- Localizers may copy this file to edit as necessary. 
local AceLocale = LibStub:GetLibrary("AceLocale-3.0") 
local L = AceLocale:NewLocale("SimpleMD", "enUS", true) 
if not L then return end 

-- SimpleMD.lua
L["%s cast Misdirection on %s"] = true
L["%s cast Tricks on %s"] = true
L["Misdirection fades from %s"] = true
L["Tricks fades from %s"] = true
L["%s has 10 seconds left on MD cooldown!"] = true
L["%s has 5 seconds left on MD cooldown!"] = true
L["%s has 15 seconds left on MD cooldown!"] = true
L["%s has MD ready!"] = true
L["%s used Readiness! MD ready!"] = true
L["%s has 10 seconds left on Tricks cooldown!"] = true
L["%s has 5 seconds left on Tricks cooldown!"] = true
L["%s has 15 seconds left on Tricks cooldown!"] = true
L["%s has Tricks ready!"] = true

-- SMD_Menu.lua
L["Anchor"] = true
L["Show the dragable anchor."] = "Toggle the dragable anchor."
L["Bar"] = true
L["Bar Options"] = true
L["Bar Texture"] = true
L["Bar Color"] = true
L["Set the default bar color."] = true
L["Threat Transfer Color"] = true
L["Set the bar color when transferring threat."] = true
L["Cooldown Color"] = true
L["Set the bar color when Misdirection is on cooldown."] = true
L["Background Color"] = true
L["Set the bar background color."] = true
L["Transfer Bar Background Color"] = true
L["Set the transfer bar background color."] = true
L["Background Alpha"] = true
L["Set the bar background alpha."] = true
L["Font"] = true
L["Text Color"] = true
L["Set the bar text color."] = true
L["Text Size"] = true
L["Set the bar text size."] = true
L["Bar Scale"] = true
L["Set the bar scale."] = true
L["Bar Height"] = true
L["Set the bar height."] = true
L["Bar Width"] = true
L["Set the bar width."] = true
L["Grow Up"] = true
L["Toggle the bar growing upwards or downwards."] = true
L["Reverse"] = true
L["Toggle the bar fill direction."] = true
L["Static Bars"] = true
L["Toggle the static bars feature"] = true
L["Message Text Options"] = true
L["Options for setting the various alert texts"] = true
L["5 Second Warning"] = true
L["Set Five Seconds Remaining Message. NOTE: Use %s once to insert a name."] = true
L["10 Second Warning"] = true
L["Set Ten Seconds Remaining Message. NOTE: Use %s once to insert a name."] = true
L["15 Second Warning"] = true
L["Set Fifteen Seconds Remaining Message. NOTE: Use %s once to insert a name."] = true
L["Cooldown Finished Warning"] = true
L["Set Cooldown Finished Message. NOTE: Use %s once to insert a name."] = true
L["Readiness Warning"] = true
L["Set Readiness Message. NOTE: Use %s once to insert a name."] = true
L["Message Text Color"] = true
L["Set the color of the messages shown in Floating Combat Text"] = true
L["Broadcast Options"] = true
L["Options for how and where the alerts are displayed"] = true
L["Show in Chat"] = true
L["Toggles the display of the alerts as self messages"] = true
L["Show in Channel"] = true
L["Toggles broadcasting of alerts to a user defined channel"] = true
L["Show in Combat Text"] = true
L["Toggles showing alerts in popular SCT like mods"] = true
L["Show Own Alerts"] = true
L["Toggles showing your alerts on your client"] = true
L["Custom Channel"] = true
L["Show in Raid Warning"] = true
L["Broadcast Misdirection casts to Raid Warning"] = true
L["Show Gain Message"] = true
L["Toggles the display and broadcast of the Gain message"] = true
L["Show Faded Message"] = true
L["Toggles the display and broadcast of the Faded message"] = true
L["Show in Party Chat"] = true
L["Toggles broadcasting alerts to Party chat"] = true
L["Show in Raid Chat"] = true
L["Toggles broadcasting alerts to Raid chat"] = true
L["Show in Yells"] = true
L["Toggles broadcasting alerts to Yells"] = true
L["Cooldown Broadcast Options"] = true
L["Toggle which cooldown warnings you want to display to other users"] = true
L["Show Cooldown Bars"] = true
L["Toggles the creation of cooldown bars"] = true
L["CD Finished Warning"] = true
L["Display a warning when MD cooldown finishes"] = true
L["Readiness Message"] = true
L["Toggle showing readiness messages"] = true
L["Display a warning with 10 seconds left on MD cooldown"] = true
L["Display a warning with 5 seconds left on MD cooldown"] = true
L["Display a warning with 15 seconds left on MD cooldown"] = true

-- SMD_Timers.lua
-- no localization

