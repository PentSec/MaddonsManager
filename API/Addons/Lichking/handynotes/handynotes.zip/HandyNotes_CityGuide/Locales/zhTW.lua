﻿local L = LibStub("AceLocale-3.0"):NewLocale("HandyNotes_CityGuide", "zhTW")
if not L then return end

--
-- DO NOT MODIFY!
--
-- These localizations are generated automatically from WowAce Localization Tool
-- Please use this URL to edit:
--
-- http://www.wowace.com/addons/handy-notes_city-guide/localization/zhTW/
--

L["CityGuide"] = "城市指南"
L["Close"] = "關閉"
L["Create waypoint"] = "建立路徑點"
L["Delete note"] = "刪除註記"
L["Filters"] = "篩選"
L["HandyNotes - CityGuide"] = "HandyNotes - 城市指南"
L["Icon Alpha"] = "圖示透明度"
L["Icon Scale"] = "圖示比例"
L["The alpha transparency of the icons"] = "圖示的透明程度"
L["The scale of the icons"] = "圖示的比例"
L["These settings control the look and feel of the CityGuide icons."] = "這些設定控制城市指南圖示的外觀和風格。"
L["TYPE_Auctioneer"] = "拍賣師"
L["TYPE_Banker"] = "銀行職員"
L["TYPE_BattleMaster"] = "戰場軍官"
L["TYPE_SpiritHealer"] = "靈魂醫者"
L["TYPE_StableMaster"] = "獸欄管理員"


