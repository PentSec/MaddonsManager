﻿local L = LibStub("AceLocale-3.0"):NewLocale("HandyNotes_CityGuide", "koKR")
if not L then return end

--
-- DO NOT MODIFY!
--
-- These localizations are generated automatically from WowAce Localization Tool
-- Please use this URL to edit:
--
-- http://www.wowace.com/addons/handy-notes_city-guide/localization/koKR/
--

L["CityGuide"] = "CityGuide"
L["Close"] = "닫기"
L["Create waypoint"] = "웨이포인트 만들기"
L["Delete note"] = "노트 삭제"
L["Filters"] = "필터"
L["HandyNotes - CityGuide"] = "HandyNotes - CityGuide"
L["Icon Alpha"] = "아이콘 투명도"
L["Icon Scale"] = "아이콘 크기비율"
L["The alpha transparency of the icons"] = "아이콘의 투명도"
L["The scale of the icons"] = "아이콘의 크기비율"
L["These settings control the look and feel of the CityGuide icons."] = "CityGuide의 아이콘들을 설정을 조절합니다."
L["TYPE_Auctioneer"] = "경매인"
L["TYPE_Banker"] = "은행원"
-- L["TYPE_BattleMaster"] = "Battle Master"
L["TYPE_SpiritHealer"] = "구원의 영혼"
L["TYPE_StableMaster"] = "전문 기수"


