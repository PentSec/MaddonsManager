﻿local L = LibStub("AceLocale-3.0"):NewLocale("HandyNotes_CityGuide", "ruRU")
if not L then return end

--
-- DO NOT MODIFY!
--
-- These localizations are generated automatically from WowAce Localization Tool
-- Please use this URL to edit:
--
-- http://www.wowace.com/addons/handy-notes_city-guide/localization/ruRU/
--

L["CityGuide"] = "CityGuide"
L["Close"] = "Закрыть"
L["Create waypoint"] = "Создать точку назначения"
L["Delete note"] = "Удалить заметку"
L["Filters"] = "Фильтры"
L["HandyNotes - CityGuide"] = "HandyNotes - CityGuide"
L["Icon Alpha"] = "Прозрачность значка"
L["Icon Scale"] = "Масштаб значка"
L["The alpha transparency of the icons"] = "Прозрачность значков"
L["The scale of the icons"] = "Масштаб значков"
L["These settings control the look and feel of the CityGuide icons."] = "Эти настройки контролируют вид значков CityGuide."
L["TYPE_Auctioneer"] = "Аукционер"
L["TYPE_Banker"] = "Банкир"
L["TYPE_BattleMaster"] = "Военачальник"
L["TYPE_SpiritHealer"] = "Целитель душ"
L["TYPE_StableMaster"] = "Смотритель стойл"


