﻿local L = LibStub("AceLocale-3.0"):NewLocale("HandyNotes_CityGuide", "frFR")
if not L then return end

--
-- DO NOT MODIFY!
--
-- These localizations are generated automatically from WowAce Localization Tool
-- Please use this URL to edit:
--
-- http://www.wowace.com/addons/handy-notes_city-guide/localization/frFR/
--

L["CityGuide"] = "CityGuide"
L["Close"] = "Fermer"
L["Create waypoint"] = "Créer une route"
L["Delete note"] = "Supprimer la note"
L["Filters"] = "Filtres"
L["HandyNotes - CityGuide"] = "HandyNotes - CityGuide"
L["Icon Alpha"] = "Icon Alpha"
L["Icon Scale"] = "échelle de l'icône"
L["The alpha transparency of the icons"] = "Alpha transparence des icônes"
L["The scale of the icons"] = "échelle des icônes"
L["These settings control the look and feel of the CityGuide icons."] = "Ces paramètres contrôle le look des icônes de CityGuide."
L["TYPE_Auctioneer"] = "commissaire-priseur"
L["TYPE_Banker"] = "Banque"
L["TYPE_BattleMaster"] = "Maître de Bataille"
L["TYPE_SpiritHealer"] = "Gardien des âmes"
L["TYPE_StableMaster"] = "Maître des écuries"


