﻿local L = LibStub("AceLocale-3.0"):NewLocale("HandyNotes_Vendors", "esES")
if not L then return end

--
-- DO NOT MODIFY!
--
-- These localizations are generated automatically from WowAce Localization Tool
-- Please use this URL to edit:
--
-- http://www.wowace.com/addons/handy-notes_vendors/localization/esES/
--

L["Close"] = "Cerrar"
L["Create waypoint"] = "Crear punto de ruta"
L["Delete vendor"] = "Eliminar vendedor"
L["Filters"] = "Filtros"
L["HandyNotes - Vendors"] = "HandyNotes - Vendedores"
L["Icon Alpha"] = "Alfa Icono"
L["Icon Scale"] = "Escala Icono"
L["Minimap Filter"] = "Filtro del Minimapa"
L["The alpha transparency of the icons"] = "La transparencia alfa de los iconos"
L["The scale of the icons"] = "El tamaño de los iconos"
L["These settings control the look and feel of the Vendors icons."] = "Esta configuración controla la apariencia de los iconos de los vendedores."
L["TYPE_Innkeeper"] = "Tabernero"
L["TYPE_Repair"] = "Armero"
L["TYPE_Vendor"] = "Vendedor"
L["Vendor"] = "Vendedor"
L["World Map Filter"] = "Filtro del Mapa del Mundo"

