﻿local L = LibStub("AceLocale-3.0"):NewLocale("HandyNotes_Vendors", "ruRU")
if not L then return end

--
-- DO NOT MODIFY!
--
-- These localizations are generated automatically from WowAce Localization Tool
-- Please use this URL to edit:
--
-- http://www.wowace.com/addons/handy-notes_vendors/localization/ruRU/
--

L["Close"] = "Закрыть"
L["Create waypoint"] = "Создать точку назначения"
L["Delete vendor"] = "Удалить торговца"
L["Filters"] = "Фильтры"
L["HandyNotes - Vendors"] = "HandyNotes - Vendors"
L["Icon Alpha"] = "Прозрачность значка"
L["Icon Scale"] = "Масштаб значка"
L["Minimap Filter"] = "Фильтр миникарты"
L["The alpha transparency of the icons"] = "Прозрачность значков"
L["The scale of the icons"] = "Масштаб значков"
L["These settings control the look and feel of the Vendors icons."] = "Эти настройки контролируют вид значков Торговцев."
L["TYPE_Innkeeper"] = "Хозяин таверны"
L["TYPE_Repair"] = "Оружейник"
L["TYPE_Vendor"] = "Торговец"
L["Vendor"] = "Торговец"
L["World Map Filter"] = "Фильтр карты мира"

