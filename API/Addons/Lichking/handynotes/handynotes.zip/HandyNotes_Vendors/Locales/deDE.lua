﻿local L = LibStub("AceLocale-3.0"):NewLocale("HandyNotes_Vendors", "deDE")
if not L then return end

--
-- DO NOT MODIFY!
--
-- These localizations are generated automatically from WowAce Localization Tool
-- Please use this URL to edit:
--
-- http://www.wowace.com/addons/handy-notes_vendors/localization/deDE/
--

L["Close"] = "schließen"
L["Create waypoint"] = "Generiere Wegpunkt"
L["Delete vendor"] = "Lösche Händler"
L["Filters"] = "Was soll angezeigt werden?"
L["HandyNotes - Vendors"] = "HandyNotes - Verkäufer"
L["Icon Alpha"] = "Icon-Transparenz"
L["Icon Scale"] = "Icon-Skalierung"
-- L["Minimap Filter"] = "Minimap Filter"
L["The alpha transparency of the icons"] = "Die Transparenz der Icons"
L["The scale of the icons"] = "Die Skalierung der Icons"
L["These settings control the look and feel of the Vendors icons."] = "Diese Einstellungungen kontrollieren das Aussehen und die Wirkung der Verkäufer-Icons"
L["TYPE_Innkeeper"] = "Gastwirt"
L["TYPE_Repair"] = "Schmied"
L["TYPE_Vendor"] = "Verkäufer"
L["Vendor"] = "Händler"
-- L["World Map Filter"] = "World Map Filter"


