﻿local L = LibStub("AceLocale-3.0"):NewLocale("HandyNotes_Vendors", "zhTW")
if not L then return end

--
-- DO NOT MODIFY!
--
-- These localizations are generated automatically from WowAce Localization Tool
-- Please use this URL to edit:
--
-- http://www.wowace.com/addons/handy-notes_vendors/localization/zhTW/
--

L["Close"] = "關閉"
L["Create waypoint"] = "建立路徑點"
L["Delete vendor"] = "刪除商人"
L["Filters"] = "篩選"
L["HandyNotes - Vendors"] = "HandyNotes - 商人"
L["Icon Alpha"] = "圖示透明度"
L["Icon Scale"] = "圖示比例"
L["Minimap Filter"] = "小地圖篩選"
L["The alpha transparency of the icons"] = "圖示的透明程度"
L["The scale of the icons"] = "圖示的比例"
L["These settings control the look and feel of the Vendors icons."] = "這些設定控制商人圖示的外觀和風格。"
L["TYPE_Innkeeper"] = "旅店老闆"
L["TYPE_Repair"] = "護甲商"
L["TYPE_Vendor"] = "商人"
L["Vendor"] = "商人"
L["World Map Filter"] = "世界地圖篩選"


