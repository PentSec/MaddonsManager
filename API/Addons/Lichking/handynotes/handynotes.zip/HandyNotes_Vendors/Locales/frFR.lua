﻿local L = LibStub("AceLocale-3.0"):NewLocale("HandyNotes_Vendors", "frFR")
if not L then return end

--
-- DO NOT MODIFY!
--
-- These localizations are generated automatically from WowAce Localization Tool
-- Please use this URL to edit:
--
-- http://www.wowace.com/addons/handy-notes_vendors/localization/frFR/
--

L["Close"] = "Fermer"
L["Create waypoint"] = "Creer un point de passage"
L["Delete vendor"] = "Effacer le commerçant"
L["Filters"] = "Filtre"
L["HandyNotes - Vendors"] = "HandyNotes - Vendeur"
L["Icon Alpha"] = "Alpha icone"
L["Icon Scale"] = "Echelle de l'icone"
L["Minimap Filter"] = "Filtrage de la Mini Carte"
L["The alpha transparency of the icons"] = "Transparence Alpha de l'icone"
L["The scale of the icons"] = "Echelle des icones"
L["These settings control the look and feel of the Vendors icons."] = "Ces paramètres contrôlent l'affichage des icones des vendeurs"
L["TYPE_Innkeeper"] = "Aubergiste"
L["TYPE_Repair"] = "Réparateur"
L["TYPE_Vendor"] = "Vendeur"
L["Vendor"] = "Vendeur"
L["World Map Filter"] = "Filtrage Carte du monde"


