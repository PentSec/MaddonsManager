﻿local L = LibStub("AceLocale-3.0"):NewLocale("HandyNotes_Vendors", "koKR")
if not L then return end

--
-- DO NOT MODIFY!
--
-- These localizations are generated automatically from WowAce Localization Tool
-- Please use this URL to edit:
--
-- http://www.wowace.com/addons/handy-notes_vendors/localization/koKR/
--

L["Close"] = "닫기"
L["Create waypoint"] = "웨이포인트 추가"
L["Delete vendor"] = "상인 삭제"
-- L["Filters"] = "Filters"
L["HandyNotes - Vendors"] = "HandyNotes - 상인"
L["Icon Alpha"] = "아이콘 투명도"
L["Icon Scale"] = "아이콘 크기"
-- L["Minimap Filter"] = "Minimap Filter"
L["The alpha transparency of the icons"] = "아이콘 투명도를 변경합니다."
L["The scale of the icons"] = "아이콘의 크기를 변경합니다."
L["These settings control the look and feel of the Vendors icons."] = "이 설정은 상인 아이콘에만 적용됩니다."
L["TYPE_Innkeeper"] = "Innkeeper" -- Needs review
L["TYPE_Repair"] = "Armorer" -- Needs review
L["TYPE_Vendor"] = "Vendor" -- Needs review
L["Vendor"] = "상인"
-- L["World Map Filter"] = "World Map Filter"



