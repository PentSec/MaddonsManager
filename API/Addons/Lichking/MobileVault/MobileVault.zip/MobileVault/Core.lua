﻿--[[
MobileVault
Author: Michael Joseph Murray aka Lyte of Lothar(US)
Please see license.txt for details.
$Revision: 128 $
$Date: 2010-05-28 22:08:16 +0000 (Fri, 28 May 2010) $
Project Version: r134
contact: codemaster2010 AT gmail DOT com

Copyright (c) 2007-2010 Michael J. Murray aka Lyte of Lothar(US)
All rights reserved unless otherwise explicitly stated.
]]

MobileVault = LibStub("AceAddon-3.0"):NewAddon("MobileVault", "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("MobileVault")

--deal with keybinding stuff
BINDING_HEADER_MOBILEVAULT = "Mobile Vault"
BINDING_NAME_MGVTOGGLE = L["Toggle Frame"]

--create our LDB launcher
LibStub:GetLibrary("LibDataBroker-1.1"):NewDataObject("MobileVault", {
	type = "launcher",
	label = "MobileVault",
	OnClick = function(_, button)
		if button == "LeftButton" then
			--open vault frame
			MobileVault:ShowVaultFrame()
		elseif button == "RightButton" then
			--open config
			LoadAddOn("MobileVault_Options")
			LibStub("AceConfigDialog-3.0"):Open("MobileVault")
		end
	end,
	icon = [[Interface\AddOns\MobileVault\icon]],
	OnTooltipShow = function(tooltip)
		if not tooltip or not tooltip.AddLine then return end
		tooltip:AddLine("MobileVault")
		tooltip:AddLine("|cffffff00" .. L["Click|r to toggle the Vault window"])
		tooltip:AddLine("|cffffff00" .. L["Right-click|r to open the options menu"])
	end,
})

function MobileVault:OnInitialize()
	local defaults = {
		profile = {
			position = {},
			guildTooltips = {
				['*'] = true,
			},
			frameColor = {0, 0, 0},
			highlightColor = {0, 0, 1},
			itemBorderColor = {1, 1, 1},
			selectedColor = {0, 1, 1},
			tabBorderColor = {1, 1, 1},
			textColor = {1, 1, 1},
			frameAlpha = 1,
			tooltipColor = "eda55f",
			itemPadding = 0,
			tabButtonSpacing = 7,
			strata = "LOW",
			scale = 1,
		},
		realm = {
			['*'] = {
				links = {
					['*'] = {},
				},
				info = {
					['*'] = {},
				},
				tabs = {
					names = {},
					textures = {},
					views = {},
				},
			},
		},
	}
	
	self.db = LibStub("AceDB-3.0"):New("MobileVaultDB", defaults, "Default")
	self.guilds = self.db.realm
	self.db.RegisterCallback(self, "OnProfileReset", "Update")
	self.db.RegisterCallback(self, "OnProfileCopied", "Update")
	self.db.RegisterCallback(self, "OnProfileChanged", "Update")
	
	_G["SlashCmdList"]["MOBILEVAULT_MAIN"] = function(s)
		if string.lower(s) == "show" then
			--open vault frame
			MobileVault:ShowVaultFrame()
		else
			LoadAddOn("MobileVault_Options")
			LibStub("AceConfigDialog-3.0"):Open("MobileVault")
		end
	end
	_G["SLASH_MOBILEVAULT_MAIN1"] = "/mgv"
	_G["SLASH_MOBILEVAULT_MAIN2"] = "/mobilevault"
end

function MobileVault:OnEnable()
	self:RegisterEvent("GUILDBANKFRAME_OPENED")
	self:RegisterEvent("GUILDBANK_UPDATE_MONEY")
	self:RegisterEvent("GUILDBANKBAGSLOTS_CHANGED", "ScanPage")
	self:RegisterEvent("PLAYER_GUILD_UPDATE", "ObtainGuildName")
	
	self.frame = self:CreateVaultFrame()
	self.activePage = 0
	self:ScheduleTimer("ObtainGuildName", 0.25)
end

function MobileVault:Update()
	--set the main frame properties
	self.frame:SetWidth(600*self.db.profile.scale)
	self.frame:SetHeight(375*self.db.profile.scale)
	self.frame.actionbutton:SetWidth(100*self.db.profile.scale)
	self.frame.actionbutton:SetHeight(22*self.db.profile.scale)
	self.frame.text:SetWidth(600*self.db.profile.scale)
	self.frame.text:SetHeight(20*self.db.profile.scale)
	self.frame.subtext:SetWidth(600*self.db.profile.scale)
	self.frame.subtext:SetHeight(20*self.db.profile.scale)
	self.frame.scan:SetHeight(20*self.db.profile.scale)
	self.frame.gold:SetHeight(20*self.db.profile.scale)
	self.frame:SetFrameStrata(self.db.profile.strata)
	self.frame:SetAlpha(self.db.profile.frameAlpha)
	
	--set the main frame position
	if self.db.profile.position.x then
		self.frame:ClearAllPoints()
		self.frame:SetPoint(self.db.profile.position.point, UIParent, self.db.profile.position.anchor, self.db.profile.position.x, self.db.profile.position.y)
	else
		self.frame:SetPoint("CENTER", UIParent, "CENTER", 0, 200)
	end
	
	--set the main frame colors
	self.frame:SetBackdropColor(unpack(self.db.profile.frameColor))
	self.frame.text:SetTextColor(unpack(self.db.profile.textColor))
	self.frame.subtext:SetTextColor(unpack(self.db.profile.textColor))
	self.frame.scan:SetTextColor(unpack(self.db.profile.textColor))
	self.frame.gold:SetTextColor(unpack(self.db.profile.textColor))
	
	--iterate the item slots
	for i = 1, 98 do
		--sizes
		self.frame.items[i]:SetWidth(40*self.db.profile.scale)
		self.frame.items[i]:SetHeight(40*self.db.profile.scale)
		self.frame.items[i].tex:SetWidth(32*self.db.profile.scale)
		self.frame.items[i].tex:SetHeight(32*self.db.profile.scale)
		self.frame.items[i].count:SetWidth(32*self.db.profile.scale)
		self.frame.items[i].count:SetHeight(32*self.db.profile.scale)
		
		--colors
		self.frame.items[i]:SetBackdropBorderColor(unpack(self.db.profile.itemBorderColor))
		self.frame.items[i].count:SetTextColor(unpack(self.db.profile.textColor))
		
		--adjust padding
		if i == 1 then
			self.frame.items[i]:SetPoint("TOPLEFT", parent, "TOPLEFT", 20, -60)
		else
			if (i % 7 > 1) or (i % 7 == 0) then
				self.frame.items[i]:SetPoint("TOP", self.frame.items[i-1], "BOTTOM", 0, -padding)
			elseif (i % 7 == 1) then
				self.frame.items[i]:SetPoint("LEFT", self.frame.items[i-7], "RIGHT", padding, 0)
			end
		end
	end
	--iterate the tab buttons
	for i = 1, 6 do
		--sizes
		self.frame.tabButtons[i]:SetWidth(40*self.db.profile.scale)
		self.frame.tabButtons[i]:SetHeight(40*self.db.profile.scale)
		self.frame.tabButtons[i].tab:SetWidth(32*self.db.profile.scale)
		self.frame.tabButtons[i].tab:SetHeight(32*self.db.profile.scale)
		
		--adjust padding between buttons
		if i == 1 then
			self.frame.tabButtons[i]:SetPoint("LEFT", self.frame, "RIGHT", 5, 120)
		else
			self.frame.tabButtons[i]:SetPoint("TOP", self.frame.tabButtons[i-1], "BOTTOM", 0, -padding)
		end
		--colors
		self.frame.tabButtons[i]:SetBackdropBorderColor(unpack(self.db.profile.tabBorderColor))
		self.frame.tabButtons[i]:SetBackdropColor(unpack(self.db.profile.frameColor))
		
		--make sure the selected tab's color is updated too
		if self.frame.tabButtons[i].clicked then
			self.frame.tabButtons[i]:SetBackdropBorderColor(unpack(self.db.profile.selectedColor))
		end
	end
end

--take the given guild and page and show that page's items in the frame
function MobileVault:Populate(guild, page)
	if not self.guilds[guild] then return end
	if page == 0 then
		page = next(self.guilds[guild].links)
		self.frame.subtext:SetText(self.guilds[self.activeGuild].tabs.names[page] or L["Tab"] .. " "..page)
		self.frame.tabButtons[page].clicked = true
		self.frame.tabButtons[page]:SetBackdropBorderColor(unpack(self.db.profile.selectedColor))
		self.activePage = page
	end
	
	local itemName, itemLink, itemTexture
	for i = 1, 98 do
		itemName, itemLink, _, _, _, _, _, _, _, itemTexture = GetItemInfo(self.guilds[guild].links[page][i])
		self.frame.items[i].tex:SetTexture(itemTexture)
		self.frame.items[i].tex:SetTexCoord(0, 1, 0, 1)
		if self.guilds[guild].links[page][i] ~= "empty" and self.guilds[guild].info[page][i] > 1 then
			self.frame.items[i].count:SetText(self.guilds[guild].info[page][i])
			self.frame.items[i].stacksize = self.guilds[guild].info[page][i]
		end
		self.frame.items[i].item = itemLink
	end
end

--clear the currently displayed items
function MobileVault:Unpopulate()
	for i = 1, 98 do
		self.frame.items[i].tex:SetTexture(nil)
		self.frame.items[i].count:SetText("")
		self.frame.items[i].item = nil
	end
end

function MobileVault:SetupTabs(guild)
	local numtabs = self.guilds[guild].numtabs
	for i = 1, numtabs do
		self.frame.tabButtons[i].tab:SetTexture(self.guilds[guild].tabs.textures[i])
		self.frame.tabButtons[i]:Show()
	end
end

function MobileVault:ObtainGuildName()
	if IsInGuild() then
		self.guildName = GetGuildInfo("player")
		self.activeGuild = self.guildName
	else
		self.guildName = next(self.guilds)
		self.activeGuild = self.guildName
	end
end

function MobileVault:GUILDBANKFRAME_OPENED()
	self.guilds[self.guildName].guildfunds = self:GetMoneyString()
	self.guilds[self.guildName].numtabs = GetNumGuildBankTabs()
	
	--save the tab information
	local name, icon, view
	for page = 1, self.guilds[self.guildName].numtabs do
		name, icon, view = GetGuildBankTabInfo(page)
		--because I like booleans better
		if view == 1 then
			view = true
		else
			view = false
		end
		
		self.guilds[self.guildName].tabs.textures[page] = icon
		self.guilds[self.guildName].tabs.names[page] = name
		self.guilds[self.guildName].tabs.views[page] = view
	end
end

function MobileVault:GUILDBANK_UPDATE_MONEY()
	self.guilds[self.guildName].guildfunds = self:GetMoneyString()
end

local num, itemString
function MobileVault:ScanPage()
	if (GuildBankFrame and GuildBankFrame:IsVisible()) or (BagnonFrameguildbank and BagnonFrameguildbank:IsVisible()) then
		local page = GetCurrentGuildBankTab()
		--98 slots on a page
		for slot = 1, 98 do
			--see if the slot has an item in it
			if GetGuildBankItemLink(page, slot) then
				--if there is link, parse the ID and place that in table w/ key = slot
				_, _, itemString = string.find(GetGuildBankItemLink(page, slot), "^|c%x+|H(.+)|h%[.+%]")
				self.guilds[self.guildName].links[page][slot] = itemString
				
				--get item info too, need for stack sizes in image
				_, num = GetGuildBankItemInfo(page, slot)
				self.guilds[self.guildName].info[page][slot] = num
			else
				--if there is no link, slot is empty... fill slot w/ empty string
				--needed to keep consistent tables with keys from 1 to 98
				self.guilds[self.guildName].links[page][slot] = "empty"
				self.guilds[self.guildName].info[page][slot] = "empty"
			end
			num, itemString = nil, nil
		end
		
		--save a timestamp
		self.guilds[self.guildName].lastScan = string.format("%s %s %s", date(L["date_format"]), L["at"], self:TimeStamp())
	end
end

function MobileVault:TimeStamp()
	local hour, minute = GetGameTime()
	if minute < 10 then
		minute = "0"..minute
	end
	
	if hour == 0 then
		return string.format(" %s:%s %s", "12", minute, L["AM"])
	elseif hour == 12 then
		return string.format(" %s:%s %s", hour, minute, L["PM"])
	elseif hour > 12 then
		return string.format(" %s:%s %s", (hour-12), minute, L["PM"])
	else
		return string.format(" %s:%s %s", hour, minute, L["AM"])
	end
end

local goldAbrv = L["g"]
local silverAbrv = L["s"]
local copperAbrv = L["c"]
function MobileVault:GetMoneyString()
	local copper = GetGuildBankMoney()
	local gold = (copper - (copper % 10000)) / 10000
	copper = copper % 10000
	local silver = (copper - (copper % 100)) / 100
	copper = copper % 100
	
	return string.format("%s|cff%s%s|r %s|cff%s%s|r %s|cff%s%s|r", gold, "ffd700", goldAbrv, silver, "c7c7cf", silverAbrv, copper, "eda55f", copperAbrv)
end

----------------------------------------------------------------------------------------------
--				TOOLTIP FUNCTIONS				     --
----------------------------------------------------------------------------------------------

local function GetCounts(frame, item, guild, tabs)
	local gBankCount = 0
	for page = 1, tabs do
		if MobileVault.guilds[guild].links[page] then
			for k, v in pairs(MobileVault.guilds[guild].links[page]) do
				if v == item then
					gBankCount = gBankCount + MobileVault.guilds[guild].info[page][k]
				end
			end
		end
	end
	
	if gBankCount and (gBankCount ~= '' or gBankCount ~= 0) then
		frame:AddDoubleLine("|cff"..MobileVault.db.profile.tooltipColor..guild, "|cff"..MobileVault.db.profile.tooltipColor..L["Vault:"].." "..gBankCount)
	end
end

local function AddItemCounts(frame, itemLink)
	local vaultID
	local _, _, itemString = strfind(itemLink, "^|c%x+|H(.+)|h%[.+%]")
	if itemString then
		local _, itemID = strsplit(":", itemString)
		for guild, data in pairs(MobileVault.guilds) do
			if MobileVault.guilds[guild].numtabs and MobileVault.db.profile.guildTooltips[guild] then
				local found = false
				for page = 1, MobileVault.guilds[guild].numtabs do
					for k, v in pairs(MobileVault.guilds[guild].links[page]) do
						_, vaultID = strsplit(":", v)
						if vaultID == itemID and (not found) then
							found = true
							GetCounts(frame, MobileVault.guilds[guild].links[page][k], guild, MobileVault.guilds[guild].numtabs)
							break
						end
					end
				end
			end
		end
	end
	
	frame:Show()
end

local function HookIt(tt)
	tt:HookScript("OnTooltipSetItem", function(self, ...)
		local itemLink = select(2, self:GetItem())
		if itemLink and GetItemInfo(itemLink) then
			AddItemCounts(self, itemLink)
		end
	end)
end

HookIt(GameTooltip)
HookIt(ItemRefTooltip)
