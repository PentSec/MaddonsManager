-- This file is script-generated and should not be manually edited. 
-- Localizers may copy this file to edit as necessary. 
local AceLocale = LibStub:GetLibrary("AceLocale-3.0") 
local L = AceLocale:NewLocale("MobileVault", "enUS", true) 
if not L then return end 

-- Core.lua
L["Toggle Frame"] = true
L["Click|r to toggle the Vault window"] = true
L["Right-click|r to open the options menu"] = true
L["Tab"] = true
L["date_format"] = "%B %d, %Y"
L["at"] = true
L["AM"] = true
L["PM"] = true
L["g"] = true
L["s"] = true
L["c"] = true
L["Vault:"] = true

-- Frames.lua
L["Guilds"] = true
L["Mobile Guild Vault"] = true

-- Options/Options.lua
L["Tooltip Options"] = true
L["Choose which guilds will display item counts on tooltips"] = true
L["Tooltip Text Color"] = true
L["Set the color for the tooltip text"] = true
L["Vault Options"] = true
L["Vault Frame Color"] = true
L["Set the color of the vault frame."] = true
L["Border Highlight Color"] = true
L["Set the color of the borders when highlighted."] = true
L["Item Border Color"] = true
L["Set the color of the item slot borders."] = true
L["Selected Tab Color"] = true
L["Set the color of the selected tab's border."] = true
L["Tab Border Color"] = true
L["Set the color of the tab button borders."] = true
L["Text Color"] = true
L["Set the color of all the vault text."] = true
L["Frame Alpha"] = true
L["Set the alpha of the vault frame."] = true
L["Item and Tab Alpha"] = true
L["Set the alpha of the item slots and the tab buttons."] = true
L["Frame Strata"] = true
L["Set the strata level of the frame."] = true
L["Item Slot Padding"] = true
L["Set the amount of space between the item slots."] = true
L["Tab Button Spacing"] = true
L["Set the amount of spacing between the tab buttons."] = true
L["Global Scale"] = true
L["Set the global scale."] = true

