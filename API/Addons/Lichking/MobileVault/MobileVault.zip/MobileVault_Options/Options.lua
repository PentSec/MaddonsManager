--[[
MobileVault_Options - LoD options module for MobileVault
Author: Michael Joseph Murray aka Lyte of Lothar(US)
Please see license.txt for details.
$Revision: 134 $
$Date: 2010-07-13 04:44:43 +0000 (Tue, 13 Jul 2010) $
Project Version: r134
contact: codemaster2010 AT gmail DOT com

Copyright (c) 2007-2010 Michael J. Murray aka Lyte of Lothar(US)
All rights reserved unless otherwise explicitly stated.
]]
local L = LibStub("AceLocale-3.0"):GetLocale("MobileVault")
local mgv = LibStub("AceAddon-3.0"):GetAddon("MobileVault")

--color functions for tooltips
local function HexToRGBPerc(hex)
	local rhex, ghex, bhex = string.sub(hex, 1, 2), string.sub(hex, 3, 4), string.sub(hex, 5, 6)
	return tonumber(rhex, 16)/255, tonumber(ghex, 16)/255, tonumber(bhex, 16)/255
end

local function RGBPercToHex(r, g, b)
	r = r <= 1 and r >= 0 and r or 0
	g = g <= 1 and g >= 0 and g or 0
	b = b <= 1 and b >= 0 and b or 0
	return string.format("%02x%02x%02x", r*255, g*255, b*255)
end

local guildlist = {}
local handler = {}

function handler:Set(info, ...)
	if info.type == "multiselect" then
		local value, flag = ...
		mgv.db.profile[info.arg][value] = flag
	elseif info.type == "color" then
		local color = mgv.db.profile[info.arg]
		color[1], color[2], color[3] = ...
	else
		mgv.db.profile[info.arg] = ...
	end
	self:UpdateFrame()
end

function handler:Get(info, ...)
	if info.type == "multiselect" then
		return mgv.db.profile[info.arg][...]
	elseif info.type == "color" then
		return unpack(mgv.db.profile[info.arg])
	else
		return mgv.db.profile[info.arg]
	end
end

function handler:UpdateFrame()
	--set the main frame properties
	mgv.frame:SetWidth(600*mgv.db.profile.scale)
	mgv.frame:SetHeight(375*mgv.db.profile.scale)
	mgv.frame.actionbutton:SetWidth(100*mgv.db.profile.scale)
	mgv.frame.actionbutton:SetHeight(22*mgv.db.profile.scale)
	mgv.frame.text:SetWidth(600*mgv.db.profile.scale)
	mgv.frame.text:SetHeight(20*mgv.db.profile.scale)
	mgv.frame.subtext:SetWidth(600*mgv.db.profile.scale)
	mgv.frame.subtext:SetHeight(20*mgv.db.profile.scale)
	mgv.frame.scan:SetHeight(20*mgv.db.profile.scale)
	mgv.frame.gold:SetHeight(20*mgv.db.profile.scale)
	mgv.frame:SetFrameStrata(mgv.db.profile.strata)
	mgv.frame:SetAlpha(mgv.db.profile.frameAlpha)
	
	--set the main frame colors
	mgv.frame:SetBackdropColor(unpack(mgv.db.profile.frameColor))
	mgv.frame.text:SetTextColor(unpack(mgv.db.profile.textColor))
	mgv.frame.subtext:SetTextColor(unpack(mgv.db.profile.textColor))
	mgv.frame.scan:SetTextColor(unpack(mgv.db.profile.textColor))
	mgv.frame.gold:SetTextColor(unpack(mgv.db.profile.textColor))
	
	--iterate the item slots
	for i = 1, 98 do
		--sizes
		mgv.frame.items[i]:SetWidth(40*mgv.db.profile.scale)
		mgv.frame.items[i]:SetHeight(40*mgv.db.profile.scale)
		mgv.frame.items[i].tex:SetWidth(32*mgv.db.profile.scale)
		mgv.frame.items[i].tex:SetHeight(32*mgv.db.profile.scale)
		mgv.frame.items[i].count:SetWidth(32*mgv.db.profile.scale)
		mgv.frame.items[i].count:SetHeight(32*mgv.db.profile.scale)
		
		--colors
		mgv.frame.items[i]:SetBackdropBorderColor(unpack(mgv.db.profile.itemBorderColor))
		mgv.frame.items[i].count:SetTextColor(unpack(mgv.db.profile.textColor))
		
		--adjust padding
		if i == 1 then
			mgv.frame.items[i]:SetPoint("TOPLEFT", mgv.frame, "TOPLEFT", 20, -60)
		else
			if (i % 7 > 1) or (i % 7 == 0) then
				mgv.frame.items[i]:SetPoint("TOP", mgv.frame.items[i-1], "BOTTOM", 0, -mgv.db.profile.itemPadding)
			elseif (i % 7 == 1) then
				mgv.frame.items[i]:SetPoint("LEFT", mgv.frame.items[i-7], "RIGHT", mgv.db.profile.itemPadding, 0)
			end
		end
	end
	--iterate the tab buttons
	for i = 1, 6 do
		--sizes
		mgv.frame.tabButtons[i]:SetWidth(40*mgv.db.profile.scale)
		mgv.frame.tabButtons[i]:SetHeight(40*mgv.db.profile.scale)
		mgv.frame.tabButtons[i].tab:SetWidth(32*mgv.db.profile.scale)
		mgv.frame.tabButtons[i].tab:SetHeight(32*mgv.db.profile.scale)
		
		--adjust padding between buttons
		if i == 1 then
			mgv.frame.tabButtons[i]:SetPoint("LEFT", mgv.frame, "RIGHT", 5, 120)
		else
			mgv.frame.tabButtons[i]:SetPoint("TOP", mgv.frame.tabButtons[i-1], "BOTTOM", 0, -mgv.db.profile.tabButtonSpacing)
		end
		--colors
		mgv.frame.tabButtons[i]:SetBackdropBorderColor(unpack(mgv.db.profile.tabBorderColor))
		mgv.frame.tabButtons[i]:SetBackdropColor(unpack(mgv.db.profile.frameColor))
		
		--make sure the selected tab's color is updated too
		if mgv.frame.tabButtons[i].clicked then
			mgv.frame.tabButtons[i]:SetBackdropBorderColor(unpack(mgv.db.profile.selectedColor))
		end
	end
end

local opts = {
	type = 'group',
	handler = handler,
	args = {
		tooltips = {
			type = 'group',
			name = L["Tooltip Options"],
			order = 2,
			args = {
				guilds = {
					type = 'multiselect',
					name = L["Guilds"],
					desc = L["Choose which guilds will display item counts on tooltips"],
					get = "Get",
					set = "Set",
					arg = "guildTooltips",
					values = function()
						wipe(guildlist)
						for k, v in pairs(mgv.guilds) do
							guildlist[k] = k
						end
						return guildlist
					end,
				},
				colors = {
					type = 'color',
					name = L["Tooltip Text Color"],
					desc = L["Set the color for the tooltip text"],
					get = function() return HexToRGBPerc(mgv.db.profile.tooltipColor) end,
					set = function(info, r, g, b) mgv.db.profile.tooltipColor = RGBPercToHex(r, g, b) end,
				},
			},
		},
		vault = {
			type = 'group',
			name = L["Vault Options"],
			order = 1,
			args = {
				frameColor = {
					type = 'color',
					name = L["Vault Frame Color"],
					desc = L["Set the color of the vault frame."],
					get = "Get",
					set = "Set",
					arg = "frameColor",
					order = 1,
				},
				highlightColor = {
					type = 'color',
					name = L["Border Highlight Color"],
					desc = L["Set the color of the borders when highlighted."],
					get = "Get",
					set = "Set",
					arg = "highlightColor",
					order = 2,
				},
				itemColor = {
					type = 'color',
					name = L["Item Border Color"],
					desc = L["Set the color of the item slot borders."],
					get = "Get",
					set = "Set",
					arg = "itemBorderColor",
					order = 5,
				},
				selectedColor = {
					type = 'color',
					name = L["Selected Tab Color"],
					desc = L["Set the color of the selected tab's border."],
					get = "Get",
					set = "Set",
					arg = "selectedColor",
					order = 3,
				},
				tabColor = {
					type = 'color',
					name = L["Tab Border Color"],
					desc = L["Set the color of the tab button borders."],
					get = "Get",
					set = "Set",
					arg = "tabBorderColor",
					order = 4,
				},
				textColor = {
					type = 'color',
					name = L["Text Color"],
					desc = L["Set the color of all the vault text."],
					get = "Get",
					set = "Set",
					arg = "textColor",
					order = 6,
				},
				frameAlpha = {
					type = 'range',
					name = L["Frame Alpha"],
					desc = L["Set the alpha of the vault frame."],
					get = "Get",
					set = "Set",
					min = 0,
					max = 1,
					step = 0.1,
					arg = "frameAlpha",
					order = 7,
				},
				strata = {
					type = 'select',
					name = L["Frame Strata"],
					desc = L["Set the strata level of the frame."],
					get = "Get",
					set = "Set",
					arg = "strata",
					values = {["FULLSCREEN"] = "Fullscreen", ["HIGH"] = "High", ["MEDIUM"] = "Medium", ["LOW"] = "Low", ["BACKGROUND"] = "Background",},
					order = 11,
				},
				itemPadding = {
					type = 'range',
					name = L["Item Slot Padding"],
					desc = L["Set the amount of space between the item slots."],
					get = "Get",
					set = "Set",
					min = 0,
					max = 7,
					step = 0.5,
					arg = "itemPadding",
					order = 10,
				},
				tabSpacing = {
					type = 'range',
					name = L["Tab Button Spacing"],
					desc = L["Set the amount of spacing between the tab buttons."],
					get = "Get",
					set = "Set",
					min = 0,
					max = 14,
					step = 1,
					arg = "tabButtonSpacing",
					order = 9,
				},
				scale = {
					type = 'range',
					name = L["Global Scale"],
					desc = L["Set the global scale."],
					get = "Get",
					set = "Set",
					min = 0.8,
					max = 1.5,
					step = 0.01,
					arg = "scale",
					order = 8,
				},
			},
		},
	},
}

--add profile controls
opts.args.profile = LibStub("AceDBOptions-3.0"):GetOptionsTable(mgv.db)

LibStub("AceConfig-3.0"):RegisterOptionsTable("MobileVault", opts)
LibStub("AceConfigDialog-3.0"):SetDefaultSize("MobileVault", 650, 400)
