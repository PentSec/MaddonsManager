﻿-- Author      : Bandayd of Uther
-- Create Date : 5/22/2008 6:24:22 PM

	FearWardSpellName = "Fear Ward"
	ShackleUndeadSpellName = "Shackle Undead"
	DivineSpiritSpellName = "Divine Spirit"
	VampiricEmbraceSpellName = "Vampiric Embrace"
	PrayerOfSpiritSpellName = "Prayer of Spirit"
	PowerWordFortitudeSpellName = "Power Word: Fortitude"
	PrayerofFortitudeSpellName = "Prayer of Fortitude"
	ShadowProtectionSpellName = "Shadow Protection"
	PrayerOfShadowProtectionSpellName = "Prayer of Shadow Protection"
	InnerFireSpellName = "Inner Fire"
	SpiritOfRedemptionSpellName = "Spirit of Redemption"
	PhaseShiftSpellName = "Phase Shift"
	ResurrectionSpellName = "Resurrection"
	RebirthSpellName = "Rebirth"
	RedemptionSpellName = "Redemption"
	AncestralSpiritSpellName = "Ancestral Spirit"
	ReviveSpellName = "Revive"
	MindControlSpellName = "Mind Control"
	PowerInfusionSpellName = "Power Infusion"
	RenewedHopeSpellName = "Renewed Hope"
	PowerWordShieldSpellName = "Power Word: Shield"

	--This loads the default values, just in case this is their first time loading the addon :-)
	PriestFriendVars = {
		FearWardReadySoundDisplay = "Coocoo",
		FearWardFadedSoundDisplay = "Yell",
		FearWardCastSoundDisplay = "Woohoo!!!",
		InnerFireSoundDisplay = "Coocoo",
		FortitudeSoundDisplay = "Coocoo",
		ShadowProtectionSoundDisplay = "Coocoo",
		DivineSpiritSoundDisplay = "Coocoo",
		VampiricEmbraceSoundDisplay = "Coocoo",
		PISoundDisplay = "Coocoo",
		RHSoundDisplay = "Coocoo",
		DiseaseSoundDisplay = "Coocoo",
		MagicSoundDisplay = "Coocoo",
		ShackleBreakSoundDisplay = "Bring Dead",
		OtherShackleBreakSoundDisplay = "Problem",
		FWReadyText = 1,
		FWFadedText = 1,
		FWCastText = 1,
		InnerFireText = 1,
		FortitudeText = 1,
		ShadowProtectionText = 1,
		DivineSpiritText = 1,
		VampiricEmbraceText = 1,
		PIText = 1,
		RHText = 1,
		DiseaseText = 1,
		MagicText = 1,
		ShackleBreakText = 1,
		OtherShackleBreakText = 1,
		InnerFireNag = 1,
		FortitudeNag = 1,
		ShadowProtectionNag = 1,
		DivineSpiritNag = 1,
		VampiricEmbraceNag = 1,
		PINag = 1,
		RHNag = 1,
		DevoutCandleText = 60,
		SacredCandleText = 0,
		HolyCandleText = 0,
		NagIntervalText = 60,
		MountSayText = 1,
		RezSayText = 1,
		RezWhisperText = 1,
		RezPartyText = 1,
		MCSayText = 1,
		ShackleSayText = 1,
		AlreadyStoredVars = nil,
		MountPartyText = 1,
		MCPartyText = 1,
		ShacklePartyText = 1,
		NagDuringCombat = nil,
		DisableNag = nil,
		OnlyNagInInstances = 1,
		IgnorePets = 1
	}

    ShackleMessage = {  --1 to 14
    "THE POWER OF "..string.upper(UnitName("player")).." COMPELS YOU!!",
	"Shackling <target>!  Stay away from it!",
	"I hope you brought the gag, <target>; I brought the handcuffs!",
	"Believe it or not, <target>, I'm into bondage.",
	"Shackling <target>! Drop what you're doing and leave it alone! ",
	"Shackling <target>. Everytime you break it, I'll kill a kitten.",
	"Shackling <target>!  You break it, you tank it.",
	"<target> is my undead. There are many others like it but this one is mine.",
	"Shackling <target> because the dead can't say no.",
	"Go to your cage, <target>!",
	"All I ever hear from you is 'mind this' and 'mind that', <target>.  No more!",
	"You fought the law and the law won, <target>.",
	"<target>, go to jail.  Go directly to jail.  Do not pass go.  Do not collect 200g",
	"You were never meant to move, <target>. Be still once more!",
    };
    MindControlMessage = {  --1 to 3
        "I'm feeling alone ! <target>, be mine !!",
        "Come here <target>. Now!",
        "The problem with doing this <target>, is your friends no longer like you!",
    };
    ResurrectionNoTarget = {  --1 to 27
	"Okay, nap time is over! Back to work!",
	"Cool, I received 42 silver, 32 copper from this corpse",
	"Okay, Stop being dead.",
	"Don't rush me. You rush a miracle worker, you get rotten miracles.",
	"Administering Resurrecting. Side effects may include: nausea, explosive bowels, a craving for brains, and erectile dysfunction. Resurrection is not for everyone. Please consult healer before dying.",
	"Dammit I'm a doctor! Not a priest! .... Wait a second.... Nevermind. Rezzing",
	"Dying makes me sad.",
	"Stop worshipping the ground I walk on and get up." ,
	"Walk it off.",
	"By accepting this resurrection you hereby accept that you must forfeit your immortal soul to <player>. Please click 'Accept' to continue.",
	"This better not be another attempt to get me to give you mouth-to-mouth.",
	"Arise, and fear death no more...or at least until the next pull.",
	"Stop slacking, You can sleep when you're dea... Oh... Um, rezzing",
	"Quit hitting on the Spirit Healer and come kill something!",
	"I *warned* you, but did you listen to me? Oh, no, you *knew*, didn't you? Oh, it's just a harmless little *bunny*, isn't it?",
	"Please! This is supposed to be a happy occasion. Let's not bicker and argue over who killed who.",
	"There are worse things then death. Have you ever grouped with... oh, wait. We aren't supposed to mention that in front of you.",
	"Did you run into some snakes on a plane or something? 'cause you're dead.",
	"Wee-ooo! Wee-ooo! Wee-ooo! Wee-ooo! Wee-ooo! Wee-ooo... that's the best ambulance impression I can do.",
	"Tsk tsk, See, I told you to sacrifice that virgin to the Volcano God.",
	"Hey, do you know what you call a physician that was last in his class?  Doctor.",
	"You don't deserve a cute rez macro, You deserve to die. But you already did, so, um... yeah.",
	"You have been weighed, you have been measured, and you have been found wanting.",
	"Gah, dead again? You probably want a rez, don't you? What do you think I am, a prie... oh. Fair enough.",
	"Sorry, I know I'm a priest ... but come ON! Did you see how many guys there were!?",
	"Hey! Don't go towards the light! Well, unless it says 'Accept' ... but even then, it might be a trick!",
	"Sorry, I couldn't heal you. I was too busy being the tank.",
    };
    Resurrection = {  --1 to 55
    "Granddaddy always said laughter was the best medicine. I guess it wasn't strong enough to keep <target> alive.",
	"Okay, <target>, nap time is over! Back to work!",
	"Rezzing <target>. Can I get an 'amen', please!",
	"<target>, your subscription to Life(tm) has expired. Do you wish to renew?",
	"YAY! I always wanted my very own <target>-zombie!",
	"It just so happens that <target> is only MOSTLY dead. There's a big difference between mostly dead and all dead. Mostly dead is slightly alive.",
	"<target> has failed at life, I'm giving him a second chance. That's right, not the Spirit Healer, ME!!",
	"Cool, I received 42 silver, 32 copper from <target>'s corpse",
	"GAME OVER, <target>. To continue press up, up, down, down, left, right, left, right, B, A, B, A, Select + Start",
	"<target>, it's more mana efficient just to resurrect you.  Haha, I'm just kidding!",
	"Well, <target>, if you had higher reputation with the faction <player>, you might have gotten a heal.  How do you raise it?  10g donation = 15 rep.",
	"Okay, <target>.  Stop being dead.",
	"If you are reading this message, <target> is already dead.",
	"Don't rush me <target>. You rush a miracle worker, you get rotten miracles.",
	"Death comes for you <target>! with large, pointy teeth!",
	"Resurrecting <target>. Side effects may include: nausea, explosive bowels, a craving for brains, and erectile dysfunction. Resurrection is not for everyone. Please consult healer before dying.",
	"Dammit <target>, I'm a doctor! Not a priest! .... Wait a second.... Nevermind. Rezzing <target>",
	"Dying makes me sad, <target>.",
	"<target> stop worshipping the ground I walk on and get up." ,
	"Hey <target>, will you check to see if Elvis is really dead?...and will he fill your spot in the party?",
	"Giving <target> another chance to mess it up. ",
	"Dammit, <target>, did you get my PERMISSION before dying?!",
	"Death defying feats are clearly not your strong point, <target>",
	"Walk it off, <target>.",
	"<target>, by accepting this resurrection you hereby accept that you must forfeit your immortal soul to <player>. Please click 'Accept' to continue.",
	"<target>, this better not be another attempt to get me to give you mouth-to-mouth.",
	"Arise <target>, and fear death no more...or at least until the next pull.",
	"Stop slacking, <target>. You can sleep when you're dea... Oh... Um, rezzing <target>",
	"We can rebuild <target>. We can make <himher> stronger, faster, but we can't make <himher> any smarter.",
	"<target> has fallen and can't get up!",
	"Bring out your dead! *throws <target> on the cart*",
	"Hey <target>, say hello to Feathers for me, will ya?",
	"<target>, quit hitting on the Spirit Healer and come kill something!",
	"<target> I *warned* you, but did you listen to me? Oh, no, you *knew*, didn't you? Oh, it's just a harmless little *bunny*, isn't it?",
	"<target>, please! This is supposed to be a happy occasion. Let's not bicker and argue over who killed who.",
	"Today's category on Final Jeopardy: Spells that end in 'esurrection'. <target>, ready?",
	"There are worse things then death, <target>. Have you ever grouped with... oh, wait. We aren't supposed to mention that in front of you.",
	"Did you run into some snakes on a plane or something, <target>? 'cause you're dead.",
	"Wee-ooo! Wee-ooo! Wee-ooo! Wee-ooo! Wee-ooo! Wee-ooo... that's the best ambulance impression I can do, <target>.",
	"Tsk tsk, <target>. See, I told you to sacrifice that virgin to the Volcano God.",
	"<target> gets a Mulligan.",
	"Hey <target>, do you know what you call a physician that was last in his class?  Doctor.",
	"Eww!  What's that smell!  It smells like something died in here!  Hey, where is <target>?... Oh.",
	"Sorry to hear that you're dead, <target>, but hey, the good news is that I just saved a bunch of money on my car insurance by switching to Geico.",  
	"You don't deserve a cute rez macro, <target>. You deserve to die. But you already did, so, um... yeah.",
	"<target>, you have been weighed, you have been measured, and you have been found wanting.",
	"Well <target>, you tried your best...and apparently failed miserably. Good job.", 
	"Did it hurt, <target>, when you fell from Heaven? Oh, wait...You're dead...hmmm...I don't know where I was going with that. Nevermind.", 
	"Gah, <target>, dead again? You probably want a rez, don't you? What do you think I am, a prie... oh. Fair enough.",
	"<target> have you heard of Nethaera?  Yeah, she's really cool.  Why do I bring it up?  No reason.",
	"Can somebody get <target> a Phoenix Down over here? *stumbles* Wow, out of body experience...",
	"Funny how everyone else can die and come back, but a Phoenix Down won't take care of <target>.",
	"Sorry <target>, I know I'm a priest ... but come ON! Did you see how many guys there were!?",
	"Hey <target>! Don't go towards the light! Well, unless it says 'Accept' ... but even then, it might be a trick!",
	"Sorry <target>, I couldn't heal you. I was too busy being the tank.",
    };
    MountMessage = {  --1 to 16
    "If it wasn't for my <mount>, I wouldn't have spent that year in college.",
	"The directions said to just add water and... WHOA a <mount>!",
	"If it wasn't for my <mount>, I'd be walking.",
	"I'd love to hang around, but my <mount> needs exercise.",
	"Alright <mount>, I'm ready to ride!",
	"Fasten your seat belts, it's going to be a bouncy ride.",
	"Hi-ho <mount>...Away!!!",
	"You should see my other mount... but it's in the shop getting fixed.",
	"Shotgun!",
	"Hm, something's growing under my butt!",
	"Ah, now for some good old fashioned <mount> riding.",
	"Does this look like a <mount> to you? Oh, I guess it really is. Nevermind.",
	"Ok, mounting my <mount> now. Wait... that didn't come out right.",
	"*cough cough* Man, I wish my <mount> didn't smoke.",
	"Pardon the smoke, folks! My <mount> adores flashy appearances...",
	"On the road again ... *whistles* ... let's go, <mount>!",
	};
	FearWardCooldown = 181;
	CurrentCountdown = 1.0;
	UpdateInterval = 1.0; -- How often the OnUpdate code will run (in seconds)
	FWTimeSinceLastUpdate = 0.0;
	NagTimeSinceLastUpdate = 0.0;
	FWTimerEnabled = false;
	elapsed = 0.0;
	SoundPath = "Interface\\AddOns\\PriestFriend\\Sounds\\";
	SettingWhat = "FWReady";
	myShackleID = 0;
	LastShackleID = 0;
	TempMessage = "";
	LastMouseoverName = "";
	AmIMounted = true;
	--MountList = {   --1 to 32
		--"saber",--1
		--"Tiger",--2
		--"Elekk",--3
		--"Steed",--4
		--"Mechanostrider",--5
		--"Ram",--6
		--"Raptor",--7
		--"orse",--8
		--"Wolf",--9
		--"Hawkstrider",--10
		--"Kodo",--11
		--"Swift",--12
		--"Pinto",--13
		--"Brown Horse",--14
		--"Black Stallion",--15
		--"Chestnut Mare",--16
		--"harger",--17
		--"Talbuk",--18
		--"Windrider",--19
		--"Gryphon",--20
		--"Nether Ray",--21
		--"Drake",--22
		--"Hippogryph",--23
		--"Flying Machine",--24
		--"Phoenix",--25
		--"Nether-Rocket",--26
		--"Howler",--27
		--"Battlestrider",--28
		--"Raven Lord",--29
		--"Battle Tank",--30
		--"Riding Turtle",--31
		--"War Bear",--32
	--};
    --ResurrectionWhisper = {  --1 to 8
		--"Hey, you're legs look \"dead tired\" why don't you just sit there and I'll rez ya :-P",
		--"Hey seeing as I failed to heal you I might as well throw you a rez :-P",
		--"So, I know you're probably havin' fun lying there dead, wanna join the living??? :-P",
		--"So, how much gold will ya pay for a rez right now :-P",
		--"Ok here's the deal, I'm gonna rez ya but try and not die this time ok? :-P",
		--"So, how's you're durability doin these days? Goin down is it? hmmmmm, that's wierd :-P",
		--"<Insert smart-alec Resurrection message here>",
		--"I'm rezzing you now since you're my favorite... just don't tell tell anyone... :-P",
    --};
	
function Timer_OnLoad()
	--this:RegisterEvent("CHAT_MSG_SAY");
	--this:RegisterEvent("CHAT_MSG_WHISPER");
	--HideConfig();
	this:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	this:RegisterEvent("VARIABLES_LOADED");
	this:RegisterEvent("UNIT_SPELLCAST_SENT");
	this:RegisterEvent("MERCHANT_SHOW");
	this:RegisterEvent("MERCHANT_CLOSED");
	this:RegisterEvent("PLAYER_LEAVE_COMBAT");
	this:RegisterEvent("COMPANION_UPDATE");
	this:RegisterEvent("UPDATE_MOUSEOVER_UNIT");

	--this:RegisterEvent("PLAYER_TARGET_CHANGED");
	--this:RegisterEvent('UNIT_SPELLCAST_SUCCEEDED');

	--this:RegisterEvent('PLAYER_ENTERING_WORLD');
	---- new zone
	--this:RegisterEvent('ZONE_CHANGED_NEW_AREA');
	--
	---- monitor some status infos
	--this:RegisterEvent('UNIT_HEALTH');
	--this:RegisterEvent('UNIT_MANA');
	--this:RegisterEvent('UNIT_FOCUS');
	--r
	---- some basic info has changed
	----this:RegisterEvent('PLAYER_PET_CHANGED');
	--this:RegisterEvent('SPELLS_CHANGED');
	--this:RegisterEvent('BAG_UPDATE');
	--this:RegisterEvent('UNIT_INVENTORY_CHANGED');
	--
	---- capture spellcasts (messages, recasts)
	--this:RegisterEvent('UNIT_SPELLCAST_FAILED'); 
	--this:RegisterEvent('UNIT_SPELLCAST_INTERRUPTED'); 
	--this:RegisterEvent('UNIT_SPELLCAST_STOP');
	--this:RegisterEvent('UNIT_SPELLCAST_SUCCEEDED');     
	--
	SLASH_CMD1 = "/pf";
	SLASH_CMD2 = "/priestfriend";
	SLASH_CMD3 = "/fw";
	SLASH_CMD4 = "/fearwatch";
	SlashCmdList["CMD"] = CMD_Command;
end

function CMD_Command(cmd)
	if (cmd == "hide") then
	    HideConfig();
	elseif (cmd == "show") then
		ShowConfig();
	else
		ShowConfig();
		DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76Usage:|r /pf {show | hide}", 1.0, 1.0, 1.0, nil, false);
		DEFAULT_CHAT_FRAME:AddMessage(" - |cfff0ef76Show:|r Shows the configuration page", 1.0, 1.0, 1.0, nil, false);
		DEFAULT_CHAT_FRAME:AddMessage(" - |cfff0ef76Hide:|r Hides the configuration page", 1.0, 1.0, 1.0, nil, false);
	end
end

--function MyUnhandledEvent(timestamp, event, srcGUID, srcName, srcFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, auraType)
	----DEFAULT_CHAT_FRAME:AddMessage(.." : "..srcName.." just cast "..spellName.." on "..destName, 0.0, 1.0, 1.0, nil, false);
	--if (timestamp ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("timestamp"..timestamp, 1.0, 1.0, 0.0, nil, false);
	--end
	--if (event ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("event"..event, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (srcGUID ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("srcGUID"..srcGUID, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (srcName ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("srcName"..srcName, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (srcFlags ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("srcFlags"..srcFlags, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (destGUID ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("destGUID"..destGUID, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (destName ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("destName"..destName, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (destFlags ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("destFlags"..destFlags, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (spellId ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("spellId"..spellId, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (spellName ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("spellName"..spellName, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (spellSchool ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("spellSchool"..spellSchool, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (auraType ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("auraType"..auraType, 0.0, 1.0, 1.0, nil, false);
	--end
--end

function Timer_OnEvent()
	if (event == "VARIABLES_LOADED") then
		MyVariablesLoadedEvent()
	elseif (event == "COMBAT_LOG_EVENT_UNFILTERED") then
		if (arg2 == "SPELL_AURA_APPLIED") then
			MyAuraAppliedEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12);
		elseif (arg2 == "SPELL_AURA_REMOVED") then
			MyAuraRemovedEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12);
		elseif (arg2 == "SPELL_CAST_SUCCESS") then
			MySpellCastSuccessEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11);
		elseif (arg2 == "SPELL_CAST_START") then
			MySpellCastStartEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11);
		elseif (arg2 == "SPELL_CAST_FAILED") then
			MySpellCastFailedEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11);
		else
			----THIS IS FOR TROUBLESHOOTING PURPOSES
			--MyUnhandledEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12);
			----THIS IS FOR TROUBLESHOOTING PURPOSES
		end
	elseif (event == "UNIT_SPELLCAST_SENT") then
		MyRezEvent(arg1, arg2, arg3, arg4);
	elseif (event == "MERCHANT_SHOW") then
		MyVendorOpenEvent();
	elseif (event == "MERCHANT_CLOSED") then
		MyVendorCloseEvent();
	elseif (event == "PLAYER_LEAVE_COMBAT") then
		MyLeftCombatEvent();
	elseif (event == "COMPANION_UPDATE") then
		MyMountEvent(arg1);
	elseif (event == "UPDATE_MOUSEOVER_UNIT") then
		if (UnitExists("mouseover")) then
			LastMouseoverName = UnitName("mouseover");
			--DEFAULT_CHAT_FRAME:AddMessage(UnitName("mouseover"), 1.0, 0.0, 1.0, nil, false);
		end
	--else
		--THIS IS FOR TROUBLESHOOTING PURPOSES
		--MyUnhandledEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12);
		--THIS IS FOR TROUBLESHOOTING PURPOSES
	end
end

function GetMount()
	local ReturnValue
	local NumMounts
	local creatureID, creatureName, creatureSpellID, icon, issummoned
	--DEFAULT_CHAT_FRAME:AddMessage("poop on a stick", 1.0, 1.0, 1.0, nil, false);
	ReturnValue = "";
	NumMounts = GetNumCompanions("MOUNT");
	for j=1,NumMounts do
		creatureID, creatureName, creatureSpellID, icon, issummoned = GetCompanionInfo("MOUNT", j)
		if (issummoned) then
			ReturnValue = creatureName;
			--DEFAULT_CHAT_FRAME:AddMessage("Mounted Test:"..creatureName, 1.0, 1.0, 1.0, nil, false);
		end
	end
	return ReturnValue;
end

function MyMountEvent(Type)
	--DEFAULT_CHAT_FRAME:AddMessage("Mounted Test", 1.0, 1.0, 1.0, nil, false);
	local MountName, IsMounted
	MountName = "";
	if (Type == "MOUNT") then
		MountName = GetMount();
		if (MountName ~= "") then
			isMounted = true;
		else
			isMounted = false;
		end
	end
	if (isMounted) then
		if (AmIMounted ~= isMounted) then
			--DEFAULT_CHAT_FRAME:AddMessage("Mounted", 1.0, 1.0, 1.0, nil, false);
			--math.randomseed(math.random(0,2147483647)+(GetTime()*1000));
			TempMessage = InsertTagValues(MountMessage[math.random(1,16)],"","",MountName)
			if (PriestFriendVars.MountPartyText) then
				if (GetNumRaidMembers() > 0) then  --iterate through your raid members
					SendChatMessage(TempMessage, "RAID", GetDefaultLanguage("player"));
				elseif (GetNumPartyMembers() > 0) then  --iterate through your party members
					SendChatMessage(TempMessage, "PARTY", GetDefaultLanguage("player"));
				end
			end
			if (PriestFriendVars.MountSayText) then
				SendChatMessage(TempMessage, "SAY");
			end
		end
	else
		--DEFAULT_CHAT_FRAME:AddMessage("UnMounted", 1.0, 1.0, 1.0, nil, false);
	end
	AmIMounted = isMounted;
end

function MyLeftCombatEvent()
	----check to see if we have dead people
	--if (GetNumRaidMembers() > 0) then
		----go through and check for dead people to rez
		--for i=1,40 do
			--if (UnitIsDeadOrGhost("raid"..i)) then
				--DEFAULT_CHAT_FRAME:AddMessage("Just FYI "..UnitName("raid"..i).." is dead", 1.0, 1.0, 1.0, nil, false);
				--i=40;
			--end
		--end
	--elseif (GetNumPartyMembers() > 0) then
		----go through and check for dead people to rez
		--for i=1,4 do
			--if (UnitIsDeadOrGhost("party"..i)) then
				--DEFAULT_CHAT_FRAME:AddMessage("Just FYI "..UnitName("party"..i).." is dead", 1.0, 1.0, 1.0, nil, false);
				--i=40;
			--end
		--end
	--end
end

function MyVendorOpenEvent()
	local MerchItems = GetMerchantNumItems()
	local Purchase = false;
	local color;
 	local display = false;
	for item= 1, MerchItems do
		local itemString = GetMerchantItemInfo(item)
		if (itemString == "Devout Candle") then
			if (PriestFriendVars.DevoutCandleText > 0) then
				--check bags to see if we have enough
				local numCandles = 0;
				--now see if we have something in our bag which contains this spell's name
				--if so then that's our mount :-)
				--For each bag
				local tempItemLink
				for container=0,4 do
					-- For each slot
					for slot=1,GetContainerNumSlots(container) do
						tempItemLink = GetContainerItemLink(container, slot);
						if (tempItemLink) then
							local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(tempItemLink);
							local texture, itemCount, locked, quality, readable = GetContainerItemInfo(container, slot);
							if (itemName) then
								if (itemName == "Devout Candle") then
									numCandles = numCandles + itemCount;
								end
							end
						end
					end
				end
				DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..numCandles.." Devout Candles in inventory|r", 1.0, 1.0, 1.0, nil, false);
				if (numCandles < PriestFriendVars.DevoutCandleText) then
					StaticPopupDialogs["RESTOCK_DEVOUT_CONFIRMATION"] = {
						text = "Restock Devout Candles?",
						button1 = "Yes",
						button2 = "No",
						OnAccept = function()
							local TempNumNeeded
							TempNumNeeded = PriestFriendVars.DevoutCandleText-numCandles;
							while (numCandles < PriestFriendVars.DevoutCandleText) do
								if ((PriestFriendVars.DevoutCandleText-numCandles) > 20) then
									BuyMerchantItem(item, 20);
									numCandles = numCandles + 20;
								else
									BuyMerchantItem(item, PriestFriendVars.DevoutCandleText-numCandles);
									numCandles = numCandles + (PriestFriendVars.DevoutCandleText-numCandles);
								end
							end
							DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..(TempNumNeeded).." Devout Candles purchased|r", 1.0, 1.0, 1.0, nil, false);
						end,
						OnShow = function()
							DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..(PriestFriendVars.DevoutCandleText-numCandles).." Devout Candles needed|r", 1.0, 1.0, 1.0, nil, false);
						end,
						timeout = 0,
						whileDead = 1,
						hideOnEscape = 1
					};
					StaticPopup_Show("RESTOCK_DEVOUT_CONFIRMATION");
				end
			end
		elseif (itemString == "Sacred Candle") then
			if (PriestFriendVars.SacredCandleText > 0) then
				--check bags to see if we have enough
				local numCandles = 0;
				--now see if we have something in our bag which contains this spell's name
				--if so then that's our mount :-)
				--For each bag
				local tempItemLink
				for container=0,4 do
					-- For each slot
					for slot=1,GetContainerNumSlots(container) do
						tempItemLink = GetContainerItemLink(container, slot);
						if (tempItemLink) then
							local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(tempItemLink);
							local texture, itemCount, locked, quality, readable = GetContainerItemInfo(container, slot);
							if (itemName) then
								if (itemName == "Sacred Candle") then
									numCandles = numCandles + itemCount;
								end
							end
						end
					end
				end
				DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..numCandles.." Sacred Candles in inventory|r", 1.0, 1.0, 1.0, nil, false);
				if (numCandles < PriestFriendVars.SacredCandleText) then
					StaticPopupDialogs["RESTOCK_SACRED_CONFIRMATION"] = {
						text = "Restock Sacred Candles?",
						button1 = "Yes",
						button2 = "No",
						OnAccept = function()
							local TempNumNeeded
							TempNumNeeded = PriestFriendVars.SacredCandleText-numCandles;
							while (numCandles < PriestFriendVars.SacredCandleText) do
								if ((PriestFriendVars.SacredCandleText-numCandles) > 20) then
									BuyMerchantItem(item, 20);
									numCandles = numCandles + 20;
								else
									BuyMerchantItem(item, PriestFriendVars.SacredCandleText-numCandles);
									numCandles = numCandles + (PriestFriendVars.SacredCandleText-numCandles);
								end
							end
							DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..(TempNumNeeded).." Sacred Candles purchased|r", 1.0, 1.0, 1.0, nil, false);
						end,
						OnShow = function()
							DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..(PriestFriendVars.SacredCandleText-numCandles).." Sacred Candles needed|r", 1.0, 1.0, 1.0, nil, false);
						end,
						timeout = 0,
						whileDead = 1,
						hideOnEscape = 1
					};
					StaticPopup_Show("RESTOCK_SACRED_CONFIRMATION");
				end
			end
		elseif (itemString == "Holy Candle") then
			if (PriestFriendVars.HolyCandleText > 0) then
				--check bags to see if we have enough
				local numCandles = 0;
				--now see if we have something in our bag which contains this spell's name
				--if so then that's our mount :-)
				--For each bag
				local tempItemLink
				for container=0,4 do
					-- For each slot
					for slot=1,GetContainerNumSlots(container) do
						tempItemLink = GetContainerItemLink(container, slot);
						if (tempItemLink) then
							local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(tempItemLink);
							local texture, itemCount, locked, quality, readable = GetContainerItemInfo(container, slot);
							if (itemName) then
								if (itemName == "Holy Candle") then
									numCandles = numCandles + itemCount;
								end
							end
						end
					end
				end
				DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..numCandles.." Holy Candles in inventory|r", 1.0, 1.0, 1.0, nil, false);
				if (numCandles < PriestFriendVars.HolyCandleText) then
					StaticPopupDialogs["RESTOCK_HOLY_CONFIRMATION"] = {
						text = "Restock Holy Candles?",
						button1 = "Yes",
						button2 = "No",
						OnAccept = function()
							local TempNumNeeded
							TempNumNeeded = PriestFriendVars.HolyCandleText-numCandles;
							while (numCandles < PriestFriendVars.HolyCandleText) do
								if ((PriestFriendVars.HolyCandleText-numCandles) > 20) then
									BuyMerchantItem(item, 20);
									numCandles = numCandles + 20;
								else
									BuyMerchantItem(item, PriestFriendVars.HolyCandleText-numCandles);
									numCandles = numCandles + (PriestFriendVars.HolyCandleText-numCandles);
								end
							end
							DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..(TempNumNeeded).." Holy Candles purchased|r", 1.0, 1.0, 1.0, nil, false);
						end,
						OnShow = function()
							DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..(PriestFriendVars.HolyCandleText-numCandles).." Holy Candles needed|r", 1.0, 1.0, 1.0, nil, false);
						end,
						timeout = 0,
						whileDead = 1,
						hideOnEscape = 1
					};
					StaticPopup_Show("RESTOCK_HOLY_CONFIRMATION");				
				end
			end
		end
	end
end

function MyVendorCloseEvent()
	StaticPopup_Hide("RESTOCK_DEVOUT_CONFIRMATION");
	StaticPopup_Hide("RESTOCK_SACRED_CONFIRMATION");
	StaticPopup_Hide("RESTOCK_HOLY_CONFIRMATION");
end

function InsertTagValues(myMessage,myTarget,isFemale,myMount)
	--<target>
	--<mount>
	--string.find(spellName, itemName)
	while (string.find(myMessage,"<player>")) do
		myMessage = string.gsub(myMessage,"<player>",UnitName("player"));
	end
	while (string.find(myMessage,"<mount>")) do
		myMessage = string.gsub(myMessage,"<mount>",myMount);
	end
	while (string.find(myMessage,"<target>")) do
		myMessage = string.gsub(myMessage,"<target>",myTarget);
	end
	while (string.find(myMessage,"<himher>")) do
		if (isFemale) then
			myMessage = string.gsub(myMessage,"<himher>","her");
		else
			myMessage = string.gsub(myMessage,"<himher>","him");
		end
	end
	return myMessage;
end

function MyRezEvent(unitName, spellName, spellRank, spellTarget)
	if (unitName == "player") then
		--elseif ((spellName == ResurrectionSpellName) and (srcName == UnitName("player"))) then
		if ((spellName == ResurrectionSpellName) or (spellName == RebirthSpellName) or (spellName == RedemptionSpellName) or (spellName == AncestralSpiritSpellName) or (spellName == ReviveSpellName)) then
			--display resurrection message
			--math.randomseed(math.random(0,2147483647)+(GetTime()*1000));
			if (spellTarget == "Unknown") then --use the mouseover if we can
				if (UnitExists(LastMouseoverName)) then
					if (UnitIsDeadOrGhost(LastMouseoverName)) then
					--DEFAULT_CHAT_FRAME:AddMessage(UnitName("mouseover"), 1.0, 0.0, 1.0, nil, false);
						--whipser the person you are rezzing
						if (PriestFriendVars.RezSayText) then
							SendChatMessage(InsertTagValues(Resurrection[math.random(1,55)], LastMouseoverName, (UnitSex(LastMouseoverName) == 3),""), "SAY");
						end
						if (PriestFriendVars.RezWhisperText) then
							--SendChatMessage(InsertTagValues(ResurrectionWhisper[math.random(1,8)], LastMouseoverName, (UnitSex(LastMouseoverName) == 3),""), "WHISPER", GetDefaultLanguage("player"), UnitName(LastMouseoverName));
							SendChatMessage("Just FYI I'm rezzing you now", "WHISPER", GetDefaultLanguage("player"), LastMouseoverName);
						end
						if (PriestFriendVars.RezPartyText) then
							if (GetNumRaidMembers() > 0) then  --iterate through your raid members
								SendChatMessage("Now casting "..spellName.." on "..LastMouseoverName, "RAID", GetDefaultLanguage("player"));
							elseif (GetNumPartyMembers() > 0) then  --iterate through your party members
								SendChatMessage("Now casting "..spellName.." on "..LastMouseoverName, "PARTY", GetDefaultLanguage("player"));
							end
						end
					end
				else
					DEFAULT_CHAT_FRAME:AddMessage("No target found :-(", 1.0, 0.0, 1.0, nil, false);
					SendChatMessage(InsertTagValues(ResurrectionNoTarget[math.random(1,27)],"<unknown>","",""), "SAY");
				end
			else
				--whipser the person you are rezzing
				if (PriestFriendVars.RezSayText) then
					SendChatMessage(InsertTagValues(Resurrection[math.random(1,55)], spellTarget, (UnitSex(spellTarget) == 3),""), "SAY");
				end
				if (PriestFriendVars.RezWhisperText) then
					--SendChatMessage(InsertTagValues(ResurrectionWhisper[math.random(1,8)], spellTarget, (UnitSex(spellTarget) == 3),""), "WHISPER", GetDefaultLanguage("player"), spellTarget);
					SendChatMessage("Just FYI I'm rezzing you now", "WHISPER", GetDefaultLanguage("player"), spellTarget);
				end
				if (PriestFriendVars.RezPartyText) then
					if (GetNumRaidMembers() > 0) then  --iterate through your raid members
						SendChatMessage("Now casting "..spellName.." on "..spellTarget, "RAID", GetDefaultLanguage("player"));
					elseif (GetNumPartyMembers() > 0) then  --iterate through your raid members
						SendChatMessage("Now casting "..spellName.." on "..spellTarget, "PARTY", GetDefaultLanguage("player"));
					end
				end
			end
		end
	end
end

function MySpellCastStartEvent(timestamp, event, srcGUID, srcName, srcFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool)
	--this part makes it remember which shackle belongs to you
	--we store the previous target id just in case this cast fails
	if ((spellName == ShackleUndeadSpellName) and (srcName == UnitName("player"))) then
		LastShackleID = myShackleID;
		myShackleID = spellId; --destGUID;
		--display shackle message
		--math.randomseed(math.random(0,2147483647)+(GetTime()*1000));
		if (UnitName("target")) then
			TempMessage = InsertTagValues(ShackleMessage[math.random(1,14)],UnitName("target"),"","");
		else
			TempMessage = InsertTagValues(ShackleMessage[math.random(1,14)],"<unknown>","","");
		end
		if (PriestFriendVars.ShackleSayText) then
			SendChatMessage(TempMessage, "SAY");
		end
		if (PriestFriendVars.ShacklePartyText) then
			if (GetNumRaidMembers() > 0) then  --iterate through your raid members
				SendChatMessage(TempMessage, "RAID", GetDefaultLanguage("player"));
			elseif (GetNumPartyMembers() > 0) then  --iterate through your party members
				SendChatMessage(TempMessage, "PARTY", GetDefaultLanguage("player"));
			end
		end
	elseif ((spellName == MindControlSpellName) and (srcName == UnitName("player"))) then
		--display Mind Control message
		--math.randomseed(math.random(0,2147483647)+(GetTime()*1000));
		if (UnitName("target")) then
			TempMessage = InsertTagValues(MindControlMessage[math.random(1,3)],UnitName("target"),"","");
		else
			TempMessage = InsertTagValues(MindControlMessage[math.random(1,3)],"<unknown>","","");
		end
		if (PriestFriendVars.MCSayText) then
			SendChatMessage(TempMessage, "SAY");
		end
		if (PriestFriendVars.MCPartyText) then
			if (GetNumRaidMembers() > 0) then  --iterate through your raid members
				SendChatMessage(TempMessage, "RAID", GetDefaultLanguage("player"));
			elseif (GetNumPartyMembers() > 0) then  --iterate through your party members
				SendChatMessage(TempMessage, "PARTY", GetDefaultLanguage("player"));
			end
		end
	--elseif (srcName == UnitName("player")) then
		----display info for finding spell name
		--SendChatMessage(spellName.." on "..UnitName("target"), "SAY");
	end
end

function MySpellCastFailedEvent(timestamp, event, srcGUID, srcName, srcFlags, destGUID, destName, destFlags, spellId, spellName, failedType)
	--this part is for making it remember which shackle belongs to you 
	--but this part is for if our shackle fails which means the previous shackle
	--is what is ours
	if ((spellName == ShackleUndeadSpellName) and (srcName == UnitName("player"))) then
		--sets it to the previous one since this one failed
		myShackleID = LastShackleID;
	end
end

function isGroupMember(destName)
	local theirGroupID = "";
	for i=1,40 do
		if (destName == UnitName("raid"..i)) then
			theirGroupID = "raid"..i;
			i=40;
		elseif (destName == UnitName("raidpet"..i)) then
			if (not (PriestFriendVars.IgnorePets)) then
				theirGroupID = "raidpet"..i;
				i=40;
			end
		end
	end
	if (theirGroupID == "") then --keep looking
		for i=1,4 do
			if (destName == UnitName("party"..i)) then
				theirGroupID = "party"..i;
				i=4;
			elseif (destName == UnitName("partypet"..i)) then
				if (not (PriestFriendVars.IgnorePets)) then
					theirGroupID = "partypet"..i;
					i=4;
				end
			end
		end
	end
	return theirGroupID;
end

function MyAuraAppliedEvent(timestamp, event, srcGUID, srcName, srcFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, auraType)
	if (auraType == "DEBUFF") then
		if (destName == UnitName("player")) then
			--iterate through their debuffs
			for i=1,40 do
				local myDebuffName, rank, iconTexture, count, debuffType, duration, timeLeft = UnitDebuff("player",i,1);
				if (myDebuffName == spellName) then
					--now check to see if it's magic or disease
					if (debuffType == "Magic") then
						if (PriestFriendVars.MagicText) then
							if (not UnitIsDeadOrGhost("player")) then
								if (not UnitOnTaxi("player")) then
									DEFAULT_CHAT_FRAME:AddMessage("You need to dispell the Magic "..spellName.." from yourself", 1.0, 0.0, 0.0, nil, false);
								end
							end
						end
					elseif (debuffType == "Disease") then
						if (PriestFriendVars.DiseaseText) then
							if (not UnitIsDeadOrGhost("player")) then
								if(not UnitOnTaxi("player")) then
									DEFAULT_CHAT_FRAME:AddMessage("You need to cure the Disease "..spellName.." from yourself", 0.0, 1.0, 0.0, nil, false);
								end
							end
						end
					end
					i=40;
				end
			end
		else
			local myGroupID = isGroupMember(destName);
			if (myGroupID ~= "") then
				--we need to iterate through all their debuffs to find the one we want
				for i=1,40 do --iterate through their debuffs
					local myDebuffName, rank, iconTexture, count, debuffType, duration, timeLeft = UnitDebuff(myGroupID,i,1);
					if (myDebuffName == spellName) then
						--now check to see if it's magic or disease
						if (debuffType == "Magic") then
							if (PriestFriendVars.MagicText) then
								if (not UnitIsDeadOrGhost("player")) then
									if (not UnitOnTaxi("player")) then
										if (IsSpellInRange("Dispel Magic", destName) == 1) then
											DEFAULT_CHAT_FRAME:AddMessage("You need to dispell the Magic "..spellName.." from "..UnitName(myGroupID), 1.0, 0.0, 0.0, nil, false);
										end
									end
								end
							end
						elseif (debuffType == "Disease") then
							if (PriestFriendVars.DiseaseText) then
								if (not UnitIsDeadOrGhost("player")) then
									if (not UnitOnTaxi("player")) then
										if (IsSpellInRange("Cure Disease", destName) == 1) then
											DEFAULT_CHAT_FRAME:AddMessage("You need to cure the Disease "..spellName.." from "..UnitName(myGroupID), 0.0, 1.0, 0.0, nil, false);
										end
									end
								end
							end
						end
						i=40;
					end
				end
			end
		end
	end
end

function MyAuraRemovedEvent(timestamp, event, srcGUID, srcName, srcFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, auraType)
	if (spellName == FearWardSpellName) then
		if (not UnitIsDeadOrGhost("player")) then
			if (srcName == UnitName("player")) then
				if (PriestFriendVars.FWFadedText) then
					UIErrorsFrame:AddMessage(FearWardSpellName.." faded from from yourself", 1.0, 0.0, 0.0, nil, false);
					if (PriestFriendVars.FearWardFadedSound ~= "") then
						if (CurrentCountdown < FearWardCooldown-2) then
							PlaySoundFile(SoundPath..PriestFriendVars.FearWardFadedSound);
						end
					end
				end
			elseif (isGroupMember(destName) ~= "") then
				if (PriestFriendVars.FWFadedText) then
					UIErrorsFrame:AddMessage(FearWardSpellName.." faded from from "..destName, 1.0, 0.0, 0.0, nil, false);
					if (PriestFriendVars.FearWardFadedSound ~= "") then
						if (CurrentCountdown < FearWardCooldown-2) then
							PlaySoundFile(SoundPath..PriestFriendVars.FearWardFadedSound);
						end
					end
				end
			end
		end
	elseif ((spellName == InnerFireSpellName) and (destName == UnitName("player"))) then
		if (PriestFriendVars.InnerFireText) then
			if (not UnitIsDeadOrGhost("player")) then
				UIErrorsFrame:AddMessage("You lost "..InnerFireSpellName, 1.0, 0.0, 1.0, nil, false);
				if (PriestFriendVars.InnerFireSound ~= "") then
					PlaySoundFile(SoundPath..PriestFriendVars.InnerFireSound);
				end
			end
		end
	elseif ((spellName == PowerWordFortitudeSpellName) or (spellName == PrayerofFortitudeSpellName)) then
		if (destName == UnitName("player")) then
			if (PriestFriendVars.FortitudeText) then
				if (not UnitIsDeadOrGhost("player")) then
					UIErrorsFrame:AddMessage("You lost "..spellName, 1.0, 0.0, 1.0, nil, false);
					if (PriestFriendVars.FortitudeSound ~= "") then
						PlaySoundFile(SoundPath..PriestFriendVars.FortitudeSound);
					end
				end
			end
		else
			if (isGroupMember(destName) ~= "") then
				if (PriestFriendVars.FortitudeText) then
					if (not UnitIsDeadOrGhost("player")) then
						UIErrorsFrame:AddMessage(destName.." just lost "..spellName, 1.0, 0.0, 1.0, nil, false);
						if (PriestFriendVars.FortitudeSound ~= "") then
							PlaySoundFile(SoundPath..PriestFriendVars.FortitudeSound);
						end
					end
				end
			end
		end
	elseif ((spellName == ShadowProtectionSpellName) or (spellName == PrayerOfShadowProtectionSpellName)) then
		if (destName == UnitName("player")) then
			if (PriestFriendVars.ShadowProtectionText) then
				if (not UnitIsDeadOrGhost("player")) then
					UIErrorsFrame:AddMessage("You lost "..spellName, 1.0, 0.0, 1.0, nil, false);
					if (PriestFriendVars.ShadowProtectionSound ~= "") then
						PlaySoundFile(SoundPath..PriestFriendVars.ShadowProtectionSound);
					end
				end
			end
		else
			if (isGroupMember(destName) ~= "") then
				if (PriestFriendVars.ShadowProtectionText) then
					if (not UnitIsDeadOrGhost("player")) then
						UIErrorsFrame:AddMessage(destName.." just lost "..spellName, 1.0, 0.0, 1.0, nil, false);
						if (PriestFriendVars.ShadowProtectionSound ~= "") then
							PlaySoundFile(SoundPath..PriestFriendVars.ShadowProtectionSound);
						end
					end
				end
			end
		end
	elseif ((spellName == DivineSpiritSpellName) or (spellName == PrayerOfSpiritSpellName)) then
		if (destName == UnitName("player")) then
			if (PriestFriendVars.DivineSpiritText) then
				if (not UnitIsDeadOrGhost("player")) then
					UIErrorsFrame:AddMessage("You lost "..spellName, 1.0, 0.0, 1.0, nil, false);
					if (PriestFriendVars.DivineSpiritSound ~= "") then
						PlaySoundFile(SoundPath..PriestFriendVars.DivineSpiritSound);
					end
				end
			end
		else
			if (isGroupMember(destName) ~= "") then
				if (PriestFriendVars.DivineSpiritText) then
					if (not UnitIsDeadOrGhost("player")) then
						UIErrorsFrame:AddMessage(destName.." just lost "..spellName, 1.0, 0.0, 1.0, nil, false);
						if (PriestFriendVars.DivineSpiritSound ~= "") then
							PlaySoundFile(SoundPath..PriestFriendVars.DivineSpiritSound);
						end
					end
				end
			end
		end
	elseif (spellName == VampiricEmbraceSpellName) then
		if (destName == UnitName("player")) then
			if (PriestFriendVars.VampiricEmbraceText) then
				if (not UnitIsDeadOrGhost("player")) then
					UIErrorsFrame:AddMessage("You lost "..spellName, 1.0, 0.0, 1.0, nil, false);
					if (PriestFriendVars.VampiricEmbraceSound ~= "") then
						PlaySoundFile(SoundPath..PriestFriendVars.VampiricEmbraceSound);
					end
				end
			end
		end
	elseif (spellName == RenewedHopeSpellName) then
		if (destName == UnitName("player")) then
			if (PriestFriendVars.RHText) then
				if (not UnitIsDeadOrGhost("player")) then
					UIErrorsFrame:AddMessage("You lost "..spellName, 1.0, 0.0, 1.0, nil, false);
					if (PriestFriendVars.RenewedHopeSound ~= "") then
						PlaySoundFile(SoundPath..PriestFriendVars.RenewedHopeSound);
					end
				end
			end
		end
	elseif (spellName == ShackleUndeadSpellName) then
		if (spellId == myShackleID) then
			--that means it was my shackle that broke
			if (PriestFriendVars.ShackleBreakText) then
				UIErrorsFrame:AddMessage("Your shackle just broke", 1.0, 0.0, 1.0, nil, false);
				if (PriestFriendVars.ShackleBreakSound ~= "") then
					PlaySoundFile(SoundPath..PriestFriendVars.ShackleBreakSound);
				end
			end
		else
			--that means it was someone elses shackle that broke
			if (PriestFriendVars.OtherShackleBreakText) then
				UIErrorsFrame:AddMessage("Someone else's shackle just broke", 1.0, 0.0, 1.0, nil, false);
				if (PriestFriendVars.OtherShackleBreakSound ~= "") then
					PlaySoundFile(SoundPath..PriestFriendVars.OtherShackleBreakSound);
				end
			end
		end
	end
end

function MySpellCastSuccessEvent(timestamp, event, srcGUID, srcName, srcFlags, destGUID, destName, destFlags, spellID, spellName, spellSchool)
	if (spellName == FearWardSpellName) then
		if (srcName == UnitName("player")) then
			if (PriestFriendVars.FWReadyText) then
				UIErrorsFrame:AddMessage("You just cast "..FearWardSpellName.." on "..destName, 1.0, 0.0, 1.0, nil, false);
			end
			FWTimerEnabled = true;
		elseif (isGroupMember(destName) ~= "") then
			if (PriestFriendVars.FWCastText) then
				UIErrorsFrame:AddMessage(srcName.." just cast "..FearWardSpellName.." on "..destName, 1.0, 1.0, 1.0, nil, false);
				if (FearWardCastSound ~= "") then
					PlaySoundFile(SoundPath..PriestFriendVars.FearWardCastSound);
				end
			end
		end
	end
end

function MyVariablesLoadedEvent()
	--this just sets up the variables as well as
	--it sets up what is displayed on the form
	--now we need to check and see if the previous settings are empty, if so, then
	--we'll set them to the default value
	if 	(AlreadyStoredVars and (not PriestFriendVars.AlreadyStoredVars)) then
		--load the old variables
		PriestFriendVars.FearWardReadySoundDisplay = FearWardReadySoundDisplay
		PriestFriendVars.FearWardFadedSoundDisplay = FearWardFadedSoundDisplay
		PriestFriendVars.FearWardCastSoundDisplay = FearWardCastSoundDisplay
		PriestFriendVars.InnerFireSoundDisplay = InnerFireSoundDisplay
		PriestFriendVars.FortitudeSoundDisplay = FortitudeSoundDisplay
		PriestFriendVars.ShadowProtectionSoundDisplay = ShadowProtectionSoundDisplay
		PriestFriendVars.DivineSpiritSoundDisplay = DivineSpiritSoundDisplay
		PriestFriendVars.VampiricEmbraceSoundDisplay = VampiricEmbraceSoundDisplay
		
		PriestFriendVars.DiseaseSoundDisplay = DiseaseSoundDisplay
		PriestFriendVars.MagicSoundDisplay = MagicSoundDisplay
		PriestFriendVars.ShackleBreakSoundDisplay = ShackleBreakSoundDisplay
		PriestFriendVars.OtherShackleBreakSoundDisplay = OtherShackleBreakSoundDisplay
		PriestFriendVars.FWReadyText = FWReadyText
		PriestFriendVars.FWFadedText = FWFadedText
		PriestFriendVars.FWCastText = FWCastText
		PriestFriendVars.InnerFireText = InnerFireText
		PriestFriendVars.FortitudeText = FortitudeText
		PriestFriendVars.ShadowProtectionText = ShadowProtectionText
		PriestFriendVars.DivineSpiritText = DivineSpiritText
		PriestFriendVars.VampiricEmbraceText = VampiricEmbraceText
		PriestFriendVars.DiseaseText = DiseaseText
		PriestFriendVars.MagicText = MagicText
		PriestFriendVars.ShackleBreakText = ShackleBreakText
		PriestFriendVars.OtherShackleBreakText = OtherShackleBreakText
		PriestFriendVars.InnerFireNag = InnerFireNag
		PriestFriendVars.FortitudeNag = FortitudeNag
		PriestFriendVars.ShadowProtectionNag = ShadowProtectionNag
		PriestFriendVars.DivineSpiritNag = DivineSpiritNag
		PriestFriendVars.VampiricEmbraceNag = VampiricEmbraceNag
		
		PriestFriendVars.DevoutCandleText = DevoutCandleText
		PriestFriendVars.SacredCandleText = SacredCandleText
		PriestFriendVars.HolyCandleText = HolyCandleText
		PriestFriendVars.NagIntervalText = NagIntervalText
		PriestFriendVars.MountSayText = MountSayText
		PriestFriendVars.RezSayText = RezSayText
		PriestFriendVars.RezWhisperText = RezWhisperText
		PriestFriendVars.RezPartyText = RezPartyText
		PriestFriendVars.MCSayText = MCSayText
		PriestFriendVars.ShackleSayText = ShackleSayText
		PriestFriendVars.MountPartyText = MountPartyText
		PriestFriendVars.MCPartyText = MCPartyText
		PriestFriendVars.ShacklePartyText = ShacklePartyText
		
		PriestFriendVars.NagDuringCombat = NagDuringCombat
		PriestFriendVars.DisableNag = DisableNag
		PriestFriendVars.OnlyNagInInstances = OnlyNagInInstances
		PriestFriendVars.IgnorePets = IgnorePets
		
		--PriestFriendVars.PIText = PIText
		--PriestFriendVars.PISoundDisplay = PISoundDisplay
		--PriestFriendVars.PINag = PriestFriendVars.PINag
		
		--PriestFriendVars.RHText = RHText
		--PriestFriendVars.RHSoundDisplay = RHSoundDisplay
		--PriestFriendVars.RHNag = RHNag
		UIErrorsFrame:AddMessage("Loaded old values", 1.0, 0.0, 1.0, nil, false);
		UIErrorsFrame:AddMessage("Loaded old values", 1.0, 0.0, 1.0, nil, false);
		UIErrorsFrame:AddMessage("Loaded old values", 1.0, 0.0, 1.0, nil, false);
		UIErrorsFrame:AddMessage("Loaded old values", 1.0, 0.0, 1.0, nil, false);
	end
	PriestFriendVars.AlreadyStoredVars = 1
	
	if (PriestFriendVars.FearWardReadySoundDisplay == nil) then
		PriestFriendVars.FearWardReadySoundDisplay = "Coocoo";
	end
	if (PriestFriendVars.FearWardFadedSoundDisplay == nil) then
		PriestFriendVars.FearWardFadedSoundDisplay = "Yell";
	end
	if (PriestFriendVars.FearWardCastSoundDisplay == nil) then
		PriestFriendVars.FearWardCastSoundDisplay = "Woohoo!!!";
	end
	if (PriestFriendVars.InnerFireSoundDisplay == nil) then
		PriestFriendVars.InnerFireSoundDisplay = "Coocoo";
	end
	if (PriestFriendVars.FortitudeSoundDisplay == nil) then
		PriestFriendVars.FortitudeSoundDisplay = "Coocoo";
	end
	if (PriestFriendVars.ShadowProtectionSoundDisplay == nil) then
		PriestFriendVars.ShadowProtectionSoundDisplay = "Coocoo";
	end
	if (PriestFriendVars.DivineSpiritSoundDisplay == nil) then
		PriestFriendVars.DivineSpiritSoundDisplay = "Coocoo";
	end
	if (PriestFriendVars.VampiricEmbraceSoundDisplay == nil) then
		PriestFriendVars.VampiricEmbraceSoundDisplay = "Coocoo";
	end
	if (PriestFriendVars.RHSoundDisplay == nil) then
		PriestFriendVars.RHSoundDisplay = "Coocoo";
	end
	if (PriestFriendVars.PISoundDisplay == nil) then
		PriestFriendVars.PISoundDisplay = "Coocoo";
	end
	if (PriestFriendVars.DiseaseSoundDisplay == nil) then
		PriestFriendVars.DiseaseSoundDisplay = "Coocoo";
	end
	if (PriestFriendVars.MagicSoundDisplay == nil) then
		PriestFriendVars.MagicSoundDisplay = "Coocoo";
	end
	if (PriestFriendVars.ShackleBreakSoundDisplay == nil) then
		PriestFriendVars.ShackleBreakSoundDisplay = "Bring Dead";
	end
	if (PriestFriendVars.OtherShackleBreakSoundDisplay == nil) then
		PriestFriendVars.OtherShackleBreakSoundDisplay = "Problem";
	end

	--now load them all into the text boxes :-)
	SettingWhat = "FWReady";
	SetSound(PriestFriendVars.FearWardReadySoundDisplay);
	SettingWhat = "FWFaded";
	SetSound(PriestFriendVars.FearWardFadedSoundDisplay);
	SettingWhat = "FWCast";
	SetSound(PriestFriendVars.FearWardCastSoundDisplay);
	SettingWhat = "InnerFire";
	SetSound(PriestFriendVars.InnerFireSoundDisplay);
	SettingWhat = "Fortitude";
	SetSound(PriestFriendVars.FortitudeSoundDisplay);
	SettingWhat = "ShadowProtection";
	SetSound(PriestFriendVars.ShadowProtectionSoundDisplay);
	SettingWhat = "DivineSpirit";
	SetSound(PriestFriendVars.DivineSpiritSoundDisplay);
	SettingWhat = "VampiricEmbrace";
	SetSound(PriestFriendVars.VampiricEmbraceSoundDisplay);
	SettingWhat = "PowerInfusion";
	SetSound(PriestFriendVars.PISoundDisplay);
	SettingWhat = "RenewedHope";
	SetSound(PriestFriendVars.RHSoundDisplay);
	SettingWhat = "Disease";
	SetSound(PriestFriendVars.DiseaseSoundDisplay);
	SettingWhat = "Magic";
	SetSound(PriestFriendVars.MagicSoundDisplay);
	SettingWhat = "ShackleBreak";
	SetSound(PriestFriendVars.ShackleBreakSoundDisplay);
	SettingWhat = "OtherShackleBreak";
	SetSound(PriestFriendVars.OtherShackleBreakSoundDisplay);

	--now set up all the checkboxes
	if (PriestFriendVars.AlreadyStoredVars) then
		chkNagCombat:SetChecked(PriestFriendVars.NagDuringCombat);
		chkDisableNag:SetChecked(PriestFriendVars.DisableNag);
		chkOnlyNagInInstances:SetChecked(PriestFriendVars.OnlyNagInInstances);
		chkIgnorePets:SetChecked(PriestFriendVars.IgnorePets);
		chkFWReady:SetChecked(PriestFriendVars.FWReadyText);
		chkFWFaded:SetChecked(PriestFriendVars.FWFadedText);
		chkFWCast:SetChecked(PriestFriendVars.FWCastText);
		chkInnerFire:SetChecked(PriestFriendVars.InnerFireText);
		chkFortitude:SetChecked(PriestFriendVars.FortitudeText);
		chkShadowProtection:SetChecked(PriestFriendVars.ShadowProtectionText);
		chkDivineSpirit:SetChecked(PriestFriendVars.DivineSpiritText);
		chkVampiricEmbrace:SetChecked(PriestFriendVars.VampiricEmbraceText);
		chkPowerInfusion:SetChecked(PriestFriendVars.PIText);
		chkRenewedHope:SetChecked(PriestFriendVars.RHText);
		chkDisease:SetChecked(PriestFriendVars.DiseaseText);
		chkMagic:SetChecked(PriestFriendVars.MagicText);
		chkShackleBreak:SetChecked(PriestFriendVars.ShackleBreakText);
		chkOtherShackleBreak:SetChecked(PriestFriendVars.OtherShackleBreakText);
		chkInnerFireNag:SetChecked(PriestFriendVars.InnerFireNag);
		chkFortitudeNag:SetChecked(PriestFriendVars.FortitudeNag);
		chkShadowProtectionNag:SetChecked(PriestFriendVars.ShadowProtectionNag);
		chkDivineSpiritNag:SetChecked(PriestFriendVars.DivineSpiritNag);
		chkVampiricEmbraceNag:SetChecked(PriestFriendVars.VampiricEmbraceNag);
		chkPowerInfusionNag:SetChecked(PriestFriendVars.PINag);
		chkRenewedHopeNag:SetChecked(PriestFriendVars.RHNag);
		chkMountSay:SetChecked(PriestFriendVars.MountSayText);
		chkRezSay:SetChecked(PriestFriendVars.RezSayText);
		chkRezWhisper:SetChecked(PriestFriendVars.RezWhisperText);
		chkRezParty:SetChecked(PriestFriendVars.RezPartyText);
		chkMCSay:SetChecked(PriestFriendVars.MCSayText);
		chkShackleSay:SetChecked(PriestFriendVars.ShackleSayText);
		chkMountParty:SetChecked(PriestFriendVars.MountPartyText);
		chkMCParty:SetChecked(PriestFriendVars.MCPartyText);
		chkShackleParty:SetChecked(PriestFriendVars.ShacklePartyText);
	end
	
	--now set up the sliders
	if (PriestFriendVars.DevoutCandleText) then
		sldDevoutCandles:SetValue(PriestFriendVars.DevoutCandleText);
	else
		sldDevoutCandles:SetValue("60");
	end
	if (PriestFriendVars.SacredCandleText) then
		sldSacredCandles:SetValue(PriestFriendVars.SacredCandleText);
	else
		sldSacredCandles:SetValue("0");
	end
	if (PriestFriendVars.HolyCandleText) then
		sldHolyCandles:SetValue(PriestFriendVars.HolyCandleText);
	else
		sldHolyCandles:SetValue("0");
	end
	if (PriestFriendVars.NagIntervalText) then
		sldNagInterval:SetValue(PriestFriendVars.NagIntervalText);
	else
		sldNagInterval:SetValue("60");
	end
end

function Timer_OnUpdate(self, elapsed)
	--DEFAULT_CHAT_FRAME:AddMessage("it's running", 1.0, 1.0, 1.0, nil, false);
	if (FWTimerEnabled == true) then
		--DEFAULT_CHAT_FRAME:AddMessage("here:"..elapsed, 1.0, 1.0, 1.0, nil, false);
		FWTimeSinceLastUpdate = FWTimeSinceLastUpdate + elapsed;
		while (FWTimeSinceLastUpdate > UpdateInterval) do
			--DEFAULT_CHAT_FRAME:AddMessage("Counting "..CurrentCountdown, 1.0, 0.0, 0.0, nil, false);
			CurrentCountdown = CurrentCountdown + 1.0; --count 1 second
			if (CurrentCountdown > FearWardCooldown-6) then
				if (CurrentCountdown > FearWardCooldown-1) then
					CurrentCountdown = 1;
					FWTimerEnabled = false;
					FWTimeSinceLastUpdate = 0;
					if (PriestFriendVars.FWReadyText) then
						DEFAULT_CHAT_FRAME:AddMessage(FearWardSpellName.." is ready!!!", 1.0, 0.0, 0.0, nil, false);
						if (FearWardReadySound ~= "") then
							PlaySoundFile(SoundPath..PriestFriendVars.FearWardReadySound);
						end
					end
				else
					--print the last 5 seconds of the countdown
					if (PriestFriendVars.FWReadyText) then
						DEFAULT_CHAT_FRAME:AddMessage(FearWardSpellName.." will be ready in "..(FearWardCooldown-CurrentCountdown).." seconds", 1.0, 1.0, 1.0, nil, false);
					end
				end
			end
			FWTimeSinceLastUpdate = FWTimeSinceLastUpdate - UpdateInterval;
		end
	end
	local TempNagMessageSelf = "";
	TempNagMessageRaidFort = "";
	TempNagMessageRaidShadowProt = "";
	HasInnerFire = false;
	HasFort = false;
	HasShadowProt = false;
	HasDivineSpirit = false;
	HasVampiricEmbrace = false;
	HasPowerInfusion = false;
	HasRenewedHope = false;
	--DEFAULT_CHAT_FRAME:AddMessage("here:"..elapsed, 1.0, 1.0, 1.0, nil, false);
	NagTimeSinceLastUpdate = NagTimeSinceLastUpdate + elapsed;
	if (NagTimeSinceLastUpdate > PriestFriendVars.NagIntervalText) then
		if (not PriestFriendVars.DisableNag) then
			if (PriestFriendVars.NagDuringCombat or (not InCombatLockdown())) then
				local TheyAreInAnInstance = false
				local instance, Type = IsInInstance()
				if (instance and Type == "party") then
					TheyAreInAnInstance = true;
				elseif (instance and Type == "raid") then
					TheyAreInAnInstance = true;
				else
					TheyAreInAnInstance = false;
				end
				if (TheyAreInAnInstance or (not PriestFriendVars.OnlyNagInInstances)) then
					if (PriestFriendVars.InnerFireNag or PriestFriendVars.FortitudeNag or PriestFriendVars.ShadowProtectionNag or PriestFriendVars.DivineSpiritNag or PriestFriendVars.VampiricEmbraceNag or PriestFriendVars.PINag or PriestFriendVars.RHNag) then
						if (not UnitIsDeadOrGhost("player")) then
							if (not UnitOnTaxi("player")) then
								if (GetMount() == "") then
									if (not UnitOnTaxi("player")) then
										local IsSpiritOfRedemption = false;
										--now check the buffs that we need to check
										--check yo'self before you reck yo'self :-P
										--iterate through your buffs
										--DEFAULT_CHAT_FRAME:AddMessage("Checking Buffs", 1.0, 0.0, 0.0, 53, 5);
										TempNagMessageSelf = "";
										
										local usable, nomana = IsUsableSpell(InnerFireSpellName); --this disables it if it's not castable (false positive)
										HasInnerFire = (not PriestFriendVars.InnerFireNag) or (not usable); --this will give us a false positive if it's disabled
										
										usable, nomana = IsUsableSpell(PowerWordFortitudeSpellName); --this disables it if it's not castable (false positive)
										HasFort = (not PriestFriendVars.FortitudeNag) or (not usable); --this will give us a false positive if it's disabled
										
										usable, nomana = IsUsableSpell(ShadowProtectionSpellName); --this disables it if it's not castable (false positive)
										HasShadowProt = (not PriestFriendVars.ShadowProtectionNag) or (not usable); --this will give us a false positive if it's disabled
										
										usable, nomana = IsUsableSpell(DivineSpiritSpellName); --this disables it if it's not castable (false positive)
										HasDivineSpirit = (not PriestFriendVars.DivineSpiritNag) or (not usable); --this will give us a false positive if it's disabled
										
										usable, nomana = IsUsableSpell(VampiricEmbraceSpellName); --this disables it if it's not castable (false positive)
										HasVampiricEmbrace = (not PriestFriendVars.VampiricEmbraceNag) or (not usable); --this will give us a false positive if it's disabled
										
										usable, nomana = IsUsableSpell(PowerInfusionSpellName); --this disables it if it's not castable (false positive)
										if (usable) then
											start, duration, enabled = GetSpellCooldown(PowerInfusionSpellName);
											HasPowerInfusion = (not PriestFriendVars.PINag) or (duration > 0); --this will give us a false positive if it's disabled
										else
											HasPowerInfusion = true;
										end
										
										numTalents = GetNumTalents(1, false, false)
										RenewedHopeTalentNum = 21;
										if (numTalents >= RenewedHopeTalentNum) then
											name, iconPath, tier, column, currentRank, maxRank, isExceptional, meetsPrereq = GetTalentInfo(1, RenewedHopeTalentNum, false, false, nil)
											if (currentRank > 0) then
												usable, nomana = IsUsableSpell(PowerWordShieldSpellName); --this disables it if it's not castable (false positive)
												HasRenewedHope = (not PriestFriendVars.RHNag) or (not usable); --this will give us a false positive if it's disabled
											else
												HasRenewedHope = true; --this will give us a false positive because they're not specc'd into it
											end
										else
											HasRenewedHope = true;
										end
										
										NumBuffs = 0;
										TempNumBuffs = 0;
										--first check yourself
										for i=1,40 do
											local myBuffName, rank, iconTexture, count, duration, timeLeft =  UnitBuff("player", i);
											if (myBuffName == InnerFireSpellName) then
												HasInnerFire = true;
											elseif ((myBuffName == PowerWordFortitudeSpellName) or (myBuffName == PrayerofFortitudeSpellName)) then
												HasFort = true;
											elseif ((myBuffName == ShadowProtectionSpellName) or (myBuffName == PrayerOfShadowProtectionSpellName)) then
												HasShadowProt = true;						
											elseif ((myBuffName == DivineSpiritSpellName) or (myBuffName == PrayerOfSpiritSpellName)) then
												HasDivineSpirit = true;
											elseif (myBuffName == VampiricEmbraceSpellName) then
												HasVampiricEmbrace = true;
											elseif (myBuffName == RenewedHopeSpellName) then
												HasRenewedHope = true;
											elseif (myBuffName == SpiritOfRedemptionSpellName) then
												IsSpiritOfRedemption = true;
											end
											if ((HasInnerFire) and (HasFort) and (HasShadowProt) and (HasDivineSpirit) and (HasVampiricEmbrace) and (HasRenewedHope)) then
												i=40;
											end
										end
										if (not IsSpiritOfRedemption) then
											TempNagMessageSelf = MakeMyMessage(HasInnerFire, HasFort, HasShadowProt, HasDivineSpirit, HasVampiricEmbrace, HasPowerInfusion, HasRenewedHope);
											if (TempNagMessageSelf ~= "") then
												if (not HasInnerFire) then
													if (PriestFriendVars.InnerFireSound ~= "") then
														PlaySoundFile(SoundPath..PriestFriendVars.InnerFireSound);
													end
												end
												if (not HasFort) then
													if (PriestFriendVars.FortitudeSound ~= "") then
														PlaySoundFile(SoundPath..PriestFriendVars.FortitudeSound);
													end
												end
												if (not HasShadowProt) then
													if (PriestFriendVars.ShadowProtectionSound ~= "") then
														PlaySoundFile(SoundPath..PriestFriendVars.ShadowProtectionSound);
													end
												end
												if (not HasDivineSpirit) then
													if (PriestFriendVars.DivineSpiritSound ~= "") then
														PlaySoundFile(SoundPath..PriestFriendVars.DivineSpiritSound);
													end
												end
												if (not HasVampiricEmbrace) then
													if (PriestFriendVars.VampiricEmbraceSound ~= "") then
														PlaySoundFile(SoundPath..PriestFriendVars.VampiricEmbraceSound);
													end
												end
												if (not HasPowerInfusion) then
													if (PriestFriendVars.PowerInfusionSound ~= "") then
														PlaySoundFile(SoundPath..PriestFriendVars.PowerInfusionSound);
													end
												end
												if (not HasRenewedHope) then
													if (PriestFriendVars.RenewedHopeSound ~= "") then
														PlaySoundFile(SoundPath..PriestFriendVars.RenewedHopeSound);
													end
												end
												UIErrorsFrame:AddMessage("You need "..TempNagMessageSelf, 1.0, 0.0, 0.0, 53, 5);
											end
											--now check party/raid members for the buffs
											TempNagMessageRaidFort = "";
											TempNagMessageRaidShadowProt = "";
											TempNagMessageRaidDivineSpirit = "";
											if (GetNumRaidMembers() > 0) then  --iterate through your raid members
												--go through and check for dead people to rez
												for i=1,40 do
													if (UnitName("raid"..i)) then
														if (UnitName("raid"..i) ~= UnitName("player")) then
															if (not UnitIsDeadOrGhost("raid"..i)) then
																if (UnitIsConnected("raid"..i)) then
																	--check buffs
																	CheckFortAndShadowBuffs("raid"..i);
																end
															end
														end
													end
													if (not (PriestFriendVars.IgnorePets)) then
														if (UnitName("raidpet"..i)) then
															if (not UnitIsDeadOrGhost("raid"..i)) then
																if (UnitIsConnected("raid"..i)) then
																	--check buffs
																	CheckFortAndShadowBuffs("raidpet"..i);
																end
															end
														end
													end
												end
											elseif (GetNumPartyMembers() > 0) then  --iterate through your raid members
												for i=1,4 do
													if (UnitName("party"..i)) then
														if (not UnitIsDeadOrGhost("party"..i)) then
															if (UnitIsConnected("party"..i)) then
																--check buffs
																CheckFortAndShadowBuffs("party"..i);
															end
														end
													end
													if (not (PriestFriendVars.IgnorePets)) then
														if (UnitName("partypet"..i)) then
															if (not UnitIsDeadOrGhost("party"..i)) then
																if (UnitIsConnected("party"..i)) then
																	--check buffs
																	CheckFortAndShadowBuffs("partypet"..i);
																end
															end
														end
													end
												end
											end
											if (TempNagMessageRaidFort ~= "") then
												UIErrorsFrame:AddMessage("Needs Fortitude:"..TempNagMessageRaidFort, 1.0, 0.0, 0.0, 53, 5);
												if (FortitudeSound ~= "") then
													PlaySoundFile(SoundPath..PriestFriendVars.FortitudeSound);
												end
											end
											if (TempNagMessageRaidShadowProt ~= "") then
												UIErrorsFrame:AddMessage("Needs Shadow Protection:"..TempNagMessageRaidShadowProt, 1.0, 0.0, 0.0, 53, 5);
												if (ShadowProtectionSound ~= "") then
													PlaySoundFile(SoundPath..PriestFriendVars.ShadowProtectionSound);
												end
											end
											if (TempNagMessageRaidDivineSpirit ~= "") then
												UIErrorsFrame:AddMessage("Needs Divine Spirit:"..TempNagMessageRaidDivineSpirit, 1.0, 0.0, 0.0, 53, 5);
												if (DivineSpiritSound ~= "") then
													PlaySoundFile(SoundPath..PriestFriendVars.DivineSpiritSound);
												end
											end
										end
									end
								end	
							end
						end
					end
				end
			end
		end
		while (NagTimeSinceLastUpdate > PriestFriendVars.NagIntervalText) do
			NagTimeSinceLastUpdate = NagTimeSinceLastUpdate - PriestFriendVars.NagIntervalText;
		end
	end
end

function CheckFortAndShadowBuffs(WhoToCheck)
	local HasPhaseShift = False; --this keeps track of if they have phase shift (warlock pet)
	
	local usable, nomana = IsUsableSpell(PowerWordFortitudeSpellName); --this disables it if it's not castable (false positive)
	HasFort = (not PriestFriendVars.FortitudeNag) or (not usable); --this will give us a false positive if it's disabled
	
	usable, nomana = IsUsableSpell(ShadowProtectionSpellName); --this disables it if it's not castable (false positive)
	HasShadowProt = (not PriestFriendVars.ShadowProtectionNag) or (not usable); --this will give us a false positive if it's disabled
	
	usable, nomana = IsUsableSpell(DivineSpiritSpellName); --this disables it if it's not castable (false positive)
	HasDivineSpirit = (not PriestFriendVars.DivineSpiritNag) or (not usable); --this will give us a false positive if it's disabled
	local j
	for j=1,40 do
		local myBuffName, rank, iconTexture, count, duration, timeLeft =  UnitBuff(WhoToCheck, j);
		if (myBuffName) then
			if ((myBuffName == PowerWordFortitudeSpellName) or (myBuffName == PrayerofFortitudeSpellName)) then
				HasFort = true;
			elseif ((myBuffName == ShadowProtectionSpellName) or (myBuffName == PrayerOfShadowProtectionSpellName)) then
				HasShadowProt = true;
			elseif ((myBuffName == DivineSpiritSpellName) or (myBuffName == PrayerOfSpiritSpellName)) then
				HasDivineSpirit = true;
			elseif (myBuffName == PhaseShiftSpellName) then
				HasPhaseShift = true;
			end
			if (((HasFort) and (HasShadowProt)) and (HasDivineSpirit)) then
				j=40; --stop looking, we have what we want
			end
		else
			j=40; --because we reached the end
		end
	end
	if (UnitName(WhoToCheck) == "Treant") then
		HasShadowProt = true; --lie and say they have it
		HasFort = true; --lie and say they have it
		HasDivineSpirit = true; --lie and say they have it
	elseif (UnitName(WhoToCheck) == "Spirit Wolf") then
		HasShadowProt = true; --lie and say they have it
		HasFort = true; --lie and say they have it
		HasDivineSpirit = true; --lie and say they have it
	else
		if (not UnitIsPlayer(WhoToCheck)) then
			--check to see if they're either a hunter's pet, or a warlock's pet or a deathknight's pet
			if (not (UnitCreatureType("unit") == "Beast")) then
				if (not (UnitCreatureType("unit") == "Demon")) then
					if (not (UnitCreatureType("unit") == "Undead")) then
						--that means it's not the pet of a hunter, warlock, or deathknight
						--so give it a false positive because we don't care about them
						HasShadowProt = true; --lie and say they have it
						HasFort = true; --lie and say they have it
						HasDivineSpirit = true; --lie and say they have it
					end
				end
			end
		end
	end
	if (HasPhaseShift) then
		HasShadowProt = true; --lie and say they have it
		HasFort = true; --lie and say they have it
		HasDivineSpirit = true; --lie and say they have it
	end
	if (IsSpellInRange(PowerWordFortitudeSpellName, WhoToCheck) ~= 1) then
		HasFort = true; --lie and say they have it
	end
	if (IsSpellInRange(ShadowProtectionSpellName, WhoToCheck) ~= 1) then
		HasShadowProt = true; --lie and say they have it
	end
	if (IsSpellInRange(DivineSpiritSpellName, WhoToCheck) ~= 1) then
		HasDivineSpirit = true; --lie and say they have it
	end
	if (not ((((HasFort) and (HasShadowProt))) and (HasDivineSpirit))) then
		if (not HasFort) then
			if (TempNagMessageRaidFort == "") then
				TempNagMessageRaidFort = TempNagMessageRaidFort..UnitName(WhoToCheck);
			else
				TempNagMessageRaidFort = TempNagMessageRaidFort..","..UnitName(WhoToCheck);
			end
		end
		if (not HasShadowProt) then
			if (TempNagMessageRaidShadowProt == "") then
				TempNagMessageRaidShadowProt = TempNagMessageRaidShadowProt..UnitName(WhoToCheck);
			else
				TempNagMessageRaidShadowProt = TempNagMessageRaidShadowProt..","..UnitName(WhoToCheck);
			end
		end
		if (not HasDivineSpirit) then
			if (TempNagMessageRaidDivineSpirit == "") then
				TempNagMessageRaidDivineSpirit = TempNagMessageRaidDivineSpirit..UnitName(WhoToCheck);
			else
				TempNagMessageRaidDivineSpirit = TempNagMessageRaidDivineSpirit..","..UnitName(WhoToCheck);
			end
		end
	end
end

function MakeMyMessage(HasInnerFire, HasFort, HasShadowProt, HasDivineSpirit, HasVampiricEmbrace, HasPowerInfusion, HasRenewedHope)
	local TempMyMessage = "";
	local NumBuffs = 0;
	local TempNumBuffs = 0;
	if (not ((HasInnerFire) and (HasFort) and (HasShadowProt) and (HasDivineSpirit) and (HasVampiricEmbrace) and (HasPowerInfusion) and (HasRenewedHope))) then
		NumBuffs = 0;
		TempNumBuffs = 0;
		if (not (HasInnerFire)) then
			NumBuffs = NumBuffs + 1;
		end
		if (not (HasFort)) then
			NumBuffs = NumBuffs + 1;
		end
		if (not (HasShadowProt)) then
			NumBuffs = NumBuffs + 1;
		end
		if (not (HasDivineSpirit)) then
			NumBuffs = NumBuffs + 1;
		end
		if (not (HasVampiricEmbrace)) then
			NumBuffs = NumBuffs + 1;
		end
		if (not (HasPowerInfusion)) then
			NumBuffs = NumBuffs + 1;
		end
		if (not (HasRenewedHope)) then
			NumBuffs = NumBuffs + 1;
		end
		-- now that we know how many put the message together
		if (not (HasInnerFire)) then
			TempMyMessage = InnerFireSpellName;
			TempNumBuffs = TempNumBuffs + 1;
		end
		if (not (HasFort)) then
			if (TempNumBuffs == 0) then
				TempMyMessage = PowerWordFortitudeSpellName;
			elseif (NumBuffs == TempNumBuffs + 1) then --this is the last buff
				if (NumBuffs == 2) then
					TempMyMessage = TempMyMessage.." and "..PowerWordFortitudeSpellName;
				else
					TempMyMessage = TempMyMessage..", and "..PowerWordFortitudeSpellName;
				end
			else 
				TempMyMessage = TempMyMessage..", "..PowerWordFortitudeSpellName;
			end
			TempNumBuffs = TempNumBuffs + 1;
		end
		if (not (HasShadowProt)) then
			if (TempNumBuffs == 0) then
				TempMyMessage = ShadowProtectionSpellName;
			elseif (NumBuffs == TempNumBuffs + 1) then --this is the last buff
				if (NumBuffs == 2) then
					TempMyMessage = TempMyMessage.." and "..ShadowProtectionSpellName;
				else
					TempMyMessage = TempMyMessage..", and "..ShadowProtectionSpellName;
				end
			else 
				TempMyMessage = TempMyMessage..", "..ShadowProtectionSpellName;
			end
			TempNumBuffs = TempNumBuffs + 1;
		end
		if (not (HasDivineSpirit)) then
			if (TempNumBuffs == 0) then
				TempMyMessage = DivineSpiritSpellName;
			elseif (NumBuffs == TempNumBuffs + 1) then --this is the last buff
				if (NumBuffs == 2) then
					TempMyMessage = TempMyMessage.." and "..DivineSpiritSpellName;
				else
					TempMyMessage = TempMyMessage..", and "..DivineSpiritSpellName;
				end
			else 
				TempMyMessage = TempMyMessage..", "..DivineSpiritSpellName;
			end
			TempNumBuffs = TempNumBuffs + 1;
		end
		if (not (HasVampiricEmbrace)) then
			if (TempNumBuffs == 0) then
				TempMyMessage = VampiricEmbraceSpellName;
			elseif (NumBuffs == TempNumBuffs + 1) then --this is the last buff
				if (NumBuffs == 2) then
					TempMyMessage = TempMyMessage.." and "..VampiricEmbraceSpellName;
				else
					TempMyMessage = TempMyMessage..", and "..VampiricEmbraceSpellName;
				end
			else 
				TempMyMessage = TempMyMessage..", "..VampiricEmbraceSpellName;
			end
			TempNumBuffs = TempNumBuffs + 1;
		end
		if (not (HasPowerInfusion)) then
			if (TempNumBuffs == 0) then
				TempMyMessage = PowerInfusionSpellName;
			elseif (NumBuffs == TempNumBuffs + 1) then --this is the last buff
				if (NumBuffs == 2) then
					TempMyMessage = TempMyMessage.." and "..PowerInfusionSpellName;
				else
					TempMyMessage = TempMyMessage..", and "..PowerInfusionSpellName;
				end
			else 
				TempMyMessage = TempMyMessage..", "..PowerInfusionSpellName;
			end
			TempNumBuffs = TempNumBuffs + 1;
		end
		if (not (HasRenewedHope)) then
			if (TempNumBuffs == 0) then
				TempMyMessage = RenewedHopeSpellName;
			elseif (NumBuffs == TempNumBuffs + 1) then --this is the last buff
				if (NumBuffs == 2) then
					TempMyMessage = TempMyMessage.." and "..RenewedHopeSpellName;
				else
					TempMyMessage = TempMyMessage..", and "..RenewedHopeSpellName;
				end
			else 
				TempMyMessage = TempMyMessage..", "..RenewedHopeSpellName;
			end
			TempNumBuffs = TempNumBuffs + 1;
		end
	end
	return TempMyMessage;
end

function HideConfig()
	Config:Hide();
end

function ShowConfig()
	Config:Show();
end

--function MyAddOn_OnComms(chattype, text, author)
	--if (chattype == "CHAT_MSG_SAY") then
	--	DEFAULT_CHAT_FRAME:AddMessage(text, 1.0, 1.0, 1.0, nil, false);
	--elseif (chattype == "CHAT_MSG_WHISPER") then
	--	DEFAULT_CHAT_FRAME:AddMessage(text, 1.0, 0.0, 0.0, nil, false);
	--end
--end
