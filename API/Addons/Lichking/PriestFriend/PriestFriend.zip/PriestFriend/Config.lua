﻿-- Author        : jmeadows
-- Creation Date : 5/22/2008 6:24:22 PM
-- Last Modified : 7/18/2008

function btnClose_OnClick()
	cmbSounds:Hide();
	Config:Hide();
end

function Config_OnLoad()
--this just makes em so the background is grey
	btnFWReadyBG:Disable();
	btnFWFadedBG:Disable();
	btnFWCastBG:Disable();
	btnInnerFireBG:Disable();
	btnFortitudeBG:Disable();
	btnShadowProtectionBG:Disable();
	btnDivineSpiritBG:Disable();
	btnVampiricEmbraceBG:Disable();
	btnPowerInfusionBG:Disable();
	btnRenewedHopeBG:Disable();
	btnDiseaseBG:Disable();
	btnMagicBG:Disable();
	btnShackleBreakBG:Disable();
	btnOtherShackleBreakBG:Disable();
end

function btnFWReadyDropdown_OnClick()
	if ((SettingWhat == "FWReady") and (cmbSounds:IsVisible())) then
		--close it because they hit it again
		cmbSounds:Hide();
	else
		--open it
		SettingWhat = "FWReady";
		SetSoundChecks(lblFWReadyValue:GetText());
	end
end

function btnFWFadedDropdown_OnClick()
	if ((SettingWhat == "FWFaded") and (cmbSounds:IsVisible())) then
		cmbSounds:Hide();
	else
		SettingWhat = "FWFaded";
		SetSoundChecks(lblFWFadedValue:GetText());
	end
end

function btnFWCastDropdown_OnClick()
	if ((SettingWhat == "FWCast") and (cmbSounds:IsVisible())) then
		cmbSounds:Hide();
	else
		SettingWhat = "FWCast";
		SetSoundChecks(lblFWCastValue:GetText());
	end
end

function btnInnerFireDropdown_OnClick()
	if ((SettingWhat == "InnerFire") and (cmbSounds:IsVisible())) then
		cmbSounds:Hide();
	else
		SettingWhat = "InnerFire";
		SetSoundChecks(lblInnerFireValue:GetText());
	end
end

function btnFortitudeDropdown_OnClick()
	if ((SettingWhat == "Fortitude") and (cmbSounds:IsVisible())) then
		cmbSounds:Hide();
	else
		SettingWhat = "Fortitude";
		SetSoundChecks(lblFortitudeValue:GetText());
	end
end

function btnShadowProtectionDropdown_OnClick()
	if ((SettingWhat == "ShadowProtection") and (cmbSounds:IsVisible())) then
		cmbSounds:Hide();
	else
		SettingWhat = "ShadowProtection";
		SetSoundChecks(lblShadowProtectionValue:GetText());
	end
end

function btnDivineSpiritDropdown_OnClick()
	if ((SettingWhat == "DivineSpirit") and (cmbSounds:IsVisible())) then
		cmbSounds:Hide();
	else
		SettingWhat = "DivineSpirit";
		SetSoundChecks(lblDivineSpiritValue:GetText());
	end
end

function btnVampiricEmbraceDropdown_OnClick()
	if ((SettingWhat == "VampiricEmbrace") and (cmbSounds:IsVisible())) then
		cmbSounds:Hide();
	else
		SettingWhat = "VampiricEmbrace";
		SetSoundChecks(lblVampiricEmbraceValue:GetText());
	end
end

function btnPowerInfusionDropdown_OnClick()
	if ((SettingWhat == "PowerInfusion") and (cmbSounds:IsVisible())) then
		cmbSounds:Hide();
	else
		SettingWhat = "PowerInfusion";
		SetSoundChecks(lblPowerInfusionValue:GetText());
	end
end

function btnRenewedHopeDropdown_OnClick()
	if ((SettingWhat == "RenewedHope") and (cmbSounds:IsVisible())) then
		cmbSounds:Hide();
	else
		SettingWhat = "RenewedHope";
		SetSoundChecks(lblRenewedHopeValue:GetText());
	end
end

function btnDiseaseDropdown_OnClick()
	if ((SettingWhat == "Disease") and (cmbSounds:IsVisible())) then
		cmbSounds:Hide();
	else
		SettingWhat = "Disease";
		SetSoundChecks(lblDiseaseValue:GetText());
	end
end

function btnMagicDropdown_OnClick()
	if ((SettingWhat == "Magic") and (cmbSounds:IsVisible())) then
		cmbSounds:Hide();
	else
		SettingWhat = "Magic";
		SetSoundChecks(lblMagicValue:GetText());
	end
end

function btnShackleBreakDropdown_OnClick()
	if ((SettingWhat == "ShackleBreak") and (cmbSounds:IsVisible())) then
		cmbSounds:Hide();
	else
		SettingWhat = "ShackleBreak";
		SetSoundChecks(lblShackleBreakValue:GetText());
	end
end

function btnOtherShackleBreakDropdown_OnClick()
	if ((SettingWhat == "OtherShackleBreak") and (cmbSounds:IsVisible())) then
		cmbSounds:Hide();
	else
		SettingWhat = "OtherShackleBreak";
		SetSoundChecks(lblOtherShackleBreakValue:GetText());
	end
end

function SetSound(SoundName)
	local SoundFilename
	cmbSounds:Hide();
	if (SoundName == "(None)") then
		SoundFilename = "";
	elseif (SoundName == "Engage") then
		SoundFilename = "startrek-tng-engage.wav";
	elseif (SoundName == "Woohoo!!!") then
		SoundFilename = "WOOHOO.WAV";
	elseif (SoundName == "Hallelujah") then
		SoundFilename = "HALLELUJ.WAV";
	elseif (SoundName == "Alrighty") then
		SoundFilename = "ALRIGHTY.WAV";
	elseif (SoundName == "Come On") then
		SoundFilename = "come-on-you-can-do-it.wav";
	elseif (SoundName == "Aooga") then
		SoundFilename = "AOOGA.WAV";
	elseif (SoundName == "Anxious") then
		SoundFilename = "ANXIOUS.WAV";
	elseif (SoundName == "Reload") then
		SoundFilename = "gun-reload-1.wav";
	elseif (SoundName == "Yell") then
		SoundFilename = "WilhelmScream.mp3";
	elseif (SoundName == "Bummer") then
		SoundFilename = "BUMMER.WAV";
	elseif (SoundName == "Coocoo") then
		SoundFilename = "birds_kuku.wav";
	elseif (SoundName == "Dammit") then
		SoundFilename = "damn-it.wav";
	elseif (SoundName == "Aye Caramba") then
		SoundFilename = "bart-aycaramba.wav";
	elseif (SoundName == "Problem") then
		SoundFilename = "APOLLO03.WAV";
	elseif (SoundName == "Ooga") then
		SoundFilename = "OOGA.WAV";
	elseif (SoundName == "Bring Dead") then
		SoundFilename = "BRNGDEAD.WAV";
	else
		SoundFilename = "";
	end
	if (SettingWhat == "FWReady") then
		lblFWReadyValue:SetText(SoundName);
		PriestFriendVars.FearWardReadySound = SoundFilename;
		PriestFriendVars.FearWardReadySoundDisplay = SoundName;
	elseif (SettingWhat == "FWFaded") then
		lblFWFadedValue:SetText(SoundName);
		PriestFriendVars.FearWardFadedSound = SoundFilename;
		PriestFriendVars.FearWardFadedSoundDisplay = SoundName;
	elseif (SettingWhat == "FWCast") then
		lblFWCastValue:SetText(SoundName);
		PriestFriendVars.FearWardCastSound = SoundFilename;
		PriestFriendVars.FearWardCastSoundDisplay = SoundName;
	elseif (SettingWhat == "InnerFire") then
		lblInnerFireValue:SetText(SoundName);
		PriestFriendVars.InnerFireSound = SoundFilename;
		PriestFriendVars.InnerFireSoundDisplay = SoundName;
	elseif (SettingWhat == "Fortitude") then
		lblFortitudeValue:SetText(SoundName);
		PriestFriendVars.FortitudeSound = SoundFilename;
		PriestFriendVars.FortitudeSoundDisplay = SoundName;
	elseif (SettingWhat == "ShadowProtection") then
		lblShadowProtectionValue:SetText(SoundName);
		PriestFriendVars.ShadowProtectionSound = SoundFilename;
		PriestFriendVars.ShadowProtectionSoundDisplay = SoundName;
	elseif (SettingWhat == "DivineSpirit") then
		lblDivineSpiritValue:SetText(SoundName);
		PriestFriendVars.DivineSpiritSound = SoundFilename;
		PriestFriendVars.DivineSpiritSoundDisplay = SoundName;
	elseif (SettingWhat == "VampiricEmbrace") then
		lblVampiricEmbraceValue:SetText(SoundName);
		PriestFriendVars.VampiricEmbraceSound = SoundFilename;
		PriestFriendVars.VampiricEmbraceSoundDisplay = SoundName;
	elseif (SettingWhat == "PowerInfusion") then
		lblPowerInfusionValue:SetText(SoundName);
		PriestFriendVars.PowerInfusionSound = SoundFilename;
		PriestFriendVars.PISoundDisplay = SoundName;
	elseif (SettingWhat == "RenewedHope") then
		lblRenewedHopeValue:SetText(SoundName);
		PriestFriendVars.RenewedHopeSound = SoundFilename;
		PriestFriendVars.RHSoundDisplay = SoundName;
	elseif (SettingWhat == "Disease") then
		lblDiseaseValue:SetText(SoundName);
		PriestFriendVars.DiseaseSound = SoundFilename;
		PriestFriendVars.DiseaseSoundDisplay = SoundName;
	elseif (SettingWhat == "Magic") then
		lblMagicValue:SetText(SoundName);
		PriestFriendVars.MagicSound = SoundFilename;
		PriestFriendVars.MagicSoundDisplay = SoundName;
	elseif (SettingWhat == "ShackleBreak") then
		lblShackleBreakValue:SetText(SoundName);
		PriestFriendVars.ShackleBreakSound = SoundFilename;
		PriestFriendVars.ShackleBreakSoundDisplay = SoundName;
	elseif (SettingWhat == "OtherShackleBreak") then
		lblOtherShackleBreakValue:SetText(SoundName);
		PriestFriendVars.OtherShackleBreakSound = SoundFilename;
		PriestFriendVars.OtherShackleBreakSoundDisplay = SoundName;
	end
	--DEFAULT_CHAT_FRAME:AddMessage(SettingWhat.." sound set to "..SoundName, 1.0, 0.0, 0.0, nil, false);
end

function SetSoundChecks(SoundName)
	if (SoundName == "(None)") then
		chkNone:SetChecked(true);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Engage") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(true);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Woohoo!!!") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(true);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Hallelujah") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(true);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Alrighty") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(true);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Come On") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(true);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Aooga") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(true);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Anxious") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(true);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Reload") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(true);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Yell") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(true);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Bummer") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(true);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Coocoo") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(true);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Dammit") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(true);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Aye Caramba") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(true);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Problem") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(true);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Ooga") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(true);
		chkBringDead:SetChecked(false);
	elseif (SoundName == "Bring Dead") then
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(true);
	else
		chkNone:SetChecked(false);
		chkEngage:SetChecked(false);
		chkWoohoo:SetChecked(false);
		chkHallelujah:SetChecked(false);
		chkAlrighty:SetChecked(false);
		chkComeon:SetChecked(false);
		chkAooga:SetChecked(false);
		chkAnxious:SetChecked(false);
		chkReload:SetChecked(false);
		chkYell:SetChecked(false);
		chkBummer:SetChecked(false);
		chkCoocoo:SetChecked(false);
		chkDammit:SetChecked(false);
		chkAyecaramba:SetChecked(false);
		chkProblem:SetChecked(false);
		chkOoga:SetChecked(false);
		chkBringDead:SetChecked(false);
	end
	cmbSounds:Show();
end

function chkNone_OnClick()
	SetSound("(None)");
end

function chkEngage_OnClick()
	SetSound("Engage");
end

function chkWoohoo_OnClick()
	SetSound("Woohoo!!!");
end

function chkHallelujah_OnClick()
	SetSound("Hallelujah");
end

function chkAlrighty_OnClick()
	SetSound("Alrighty");
end

function chkComeon_OnClick()
	SetSound("Come On");
end

function chkAooga_OnClick()
	SetSound("Aooga");
end

function chkAnxious_OnClick()
	SetSound("Anxious");
end

function chkReload_OnClick()
	SetSound("Reload");
end

function chkYell_OnClick()
	SetSound("Yell");
end

function chkBummer_OnClick()
	SetSound("Bummer");
end

function chkCoocoo_OnClick()
	SetSound("Coocoo");
end

function chkDammit_OnClick()
	SetSound("Dammit");
end

function chkAyecaramba_OnClick()
	SetSound("Aye Caramba");
end

function chkProblem_OnClick()
	SetSound("Problem");
end

function chkOoga_OnClick()
	SetSound("Ooga");
end

function chkBringDead_OnClick()
	SetSound("Bring Dead");
end

function TestSound(SoundName)
	local SoundFilename
	if (SoundName == "(None)") then
		SoundFilename = "";
	elseif (SoundName == "Engage") then
		SoundFilename = "startrek-tng-engage.wav";
	elseif (SoundName == "Woohoo!!!") then
		SoundFilename = "WOOHOO.WAV";
	elseif (SoundName == "Hallelujah") then
		SoundFilename = "HALLELUJ.WAV";
	elseif (SoundName == "Alrighty") then
		SoundFilename = "ALRIGHTY.WAV";
	elseif (SoundName == "Come On") then
		SoundFilename = "come-on-you-can-do-it.wav";
	elseif (SoundName == "Aooga") then
		SoundFilename = "AOOGA.WAV";
	elseif (SoundName == "Anxious") then
		SoundFilename = "ANXIOUS.WAV";
	elseif (SoundName == "Reload") then
		SoundFilename = "gun-reload-1.wav";
	elseif (SoundName == "Yell") then
		SoundFilename = "WilhelmScream.mp3";
	elseif (SoundName == "Bummer") then
		SoundFilename = "BUMMER.WAV";
	elseif (SoundName == "Coocoo") then
		SoundFilename = "birds_kuku.wav";
	elseif (SoundName == "Dammit") then
		SoundFilename = "damn-it.wav";
	elseif (SoundName == "Aye Caramba") then
		SoundFilename = "bart-aycaramba.wav";
	elseif (SoundName == "Problem") then
		SoundFilename = "APOLLO03.WAV";
	elseif (SoundName == "Ooga") then
		SoundFilename = "OOGA.WAV";
	elseif (SoundName == "Bring Dead") then
		SoundFilename = "BRNGDEAD.WAV";
	else
		SoundFilename = "";
	end
	if (SoundFilename ~= "") then
		PlaySoundFile(SoundPath..SoundFilename);
	end
end

function btnEngage_OnClick()
	TestSound("Engage");	
end

function btnWoohoo_OnClick()
	TestSound("Woohoo!!!");
end

function btnHallelujah_OnClick()
	TestSound("Hallelujah");
end

function btnAlrighty_OnClick()
	TestSound("Alrighty");
end

function btnComeon_OnClick()
	TestSound("Come On");
end

function btnAooga_OnClick()
	TestSound("Aooga");
end

function btnAnxious_OnClick()
	TestSound("Anxious");
end

function btnReload_OnClick()
	TestSound("Reload");
end

function btnYell_OnClick()
	TestSound("Yell");
end

function btnBummer_OnClick()
	TestSound("Bummer");
end

function btnCoocoo_OnClick()
	TestSound("Coocoo");
end

function btnDammit_OnClick()
	TestSound("Dammit");
end

function btnAyecaramba_OnClick()
	TestSound("Aye Caramba");
end

function btnProblem_OnClick()
	TestSound("Problem");
end

function btnOoga_OnClick()
	TestSound("Ooga");
end

function btnBringDead_OnClick()
	TestSound("Bring Dead");
end

function chkFWReady_PostClick()
	PriestFriendVars.FWReadyText = chkFWReady:GetChecked();
end

function chkFWFaded_PostClick()
	PriestFriendVars.FWFadedText = chkFWFaded:GetChecked();
end

function chkFWCast_PostClick()
	PriestFriendVars.FWCastText = chkFWCast:GetChecked();
end

function chkInnerFire_PostClick()
	PriestFriendVars.InnerFireText = chkInnerFire:GetChecked();
end

function chkFortitude_PostClick()
	PriestFriendVars.FortitudeText = chkFortitude:GetChecked();
end

function chkShadowProtection_PostClick()
	PriestFriendVars.ShadowProtectionText = chkShadowProtection:GetChecked();
end

function chkDivineSpirit_PostClick()
	PriestFriendVars.DivineSpiritText = chkDivineSpirit:GetChecked();
end

function chkVampiricEmbrace_PostClick()
	PriestFriendVars.VampiricEmbraceText = chkVampiricEmbrace:GetChecked();
end

function chkPowerInfusion_PostClick()
	PriestFriendVars.PIText = chkPowerInfusion:GetChecked();
end

function chkRenewedHope_PostClick()
	PriestFriendVars.RHText = chkRenewedHope:GetChecked();
end

function chkDisease_PostClick()
	PriestFriendVars.DiseaseText = chkDisease:GetChecked();
end

function chkMagic_PostClick()
	PriestFriendVars.MagicText = chkMagic:GetChecked();
end

function chkShackleBreak_PostClick()
	PriestFriendVars.ShackleBreakText = chkShackleBreak:GetChecked();
end

function chkOtherShackleBreak_PostClick()
	PriestFriendVars.OtherShackleBreakText = chkOtherShackleBreak:GetChecked();
end

function chkInnerFireNag_PostClick()
	PriestFriendVars.InnerFireNag = chkInnerFireNag:GetChecked();
end

function chkFortitudeNag_PostClick()
	PriestFriendVars.FortitudeNag = chkFortitudeNag:GetChecked();
end

function chkShadowProtectionNag_PostClick()
	PriestFriendVars.ShadowProtectionNag = chkShadowProtectionNag:GetChecked();
end

function chkDivineSpiritNag_PostClick()
	PriestFriendVars.DivineSpiritNag = chkDivineSpiritNag:GetChecked();
end

function chkVampiricEmbraceNag_PostClick()
	PriestFriendVars.VampiricEmbraceNag = chkVampiricEmbraceNag:GetChecked();
end

function chkPowerInfusionNag_PostClick()
	PriestFriendVars.PINag = chkPowerInfusionNag:GetChecked();
end

function chkRenewedHopeNag_PostClick()
	PriestFriendVars.RHNag = chkRenewedHopeNag:GetChecked();
end

function sldSacredCandles_OnValueChanged()
	if (sldSacredCandles:GetValue()) then
		PriestFriendVars.SacredCandleText = sldSacredCandles:GetValue();
		lblValueSacredCandles:SetText(PriestFriendVars.SacredCandleText);
	end
end

function sldHolyCandles_OnValueChanged()
	if (sldHolyCandles:GetValue()) then
		PriestFriendVars.HolyCandleText = sldHolyCandles:GetValue();
		lblValueHolyCandles:SetText(PriestFriendVars.HolyCandleText);
	end
end

function sldDevoutCandles_OnValueChanged()
	if (sldDevoutCandles:GetValue()) then
		PriestFriendVars.DevoutCandleText = sldDevoutCandles:GetValue();
		lblValueDevoutCandles:SetText(PriestFriendVars.DevoutCandleText);
	end
end

function sldNagInterval_OnValueChanged()
	if (sldNagInterval:GetValue()) then
		PriestFriendVars.NagIntervalText = sldNagInterval:GetValue();
		lblValueNagInterval:SetText(PriestFriendVars.NagIntervalText);
	end
end

function sldNagInterval_OnMouseWheel(arg1)
	if (PriestFriendVars.NagIntervalText) then
		local sliderMin, sliderMax = sldNagInterval:GetMinMaxValues()
		if ((sliderMin <= PriestFriendVars.NagIntervalText+arg1) and (PriestFriendVars.NagIntervalText+arg1 <= sliderMax)) then
			NagIntervalText = PriestFriendVars.NagIntervalText+arg1;
			lblValueNagInterval:SetText(PriestFriendVars.NagIntervalText);
			sldNagInterval:SetValue(PriestFriendVars.NagIntervalText);
		end
	end
end

function sldHolyCandles_OnMouseWheel(arg1)
	if (PriestFriendVars.HolyCandleText) then
		local sliderMin, sliderMax = sldHolyCandles:GetMinMaxValues()
		if ((sliderMin <= PriestFriendVars.HolyCandleText+arg1) and (PriestFriendVars.HolyCandleText+arg1 <= sliderMax)) then
			PriestFriendVars.HolyCandleText = PriestFriendVars.HolyCandleText+arg1;
			lblValueHolyCandles:SetText(PriestFriendVars.HolyCandleText);
			sldHolyCandles:SetValue(PriestFriendVars.HolyCandleText);
		end
	end
end

function sldDevoutCandles_OnMouseWheel(arg1)
	if (PriestFriendVars.DevoutCandleText) then
		local sliderMin, sliderMax = sldDevoutCandles:GetMinMaxValues()
		if ((sliderMin <= PriestFriendVars.DevoutCandleText+arg1) and (PriestFriendVars.DevoutCandleText+arg1 <= sliderMax)) then
			PriestFriendVars.DevoutCandleText = PriestFriendVars.DevoutCandleText+arg1;
			lblValueDevoutCandles:SetText(PriestFriendVars.DevoutCandleText);
			sldDevoutCandles:SetValue(PriestFriendVars.DevoutCandleText);
		end
	end
end

function sldSacredCandles_OnMouseWheel(arg1)
	if (PriestFriendVars.SacredCandleText) then
		local sliderMin, sliderMax = sldSacredCandles:GetMinMaxValues()
		if ((sliderMin <= PriestFriendVars.SacredCandleText+arg1) and (PriestFriendVars.SacredCandleText+arg1 <= sliderMax)) then
			PriestFriendVars.SacredCandleText = PriestFriendVars.SacredCandleText+arg1;
			lblValueSacredCandles:SetText(PriestFriendVars.SacredCandleText);
			sldSacredCandles:SetValue(PriestFriendVars.SacredCandleText);
		end
	end
end

function chkMountSay_PostClick()
	PriestFriendVars.MountSayText = chkMountSay:GetChecked();
end

function chkRezSay_PostClick()
	PriestFriendVars.RezSayText = chkRezSay:GetChecked();
end

function chkRezWhisper_PostClick()
	PriestFriendVars.RezWhisperText = chkRezWhisper:GetChecked();
end

function chkRezParty_PostClick()
	PriestFriendVars.RezPartyText = chkRezParty:GetChecked();
end

function chkMCSay_PostClick()
	PriestFriendVars.MCSayText = chkMCSay:GetChecked();
end

function chkShackleSay_PostClick()
	PriestFriendVars.ShackleSayText = chkShackleSay:GetChecked();
end

function chkMountParty_PostClick()
	PriestFriendVars.MountPartyText = chkMountParty:GetChecked();
end

function chkMCParty_PostClick()
	PriestFriendVars.MCPartyText = chkMCParty:GetChecked();
end

function chkShackleParty_PostClick()
	PriestFriendVars.ShacklePartyText = chkShackleParty:GetChecked();
end

function chkNagCombat_PostClick()
	PriestFriendVars.NagDuringCombat = chkNagCombat:GetChecked();
end

function chkDisableNag_PostClick()
	PriestFriendVars.DisableNag = chkDisableNag:GetChecked();
end

function chkOnlyNagInInstances_PostClick()
	PriestFriendVars.OnlyNagInInstances = chkOnlyNagInInstances:GetChecked();
end

function chkIgnorePets_PostClick()
	PriestFriendVars.IgnorePets = chkIgnorePets:GetChecked();
end
