# TrinketICD
<p align="left">
  <img src="http://i.imgur.com/WEZraYX.png" width="150"/>
  <img src="http://i.imgur.com/lak1el8.png" width="195"/>
  <img src="http://i.imgur.com/vjdNdT4.png" width="335"/>
  <img src="http://i.imgur.com/0X2b3ZP.png" width="150"/>
</p>

TrinketICD is a WotLK AddOn to display your item proc(s) ICD (internal cooldown). The frame is movable and scalable with your mousewheel.

It lets you choose the icon, ICD value and auras you want the addon to check. You may also add a small H in order to make a difference between two similar trinkets with one being the heroic version of the other.   
Once activated, the debug mode will print all your buffs with more information (buff name, icon name, buff ID) whenever you gain or lose one. This can be handy in order to config the AddOn, as you won't even need to check that specific info on a database.
