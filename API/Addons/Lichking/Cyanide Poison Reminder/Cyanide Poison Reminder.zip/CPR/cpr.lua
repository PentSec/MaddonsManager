local frame = CreateFrame("Frame");
frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");

local lastWarned =  GetTime();
-- we could also add a color for each command and it's description
local cmdListFormat = '|cffffcc00%s|r';
local soundListFormat = '|cff32cd32%s|r';
local valueDisplayFormat = '|cff00ff00%s|r';
local cmdList = {
  [1] = { name = 'test', descr = 'see how a warning looks like' },
  [2] = { name = 'et', descr = '"expire timer", set the expire time, in minutes, left on poison, before a warning occurs' },
  [3] = { name = 'timer', descr = 'set the interval, in minutes, at which you are warned you have no poison' },
  [4] = { name = 'on', descr = 'enable warning' },
  [5] = { name = 'off', descr = 'disable warning' },
  [6] = { name = 'wson', descr = 'enable warning sound' },
  [7] = { name = 'wsoff', descr = 'disable warning sound ( only warning text will popup )' },
  [8] = { name = 'wsset', descr = 'set a warning sound from a list of sounds' },
  [9] = { name = 'wsli', descr = 'listen to a warning sound from a list of sounds' },
};
local warnSoundList = {
  [1] =  { name = "Raid Warn",   path = "Sound\\interface\\RaidWarning.wav" },
  [2] =  { name = "Moo",         path = "Sound\\Spells\\PolyMorphCow.wav" },
  [3] =  { name = "Moo2",        path = "Sound\\Creature\\Cow\\CowDeath.wav" },
  [4] =  { name = "Ta-Da",       path = "Sound\\Spells\\PVPFlagTaken.wav" },
  [5] =  { name = "Tadpole",     path = "Sound\\Creature\\BabyMurloc\\BabyMurlocA.wav" },
  [6] =  { name = "Yahh",        path = "Sound\\Character\\Human\\MaleNPC\\HumanMalePirateHeavy\\HumanMalePirateHeavyAggro.wav" },
  [7] =  { name = "Murmur",      path = "Sound\\Creature\\Murmur\\MurmurSpawn.wav" },
  [8] =  { name = "Turkey",      path = "Sound\\Creature\\turkey\\TurkeyAttackA.wav" },
  [9] =  { name = "Klunk",       path = "Sound\\Doodad\\ArcaneCrystalOpen.wav" },
  [10] = { name = "Gong",        path = "Sound\\Doodad\\G_GongTroll01.wav" },
  [11] = { name = "Gong2",       path = "Sound\\Doodad\\BellTollHorde.wav" },
  [12] = { name = "Drum",        path = "Sound\\Doodad\\BellTollTribal.wav" },
  [13] = { name = "Ding Ding",   path = "Sound\\Doodad\\BoatDockedWarning.wav" },
  [14] = { name = "Boom",        path = "Sound\\Doodad\\Cannon01_BlastA.wav" },
  [15] = { name = "Klank",       path = "Sound\\Doodad\\DireMaulCrystalGeneratorOpen.wav" },
  [16] = { name = "Thunk",       path = "Sound\\Item\\Weapons\\Shields\\MetalShieldBlock2.wav" },
  [17] = { name = "Poison",       path = "Sound\\Creature\\HydrossTheUnstable_Corrupt\\COIL_HydroCorr_SwtchCorrpt01.wav" },
};

local playerClass, englishClass = UnitClass("player");

-- assuming savedvariables have been loaded :/
if cprexp == nil then
    cprexp = 5;
end

if cprTimer == nil then
    cprTimer = 1;
end

if cprTimerS == nil then
    cprTimerS = cprTimer * 60;
end

if expmath == nil then
    expmath = cprexp * 60000 ;
end

if warnSound == nil then
	warnSound = 17;
end

if warnSoundState == nil then
	warnSoundState = "off";
end

if ( englishClass == "ROGUE" and (UnitLevel("player")) > 19 and cprstatus == nil ) then
    cprstatus = "on";
else
    cprstatus = "off";
end

SLASH_CYANIDESLASH1, SLASH_CYANIDESLASH2 = '/cypr', '/cyanide';
local function handler(msg)
    local command, cprrest = msg:match("^(%S*)%s*(.-)$");
    if command == "et" then
		if( cprrest == "" ) then
			print ("Set the number of minutes left on poison before a warning occurs. Value must be between 1 and 59. Default=5, current=" .. cprexp);
			print ("Example: /cpr et 3");
		else
	        cprrest = tonumber( cprrest );
			if ( cprrest > 0 and cprrest < 60 ) then
				cprexp = cprrest;
				expmath = cprexp * 60000;
				print ("Expire timer has been set to " .. valueDisplay(cprexp));
			else
				print "Expire timer value must be between 1 and 59";
			end
		end
    elseif command == "timer" then
		if( cprrest == "" ) then
			print ("Set the inverval, in minutes, at which you are warned you have no poison. Value must be between 1 and 59. Default=1, current=" ..cprTimer);
			print ("Example: /cpr timer 3");
		else
	        cprrest = tonumber( cprrest );
			if ( cprrest > 0 and cprrest < 60 ) then
				cprTimer = cprrest;
				cprTimerS = cprTimer * 60;
				print ("Timer has been set to " .. valueDisplay(cprTimer));
			else
				print "Timer value must be between 1 and 59";
			end
		end
    -- test case
    elseif command == 'test' then
        SoundHandle( true );
        UIErrorsFrame:AddMessage("Mainhand Poison Running Out   ", 1.0, 1.0, 0.5, 5.0);
        UIErrorsFrame:AddMessage("Offhand Poison Running Out   ", 1.0, 1.0, 0.5, 5.0);
    -- on
    elseif command == 'on' then
        cprstatus = "on";
        print ("Warning enabled");
    -- off
    elseif command == 'off' then
        cprstatus ="off";
        print ("Warning disabled");
    -- status for variables
    elseif command == 'status' then
        print ("CPR status = " .. valueDisplay(cprstatus));
        print ("CPR expire timer = " .. valueDisplay(GetDuration(expmath)));
        print ("CPR timer = " .. valueDisplay(GetDuration(cprTimerS*1000)));
        print ("Warning sound state = " .. valueDisplay(warnSoundState));
        print ("Warning sound = " .. warnSound..' - '..valueDisplay(getWSLNameByIndex(warnSound)));
    -- turn warning sound on
    elseif command == 'wson' then
		warnSoundState = "on";
		print("Warning sound has been set to " .. valueDisplay(warnSoundState));
    -- turn warning sound off
    elseif command == 'wsoff' then
		warnSoundState = "off";
		print("Warning sound has been set to " .. valueDisplay(warnSoundState));
    -- warning sound selector
    elseif command == 'wsset' then
		sndListSize = getn( warnSoundList );
		if( cprrest == "" ) then
			displayListOfSounds();
			print( 'Select a number between 1 and '..sndListSize );
		else
			cprrest = tonumber( cprrest );
			if( cprrest > 0 and cprrest <= sndListSize ) then
				warnSound = cprrest;
				print( 'Setting warning sound to: '..warnSound..' - '..string.format( soundListFormat, getWSLNameByIndex(warnSound) ) );
			else
				print( 'The value must be between 1 and '..sndListSize );
			end
		end
    -- warning sound selector
    elseif command == 'wsli' then
		sndListSize = getn( warnSoundList );
		if( cprrest == "" ) then
			displayListOfSounds();
			print( 'Select a number between 1 and '..sndListSize );
		else
			cprrest = tonumber( cprrest );
			if( cprrest > 0 and cprrest <= sndListSize ) then
				print( 'Listening to: '..cprrest..' - '..string.format( soundListFormat, getWSLNameByIndex(cprrest) ) );
				PlaySoundFile( getWSLPathByIndex( cprrest ) );
			else
				print( 'The value must be between 1 and '..sndListSize );
			end
		end
    else
		-- getting a shorter list of commands
		cmdShortList = "";
		cmdListSize = getn( cmdList );
        for i,cmd in ipairs(cmdList) do
			if( i < cmdListSize ) then
				cmdShortList = cmdShortList..string.format( cmdListFormat, cmd.name ).." | ";
			else
				cmdShortList = cmdShortList..string.format( cmdListFormat, cmd.name );
			end
        end
        print("Options: /cypr ( "..cmdShortList.." ) ");
        
        -- printing a detailed command list
        print("Explained commands:");
        for i,cmd in ipairs(cmdList) do
			print( string.format( cmdListFormat, cmd.name )..' - '..cmd.descr );
        end
    end
end

SlashCmdList["CYANIDESLASH"] = handler;

function CPR_OnEvent()
    cprtaxi = UnitOnTaxi("player");    
    doifish = OffhandHasWeapon();
    local hasMainHandEnchant, mainHandExpiration, mainHandCharges, hasOffHandEnchant, offHandExpiration, offHandCharges = GetWeaponEnchantInfo()
    if (lastWarned + cprTimerS < GetTime() and cprstatus ~= "off" and IsResting() == nil and cprtaxi == nil and doifish ~= nill) then
        lastWarned = GetTime();
        if hasMainHandEnchant then
            if (mainHandExpiration < expmath) then
                SoundHandle( false );
                UIErrorsFrame:AddMessage("Mainhand Poison Running Out   ", 1.0, 1.0, 0.5, 5.0);
                print ("Mainhand poison running out");
            end
        else
			  SoundHandle( false );
              UIErrorsFrame:AddMessage("No Mainhand Poison", 1.0, 1.0, 0.5, 5.0);
        end
    
        if hasOffHandEnchant then
            if (offHandExpiration < expmath) then
                SoundHandle( false );
                UIErrorsFrame:AddMessage("Offhand Poison Running Out", 1.0, 1.0, 0.5, 5.0);
                print ("Offhand poison running out");
            end       
        else
				SoundHandle( false );
                UIErrorsFrame:AddMessage("No Offhand Poison", 1.0, 1.0, 0.5, 5.0);
        end  
    end 

end

-- playing sound according to the settings
function SoundHandle( isTestCmd )
	if( isTestCmd ) then
		PlaySoundFile( getWSLPathByIndex(warnSound) );
	else
		if ( warnSoundState == "on" ) then
			PlaySoundFile( getWSLPathByIndex(warnSound) );
		end
	end
end

-- displaying value according to format
function valueDisplay( val )
	return string.format( valueDisplayFormat, val );
end

-- display list of sounds available
function displayListOfSounds()
	print('Displaying a list of warning sounds:');
	for i,snd in ipairs(warnSoundList) do
		print( i..' - '..string.format( soundListFormat, snd.name ) )
	end
	print('----------------------------------------');
end

-- getting warning sound name according to an index from warnSoundList table
function getWSLNameByIndex( index ) 
	return warnSoundList[index].name;
end

-- getting warning sound path according to an index from warnSoundList table
function getWSLPathByIndex( index ) 
	return warnSoundList[index].path;
end

-- returns a combination of hours/minutes/seconds from a given number of miliseconds
function GetDuration( time )
	time = math.floor( time / 1000 );
	
	-- treating something that is returned as 0ms from GetBattlefieldEstimatedWaitTime
	-- when you join a BG for which there are no instances existing
	-- not 100% correct
	if( time == 0 ) then
		return "< 1 minute"
	end
	
	maxMinutes = 60
	maxHours = 3600
	seconds = time
	minutes = 0
	hours = 0
	
	if( time > maxMinutes - 1 and time < maxHours ) then
		minutes = math.floor( time / maxMinutes )
		seconds = time % maxMinutes
	elseif( time > maxHours - 1 ) then
		hours = math.floor( time / maxHours )
		remainder = time % maxHours
		minutes = math.floor( remainder / maxMinutes )
		seconds = remainder % maxMinutes
	end
	
	-- we return time in hours, minutes and seconds
	if( hours > 0 ) then
		return GetPlural( hours, "hour" ).." , "..GetPlural(  minutes, "minute" ).." , "..GetPlural(  seconds, "second" );
		
	elseif( minutes > 0 ) then -- we return time in minutes and seconds
		return GetPlural(  minutes, "minute" ).." , "..GetPlural(  seconds, "second" );
	else -- we return time in seconds
		return GetPlural(  seconds, "second" );
	end
		
end

-- returns the plural of a measuring unit according to the value
function GetPlural( value, unit )
	result = value.." "
	if( value > 1 or value == 0 ) then
		return result..unit..'s'
	end
	
	return result..unit
end

frame:SetScript("OnEvent", CPR_OnEvent);