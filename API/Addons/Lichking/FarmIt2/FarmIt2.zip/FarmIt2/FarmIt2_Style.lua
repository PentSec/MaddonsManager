﻿--------------------------------------------------------------------------------
--  BAR/BUTTON VISUAL STYLES
--
--  "Fonts/FRIZQT__.TTF"
--  "Fonts/ARIALN.TTF"
--------------------------------------------------------------------------------
if FI_DEBUG then print("FarmIt2_Style.lua loaded."); end

FI_STYLES = {};

-- default style, matches the stock wow interface
FI_STYLES["default"] = {
	["anchor"] = {
		["background"] = {
			texture = "Interface/PaperDoll/UI-Backpack-EmptySlot",
			color = {},
			alpha = 0.75,
		},
		["border"] = {
			texture = "",
			tile = true,
			size = 6,
			offset = 2,
			color = {},
			alpha = 1,
		},
		["text"] = {
			font = "Fonts/ARIALN.TTF",
			size = 13,
			flags = "",
			color = {1,1,1},
			alpha = 1,
		},
	},
	
	["button"] = {
		["background"] = {
			texture = "Interface/PaperDoll/UI-Backpack-EmptySlot",
			color = {},
			alpha = 0.75,
		},
		["border"] = {
			texture = "Interface/Buttons/UI-Quickslot2", --not a true border, this is an overlay
			tile = true,
			size = 6,
			offset = 2,
			alpha = 0.9,
		},
		["icon"] = {
			texture = "",
			color = {},
			alpha = 1,
		},
		["glow"] = {
			texture = "Interface/CHATFRAME/CHATFRAMEBACKGROUND",
			color = {1,1,0},
			alpha = 0.5,
		},
		["number"] = {
			font = "Fonts/ARIALN.TTF",
			size = 14,
			flags = "OUTLINE",
			color = {1,1,1},
			alpha = 1,
		},
		["text"] = {
			font = "Fonts/FRIZQT__.TTF",
			size = 18,
			flags = "",
			color = {0.9,0.9,0.3},
			alpha = 0.9,
		},
	},
}

--D:\Projects\WoW_Interface_art\Interface\CHATFRAME\ChatFrameBorder.blp
--

-- clean style, goes better with mods like Bartender
FI_STYLES["minimal"] = {
	["anchor"] = {
		["background"] = {
			texture = {"Interface/Tooltips/UI-Tooltip-Background"},
			color = {0,0,0},
			alpha = 0.5,
		},
		["border"] = {
			texture = "Interface/Tooltips/UI-Tooltip-Border",
			tile = true,
			size = 6,
			offset = 2,
			color = {},
			alpha = 0.9,
		},
		["text"] = {
			font = "Fonts/ARIALN.TTF",
			size = 13,
			flags = "",
			color = {1,1,1},
			alpha = 1,
		},
	},
	
	["button"] = {
		["background"] = {
			texture = {0,0,0},
			color = {},
			alpha = 0.66,
		},
		["border"] = {
			texture = "Interface/Tooltips/UI-Tooltip-Border",
			tile = true,
			size = 6,
			offset = 2,
			color = {},
			alpha = 0.9,
		},
		["icon"] = {
			texture = "",
			color = {},
			alpha = 1,
		},
		["glow"] = {
			texture = "Interface/CHATFRAME/CHATFRAMEBACKGROUND",
			color = {1,1,0},
			alpha = 0.5,
		},
		["number"] = {
			font = "Fonts/ARIALN.TTF",
			size = 14,
			flags = "OUTLINE",
			color = {1,1,1},
			alpha = 1,
		},
		["text"] = {
			font = "Fonts/FRIZQT__.TTF",
			size = 18,
			flags = "",
			color = {0.9,0.9,0.3},
			alpha = 0.9,
		},
	},
}
