﻿--------------------------------------------------------------------------------
--  TO DO:
--[[

A	GUI config panel!
A	Farming templates- DONE. Need to gather the rest of the item ID's for the built-in template categories.
A	Right-click interacts with actual inventory item. (For combining motes into primals.)

B	Add an item via chat link, etc. Editbox that would feed a text (item name) call to getiteminfo() ?
B	Templates enhancement- store the required profession skill level along with items, then display it in the tooltip.
	Then check the current skill level of the player in their profession related to the item, 
	and highlight the item in red if their skill level is too low to gather it.

C	Set a time marker to track farming "sessions"
C	Basic money tracking during a "session" (money looted).
C	Calculate estimated drop rates for tracked items.
C	Work with auctioneer/auctionator to calculate the AH value of tracked items.

D	Profiles.
D	Support for ButtonFacade

E	Respawn timer.

]]--
--------------------------------------------------------------------------------
if FI_DEBUG then print("FarmIt2.lua loaded."); end


--------------------------------------------------------------------------------
--  EVENT HANDLES
--------------------------------------------------------------------------------
function FI_OnLoad(self)
	if FI_DEBUG then print("OnLoad() fired."); end

	self:RegisterEvent("ADDON_LOADED");
	self:RegisterEvent("BAG_UPDATE");

	SlashCmdList["farmit"] = FI_Command;
	SLASH_farmit1 = "/farmit";

	StaticPopupDialogs["RELOAD"] = {
		text = "This action will reload your game interface. Are you sure?",
		button1 = "RELOAD",
		button2 = "Cancel",
		OnAccept = function()
			ReloadUI();
		end,
		timeout = 0,
		whileDead = true,
		hideOnEscape = true,
	}

	StaticPopupDialogs["RESET"] = {
		text = "This will reset FarmIt to it's default settings, and reload your game interface. Are you sure?",
		button1 = "RESET",
		button2 = "Cancel",
		OnAccept = function()
			FI_Reset();
		end,
		timeout = 0,
		whileDead = true,
		hideOnEscape = true,
		showAlert = true,
	}

	StaticPopupDialogs["DELETE"] = {
		text = "NOTE: Removing a bar destroys it completely, and requires an interface reload. "..
			"If you don't want to do that right now, try hiding the bar instead using:  /farmit toggle %s",
		button1 = "DELETE",
		button2 = "Cancel",
		OnAccept = function()
		end,
		timeout = 0,
		whileDead = true,
		hideOnEscape = true,
	}
end

function FI_OnEvent(self, event, ...)
	local arg = ...;

	if FI_DEBUG then
		if (type(arg) == "table") then 
			print("OnEvent() fired: "..event); table.dump(arg);
		else
			print("OnEvent() fired: "..event.." "..arg);
		end
	end

	if (event == "ADDON_LOADED") and (arg == "FarmIt2") then
		self:UnregisterEvent("ADDON_LOADED");
		
		FI_LOADING = true;
		
		FI_Init();
		FI_Frames();
		FI_Load();
		
		FI_LOADING = false;
	end

	if (event == "BAG_UPDATE") then
		FI_Update(arg);
	end
end


--------------------------------------------------------------------------------
--  DISPATCHER
--------------------------------------------------------------------------------
function FI_Command( input, editbox )
	--------------------------------------------------
	--  PARSE INPUT
	--------------------------------------------------
	local cmd, arg, val, val2, val3 = strsplit(' ', input);

	--------------------------------------------------
	--  COMMANDS
	--------------------------------------------------
	cmd = strlower(cmd);
	if (cmd == "help") then
		InterfaceOptionsFrame_OpenToCategory(FI_CONFIG.Pages[1]);

	elseif (cmd == "options") then
		InterfaceOptionsFrame_OpenToCategory(FI_CONFIG.Panel);

	elseif (cmd == "reset") then
		StaticPopup_Show("RESET");

	elseif (cmd == "rebuild") then --for ninjas pwnly!!!
		FI_DB.rebuild("all");
		ReloadUI();

	elseif (cmd == "toggle") then
		if arg then
			local bar = tonumber(arg);
			FI_Show( FI_SVPC_DATA.Groups[bar]["id"] );
		else
			FI_Show();
		end

	elseif (cmd == "lock") then
		local lockmsg = "locked";
		if arg then
			local bar = tonumber(arg);
			FI_SVPC_DATA.Groups[bar]["move"] = FI_Toggle( FI_SVPC_DATA.Groups[bar]["move"] );
			
			if FI_SVPC_DATA.Groups[bar]["move"] then lockmsg = "unlocked"; end
			DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Bar "..bar.." position "..lockmsg..".");
		else
			FI_SVPC_CONFIG.move = FI_Toggle( FI_SVPC_CONFIG.move );
			
			if FI_SVPC_CONFIG.move then lockmsg = "unlocked"; end
			DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Addon position "..lockmsg..".");
		end

	elseif (cmd == "scale") then
		if arg then
			if val then
				local bar = tonumber(val);
				FI_Scale( tonumber(arg), FI_SVPC_DATA.Groups[bar]["id"] );
			else
				FI_Scale( tonumber(arg) );
			end
		end

	elseif (cmd == "alpha") then
		if arg then
			if val then
				local bar = tonumber(val);
				FI_Alpha( tonumber(arg), FI_SVPC_DATA.Groups[bar]["id"] );
			else
				FI_Alpha( tonumber(arg) );
			end
		end

	elseif (cmd == "notify") then
		if arg then
			FI_ToggleNotify( strlower(arg) )
		end
	
	elseif (cmd == "group") then
		if arg then
			if (strlower(arg) == "remove") then
				if val then
					local bar = tonumber(val);
					-- pass gid to popup callback
					StaticPopupDialogs["DELETE"].OnAccept = function() FI_Group("remove", FI_SVPC_DATA.Groups[bar]["id"] ); end
					-- show dialog
					StaticPopup_Show("DELETE", bar);
				else
					DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  You must include the bar number when removing a group.");
				end
			elseif (strlower(arg) == "add") then
				FI_Group("add");
			end
		end

	elseif (cmd == "size") then
		if arg then
			local bar = tonumber(arg);
			if val then
				FI_Group("size", FI_SVPC_DATA.Groups[bar]["id"], tonumber(val) );
			else
				DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Please specify the number of buttons you want the bar to have.");
			end
		end

	elseif (cmd == "grow") then
		if arg then
			local bar = tonumber(arg);
			if val then
				FI_Group("grow", FI_SVPC_DATA.Groups[bar]["id"], strupper(val) );
			else
				DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Please choose a direction for the bar to grow:  U,D,L,R");
			end
		end

	elseif (cmd == "style") then
		if arg then
			FI_Style( strlower(arg) );
		end

	elseif (cmd == "tpl") then
		if arg then
			FI_Template( strlower(arg), val, val2, val3 );
		end

	else
		-- no valid options given, show help prompt
		DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Basic commands:\n"..
			"    help\n"..
			"        Shows the help window. (Includes a full list of commands.)\n"..
			"    options\n"..
			"        Opens the configuration panel.\n"..
			"    reset\n"..
			"        Resets the addon to default settings."
		);
		
	end
end
