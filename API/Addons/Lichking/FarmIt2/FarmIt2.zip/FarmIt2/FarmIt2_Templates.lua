﻿--------------------------------------------------------------------------------
--  ITEM SETS
--
--  These are the default item templates that FarmIt includes.
--  Items are grouped by the part of the game in which they are obtained.
--  To add your own: set up a bar in-game, then use the following commands:
--    /farmit tpl list
--    /farmit tpl save {bar#} name
--    /farmit tpl load {bar#} name
--    /farmit tpl delete name
--
--  Note: To simplify input parsing, spaces are not allowed in custom template names.
--
--[[
["Category"] = {
	-- primary professions
	["Alchemy"] = {},
	["Blacksmithing"] = {},
	["Enchanting"] = {},
	["Engineering"] = {},
	["Herbalism"] = {},
	["Inscription"] = {},
	["Jewelcrafting"] = {},
	["Leatherworking"] = {},
	["Mining"] = {},
	["Skinning"] = {},
	["Tailoring"] = {},
	-- secondary professions
	["Archaeology"] = {},
	["Cooking"] = {},
	["FirstAid"] = {},
	["Fishing"] = {},
	-- other
	["Elemental"] = {},
	["Misc"] = {},
}
]]
--------------------------------------------------------------------------------
if FI_DEBUG then print("FarmIt2_Templates.lua loaded."); end


-- categories
FI_TPL = {
	["WOW"] = {},
	["TBC"] = {},
	["WOTLK"] = {},
	["CATA"] = {},
}

-- Mining
FI_TPL.WOW.Mining = {2770,2771,2775,2772,2776,3858,7911,11370,10620}
FI_TPL.TBC.Mining = {23424,23425,23426,23427}
FI_TPL.WOTLK.Mining = {36909,36912,36910}
FI_TPL.CATA.Mining = {53038,52184,52185,52183}

-- Herbalism
FI_TPL.WOW.Herbalism = {2447,765,785,2449,2450,2452,2453,3820,3369,3355,3356,3357,3818,3821,3358,3819}
FI_TPL.WOW.Herbalism2 = {8153,4625,8831,8836,8838,8839,8845,8846,13464,13463,13465,13466,13467,13468,19726}
FI_TPL.TBC.Herbalism = {22785,22786,22789,22787,22790,22791,22792,22793,22794}
FI_TPL.WOTLK.Herbalism = {36901,37921,36904,36907,36903,36905,36906,36908}
FI_TPL.CATA.Herbalism = {52983,52984,52985,52986,52988,52987,52989}

-- Skinning
FI_TPL.WOW.Skinning = {2934,2318,783,5082,2319,4232,4234,4235,8167,4304,8169,8154,8165,15415,15412,15416,8170,8171}
FI_TPL.WOW.Skinning2 = {15419,15417,15408,20500,20501,20498,15414,29547,29539,25700,19767,19768,25699,17012,15410}
FI_TPL.TBC.Skinning = {25649,21887,25708,25707}
FI_TPL.WOTLK.Skinning = {33567,33568,38557,38561,38558,44128}
FI_TPL.CATA.Skinning = {52977,52976,52979,52982,52980}


-- More templates to come in future updates...