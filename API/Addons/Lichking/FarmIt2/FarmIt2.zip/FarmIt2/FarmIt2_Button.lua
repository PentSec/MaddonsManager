﻿--------------------------------------------------------------------------------
--  BUTTON RELATED CODE
--
--[[
	The goal of this code is to have the item buttons be autonomous units.
	We want the mod to be as flexible as possible.

	inherits="ItemButtonTemplate"
]]--
--------------------------------------------------------------------------------
if FI_DEBUG then print("FarmIt2_Button.lua loaded."); end


--------------------------------------------------------------------------------
--  TOOLTIP
--------------------------------------------------------------------------------
function FI_Tooltip( self )
	local bid = FI_FrameToID( self:GetName() );
	if FI_DEBUG then print("You hovered button ID: "..bid); end

	local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
	
	if button.item then
		GameTooltip:SetOwner(self, "ANCHOR_TOPLEFT");

		local sName, sLink, iQuality, iLevel, iMinLevel, sType, sSubType, iStackSize = GetItemInfo(button.item);
		if sLink then
			GameTooltip:SetHyperlink(sLink);
			GameTooltip:AddLine("\n"..sType.." ("..sSubType..")");
			GameTooltip:AddLine("Item Level "..iLevel, 1,1,1);
			GameTooltip:AddLine("Stack Size:  "..iStackSize, 1,1,1);
		end
		GameTooltip:AddLine("Item ID:  "..button.item, 1,1,1);
		GameTooltip:AddLine("Button ID:  "..button.id, 1,1,1);
		GameTooltip:AddLine("Bank Included:  "..strupper(tostring(button.bank)));
		
		GameTooltip:Show();
	end
end


--------------------------------------------------------------------------------
--  MOUSE CLICK!
--------------------------------------------------------------------------------
function FI_Click( self, click, down )
	local f_name = self:GetName();
	if FI_DEBUG then print("You CLICKED the "..click.." ("..tostring(down)..") on frame: "..f_name); end

	local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = FI_FrameToID(f_name)}, true);

	if CursorHasItem() then
		------------------------------------------------------------
		-- NEW ITEM
		------------------------------------------------------------
		local itemType, itemID, itemLink = GetCursorInfo();
		if (itemType == "item") then
			-- save new item to button record
			FI_DB.update(FI_SVPC_DATA.Buttons, {id = button.id}, {item = itemID});
			-- apply data to slot
			FI_SetButton(button.id);
			-- clear item from cursor
			ClearCursor();
		end

	elseif (click == "LeftButton") then
		if IsShiftKeyDown() then
			------------------------------------------------------------
			-- INCLUDE BANK
			------------------------------------------------------------
			FI_ToggleBank(button.id);
		
		elseif IsControlKeyDown() then
			------------------------------------------------------------
			-- SET OBJECTIVE
			------------------------------------------------------------
			FI_EditObjective(button.id);
		
		elseif FI_SELECTED then
			------------------------------------------------------------
			-- MOVE
			------------------------------------------------------------
			if (button.id == FI_SELECTED) then
				-- cancel the selection (same slot was clicked)
				FI_Deselect();
			else
				FI_MoveItem(FI_SELECTED, button.id);
			end
			
		elseif button.item then
			------------------------------------------------------------
			-- SELECT ITEM
			------------------------------------------------------------
			FI_Select(button.id);
		end

	elseif (click == "RightButton") then
		if IsShiftKeyDown() then
			------------------------------------------------------------
			-- CLEAR SLOT
			------------------------------------------------------------
			if button.item then
				FI_ClearButton(button.id);
				PlaySound("gsTitleOptionOK");
			end

		else
			------------------------------------------------------------
			-- USE ITEM
			------------------------------------------------------------
			if button.item then
				-- Right-click "use" action on actual item is handled by SecureActionButton_OnClick()
				-- See FarmIt2_Button.xml, FI_ButtonFrames, and FI_SetButton
				local itemName, itemLink = GetItemInfo(button.item);
				if itemLink then
					DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Using "..itemLink);
				end
			end
		end
	end
	-- /mouse buttons
end

--------------------------------------------------------------------------------
--  ITEM BUTTON STUFFS
--------------------------------------------------------------------------------
function FI_SetButton( bid, newItem )
	-- update itemID before setting button elements
	if newItem then
		FI_ClearButton(bid);
		FI_DB.update(FI_SVPC_DATA.Buttons, {id = bid}, {item = newItem});
	end

	local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);

	if button.item then
		local f_name = "FI_Button_"..button.id;

		-- set secure template action
		local itemName = GetItemInfo(button.item);
		if itemName then
			_G[f_name]:SetAttribute("macrotext", "/use "..itemName);
		end
		
		-- set icon
		_G[f_name.."_Icon"]:SetTexture( GetItemIcon(button.item) );

		-- bank inclusion indicator
		if button.bank then
			-- yellowness (not to be confused with darkness, then redness, then whiteness)
			local bc = FI_SV_CONFIG.Bank.color;
			_G[f_name.."_Count"]:SetVertexColor(bc[1], bc[2], bc[3]);
		end
		
		-- set objective?
		if CursorHasItem() then
			-- we are in the middle of placing a new item, get rid of old objective
			FI_ClearObjective(button.id);
		elseif (button.objective > 0) then
			FI_SetObjective(button.id);
		end
		
		FI_UpdateButton(button.id);

		if FI_DEBUG then
			local itemName, itemLink = GetItemInfo(button.item);
			print( "FI_SetButton:  Button ID "..button.id.." set to "..itemLink );
		end
	end
end

function FI_ClearButton( bid )
	local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
	
	-- reset button data
	local i = FI_DB.find(FI_SVPC_DATA.Buttons, {id = button.id}, true);
	FI_SVPC_DATA.Buttons[i] = table.copy(FI_DEFAULTS.DB.Button);
	-- preserve the ID's
	FI_SVPC_DATA.Buttons[i]["id"] = button.id;
	FI_SVPC_DATA.Buttons[i]["group"] = button.group;

	FI_ClearObjective(button.id);

	-- reset graphical elements
	local f_name = "FI_Button_"..button.id;
	_G[f_name.."_Icon"]:SetTexture("");
	_G[f_name.."_Count"]:SetText(0);
	_G[f_name.."_Count"]:SetVertexColor(1,1,1);

	-- clear secure template action
	_G[f_name]:SetAttribute("macrotext", nil);

	if FI_SELECTED then
		FI_Deselect();
	end
end

function FI_Select( bid )
	-- copy to "clipboard"
	FI_SELECTED = bid;

	PlaySound("igAbilityIconPickup");

	-- selection indicator
	_G["FI_Button_"..FI_SELECTED.."_Glow"]:Show();

	if FI_DEBUG then print("Button ID #"..bid.." SELECTED for moving..."); end
end

-- pass true to disable sound
function FI_Deselect( mute )
	-- turn off selection indicator
	_G["FI_Button_"..FI_SELECTED.."_Glow"]:Hide();

	-- clear the "clipboard"
	FI_SELECTED = false;

	if not mute then
		PlaySound("igAbilityIconDrop");
	end
end

-- added in v2.0 beta2
function FI_MoveItem( bid1, bid2 )
	FI_MOVING = true;
	
	local source = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid1}, true);
	local target = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid2}, true);

	-- move the selected button data
	FI_DB.copy(FI_SVPC_DATA.Buttons, {id = source.id}, {id = target.id}); --preserves the primary key ("id" field)
	-- make sure the destination button keeps its *group* id
	FI_DB.update(FI_SVPC_DATA.Buttons, {id = target.id}, {group = target.group});
	-- load new button data in destination slot
	FI_SetButton(target.id);

	-- swapping contents with a populated button?
	if target.item then
		-- get table index of source button
		local index = FI_DB.find(FI_SVPC_DATA.Buttons, {id = source.id});

		-- copy target button over source
		FI_SVPC_DATA.Buttons[index] = table.copy(target);
		
		-- keep the original IDs so things dont get all discombobulated (technical term)
		FI_SVPC_DATA.Buttons[index]["id"] = source.id;
		FI_SVPC_DATA.Buttons[index]["group"] = source.group;
		
		-- make it so, number one.
		FI_SetButton(source.id);
	else
		-- clear the old slot
		FI_ClearButton(source.id);
	end
	
	FI_MOVING = false;
end

--------------------------------------------------------------------------------
--  BANK INVENTORY
--------------------------------------------------------------------------------
function FI_ToggleBank( bid )
	local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
	local f_name = "FI_Button_"..button.id;
	
	if button.item then
		-- change setting
		local newbank = FI_Toggle(button.bank);
		FI_DB.update(FI_SVPC_DATA.Buttons, {id = button.id}, {bank = newbank});

		-- refresh item count
		FI_UpdateButton(button.id);
		
		-- use banky color if true
		if newbank then
			_G[f_name.."_Count"]:SetVertexColor(1,1,0);
		else
			_G[f_name.."_Count"]:SetVertexColor(1,1,1);
		end
		
		PlaySound("TalentScreenClose");
		DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  ButtonID "..button.id..": Include Bank = "..tostring(newbank));
	end
end

--------------------------------------------------------------------------------
--  OBJECTIVE TRACKING
--------------------------------------------------------------------------------
function FI_Objective( bid, prevCount )
	local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
	local f_name = "FI_Button_"..button.id;
	
	-- color information
	local oc = FI_SV_CONFIG.Objective.color;
	local osc = FI_SV_CONFIG.Objective.color2; -- the color of success

	local debug_msg = "";
	if (button.count > button.objective) and (button.success == false) then
		------------------------------------------------------------
		-- SUCCESS!
		------------------------------------------------------------
		debug_msg = "especially GREATER THAN";

		-- change number color
		_G[f_name.."_Objective"]:SetVertexColor(osc[1], osc[2], osc[3]);

		-- objective success notification
		if FI_SV_CONFIG.Objective.notify and (button.success == false) then
			-- update notification flag
			FI_DB.update(FI_SVPC_DATA.Buttons, {id = button.id}, {success = true});

			local itemName, itemLink = GetItemInfo(button.item);
			if itemLink then
				local message = "Farming for "..itemLink.." complete! ("..button.objective.."/"..button.objective..")";
				FI_Notify(message, osc, "QUESTCOMPLETED");
			end
		end
	
	else
		------------------------------------------------------------
		-- OBJECTIVE PROGRESS
		------------------------------------------------------------
		local color;
		if (button.count < button.objective) then
			------------------------------------------------------------
			-- enforce default state of objective indicators
			-- (in case item count goes back down)
			------------------------------------------------------------
			debug_msg = "LESS THAN";
			color = oc;

			-- reset notification flag
			FI_DB.update(FI_SVPC_DATA.Buttons, {id = button.id}, {success = false});
			
			-- reset number color
			_G[f_name.."_Objective"]:SetVertexColor(oc[1], oc[2], oc[3]);
		else
			------------------------------------------------------------
			-- allow normal progress notifications after success
			------------------------------------------------------------
			debug_msg = "GREATER THAN";
			color = osc;
			
			-- enforce number color
			_G[f_name.."_Objective"]:SetVertexColor(osc[1], osc[2], osc[3]);
		end
		
		-- objective progress notification
		if FI_SV_CONFIG.Progress.notify and prevCount then
			if (button.count > prevCount) then
				local itemName, itemLink = GetItemInfo(button.item);
				if itemLink then
					local message = "Farming progress:  "..itemLink.." ("..button.count.."/"..button.objective..")";
					FI_Notify(message, color, nil, button.id);
				end
			end
		end
	end

	if FI_DEBUG then print("FI_Objective:  Item quantity "..button.count.." is "..debug_msg.." objective "..button.objective.." (BID "..button.id..")"); end
end

-- expects a button id, and (optionally) an editbox object
function FI_SetObjective( bid, editbox )
	local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
	
	if button.item then
		local prevCount = button.count;
		
		-- capture editbox input if present
		if editbox then
			local input = editbox:GetNumber();
			if FI_DEBUG then print("FI_SetObjective:  "..input.." ("..type(input)..") for ButtonID "..bid); end
			
			-- set new objective
			FI_DB.update(FI_SVPC_DATA.Buttons, {id = bid}, {objective = input, success = false});
			-- refresh variable
			button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
		end

		-- update interface
		local f_name = "FI_Button_"..button.id;
		_G[f_name.."_Objective"]:SetText(button.objective);

		-- notify user
		if (button.objective > 0) then
			if FI_SV_CONFIG.Objective.notify and (FI_LOADING == false) then
				local itemName, itemLink = GetItemInfo(button.item);
				if itemLink then
					FI_Notify("Farming objective set for:  "..itemLink, {1,1,1}, "QUESTADDED");
				end
			end

			-- show goal on button
			_G[f_name.."_Objective"]:Show();

			-- call tracking incase we already have enough
			FI_Objective(button.id, prevCount);
		else
			-- inform user we are erasing an objective
			if FI_SV_CONFIG.Objective.notify and editbox and (prevCount > 0) then
				FI_Notify("Farming objective abandoned.", {1,1,1}, "igQuestLogAbandonQuest");
			end

			-- hide goal number
			_G[f_name.."_Objective"]:Hide();
		end
	end
end

function FI_EditObjective( bid )
	-- hide other edit boxes
	for i,b in ipairs(FI_SVPC_DATA.Buttons) do
		_G["FI_Button_"..b.id.."_Edit"]:Hide();
	end

	local button = FI_DB.select(FI_SVPC_DATA.Buttons, {id = bid}, true);
	local f_name = "FI_Button_"..button.id;

	-- set editbox to current value
	_G[f_name.."_Edit"]:SetText(button.objective);

	-- show editbox
	_G[f_name.."_Edit"]:Show();
	_G[f_name.."_Edit"]:HighlightText();
end

function FI_ClearObjective( bid )
	local f_name = "FI_Button_"..bid;

	-- reset objective related data
	FI_DB.update(FI_SVPC_DATA.Buttons, {id = bid}, {objective = 0, success = false});

	-- reset graphical elements
	_G[f_name.."_Objective"]:SetText(0);
	_G[f_name.."_Objective"]:Hide();
end
