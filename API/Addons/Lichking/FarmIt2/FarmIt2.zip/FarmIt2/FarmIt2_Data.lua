﻿--------------------------------------------------------------------------------
--  BOOTSTRAP
--
--  SavedVariablesPerCharacter: FI_SVPC_Config,FI_SVPC_Data
--  SavedVariables: FI_SV_Config,FI_SV_Data
--------------------------------------------------------------------------------
FI_DEBUG = false;
if FI_DEBUG then print("FarmIt2_Data.lua loaded."); end

FI_TITLE = "FarmIt2";
FI_VERSION = 2.13;
FI_RELEASE = "";
FI_REQUIRES_RESET = false;
FI_REQUIRES_REBUILD = false;

FI_LOAD_STATES = {"initialized","updated","loaded"};
FI_STATUS = 1;
FI_MOVING = false;

-- FarmIt's clipboard
FI_SELECTED = false;


--------------------------------------------------------------------------------
--  HELPER FUNCTIONS
--------------------------------------------------------------------------------
function table.dump( tab, indent )
	local pad = "  ";
	if indent then indent = indent..pad; else indent = pad; end

	for key,val in pairs(tab) do
		if (type(val) == "table") then
			print(key.." = table:");
			table.dump(val, indent);
		else
			print(key.." = "..tostring(val));
		end
	end
end

-- Copy a table by value, not by reference. *sigh*@Lua
function table.copy( tab )
	local copy = {};
	
	for key,val in pairs(tab) do
		if (type(val) == "table") then
			-- recursive call. why? because we love having to do this crap, thats why.
			copy[key] = table.copy(val);
		else
			copy[key] = val;
		end
	end
	
	return copy;
	
	-- if metatables are needed:
	--return setmetatable(copy, getmetatable(tab));
end

-- expects a boolean, returns opposite value
function FI_Toggle( value )
	if value then
		return false;
	else
		return true;
	end
end

-- for mapping visible frames to their data record
-- expects a string in the format: FI_Button_1
function FI_FrameToID( f_name )
	local prefix,frame,id = strsplit("_", f_name);
	return tonumber(id);
end


--------------------------------------------------------------------------------
--  DEFAULT VALUES
--------------------------------------------------------------------------------
FI_DEFAULTS = {};
FI_DEFAULTS["NumGroups"] = 1; --default number of bars to start with
FI_DEFAULTS["NumButtons"] = 12; --default number of buttons records in a group
FI_DEFAULTS["MaxGroups"] = 12; --prevent memory usage from getting out of hand
FI_DEFAULTS["MaxButtons"] = 48; --max buttons per group

--  DB RECORD FORMATS ----------------------------------------------------------
FI_DEFAULTS["DB"] = {
	["Group"] = {
		["id"] = 0,
		["show"] = true,
		["move"] = true,
		["grow"] = "U", -- L(eft), R(ight), U(p), D(own)
		["size"] = 4,
		["pad"] = 5,
		["scale"] = 1,
		["alpha"] = 1,
		["text"] = true,
	},
	
	["Button"] = {
		["id"] = 0,
		["group"] = 0, --(foreign key) buttons MUST be assigned to a group after creation!
		["item"] = false,
		["bank"] = false,
		["count"] = 0,
		["objective"] = 0,
		["success"] = false,
	},
}

--  SAVED VARIABLES  -----------------------------------------------------------
FI_DEFAULTS["SV"] = {
	["CONFIG"] = {
		-- shared configuration
		["version"] = FI_VERSION,
		["Progress"] = {
			["notify"] = true,
			["color"] = {1, 1, 0.25},
		},
		["Objective"] = {
			["notify"] = true,
			["color"] = {1, 0.2, 0.2},
			["color2"] = {0.3, 0.9, 0.3},
		},
		["Bank"] = {
			["color"] = {1, 1, 0},
		},
	},
	
	["DATA"] = {
		-- farming progress log
		["Log"] = {},
		
		-- user created templates
		["Templates"] = {},
	},
}
--  SAVED VARIABLES PER CHARACTER  ---------------------------------------------
FI_DEFAULTS["SVPC"] = {
	["CONFIG"] = {
		-- user preferences
		["show"] = true,
		["move"] = true,
		["scale"] = 1,
		["alpha"] = 1,
		["style"] = "default",
	},

	["DATA"] = {
		-- core data
		["Groups"] = {}, --group records
		["Buttons"] = {}, --button records
	},
}


--------------------------------------------------------------------------------
-- CONFIGURATION SETTINGS OBJECT
--------------------------------------------------------------------------------
FI_CONFIG = {};


--------------------------------------------------------------------------------
-- DATA STORAGE METHODS
--------------------------------------------------------------------------------
FI_DB = {};

-- AUTOINC ---------------------------------------------------------------------
-- expects all records in the table to have a numeric "id" field.
-- tab : (table) target table
FI_DB.autoinc = function( tab )
	local nextID = 1;

	if (#tab > 0) then
		local tmp = {};

		-- extract the IDs
		for i,record in ipairs(tab) do
			table.insert(tmp, record.id);
		end

		-- sort ascending
		table.sort(tmp);

		-- determine next value
		nextID = tmp[#tmp]+1;
	end

	return nextID;
end

-- FIND ------------------------------------------------------------------------
-- tab    : (table) target to search
-- where  : (table) expects an associative array of key==value pairs for search criteria
-- single : (boolean) simplifies formatting when expecting one result
-- any    : (boolean) if true allows partial matching (like sql's "OR" syntax)
FI_DB.find = function( tab, where, single, any )
	local results = {};
	
	for i,record in ipairs(tab) do
		local match,fail = false,false;
		
		for key,val in pairs(where) do
			if (record[key] == val) then
				match = true;
			else
				fail = true;
			end
		end
		
		if ((match == true) and (fail == false)) or (any and (match == true)) then
			table.insert(results, i);
		end
	end
	
	-- return *table index* of matching records
	if single then
		-- returns nil if nothing was found
		return results[1];
	else
		return results;
	end
end

-- INSERT ----------------------------------------------------------------------
-- tab  : (table) target table
-- data : (table) "record" to be inserted. primary key will be set automagically
FI_DB.insert = function( tab, data )
	-- avoid reference headaches
	local record = table.copy(data);

	-- set primary key
	record["id"] = FI_DB.autoinc(tab);

	-- doooo eeeet!
	table.insert(tab, record);
	
	-- return primary key of new record
	return record.id;
end

-- SELECT ----------------------------------------------------------------------
-- tab    : (table) target to search
-- where  : (table) expects an associative table of {key = value} pairs for search criteria
-- single : (boolean) return first record in the set. simplifies formatting when expecting one result
-- any    : (boolean) if true, allows partial matching. works like sql's "OR" syntax
FI_DB.select = function( tab, where, single, any )
	local results = {};

	local keys = FI_DB.find(tab, where, single, any);
	
	if single and (type(keys) == "number") then
		results = table.copy(tab[keys]);
	elseif (type(keys) == "table") and (#keys > 0) then
		-- copy contents of matching records into result set
		for i,k in ipairs(keys) do
			table.insert(results, table.copy(tab[k]));
		end
	else
		results = keys;
	end

	-- this could be: a table with multiple records, a single record (still a table), an empty table, or nil (if single and no result)
	return results;
end

-- UPDATE ----------------------------------------------------------------------

-- tab   : (table) target to search
-- where : (table) expects an associative table of {key = value} pairs for search criteria
-- set   : (table) expects a table with data updates in {key = value} pairs
-- any   : (boolean) if true, allows partial matching. works like sql's "OR" syntax
FI_DB.update = function( tab, where, set, any )
	local results = {};
	
	local keys = FI_DB.find(tab, where, nil, any);
	if (#keys > 0) then
		-- go through each record in the result set
		for i,k in ipairs(keys) do
			-- do updates
			for key,val in pairs(set) do
				tab[k][key] = val;
			end
			-- build set of affected records
			table.insert(results, tab[k]);
		end
	end

	-- return updated copies of affected records
	if (#results == 1) then
		return results[1];
	else
		return results;
	end
end

-- DELETE ----------------------------------------------------------------------
-- tab   : (table) target to search
-- where : (table) expects an associative table of {key = value} pairs for search criteria
FI_DB.delete = function( tab, where )
	local numRecords = 0;

	local keys = FI_DB.find(tab, where);
	numRecords = #keys;
	
	if (numRecords > 0) then
		for i,k in ipairs(keys) do
			table.remove(tab, k);
		end
		collectgarbage();
	end

	-- return number of "records" affected
	return numRecords;
end

-- COPY ----------------------------------------------------------------------
-- tab    : (table) target table
-- where  : (table) expects an associative table of {key = value} pairs for search criteria (source record)
-- where2 : (table) expects an associative table of {key = value} pairs for search criteria (destination record)
-- any    : (boolean) if true, allows partial matching. works like sql's "OR" syntax
FI_DB.copy = function( tab, where, where2, any )
	local source = FI_DB.select(tab, where, true);
	local keys = FI_DB.find(tab, where2, nil, any);

	if (#keys > 0) then
		-- iterate over each target record
		for i,key in ipairs(keys) do
			-- save the ID before we overwrite the record
			local id = tab[key]["id"];
			-- copy entire source record over destination
			tab[key] = table.copy(source);
			-- restore the original record id
			tab[key]["id"] = id;
		end
	end

	-- return table indexes of destination records found/changed
	return keys;
end

-- "tail" wrapper
FI_DB.first = function( tab, where, orderby )
	return FI_DB.tail(tab, where, orderby, "desc");
end

-- "tail" wrapper
FI_DB.last = function( tab, where, orderby )
	return FI_DB.tail(tab, where, orderby, "asc");
end

-- this is meant to help "tail" the farming log
FI_DB.tail = function( tab, where, orderby, order )
	if FI_DEBUG then print("FI_DB.tail in progress..."); end

	-- build data set
	local keys = FI_DB.find(tab, where);

	if keys[1] then
		-- prep for sort
		local k = keys[1];
		local temp = table.copy(tab[k]);
		
		for i,key in ipairs(keys) do
			-- this is probably only safe with numeric values at this point
			if (order == "asc") then
				if (tab[key][orderby] > temp[orderby]) then temp = table.copy(tab[key]); end
			elseif (order == "desc") then
				if (tab[key][orderby] < temp[orderby]) then temp = table.copy(tab[key]); end
			end
		end

		return temp;
	end
end


--------------------------------------------------------------------------------
-- DATA MAINTENANCE
--------------------------------------------------------------------------------
FI_DB.check = function()
end

-- rebuild saved variable structure
FI_DB.rebuild = function( arg )
	-- misc addon data
	if (arg == "data") or (arg == "all") then
		FI_SV_DATA = {};
		FI_SVPC_DATA = {};

		FI_SV_DATA = table.copy( FI_DEFAULTS.SV.DATA );
		FI_SVPC_DATA = table.copy( FI_DEFAULTS.SVPC.DATA );
	end

	-- configuration settings
	if (arg == "config") or (arg == "all") then
		FI_SV_CONFIG = {};
		FI_SVPC_CONFIG = {};

		FI_SV_CONFIG = table.copy( FI_DEFAULTS.SV.CONFIG );
		FI_SVPC_CONFIG = table.copy( FI_DEFAULTS.SVPC.CONFIG );
	end

	-- visual style data
	if (arg == "style") or (arg == "all") then
		FI_SVPC_STYLE = {};
		FI_SVPC_STYLE = table.copy( FI_STYLES.default );
	end

	-- frame data
	if (arg == "frames") or (arg == "all") then
		FI_SVPC_DATA["Groups"] = {};
		FI_SVPC_DATA["Buttons"] = {};
		
		----- build group data -----
		for i=1,FI_DEFAULTS.NumGroups do
			FI_DB.insert(FI_SVPC_DATA.Groups, FI_DEFAULTS.DB.Group);
		end

		for i,group in ipairs(FI_SVPC_DATA.Groups) do
			----- build button data -----
			for n=1,FI_DEFAULTS.NumButtons do
				-- insert button data
				local bid = FI_DB.insert(FI_SVPC_DATA.Buttons, FI_DEFAULTS.DB.Button);
				-- assign button to group
				FI_DB.update(FI_SVPC_DATA.Buttons, {id = bid}, {group = group.id});
			end
		end
	end
end

-- police for orphans! sorry little Annie.
FI_DB.garbage = function()
	-- check log size
	-- truncate to max length
	
	-- check for groups with no buttons
	-- check for buttons with no group id

	-- check size of user template table
	-- warn if table is too large
end
