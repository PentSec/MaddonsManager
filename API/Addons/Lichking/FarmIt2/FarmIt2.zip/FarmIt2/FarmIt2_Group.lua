﻿--------------------------------------------------------------------------------
--  GROUP RELATED CODE
--------------------------------------------------------------------------------
if FI_DEBUG then print("FarmIt2_Group.lua loaded."); end


-- return all the button id's that belong to a specific group
function FI_GroupMembers( gid )
	local results = {};
	
	for i,button in ipairs(FI_SVPC_DATA.Buttons) do
		if (button.group == gid) then
			table.insert(results, button.id);
		end
	end
	
	table.sort(results);
	return results;
end

function FI_Movable( gid )
	local group = FI_DB.select(FI_SVPC_DATA.Groups, {id = gid}, true);
	
	-- check both the global setting and individual bar setting
	if group.move and FI_SVPC_CONFIG.move then
		return true;
	else
		return false;
	end
end

function FI_Click_Group( self, click, down )
	local f_name = self:GetName();
	if FI_DEBUG then print("You CLICKED the "..click.." ("..tostring(down)..") on frame: "..f_name); end

	local group = FI_DB.select(FI_SVPC_DATA.Groups, {id = FI_FrameToID(f_name)}, true);

	if (click == "LeftButton") then
		if IsShiftKeyDown() then
			------------------------------------------------------------
			-- THIS SPACE FOR RENT
			------------------------------------------------------------
			
		else
			------------------------------------------------------------
			-- DRAG BAR
			------------------------------------------------------------
			if FI_Movable(group.id) then
				if down then
					_G[f_name]:StartMoving();
				else
					_G[f_name]:StopMovingOrSizing();
				end
			end
			
		end	
	
	elseif (click == "RightButton") then
		if IsShiftKeyDown() then
			------------------------------------------------------------
			-- SHOW COMMANDS
			------------------------------------------------------------
			InterfaceOptionsFrame_OpenToCategory(FI_CONFIG.Pages[2]);
			
		else
			------------------------------------------------------------
			-- SHOW CONFIG PANEL
			------------------------------------------------------------
			InterfaceOptionsFrame_OpenToCategory(FI_CONFIG.Panel);
		end
	end
end

-- This function is more of a beast than I prefer, but it gets stuff done.
function FI_Group( action, arg1, arg2 )
	--------------------------------------------------
	-- ADD
	--------------------------------------------------
	if (action == "add") then
		local total = #FI_SVPC_DATA.Groups +1;
		
		if (total > FI_DEFAULTS.MaxGroups) then
			DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  The maximum number of bars allowed is "..FI_DEFAULTS.MaxGroups..".");
		else
			-- insert group record
			local gid = FI_DB.insert(FI_SVPC_DATA.Groups, FI_DEFAULTS.DB.Group);

			-- populate the group
			for i=1,FI_DEFAULTS.NumButtons do
				-- copy default button data
				local bid = FI_DB.insert(FI_SVPC_DATA.Buttons, FI_DEFAULTS.DB.Button);
				-- assign button to group
				FI_DB.update(FI_SVPC_DATA.Buttons, {id = bid}, {group = gid});
			end
			
			-- create the frames!
			FI_GroupFrames(gid);
			FI_GroupStyle(gid);
		end

	--------------------------------------------------
	-- REMOVE
	-- arg1 == index (bar number)
	--------------------------------------------------
	elseif (action == "remove") then
		-- map bar number to group data
		local group = FI_SVPC_DATA.Groups[arg1]
		
		if group then
			-- remove associated buttons (empty the group)
			for i,bid in ipairs(FI_GroupMembers(group.id)) do
				FI_DB.delete(FI_SVPC_DATA.Buttons, {id = bid});
			end
			
			-- delete group record
			FI_DB.delete(FI_SVPC_DATA.Groups, {id = group.id});

			-- commit the changes
			ReloadUI();
		else
			DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Invalid bar number.");
		end
		
	--------------------------------------------------
	-- SIZE (NUMBER OF BUTTONS IN THE GROUP)
	--   This regulates the number of actual button records in the database. To simply show/hide buttons, see FI_QuickSize()
	-- arg1 == gid
	-- arg2 == FI_SVPC_DATA.Groups.i.size
	--------------------------------------------------
	elseif (action == "size") then
		-- map bar number to group data
		local group = FI_SVPC_DATA.Groups[arg1]
		local buttons = FI_GroupMembers(group.id);
		local newsize = arg2;
		
		if group then
			-- bar must have at least one button in the group. to hide all buttons use "/farmit show {bar#}" or see FI_QuickSize()
			if (newsize < 1) or (newsize > FI_DEFAULTS.MaxButtons) then
				DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Bar size must be a whole number between 1 and "..FI_DEFAULTS.MaxButtons..".");
			else
				-- are we adding or subtracting?
				if (newsize > #buttons) then
					--------------------------------------------------
					--  INCREASE
					--------------------------------------------------
					local diff = newsize - #buttons;
					
					for i=1,diff do
						-- insert new button data
						local bid = FI_DB.insert(FI_SVPC_DATA.Buttons, FI_DEFAULTS.DB.Button);
						-- assign button to group
						FI_DB.update(FI_SVPC_DATA.Buttons, {id = bid}, {group = group.id});
					end
					
					-- create the frames
					FI_ButtonFrames(group.id);

					-- set button visibility to match change in group size
					FI_DB.update(FI_SVPC_DATA.Groups, {id = group.id}, {size = #FI_GroupMembers(group.id)});
					-- apply quicksize
					FI_ButtonVis(group.id);
				else
					--------------------------------------------------
					--  DECREASE
					--------------------------------------------------
					-- we can't actually destroy frames, and we don't want to reload unless we really have to...
					-- so for now we will hide the button frames and remove their data records, so next time the interface loads they will be gone for good
					for i,bid in ipairs(buttons) do
						if (i > newsize) then
							-- drop the db record
							FI_DB.delete(FI_SVPC_DATA.Buttons, {id = bid});
							
							-- hide the frame
							_G["FI_Button_"..bid]:Hide();
						end
					end
				end
			end
		else
			DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Invalid bar number.");
		end

	--------------------------------------------------
	-- GROW (BAR ORIENTATION)
	-- arg1 == gid
	-- arg2 == FI_SVPC_DATA.Groups.i.grow
	--------------------------------------------------
	elseif (action == "grow") then
		-- map bar number to group data
		local group,input = FI_SVPC_DATA.Groups[arg1],arg2;
		local parent = "FI_Group_"..group.id;

		-- validate input
		local options = {"U","D","L","R"};
		local vertical = {"U","D"};
		
		if (input == group.grow) then
			-- skip redundant calls
			return;
			
		elseif tContains(options,input) then
			-- store the setting
			FI_DB.update(FI_SVPC_DATA.Groups, {id = group.id}, {grow = input});

			-- default anchor frame dimensions (assumes vertical)
			local size_x,size_y = 32,28;

			-- handle orientation related issues
			if tContains(vertical,input) then
				-- vertical
				FI_DB.update(FI_SVPC_DATA.Groups, {id = group.id}, {text = true});
			else
				-- horizontal
				FI_DB.update(FI_SVPC_DATA.Groups, {id = group.id}, {text = false});
				
				-- adjust anchor dimensions
				size_x,size_y = 32,30;
			end
			
			-- mighty morphin' group anchors!
			_G[parent]:SetSize(size_x, size_y);
			_G[parent.."_Background"]:SetSize(size_x, size_y);

			-- refresh group var
			group = FI_DB.select(FI_SVPC_DATA.Groups, {id = group.id}, true);

			-- now for the real work
			local last_frame = parent;
			local pad = 0;
			for i,bid in ipairs(FI_GroupMembers(group.id)) do
				local f_name = "FI_Button_"..bid;
				
				-- determine orientation
				if (group.grow == "U") then
					-- bar grows up
					a1,a2,x,y = "BOTTOM","TOP",0,pad;
					
				elseif (group.grow == "D") then
					-- bar grows down
					a1,a2,x,y = "TOP","BOTTOM",0,-pad;
					
				elseif (group.grow == "L") then
					-- bar grows left
					a1,a2,x,y = "RIGHT","LEFT",-pad,0;
					
				elseif (group.grow == "R") then
					-- bar grows right
					a1,a2,x,y = "LEFT","RIGHT",pad,0;
				end
				
				-- get ready to mooooove
				_G[f_name]:ClearAllPoints();
				
				-- set new frame position
				_G[f_name]:SetPoint(a1, last_frame, a2, x, y);
				
				-- on to the next...
				last_frame = f_name;
				
				-- use group padding value now that the first button is out of the way...
				if (pad == 0) then
					pad = group.pad;
				end
			end
		else
			DEFAULT_CHAT_FRAME:AddMessage("[FarmIt]  Valid options for 'grow' are:  U,D,L,R");
		end
		
	end
	return;
end

-- change number of visible buttons without altering button data
function FI_QuickSize( parent, action )
	local query = {
		id = FI_FrameToID( parent:GetName() ),
	}
	local group = FI_DB.select(FI_SVPC_DATA.Groups, query, true);
	local members = FI_GroupMembers(group.id);
	
	-- calculate new size
	local newsize;
	if (action == "less") then
		if FI_DEBUG then print("Group "..group.id.." MINUS button clicked..."); end

		newsize = group.size -1;

		if (newsize < 0) then
			newsize = nil;
			if FI_DEBUG then print("Minimum bar size reached."); end
		end

	elseif (action == "more") then
		if FI_DEBUG then print("Group "..group.id.." PLUS button clicked..."); end

		newsize = group.size +1;

		if (newsize > #members) then
			newsize = nil;
			if FI_DEBUG then print("All the buttons in that group are already showing."); end
		end
	end

	if newsize then
		-- update the group record
		FI_DB.update(FI_SVPC_DATA.Groups, {id = group.id}, {size = newsize});
		-- apply the change
		FI_ButtonVis(group.id);
	end
end

-- applies group.size to bar
function FI_ButtonVis( gid )
	local group = FI_DB.select(FI_SVPC_DATA.Groups, {id = gid}, true);
	local bids = FI_GroupMembers(group.id);

	for i,bid in ipairs(bids) do
		if (i > group.size) then
			_G["FI_Button_"..bid]:Hide();
		else
			_G["FI_Button_"..bid]:Show();
		end
	end
end

-- gid : if present, toggle visibility of that group only. (otherwise toggle entire addon)
function FI_Show( gid )
	if gid then
		-- toggle group visibility setting
		local group = FI_DB.select(FI_SVPC_DATA.Groups, {id = gid}, true);
		local newshow = FI_Toggle(group.show);
		FI_DB.update(FI_SVPC_DATA.Groups, {id = gid}, {show = newshow});

		-- apply the change
		if newshow then
			_G["FI_Group_"..group.id]:Show();
		else
			_G["FI_Group_"..group.id]:Hide();
		end
	else
		-- toggle global visibility setting
		FI_SVPC_CONFIG.show = FI_Toggle(FI_SVPC_CONFIG.show);

		-- apply the change
		if FI_SVPC_CONFIG.show then
			_G["FI_PARENT"]:Show();
		else
			_G["FI_PARENT"]:Hide();
		end
	end
end

function FI_Alpha( alpha, gid )
	if gid then
		-- set group alpha for a specific bar
		FI_DB.update(FI_SVPC_DATA.Groups, {id = gid}, {alpha = tonumber(alpha)});
		_G["FI_Group_"..gid]:SetAlpha(alpha);

	elseif alpha then
		-- set parent alpha of entire addon
		FI_SVPC_CONFIG.alpha = tonumber(alpha);
		_G["FI_PARENT"]:SetAlpha(FI_SVPC_CONFIG.alpha);
	end
end

-- scale : (numeric) decimal value for visual scaling of frames. (1.25 = 125%)
-- gid   : (numeric) if present, apply setting to this group only.
function FI_Scale( newscale, gid )
	if gid and newscale then
		-- change group setting
		FI_DB.update(FI_SVPC_DATA.Groups, {id = gid}, {scale = newscale});
		-- apply the change
		_G["FI_Group_"..gid]:SetScale(newscale);
	elseif newscale then
		-- change global setting
		FI_SVPC_CONFIG.scale = newscale;
		-- apply the change
		_G["FI_PARENT"]:SetScale(newscale);
	else
		-- apply individual group settings
		for i,group in ipairs(FI_SVPC_DATA.Groups) do
			_G["FI_Group_"..group.id]:SetScale(group.scale);
		end
		-- apply global scale saved setting
		_G["FI_PARENT"]:SetScale(FI_SVPC_CONFIG.scale);
	end
end
