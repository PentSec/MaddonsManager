--[[
	Place the sound file in the sounds folder
	You have to restart WoW after you place the sound file in the folder.
	Usage: SA_AddSound("soundName","soundFile")
	Example:
		SA_AddSound("Beep","Beep.mp3")
]]

SA_AddSound("Spa-loosh","Spa-loosh.mp3")
SA_AddSound("Zing Alarm","ZingAlarm.mp3")
