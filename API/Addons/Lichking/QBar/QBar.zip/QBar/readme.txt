QBar - Quest Item Button Bar
----------------------------
Ever been questing and had to find all those usable quest items in your bags all the time, then this addon is for you. No longer will you have to keep your bags open to do daily bombing quests!

This addon will automatically create a dynamic buttonbar for all those usable quest items, it also checks if your equipped gear for usable quest items.

If you do not wish to show a certain item on QBar, you can ignore it by holding down Shift and clicking on it.

Command Line Parameters
-----------------------

/qb toggle
Toggles QBar being enabled or not.

/qb scale <value>
Sets the scale of the buttons, default is 1.

/qb size <value>
Sets the unit size of the buttons, default is 36.

/qb padding <value>
Configures the padding between the buttons, default is 1.

/qb tips
Determines if item tips are shown when you move your mouse over the buttons.

/qb vertical
Toggles between horizontal and vertical button bar.

/qb mirror
Changes the anchor direction, top/bottom or left/right, depending on the vertical setting.

/qb lock
Toggles the button frame being locked, use this command to move the buttons around.

/qb reset
Resets the QBar frame to the middle of the screen in case it was pushed off screen.

/qb clearignore
Clears the ignore list, and shows all items again. You can shift click an item to ignore it.

/qb bind
Use this command to set the key binding for the last item used, this is pretty vital for all the dailies.

Lacking Features, Problems & Ideas
----------------------------------
- Manage the update of keybinding, no need to unbind and rebind if it stays the same as before.