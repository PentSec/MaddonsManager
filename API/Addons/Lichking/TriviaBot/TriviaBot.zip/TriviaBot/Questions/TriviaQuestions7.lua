-- Initialize arrays
TriviaBot_Questions[7] = {['Categories'] = {}, ['Question'] = {}, ['Answers'] = {}, ['Category'] = {}, ['Points'] = {}, ['Hints'] = {}};

-- List information
TriviaBot_Questions[7]['Title'] = "More World of Warcraft";
TriviaBot_Questions[7]['Description'] = "Trivia about the World of Warcraft universe.";
TriviaBot_Questions[7]['Author'] = "Various";

-- Add categories
TriviaBot_Questions[7]['Categories'][1] = "WoW Lore"; 

TriviaBot_Questions[7]['Question'][1] = "Who is the third boss in Blackwing Lair?";
TriviaBot_Questions[7]['Answers'][1] = {"Broodlord Lashlayer",  "Broodlord"};
TriviaBot_Questions[7]['Category'][1] = 1;
TriviaBot_Questions[7]['Points'][1] = 1;
TriviaBot_Questions[7]['Hints'][1] = {};

TriviaBot_Questions[7]['Question'][2] = "What is the minimum level requirement for artisan skills? (1-60)";
TriviaBot_Questions[7]['Answers'][2] = {"35",  "thirtyfive", "thirty five"};
TriviaBot_Questions[7]['Category'][2] = 1;
TriviaBot_Questions[7]['Points'][2] = 1;
TriviaBot_Questions[7]['Hints'][2] = {};

TriviaBot_Questions[7]['Question'][3] = "Which class can cast 'blessings'?";
TriviaBot_Questions[7]['Answers'][3] = {"Paladins",  "Paladin"};
TriviaBot_Questions[7]['Category'][3] = 1;
TriviaBot_Questions[7]['Points'][3] = 1;
TriviaBot_Questions[7]['Hints'][3] = {};

TriviaBot_Questions[7]['Question'][4] = "What is the zone north of Blasted Lands called? (full name)";
TriviaBot_Questions[7]['Answers'][4] = {"Swamp of Sorrows"};
TriviaBot_Questions[7]['Category'][4] = 1;
TriviaBot_Questions[7]['Points'][4] = 1;
TriviaBot_Questions[7]['Hints'][4] = {};

TriviaBot_Questions[7]['Question'][5] = "What is the busiest Alliance city?";
TriviaBot_Questions[7]['Answers'][5] = {"Ironforge",  "IF"};
TriviaBot_Questions[7]['Category'][5] = 1;
TriviaBot_Questions[7]['Points'][5] = 1;
TriviaBot_Questions[7]['Hints'][5] = {};

TriviaBot_Questions[7]['Question'][6] = "In which instance does General Drakkisath reside?";
TriviaBot_Questions[7]['Answers'][6] = {"UBRS",  "Upper Blackrock Spire"};
TriviaBot_Questions[7]['Category'][6] = 1;
TriviaBot_Questions[7]['Points'][6] = 1;
TriviaBot_Questions[7]['Hints'][6] = {};

TriviaBot_Questions[7]['Question'][7] = "What is Leeroy's surname?";
TriviaBot_Questions[7]['Answers'][7] = {"Jenkins"};
TriviaBot_Questions[7]['Category'][7] = 1;
TriviaBot_Questions[7]['Points'][7] = 1;
TriviaBot_Questions[7]['Hints'][7] = {};

TriviaBot_Questions[7]['Question'][8] = "What race has the 'Will of the Forsaken' racial ability?";
TriviaBot_Questions[7]['Answers'][8] = {"Undead",  "Undeads", "The Forsaken", "Forsaken"};
TriviaBot_Questions[7]['Category'][8] = 1;
TriviaBot_Questions[7]['Points'][8] = 1;
TriviaBot_Questions[7]['Hints'][8] = {};

TriviaBot_Questions[7]['Question'][9] = "What are low-leveled, buffed characters usually called?";
TriviaBot_Questions[7]['Answers'][9] = {"Twinks",  "Twink", "Twinked"};
TriviaBot_Questions[7]['Category'][9] = 1;
TriviaBot_Questions[7]['Points'][9] = 1;
TriviaBot_Questions[7]['Hints'][9] = {};

TriviaBot_Questions[7]['Question'][10] = "Where does each class-specific tier 0 leggings drop?";
TriviaBot_Questions[7]['Answers'][10] = {"Stratholme UD",  "Stratholme", "strat"};
TriviaBot_Questions[7]['Category'][10] = 1;
TriviaBot_Questions[7]['Points'][10] = 1;
TriviaBot_Questions[7]['Hints'][10] = {};

TriviaBot_Questions[7]['Question'][11] = "With whom must you reach exalted with to be able to buy 'The Unstoppable Force' (name one of the factions)?";
TriviaBot_Questions[7]['Answers'][11] = {"stormpike",  "frostwolf"};
TriviaBot_Questions[7]['Category'][11] = 1;
TriviaBot_Questions[7]['Points'][11] = 1;
TriviaBot_Questions[7]['Hints'][11] = {};

TriviaBot_Questions[7]['Question'][12] = "Who is the final boss in Molten Core?";
TriviaBot_Questions[7]['Answers'][12] = {"Ragnaros",  "Ragnaros the Firelord"};
TriviaBot_Questions[7]['Category'][12] = 1;
TriviaBot_Questions[7]['Points'][12] = 1;
TriviaBot_Questions[7]['Hints'][12] = {};

TriviaBot_Questions[7]['Question'][13] = "What does an orange-colored text on an item refer to?";
TriviaBot_Questions[7]['Answers'][13] = {"Legendary Quality",  "legendary"};
TriviaBot_Questions[7]['Category'][13] = 1;
TriviaBot_Questions[7]['Points'][13] = 1;
TriviaBot_Questions[7]['Hints'][13] = {};

TriviaBot_Questions[7]['Question'][14] = "What does a purple-colored text on an item refer to?";
TriviaBot_Questions[7]['Answers'][14] = {"Epic Quality",  "epic"};
TriviaBot_Questions[7]['Category'][14] = 1;
TriviaBot_Questions[7]['Points'][14] = 1;
TriviaBot_Questions[7]['Hints'][14] = {};

TriviaBot_Questions[7]['Question'][15] = "What does a blue-colored text on an item refer to?";
TriviaBot_Questions[7]['Answers'][15] = {"Rare Quality",  "rare"};
TriviaBot_Questions[7]['Category'][15] = 1;
TriviaBot_Questions[7]['Points'][15] = 1;
TriviaBot_Questions[7]['Hints'][15] = {};

TriviaBot_Questions[7]['Question'][16] = "What does a green-colored text on an item refer to?";
TriviaBot_Questions[7]['Answers'][16] = {"Uncommon Quality",  "uncommon"};
TriviaBot_Questions[7]['Category'][16] = 1;
TriviaBot_Questions[7]['Points'][16] = 1;
TriviaBot_Questions[7]['Hints'][16] = {};

TriviaBot_Questions[7]['Question'][17] = "Which of these pre-tbc end-game raiding instances is limited to 20 members? (UBRS, MC, AQ40, ZG, BWL";
TriviaBot_Questions[7]['Answers'][17] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][17] = 1;
TriviaBot_Questions[7]['Points'][17] = 1;
TriviaBot_Questions[7]['Hints'][17] = {};

TriviaBot_Questions[7]['Question'][18] = "What is the lowest level requirement for an epic weapon?";
TriviaBot_Questions[7]['Answers'][18] = {"35",  "thirty five"};
TriviaBot_Questions[7]['Category'][18] = 1;
TriviaBot_Questions[7]['Points'][18] = 1;
TriviaBot_Questions[7]['Hints'][18] = {};

TriviaBot_Questions[7]['Question'][19] = "The Elements set corresponds to which class?";
TriviaBot_Questions[7]['Answers'][19] = {"Shaman",  "Shammy"};
TriviaBot_Questions[7]['Category'][19] = 1;
TriviaBot_Questions[7]['Points'][19] = 1;
TriviaBot_Questions[7]['Hints'][19] = {};

TriviaBot_Questions[7]['Question'][20] = "What is the tier 2 Priest set called?";
TriviaBot_Questions[7]['Answers'][20] = {"Vestments of Transcendence",  "Transcendence"};
TriviaBot_Questions[7]['Category'][20] = 1;
TriviaBot_Questions[7]['Points'][20] = 1;
TriviaBot_Questions[7]['Hints'][20] = {};

TriviaBot_Questions[7]['Question'][21] = "The Barrens was once a great forest under the protection of the ______?";
TriviaBot_Questions[7]['Answers'][21] = {"Kaldorei"};
TriviaBot_Questions[7]['Category'][21] = 1;
TriviaBot_Questions[7]['Points'][21] = 1;
TriviaBot_Questions[7]['Hints'][21] = {};

TriviaBot_Questions[7]['Question'][22] = "The three bugs in AQ40 are called Vem, Kri and ...?";
TriviaBot_Questions[7]['Answers'][22] = {"Princess Yauj",  "Yauj"};
TriviaBot_Questions[7]['Category'][22] = 1;
TriviaBot_Questions[7]['Points'][22] = 1;
TriviaBot_Questions[7]['Hints'][22] = {};

TriviaBot_Questions[7]['Question'][23] = "The abbreviation 'Org' refers to?";
TriviaBot_Questions[7]['Answers'][23] = {"Orgrimmar"};
TriviaBot_Questions[7]['Category'][23] = 1;
TriviaBot_Questions[7]['Points'][23] = 1;
TriviaBot_Questions[7]['Hints'][23] = {};

TriviaBot_Questions[7]['Question'][24] = "Duskbat Pelt drops in which zone?";
TriviaBot_Questions[7]['Answers'][24] = {"Tirisfal Glades",  "Tirisfal"};
TriviaBot_Questions[7]['Category'][24] = 1;
TriviaBot_Questions[7]['Points'][24] = 1;
TriviaBot_Questions[7]['Hints'][24] = {};

TriviaBot_Questions[7]['Question'][25] = "Lethtendris in Dire Maul is what race?";
TriviaBot_Questions[7]['Answers'][25] = {"Blood Elf"};
TriviaBot_Questions[7]['Category'][25] = 1;
TriviaBot_Questions[7]['Points'][25] = 1;
TriviaBot_Questions[7]['Hints'][25] = {};

TriviaBot_Questions[7]['Question'][26] = "Which of these classes cannot duel-wield? (Warrior, Paladin, Rogue)";
TriviaBot_Questions[7]['Answers'][26] = {"Paladins",  "Paladin"};
TriviaBot_Questions[7]['Category'][26] = 1;
TriviaBot_Questions[7]['Points'][26] = 1;
TriviaBot_Questions[7]['Hints'][26] = {};

TriviaBot_Questions[7]['Question'][27] = "In which major city can the NPC Renzik 'The Shiv' be found?";
TriviaBot_Questions[7]['Answers'][27] = {"Stormwind",  "SW"};
TriviaBot_Questions[7]['Category'][27] = 1;
TriviaBot_Questions[7]['Points'][27] = 1;
TriviaBot_Questions[7]['Hints'][27] = {};

TriviaBot_Questions[7]['Question'][28] = "Negolash is found wandering off which zone's coast?";
TriviaBot_Questions[7]['Answers'][28] = {"Stranglethorn Vale",  "STV"};
TriviaBot_Questions[7]['Category'][28] = 1;
TriviaBot_Questions[7]['Points'][28] = 1;
TriviaBot_Questions[7]['Hints'][28] = {};

TriviaBot_Questions[7]['Question'][29] = "Which class can cast 'Unending Breath'?";
TriviaBot_Questions[7]['Answers'][29] = {"Warlocks",  "Warlock"};
TriviaBot_Questions[7]['Category'][29] = 1;
TriviaBot_Questions[7]['Points'][29] = 1;
TriviaBot_Questions[7]['Hints'][29] = {};

TriviaBot_Questions[7]['Question'][30] = "Who is the Chieftain of the Amani Tribe?";
TriviaBot_Questions[7]['Answers'][30] = {"Zuljin"};
TriviaBot_Questions[7]['Category'][30] = 1;
TriviaBot_Questions[7]['Points'][30] = 1;
TriviaBot_Questions[7]['Hints'][30] = {};

TriviaBot_Questions[7]['Question'][31] = "For humans, the starting place is called?";
TriviaBot_Questions[7]['Answers'][31] = {"Northshire Valley",  "northshire", "northshire abbey"};
TriviaBot_Questions[7]['Category'][31] = 1;
TriviaBot_Questions[7]['Points'][31] = 1;
TriviaBot_Questions[7]['Hints'][31] = {};

TriviaBot_Questions[7]['Question'][32] = "The King of Ironforge is called?";
TriviaBot_Questions[7]['Answers'][32] = {"Magni Bronzebeard",  "bronzebeard"};
TriviaBot_Questions[7]['Category'][32] = 1;
TriviaBot_Questions[7]['Points'][32] = 1;
TriviaBot_Questions[7]['Hints'][32] = {};

TriviaBot_Questions[7]['Question'][33] = "Using the Seal of Ascension in UBRS summons which Dragon?";
TriviaBot_Questions[7]['Answers'][33] = {"Vaelastrasz", "Vaelastrasz the Red"};
TriviaBot_Questions[7]['Category'][33] = 1;
TriviaBot_Questions[7]['Points'][33] = 1;
TriviaBot_Questions[7]['Hints'][33] = {};

TriviaBot_Questions[7]['Question'][34] = "Who is also known as the life-bender?";
TriviaBot_Questions[7]['Answers'][34] = {"Alexstrasza"};
TriviaBot_Questions[7]['Category'][34] = 1;
TriviaBot_Questions[7]['Points'][34] = 1;
TriviaBot_Questions[7]['Hints'][34] = {};

TriviaBot_Questions[7]['Question'][35] = "Who is the father of Morgraine? (first name)";
TriviaBot_Questions[7]['Answers'][35] = {"Alexandros"};
TriviaBot_Questions[7]['Category'][35] = 1;
TriviaBot_Questions[7]['Points'][35] = 1;
TriviaBot_Questions[7]['Hints'][35] = {};

TriviaBot_Questions[7]['Question'][36] = "The Emerald Dragons are Ysondre, Emeriss, Taerar and _____?";
TriviaBot_Questions[7]['Answers'][36] = {"Lethon"};
TriviaBot_Questions[7]['Category'][36] = 1;
TriviaBot_Questions[7]['Points'][36] = 1;
TriviaBot_Questions[7]['Hints'][36] = {};

TriviaBot_Questions[7]['Question'][37] = "The first wow expansion is called? (full name)";
TriviaBot_Questions[7]['Answers'][37] = {"The Burning Crusade",  "Burnign Crusade"};
TriviaBot_Questions[7]['Category'][37] = 1;
TriviaBot_Questions[7]['Points'][37] = 1;
TriviaBot_Questions[7]['Hints'][37] = {};

TriviaBot_Questions[7]['Question'][38] = "Name a secondary trade skill.";
TriviaBot_Questions[7]['Answers'][38] = {"First Aid",  "Fishing", "Cooking"};
TriviaBot_Questions[7]['Category'][38] = 1;
TriviaBot_Questions[7]['Points'][38] = 1;
TriviaBot_Questions[7]['Hints'][38] = {};

TriviaBot_Questions[7]['Question'][39] = "How much reputation does it take to get from revered to exalted?";
TriviaBot_Questions[7]['Answers'][39] = {"21000",  "21k", "21,000"};
TriviaBot_Questions[7]['Category'][39] = 1;
TriviaBot_Questions[7]['Points'][39] = 1;
TriviaBot_Questions[7]['Hints'][39] = {};

TriviaBot_Questions[7]['Question'][40] = "To which zone can Druids teleport?";
TriviaBot_Questions[7]['Answers'][40] = {"Moonglade"};
TriviaBot_Questions[7]['Category'][40] = 1;
TriviaBot_Questions[7]['Points'][40] = 1;
TriviaBot_Questions[7]['Hints'][40] = {};

TriviaBot_Questions[7]['Question'][41] = "Which achievement gives you the Kirin Tor Familiar non-combat pet?";
TriviaBot_Questions[7]['Answers'][41] = {"Higher Learning"};
TriviaBot_Questions[7]['Category'][41] = 1;
TriviaBot_Questions[7]['Points'][41] = 1;
TriviaBot_Questions[7]['Hints'][41] = {};

TriviaBot_Questions[7]['Question'][42] = "The enchant 'Enchant Chest - Major Mana' requires how many Lesser Eternal Essences?";
TriviaBot_Questions[7]['Answers'][42] = {"Zero",  "0"};
TriviaBot_Questions[7]['Category'][42] = 1;
TriviaBot_Questions[7]['Points'][42] = 1;
TriviaBot_Questions[7]['Hints'][42] = {};

TriviaBot_Questions[7]['Question'][43] = "The item 'Smite's Mighty Hammer' is what weapon-type?";
TriviaBot_Questions[7]['Answers'][43] = {"Mace",  "a mace"};
TriviaBot_Questions[7]['Category'][43] = 1;
TriviaBot_Questions[7]['Points'][43] = 1;
TriviaBot_Questions[7]['Hints'][43] = {};

TriviaBot_Questions[7]['Question'][44] = "_______ of Power consist of Zul'Gurub Coins, Bijous and Primal Hakkari items that can be obtained in Zul'Gurub.";
TriviaBot_Questions[7]['Answers'][44] = {"Paragons",  "Paragon"};
TriviaBot_Questions[7]['Category'][44] = 1;
TriviaBot_Questions[7]['Points'][44] = 1;
TriviaBot_Questions[7]['Hints'][44] = {};

TriviaBot_Questions[7]['Question'][45] = "Thane Korth'azz represents which of the 4 Horseman of the Apocalypse?";
TriviaBot_Questions[7]['Answers'][45] = {"Famine"};
TriviaBot_Questions[7]['Category'][45] = 1;
TriviaBot_Questions[7]['Points'][45] = 1;
TriviaBot_Questions[7]['Hints'][45] = {};

TriviaBot_Questions[7]['Question'][46] = "In order to summon the Avatar of Hakkar in the Sunken Temple, you need 4x of what item?";
TriviaBot_Questions[7]['Answers'][46] = {"Blood of Hakkar",  "blood"};
TriviaBot_Questions[7]['Category'][46] = 1;
TriviaBot_Questions[7]['Points'][46] = 1;
TriviaBot_Questions[7]['Hints'][46] = {};

TriviaBot_Questions[7]['Question'][47] = "Reginald Windsor plays a part in whose attunement chain?";
TriviaBot_Questions[7]['Answers'][47] = {"Onyxia Key",  "Onyxia", "Ony"};
TriviaBot_Questions[7]['Category'][47] = 1;
TriviaBot_Questions[7]['Points'][47] = 1;
TriviaBot_Questions[7]['Hints'][47] = {};

TriviaBot_Questions[7]['Question'][48] = "Gnomes can purchase their mount just outside Ironforge, at _______'s Depot.";
TriviaBot_Questions[7]['Answers'][48] = {"Steelgrill's Depot",  "Steelgrill", "Steelgrill's"};
TriviaBot_Questions[7]['Category'][48] = 1;
TriviaBot_Questions[7]['Points'][48] = 1;
TriviaBot_Questions[7]['Hints'][48] = {};

TriviaBot_Questions[7]['Question'][49] = "Who is the leader of The Watchers?";
TriviaBot_Questions[7]['Answers'][49] = {"Maiev",  "Maiev Shadowsong"};
TriviaBot_Questions[7]['Category'][49] = 1;
TriviaBot_Questions[7]['Points'][49] = 1;
TriviaBot_Questions[7]['Hints'][49] = {};

TriviaBot_Questions[7]['Question'][50] = "Which class can cast Moonfire?";
TriviaBot_Questions[7]['Answers'][50] = {"Druids",  "Druid"};
TriviaBot_Questions[7]['Category'][50] = 1;
TriviaBot_Questions[7]['Points'][50] = 1;
TriviaBot_Questions[7]['Hints'][50] = {};

TriviaBot_Questions[7]['Question'][51] = "By how much does a Priest's Inner Focus spell increase crit chance?";
TriviaBot_Questions[7]['Answers'][51] = {"25%",  "25"};
TriviaBot_Questions[7]['Category'][51] = 1;
TriviaBot_Questions[7]['Points'][51] = 1;
TriviaBot_Questions[7]['Hints'][51] = {};

TriviaBot_Questions[7]['Question'][52] = "Which class has a talent tree called 'protection'?";
TriviaBot_Questions[7]['Answers'][52] = {"Warriors",  "Warrior"};
TriviaBot_Questions[7]['Category'][52] = 1;
TriviaBot_Questions[7]['Points'][52] = 1;
TriviaBot_Questions[7]['Hints'][52] = {};

TriviaBot_Questions[7]['Question'][53] = "The first boss in AQ40 is called?";
TriviaBot_Questions[7]['Answers'][53] = {"The Prophet Skeram",  "Prophet Skeram", "Skeram"};
TriviaBot_Questions[7]['Category'][53] = 1;
TriviaBot_Questions[7]['Points'][53] = 1;
TriviaBot_Questions[7]['Hints'][53] = {};

TriviaBot_Questions[7]['Question'][54] = "How many primary languages are available by The Alliance in total?";
TriviaBot_Questions[7]['Answers'][54] = {"5",  "Five"};
TriviaBot_Questions[7]['Category'][54] = 1;
TriviaBot_Questions[7]['Points'][54] = 1;
TriviaBot_Questions[7]['Hints'][54] = {};

TriviaBot_Questions[7]['Question'][55] = " How many primary languages are spoken by The Horde in total?";
TriviaBot_Questions[7]['Answers'][55] = {"5",  "Five"};
TriviaBot_Questions[7]['Category'][55] = 1;
TriviaBot_Questions[7]['Points'][55] = 1;
TriviaBot_Questions[7]['Hints'][55] = {};

TriviaBot_Questions[7]['Question'][56] = "What language do demons speak?";
TriviaBot_Questions[7]['Answers'][56] = {"Eredun"};
TriviaBot_Questions[7]['Category'][56] = 1;
TriviaBot_Questions[7]['Points'][56] = 1;
TriviaBot_Questions[7]['Hints'][56] = {};

TriviaBot_Questions[7]['Question'][57] = "Which race is immune to undeath?";
TriviaBot_Questions[7]['Answers'][57] = {"Murlocs",  "Murloc"};
TriviaBot_Questions[7]['Category'][57] = 1;
TriviaBot_Questions[7]['Points'][57] = 1;
TriviaBot_Questions[7]['Hints'][57] = {};

TriviaBot_Questions[7]['Question'][58] = "Chromaggus's Brood Affliction: Blue is what kind of debuff type?";
TriviaBot_Questions[7]['Answers'][58] = {"magic"};
TriviaBot_Questions[7]['Category'][58] = 1;
TriviaBot_Questions[7]['Points'][58] = 1;
TriviaBot_Questions[7]['Hints'][58] = {};

TriviaBot_Questions[7]['Question'][59] = "Who is also known as the Ã�Â¢Ã¯Â¿Â½Ã¯Â¿Â½Destroyer of Dreams?";
TriviaBot_Questions[7]['Answers'][59] = {"Gul'dan "};
TriviaBot_Questions[7]['Category'][59] = 1;
TriviaBot_Questions[7]['Points'][59] = 1;
TriviaBot_Questions[7]['Hints'][59] = {};

TriviaBot_Questions[7]['Question'][60] = "Acronyms: What does ZF stand for?";
TriviaBot_Questions[7]['Answers'][60] = {"Zul'Farrak",  "zulfarrak", "zul farrak"};
TriviaBot_Questions[7]['Category'][60] = 1;
TriviaBot_Questions[7]['Points'][60] = 1;
TriviaBot_Questions[7]['Hints'][60] = {};

TriviaBot_Questions[7]['Question'][61] = "Acronyms: What does ZG stand for?";
TriviaBot_Questions[7]['Answers'][61] = {"Zul'Gurub",  "zulgurub", "zul gurub"};
TriviaBot_Questions[7]['Category'][61] = 1;
TriviaBot_Questions[7]['Points'][61] = 1;
TriviaBot_Questions[7]['Hints'][61] = {};

TriviaBot_Questions[7]['Question'][62] = "What being was supposedly created by the Old God, C'thun, as a mockery of life?";
TriviaBot_Questions[7]['Answers'][62] = {"Ouro",  "Ouro the Sandworm"};
TriviaBot_Questions[7]['Category'][62] = 1;
TriviaBot_Questions[7]['Points'][62] = 1;
TriviaBot_Questions[7]['Hints'][62] = {};

TriviaBot_Questions[7]['Question'][63] = "Acronyms: What does WTT stand for?";
TriviaBot_Questions[7]['Answers'][63] = {"Want To Trade"};
TriviaBot_Questions[7]['Category'][63] = 1;
TriviaBot_Questions[7]['Points'][63] = 1;
TriviaBot_Questions[7]['Hints'][63] = {};

TriviaBot_Questions[7]['Question'][64] = "Acronyms: What does NPC stand for?";
TriviaBot_Questions[7]['Answers'][64] = {"Non-Player Character",  "Non Player Character", "Non Playing Character"};
TriviaBot_Questions[7]['Category'][64] = 1;
TriviaBot_Questions[7]['Points'][64] = 1;
TriviaBot_Questions[7]['Hints'][64] = {};

TriviaBot_Questions[7]['Question'][65] = "Acronyms: What does ML stand for?";
TriviaBot_Questions[7]['Answers'][65] = {"Master Looter",  "Main Loot", "Masterloot", "Master Loot"};
TriviaBot_Questions[7]['Category'][65] = 1;
TriviaBot_Questions[7]['Points'][65] = 1;
TriviaBot_Questions[7]['Hints'][65] = {};

TriviaBot_Questions[7]['Question'][66] = "Acronyms: What does DPS stand for?";
TriviaBot_Questions[7]['Answers'][66] = {"damage per second"};
TriviaBot_Questions[7]['Category'][66] = 1;
TriviaBot_Questions[7]['Points'][66] = 1;
TriviaBot_Questions[7]['Hints'][66] = {};

TriviaBot_Questions[7]['Question'][67] = "Who is first boss in Ulduar?";
TriviaBot_Questions[7]['Answers'][67] = {"Flame Leviathan"};
TriviaBot_Questions[7]['Category'][67] = 1;
TriviaBot_Questions[7]['Points'][67] = 1;
TriviaBot_Questions[7]['Hints'][67] = {};

TriviaBot_Questions[7]['Question'][68] = "This boss in Ulduar can be found in the Colossal Forge?";
TriviaBot_Questions[7]['Answers'][68] = {"Ignis",  "Ignis the Furnace Master"};
TriviaBot_Questions[7]['Category'][68] = 1;
TriviaBot_Questions[7]['Points'][68] = 1;
TriviaBot_Questions[7]['Hints'][68] = {};

TriviaBot_Questions[7]['Question'][69] = "Which boss is an iron-bound drake in Ulduar?";
TriviaBot_Questions[7]['Answers'][69] = {"Razorscale"};
TriviaBot_Questions[7]['Category'][69] = 1;
TriviaBot_Questions[7]['Points'][69] = 1;
TriviaBot_Questions[7]['Hints'][69] = {};

TriviaBot_Questions[7]['Question'][70] = "Guess The Zone: A Desert Zone with a Goblin town in it.";
TriviaBot_Questions[7]['Answers'][70] = {"Tanaris"};
TriviaBot_Questions[7]['Category'][70] = 1;
TriviaBot_Questions[7]['Points'][70] = 1;
TriviaBot_Questions[7]['Hints'][70] = {};

TriviaBot_Questions[7]['Question'][71] = "Guess The Zone: A Tropical Zone, with lots of coastlines, and a Goblin Port.";
TriviaBot_Questions[7]['Answers'][71] = {"STV",  "Stranglethorn Vale"};
TriviaBot_Questions[7]['Category'][71] = 1;
TriviaBot_Questions[7]['Points'][71] = 1;
TriviaBot_Questions[7]['Hints'][71] = {};

TriviaBot_Questions[7]['Question'][72] = "Guess The Zone: Has volcanic terrain, and 'The Cauldron'.";
TriviaBot_Questions[7]['Answers'][72] = {"Searing Gorge"};
TriviaBot_Questions[7]['Category'][72] = 1;
TriviaBot_Questions[7]['Points'][72] = 1;
TriviaBot_Questions[7]['Hints'][72] = {};

TriviaBot_Questions[7]['Question'][73] = "Guess The Zone: A Tropical Zone, which has a dark portal, and a mountain you can parachute off.";
TriviaBot_Questions[7]['Answers'][73] = {"Feralas"};
TriviaBot_Questions[7]['Category'][73] = 1;
TriviaBot_Questions[7]['Points'][73] = 1;
TriviaBot_Questions[7]['Hints'][73] = {};

TriviaBot_Questions[7]['Question'][74] = "Guess The Zone: A Diseased wooded zone with special plants.";
TriviaBot_Questions[7]['Answers'][74] = {"Felwood"};
TriviaBot_Questions[7]['Category'][74] = 1;
TriviaBot_Questions[7]['Points'][74] = 1;
TriviaBot_Questions[7]['Hints'][74] = {};

TriviaBot_Questions[7]['Question'][75] = "Guess The Zone: A Winter Zone which has hot springs.";
TriviaBot_Questions[7]['Answers'][75] = {"Winterspring"};
TriviaBot_Questions[7]['Category'][75] = 1;
TriviaBot_Questions[7]['Points'][75] = 1;
TriviaBot_Questions[7]['Hints'][75] = {};

TriviaBot_Questions[7]['Question'][76] = "Who convinced Illidan to use the Skull of Gul'dan?";
TriviaBot_Questions[7]['Answers'][76] = {"Arthas"};
TriviaBot_Questions[7]['Category'][76] = 1;
TriviaBot_Questions[7]['Points'][76] = 1;
TriviaBot_Questions[7]['Hints'][76] = {};

TriviaBot_Questions[7]['Question'][77] = "The Maker's Terrace can be found outside which instance?";
TriviaBot_Questions[7]['Answers'][77] = {"Uldaman",  "Ulda"};
TriviaBot_Questions[7]['Category'][77] = 1;
TriviaBot_Questions[7]['Points'][77] = 1;
TriviaBot_Questions[7]['Hints'][77] = {};

TriviaBot_Questions[7]['Question'][78] = "What was the name of the ten year between the Nerubians and the Scourge?";
TriviaBot_Questions[7]['Answers'][78] = {"The War of the Spider "};
TriviaBot_Questions[7]['Category'][78] = 1;
TriviaBot_Questions[7]['Points'][78] = 1;
TriviaBot_Questions[7]['Hints'][78] = {};

TriviaBot_Questions[7]['Question'][79] = "Who was torn apart by Kil'Jaden only to have his spirit survive, imprison in armor and frozen over with unbreakable ice?";
TriviaBot_Questions[7]['Answers'][79] = {"Ner'zhul"};
TriviaBot_Questions[7]['Category'][79] = 1;
TriviaBot_Questions[7]['Points'][79] = 1;
TriviaBot_Questions[7]['Hints'][79] = {};

TriviaBot_Questions[7]['Question'][80] = "What is the cooldown of the 'Smelt Titansteel' skill?";
TriviaBot_Questions[7]['Answers'][80] = {"24 hours",  "1 day",  "one day"};
TriviaBot_Questions[7]['Category'][80] = 1;
TriviaBot_Questions[7]['Points'][80] = 1;
TriviaBot_Questions[7]['Hints'][80] = {};

TriviaBot_Questions[7]['Category'][80] = 1;
TriviaBot_Questions[7]['Points'][80] = 1;
TriviaBot_Questions[7]['Hints'][80] = {};

TriviaBot_Questions[7]['Question'][81] = "How many primary and secondary professions are there all together?";
TriviaBot_Questions[7]['Answers'][81] = {"Fourteen",  "14"};
TriviaBot_Questions[7]['Category'][81] = 1;
TriviaBot_Questions[7]['Points'][81] = 1;
TriviaBot_Questions[7]['Hints'][81] = {};

TriviaBot_Questions[7]['Question'][82] = "How many copper bars are required to make 1x copper chain pants?";
TriviaBot_Questions[7]['Answers'][82] = {"Four",  "4"};
TriviaBot_Questions[7]['Category'][82] = 1;
TriviaBot_Questions[7]['Points'][82] = 1;
TriviaBot_Questions[7]['Hints'][82] = {};

TriviaBot_Questions[7]['Question'][83] = "How much does a linen bandage heal for (per second)?";
TriviaBot_Questions[7]['Answers'][83] = {"Eleven",  "11"};
TriviaBot_Questions[7]['Category'][83] = 1;
TriviaBot_Questions[7]['Points'][83] = 1;
TriviaBot_Questions[7]['Hints'][83] = {};

TriviaBot_Questions[7]['Question'][84] = "What is the only class totally devoid of healing effects?";
TriviaBot_Questions[7]['Answers'][84] = {"Mage",  "Mages"};
TriviaBot_Questions[7]['Category'][84] = 1;
TriviaBot_Questions[7]['Points'][84] = 1;
TriviaBot_Questions[7]['Hints'][84] = {};

TriviaBot_Questions[7]['Question'][85] = "Which Horde races cannot be a Shaman?";
TriviaBot_Questions[7]['Answers'][85] = {"Undeads and Blood Elves",  "Blood Elves and Undeads"};
TriviaBot_Questions[7]['Category'][85] = 1;
TriviaBot_Questions[7]['Points'][85] = 1;
TriviaBot_Questions[7]['Hints'][85] = {};

TriviaBot_Questions[7]['Question'][86] = "The Valley Of Trials is the starting area for which races (name at least one)?";
TriviaBot_Questions[7]['Answers'][86] = {"Orcs and Trolls",  "Orcs", "Trolls"};
TriviaBot_Questions[7]['Category'][86] = 1;
TriviaBot_Questions[7]['Points'][86] = 1;
TriviaBot_Questions[7]['Hints'][86] = {};

TriviaBot_Questions[7]['Question'][87] = "How many weapon types are there (like one-handed sword, two-handed sword, dagger etc.)?";
TriviaBot_Questions[7]['Answers'][87] = {"Sixteen",  "16"};
TriviaBot_Questions[7]['Category'][87] = 1;
TriviaBot_Questions[7]['Points'][87] = 1;
TriviaBot_Questions[7]['Hints'][87] = {};

TriviaBot_Questions[7]['Question'][88] = "What is the name of the zone that lies west of Tanaris?";
TriviaBot_Questions[7]['Answers'][88] = {"Un'Goro Crater",  "Un'Goro", "UnGoro"};
TriviaBot_Questions[7]['Category'][88] = 1;
TriviaBot_Questions[7]['Points'][88] = 1;
TriviaBot_Questions[7]['Hints'][88] = {};

TriviaBot_Questions[7]['Question'][89] = "Who is the famous raid boss in Elywnn Forest?";
TriviaBot_Questions[7]['Answers'][89] = {"Hogger"};
TriviaBot_Questions[7]['Category'][89] = 1;
TriviaBot_Questions[7]['Points'][89] = 1;
TriviaBot_Questions[7]['Hints'][89] = {};

TriviaBot_Questions[7]['Question'][90] = "What continent in Azeroth has two Horde capital cities?";
TriviaBot_Questions[7]['Answers'][90] = {"Kalimdor"};
TriviaBot_Questions[7]['Category'][90] = 1;
TriviaBot_Questions[7]['Points'][90] = 1;
TriviaBot_Questions[7]['Hints'][90] = {};

TriviaBot_Questions[7]['Question'][91] = "Attempting to swim the Great Sea will ultimatly lead to death by _____?";
TriviaBot_Questions[7]['Answers'][91] = {"Fatigue"};
TriviaBot_Questions[7]['Category'][91] = 1;
TriviaBot_Questions[7]['Points'][91] = 1;
TriviaBot_Questions[7]['Hints'][91] = {};

TriviaBot_Questions[7]['Question'][92] = "Name one of the continents in Azeroth that actually is ingame and accessible?";
TriviaBot_Questions[7]['Answers'][92] = {"Eastern Kingdoms",  "Kalimdor"};
TriviaBot_Questions[7]['Category'][92] = 1;
TriviaBot_Questions[7]['Points'][92] = 1;
TriviaBot_Questions[7]['Hints'][92] = {};

TriviaBot_Questions[7]['Question'][93] = "What new profession came in the expansion? (full name)";
TriviaBot_Questions[7]['Answers'][93] = {"Inscription"};
TriviaBot_Questions[7]['Category'][93] = 1;
TriviaBot_Questions[7]['Points'][93] = 1;
TriviaBot_Questions[7]['Hints'][93] = {};

TriviaBot_Questions[7]['Question'][94] = "Essence of the Red in the Vaelastrasz encounter restores how much energy per second?";
TriviaBot_Questions[7]['Answers'][94] = {"Fifty",  "50"};
TriviaBot_Questions[7]['Category'][94] = 1;
TriviaBot_Questions[7]['Points'][94] = 1;
TriviaBot_Questions[7]['Hints'][94] = {};

TriviaBot_Questions[7]['Question'][95] = "The transport mechanism between the southern Barrens and Thousand Needles is called?";
TriviaBot_Questions[7]['Answers'][95] = {"The Great Lift",  "great lift"};

TriviaBot_Questions[7]['Category'][95] = 1;
TriviaBot_Questions[7]['Points'][95] = 1;
TriviaBot_Questions[7]['Hints'][95] = {};

TriviaBot_Questions[7]['Question'][96] = "'Skull Rock' is found in which zone?";
TriviaBot_Questions[7]['Answers'][96] = {"Durotar"};
TriviaBot_Questions[7]['Category'][96] = 1;
TriviaBot_Questions[7]['Points'][96] = 1;
TriviaBot_Questions[7]['Hints'][96] = {};

TriviaBot_Questions[7]['Question'][97] = "Sven and Lars can be found at which camp?";
TriviaBot_Questions[7]['Answers'][97] = {"Rebel Camp",  "Rebel"};
TriviaBot_Questions[7]['Category'][97] = 1;
TriviaBot_Questions[7]['Points'][97] = 1;
TriviaBot_Questions[7]['Hints'][97] = {};

TriviaBot_Questions[7]['Question'][98] = "Larion's companion in Un'Goro Crater is called?";
TriviaBot_Questions[7]['Answers'][98] = {"Muigin",  "Muigi"};
TriviaBot_Questions[7]['Category'][98] = 1;
TriviaBot_Questions[7]['Points'][98] = 1;
TriviaBot_Questions[7]['Hints'][98] = {};

TriviaBot_Questions[7]['Question'][99] = "Sten Stoutarm starts intrepid adventurers of which race(s) on their first quest?";
TriviaBot_Questions[7]['Answers'][99] = {"Gnomes and dwarves",  "Gnomes", "dwarves"};
TriviaBot_Questions[7]['Category'][99] = 1;
TriviaBot_Questions[7]['Points'][99] = 1;
TriviaBot_Questions[7]['Hints'][99] = {};

TriviaBot_Questions[7]['Question'][100] = "The Icebane set grants resistence to which school of magic?";
TriviaBot_Questions[7]['Answers'][100] = {"Frost"};
TriviaBot_Questions[7]['Category'][100] = 1;
TriviaBot_Questions[7]['Points'][100] = 1;
TriviaBot_Questions[7]['Hints'][100] = {};

TriviaBot_Questions[7]['Question'][101] = "The 'Banner of Provocation' is used in which questline?";
TriviaBot_Questions[7]['Answers'][101] = {"tier 0.5",  "t0.5"};
TriviaBot_Questions[7]['Category'][101] = 1;
TriviaBot_Questions[7]['Points'][101] = 1;
TriviaBot_Questions[7]['Hints'][101] = {};

TriviaBot_Questions[7]['Question'][102] = "Sarltooth in the Wetlands is what type of beast?";
TriviaBot_Questions[7]['Answers'][102] = {"Raptor"};
TriviaBot_Questions[7]['Category'][102] = 1;
TriviaBot_Questions[7]['Points'][102] = 1;
TriviaBot_Questions[7]['Hints'][102] = {};

TriviaBot_Questions[7]['Question'][103] = "Light Feathers are used as a reagent by which class(es)?";
TriviaBot_Questions[7]['Answers'][103] = {"Mage and Priest",  "Mage", "Priest"};
TriviaBot_Questions[7]['Category'][103] = 1;
TriviaBot_Questions[7]['Points'][103] = 1;
TriviaBot_Questions[7]['Hints'][103] = {};

TriviaBot_Questions[7]['Question'][104] = "Who is the supreme commander of the Argent Crusade?";
TriviaBot_Questions[7]['Answers'][104] = {"Tirion Fordring",  "Tirion"};
TriviaBot_Questions[7]['Category'][104] = 1;
TriviaBot_Questions[7]['Points'][104] = 1;
TriviaBot_Questions[7]['Hints'][104] = {};

TriviaBot_Questions[7]['Question'][105] = "Jaina Proudmoore's father is called?";
TriviaBot_Questions[7]['Answers'][105] = {"Daelin Proudmoore",  "Daelin"};
TriviaBot_Questions[7]['Category'][105] = 1;
TriviaBot_Questions[7]['Points'][105] = 1;
TriviaBot_Questions[7]['Hints'][105] = {};

TriviaBot_Questions[7]['Question'][106] = "Cooking a 'Herb Baked Egg' requires which type of spice?";
TriviaBot_Questions[7]['Answers'][106] = {"Mild Spices",  "mild"};
TriviaBot_Questions[7]['Category'][106] = 1;
TriviaBot_Questions[7]['Points'][106] = 1;
TriviaBot_Questions[7]['Hints'][106] = {};

TriviaBot_Questions[7]['Question'][107] = "Huhuran's Stinger grants how much extra agility?";
TriviaBot_Questions[7]['Answers'][107] = {"Eighteen",  "18"};
TriviaBot_Questions[7]['Category'][107] = 1;
TriviaBot_Questions[7]['Points'][107] = 1;
TriviaBot_Questions[7]['Hints'][107] = {};

TriviaBot_Questions[7]['Question'][108] = "The 'Soulforge' set can only be used by which class?";
TriviaBot_Questions[7]['Answers'][108] = {"Paladins",  "Paladin"};
TriviaBot_Questions[7]['Category'][108] = 1;
TriviaBot_Questions[7]['Points'][108] = 1;
TriviaBot_Questions[7]['Hints'][108] = {};

TriviaBot_Questions[7]['Question'][109] = "The Twilight Vale can be found in which zone?";
TriviaBot_Questions[7]['Answers'][109] = {"Darkshore"};
TriviaBot_Questions[7]['Category'][109] = 1;
TriviaBot_Questions[7]['Points'][109] = 1;
TriviaBot_Questions[7]['Hints'][109] = {};

TriviaBot_Questions[7]['Question'][110] = "What is the duration on Prayer of Shadow Protection?";
TriviaBot_Questions[7]['Answers'][110] = {"20 Minutes",  "20 min", "20 mins"};
TriviaBot_Questions[7]['Category'][110] = 1;
TriviaBot_Questions[7]['Points'][110] = 1;
TriviaBot_Questions[7]['Hints'][110] = {};

TriviaBot_Questions[7]['Question'][111] = "How many tracks is there in The Burning Crusade soundtrack?";
TriviaBot_Questions[7]['Answers'][111] = {"22",  "twenty two", "twenty-two"};
TriviaBot_Questions[7]['Category'][111] = 1;
TriviaBot_Questions[7]['Points'][111] = 1;
TriviaBot_Questions[7]['Hints'][111] = {};

TriviaBot_Questions[7]['Question'][112] = "Sir Zeliek represents which of the 4 Horseman of the Apocalypse?";
TriviaBot_Questions[7]['Answers'][112] = {"Pestilence"};
TriviaBot_Questions[7]['Category'][112] = 1;
TriviaBot_Questions[7]['Points'][112] = 1;
TriviaBot_Questions[7]['Hints'][112] = {};

TriviaBot_Questions[7]['Question'][113] = "The Doom Touched Warriors are found in which instance?";
TriviaBot_Questions[7]['Answers'][113] = {"Naxxramas",  "Naxx"};
TriviaBot_Questions[7]['Category'][113] = 1;
TriviaBot_Questions[7]['Points'][113] = 1;
TriviaBot_Questions[7]['Hints'][113] = {};

TriviaBot_Questions[7]['Question'][114] = "What will undead NPC's not do?";
TriviaBot_Questions[7]['Answers'][114] = {"Swim",  "swimming"};
TriviaBot_Questions[7]['Category'][114] = 1;
TriviaBot_Questions[7]['Points'][114] = 1;
TriviaBot_Questions[7]['Hints'][114] = {};

TriviaBot_Questions[7]['Question'][115] = "What is the Wildbend River called further upstream?";
TriviaBot_Questions[7]['Answers'][115] = {"Bloodvenom River",  "Bloodvenom"};
TriviaBot_Questions[7]['Category'][115] = 1;
TriviaBot_Questions[7]['Points'][115] = 1;
TriviaBot_Questions[7]['Hints'][115] = {};

TriviaBot_Questions[7]['Question'][116] = "The NPC Donni Anthania sells which kind of non-combat pet?";
TriviaBot_Questions[7]['Answers'][116] = {"cats",  "cat"};
TriviaBot_Questions[7]['Category'][116] = 1;
TriviaBot_Questions[7]['Points'][116] = 1;
TriviaBot_Questions[7]['Hints'][116] = {};

TriviaBot_Questions[7]['Question'][117] = "Which titan created the skies and seas of Azeroth and constantly has lightning shooting out of eyes?";
TriviaBot_Questions[7]['Answers'][117] = {"Golganneth"};
TriviaBot_Questions[7]['Category'][117] = 1;
TriviaBot_Questions[7]['Points'][117] = 1;
TriviaBot_Questions[7]['Hints'][117] = {}; 

TriviaBot_Questions[7]['Question'][118] = "To get a pet chicken (Chicken Egg) players must complete which quest?";
TriviaBot_Questions[7]['Answers'][118] = {"CLUCK!",  "cluck"};
TriviaBot_Questions[7]['Category'][118] = 1;
TriviaBot_Questions[7]['Points'][118] = 1;
TriviaBot_Questions[7]['Hints'][118] = {};

TriviaBot_Questions[7]['Question'][119] = "Which titan is the master of the forge and created Khaz'Modan where Ironforge is located?";
TriviaBot_Questions[7]['Answers'][119] = {"Khaz'goroth"};
TriviaBot_Questions[7]['Category'][119] = 1;
TriviaBot_Questions[7]['Points'][119] = 1;
TriviaBot_Questions[7]['Hints'][119] = {};

TriviaBot_Questions[7]['Question'][120] = "What is the biggest lake in Azeroth?";
TriviaBot_Questions[7]['Answers'][120] = {"Lordamere Lake",  "Lordamere"};
TriviaBot_Questions[7]['Category'][120] = 1;
TriviaBot_Questions[7]['Points'][120] = 1;
TriviaBot_Questions[7]['Hints'][120] = {};

TriviaBot_Questions[7]['Question'][121] = "Upon using an Orb of Deception, what race will a dwarf turn into?";
TriviaBot_Questions[7]['Answers'][121] = {"Darkspear Troll",  "Troll"};
TriviaBot_Questions[7]['Category'][121] = 1;
TriviaBot_Questions[7]['Points'][121] = 1;
TriviaBot_Questions[7]['Hints'][121] = {};

TriviaBot_Questions[7]['Question'][122] = "Who is the father of the dreaded Lord of Blackrock, Nefarian?";
TriviaBot_Questions[7]['Answers'][122] = {"Neltharion",  "Deathwing", "The Earth-warder", "Neltharion the Earth-Warder"};
TriviaBot_Questions[7]['Category'][122] = 1;
TriviaBot_Questions[7]['Points'][122] = 1;
TriviaBot_Questions[7]['Hints'][122] = {};

TriviaBot_Questions[7]['Question'][123] = "What is the name of the original World Tree?";
TriviaBot_Questions[7]['Answers'][123] = {"Nordrassil"};
TriviaBot_Questions[7]['Category'][123] = 1;
TriviaBot_Questions[7]['Points'][123] = 1;
TriviaBot_Questions[7]['Hints'][123] = {};

TriviaBot_Questions[7]['Question'][124] = "How many people does it take to perform to summon at a Meeting Stone?";
TriviaBot_Questions[7]['Answers'][124] = {"Two",  "2"};
TriviaBot_Questions[7]['Category'][124] = 1;
TriviaBot_Questions[7]['Points'][124] = 1;
TriviaBot_Questions[7]['Hints'][124] = {};

TriviaBot_Questions[7]['Question'][125] = "The Beast with a Thousand Maws is also known as what?";
TriviaBot_Questions[7]['Answers'][125] = {"Yogg-Saron"};
TriviaBot_Questions[7]['Category'][125] = 1;
TriviaBot_Questions[7]['Points'][125] = 1;
TriviaBot_Questions[7]['Hints'][125] = {};

TriviaBot_Questions[7]['Question'][126] = "Who is Lokens brother?";
TriviaBot_Questions[7]['Answers'][126] = {"Thorim"};
TriviaBot_Questions[7]['Category'][126] = 1;
TriviaBot_Questions[7]['Points'][126] = 1;
TriviaBot_Questions[7]['Hints'][126] = {};

TriviaBot_Questions[7]['Question'][128] = "What is the name of the hammer Thorim uses?";
TriviaBot_Questions[7]['Answers'][128] = {"Krolmir, Hammer of Storms",  "Krolmir"};
TriviaBot_Questions[7]['Category'][128] = 1;
TriviaBot_Questions[7]['Points'][128] = 1;
TriviaBot_Questions[7]['Hints'][128] = {};

TriviaBot_Questions[7]['Question'][128] = "Who is the brother of Sargeras?";
TriviaBot_Questions[7]['Answers'][128] = {"Aman'Thul"};
TriviaBot_Questions[7]['Category'][128] = 1;
TriviaBot_Questions[7]['Points'][128] = 1;
TriviaBot_Questions[7]['Hints'][128] = {};

TriviaBot_Questions[7]['Question'][129] = "Which faction do you get a Mysterious Egg from?";
TriviaBot_Questions[7]['Answers'][129] = {"The Oracles",  "Oracles"};
TriviaBot_Questions[7]['Category'][129] = 1;
TriviaBot_Questions[7]['Points'][129] = 1;
TriviaBot_Questions[7]['Hints'][129] = {};

TriviaBot_Questions[7]['Question'][130] = "Which class(es) has a restoration talent tree? (name both or one of them)";
TriviaBot_Questions[7]['Answers'][130] = {"Druid",  "Shaman", "Shamans", "Druids", "Druid and Shaman", "Druids and Shamans", "Shaman and Druid", "Shamans and Druids"};
TriviaBot_Questions[7]['Category'][130] = 1;
TriviaBot_Questions[7]['Points'][130] = 1;
TriviaBot_Questions[7]['Hints'][130] = {};

TriviaBot_Questions[7]['Question'][131] = "Who is the current leader of the Kirin Tor?";
TriviaBot_Questions[7]['Answers'][131] = {"Rhonin"};
TriviaBot_Questions[7]['Category'][131] = 1;
TriviaBot_Questions[7]['Points'][131] = 1;
TriviaBot_Questions[7]['Hints'][131] = {};

TriviaBot_Questions[7]['Question'][132] = "Which racial skill breaks fear effects?";
TriviaBot_Questions[7]['Answers'][132] = {"Will of the Forsaken",  "wotf"};
TriviaBot_Questions[7]['Category'][132] = 1;
TriviaBot_Questions[7]['Points'][132] = 1;
TriviaBot_Questions[7]['Hints'][132] = {};

TriviaBot_Questions[7]['Question'][133] = "What are level 80 Mages always asked for before raids begin?";
TriviaBot_Questions[7]['Answers'][133] = {"Table",  "Pop Table",  "Mage Table"};
TriviaBot_Questions[7]['Category'][133] = 1;
TriviaBot_Questions[7]['Points'][133] = 1;
TriviaBot_Questions[7]['Hints'][133] = {};

TriviaBot_Questions[7]['Question'][134] = "Who is the sister of Arthas?";
TriviaBot_Questions[7]['Answers'][134] = {"Calia",  "Calia Menethil"};
TriviaBot_Questions[7]['Category'][134] = 1;
TriviaBot_Questions[7]['Points'][134] = 1;
TriviaBot_Questions[7]['Hints'][134] = {};

TriviaBot_Questions[7]['Question'][135] = "What is the hardest race to target in a Battleground?";
TriviaBot_Questions[7]['Answers'][135] = {"Gnome",  "Gnomes"};
TriviaBot_Questions[7]['Category'][135] = 1;
TriviaBot_Questions[7]['Points'][135] = 1;
TriviaBot_Questions[7]['Hints'][135] = {};

TriviaBot_Questions[7]['Question'][136] = "Who was the father of Arthas?";
TriviaBot_Questions[7]['Answers'][136] = {"King Terenas",  "Terenas",  "King Terenas Menethil",  "Terenas Menthil"};
TriviaBot_Questions[7]['Category'][136] = 1;
TriviaBot_Questions[7]['Points'][136] = 1;
TriviaBot_Questions[7]['Hints'][136] = {};

TriviaBot_Questions[7]['Question'][137] = "Where can you get Tier 8?";
TriviaBot_Questions[7]['Answers'][137] = {"Ulduar"};
TriviaBot_Questions[7]['Category'][137] = 1;
TriviaBot_Questions[7]['Points'][137] = 1;
TriviaBot_Questions[7]['Hints'][137] = {};

TriviaBot_Questions[7]['Question'][138] = "Which element slows Viscidus, and is needed in order to defeat him?";
TriviaBot_Questions[7]['Answers'][138] = {"Frost"};
TriviaBot_Questions[7]['Category'][138] = 1;
TriviaBot_Questions[7]['Points'][138] = 1;
TriviaBot_Questions[7]['Hints'][138] = {};

TriviaBot_Questions[7]['Question'][139] = "How many bosses can drop tier 2 gloves in Blackwing Lair?";
TriviaBot_Questions[7]['Answers'][139] = {"Three",  "3"};
TriviaBot_Questions[7]['Category'][139] = 1;
TriviaBot_Questions[7]['Points'][139] = 1;
TriviaBot_Questions[7]['Hints'][139] = {};

TriviaBot_Questions[7]['Question'][140] = "Who is known as 'The Ashbringer'?";
TriviaBot_Questions[7]['Answers'][140] = {"Highlord Mograine",  "Mograine"};
TriviaBot_Questions[7]['Category'][140] = 1;
TriviaBot_Questions[7]['Points'][140] = 1;
TriviaBot_Questions[7]['Hints'][140] = {};

TriviaBot_Questions[7]['Question'][141] = "Which drop from Hakkar allows you to get 3 different epic trinkets? (full name)";
TriviaBot_Questions[7]['Answers'][141] = {"Heart of Hakkar"};
TriviaBot_Questions[7]['Category'][141] = 1;
TriviaBot_Questions[7]['Points'][141] = 1;
TriviaBot_Questions[7]['Hints'][141] = {};

TriviaBot_Questions[7]['Question'][142] = "What is the name of the horse Arthas rides?";
TriviaBot_Questions[7]['Answers'][142] = {"Invincible"};
TriviaBot_Questions[7]['Category'][142] = 1;
TriviaBot_Questions[7]['Points'][142] = 1;
TriviaBot_Questions[7]['Hints'][142] = {};

TriviaBot_Questions[7]['Question'][143] = "What herb is required for all the Greater Protection potions?";
TriviaBot_Questions[7]['Answers'][143] = {"Dreamfoil"};
TriviaBot_Questions[7]['Category'][143] = 1;
TriviaBot_Questions[7]['Points'][143] = 1;
TriviaBot_Questions[7]['Hints'][143] = {};

TriviaBot_Questions[7]['Question'][144] = "Which instance is located in Silverpine Forest?";
TriviaBot_Questions[7]['Answers'][144] = {"Shadowfang Keep",  "SFK"};
TriviaBot_Questions[7]['Category'][144] = 1;
TriviaBot_Questions[7]['Points'][144] = 1;
TriviaBot_Questions[7]['Hints'][144] = {};

TriviaBot_Questions[7]['Question'][145] = "At what percentage of health does Princess Huhuran enrage?";
TriviaBot_Questions[7]['Answers'][145] = {"30%",  "30", "thirty"};
TriviaBot_Questions[7]['Category'][145] = 1;
TriviaBot_Questions[7]['Points'][145] = 1;
TriviaBot_Questions[7]['Hints'][145] = {};

TriviaBot_Questions[7]['Question'][146] = "How much spellcrit does the 'Rallying Cry of the Dragonslayer' buff give?";
TriviaBot_Questions[7]['Answers'][146] = {"10",  "10%"};
TriviaBot_Questions[7]['Category'][146] = 1;
TriviaBot_Questions[7]['Points'][146] = 1;
TriviaBot_Questions[7]['Hints'][146] = {};

TriviaBot_Questions[7]['Question'][147] = "Which Naxxramas boss has two helpers called Stalagg and Fuegan?";
TriviaBot_Questions[7]['Answers'][147] = {"Thaddius"};
TriviaBot_Questions[7]['Category'][147] = 1;
TriviaBot_Questions[7]['Points'][147] = 1;
TriviaBot_Questions[7]['Hints'][147] = {};

TriviaBot_Questions[7]['Question'][148] = "Who drops the Hunter book 'Tranquilizing shot'?";
TriviaBot_Questions[7]['Answers'][148] = {"Lucifron"};
TriviaBot_Questions[7]['Category'][148] = 1;
TriviaBot_Questions[7]['Points'][148] = 1;
TriviaBot_Questions[7]['Hints'][148] = {};

TriviaBot_Questions[7]['Question'][149] = "Which class is often considered the main healing class?";
TriviaBot_Questions[7]['Answers'][149] = {"Priest"};
TriviaBot_Questions[7]['Category'][149] = 1;
TriviaBot_Questions[7]['Points'][149] = 1;
TriviaBot_Questions[7]['Hints'][149] = {};

TriviaBot_Questions[7]['Question'][150] = "How many tracks does the world of warcraft soundtrack have?";
TriviaBot_Questions[7]['Answers'][150] = {"30",  "thirty"};
TriviaBot_Questions[7]['Category'][150] = 1;
TriviaBot_Questions[7]['Points'][150] = 1;
TriviaBot_Questions[7]['Hints'][150] = {};

TriviaBot_Questions[7]['Question'][151] = "How much rage does the improved berserker rage talent (2/2) generate?";
TriviaBot_Questions[7]['Answers'][151] = {"10",  "ten"};
TriviaBot_Questions[7]['Category'][151] = 1;
TriviaBot_Questions[7]['Points'][151] = 1;
TriviaBot_Questions[7]['Hints'][151] = {};

TriviaBot_Questions[7]['Question'][152] = "How long does the unimproved Shield Wall last? ( ___ sec)";
TriviaBot_Questions[7]['Answers'][152] = {"10 seconds",  "10", "ten", "ten secs", "ten sec", "10 sec"};
TriviaBot_Questions[7]['Category'][152] = 1;
TriviaBot_Questions[7]['Points'][152] = 1;
TriviaBot_Questions[7]['Hints'][152] = {};

TriviaBot_Questions[7]['Question'][153] = "What tree is Improved Berserker Stance talent on?";
TriviaBot_Questions[7]['Answers'][153] = {"Fury"};
TriviaBot_Questions[7]['Category'][153] = 1;
TriviaBot_Questions[7]['Points'][153] = 1;
TriviaBot_Questions[7]['Hints'][153] = {};

TriviaBot_Questions[7]['Question'][154] = "How much damage does each point of rage convert into on the last rank of Execute if your level 70?";
TriviaBot_Questions[7]['Answers'][154] = {"18",  "eighteen"};
TriviaBot_Questions[7]['Category'][154] = 1;
TriviaBot_Questions[7]['Points'][154] = 1;
TriviaBot_Questions[7]['Hints'][154] = {};

TriviaBot_Questions[7]['Question'][155] = "Switching Stances constantly as a Warrior is called?";
TriviaBot_Questions[7]['Answers'][155] = {"stance dance",  "stance dancing", "stance-dancing", "stance-dance"};
TriviaBot_Questions[7]['Category'][155] = 1;
TriviaBot_Questions[7]['Points'][155] = 1;
TriviaBot_Questions[7]['Hints'][155] = {};

TriviaBot_Questions[7]['Question'][156] = "The last rank of Sunder Armor reduces armor by how much?";
TriviaBot_Questions[7]['Answers'][156] = {"520",  "Five hundred twenty"};
TriviaBot_Questions[7]['Category'][156] = 1;
TriviaBot_Questions[7]['Points'][156] = 1;
TriviaBot_Questions[7]['Hints'][156] = {};

TriviaBot_Questions[7]['Question'][157] = "Piercing Howl reduces the movement speed of enemies by what percentage?";
TriviaBot_Questions[7]['Answers'][157] = {"50%",  "50", "fifty"};
TriviaBot_Questions[7]['Category'][157] = 1;
TriviaBot_Questions[7]['Points'][157] = 1;
TriviaBot_Questions[7]['Hints'][157] = {};

TriviaBot_Questions[7]['Question'][158] = "Overpower can only be used after the target does what?";
TriviaBot_Questions[7]['Answers'][158] = {"dodge",  "dodges"};
TriviaBot_Questions[7]['Category'][158] = 1;
TriviaBot_Questions[7]['Points'][158] = 1;
TriviaBot_Questions[7]['Hints'][158] = {};

TriviaBot_Questions[7]['Question'][159] = "The talent Blood Craze can be found in which talent tree?";
TriviaBot_Questions[7]['Answers'][159] = {"Fury"};
TriviaBot_Questions[7]['Category'][159] = 1;
TriviaBot_Questions[7]['Points'][159] = 1;
TriviaBot_Questions[7]['Hints'][159] = {};

TriviaBot_Questions[7]['Question'][160] = "Rend (Rank 8) causes ___ damage over 21 secs.";
TriviaBot_Questions[7]['Answers'][160] = {"182",  "One hundred eighty two"};
TriviaBot_Questions[7]['Category'][160] = 1;
TriviaBot_Questions[7]['Points'][160] = 1;
TriviaBot_Questions[7]['Hints'][160] = {};

TriviaBot_Questions[7]['Question'][161] = "Which Warrior ability reduces healing effects by 50%?";
TriviaBot_Questions[7]['Answers'][161] = {"Mortal Strike",  "MS"};
TriviaBot_Questions[7]['Category'][161] = 1;
TriviaBot_Questions[7]['Points'][161] = 1;
TriviaBot_Questions[7]['Hints'][161] = {};

TriviaBot_Questions[7]['Question'][162] = "Which sword was too powerful to be included in the game? (hint: Southpark)";
TriviaBot_Questions[7]['Answers'][162] = {"The Sword of a Thousand Truths",  "sword of a thousand truths", "sword of a 1000 truths"};
TriviaBot_Questions[7]['Category'][162] = 1;
TriviaBot_Questions[7]['Points'][162] = 1;
TriviaBot_Questions[7]['Hints'][162] = {};

TriviaBot_Questions[7]['Question'][163] = "How much spell damage does the Zandalarian Hero Charm increase?";
TriviaBot_Questions[7]['Answers'][163] = {"204",  "two hundred four"};
TriviaBot_Questions[7]['Category'][163] = 1;
TriviaBot_Questions[7]['Points'][163] = 1;
TriviaBot_Questions[7]['Hints'][163] = {};

TriviaBot_Questions[7]['Question'][164] = "Which races could use the Mechanostrider Mount before the patch? (x and y)";
TriviaBot_Questions[7]['Answers'][164] = {"dwarves and Gnomes",  "Dwarf and Gnome",  "Gnomes and dwarves"};
TriviaBot_Questions[7]['Category'][164] = 1;
TriviaBot_Questions[7]['Points'][164] = 1;
TriviaBot_Questions[7]['Hints'][164] = {};

TriviaBot_Questions[7]['Question'][165] = "How long cooldown does the Zandalarian Hero Charm have?";
TriviaBot_Questions[7]['Answers'][165] = {"2 minutes",  "2 min", "2", "2 mins", "two minutes", "two min", "two", "two mins"};
TriviaBot_Questions[7]['Category'][165] = 1;
TriviaBot_Questions[7]['Points'][165] = 1;
TriviaBot_Questions[7]['Hints'][165] = {};

TriviaBot_Questions[7]['Question'][166] = "Which guild made the world first kill of Cthun?";
TriviaBot_Questions[7]['Answers'][166] = {"Nihilum"};
TriviaBot_Questions[7]['Category'][166] = 1;
TriviaBot_Questions[7]['Points'][166] = 1;
TriviaBot_Questions[7]['Hints'][166] = {};

TriviaBot_Questions[7]['Question'][167] = "What is Mages with talents mainly in Frost and Fire called?";
TriviaBot_Questions[7]['Answers'][167] = {"Elemental",  "Elemental Mages"};
TriviaBot_Questions[7]['Category'][167] = 1;
TriviaBot_Questions[7]['Points'][167] = 1;
TriviaBot_Questions[7]['Hints'][167] = {};

TriviaBot_Questions[7]['Question'][168] = "What two things can a Mage polymorph his foe into, besides a sheep? (x and y)";
TriviaBot_Questions[7]['Answers'][168] = {"Pig and Turtle",  "Turtle and Pig"};
TriviaBot_Questions[7]['Category'][168] = 1;
TriviaBot_Questions[7]['Points'][168] = 1;
TriviaBot_Questions[7]['Hints'][168] = {};

TriviaBot_Questions[7]['Question'][169] = "Which boss drops Ashkandi, greatsword of the Brotherhood?";
TriviaBot_Questions[7]['Answers'][169] = {"Nefarian"};
TriviaBot_Questions[7]['Category'][169] = 1;
TriviaBot_Questions[7]['Points'][169] = 1;
TriviaBot_Questions[7]['Hints'][169] = {};

TriviaBot_Questions[7]['Question'][170] = "What beast is Grimclaw, which patrols Darkshore?";
TriviaBot_Questions[7]['Answers'][170] = {"Bear",  "Icebear", "Ice-bear"};
TriviaBot_Questions[7]['Category'][170] = 1;
TriviaBot_Questions[7]['Points'][170] = 1;
TriviaBot_Questions[7]['Hints'][170] = {};

TriviaBot_Questions[7]['Question'][171] = "How many people are there in a full party?";
TriviaBot_Questions[7]['Answers'][171] = {"5",  "five"};
TriviaBot_Questions[7]['Category'][171] = 1;
TriviaBot_Questions[7]['Points'][171] = 1;
TriviaBot_Questions[7]['Hints'][171] = {};

TriviaBot_Questions[7]['Question'][172] = "How many people are there in a full raid?";
TriviaBot_Questions[7]['Answers'][172] = {"40",  "forty"};
TriviaBot_Questions[7]['Category'][172] = 1;
TriviaBot_Questions[7]['Points'][172] = 1;
TriviaBot_Questions[7]['Hints'][172] = {};

TriviaBot_Questions[7]['Question'][173] = "Who can teach you how to use one handed swords in Stormwind?";
TriviaBot_Questions[7]['Answers'][173] = {"Wu Ping"};
TriviaBot_Questions[7]['Category'][173] = 1;
TriviaBot_Questions[7]['Points'][173] = 1;
TriviaBot_Questions[7]['Hints'][173] = {};

TriviaBot_Questions[7]['Question'][174] = "Curse of agony ticks every ___ seconds?";
TriviaBot_Questions[7]['Answers'][174] = {"Two",  "2"};
TriviaBot_Questions[7]['Category'][174] = 1;
TriviaBot_Questions[7]['Points'][174] = 1;
TriviaBot_Questions[7]['Hints'][174] = {};

TriviaBot_Questions[7]['Question'][175] = "Curse of doom ticks for how much base damage?";
TriviaBot_Questions[7]['Answers'][175] = {"4200",  "four thousand two hundred"};
TriviaBot_Questions[7]['Category'][175] = 1;
TriviaBot_Questions[7]['Points'][175] = 1;
TriviaBot_Questions[7]['Hints'][175] = {};

TriviaBot_Questions[7]['Question'][176] = "How many statues is there outside Stormwind?";
TriviaBot_Questions[7]['Answers'][176] = {"6",  "Six"};
TriviaBot_Questions[7]['Category'][176] = 1;
TriviaBot_Questions[7]['Points'][176] = 1;
TriviaBot_Questions[7]['Hints'][176] = {};

TriviaBot_Questions[7]['Question'][177] = "Where is the Valley of Heroes?";
TriviaBot_Questions[7]['Answers'][177] = {"Stormwind",  "SW"};
TriviaBot_Questions[7]['Category'][177] = 1;
TriviaBot_Questions[7]['Points'][177] = 1;
TriviaBot_Questions[7]['Hints'][177] = {};

TriviaBot_Questions[7]['Question'][178] = "Where is the Valley of Kings?";
TriviaBot_Questions[7]['Answers'][178] = {"Loch Modan"};
TriviaBot_Questions[7]['Category'][178] = 1;
TriviaBot_Questions[7]['Points'][178] = 1;
TriviaBot_Questions[7]['Hints'][178] = {};

TriviaBot_Questions[7]['Question'][179] = "Which class originally soloed Kazzak?";
TriviaBot_Questions[7]['Answers'][179] = {"Paladin",  "Paladins"};
TriviaBot_Questions[7]['Category'][179] = 1;
TriviaBot_Questions[7]['Points'][179] = 1;
TriviaBot_Questions[7]['Hints'][179] = {};

TriviaBot_Questions[7]['Question'][180] = "How many DoTs can a warlock have as abilities?";
TriviaBot_Questions[7]['Answers'][180] = {"5",  "Five"};
TriviaBot_Questions[7]['Category'][180] = 1;
TriviaBot_Questions[7]['Points'][180] = 1;
TriviaBot_Questions[7]['Hints'][180] = {};

TriviaBot_Questions[7]['Question'][181] = "Name a DoT which was added to the Warlock class in TBC?";
TriviaBot_Questions[7]['Answers'][181] = {"Unstable Affliction",  "Seed of Corruption"};
TriviaBot_Questions[7]['Category'][181] = 1;
TriviaBot_Questions[7]['Points'][181] = 1;
TriviaBot_Questions[7]['Hints'][181] = {};

TriviaBot_Questions[7]['Question'][182] = "What class besides a Warrior has a talent tree called protection?";
TriviaBot_Questions[7]['Answers'][182] = {"Paladin",  "Paladins"};
TriviaBot_Questions[7]['Category'][182] = 1;
TriviaBot_Questions[7]['Points'][182] = 1;
TriviaBot_Questions[7]['Hints'][182] = {};

TriviaBot_Questions[7]['Question'][183] = "Before the Paladin revamp, what was the top tier spell in the retribution tree of Paladins?";
TriviaBot_Questions[7]['Answers'][183] = {"Blessing of Kings",  "BoK"};
TriviaBot_Questions[7]['Category'][183] = 1;
TriviaBot_Questions[7]['Points'][183] = 1;
TriviaBot_Questions[7]['Hints'][183] = {};

TriviaBot_Questions[7]['Question'][184] = "How many capital cities was there ingame, including Shattrath before WOTLK?";
TriviaBot_Questions[7]['Answers'][184] = {"9",  "Nine"};
TriviaBot_Questions[7]['Category'][184] = 1;
TriviaBot_Questions[7]['Points'][184] = 1;
TriviaBot_Questions[7]['Hints'][184] = {};

TriviaBot_Questions[7]['Question'][185] = "On which boss in Naxxramas do you have to mind control a mob, but not use it for more than 5 seconds?";
TriviaBot_Questions[7]['Answers'][185] = {"Grand widow faerlina",  "Faerlina"};
TriviaBot_Questions[7]['Category'][185] = 1;
TriviaBot_Questions[7]['Points'][185] = 1;
TriviaBot_Questions[7]['Hints'][185] = {};

TriviaBot_Questions[7]['Question'][186] = "What is the Alliance equivelent to Will of the Forsaken? (gives a great advantage against a certain class)";
TriviaBot_Questions[7]['Answers'][186] = {"perception"};
TriviaBot_Questions[7]['Category'][186] = 1;
TriviaBot_Questions[7]['Points'][186] = 1;
TriviaBot_Questions[7]['Hints'][186] = {};

TriviaBot_Questions[7]['Question'][187] = "Who originally dropped the lightforge gauntlets?";
TriviaBot_Questions[7]['Answers'][187] = {"Emperor Dagran Thaurissan",  "Dagran Thaurissan"};
TriviaBot_Questions[7]['Category'][187] = 1;
TriviaBot_Questions[7]['Points'][187] = 1;
TriviaBot_Questions[7]['Hints'][187] = {};

TriviaBot_Questions[7]['Question'][188] = "In which zone does most blindweed grow?";
TriviaBot_Questions[7]['Answers'][188] = {"Swamp of Sorrows"};
TriviaBot_Questions[7]['Category'][188] = 1;
TriviaBot_Questions[7]['Points'][188] = 1;
TriviaBot_Questions[7]['Hints'][188] = {};

TriviaBot_Questions[7]['Question'][189] = "Which is the only zone where you can find gromsblood, mountain silversage and dreamfoil?";
TriviaBot_Questions[7]['Answers'][189] = {"Felwood"};
TriviaBot_Questions[7]['Category'][189] = 1;
TriviaBot_Questions[7]['Points'][189] = 1;
TriviaBot_Questions[7]['Hints'][189] = {};

TriviaBot_Questions[7]['Question'][190] = "Who created Thrym?";
TriviaBot_Questions[7]['Answers'][190] = {"Prince Navarius",  "Navarius"};
TriviaBot_Questions[7]['Category'][190] = 1;
TriviaBot_Questions[7]['Points'][190] = 1;
TriviaBot_Questions[7]['Hints'][190] = {};

TriviaBot_Questions[7]['Question'][191] = "One of the 5 demi-gods, known as The Lady Raven.";
TriviaBot_Questions[7]['Answers'][191] = {"Aviana"};
TriviaBot_Questions[7]['Category'][191] = 1;
TriviaBot_Questions[7]['Points'][191] = 1;
TriviaBot_Questions[7]['Hints'][191] = {};

TriviaBot_Questions[7]['Question'][192] = "What is the name of the monument in Azshara that has been broken in half?";
TriviaBot_Questions[7]['Answers'][192] = {"Ravencrest Monument",  "Ravencrest"};
TriviaBot_Questions[7]['Category'][192] = 1;
TriviaBot_Questions[7]['Points'][192] = 1;
TriviaBot_Questions[7]['Hints'][192] = {};

TriviaBot_Questions[7]['Question'][193] = "What is the name of the last boss in Shadowfang Keep?";
TriviaBot_Questions[7]['Answers'][193] = {"Arugal",  "Archmage Arugal"};
TriviaBot_Questions[7]['Category'][193] = 1;
TriviaBot_Questions[7]['Points'][193] = 1;
TriviaBot_Questions[7]['Hints'][193] = {};

TriviaBot_Questions[7]['Question'][194] = "Who is the mother of Nefarian and Onyxia?";
TriviaBot_Questions[7]['Answers'][194] = {"Sintharia"};
TriviaBot_Questions[7]['Category'][194] = 1;
TriviaBot_Questions[7]['Points'][194] = 1;
TriviaBot_Questions[7]['Hints'][194] = {};

TriviaBot_Questions[7]['Question'][195] = "Baron Rivendare represents which of the 4 Horseman of the Apocalypse?";
TriviaBot_Questions[7]['Answers'][195] = {"War"};
TriviaBot_Questions[7]['Category'][195] = 1;
TriviaBot_Questions[7]['Points'][195] = 1;
TriviaBot_Questions[7]['Hints'][195] = {};

TriviaBot_Questions[7]['Question'][196] = "Gothik the Harvester in Naxxramas has how many waves of adds?";
TriviaBot_Questions[7]['Answers'][196] = {"18",  "Eighteen"};
TriviaBot_Questions[7]['Category'][196] = 1;
TriviaBot_Questions[7]['Points'][196] = 1;
TriviaBot_Questions[7]['Hints'][196] = {};

TriviaBot_Questions[7]['Question'][197] = "What trinket allows you to kill yourself when equipped?";
TriviaBot_Questions[7]['Answers'][197] = {"Crystal of Zin-Malor",  "Zin-Malor"};
TriviaBot_Questions[7]['Category'][197] = 1;
TriviaBot_Questions[7]['Points'][197] = 1;
TriviaBot_Questions[7]['Hints'][197] = {};

TriviaBot_Questions[7]['Question'][198] = "What is the color of the rarest AQ40 mount that drops from trash mobs?";
TriviaBot_Questions[7]['Answers'][198] = {"red"};
TriviaBot_Questions[7]['Category'][198] = 1;
TriviaBot_Questions[7]['Points'][198] = 1;
TriviaBot_Questions[7]['Hints'][198] = {};

TriviaBot_Questions[7]['Question'][199] = "What herb will sometimes spawn instead of grave moss in the SM graveyard?";
TriviaBot_Questions[7]['Answers'][199] = {"Kingsblood"};
TriviaBot_Questions[7]['Category'][199] = 1;
TriviaBot_Questions[7]['Points'][199] = 1;
TriviaBot_Questions[7]['Hints'][199] = {};

TriviaBot_Questions[7]['Question'][200] = "What is the name of the raiding instance in Netherstorm? (full name)";
TriviaBot_Questions[7]['Answers'][200] = {"Tempest Keep"};
TriviaBot_Questions[7]['Category'][200] = 1;
TriviaBot_Questions[7]['Points'][200] = 1;
TriviaBot_Questions[7]['Hints'][200] = {};

TriviaBot_Questions[7]['Question'][201] = "What debuff once allowed Horde players to attack NPCs of their own faction?";
TriviaBot_Questions[7]['Answers'][201] = {"Mark of Shame"};
TriviaBot_Questions[7]['Category'][201] = 1;
TriviaBot_Questions[7]['Points'][201] = 1;
TriviaBot_Questions[7]['Hints'][201] = {};

TriviaBot_Questions[7]['Question'][202] = "Who is the final boss you have to kill for the tier 0.5 series of quests?";
TriviaBot_Questions[7]['Answers'][202] = {"Lord Valthalak",  "Valthalak"};
TriviaBot_Questions[7]['Category'][202] = 1;
TriviaBot_Questions[7]['Points'][202] = 1;
TriviaBot_Questions[7]['Hints'][202] = {};

TriviaBot_Questions[7]['Question'][203] = "Greater Shadow Protection potions require one dreamfoil, one __________, and one crystal vial.";
TriviaBot_Questions[7]['Answers'][203] = {"shadow oil"};
TriviaBot_Questions[7]['Category'][203] = 1;
TriviaBot_Questions[7]['Points'][203] = 1;
TriviaBot_Questions[7]['Hints'][203] = {};

TriviaBot_Questions[7]['Question'][204] = "How long is the auto-release timer when you die outside of an instance?";
TriviaBot_Questions[7]['Answers'][204] = {"6 minutes",  "6 min", "6 mins"};
TriviaBot_Questions[7]['Category'][204] = 1;
TriviaBot_Questions[7]['Points'][204] = 1;
TriviaBot_Questions[7]['Hints'][204] = {};

TriviaBot_Questions[7]['Question'][205] = "Name one of the two bosses you must kill during the Thaddius fight before you face Thaddius himself.";
TriviaBot_Questions[7]['Answers'][205] = {"Stalagg",  "Feugen"};
TriviaBot_Questions[7]['Category'][205] = 1;
TriviaBot_Questions[7]['Points'][205] = 1;
TriviaBot_Questions[7]['Hints'][205] = {};

TriviaBot_Questions[7]['Question'][206] = "What was the name of the first living creature on Azeroth?";
TriviaBot_Questions[7]['Answers'][206] = {"Agamaggan"};
TriviaBot_Questions[7]['Category'][206] = 1;
TriviaBot_Questions[7]['Points'][206] = 1;
TriviaBot_Questions[7]['Hints'][206] = {};

TriviaBot_Questions[7]['Question'][207] = "The Pools of Vision are found in what main city? (full name)";
TriviaBot_Questions[7]['Answers'][207] = {"Thunder Bluff"};
TriviaBot_Questions[7]['Category'][207] = 1;
TriviaBot_Questions[7]['Points'][207] = 1;
TriviaBot_Questions[7]['Hints'][207] = {};

TriviaBot_Questions[7]['Question'][208] = "What is the name of the lowest level zone in Outland?";
TriviaBot_Questions[7]['Answers'][208] = {"Hellfire Peninsula"};
TriviaBot_Questions[7]['Category'][208] = 1;
TriviaBot_Questions[7]['Points'][208] = 1;
TriviaBot_Questions[7]['Hints'][208] = {};

TriviaBot_Questions[7]['Question'][209] = "Which zone do Druids gain a teleport to at level 10?";
TriviaBot_Questions[7]['Answers'][209] = {"Moonglade"};
TriviaBot_Questions[7]['Category'][209] = 1;
TriviaBot_Questions[7]['Points'][209] = 1;
TriviaBot_Questions[7]['Hints'][209] = {};

TriviaBot_Questions[7]['Question'][210] = "Who is the king of the Vrykul?";
TriviaBot_Questions[7]['Answers'][210] = {"King Ymiron"};
TriviaBot_Questions[7]['Category'][210] = 1;
TriviaBot_Questions[7]['Points'][210] = 1;
TriviaBot_Questions[7]['Hints'][210] = {};

TriviaBot_Questions[7]['Question'][211] = "What creature despawns at 20%, saying it is 'not his time yet'?";
TriviaBot_Questions[7]['Answers'][211] = {"Anachronos"};
TriviaBot_Questions[7]['Category'][211] = 1;
TriviaBot_Questions[7]['Points'][211] = 1;
TriviaBot_Questions[7]['Hints'][211] = {};

TriviaBot_Questions[7]['Question'][212] = "Which zone contains the original World Tree? (full name)";
TriviaBot_Questions[7]['Answers'][212] = {"Mount Hyjal"};
TriviaBot_Questions[7]['Category'][212] = 1;
TriviaBot_Questions[7]['Points'][212] = 1;
TriviaBot_Questions[7]['Hints'][212] = {};

TriviaBot_Questions[7]['Question'][213] = "Overlord _______ is the Scourge warlord in Zuldrak.";
TriviaBot_Questions[7]['Answers'][213] = {"Drakuru"};
TriviaBot_Questions[7]['Category'][213] = 1;
TriviaBot_Questions[7]['Points'][213] = 1;
TriviaBot_Questions[7]['Hints'][213] = {};

TriviaBot_Questions[7]['Question'][214] = "How many mini-bosses are there on the top-level of the Sunken Temple?";
TriviaBot_Questions[7]['Answers'][214] = {"6",  "Six"};
TriviaBot_Questions[7]['Category'][214] = 1;
TriviaBot_Questions[7]['Points'][214] = 1;
TriviaBot_Questions[7]['Hints'][214] = {};

TriviaBot_Questions[7]['Question'][215] = "What does Gluth eat to regain health?";
TriviaBot_Questions[7]['Answers'][215] = {"Zombie Chow",  "zombies", "zombie"};
TriviaBot_Questions[7]['Category'][215] = 1;
TriviaBot_Questions[7]['Points'][215] = 1;
TriviaBot_Questions[7]['Hints'][215] = {};

TriviaBot_Questions[7]['Question'][216] = "What is the name of the dragon that appears at the WOTLK login screen?";
TriviaBot_Questions[7]['Answers'][216] = {"Sindragosa"};
TriviaBot_Questions[7]['Category'][216] = 1;
TriviaBot_Questions[7]['Points'][216] = 1;
TriviaBot_Questions[7]['Hints'][216] = {};

TriviaBot_Questions[7]['Question'][217] = "Who is the most damaging boss in Naxxramas?";
TriviaBot_Questions[7]['Answers'][217] = {"Instructor Razuvious",  "Razuvious"};
TriviaBot_Questions[7]['Category'][217] = 1;
TriviaBot_Questions[7]['Points'][217] = 1;
TriviaBot_Questions[7]['Hints'][217] = {};

TriviaBot_Questions[7]['Question'][218] = "Which boss drops the tier 7 headpieces?";
TriviaBot_Questions[7]['Answers'][218] = {"Kelthuzad "};
TriviaBot_Questions[7]['Category'][218] = 1;
TriviaBot_Questions[7]['Points'][218] = 1;
TriviaBot_Questions[7]['Hints'][218] = {};

TriviaBot_Questions[7]['Question'][219] = "How many parts does the tier 3 armor set have?";
TriviaBot_Questions[7]['Answers'][219] = {"9",  "Nine"};
TriviaBot_Questions[7]['Category'][219] = 1;
TriviaBot_Questions[7]['Points'][219] = 1;
TriviaBot_Questions[7]['Hints'][219] = {};

TriviaBot_Questions[7]['Question'][220] = "Who was the apprentice to Medivh??";
TriviaBot_Questions[7]['Answers'][220] = {"Khadgar"};
TriviaBot_Questions[7]['Category'][220] = 1;
TriviaBot_Questions[7]['Points'][220] = 1;
TriviaBot_Questions[7]['Hints'][220] = {};

TriviaBot_Questions[7]['Question'][221] = "What is the second last boss in Molten Core?";
TriviaBot_Questions[7]['Answers'][221] = {"Majordomo Executus",  "Majordomo"};
TriviaBot_Questions[7]['Category'][221] = 1;
TriviaBot_Questions[7]['Points'][221] = 1;
TriviaBot_Questions[7]['Hints'][221] = {};

TriviaBot_Questions[7]['Question'][222] = "In the AQ War Effort, what item was required in the greatest number?";
TriviaBot_Questions[7]['Answers'][222] = {"Linen bandages"};
TriviaBot_Questions[7]['Category'][222] = 1;
TriviaBot_Questions[7]['Points'][222] = 1;
TriviaBot_Questions[7]['Hints'][222] = {};

TriviaBot_Questions[7]['Question'][223] = "What does Ragnaros summon when he submerges after 3 minutes of combat?";
TriviaBot_Questions[7]['Answers'][223] = {"Sons of Flame"};
TriviaBot_Questions[7]['Category'][223] = 1;
TriviaBot_Questions[7]['Points'][223] = 1;
TriviaBot_Questions[7]['Hints'][223] = {};

TriviaBot_Questions[7]['Question'][224] = "What is the last name of the orc that the spell Eye of Kilrogg is based on?";
TriviaBot_Questions[7]['Answers'][224] = {"Deadeye"};
TriviaBot_Questions[7]['Category'][224] = 1;
TriviaBot_Questions[7]['Points'][224] = 1;
TriviaBot_Questions[7]['Hints'][224] = {};

TriviaBot_Questions[7]['Question'][225] = "Who is the 'Dad' in the Bug Family in AQ40?";
TriviaBot_Questions[7]['Answers'][225] = {"Lord Kri",  "Kri"};
TriviaBot_Questions[7]['Category'][225] = 1;
TriviaBot_Questions[7]['Points'][225] = 1;
TriviaBot_Questions[7]['Hints'][225] = {};

TriviaBot_Questions[7]['Question'][226] = "When the game was released, the mobs of which zone had no loot?";
TriviaBot_Questions[7]['Answers'][226] = {"Silithus"};
TriviaBot_Questions[7]['Category'][226] = 1;
TriviaBot_Questions[7]['Points'][226] = 1;
TriviaBot_Questions[7]['Hints'][226] = {};

TriviaBot_Questions[7]['Question'][227] = "Which Blackwing Lair boss drops the tier 2 Bracers?";
TriviaBot_Questions[7]['Answers'][227] = {"Razorgore the Untamed",  "Razorgore"};
TriviaBot_Questions[7]['Category'][227] = 1;
TriviaBot_Questions[7]['Points'][227] = 1;
TriviaBot_Questions[7]['Hints'][227] = {};

TriviaBot_Questions[7]['Question'][228] = "What is the name of the bar in Blackrock Depths?";
TriviaBot_Questions[7]['Answers'][228] = {"The Grim Guzzler",  "Grim Guzzler"};
TriviaBot_Questions[7]['Category'][228] = 1;
TriviaBot_Questions[7]['Points'][228] = 1;
TriviaBot_Questions[7]['Hints'][228] = {};

TriviaBot_Questions[7]['Question'][229] = "How many bosses in AQ20 must be kited to kill them?";
TriviaBot_Questions[7]['Answers'][229] = {"2",  "two"};
TriviaBot_Questions[7]['Category'][229] = 1;
TriviaBot_Questions[7]['Points'][229] = 1;
TriviaBot_Questions[7]['Hints'][229] = {};

TriviaBot_Questions[7]['Question'][230] = "Who has the lowest health of all the bosses in Naxxramas?";
TriviaBot_Questions[7]['Answers'][230] = {"Gothik the Harvester",  "Gothik"};
TriviaBot_Questions[7]['Category'][230] = 1;
TriviaBot_Questions[7]['Points'][230] = 1;
TriviaBot_Questions[7]['Hints'][230] = {};

TriviaBot_Questions[7]['Question'][231] = "How many optional encounters does AQ40 have?";
TriviaBot_Questions[7]['Answers'][231] = {"3",  "Three"};
TriviaBot_Questions[7]['Category'][231] = 1;
TriviaBot_Questions[7]['Points'][231] = 1;
TriviaBot_Questions[7]['Hints'][231] = {};

TriviaBot_Questions[7]['Question'][232] = "The Gurubashi Arena event takes place at ____-hourly intervals?";
TriviaBot_Questions[7]['Answers'][232] = {"3",  "three"};
TriviaBot_Questions[7]['Category'][232] = 1;
TriviaBot_Questions[7]['Points'][232] = 1;
TriviaBot_Questions[7]['Hints'][232] = {};

TriviaBot_Questions[7]['Question'][233] = "In what patch were the 4 world Dragons introduced?";
TriviaBot_Questions[7]['Answers'][233] = {"1.8"};
TriviaBot_Questions[7]['Category'][233] = 1;
TriviaBot_Questions[7]['Points'][233] = 1;
TriviaBot_Questions[7]['Hints'][233] = {};

TriviaBot_Questions[7]['Question'][234] = "What is the lowest level instance in the game?";
TriviaBot_Questions[7]['Answers'][234] = {"Ragefire Chasm",  "RFC"};
TriviaBot_Questions[7]['Category'][234] = 1;
TriviaBot_Questions[7]['Points'][234] = 1;
TriviaBot_Questions[7]['Hints'][234] = {};

TriviaBot_Questions[7]['Question'][235] = "What is the name of the draenei capital city?";
TriviaBot_Questions[7]['Answers'][235] = {"The Exodar",  "Exodar"};
TriviaBot_Questions[7]['Category'][235] = 1;
TriviaBot_Questions[7]['Points'][235] = 1;
TriviaBot_Questions[7]['Hints'][235] = {};

TriviaBot_Questions[7]['Question'][236] = "Which Alliance race has +15 engineering as racial passive?";
TriviaBot_Questions[7]['Answers'][236] = {"Gnome",  "Gnomes"};
TriviaBot_Questions[7]['Category'][236] = 1;
TriviaBot_Questions[7]['Points'][236] = 1;
TriviaBot_Questions[7]['Hints'][236] = {};

TriviaBot_Questions[7]['Question'][237] = "Which titan wields the Taeshalach?";
TriviaBot_Questions[7]['Answers'][237] = {"Aggramar"};
TriviaBot_Questions[7]['Category'][237] = 1;
TriviaBot_Questions[7]['Points'][237] = 1;
TriviaBot_Questions[7]['Hints'][237] = {};

TriviaBot_Questions[7]['Question'][238] = "How many fears does the Warlock class have?";
TriviaBot_Questions[7]['Answers'][238] = {"2",  "two"};
TriviaBot_Questions[7]['Category'][238] = 1;
TriviaBot_Questions[7]['Points'][238] = 1;
TriviaBot_Questions[7]['Hints'][238] = {};

TriviaBot_Questions[7]['Question'][239] = "Druids can do Physical, Nature and ______ damage.";
TriviaBot_Questions[7]['Answers'][239] = {"Arcane damage",  "arcane"};
TriviaBot_Questions[7]['Category'][239] = 1;
TriviaBot_Questions[7]['Points'][239] = 1;
TriviaBot_Questions[7]['Hints'][239] = {};

TriviaBot_Questions[7]['Question'][240] = "Who was the mother of Medivh?";
TriviaBot_Questions[7]['Answers'][240] = {"Aegwynn"};
TriviaBot_Questions[7]['Category'][240] = 1;
TriviaBot_Questions[7]['Points'][240] = 1;
TriviaBot_Questions[7]['Hints'][240] = {};

TriviaBot_Questions[7]['Question'][241] = "What is the name of the sword that can destroy the universe if the two pieces, Taeshalach and Gorribal ever united?";
TriviaBot_Questions[7]['Answers'][241] = {"Gorshalach"};
TriviaBot_Questions[7]['Category'][241] = 1;
TriviaBot_Questions[7]['Points'][241] = 1;
TriviaBot_Questions[7]['Hints'][241] = {};

TriviaBot_Questions[7]['Question'][242] = "Which titan wields the Gorribal?";
TriviaBot_Questions[7]['Answers'][242] = {"Gorribal"};
TriviaBot_Questions[7]['Category'][242] = 1;
TriviaBot_Questions[7]['Points'][242] = 1;
TriviaBot_Questions[7]['Hints'][242] = {};

TriviaBot_Questions[7]['Question'][243] = "Arcane Resilience will increase your armor by what % of your intellect?";
TriviaBot_Questions[7]['Answers'][243] = {"50%",  "Fifty", "50"};
TriviaBot_Questions[7]['Category'][243] = 1;
TriviaBot_Questions[7]['Points'][243] = 1;
TriviaBot_Questions[7]['Hints'][243] = {};

TriviaBot_Questions[7]['Question'][244] = "What instance is sometimes called 'UD'?";
TriviaBot_Questions[7]['Answers'][244] = {"Stratholme",  "Strat"};
TriviaBot_Questions[7]['Category'][244] = 1;
TriviaBot_Questions[7]['Points'][244] = 1;
TriviaBot_Questions[7]['Hints'][244] = {};

TriviaBot_Questions[7]['Question'][245] = "Name a faction that is part of the Steamwheedle Cartel.";
TriviaBot_Questions[7]['Answers'][245] = {"Booty Bay",  "Everlook", "Ratchet", "Gadgetztan"};
TriviaBot_Questions[7]['Category'][245] = 1;
TriviaBot_Questions[7]['Points'][245] = 1;
TriviaBot_Questions[7]['Hints'][245] = {};

TriviaBot_Questions[7]['Question'][246] = "What race has the racial skill 'Diplomacy'?";
TriviaBot_Questions[7]['Answers'][246] = {"Human",  "Humans"};
TriviaBot_Questions[7]['Category'][246] = 1;
TriviaBot_Questions[7]['Points'][246] = 1;
TriviaBot_Questions[7]['Hints'][246] = {};

TriviaBot_Questions[7]['Question'][247] = "Blizzard will do up to 1472 damage over ___ seconds?";
TriviaBot_Questions[7]['Answers'][247] = {"8",  "eight"};
TriviaBot_Questions[7]['Category'][247] = 1;
TriviaBot_Questions[7]['Points'][247] = 1;
TriviaBot_Questions[7]['Hints'][247] = {};

TriviaBot_Questions[7]['Question'][248] = "Evocation has a ___ min cooldown?";
TriviaBot_Questions[7]['Answers'][248] = {"8",  "eight"};
TriviaBot_Questions[7]['Category'][248] = 1;
TriviaBot_Questions[7]['Points'][248] = 1;
TriviaBot_Questions[7]['Hints'][248] = {};

TriviaBot_Questions[7]['Question'][249] = "What was The Demon Soul also known as?";
TriviaBot_Questions[7]['Answers'][249] = {"The Dragon Soul"};
TriviaBot_Questions[7]['Category'][249] = 1;
TriviaBot_Questions[7]['Points'][249] = 1;
TriviaBot_Questions[7]['Hints'][249] = {};

TriviaBot_Questions[7]['Question'][250] = "Which class can cast Fear?";
TriviaBot_Questions[7]['Answers'][250] = {"Warlock"};
TriviaBot_Questions[7]['Category'][250] = 1;
TriviaBot_Questions[7]['Points'][250] = 1;
TriviaBot_Questions[7]['Hints'][250] = {};

TriviaBot_Questions[7]['Question'][251] = "The tier 7 Mage set is called?";
TriviaBot_Questions[7]['Answers'][251] = {"Frostfire"};
TriviaBot_Questions[7]['Category'][251] = 1;
TriviaBot_Questions[7]['Points'][251] = 1;
TriviaBot_Questions[7]['Hints'][251] = {};

TriviaBot_Questions[7]['Question'][252] = "Which is the most hated instance?";
TriviaBot_Questions[7]['Answers'][252] = {"Gnomeregan"};
TriviaBot_Questions[7]['Category'][252] = 1;
TriviaBot_Questions[7]['Points'][252] = 1;
TriviaBot_Questions[7]['Hints'][252] = {};

TriviaBot_Questions[7]['Question'][253] = "Acronyms: What does DKP stand for?";
TriviaBot_Questions[7]['Answers'][253] = {"Dragon Kill Points"};
TriviaBot_Questions[7]['Category'][253] = 1;
TriviaBot_Questions[7]['Points'][253] = 1;
TriviaBot_Questions[7]['Hints'][253] = {};

TriviaBot_Questions[7]['Question'][254] = "Who is being held captive by the Baron in Stratholme?";
TriviaBot_Questions[7]['Answers'][254] = {"Ysida Harmon",  "Ysida"};
TriviaBot_Questions[7]['Category'][254] = 1;
TriviaBot_Questions[7]['Points'][254] = 1;
TriviaBot_Questions[7]['Hints'][254] = {};

TriviaBot_Questions[7]['Question'][255] = "What epic sword set was 'Forged in the seething flames of hatred'?";
TriviaBot_Questions[7]['Answers'][255] = {"The Twin blades of Hakkari",  "Twin blades of Hakkari"};
TriviaBot_Questions[7]['Category'][255] = 1;
TriviaBot_Questions[7]['Points'][255] = 1;
TriviaBot_Questions[7]['Hints'][255] = {};

TriviaBot_Questions[7]['Question'][256] = "What is the name of the fruit vendor patrolling in Ironforge (The Mystic Ward)?";
TriviaBot_Questions[7]['Answers'][256] = {"Bimble Longberry",  "Longberry", "Bimble"};
TriviaBot_Questions[7]['Category'][256] = 1;
TriviaBot_Questions[7]['Points'][256] = 1;
TriviaBot_Questions[7]['Hints'][256] = {};

TriviaBot_Questions[7]['Question'][257] = "What is the name of the food you get from the Mage spell 'Conjure food (Rank 1)'?";
TriviaBot_Questions[7]['Answers'][257] = {"Muffin",  "Muffins", "Conjured Muffins", "Conjured Muffin"};
TriviaBot_Questions[7]['Category'][257] = 1;
TriviaBot_Questions[7]['Points'][257] = 1;
TriviaBot_Questions[7]['Hints'][257] = {};

TriviaBot_Questions[7]['Question'][258] = "Humanoids can drop linen cloth from level _.";
TriviaBot_Questions[7]['Answers'][258] = {"8",  "eight"};
TriviaBot_Questions[7]['Category'][258] = 1;
TriviaBot_Questions[7]['Points'][258] = 1;
TriviaBot_Questions[7]['Hints'][258] = {};

TriviaBot_Questions[7]['Question'][259] = "One area in Silverpine Forest is called '______ Isle'.";
TriviaBot_Questions[7]['Answers'][259] = {"Fenris"};
TriviaBot_Questions[7]['Category'][259] = 1;
TriviaBot_Questions[7]['Points'][259] = 1;
TriviaBot_Questions[7]['Hints'][259] = {};

TriviaBot_Questions[7]['Question'][260] = "Where does most of the Blue Dragonflight reside?";
TriviaBot_Questions[7]['Answers'][260] = {"Northrend"};
TriviaBot_Questions[7]['Category'][260] = 1;
TriviaBot_Questions[7]['Points'][260] = 1;
TriviaBot_Questions[7]['Hints'][260] = {};

TriviaBot_Questions[7]['Question'][261] = "Where does most of the Black Dragonflight reside?";
TriviaBot_Questions[7]['Answers'][261] = {"Blackrock Mountain",  "Blackrock Spire", "Burning Steppes"};
TriviaBot_Questions[7]['Category'][261] = 1;
TriviaBot_Questions[7]['Points'][261] = 1;
TriviaBot_Questions[7]['Hints'][261] = {};

TriviaBot_Questions[7]['Question'][262] = "Where does most of the Bronze Dragonflight reside?";
TriviaBot_Questions[7]['Answers'][262] = {"Caverns of Time",  "Tanaris"};
TriviaBot_Questions[7]['Category'][262] = 1;
TriviaBot_Questions[7]['Points'][262] = 1;
TriviaBot_Questions[7]['Hints'][262] = {};

TriviaBot_Questions[7]['Question'][263] = "Where does most of the Red Dragonflight reside?";
TriviaBot_Questions[7]['Answers'][263] = {"Grim Batol",  "Wetlands"};
TriviaBot_Questions[7]['Category'][263] = 1;
TriviaBot_Questions[7]['Points'][263] = 1;
TriviaBot_Questions[7]['Hints'][263] = {};

TriviaBot_Questions[7]['Question'][264] = "Where does most of the Green Dragonflight reside?";
TriviaBot_Questions[7]['Answers'][264] = {"The Emerald Dream",  "Emerald Dream", "Swamp of Sorrows"};
TriviaBot_Questions[7]['Category'][264] = 1;
TriviaBot_Questions[7]['Points'][264] = 1;
TriviaBot_Questions[7]['Hints'][264] = {};

TriviaBot_Questions[7]['Question'][265] = "Who is the leader of the Bronze Dragonflight?";
TriviaBot_Questions[7]['Answers'][265] = {"Nozdormu",  "Nozdormu the Timeless one"};
TriviaBot_Questions[7]['Category'][265] = 1;
TriviaBot_Questions[7]['Points'][265] = 1;
TriviaBot_Questions[7]['Hints'][265] = {};

TriviaBot_Questions[7]['Question'][266] = "Who is the leader of the Green Dragonflight?";
TriviaBot_Questions[7]['Answers'][266] = {"Ysera",  "Ysera the Dreamer"};
TriviaBot_Questions[7]['Category'][266] = 1;
TriviaBot_Questions[7]['Points'][266] = 1;
TriviaBot_Questions[7]['Hints'][266] = {};

TriviaBot_Questions[7]['Question'][267] = "Who is the leader of the Red Dragonflight?";
TriviaBot_Questions[7]['Answers'][267] = {"Alexstraza",  "Alexstrasza the Life-Binder", "Alexstrasza the Life Binder"};
TriviaBot_Questions[7]['Category'][267] = 1;
TriviaBot_Questions[7]['Points'][267] = 1;
TriviaBot_Questions[7]['Hints'][267] = {};

TriviaBot_Questions[7]['Question'][268] = "Who is the leader of the Blue Dragonflight?";
TriviaBot_Questions[7]['Answers'][268] = {"Malygos",  "Malygos the Spell-Weaver", "Malygos the Spell Weaver"};
TriviaBot_Questions[7]['Category'][268] = 1;
TriviaBot_Questions[7]['Points'][268] = 1;
TriviaBot_Questions[7]['Hints'][268] = {};

TriviaBot_Questions[7]['Question'][269] = "Who is the leader of the Black Dragonflight?";
TriviaBot_Questions[7]['Answers'][269] = {"Neltharion",  "Deathwing", "Neltharion the Earth-Warder", "Deathwing the Destroyer"};
TriviaBot_Questions[7]['Category'][269] = 1;
TriviaBot_Questions[7]['Points'][269] = 1;
TriviaBot_Questions[7]['Hints'][269] = {};

TriviaBot_Questions[7]['Question'][270] = "The Black Dragonflight was originally which color, before becoming corrupted?";
TriviaBot_Questions[7]['Answers'][270] = {"Brown"};
TriviaBot_Questions[7]['Category'][270] = 1;
TriviaBot_Questions[7]['Points'][270] = 1;
TriviaBot_Questions[7]['Hints'][270] = {};

TriviaBot_Questions[7]['Question'][271] = "To where does the portals which the corrupted Emerald Dragons are guarding, lead?";
TriviaBot_Questions[7]['Answers'][271] = {"The Emerald Dream",  "Emerald Dream"};
TriviaBot_Questions[7]['Category'][271] = 1;
TriviaBot_Questions[7]['Points'][271] = 1;
TriviaBot_Questions[7]['Hints'][271] = {};

TriviaBot_Questions[7]['Question'][272] = "Name one of the two places where Eranikus can be found.";
TriviaBot_Questions[7]['Answers'][272] = {"Sunken Temple or Moonglade",  "Sunken Temple", "Moonglade", "Moonglade or Sunken Temple"};
TriviaBot_Questions[7]['Category'][272] = 1;
TriviaBot_Questions[7]['Points'][272] = 1;
TriviaBot_Questions[7]['Hints'][272] = {};

TriviaBot_Questions[7]['Question'][273] = "With the Genesis (t2.5) set bonus, what is the cooldown on Rebirth for Druids?";
TriviaBot_Questions[7]['Answers'][273] = {"20 minutes",  "Twenty minutes", "Twenty mins"};
TriviaBot_Questions[7]['Category'][273] = 1;
TriviaBot_Questions[7]['Points'][273] = 1;
TriviaBot_Questions[7]['Hints'][273] = {};

TriviaBot_Questions[7]['Question'][274] = "The only non-combat pet with an effect on gameplay is the _____.";
TriviaBot_Questions[7]['Answers'][274] = {"Disgusting Oozeling"};
TriviaBot_Questions[7]['Category'][274] = 1;
TriviaBot_Questions[7]['Points'][274] = 1;
TriviaBot_Questions[7]['Hints'][274] = {};

TriviaBot_Questions[7]['Question'][275] = "What is the name of the mount you can obtain through the repeatable quests in Winterspring?";
TriviaBot_Questions[7]['Answers'][275] = {"Reins of the Winterspring Frostsaber",  "Winterspring Frostsaber"};
TriviaBot_Questions[7]['Category'][275] = 1;
TriviaBot_Questions[7]['Points'][275] = 1;
TriviaBot_Questions[7]['Hints'][275] = {};

TriviaBot_Questions[7]['Question'][276] = "What is the name of the dranei mount?";
TriviaBot_Questions[7]['Answers'][276] = {"Elekk"};
TriviaBot_Questions[7]['Category'][276] = 1;
TriviaBot_Questions[7]['Points'][276] = 1;
TriviaBot_Questions[7]['Hints'][276] = {};

TriviaBot_Questions[7]['Question'][277] = "Who is the mighty Warrior you must defeat in the Upper Blackrock Spire in order to obtain the tier 0 Warrior shoulders?";
TriviaBot_Questions[7]['Answers'][277] = {"Rend",  "Rend Blackhand", "Warchief Rend Blackhand"};
TriviaBot_Questions[7]['Category'][277] = 1;
TriviaBot_Questions[7]['Points'][277] = 1;
TriviaBot_Questions[7]['Hints'][277] = {};

TriviaBot_Questions[7]['Question'][278] = "In the Upper Blackrock Spires is a giant hound named 'The ____'.";
TriviaBot_Questions[7]['Answers'][278] = {"Beast"};
TriviaBot_Questions[7]['Category'][278] = 1;
TriviaBot_Questions[7]['Points'][278] = 1;
TriviaBot_Questions[7]['Hints'][278] = {};

TriviaBot_Questions[7]['Question'][279] = "What dragon drops the tier 2 headpieces? (the full name)";
TriviaBot_Questions[7]['Answers'][279] = {"Onyxia"};
TriviaBot_Questions[7]['Category'][279] = 1;
TriviaBot_Questions[7]['Points'][279] = 1;
TriviaBot_Questions[7]['Hints'][279] = {};

TriviaBot_Questions[7]['Question'][280] = "How long does it take for a Rogues stealth to be ready after unstealthing (Without Talents)?";
TriviaBot_Questions[7]['Answers'][280] = {"10 seconds",  "10 secs", "10 sec"};
TriviaBot_Questions[7]['Category'][280] = 1;
TriviaBot_Questions[7]['Points'][280] = 1;
TriviaBot_Questions[7]['Hints'][280] = {};

TriviaBot_Questions[7]['Question'][281] = "The cooldown for Goblin Jumper Cables is ____ minutes?";
TriviaBot_Questions[7]['Answers'][281] = {"30",  "30 mins", "30 minutes", "30 min"};
TriviaBot_Questions[7]['Category'][281] = 1;
TriviaBot_Questions[7]['Points'][281] = 1;
TriviaBot_Questions[7]['Hints'][281] = {};

TriviaBot_Questions[7]['Question'][282] = "Who does the trinket Warmth of Forgiveness drop off?";
TriviaBot_Questions[7]['Answers'][282] = {"The Four Horsemen",  "Four Horsemen"};
TriviaBot_Questions[7]['Category'][282] = 1;
TriviaBot_Questions[7]['Points'][282] = 1;
TriviaBot_Questions[7]['Hints'][282] = {};

TriviaBot_Questions[7]['Question'][283] = "What is the Hunter's tier 3 called?";
TriviaBot_Questions[7]['Answers'][283] = {"Cryptstalker"};
TriviaBot_Questions[7]['Category'][283] = 1;
TriviaBot_Questions[7]['Points'][283] = 1;
TriviaBot_Questions[7]['Hints'][283] = {};

TriviaBot_Questions[7]['Question'][284] = "Lady Blaumeux represents which of the 4 Horseman of the Apocalypse?";
TriviaBot_Questions[7]['Answers'][284] = {"Death"};
TriviaBot_Questions[7]['Category'][284] = 1;
TriviaBot_Questions[7]['Points'][284] = 1;
TriviaBot_Questions[7]['Hints'][284] = {};

TriviaBot_Questions[7]['Question'][285] = "Prince ______ is the Scourge Ambassador to the Vrykuls.";
TriviaBot_Questions[7]['Answers'][285] = {"Keleseth"};
TriviaBot_Questions[7]['Category'][285] = 1;
TriviaBot_Questions[7]['Points'][285] = 1;
TriviaBot_Questions[7]['Hints'][285] = {};

TriviaBot_Questions[7]['Question'][286] = "What is the full name of the last boss in The Deadmines?";
TriviaBot_Questions[7]['Answers'][286] = {"Edwin Van Cleef"};
TriviaBot_Questions[7]['Category'][286] = 1;
TriviaBot_Questions[7]['Points'][286] = 1;
TriviaBot_Questions[7]['Hints'][286] = {};

TriviaBot_Questions[7]['Question'][287] = "What rare spawn in Stratholme drops Piccolo of the Flaming Fire?";
TriviaBot_Questions[7]['Answers'][287] = {"Hearthsinger Forresten",  "Forresten"};
TriviaBot_Questions[7]['Category'][287] = 1;
TriviaBot_Questions[7]['Points'][287] = 1;
TriviaBot_Questions[7]['Hints'][287] = {};

TriviaBot_Questions[7]['Question'][288] = "What is the name of the zone that you'll teleport into after entering the dark portal at Blasted Lands?";
TriviaBot_Questions[7]['Answers'][288] = {"Hellfire Peninsula"};
TriviaBot_Questions[7]['Category'][288] = 1;
TriviaBot_Questions[7]['Points'][288] = 1;
TriviaBot_Questions[7]['Hints'][288] = {};

TriviaBot_Questions[7]['Question'][289] = "Blizzard Entertainment is owned by which company?";
TriviaBot_Questions[7]['Answers'][289] = {"Vivendi Universal Games",  "vivendi"};
TriviaBot_Questions[7]['Category'][289] = 1;
TriviaBot_Questions[7]['Points'][289] = 1;
TriviaBot_Questions[7]['Hints'][289] = {};

TriviaBot_Questions[7]['Question'][290] = "What is the homeworld of the eredar called?";
TriviaBot_Questions[7]['Answers'][290] = {"Argus"};
TriviaBot_Questions[7]['Category'][290] = 1;
TriviaBot_Questions[7]['Points'][290] = 1;
TriviaBot_Questions[7]['Hints'][290] = {};

TriviaBot_Questions[7]['Question'][291] = "What is the undead's starting place called?";
TriviaBot_Questions[7]['Answers'][291] = {"Deathknell"};
TriviaBot_Questions[7]['Category'][291] = 1;
TriviaBot_Questions[7]['Points'][291] = 1;
TriviaBot_Questions[7]['Hints'][291] = {};

TriviaBot_Questions[7]['Question'][292] = "In which talent tree can the spell 'Dark Pact' be found?";
TriviaBot_Questions[7]['Answers'][292] = {"Affliction"};
TriviaBot_Questions[7]['Category'][292] = 1;
TriviaBot_Questions[7]['Points'][292] = 1;
TriviaBot_Questions[7]['Hints'][292] = {};

TriviaBot_Questions[7]['Question'][293] = "In which talent tree can the spell 'Soul Link' be found?";
TriviaBot_Questions[7]['Answers'][293] = {"Demonology"};
TriviaBot_Questions[7]['Category'][293] = 1;
TriviaBot_Questions[7]['Points'][293] = 1;
TriviaBot_Questions[7]['Hints'][293] = {};

TriviaBot_Questions[7]['Question'][294] = "What lvl of First Aid is required to learn Artisan First Aid?";
TriviaBot_Questions[7]['Answers'][294] = {"225"};
TriviaBot_Questions[7]['Category'][294] = 1;
TriviaBot_Questions[7]['Points'][294] = 1;
TriviaBot_Questions[7]['Hints'][294] = {};

TriviaBot_Questions[7]['Question'][295] = "Which class(es) can breathe under water infinitely?";
TriviaBot_Questions[7]['Answers'][295] = {"Warlock",  "Shaman", "Druid"};
TriviaBot_Questions[7]['Category'][295] = 1;
TriviaBot_Questions[7]['Points'][295] = 1;
TriviaBot_Questions[7]['Hints'][295] = {};

TriviaBot_Questions[7]['Question'][296] = "In which zone can you find Donova Snowden";
TriviaBot_Questions[7]['Answers'][296] = {"Winterspring"};
TriviaBot_Questions[7]['Category'][296] = 1;
TriviaBot_Questions[7]['Points'][296] = 1;
TriviaBot_Questions[7]['Hints'][296] = {};

TriviaBot_Questions[7]['Question'][297] = "How many items is there in a tier 3 set?";
TriviaBot_Questions[7]['Answers'][297] = {"9",  "Nine"};
TriviaBot_Questions[7]['Category'][297] = 1;
TriviaBot_Questions[7]['Points'][297] = 1;
TriviaBot_Questions[7]['Hints'][297] = {};

TriviaBot_Questions[7]['Question'][298] = "What were the Blood Elves originally called?";
TriviaBot_Questions[7]['Answers'][298] = {"high elfs",  "high elves"};
TriviaBot_Questions[7]['Category'][298] = 1;
TriviaBot_Questions[7]['Points'][298] = 1;
TriviaBot_Questions[7]['Hints'][298] = {};

TriviaBot_Questions[7]['Question'][299] = "What race has Escape Artist as their racial?";
TriviaBot_Questions[7]['Answers'][299] = {"Gnomes",  "Gnome"};
TriviaBot_Questions[7]['Category'][299] = 1;
TriviaBot_Questions[7]['Points'][299] = 1;
TriviaBot_Questions[7]['Hints'][299] = {};

TriviaBot_Questions[7]['Question'][300] = "What is the Warlocks second pet called?";
TriviaBot_Questions[7]['Answers'][300] = {"Voidwalker",  "vw"};
TriviaBot_Questions[7]['Category'][300] = 1;
TriviaBot_Questions[7]['Points'][300] = 1;
TriviaBot_Questions[7]['Hints'][300] = {};

TriviaBot_Questions[7]['Question'][301] = "What is the highest rank of Fireball?";
TriviaBot_Questions[7]['Answers'][301] = {"Rank 13",  "13", "thirteen"};
TriviaBot_Questions[7]['Category'][301] = 1;
TriviaBot_Questions[7]['Points'][301] = 1;
TriviaBot_Questions[7]['Hints'][301] = {};

TriviaBot_Questions[7]['Question'][302] = "How much resources do you need to win an Arathi Basin match?";
TriviaBot_Questions[7]['Answers'][302] = {"2000",  "two thousand"};
TriviaBot_Questions[7]['Category'][302] = 1;
TriviaBot_Questions[7]['Points'][302] = 1;
TriviaBot_Questions[7]['Hints'][302] = {};

TriviaBot_Questions[7]['Question'][303] = "What type of resistance do you need for the Sapphiron encounter?";
TriviaBot_Questions[7]['Answers'][303] = {"Frost"};
TriviaBot_Questions[7]['Category'][303] = 1;
TriviaBot_Questions[7]['Points'][303] = 1;
TriviaBot_Questions[7]['Hints'][303] = {};

TriviaBot_Questions[7]['Question'][304] = "What kind of monster is Onyxia?";
TriviaBot_Questions[7]['Answers'][304] = {"Dragon",  "Dragonkin"};
TriviaBot_Questions[7]['Category'][304] = 1;
TriviaBot_Questions[7]['Points'][304] = 1;
TriviaBot_Questions[7]['Hints'][304] = {};

TriviaBot_Questions[7]['Question'][305] = "On which continent is Deadwind Pass found?";
TriviaBot_Questions[7]['Answers'][305] = {"eastern kingdoms"};
TriviaBot_Questions[7]['Category'][305] = 1;
TriviaBot_Questions[7]['Points'][305] = 1;
TriviaBot_Questions[7]['Hints'][305] = {};

TriviaBot_Questions[7]['Question'][306] = "In what instance does Illidan the Betrayer reside in?";
TriviaBot_Questions[7]['Answers'][306] = {"The Black Temple",  "black temple", "bt"};
TriviaBot_Questions[7]['Category'][306] = 1;
TriviaBot_Questions[7]['Points'][306] = 1;
TriviaBot_Questions[7]['Hints'][306] = {};

TriviaBot_Questions[7]['Question'][307] = "What will Piccolo of the Flaming Fire make you do?";
TriviaBot_Questions[7]['Answers'][307] = {"Dance",  "dancing"};
TriviaBot_Questions[7]['Category'][307] = 1;
TriviaBot_Questions[7]['Points'][307] = 1;
TriviaBot_Questions[7]['Hints'][307] = {};

TriviaBot_Questions[7]['Question'][308] = "Which boss do you need to defeat in order to aquire 'Thunderfury, The Blessed Blade of the Windseeker', if you have the bindings?";
TriviaBot_Questions[7]['Answers'][308] = {"Prince Thunderaan",  "thunderaan"};
TriviaBot_Questions[7]['Category'][308] = 1;
TriviaBot_Questions[7]['Points'][308] = 1;
TriviaBot_Questions[7]['Hints'][308] = {};

TriviaBot_Questions[7]['Question'][309] = "What is the name of the new raid boss that will be added to the Vault of Archavon and will drop tier 8?";
TriviaBot_Questions[7]['Answers'][309] = {"Emalon"};
TriviaBot_Questions[7]['Category'][309] = 1;
TriviaBot_Questions[7]['Points'][309] = 1;
TriviaBot_Questions[7]['Hints'][309] = {};

TriviaBot_Questions[7]['Question'][310] = "What is the name of the Warlocks Tier 7?";
TriviaBot_Questions[7]['Answers'][310] = {"Plaqueheart"};
TriviaBot_Questions[7]['Category'][310] = 1;
TriviaBot_Questions[7]['Points'][310] = 1;
TriviaBot_Questions[7]['Hints'][310] = {};

TriviaBot_Questions[7]['Question'][311] = "Name the crafted engineering item that only affects beasts";
TriviaBot_Questions[7]['Answers'][311] = {"Flash Bomb"};
TriviaBot_Questions[7]['Category'][311] = 1;
TriviaBot_Questions[7]['Points'][311] = 1;
TriviaBot_Questions[7]['Hints'][311] = {};

TriviaBot_Questions[7]['Question'][312] = "How many Elementium Ore does it take to make a bar?";
TriviaBot_Questions[7]['Answers'][312] = {"One",  "1"};
TriviaBot_Questions[7]['Category'][312] = 1;
TriviaBot_Questions[7]['Points'][312] = 1;
TriviaBot_Questions[7]['Hints'][312] = {};

TriviaBot_Questions[7]['Question'][313] = "The acronym 'WPL' refers to?";
TriviaBot_Questions[7]['Answers'][313] = {"Western Plaguelands"};
TriviaBot_Questions[7]['Category'][313] = 1;
TriviaBot_Questions[7]['Points'][313] = 1;
TriviaBot_Questions[7]['Hints'][313] = {};

TriviaBot_Questions[7]['Question'][314] = "What is the name of the blood elves capital city?";
TriviaBot_Questions[7]['Answers'][314] = {"Silvermoon",  "Silvermoon city", "The Silvermoon", "The Silvermoon City"};
TriviaBot_Questions[7]['Category'][314] = 1;
TriviaBot_Questions[7]['Points'][314] = 1;
TriviaBot_Questions[7]['Hints'][314] = {};

TriviaBot_Questions[7]['Question'][315] = "What is the starting place for Orcs?";
TriviaBot_Questions[7]['Answers'][315] = {"Valley of Trials",  "The Valley of Trials"};
TriviaBot_Questions[7]['Category'][315] = 1;
TriviaBot_Questions[7]['Points'][315] = 1;
TriviaBot_Questions[7]['Hints'][315] = {};

TriviaBot_Questions[7]['Question'][316] = "In what zone lies Tempest Keep?";
TriviaBot_Questions[7]['Answers'][316] = {"Netherstorm",  "The Netherstorm"};
TriviaBot_Questions[7]['Category'][316] = 1;
TriviaBot_Questions[7]['Points'][316] = 1;
TriviaBot_Questions[7]['Hints'][316] = {};

TriviaBot_Questions[7]['Question'][317] = "In what zone is Razorfen Kraul in?";
TriviaBot_Questions[7]['Answers'][317] = {"The Barrens",  "Barrens"};
TriviaBot_Questions[7]['Category'][317] = 1;
TriviaBot_Questions[7]['Points'][317] = 1;
TriviaBot_Questions[7]['Hints'][317] = {};

TriviaBot_Questions[7]['Question'][318] = "In what zone does Gruul the Dragonslayer live?";
TriviaBot_Questions[7]['Answers'][318] = {"Blade's Edge Mountains",  "Blades Edge Mountains"};
TriviaBot_Questions[7]['Category'][318] = 1;
TriviaBot_Questions[7]['Points'][318] = 1;
TriviaBot_Questions[7]['Hints'][318] = {};

TriviaBot_Questions[7]['Question'][319] = "In what zone is Auchindoun in?";
TriviaBot_Questions[7]['Answers'][319] = {"Terokkar forest",  "Terokkar"};
TriviaBot_Questions[7]['Category'][319] = 1;
TriviaBot_Questions[7]['Points'][319] = 1;
TriviaBot_Questions[7]['Hints'][319] = {};

TriviaBot_Questions[7]['Question'][320] = "In what zone does Lady Vashj reside in?";
TriviaBot_Questions[7]['Answers'][320] = {"Zangarmarsh"};
TriviaBot_Questions[7]['Category'][320] = 1;
TriviaBot_Questions[7]['Points'][320] = 1;
TriviaBot_Questions[7]['Hints'][320] = {};

TriviaBot_Questions[7]['Question'][321] = "Where can you find Kargath Bladefist?";
TriviaBot_Questions[7]['Answers'][321] = {"Hellfire Peninsula"};
TriviaBot_Questions[7]['Category'][321] = 1;
TriviaBot_Questions[7]['Points'][321] = 1;
TriviaBot_Questions[7]['Hints'][321] = {};

TriviaBot_Questions[7]['Question'][322] = "What is the name of dranei's starting zone?";
TriviaBot_Questions[7]['Answers'][322] = {"Azuremyst Isle"};
TriviaBot_Questions[7]['Category'][322] = 1;
TriviaBot_Questions[7]['Points'][322] = 1;
TriviaBot_Questions[7]['Hints'][322] = {};

TriviaBot_Questions[7]['Question'][323] = "What is the name of the blood elves starting zone?";
TriviaBot_Questions[7]['Answers'][323] = {"Eversong Woods"};
TriviaBot_Questions[7]['Category'][323] = 1;
TriviaBot_Questions[7]['Points'][323] = 1;
TriviaBot_Questions[7]['Hints'][323] = {};

TriviaBot_Questions[7]['Question'][324] = "What is the name of zone that contains Zul'Aman?";
TriviaBot_Questions[7]['Answers'][324] = {"Ghostlands",  "Ghostland"};
TriviaBot_Questions[7]['Category'][324] = 1;
TriviaBot_Questions[7]['Points'][324] = 1;
TriviaBot_Questions[7]['Hints'][324] = {};

TriviaBot_Questions[7]['Question'][325] = "Acronyms: What does JC stand for?";
TriviaBot_Questions[7]['Answers'][325] = {"Jewelcrafter",  "Jewelcrafting"};
TriviaBot_Questions[7]['Category'][325] = 1;
TriviaBot_Questions[7]['Points'][325] = 1;
TriviaBot_Questions[7]['Hints'][325] = {};

TriviaBot_Questions[7]['Question'][326] = "Who is the leader of Ashtongue Deathsworn?";
TriviaBot_Questions[7]['Answers'][326] = {"Akama"};
TriviaBot_Questions[7]['Category'][326] = 1;
TriviaBot_Questions[7]['Points'][326] = 1;
TriviaBot_Questions[7]['Hints'][326] = {};

TriviaBot_Questions[7]['Question'][327] = "Where is Caverns of Time?";
TriviaBot_Questions[7]['Answers'][327] = {"Tanaris"};
TriviaBot_Questions[7]['Category'][327] = 1;
TriviaBot_Questions[7]['Points'][327] = 1;
TriviaBot_Questions[7]['Hints'][327] = {};

TriviaBot_Questions[7]['Question'][328] = "Where do you fight 'Epoch Hunter'?";
TriviaBot_Questions[7]['Answers'][328] = {"Durnholde",  "Escape from Durnholde Keep", "CoT - Durnholde", "CoT - Escape from Durnholde Keep", "Escape from Durnholde", "CoT - Escape from Durnholde"};
TriviaBot_Questions[7]['Category'][328] = 1;
TriviaBot_Questions[7]['Points'][328] = 1;
TriviaBot_Questions[7]['Hints'][328] = {};

TriviaBot_Questions[7]['Question'][329] = "What is the name of the zone where you protect Medivith? Its future name is the Blasted Lands.";
TriviaBot_Questions[7]['Answers'][329] = {"Black Morass"};
TriviaBot_Questions[7]['Category'][329] = 1;
TriviaBot_Questions[7]['Points'][329] = 1;
TriviaBot_Questions[7]['Hints'][329] = {};

TriviaBot_Questions[7]['Question'][330] = "In what zone is Molten Core?";
TriviaBot_Questions[7]['Answers'][330] = {"Searing Gorge",  "Burning Steppes"};
TriviaBot_Questions[7]['Category'][330] = 1;
TriviaBot_Questions[7]['Points'][330] = 1;
TriviaBot_Questions[7]['Hints'][330] = {};

TriviaBot_Questions[7]['Question'][331] = "In what zone is Zul'Gurub?";
TriviaBot_Questions[7]['Answers'][331] = {"Stranglethorn Vale",  "STV"};
TriviaBot_Questions[7]['Category'][331] = 1;
TriviaBot_Questions[7]['Points'][331] = 1;
TriviaBot_Questions[7]['Hints'][331] = {};

TriviaBot_Questions[7]['Question'][332] = "In what zone is Naxxramas in?";
TriviaBot_Questions[7]['Answers'][332] = {"Dragonblight"};
TriviaBot_Questions[7]['Category'][332] = 1;
TriviaBot_Questions[7]['Points'][332] = 1;
TriviaBot_Questions[7]['Hints'][332] = {};

TriviaBot_Questions[7]['Question'][333] = "What was the patch that came out before the expansion (tbc) called?";
TriviaBot_Questions[7]['Answers'][333] = {"Before the Storm"};
TriviaBot_Questions[7]['Category'][333] = 1;
TriviaBot_Questions[7]['Points'][333] = 1;
TriviaBot_Questions[7]['Hints'][333] = {};

TriviaBot_Questions[7]['Question'][334] = "What is the name of the populare auctioning addon?";
TriviaBot_Questions[7]['Answers'][334] = {"Auctioneer"};
TriviaBot_Questions[7]['Category'][334] = 1;
TriviaBot_Questions[7]['Points'][334] = 1;
TriviaBot_Questions[7]['Hints'][334] = {};

TriviaBot_Questions[7]['Question'][335] = "Where was the Tomb of Sargeras located";
TriviaBot_Questions[7]['Answers'][335] = {"Broken Isles", "The Broken Isles"};
TriviaBot_Questions[7]['Category'][335] = 1;
TriviaBot_Questions[7]['Points'][335] = 1;
TriviaBot_Questions[7]['Hints'][335] = {};

TriviaBot_Questions[7]['Question'][336] = "Who are the  Daggerspine?";
TriviaBot_Questions[7]['Answers'][336] = {"naga",  "nagas"};
TriviaBot_Questions[7]['Category'][336] = 1;
TriviaBot_Questions[7]['Points'][336] = 1;
TriviaBot_Questions[7]['Hints'][336] = {};

TriviaBot_Questions[7]['Question'][337] = "What is the blood elves mount called?";
TriviaBot_Questions[7]['Answers'][337] = {"Hawkstrider"};
TriviaBot_Questions[7]['Category'][337] = 1;
TriviaBot_Questions[7]['Points'][337] = 1;
TriviaBot_Questions[7]['Hints'][337] = {};

TriviaBot_Questions[7]['Question'][338] = "What guild is infamous for its raiding achievments, such as world first C'thun and Kel'Thuzad kill?";
TriviaBot_Questions[7]['Answers'][338] = {"Nihilum"};
TriviaBot_Questions[7]['Category'][338] = 1;
TriviaBot_Questions[7]['Points'][338] = 1;
TriviaBot_Questions[7]['Hints'][338] = {};

TriviaBot_Questions[7]['Question'][339] = "What guild was considered to be the 'best' raiding guild in terms of first kills and that sort of things, on the US servers?";
TriviaBot_Questions[7]['Answers'][339] = {"DT",  "Death & Taxes", "Death and Taxes"};
TriviaBot_Questions[7]['Category'][339] = 1;
TriviaBot_Questions[7]['Points'][339] = 1;
TriviaBot_Questions[7]['Hints'][339] = {};

TriviaBot_Questions[7]['Question'][340] = "Name one of three dreadlords that helped Sylvanas Windrunner in rebelling against Arthas";
TriviaBot_Questions[7]['Answers'][340] = {"Varimathras",  "Dethroc",  "Balnazzar"};
TriviaBot_Questions[7]['Category'][340] = 1;
TriviaBot_Questions[7]['Points'][340] = 1;
TriviaBot_Questions[7]['Hints'][340] = {};

TriviaBot_Questions[7]['Question'][341] = "What are the Bloodfeather?";
TriviaBot_Questions[7]['Answers'][341] = {"Harpies",  "Harpy"};
TriviaBot_Questions[7]['Category'][341] = 1;
TriviaBot_Questions[7]['Points'][341] = 1;
TriviaBot_Questions[7]['Hints'][341] = {};

TriviaBot_Questions[7]['Question'][342] = "_______ the Windlord was the Air Elemental Lieutenant of the Old Gods.";
TriviaBot_Questions[7]['Answers'][342] = {" Al'Akir"};
TriviaBot_Questions[7]['Category'][342] = 1;
TriviaBot_Questions[7]['Points'][342] = 1;
TriviaBot_Questions[7]['Hints'][342] = {};

TriviaBot_Questions[7]['Question'][343] = "Aszune was a woman that was turned into a statue of living stone by the Oracle. What race was she?";
TriviaBot_Questions[7]['Answers'][343] = {"night elf",  "Kaldorei"};
TriviaBot_Questions[7]['Category'][343] = 1;
TriviaBot_Questions[7]['Points'][343] = 1;
TriviaBot_Questions[7]['Hints'][343] = {};

TriviaBot_Questions[7]['Question'][344] = "What is the nathrezim race also known as?";
TriviaBot_Questions[7]['Answers'][344] = {"Dreadlord",  "Dreadlords"};
TriviaBot_Questions[7]['Category'][344] = 1;
TriviaBot_Questions[7]['Points'][344] = 1;
TriviaBot_Questions[7]['Hints'][344] = {};

TriviaBot_Questions[7]['Question'][345] = "What is Bladefist's first name?";
TriviaBot_Questions[7]['Answers'][345] = {"Kargath"};
TriviaBot_Questions[7]['Category'][345] = 1;
TriviaBot_Questions[7]['Points'][345] = 1;
TriviaBot_Questions[7]['Hints'][345] = {};

TriviaBot_Questions[7]['Question'][346] = "What is 'The Venture Co.' mostly made of?";
TriviaBot_Questions[7]['Answers'][346] = {"Goblin",  "Goblins"};
TriviaBot_Questions[7]['Category'][346] = 1;
TriviaBot_Questions[7]['Points'][346] = 1;
TriviaBot_Questions[7]['Hints'][346] = {}; 

TriviaBot_Questions[7]['Question'][347] = "Who became the first satyr?";
TriviaBot_Questions[7]['Answers'][347] = {"Xavius"};
TriviaBot_Questions[7]['Category'][347] = 1;
TriviaBot_Questions[7]['Points'][347] = 1;
TriviaBot_Questions[7]['Hints'][347] = {};

TriviaBot_Questions[7]['Question'][348] = "Where is Uldum located?";
TriviaBot_Questions[7]['Answers'][348] = {"Tanaris"};
TriviaBot_Questions[7]['Category'][348] = 1;
TriviaBot_Questions[7]['Points'][348] = 1;
TriviaBot_Questions[7]['Hints'][348] = {};

TriviaBot_Questions[7]['Question'][349] = "Who is C'thun?";
TriviaBot_Questions[7]['Answers'][349] = {"Old God",  "an Old God"};
TriviaBot_Questions[7]['Category'][349] = 1;
TriviaBot_Questions[7]['Points'][349] = 1;
TriviaBot_Questions[7]['Hints'][349] = {};

TriviaBot_Questions[7]['Question'][350] = "Who leads the orcish Dragonmaw clan?";
TriviaBot_Questions[7]['Answers'][350] = {"Zuluhed the Whacked", "Zuluhed"};
TriviaBot_Questions[7]['Category'][350] = 1;
TriviaBot_Questions[7]['Points'][350] = 1;
TriviaBot_Questions[7]['Hints'][350] = {};

TriviaBot_Questions[7]['Question'][351] = "The acronym 'SW' refers to?";
TriviaBot_Questions[7]['Answers'][351] = {"Stormwind"};
TriviaBot_Questions[7]['Category'][351] = 1;
TriviaBot_Questions[7]['Points'][351] = 1;
TriviaBot_Questions[7]['Hints'][351] = {};

TriviaBot_Questions[7]['Question'][352] = "The acronym 'UC' refers to?";
TriviaBot_Questions[7]['Answers'][352] = {"Undercity"};
TriviaBot_Questions[7]['Category'][352] = 1;
TriviaBot_Questions[7]['Points'][352] = 1;
TriviaBot_Questions[7]['Hints'][352] = {};

TriviaBot_Questions[7]['Question'][353] = "The acronym 'SM' refers to?";
TriviaBot_Questions[7]['Answers'][353] = {"Scarlet Monastery"};
TriviaBot_Questions[7]['Category'][353] = 1;
TriviaBot_Questions[7]['Points'][353] = 1;
TriviaBot_Questions[7]['Hints'][353] = {};

TriviaBot_Questions[7]['Question'][354] = "The acronym 'RFD' refers to?";
TriviaBot_Questions[7]['Answers'][354] = {"Razorfen downs"};
TriviaBot_Questions[7]['Category'][354] = 1;
TriviaBot_Questions[7]['Points'][354] = 1;
TriviaBot_Questions[7]['Hints'][354] = {};

TriviaBot_Questions[7]['Question'][355] = "The abbreviation 'BFD' refers to?";
TriviaBot_Questions[7]['Answers'][355] = {"Blackfathom Deeps"};
TriviaBot_Questions[7]['Category'][355] = 1;
TriviaBot_Questions[7]['Points'][355] = 1;
TriviaBot_Questions[7]['Hints'][355] = {};

TriviaBot_Questions[7]['Question'][356] = "Who was Jaina Proudmoore's teacher?";
TriviaBot_Questions[7]['Answers'][356] = {"Antonidas"};
TriviaBot_Questions[7]['Category'][356] = 1;
TriviaBot_Questions[7]['Points'][356] = 1;
TriviaBot_Questions[7]['Hints'][356] = {};

TriviaBot_Questions[7]['Question'][357] = "What zone lies north of Ashenvale?";
TriviaBot_Questions[7]['Answers'][357] = {"Felwood"};
TriviaBot_Questions[7]['Category'][357] = 1;
TriviaBot_Questions[7]['Points'][357] = 1;
TriviaBot_Questions[7]['Hints'][357] = {};

TriviaBot_Questions[7]['Question'][358] = "The acronym 'WC' refers to (in wow)?";
TriviaBot_Questions[7]['Answers'][358] = {"Wailing Caverns"};
TriviaBot_Questions[7]['Category'][358] = 1;
TriviaBot_Questions[7]['Points'][358] = 1;
TriviaBot_Questions[7]['Hints'][358] = {};

TriviaBot_Questions[7]['Question'][359] = "The acronym 'RFK' refers to?";
TriviaBot_Questions[7]['Answers'][359] = {"Razorfen Kraul"};
TriviaBot_Questions[7]['Category'][359] = 1;
TriviaBot_Questions[7]['Points'][359] = 1;
TriviaBot_Questions[7]['Hints'][359] = {};

TriviaBot_Questions[7]['Question'][360] = "The acronym 'RFC' refers to?";
TriviaBot_Questions[7]['Answers'][360] = {"Ragefire Chasm"};
TriviaBot_Questions[7]['Category'][360] = 1;
TriviaBot_Questions[7]['Points'][360] = 1;
TriviaBot_Questions[7]['Hints'][360] = {};

TriviaBot_Questions[7]['Question'][361] = "The acronym 'PST' refers to?";
TriviaBot_Questions[7]['Answers'][361] = {"Please send tell"};
TriviaBot_Questions[7]['Category'][361] = 1;
TriviaBot_Questions[7]['Points'][361] = 1;
TriviaBot_Questions[7]['Hints'][361] = {};

TriviaBot_Questions[7]['Question'][362] = "The acronym 'Strat' refers to?";
TriviaBot_Questions[7]['Answers'][362] = {"Stratholme"};
TriviaBot_Questions[7]['Category'][362] = 1;
TriviaBot_Questions[7]['Points'][362] = 1;
TriviaBot_Questions[7]['Hints'][362] = {};

TriviaBot_Questions[7]['Question'][363] = "The acronym 'ST' refers to?";
TriviaBot_Questions[7]['Answers'][363] = {"Sunken Temple",  "The Temple of Atal'hakkar", "Temple of Atal'hakkar"};
TriviaBot_Questions[7]['Category'][363] = 1;
TriviaBot_Questions[7]['Points'][363] = 1;
TriviaBot_Questions[7]['Hints'][363] = {};

TriviaBot_Questions[7]['Question'][364] = "The abbreviation 'Ony' refers to?";
TriviaBot_Questions[7]['Answers'][364] = {"Onyxia"};
TriviaBot_Questions[7]['Category'][364] = 1;
TriviaBot_Questions[7]['Points'][364] = 1;
TriviaBot_Questions[7]['Hints'][364] = {};

TriviaBot_Questions[7]['Question'][365] = "The acronym 'IF' refers to?";
TriviaBot_Questions[7]['Answers'][365] = {"Ironforge"};
TriviaBot_Questions[7]['Category'][365] = 1;
TriviaBot_Questions[7]['Points'][365] = 1;
TriviaBot_Questions[7]['Hints'][365] = {};

TriviaBot_Questions[7]['Question'][366] = "The abbreviation 'Uld' refers to?";
TriviaBot_Questions[7]['Answers'][366] = {"Uldaman"};
TriviaBot_Questions[7]['Category'][366] = 1;
TriviaBot_Questions[7]['Points'][366] = 1;
TriviaBot_Questions[7]['Hints'][366] = {};

TriviaBot_Questions[7]['Question'][367] = "The acronym 'UBRS' refers to?";
TriviaBot_Questions[7]['Answers'][367] = {"Upper Blackrock Spire"};
TriviaBot_Questions[7]['Category'][367] = 1;
TriviaBot_Questions[7]['Points'][367] = 1;
TriviaBot_Questions[7]['Hints'][367] = {};


TriviaBot_Questions[7]['Question'][368] = "The acronym 'BRS' refers to?";
TriviaBot_Questions[7]['Answers'][368] = {"Blackrock Spire"};
TriviaBot_Questions[7]['Category'][368] = 1;
TriviaBot_Questions[7]['Points'][368] = 1;
TriviaBot_Questions[7]['Hints'][368] = {};

TriviaBot_Questions[7]['Question'][369] = "The acronym 'LBRS' refers to?";
TriviaBot_Questions[7]['Answers'][369] = {"Lower Blackrock Spire"};
TriviaBot_Questions[7]['Category'][369] = 1;
TriviaBot_Questions[7]['Points'][369] = 1;
TriviaBot_Questions[7]['Hints'][369] = {};

TriviaBot_Questions[7]['Question'][370] = "The acronym 'DOT' refers to?";
TriviaBot_Questions[7]['Answers'][370] = {"Damage over Time"};
TriviaBot_Questions[7]['Category'][370] = 1;
TriviaBot_Questions[7]['Points'][370] = 1;
TriviaBot_Questions[7]['Hints'][370] = {};

TriviaBot_Questions[7]['Question'][371] = "The acronym 'HOT' refers to?";
TriviaBot_Questions[7]['Answers'][371] = {"Healing over Time"};
TriviaBot_Questions[7]['Category'][371] = 1;
TriviaBot_Questions[7]['Points'][371] = 1;
TriviaBot_Questions[7]['Hints'][371] = {};

TriviaBot_Questions[7]['Question'][372] = "The acronym 'WTB' refers to?";
TriviaBot_Questions[7]['Answers'][372] = {"Want to buy"};
TriviaBot_Questions[7]['Category'][372] = 1;
TriviaBot_Questions[7]['Points'][372] = 1;
TriviaBot_Questions[7]['Hints'][372] = {};

TriviaBot_Questions[7]['Question'][373] = "The acronym 'WTS' refers to?";
TriviaBot_Questions[7]['Answers'][373] = {"Want to Sell"};
TriviaBot_Questions[7]['Category'][373] = 1;
TriviaBot_Questions[7]['Points'][373] = 1;
TriviaBot_Questions[7]['Hints'][373] = {};

TriviaBot_Questions[7]['Question'][374] = "The acronym 'GZ' refers to? (not the city, the word)";
TriviaBot_Questions[7]['Answers'][374] = {"Congratulations"};
TriviaBot_Questions[7]['Category'][374] = 1;
TriviaBot_Questions[7]['Points'][374] = 1;
TriviaBot_Questions[7]['Hints'][374] = {};

TriviaBot_Questions[7]['Question'][375] = "The abbreviation 'Scholo' refers to?";
TriviaBot_Questions[7]['Answers'][375] = {"Scholomance"};
TriviaBot_Questions[7]['Category'][375] = 1;
TriviaBot_Questions[7]['Points'][375] = 1;
TriviaBot_Questions[7]['Hints'][375] = {};

TriviaBot_Questions[7]['Question'][376] = "The acronym 'XP' refers to?";
TriviaBot_Questions[7]['Answers'][376] = {"Experience Point",  "Experience Points"};
TriviaBot_Questions[7]['Category'][376] = 1;
TriviaBot_Questions[7]['Points'][376] = 1;
TriviaBot_Questions[7]['Hints'][376] = {};

TriviaBot_Questions[7]['Question'][377] = "The acronym 'DM' refers to what instance, in Feralas?";
TriviaBot_Questions[7]['Answers'][377] = {"Dire Maul"};
TriviaBot_Questions[7]['Category'][377] = 1;
TriviaBot_Questions[7]['Points'][377] = 1;
TriviaBot_Questions[7]['Hints'][377] = {};

TriviaBot_Questions[7]['Question'][378] = "The acronym 'DM' refers to what instance, in Westfall?";
TriviaBot_Questions[7]['Answers'][378] = {"The Deadmines",  "Deadmines"};
TriviaBot_Questions[7]['Category'][378] = 1;
TriviaBot_Questions[7]['Points'][378] = 1;
TriviaBot_Questions[7]['Hints'][378] = {};

TriviaBot_Questions[7]['Question'][379] = "The acronym 'AV' refers to?";
TriviaBot_Questions[7]['Answers'][379] = {"Alterac valley"};
TriviaBot_Questions[7]['Category'][379] = 1;
TriviaBot_Questions[7]['Points'][379] = 1;
TriviaBot_Questions[7]['Hints'][379] = {};

TriviaBot_Questions[7]['Question'][380] = "The acronym 'AB' refers to?";
TriviaBot_Questions[7]['Answers'][380] = {"Arathi Basin"};
TriviaBot_Questions[7]['Category'][380] = 1;
TriviaBot_Questions[7]['Points'][380] = 1;
TriviaBot_Questions[7]['Hints'][380] = {};

TriviaBot_Questions[7]['Question'][381] = "The acronym 'WSG' refers to?";
TriviaBot_Questions[7]['Answers'][381] = {"Warsong Gulch"};
TriviaBot_Questions[7]['Category'][381] = 1;
TriviaBot_Questions[7]['Points'][381] = 1;
TriviaBot_Questions[7]['Hints'][381] = {};

TriviaBot_Questions[7]['Question'][382] = "The acronym 'AOE' refers to?";
TriviaBot_Questions[7]['Answers'][382] = {"Area of Effect",  "Area of Effects"};
TriviaBot_Questions[7]['Category'][382] = 1;
TriviaBot_Questions[7]['Points'][382] = 1;
TriviaBot_Questions[7]['Hints'][382] = {};

TriviaBot_Questions[7]['Question'][383] = "The acronym 'LFM' refers to?";
TriviaBot_Questions[7]['Answers'][383] = {"Looking for More",  "Looking for more people"};
TriviaBot_Questions[7]['Category'][383] = 1;
TriviaBot_Questions[7]['Points'][383] = 1;
TriviaBot_Questions[7]['Hints'][383] = {};

TriviaBot_Questions[7]['Question'][384] = "The acronym 'LFG' refers to?";
TriviaBot_Questions[7]['Answers'][384] = {"Looking for Group"};
TriviaBot_Questions[7]['Category'][384] = 1;
TriviaBot_Questions[7]['Points'][384] = 1;
TriviaBot_Questions[7]['Hints'][384] = {};

TriviaBot_Questions[7]['Question'][385] = "The acronym 'Mara' refers to?";
TriviaBot_Questions[7]['Answers'][385] = {"Maraudon"};
TriviaBot_Questions[7]['Category'][385] = 1;
TriviaBot_Questions[7]['Points'][385] = 1;
TriviaBot_Questions[7]['Hints'][385] = {};

TriviaBot_Questions[7]['Question'][386] = "The acronym 'MT' refers to?";
TriviaBot_Questions[7]['Answers'][386] = {"Main Tank"};
TriviaBot_Questions[7]['Category'][386] = 1;
TriviaBot_Questions[7]['Points'][386] = 1;
TriviaBot_Questions[7]['Hints'][386] = {};

TriviaBot_Questions[7]['Question'][387] = "The acronym 'OT' refers to?";
TriviaBot_Questions[7]['Answers'][387] = {"Off tank"};
TriviaBot_Questions[7]['Category'][387] = 1;
TriviaBot_Questions[7]['Points'][387] = 1;
TriviaBot_Questions[7]['Hints'][387] = {};

TriviaBot_Questions[7]['Question'][388] = "The acronyms 'IRL/RL' refers to? (name one of them)";
TriviaBot_Questions[7]['Answers'][388] = {"In real life",  "real life"};
TriviaBot_Questions[7]['Category'][388] = 1;
TriviaBot_Questions[7]['Points'][388] = 1;
TriviaBot_Questions[7]['Hints'][388] = {};

TriviaBot_Questions[7]['Question'][389] = "The acronym 'GM' refers to? (name one of them)";
TriviaBot_Questions[7]['Answers'][389] = {"Game Master",  "Guild Master"};
TriviaBot_Questions[7]['Category'][389] = 1;
TriviaBot_Questions[7]['Points'][389] = 1;
TriviaBot_Questions[7]['Hints'][389] = {};

TriviaBot_Questions[7]['Question'][390] = "The acronym 'HFR' refers to?";
TriviaBot_Questions[7]['Answers'][390] = {"Hellfire Ramparts"};
TriviaBot_Questions[7]['Category'][390] = 1;
TriviaBot_Questions[7]['Points'][390] = 1;
TriviaBot_Questions[7]['Hints'][390] = {};

TriviaBot_Questions[7]['Question'][391] = "The acronym 'SH' refers to?";
TriviaBot_Questions[7]['Answers'][391] = {"Shattered Halls",  "The Shattered Halls"};
TriviaBot_Questions[7]['Category'][391] = 1;
TriviaBot_Questions[7]['Points'][391] = 1;
TriviaBot_Questions[7]['Hints'][391] = {};

TriviaBot_Questions[7]['Question'][392] = "The acronym 'SP' refers to?";
TriviaBot_Questions[7]['Answers'][392] = {"Slave Pens",  "The Slave Pens"};
TriviaBot_Questions[7]['Category'][392] = 1;
TriviaBot_Questions[7]['Points'][392] = 1;
TriviaBot_Questions[7]['Hints'][392] = {};

TriviaBot_Questions[7]['Question'][393] = "The acronym 'UB' refers to?";
TriviaBot_Questions[7]['Answers'][393] = {"Underbog",  "The underbog"};
TriviaBot_Questions[7]['Category'][393] = 1;
TriviaBot_Questions[7]['Points'][393] = 1;
TriviaBot_Questions[7]['Hints'][393] = {};

TriviaBot_Questions[7]['Question'][394] = "The acronym 'SV' refers to?";
TriviaBot_Questions[7]['Answers'][394] = {"The Steamvault",  "Steamvault"};
TriviaBot_Questions[7]['Category'][394] = 1;
TriviaBot_Questions[7]['Points'][394] = 1;
TriviaBot_Questions[7]['Hints'][394] = {};

TriviaBot_Questions[7]['Question'][395] = "The acronym 'NE' refers to (not the direction, the race)?";
TriviaBot_Questions[7]['Answers'][395] = {"night elf"};
TriviaBot_Questions[7]['Category'][395] = 1;
TriviaBot_Questions[7]['Points'][395] = 1;
TriviaBot_Questions[7]['Hints'][395] = {};

TriviaBot_Questions[7]['Question'][396] = "The acronym 'WOTLK' refers to?";
TriviaBot_Questions[7]['Answers'][396] = {"Wrath of the Lich King"};
TriviaBot_Questions[7]['Category'][396] = 1;
TriviaBot_Questions[7]['Points'][396] = 1;
TriviaBot_Questions[7]['Hints'][396] = {};

TriviaBot_Questions[7]['Question'][397] = "The abbreviation 'Resto' refers to what? (hint: talent tree)";
TriviaBot_Questions[7]['Answers'][397] = {"Restoration"};
TriviaBot_Questions[7]['Category'][397] = 1;
TriviaBot_Questions[7]['Points'][397] = 1;
TriviaBot_Questions[7]['Hints'][397] = {};

TriviaBot_Questions[7]['Question'][398] = "The abbreviation 'Mats' refers to?";
TriviaBot_Questions[7]['Answers'][398] = {"Materials"};
TriviaBot_Questions[7]['Category'][398] = 1;
TriviaBot_Questions[7]['Points'][398] = 1;
TriviaBot_Questions[7]['Hints'][398] = {};

TriviaBot_Questions[7]['Question'][399] = "The acronym 'PUG' refers to?";
TriviaBot_Questions[7]['Answers'][399] = {"pick up group"};
TriviaBot_Questions[7]['Category'][399] = 1;
TriviaBot_Questions[7]['Points'][399] = 1;
TriviaBot_Questions[7]['Hints'][399] = {};

TriviaBot_Questions[7]['Question'][400] = "The acronym 'CC' refers to?";
TriviaBot_Questions[7]['Answers'][400] = {"Crowd Control"};
TriviaBot_Questions[7]['Category'][400] = 1;
TriviaBot_Questions[7]['Points'][400] = 1;
TriviaBot_Questions[7]['Hints'][400] = {};

TriviaBot_Questions[7]['Question'][401] = "The acronym 'AP' refers to?";
TriviaBot_Questions[7]['Answers'][401] = {"Attack power"};
TriviaBot_Questions[7]['Category'][401] = 1;
TriviaBot_Questions[7]['Points'][401] = 1;
TriviaBot_Questions[7]['Hints'][401] = {};

TriviaBot_Questions[7]['Question'][402] = "The acronym 'LOS' refers to?";
TriviaBot_Questions[7]['Answers'][402] = {"line of sight"};
TriviaBot_Questions[7]['Category'][402] = 1;
TriviaBot_Questions[7]['Points'][402] = 1;
TriviaBot_Questions[7]['Hints'][402] = {};

TriviaBot_Questions[7]['Question'][403] = "The acronym 'AQ20' refers to? (the full name)";
TriviaBot_Questions[7]['Answers'][403] = {"Ruins of Ahn'Qiraj",  "The Ruins of Ahn'Qiraj"};
TriviaBot_Questions[7]['Category'][403] = 1;
TriviaBot_Questions[7]['Points'][403] = 1;
TriviaBot_Questions[7]['Hints'][403] = {};

TriviaBot_Questions[7]['Question'][404] = "The acronym 'AQ40' refers to? (the full name)";
TriviaBot_Questions[7]['Answers'][404] = {"Temple of Ahn'Qiraj",  "The Temple of Ahn'Qiraj"};
TriviaBot_Questions[7]['Category'][404] = 1;
TriviaBot_Questions[7]['Points'][404] = 1;
TriviaBot_Questions[7]['Hints'][404] = {};

TriviaBot_Questions[7]['Question'][405] = "The acronym 'BEM' refers to?";
TriviaBot_Questions[7]['Answers'][405] = {"Blade's Edge Mountains",  "Blades Edge Mountains"};
TriviaBot_Questions[7]['Category'][405] = 1;
TriviaBot_Questions[7]['Points'][405] = 1;
TriviaBot_Questions[7]['Hints'][405] = {};

TriviaBot_Questions[7]['Question'][406] = "The acronym 'BWL' refers to?";
TriviaBot_Questions[7]['Answers'][406] = {"Blackwing Lair"};
TriviaBot_Questions[7]['Category'][406] = 1;
TriviaBot_Questions[7]['Points'][406] = 1;
TriviaBot_Questions[7]['Hints'][406] = {};

TriviaBot_Questions[7]['Question'][407] = "The acronym 'KZ' refers to? (the full name)";
TriviaBot_Questions[7]['Answers'][407] = {"Karazhan"};
TriviaBot_Questions[7]['Category'][407] = 1;
TriviaBot_Questions[7]['Points'][407] = 1;
TriviaBot_Questions[7]['Hints'][407] = {};

TriviaBot_Questions[7]['Question'][408] = "The acronym 'EPL' refers to?";
TriviaBot_Questions[7]['Answers'][408] = {"Eastern Plaguelands"};
TriviaBot_Questions[7]['Category'][408] = 1;
TriviaBot_Questions[7]['Points'][408] = 1;
TriviaBot_Questions[7]['Hints'][408] = {};

TriviaBot_Questions[7]['Question'][409] = "The acronym 'CFR' refers to?";
TriviaBot_Questions[7]['Answers'][409] = {"Coilfang Reservoir"};
TriviaBot_Questions[7]['Category'][409] = 1;
TriviaBot_Questions[7]['Points'][409] = 1;
TriviaBot_Questions[7]['Hints'][409] = {};

TriviaBot_Questions[7]['Question'][410] = "The acronym 'SL' refers to?";
TriviaBot_Questions[7]['Answers'][410] = {"Shadow Labyrinth"};
TriviaBot_Questions[7]['Category'][410] = 1;
TriviaBot_Questions[7]['Points'][410] = 1;
TriviaBot_Questions[7]['Hints'][410] = {};

TriviaBot_Questions[7]['Question'][411] = "The acronymn 'SSC' refers to?";
TriviaBot_Questions[7]['Answers'][411] = {"Serpentshrine Cavern"};
TriviaBot_Questions[7]['Category'][411] = 1;
TriviaBot_Questions[7]['Points'][411] = 1;
TriviaBot_Questions[7]['Hints'][411] = {};

TriviaBot_Questions[7]['Question'][412] = "The acronym 'SMV' refers to?";
TriviaBot_Questions[7]['Answers'][412] = {"Shadowmoon valley"};
TriviaBot_Questions[7]['Category'][412] = 1;
TriviaBot_Questions[7]['Points'][412] = 1;
TriviaBot_Questions[7]['Hints'][412] = {};

TriviaBot_Questions[7]['Question'][413] = "Which boss in Ulduar is a clockwork giant?";
TriviaBot_Questions[7]['Answers'][413] = {"XT-002",  "XT-002 Deconstructor"};
TriviaBot_Questions[7]['Category'][413] = 1;
TriviaBot_Questions[7]['Points'][413] = 1;
TriviaBot_Questions[7]['Hints'][413] = {};

TriviaBot_Questions[7]['Question'][414] = "Where is Maraudon?";
TriviaBot_Questions[7]['Answers'][414] = {"Desolace"};
TriviaBot_Questions[7]['Category'][414] = 1;
TriviaBot_Questions[7]['Points'][414] = 1;
TriviaBot_Questions[7]['Hints'][414] = {};

TriviaBot_Questions[7]['Question'][415] = "the Scourge was created by a being called ______________.";
TriviaBot_Questions[7]['Answers'][415] = {"The Lich King",  "Lich King"};
TriviaBot_Questions[7]['Category'][415] = 1;
TriviaBot_Questions[7]['Points'][415] = 1;
TriviaBot_Questions[7]['Hints'][415] = {};

TriviaBot_Questions[7]['Question'][416] = "Which boss is actually 3 bosses in Ulduar?";
TriviaBot_Questions[7]['Answers'][416] = {"The Iron Council",  "Iron Council"};
TriviaBot_Questions[7]['Category'][416] = 1;
TriviaBot_Questions[7]['Points'][416] = 1;
TriviaBot_Questions[7]['Hints'][416] = {};

TriviaBot_Questions[7]['Question'][417] = "Which boss in Ulduar must you also fight his arms?";
TriviaBot_Questions[7]['Answers'][417] = {"Kologarn"};
TriviaBot_Questions[7]['Category'][417] = 1;
TriviaBot_Questions[7]['Points'][417] = 1;
TriviaBot_Questions[7]['Hints'][417] = {};

TriviaBot_Questions[7]['Question'][418] = "Which boss in Ulduar created the Flame Leviathan?";
TriviaBot_Questions[7]['Answers'][418] = {"Mimiron"};
TriviaBot_Questions[7]['Category'][418] = 1;
TriviaBot_Questions[7]['Points'][418] = 1;
TriviaBot_Questions[7]['Hints'][418] = {};

TriviaBot_Questions[7]['Question'][419] = "Which boss in Ulduar uses Shadow Crash?";
TriviaBot_Questions[7]['Answers'][419] = {"General Vezax"};
TriviaBot_Questions[7]['Category'][419] = 1;
TriviaBot_Questions[7]['Points'][419] = 1;
TriviaBot_Questions[7]['Hints'][419] = {};

TriviaBot_Questions[7]['Question'][420] = "Which boss in Ulduar is also called THE RAID DESTROYER by blizzard?";
TriviaBot_Questions[7]['Answers'][420] = {"Algalon",  "Algalon the Observer"};
TriviaBot_Questions[7]['Category'][420] = 1;
TriviaBot_Questions[7]['Points'][420] = 1;
TriviaBot_Questions[7]['Hints'][420] = {};

TriviaBot_Questions[7]['Question'][421] = "Which boss in Ulduar has a hard mode similar to Sartharion?";
TriviaBot_Questions[7]['Answers'][421] = {"Freya"};
TriviaBot_Questions[7]['Category'][421] = 1;
TriviaBot_Questions[7]['Points'][421] = 1;
TriviaBot_Questions[7]['Hints'][421] = {};

TriviaBot_Questions[7]['Question'][422] = "The acronym 'TM' refers to?";
TriviaBot_Questions[7]['Answers'][422] = {"Tarren Mill"};
TriviaBot_Questions[7]['Category'][422] = 1;
TriviaBot_Questions[7]['Points'][422] = 1;
TriviaBot_Questions[7]['Hints'][422] = {};

TriviaBot_Questions[7]['Question'][423] = "The acronym 'TB' refers to?";
TriviaBot_Questions[7]['Answers'][423] = {"Thunder Bluff"};
TriviaBot_Questions[7]['Category'][423] = 1;
TriviaBot_Questions[7]['Points'][423] = 1;
TriviaBot_Questions[7]['Hints'][423] = {};

TriviaBot_Questions[7]['Question'][424] = "The abbreviation 'Darn' refers to?";
TriviaBot_Questions[7]['Answers'][424] = {"Darnassus"};
TriviaBot_Questions[7]['Category'][424] = 1;
TriviaBot_Questions[7]['Points'][424] = 1;
TriviaBot_Questions[7]['Hints'][424] = {};

TriviaBot_Questions[7]['Question'][425] = "Who leads the Kar'kron?";
TriviaBot_Questions[7]['Answers'][425] = {"Varok Saurfang",  "Saurfang",  "Varok"};
TriviaBot_Questions[7]['Category'][425] = 1;
TriviaBot_Questions[7]['Points'][425] = 1;
TriviaBot_Questions[7]['Hints'][425] = {};

TriviaBot_Questions[7]['Question'][426] = "The acronym 'CoS' refers to?";
TriviaBot_Questions[7]['Answers'][426] = {"Curse of Shadow"};
TriviaBot_Questions[7]['Category'][426] = 1;
TriviaBot_Questions[7]['Points'][426] = 1;
TriviaBot_Questions[7]['Hints'][426] = {};

TriviaBot_Questions[7]['Question'][427] = "Which boss in Ulduar uses Flash Freeze?";
TriviaBot_Questions[7]['Answers'][427] = {"Hodir"};
TriviaBot_Questions[7]['Category'][427] = 1;
TriviaBot_Questions[7]['Points'][427] = 1;
TriviaBot_Questions[7]['Hints'][427] = {};

TriviaBot_Questions[7]['Question'][428] = "Who drops Mojo Frenzy Greaves?";
TriviaBot_Questions[7]['Answers'][428] = {"Moorabi"};
TriviaBot_Questions[7]['Category'][428] = 1;
TriviaBot_Questions[7]['Points'][428] = 1;
TriviaBot_Questions[7]['Hints'][428] = {};

TriviaBot_Questions[7]['Question'][429] = "What is the name of the capital city of the fallen nerubian empire?";
TriviaBot_Questions[7]['Answers'][429] = {"Azjol-Nerub"};
TriviaBot_Questions[7]['Category'][429] = 1;
TriviaBot_Questions[7]['Points'][429] = 1;
TriviaBot_Questions[7]['Hints'][429] = {};

TriviaBot_Questions[7]['Question'][430] = "What is the Boulderfist clan made of?";
TriviaBot_Questions[7]['Answers'][430] = {"Ogres",  "Ogre"};
TriviaBot_Questions[7]['Category'][430] = 1;
TriviaBot_Questions[7]['Points'][430] = 1;
TriviaBot_Questions[7]['Hints'][430] = {};

TriviaBot_Questions[7]['Question'][431] = "Keeper Remulos is the son of who?";
TriviaBot_Questions[7]['Answers'][431] = {"Cenarius"};
TriviaBot_Questions[7]['Category'][431] = 1;
TriviaBot_Questions[7]['Points'][431] = 1;
TriviaBot_Questions[7]['Hints'][431] = {};

TriviaBot_Questions[7]['Question'][432] = "Cenarius is a what?";
TriviaBot_Questions[7]['Answers'][432] = {"Demigod"};
TriviaBot_Questions[7]['Category'][432] = 1;
TriviaBot_Questions[7]['Points'][432] = 1;
TriviaBot_Questions[7]['Hints'][432] = {};

TriviaBot_Questions[7]['Question'][433] = "What is the name of the new World Tree?";
TriviaBot_Questions[7]['Answers'][433] = {"Teldrassil"};
TriviaBot_Questions[7]['Category'][433] = 1;
TriviaBot_Questions[7]['Points'][433] = 1;
TriviaBot_Questions[7]['Hints'][433] = {};

TriviaBot_Questions[7]['Question'][434] = "What is Deathwing also known as?";
TriviaBot_Questions[7]['Answers'][434] = {"Neltharion",  "Neltharion the Earth Warder", "Neltharion the Earth-Warder"};
TriviaBot_Questions[7]['Category'][434] = 1;
TriviaBot_Questions[7]['Points'][434] = 1;
TriviaBot_Questions[7]['Hints'][434] = {};

TriviaBot_Questions[7]['Question'][435] = "The Bloodscalp tribe is what kind of trolls?";
TriviaBot_Questions[7]['Answers'][435] = {"Jungle",  "Jungle Trolls"};
TriviaBot_Questions[7]['Category'][435] = 1;
TriviaBot_Questions[7]['Points'][435] = 1;
TriviaBot_Questions[7]['Hints'][435] = {};

TriviaBot_Questions[7]['Question'][436] = "Who created the Twilight's Hammer?";
TriviaBot_Questions[7]['Answers'][436] = {"Cho'gall",  "Chogall"};
TriviaBot_Questions[7]['Category'][436] = 1;
TriviaBot_Questions[7]['Points'][436] = 1;
TriviaBot_Questions[7]['Hints'][436] = {};

TriviaBot_Questions[7]['Question'][437] = "Where does the Crushridge clan live?";
TriviaBot_Questions[7]['Answers'][437] = {"Alterac",  "Alterac Mountains"};
TriviaBot_Questions[7]['Category'][437] = 1;
TriviaBot_Questions[7]['Points'][437] = 1;
TriviaBot_Questions[7]['Hints'][437] = {};

TriviaBot_Questions[7]['Question'][438] = "Where can you find Chrommagus?";
TriviaBot_Questions[7]['Answers'][438] = {"Blackwing Lair",  "BWL"};
TriviaBot_Questions[7]['Category'][438] = 1;
TriviaBot_Questions[7]['Points'][438] = 1;
TriviaBot_Questions[7]['Hints'][438] = {};

TriviaBot_Questions[7]['Question'][439] = "How much health does Hogger have?";
TriviaBot_Questions[7]['Answers'][439] = {"666"};
TriviaBot_Questions[7]['Category'][439] = 1;
TriviaBot_Questions[7]['Points'][439] = 1;
TriviaBot_Questions[7]['Hints'][439] = {};

TriviaBot_Questions[7]['Question'][440] = "What is 'Darrowmere'?";
TriviaBot_Questions[7]['Answers'][440] = {"Lake",  "A lake"};
TriviaBot_Questions[7]['Category'][440] = 1;
TriviaBot_Questions[7]['Points'][440] = 1;
TriviaBot_Questions[7]['Hints'][440] = {};

TriviaBot_Questions[7]['Question'][441] = "Who founded Quel'thalas?";
TriviaBot_Questions[7]['Answers'][441] = {"Dath'Remar",  "Dath Remar", "Dath'Remar Sunstrider", "Dath'Remar Sunstrider"};
TriviaBot_Questions[7]['Category'][441] = 1;
TriviaBot_Questions[7]['Points'][441] = 1;
TriviaBot_Questions[7]['Hints'][441] = {};

TriviaBot_Questions[7]['Question'][442] = "What is the the name of the organization that is causing Stormwind major trouble? The organization has taken over nearly all of westfall.";
TriviaBot_Questions[7]['Answers'][442] = {"Defias Brotherhood",  "The Defias Brotherhood"};
TriviaBot_Questions[7]['Category'][442] = 1;
TriviaBot_Questions[7]['Points'][442] = 1;
TriviaBot_Questions[7]['Hints'][442] = {};

TriviaBot_Questions[7]['Question'][443] = "What race is Detheroc?";
TriviaBot_Questions[7]['Answers'][443] = {"Dreadlord", "Nathrezim"};
TriviaBot_Questions[7]['Category'][443] = 1;
TriviaBot_Questions[7]['Points'][443] = 1;
TriviaBot_Questions[7]['Hints'][443] = {};

TriviaBot_Questions[7]['Question'][444] = "What is Doomhammer's first name?";
TriviaBot_Questions[7]['Answers'][444] = {"Orgrim"};
TriviaBot_Questions[7]['Category'][444] = 1;
TriviaBot_Questions[7]['Points'][444] = 1;
TriviaBot_Questions[7]['Hints'][444] = {};

TriviaBot_Questions[7]['Question'][445] = "Who is Thrall's mother?";
TriviaBot_Questions[7]['Answers'][445] = {"Draka"};
TriviaBot_Questions[7]['Category'][445] = 1;
TriviaBot_Questions[7]['Points'][445] = 1;
TriviaBot_Questions[7]['Hints'][445] = {};

TriviaBot_Questions[7]['Question'][446] = "What was Outland's true name, before it was sundered?";
TriviaBot_Questions[7]['Answers'][446] = {"Draenor"};
TriviaBot_Questions[7]['Category'][446] = 1;
TriviaBot_Questions[7]['Points'][446] = 1;
TriviaBot_Questions[7]['Hints'][446] = {};

TriviaBot_Questions[7]['Question'][447] = "Who is Thrall's advisor?";
TriviaBot_Questions[7]['Answers'][447] = {"Eitrigg"};
TriviaBot_Questions[7]['Category'][447] = 1;
TriviaBot_Questions[7]['Points'][447] = 1;
TriviaBot_Questions[7]['Hints'][447] = {};

TriviaBot_Questions[7]['Question'][448] = "Which major character is currently fighting in the Emerald Dream?";
TriviaBot_Questions[7]['Answers'][448] = {"Malfurion"};
TriviaBot_Questions[7]['Category'][448] = 1;
TriviaBot_Questions[7]['Points'][448] = 1;
TriviaBot_Questions[7]['Hints'][448] = {};

TriviaBot_Questions[7]['Question'][449] = "What is Eonar? (ex. a naga)";
TriviaBot_Questions[7]['Answers'][449] = {"Titan",  "Vanir Titan", "A titan", "A Vanir Titan"};
TriviaBot_Questions[7]['Category'][449] = 1;
TriviaBot_Questions[7]['Points'][449] = 1;
TriviaBot_Questions[7]['Hints'][449] = {};

TriviaBot_Questions[7]['Question'][450] = "That is the name of the Lich King's weapon?";
TriviaBot_Questions[7]['Answers'][450] = {"Frostmourne"};
TriviaBot_Questions[7]['Category'][450] = 1;
TriviaBot_Questions[7]['Points'][450] = 1;
TriviaBot_Questions[7]['Hints'][450] = {};

TriviaBot_Questions[7]['Question'][451] = "The Firetree tribe, which is made of forest trolls, resides in?";
TriviaBot_Questions[7]['Answers'][451] = {"UBRS",  "Upper Blackrock Spire"};
TriviaBot_Questions[7]['Category'][451] = 1;
TriviaBot_Questions[7]['Points'][451] = 1;
TriviaBot_Questions[7]['Hints'][451] = {};

TriviaBot_Questions[7]['Question'][452] = "What rank was Garithos in the armies of Lordaeron before he was killed by Varimathras?";
TriviaBot_Questions[7]['Answers'][452] = {"Grand Marshall",  "14"};
TriviaBot_Questions[7]['Category'][452] = 1;
TriviaBot_Questions[7]['Points'][452] = 1;
TriviaBot_Questions[7]['Hints'][452] = {}; 

TriviaBot_Questions[7]['Question'][453] = "Genjuros was the _______ of the blackrock clan before he died.";
TriviaBot_Questions[7]['Answers'][453] = {"Blademaster"};
TriviaBot_Questions[7]['Category'][453] = 1;
TriviaBot_Questions[7]['Points'][453] = 1;
TriviaBot_Questions[7]['Hints'][453] = {};

TriviaBot_Questions[7]['Question'][454] = "Gilneas is located in the _________ and is currently unaccessible. (hint: the continent)";
TriviaBot_Questions[7]['Answers'][454] = {"Eastern kingdoms"};
TriviaBot_Questions[7]['Category'][454] = 1;
TriviaBot_Questions[7]['Points'][454] = 1;
TriviaBot_Questions[7]['Hints'][454] = {};

TriviaBot_Questions[7]['Question'][455] = "Who is the leader of Gilneas?";
TriviaBot_Questions[7]['Answers'][455] = {"Greymane",  "Genn Graymane"};
TriviaBot_Questions[7]['Category'][455] = 1;
TriviaBot_Questions[7]['Points'][455] = 1;
TriviaBot_Questions[7]['Hints'][455] = {};

TriviaBot_Questions[7]['Question'][456] = "The Gurubashi empire is made of what race?";
TriviaBot_Questions[7]['Answers'][456] = {"Trolls"};
TriviaBot_Questions[7]['Category'][456] = 1;
TriviaBot_Questions[7]['Points'][456] = 1;
TriviaBot_Questions[7]['Hints'][456] = {};

TriviaBot_Questions[7]['Question'][457] = "What is Hakkar's fullname?";
TriviaBot_Questions[7]['Answers'][457] = {"Hakkar the Soulflayer"};
TriviaBot_Questions[7]['Category'][457] = 1;
TriviaBot_Questions[7]['Points'][457] = 1;
TriviaBot_Questions[7]['Hints'][457] = {};

TriviaBot_Questions[7]['Question'][458] = "What was Hellscream's first name?";
TriviaBot_Questions[7]['Answers'][458] = {"Grom"};
TriviaBot_Questions[7]['Category'][458] = 1;
TriviaBot_Questions[7]['Points'][458] = 1;
TriviaBot_Questions[7]['Hints'][458] = {};

TriviaBot_Questions[7]['Question'][459] = "Who lead the Warsong clan, before Thrall united all the orcs in Azeroth?";
TriviaBot_Questions[7]['Answers'][459] = {"Grom Hellscream"};
TriviaBot_Questions[7]['Category'][459] = 1;
TriviaBot_Questions[7]['Points'][459] = 1;
TriviaBot_Questions[7]['Hints'][459] = {};

TriviaBot_Questions[7]['Question'][460] = "What is the largest glacier on Azeroth?";
TriviaBot_Questions[7]['Answers'][460] = {"Icecrown Glacier",  "The Icecrown glacier", "The Icecrown", "Icecrown"};
TriviaBot_Questions[7]['Category'][460] = 1;
TriviaBot_Questions[7]['Points'][460] = 1;
TriviaBot_Questions[7]['Hints'][460] = {};

TriviaBot_Questions[7]['Question'][461] = "Who is Malfurion Stormrage's brother?";
TriviaBot_Questions[7]['Answers'][461] = {"Illidan",  "Illidan Stormrage"};
TriviaBot_Questions[7]['Category'][461] = 1;
TriviaBot_Questions[7]['Points'][461] = 1;
TriviaBot_Questions[7]['Hints'][461] = {};

TriviaBot_Questions[7]['Question'][462] = "Kel'Thuzad what before becoming a lich?";
TriviaBot_Questions[7]['Answers'][462] = {"Human"};
TriviaBot_Questions[7]['Category'][462] = 1;
TriviaBot_Questions[7]['Points'][462] = 1;
TriviaBot_Questions[7]['Hints'][462] = {};

TriviaBot_Questions[7]['Question'][463] = "_______ the Stonemother was the Earth Elemental Lieutenant of the Old Gods?";
TriviaBot_Questions[7]['Answers'][463] = {"Therazane"};
TriviaBot_Questions[7]['Category'][463] = 1;
TriviaBot_Questions[7]['Points'][463] = 1;
TriviaBot_Questions[7]['Hints'][463] = {};

TriviaBot_Questions[7]['Question'][464] = "Rexxar is half orc, and half ____.";
TriviaBot_Questions[7]['Answers'][464] = {"Demon"};
TriviaBot_Questions[7]['Category'][464] = 1;
TriviaBot_Questions[7]['Points'][464] = 1;
TriviaBot_Questions[7]['Hints'][464] = {};

TriviaBot_Questions[7]['Question'][465] = "In the tauren mythology, Elune is known as Mu'sha and is the left eye of the ___________.";
TriviaBot_Questions[7]['Answers'][465] = {"Earthmother",  "the Earthmother"};
TriviaBot_Questions[7]['Category'][465] = 1;
TriviaBot_Questions[7]['Points'][465] = 1;
TriviaBot_Questions[7]['Hints'][465] = {};

TriviaBot_Questions[7]['Question'][466] = "Who did Rexxar help to found Durotar?";
TriviaBot_Questions[7]['Answers'][466] = {"Thrall"};
TriviaBot_Questions[7]['Category'][466] = 1;
TriviaBot_Questions[7]['Points'][466] = 1;
TriviaBot_Questions[7]['Hints'][466] = {};

TriviaBot_Questions[7]['Question'][467] = "Who is known as 'the Lightbringer'?";
TriviaBot_Questions[7]['Answers'][467] = {"Uther"};
TriviaBot_Questions[7]['Category'][467] = 1;
TriviaBot_Questions[7]['Points'][467] = 1;
TriviaBot_Questions[7]['Hints'][467] = {};

TriviaBot_Questions[7]['Question'][468] = "Lethon was a Lieutenant of who?";
TriviaBot_Questions[7]['Answers'][468] = {"Ysera"};
TriviaBot_Questions[7]['Category'][468] = 1;
TriviaBot_Questions[7]['Points'][468] = 1;
TriviaBot_Questions[7]['Hints'][468] = {};

TriviaBot_Questions[7]['Question'][469] = "Lord Anduin Lothar was the last descendant of the ______ royal bloodline, and was known as the 'Lion of Azeroth'.";
TriviaBot_Questions[7]['Answers'][469] = {"Arathi"};
TriviaBot_Questions[7]['Category'][469] = 1;
TriviaBot_Questions[7]['Points'][469] = 1;
TriviaBot_Questions[7]['Hints'][469] = {};

TriviaBot_Questions[7]['Question'][470] = "What transformed some of the highborne's into naga's.?";
TriviaBot_Questions[7]['Answers'][470] = {"The Maelstorm"};
TriviaBot_Questions[7]['Category'][470] = 1;
TriviaBot_Questions[7]['Points'][470] = 1;
TriviaBot_Questions[7]['Hints'][470] = {};

TriviaBot_Questions[7]['Question'][471] = "__________ was the former leader of Outland.";
TriviaBot_Questions[7]['Answers'][471] = {"Magtheridon"};
TriviaBot_Questions[7]['Category'][471] = 1;
TriviaBot_Questions[7]['Points'][471] = 1;
TriviaBot_Questions[7]['Hints'][471] = {};

TriviaBot_Questions[7]['Question'][472] = "__________ was the father of Cenarius.";
TriviaBot_Questions[7]['Answers'][472] = {"Malorne"};
TriviaBot_Questions[7]['Category'][472] = 1;
TriviaBot_Questions[7]['Points'][472] = 1;
TriviaBot_Questions[7]['Hints'][472] = {};

TriviaBot_Questions[7]['Question'][473] = "Who killed Cenarius father, Malorne, in the War of the Ancients?";
TriviaBot_Questions[7]['Answers'][473] = {"Archimonde"};
TriviaBot_Questions[7]['Category'][473] = 1;
TriviaBot_Questions[7]['Points'][473] = 1;
TriviaBot_Questions[7]['Hints'][473] = {};

TriviaBot_Questions[7]['Question'][474] = "What was Cenarius father, Malorne, also known as?";
TriviaBot_Questions[7]['Answers'][474] = {"The white stag"};
TriviaBot_Questions[7]['Category'][474] = 1;
TriviaBot_Questions[7]['Points'][474] = 1;
TriviaBot_Questions[7]['Hints'][474] = {};

TriviaBot_Questions[7]['Question'][475] = "The Earthen Ring is made of _________.";
TriviaBot_Questions[7]['Answers'][475] = {"Shamans"};
TriviaBot_Questions[7]['Category'][475] = 1;
TriviaBot_Questions[7]['Points'][475] = 1;
TriviaBot_Questions[7]['Hints'][475] = {};

TriviaBot_Questions[7]['Question'][476] = "What is Malygos the Blue aspect over?";
TriviaBot_Questions[7]['Answers'][476] = {"Magic"};
TriviaBot_Questions[7]['Category'][476] = 1;
TriviaBot_Questions[7]['Points'][476] = 1;
TriviaBot_Questions[7]['Hints'][476] = {};

TriviaBot_Questions[7]['Question'][477] = "_________ is the leader of the Blue Dragonflight.";
TriviaBot_Questions[7]['Answers'][477] = {"Malygos"};
TriviaBot_Questions[7]['Category'][477] = 1;
TriviaBot_Questions[7]['Points'][477] = 1;
TriviaBot_Questions[7]['Hints'][477] = {};

TriviaBot_Questions[7]['Question'][478] = "Who commands the generals Archimonde and Kil'Jaeden?";
TriviaBot_Questions[7]['Answers'][478] = {"Sargeras"};
TriviaBot_Questions[7]['Category'][478] = 1;
TriviaBot_Questions[7]['Points'][478] = 1;
TriviaBot_Questions[7]['Hints'][478] = {};

TriviaBot_Questions[7]['Question'][479] = "What was Mannoroth known as? (for ex. Archimonde the Defiler)";
TriviaBot_Questions[7]['Answers'][479] = {"Mannoroth the Destructor",  "the Destructor"};
TriviaBot_Questions[7]['Category'][479] = 1;
TriviaBot_Questions[7]['Points'][479] = 1;
TriviaBot_Questions[7]['Hints'][479] = {};

TriviaBot_Questions[7]['Question'][480] = "_________ opened the Dark Portal when he was possessed by Sargeras.";
TriviaBot_Questions[7]['Answers'][480] = {"Medivh"};
TriviaBot_Questions[7]['Category'][480] = 1;
TriviaBot_Questions[7]['Points'][480] = 1;
TriviaBot_Questions[7]['Hints'][480] = {};

TriviaBot_Questions[7]['Question'][481] = "_______ the Tidehunter was the Water Elemental Lieutenant of the Old Gods.";
TriviaBot_Questions[7]['Answers'][481] = {"Neptulon"};
TriviaBot_Questions[7]['Category'][481] = 1;
TriviaBot_Questions[7]['Points'][481] = 1;
TriviaBot_Questions[7]['Hints'][481] = {};

TriviaBot_Questions[7]['Question'][482] = "_______ the Firelord was the Fire Elemental Lieutenant of the Old Gods.";
TriviaBot_Questions[7]['Answers'][482] = {"Ragnaros"};
TriviaBot_Questions[7]['Category'][482] = 1;
TriviaBot_Questions[7]['Points'][482] = 1;
TriviaBot_Questions[7]['Hints'][482] = {};

TriviaBot_Questions[7]['Question'][483] = "Ner'zhul was known as the elder _________ of the orcs, before he was transformed into the Lich King.";
TriviaBot_Questions[7]['Answers'][483] = {"shaman"};
TriviaBot_Questions[7]['Category'][483] = 1;
TriviaBot_Questions[7]['Points'][483] = 1;
TriviaBot_Questions[7]['Hints'][483] = {};

TriviaBot_Questions[7]['Question'][484] = "___________ is a male Aesir Titan. Master of the arcane magic, knowledge, secrets, and mysteries.";
TriviaBot_Questions[7]['Answers'][484] = {"Norgannon"};
TriviaBot_Questions[7]['Category'][484] = 1;
TriviaBot_Questions[7]['Points'][484] = 1;
TriviaBot_Questions[7]['Hints'][484] = {};

TriviaBot_Questions[7]['Question'][485] = "Lord ______ of Alterac betrayed the Alliance and attempted to assasinate lord Uther.";
TriviaBot_Questions[7]['Answers'][485] = {"Perenolde",  "Aieden Perenolde"};
TriviaBot_Questions[7]['Category'][485] = 1;
TriviaBot_Questions[7]['Points'][485] = 1;
TriviaBot_Questions[7]['Hints'][485] = {};

TriviaBot_Questions[7]['Question'][486] = "The Quel'dorei is a term meaning ________ in Thalassian.";
TriviaBot_Questions[7]['Answers'][486] = {"high elves",  "high elfs"};
TriviaBot_Questions[7]['Category'][486] = 1;
TriviaBot_Questions[7]['Points'][486] = 1;
TriviaBot_Questions[7]['Hints'][486] = {};

TriviaBot_Questions[7]['Question'][487] = "Lord Kur'talos ________ was the master of the Black Rook Hold.";
TriviaBot_Questions[7]['Answers'][487] = {"ravencrest"};
TriviaBot_Questions[7]['Category'][487] = 1;
TriviaBot_Questions[7]['Points'][487] = 1;
TriviaBot_Questions[7]['Hints'][487] = {};

TriviaBot_Questions[7]['Question'][488] = "________ was the leader of the Darkspear tribe before he was killed by murlocs. A troll village in Durotar is named after him.";
TriviaBot_Questions[7]['Answers'][488] = {"Sen'jin",  "Senjin"};
TriviaBot_Questions[7]['Category'][488] = 1;
TriviaBot_Questions[7]['Points'][488] = 1;
TriviaBot_Questions[7]['Hints'][488] = {};

TriviaBot_Questions[7]['Question'][489] = "Who is also known as the The Coldbringer?";
TriviaBot_Questions[7]['Answers'][489] = {"Amnennar"};
TriviaBot_Questions[7]['Category'][489] = 1;
TriviaBot_Questions[7]['Points'][489] = 1;
TriviaBot_Questions[7]['Hints'][489] = {};

TriviaBot_Questions[7]['Question'][490] = "What is the name of the Archbishop who created the Paladin order of the Silver Hand, together with Uther.";
TriviaBot_Questions[7]['Answers'][490] = {"Alonsus Faol",  "Archbishop Alonsus Faol"};
TriviaBot_Questions[7]['Category'][490] = 1;
TriviaBot_Questions[7]['Points'][490] = 1;
TriviaBot_Questions[7]['Hints'][490] = {};

TriviaBot_Questions[7]['Question'][491] = "The domain of air is called The _______ on the Elemental Plane.";
TriviaBot_Questions[7]['Answers'][491] = {"Skywall"};
TriviaBot_Questions[7]['Category'][491] = 1;
TriviaBot_Questions[7]['Points'][491] = 1;
TriviaBot_Questions[7]['Hints'][491] = {};

TriviaBot_Questions[7]['Question'][492] = "The domain of earth is called _______ on the Elemental Plane.";
TriviaBot_Questions[7]['Answers'][492] = {"Deephome"};
TriviaBot_Questions[7]['Category'][492] = 1;
TriviaBot_Questions[7]['Points'][492] = 1;
TriviaBot_Questions[7]['Hints'][492] = {};

TriviaBot_Questions[7]['Question'][493] = "The domain of fire is called The ________ on the Elemental Plane.";
TriviaBot_Questions[7]['Answers'][493] = {"Firelands"};
TriviaBot_Questions[7]['Category'][493] = 1;
TriviaBot_Questions[7]['Points'][493] = 1;
TriviaBot_Questions[7]['Hints'][493] = {};

TriviaBot_Questions[7]['Question'][494] = "The domain of water is called The ___________ on the Elemental Plane.";
TriviaBot_Questions[7]['Answers'][494] = {"Abyssal Maw"};
TriviaBot_Questions[7]['Category'][494] = 1;
TriviaBot_Questions[7]['Points'][494] = 1;
TriviaBot_Questions[7]['Hints'][494] = {};

TriviaBot_Questions[7]['Question'][495] = "The ____________ Cartel is the largest and most successful of the Goblin Cartels in Undermine.";
TriviaBot_Questions[7]['Answers'][495] = {"Steamwheedle"};
TriviaBot_Questions[7]['Category'][495] = 1;
TriviaBot_Questions[7]['Points'][495] = 1;
TriviaBot_Questions[7]['Hints'][495] = {};

TriviaBot_Questions[7]['Question'][496] = "_______________ the naga tribe, is currently dwelling in the northern Darkshore. (hint: This is also a realm name, in both the EU and the US)";
TriviaBot_Questions[7]['Answers'][496] = {"Stormscale"};
TriviaBot_Questions[7]['Category'][496] = 1;
TriviaBot_Questions[7]['Points'][496] = 1;
TriviaBot_Questions[7]['Hints'][496] = {};

TriviaBot_Questions[7]['Question'][497] = "The 'oprah event' is in ___________.";
TriviaBot_Questions[7]['Answers'][497] = {"Kara",  "Karazhan"};
TriviaBot_Questions[7]['Category'][497] = 1;
TriviaBot_Questions[7]['Points'][497] = 1;
TriviaBot_Questions[7]['Hints'][497] = {};

TriviaBot_Questions[7]['Question'][498] = "Where can you find Garr?";
TriviaBot_Questions[7]['Answers'][498] = {"Molten Core",  "MC"};
TriviaBot_Questions[7]['Category'][498] = 1;
TriviaBot_Questions[7]['Points'][498] = 1;
TriviaBot_Questions[7]['Hints'][498] = {};

TriviaBot_Questions[7]['Question'][499] = "Where can you find Baron Geddon?";
TriviaBot_Questions[7]['Answers'][499] = {"Molten Core",  "MC"};
TriviaBot_Questions[7]['Category'][499] = 1;
TriviaBot_Questions[7]['Points'][499] = 1;
TriviaBot_Questions[7]['Hints'][499] = {};

TriviaBot_Questions[7]['Question'][500] = "A Warlocks Grand Fire Stone gives how much crit rating?";
TriviaBot_Questions[7]['Answers'][500] = {"49",  "Fourty-nine"};
TriviaBot_Questions[7]['Category'][500] = 1;
TriviaBot_Questions[7]['Points'][500] = 1;
TriviaBot_Questions[7]['Hints'][500] = {};

TriviaBot_Questions[7]['Question'][501] = "What boss in Ulduar drops Voldrethar, Dark Blade of Oblivion?";
TriviaBot_Questions[7]['Answers'][501] = {"General Vezax"};
TriviaBot_Questions[7]['Category'][501] = 1;
TriviaBot_Questions[7]['Points'][501] = 1;
TriviaBot_Questions[7]['Hints'][501] = {};

TriviaBot_Questions[7]['Question'][502] = "How many Fragments of Val'anyr are needed to create the Legendary mace?";
TriviaBot_Questions[7]['Answers'][502] = {"30",  "Thirty"};
TriviaBot_Questions[7]['Category'][502] = 1;
TriviaBot_Questions[7]['Points'][502] = 1;
TriviaBot_Questions[7]['Hints'][502] = {};

TriviaBot_Questions[7]['Question'][503] = "What is the name of Tier 4 Rogue set peices?";
TriviaBot_Questions[7]['Answers'][503] = {"Netherblade",  "MC"};
TriviaBot_Questions[7]['Category'][503] = 1;
TriviaBot_Questions[7]['Points'][503] = 1;
TriviaBot_Questions[7]['Hints'][503] = {};

TriviaBot_Questions[7]['Question'][504] = "Who is the last boss in Ulduar?";
TriviaBot_Questions[7]['Answers'][504] = {"Yogg",  "Yogg-saron"};
TriviaBot_Questions[7]['Category'][504] = 1;
TriviaBot_Questions[7]['Points'][504] = 1;
TriviaBot_Questions[7]['Hints'][504] = {};

TriviaBot_Questions[7]['Question'][505] = "Which Boss in Ulduar casts Flame Jets?";
TriviaBot_Questions[7]['Answers'][505] = {"Flame Leviathan"};
TriviaBot_Questions[7]['Category'][505] = 1;
TriviaBot_Questions[7]['Points'][505] = 1;
TriviaBot_Questions[7]['Hints'][505] = {};

TriviaBot_Questions[7]['Question'][506] = "Can a warlock use conflagrate if the target is afflicted with shadowflame? (TRUE/FALSE)";
TriviaBot_Questions[7]['Answers'][506] = {"True"};
TriviaBot_Questions[7]['Category'][506] = 1;
TriviaBot_Questions[7]['Points'][506] = 1;
TriviaBot_Questions[7]['Hints'][506] = {};

TriviaBot_Questions[7]['Question'][507] = "What is the name of the end spell in a druids balance tree?";
TriviaBot_Questions[7]['Answers'][507] = {"Starfall"}
TriviaBot_Questions[7]['Category'][507] = 1;
TriviaBot_Questions[7]['Points'][507] = 1;
TriviaBot_Questions[7]['Hints'][507] = {};

TriviaBot_Questions[7]['Question'][508] = "Where can you find Gal'darah?";
TriviaBot_Questions[7]['Answers'][508] = {"Gundrak"};
TriviaBot_Questions[7]['Category'][508] = 1;
TriviaBot_Questions[7]['Points'][508] = 1;
TriviaBot_Questions[7]['Hints'][508] = {};

TriviaBot_Questions[7]['Question'][509] = "How much gold is the Traveller's Tundra Mammoth with Exalted Reputation with Kirin'tor?";
TriviaBot_Questions[7]['Answers'][509] = {"16k",  "16000"};
TriviaBot_Questions[7]['Category'][509] = 1;
TriviaBot_Questions[7]['Points'][509] = 1;
TriviaBot_Questions[7]['Hints'][509] = {};

TriviaBot_Questions[7]['Question'][510] = "What is the Bonus loot of Heroic:Alone in the Darkness?";
TriviaBot_Questions[7]['Answers'][510] = {"Mimiron's head",  "Mimi's head"};
TriviaBot_Questions[7]['Category'][510] = 1;
TriviaBot_Questions[7]['Points'][510] = 1;
TriviaBot_Questions[7]['Hints'][510] = {};

TriviaBot_Questions[7]['Question'][511] = "How many bosses does Violet Hold have?";
TriviaBot_Questions[7]['Answers'][511] = {"7",  "Seven"};
TriviaBot_Questions[7]['Category'][511] = 1;
TriviaBot_Questions[7]['Points'][511] = 1;
TriviaBot_Questions[7]['Hints'][511] = {};

TriviaBot_Questions[7]['Question'][512] = "Who is the Last boss in the Halls of Lightning?";
TriviaBot_Questions[7]['Answers'][512] = {"Loken"};
TriviaBot_Questions[7]['Category'][512] = 1;
TriviaBot_Questions[7]['Points'][512] = 1;
TriviaBot_Questions[7]['Hints'][512] = {};

TriviaBot_Questions[7]['Question'][513] = "Who drops Tier 7 gloves?";
TriviaBot_Questions[7]['Answers'][513] = {"Sartharion"};
TriviaBot_Questions[7]['Category'][513] = 1;
TriviaBot_Questions[7]['Points'][513] = 1;
TriviaBot_Questions[7]['Hints'][513] = {};

TriviaBot_Questions[7]['Question'][514] = "Where can you find Applebough?";
TriviaBot_Questions[7]['Answers'][514] = {"Dalaran"};
TriviaBot_Questions[7]['Category'][514] = 1;
TriviaBot_Questions[7]['Points'][514] = 1;
TriviaBot_Questions[7]['Hints'][514] = {};

TriviaBot_Questions[7]['Question'][515] = "How fast is the turtle mount from fishing?";
TriviaBot_Questions[7]['Answers'][515] = {"60%"};
TriviaBot_Questions[7]['Category'][515] = 1;
TriviaBot_Questions[7]['Points'][515] = 1;
TriviaBot_Questions[7]['Hints'][515] = {};

TriviaBot_Questions[7]['Question'][516] = "Where can you find Baron Rivendare?";
TriviaBot_Questions[7]['Answers'][516] = {"Stratholme and Naxxramas"};
TriviaBot_Questions[7]['Category'][516] = 1;
TriviaBot_Questions[7]['Points'][516] = 1;
TriviaBot_Questions[7]['Hints'][516] = {};

TriviaBot_Questions[7]['Question'][517] = "Where can you find the Sons of Hodir Faction?";
TriviaBot_Questions[7]['Answers'][517] = {"Storm Peaks"};
TriviaBot_Questions[7]['Category'][517] = 1;
TriviaBot_Questions[7]['Points'][517] = 1;
TriviaBot_Questions[7]['Hints'][517] = {};

TriviaBot_Questions[7]['Question'][518] = "Where is Dalaran located?";
TriviaBot_Questions[7]['Answers'][518] = {"Crystalsong Forest"};
TriviaBot_Questions[7]['Category'][518] = 1;
TriviaBot_Questions[7]['Points'][518] = 1;
TriviaBot_Questions[7]['Hints'][518] = {};

TriviaBot_Questions[7]['Question'][519] = "Who is the 3rd boss in Sunwell Plateau?";
TriviaBot_Questions[7]['Answers'][519] = {"Felmyst"};
TriviaBot_Questions[7]['Category'][519] = 1;
TriviaBot_Questions[7]['Points'][519] = 1;
TriviaBot_Questions[7]['Hints'][519] = {};

TriviaBot_Questions[7]['Question'][520] = "Where is Coldarra located?";
TriviaBot_Questions[7]['Answers'][520] = {"Borean Tundra"};
TriviaBot_Questions[7]['Category'][520] = 1;
TriviaBot_Questions[7]['Points'][520] = 1;
TriviaBot_Questions[7]['Hints'][520] = {};

TriviaBot_Questions[7]['Question'][521] = "Who is the Last boss in Frostwyrm Lair of Naxxramas?";
TriviaBot_Questions[7]['Answers'][521] = {"Kel'thuzad", "KT"};
TriviaBot_Questions[7]['Category'][521] = 1;
TriviaBot_Questions[7]['Points'][521] = 1;
TriviaBot_Questions[7]['Hints'][521] = {};

TriviaBot_Questions[7]['Question'][522] = "How many Frostweave Bandages are needed to earn the achievement Stocking up?";
TriviaBot_Questions[7]['Answers'][522] = {"500"};
TriviaBot_Questions[7]['Category'][522] = 1;
TriviaBot_Questions[7]['Points'][522] = 1;
TriviaBot_Questions[7]['Hints'][522] = {};

TriviaBot_Questions[7]['Question'][523] = "Where is Trial of the Crusader raid instance found?";
TriviaBot_Questions[7]['Answers'][523] = {"Icecrown"};
TriviaBot_Questions[7]['Category'][523] = 1;
TriviaBot_Questions[7]['Points'][523] = 1;
TriviaBot_Questions[7]['Hints'][523] = {};

TriviaBot_Questions[7]['Question'][524] = "The Trial of the Champion is a raid instance? (TRUE/FALSE)";
TriviaBot_Questions[7]['Answers'][524] = {"False"};
TriviaBot_Questions[7]['Category'][524] = 1;
TriviaBot_Questions[7]['Points'][524] = 1;
TriviaBot_Questions[7]['Hints'][524] = {};

TriviaBot_Questions[7]['Question'][525] = "What is the cooldown on an Iron Boot Flast?";
TriviaBot_Questions[7]['Answers'][525] = {"1hr",  "60mins"};
TriviaBot_Questions[7]['Category'][525] = 1;
TriviaBot_Questions[7]['Points'][525] = 1;
TriviaBot_Questions[7]['Hints'][525] = {};

TriviaBot_Questions[7]['Question'][526] = "How much Spellpower does Flask of the Frostwyrm give?";
TriviaBot_Questions[7]['Answers'][526] = {"125"};
TriviaBot_Questions[7]['Category'][526] = 1;
TriviaBot_Questions[7]['Points'][526] = 1;
TriviaBot_Questions[7]['Hints'][526] = {};

TriviaBot_Questions[7]['Question'][527] = "Broodlord Lashlayer resides in ____________?";
TriviaBot_Questions[7]['Answers'][527] = {"Blackwing Lair", "BWL"};
TriviaBot_Questions[7]['Category'][527] = 1;
TriviaBot_Questions[7]['Points'][527] = 1;
TriviaBot_Questions[7]['Hints'][527] = {};

TriviaBot_Questions[7]['Question'][528] = "Mal'ganis was killed alongside with a large portion of the Scourge that thought they had achieved victory. (True/False)?";
TriviaBot_Questions[7]['Answers'][528] = {"False"};
TriviaBot_Questions[7]['Category'][528] = 1;
TriviaBot_Questions[7]['Points'][528] = 1;
TriviaBot_Questions[7]['Hints'][528] = {};

TriviaBot_Questions[7]['Question'][529] = "The Lich King is controlled by Kil'Jaeden. (True/False)?";
TriviaBot_Questions[7]['Answers'][529] = {"false"};
TriviaBot_Questions[7]['Category'][529] = 1;
TriviaBot_Questions[7]['Points'][529] = 1;
TriviaBot_Questions[7]['Hints'][529] = {};

TriviaBot_Questions[7]['Question'][530] = "The Lich King and Arthas were fused into a single entity. (True/False)?";
TriviaBot_Questions[7]['Answers'][530] = {"True"};
TriviaBot_Questions[7]['Category'][530] = 1;
TriviaBot_Questions[7]['Points'][530] = 1;
TriviaBot_Questions[7]['Hints'][530] = {};

TriviaBot_Questions[7]['Question'][531] = "Suramar was a keldorei city, which was destroyed by the _____________ during the War of the Ancients.";
TriviaBot_Questions[7]['Answers'][531] = {"Burning Legion"};
TriviaBot_Questions[7]['Category'][531] = 1;
TriviaBot_Questions[7]['Points'][531] = 1;
TriviaBot_Questions[7]['Hints'][531] = {};

TriviaBot_Questions[7]['Question'][532] = "The World of Warcraft official soundtrack is only availible if you purchased the Collector's edition. (True/False)?";
TriviaBot_Questions[7]['Answers'][532] = {"False"};
TriviaBot_Questions[7]['Category'][532] = 1;
TriviaBot_Questions[7]['Points'][532] = 1;
TriviaBot_Questions[7]['Hints'][532] = {};

TriviaBot_Questions[7]['Question'][533] = "The Sha'tar resides in _______________.";
TriviaBot_Questions[7]['Answers'][533] = {"Shattrath City",  "Shattrath", "Shat"};
TriviaBot_Questions[7]['Category'][533] = 1;
TriviaBot_Questions[7]['Points'][533] = 1;
TriviaBot_Questions[7]['Hints'][533] = {};

TriviaBot_Questions[7]['Question'][534] = "The __________ clan in blade's edge mountain was killed by the Shadowmoon clan, who were lead by Ner'zhul.";
TriviaBot_Questions[7]['Answers'][534] = {"Thunderlord"};
TriviaBot_Questions[7]['Category'][534] = 1;
TriviaBot_Questions[7]['Points'][534] = 1;
TriviaBot_Questions[7]['Hints'][534] = {};

TriviaBot_Questions[7]['Question'][535] = "Vek'nilash is the third boss in SSC. (True/False)?";
TriviaBot_Questions[7]['Answers'][535] = {"False"};
TriviaBot_Questions[7]['Category'][535] = 1;
TriviaBot_Questions[7]['Points'][535] = 1;
TriviaBot_Questions[7]['Hints'][535] = {};

TriviaBot_Questions[7]['Question'][536] = "What is the name of the populare addon which has a database of every thing you have picked, since you had the addon?";
TriviaBot_Questions[7]['Answers'][536] = {"Gatherer"};
TriviaBot_Questions[7]['Category'][536] = 1;
TriviaBot_Questions[7]['Points'][536] = 1;
TriviaBot_Questions[7]['Hints'][536] = {};

TriviaBot_Questions[7]['Question'][537] = "Guess the Zone: This zone is very nature-looking, and has light-green crystals glowing all over the place.";
TriviaBot_Questions[7]['Answers'][537] = {"Terokkar",  "Terokkar forest"};
TriviaBot_Questions[7]['Category'][537] = 1;
TriviaBot_Questions[7]['Points'][537] = 1;
TriviaBot_Questions[7]['Hints'][537] = {};

TriviaBot_Questions[7]['Question'][538] = "The zone northwest of Terokkar Forest is known as ______________.";
TriviaBot_Questions[7]['Answers'][538] = {"Zangarmarsh"};
TriviaBot_Questions[7]['Category'][538] = 1;
TriviaBot_Questions[7]['Points'][538] = 1;
TriviaBot_Questions[7]['Hints'][538] = {};

TriviaBot_Questions[7]['Question'][539] = "The shattered floating remnants of the red world is also known as __________.";
TriviaBot_Questions[7]['Answers'][539] = {"Outland", "The Outland"};
TriviaBot_Questions[7]['Category'][539] = 1;
TriviaBot_Questions[7]['Points'][539] = 1;
TriviaBot_Questions[7]['Hints'][539] = {};

TriviaBot_Questions[7]['Question'][540] = "World of Warcraft has a total of _____ million subscribers at the moment.";
TriviaBot_Questions[7]['Answers'][540] = {"11",  "eleven"};
TriviaBot_Questions[7]['Category'][540] = 1;
TriviaBot_Questions[7]['Points'][540] = 1;
TriviaBot_Questions[7]['Hints'][540] = {};

TriviaBot_Questions[7]['Question'][541] = "Guess the Zone: This zone is a giant farm land, and is nearly controlled solely by the Defias Brotherhood.";
TriviaBot_Questions[7]['Answers'][541] = {"Westfall"};
TriviaBot_Questions[7]['Category'][541] = 1;
TriviaBot_Questions[7]['Points'][541] = 1;
TriviaBot_Questions[7]['Hints'][541] = {};

TriviaBot_Questions[7]['Question'][542] = "Guess the Zone: Gruul's son Durn patrols around the enormeous crystal in this zone.";
TriviaBot_Questions[7]['Answers'][542] = {"Nagrand"};
TriviaBot_Questions[7]['Category'][542] = 1;
TriviaBot_Questions[7]['Points'][542] = 1;
TriviaBot_Questions[7]['Hints'][542] = {};

TriviaBot_Questions[7]['Question'][543] = "Guess the Zone: This zone has Eco Domes, and is known for its large population of blood elves. This zone features four instances.";
TriviaBot_Questions[7]['Answers'][543] = {"Netherstorm",  "The Netherstorm"};
TriviaBot_Questions[7]['Category'][543] = 1;
TriviaBot_Questions[7]['Points'][543] = 1;
TriviaBot_Questions[7]['Hints'][543] = {};

TriviaBot_Questions[7]['Question'][544] = "Guess the Zone: This zone is known for the Camp of Boom, and The Vortex Fields.";
TriviaBot_Questions[7]['Answers'][544] = {"Netherstorm"};
TriviaBot_Questions[7]['Category'][544] = 1;
TriviaBot_Questions[7]['Points'][544] = 1;
TriviaBot_Questions[7]['Hints'][544] = {};

TriviaBot_Questions[7]['Question'][545] = "Guess the Zone: This zone contains the Pools of Aggonar, the Void ridge, and the Path of Glory. This zone features four instances.";
TriviaBot_Questions[7]['Answers'][545] = {"Hellfire peninsula"};
TriviaBot_Questions[7]['Category'][545] = 1;
TriviaBot_Questions[7]['Points'][545] = 1;
TriviaBot_Questions[7]['Hints'][545] = {};

TriviaBot_Questions[7]['Question'][546] = "Guess the Zone: The first time you will probably meet the Mag'har. A zeppelin has crashed here. This is the best place to gather fel iron.";
TriviaBot_Questions[7]['Answers'][546] = {"Hellfire Peninsula"};
TriviaBot_Questions[7]['Category'][546] = 1;
TriviaBot_Questions[7]['Points'][546] = 1;
TriviaBot_Questions[7]['Hints'][546] = {};

TriviaBot_Questions[7]['Question'][547] = "Guess the Zone: You can visit the legendary Archmage, Khadgar, here. This zone features four instances.";
TriviaBot_Questions[7]['Answers'][547] = {"Terokkar Forest",  "Terokkar"};
TriviaBot_Questions[7]['Category'][547] = 1;
TriviaBot_Questions[7]['Points'][547] = 1;
TriviaBot_Questions[7]['Hints'][547] = {};

TriviaBot_Questions[7]['Question'][548] = "Guess the Zone: The world pvp event in this zone is to capture two beacons and to flag the graveyard.";
TriviaBot_Questions[7]['Answers'][548] = {"Zangarmarsh"};
TriviaBot_Questions[7]['Category'][548] = 1;
TriviaBot_Questions[7]['Points'][548] = 1;
TriviaBot_Questions[7]['Hints'][548] = {};

TriviaBot_Questions[7]['Question'][549] = "Guess the Zone: 'This zone is a grim spectacle of demonic magic run amok. Day and night, molten fel energy erupts from the land and lights the sky with bilious green flame'";
TriviaBot_Questions[7]['Answers'][549] = {"Shadowmoon",  "Shadowmoon Valley"};
TriviaBot_Questions[7]['Category'][549] = 1;
TriviaBot_Questions[7]['Points'][549] = 1;
TriviaBot_Questions[7]['Hints'][549] = {};

TriviaBot_Questions[7]['Question'][550] = "Guess the Zone: Felguards, infernal's and other demonic beings ravages this zone. You can encounter the Shadow Councill here.";
TriviaBot_Questions[7]['Answers'][550] = {"Shadowmoon",  "Shadowmoon valley"};
TriviaBot_Questions[7]['Category'][550] = 1;
TriviaBot_Questions[7]['Points'][550] = 1;
TriviaBot_Questions[7]['Hints'][550] = {};

TriviaBot_Questions[7]['Question'][551] = "Guess the Zone: Before TBC came out, this zone featured the popular stat potions, the ones which gives the player +25 to a stat. With the recent development with the guardian and battle elixirs, these potions are not used anymore.";
TriviaBot_Questions[7]['Answers'][551] = {"Blasted Lands"};
TriviaBot_Questions[7]['Category'][551] = 1;
TriviaBot_Questions[7]['Points'][551] = 1;
TriviaBot_Questions[7]['Hints'][551] = {};

TriviaBot_Questions[7]['Question'][552] = "Guess the Zone: This zone was originally the Black Morass, but has changed name since then, due to the changes in the environment. This zone features a dragon which drops spheres, which in turn can be turned in for loot.";
TriviaBot_Questions[7]['Answers'][552] = {"Blasted Lands"};
TriviaBot_Questions[7]['Category'][552] = 1;
TriviaBot_Questions[7]['Points'][552] = 1;
TriviaBot_Questions[7]['Hints'][552] = {};

TriviaBot_Questions[7]['Question'][553] = "Guess the Zone: This zone is located north of the Redridge Mountains, and features the two first 40man instances ever created by Blizzard.";
TriviaBot_Questions[7]['Answers'][553] = {"Burning Steppes"};
TriviaBot_Questions[7]['Category'][553] = 1;
TriviaBot_Questions[7]['Points'][553] = 1;
TriviaBot_Questions[7]['Hints'][553] = {};

TriviaBot_Questions[7]['Question'][554] = "Guess the Zone: This zone features the Altar of Storms. This zone has plenty of dragon whelps and ogres. Herbers can find dreamfoil and black lotuses here.";
TriviaBot_Questions[7]['Answers'][554] = {"Burning Steppes"};
TriviaBot_Questions[7]['Category'][554] = 1;
TriviaBot_Questions[7]['Points'][554] = 1;
TriviaBot_Questions[7]['Hints'][554] = {};

TriviaBot_Questions[7]['Question'][555] = "Guess the Zone: This zone features Karazhan, and is a relatively small zone. This place is known for its ogres that is perfect to grind, for both experience, and for runecoth.";
TriviaBot_Questions[7]['Answers'][555] = {"Deadwind Pass"};
TriviaBot_Questions[7]['Category'][555] = 1;
TriviaBot_Questions[7]['Points'][555] = 1;
TriviaBot_Questions[7]['Hints'][555] = {};

TriviaBot_Questions[7]['Question'][556] = "Guess the Zone: The town in this zone is speculated to be Sunnyglade, but later renamed due to the events that has transpired in this zone. This zone features the Scourge, and a lot of worgens.";
TriviaBot_Questions[7]['Answers'][556] = {"Duskwood"};
TriviaBot_Questions[7]['Category'][556] = 1;
TriviaBot_Questions[7]['Points'][556] = 1;
TriviaBot_Questions[7]['Hints'][556] = {};

TriviaBot_Questions[7]['Question'][558] = "Guess the Zone: This zone is 'famous' for the rumored 'Schythe of Elune'. The zone features an emerald dream portal, and is one of the four zones where the Emerald Dragons spawns in. (One in each of the four zones)";
TriviaBot_Questions[7]['Answers'][558] = {"Duskwood"};
TriviaBot_Questions[7]['Category'][558] = 1;
TriviaBot_Questions[7]['Points'][558] = 1;
TriviaBot_Questions[7]['Hints'][558] = {};

TriviaBot_Questions[7]['Question'][559] = "Guess the Zone: This zone contains the Tower of Azora, and the Westbrook Garrison. The zone's inhabitants are mainly gnolls, bandits, and murlocs.";
TriviaBot_Questions[7]['Answers'][559] = {"Elwynn Forest",  "Elwynn"};
TriviaBot_Questions[7]['Category'][559] = 1;
TriviaBot_Questions[7]['Points'][559] = 1;
TriviaBot_Questions[7]['Hints'][559] = {};

TriviaBot_Questions[7]['Question'][560] = "Guess the Zone: This zone contains the capital city of one of the Alliance races. The zone features no instances, but has a famous gnoll named.. Hogger!";
TriviaBot_Questions[7]['Answers'][560] = {"Elwynn Forest",  "Elwynn"};
TriviaBot_Questions[7]['Category'][560] = 1;
TriviaBot_Questions[7]['Points'][560] = 1;
TriviaBot_Questions[7]['Hints'][560] = {};

TriviaBot_Questions[7]['Question'][561] = "Guess the Zone: This zone features the quest 'Hillary's necklace'. The zone's inhabitants are mostly orcs and gnolls. The alliance town in this region lies on the shores of Lake Everstill.";
TriviaBot_Questions[7]['Answers'][561] = {"Redridge Mountains",  "Redridge"};
TriviaBot_Questions[7]['Category'][561] = 1;
TriviaBot_Questions[7]['Points'][561] = 1;
TriviaBot_Questions[7]['Hints'][561] = {};

TriviaBot_Questions[7]['Question'][562] = "Guess the Zone: The Tower of Ilgalar is here, though it is currently controlled by the evil Mage, Morganth. Gnolls and spiders are just a small part of the many local inhabitants of the zone.";
TriviaBot_Questions[7]['Answers'][562] = {"Redridge Mountains",  "Redridge"};
TriviaBot_Questions[7]['Category'][562] = 1;
TriviaBot_Questions[7]['Points'][562] = 1;
TriviaBot_Questions[7]['Hints'][562] = {};

TriviaBot_Questions[7]['Question'][563] = "Guess the Zone: This zone was the primary center of the Gurubashi Empire, a long time ago. The zone is known to be a paradise for gankers. A lot of beasts live here.";
TriviaBot_Questions[7]['Answers'][563] = {"Stranglethorn Vale",  "STV"};
TriviaBot_Questions[7]['Category'][563] = 1;
TriviaBot_Questions[7]['Points'][563] = 1;
TriviaBot_Questions[7]['Hints'][563] = {};

TriviaBot_Questions[7]['Question'][564] = "Where is Rexxar, in Azeroth?";
TriviaBot_Questions[7]['Answers'][564] = {"Desolace"};
TriviaBot_Questions[7]['Category'][564] = 1;
TriviaBot_Questions[7]['Points'][564] = 1;
TriviaBot_Questions[7]['Hints'][564] = {};

TriviaBot_Questions[7]['Question'][565] = "Guess the Zone: This zone features the 'Tiny Emerald Whelpling' pet. There is only one instance in this zone. This zone is actually quite similar to Black Morass.";
TriviaBot_Questions[7]['Answers'][565] = {"Swamp of Sorrows"};
TriviaBot_Questions[7]['Category'][565] = 1;
TriviaBot_Questions[7]['Points'][565] = 1;
TriviaBot_Questions[7]['Hints'][565] = {};

TriviaBot_Questions[7]['Question'][566] = "Guess the Zone: Murlocs, crocolisks, spiders and lost one's occupies this zone. You can find much blindweed and goldthorn here, and therefor is a populare spot to grind the mats for arcane elixirs.";
TriviaBot_Questions[7]['Answers'][566] = {"Swamp of Sorrows"};
TriviaBot_Questions[7]['Category'][566] = 1;
TriviaBot_Questions[7]['Points'][566] = 1;
TriviaBot_Questions[7]['Hints'][566] = {};

TriviaBot_Questions[7]['Question'][567] = "Guess the Zone: The zone lies south of Darkshore, and is the ancestral homeland of the night elves. They still remain in control of several holdings throughout the zone, such as Maestra's Post, and the Shrine of Aessina.";
TriviaBot_Questions[7]['Answers'][567] = {"Ashenvale"};
TriviaBot_Questions[7]['Category'][567] = 1;
TriviaBot_Questions[7]['Points'][567] = 1;
TriviaBot_Questions[7]['Hints'][567] = {};

TriviaBot_Questions[7]['Question'][568] = "Guess the Zone: The Furbolgs, and satyrs are some of the local inhabitants of this zone. It was a populare world pvp zone before the expansion came out. This zone also features an Emerald Dream portal.";
TriviaBot_Questions[7]['Answers'][568] = {"Ashenvale"};
TriviaBot_Questions[7]['Category'][568] = 1;
TriviaBot_Questions[7]['Points'][568] = 1;
TriviaBot_Questions[7]['Hints'][568] = {};

TriviaBot_Questions[7]['Question'][569] = "Guess the Zone: Nagas, ghosts, and satyrs are some of the local inhabitants in this zone. The zone was named after the former kaldorei Queen, which is now the leader of the naga's.";
TriviaBot_Questions[7]['Answers'][569] = {"Azshara"};
TriviaBot_Questions[7]['Category'][569] = 1;
TriviaBot_Questions[7]['Points'][569] = 1;
TriviaBot_Questions[7]['Hints'][569] = {};

TriviaBot_Questions[7]['Question'][570] = "Guess the Zone: One of the best zones for farming Dreamfoil and Mountain Silversage. This zone also features the Hydraxian Waterlords faction. The zone is also known to be one of best-looking zones in World of Warcraft.";
TriviaBot_Questions[7]['Answers'][570] = {"Azshara"};
TriviaBot_Questions[7]['Category'][570] = 1;
TriviaBot_Questions[7]['Points'][570] = 1;
TriviaBot_Questions[7]['Hints'][570] = {};

TriviaBot_Questions[7]['Question'][571] = "Guess the Zone: This zone is low on history due to being a out-of-the-way location, but the dranei capital city lies here. A quest chain named 'The Prophecy of Akida' in this zone is widely regarded to be one of the funniest quest chains in WoW.";
TriviaBot_Questions[7]['Answers'][571] = {"Azuremyst",  "Azuremyst Isle", "The Azuremyst Isle"};
TriviaBot_Questions[7]['Category'][571] = 1;
TriviaBot_Questions[7]['Points'][571] = 1;
TriviaBot_Questions[7]['Hints'][571] = {};

TriviaBot_Questions[7]['Question'][572] = "Guess the Zone: Several large kaldorei cities once stood in this zone. This zone has one instance, and is mostly about corrupted Druids. A quest chain in this zone wants you to hunt raptors all over the place becuase they stole some silver.";
TriviaBot_Questions[7]['Answers'][572] = {"Barrens",  "The Barrens"};
TriviaBot_Questions[7]['Category'][572] = 1;
TriviaBot_Questions[7]['Points'][572] = 1;
TriviaBot_Questions[7]['Hints'][572] = {};

TriviaBot_Questions[7]['Question'][573] = "Guess the Zone: The zone has some well known area's, such as the Fray Island, the Stagnant Oasis, and the Fields of Giants. This zone also features a lot of 'hunting' quests.";
TriviaBot_Questions[7]['Answers'][573] = {"Barrens",  "The Barrens"};
TriviaBot_Questions[7]['Category'][573] = 1;
TriviaBot_Questions[7]['Points'][573] = 1;
TriviaBot_Questions[7]['Hints'][573] = {};

TriviaBot_Questions[7]['Question'][574] = "Guess the Zone: This zone is filled with red glowing crystals. This place is also quite low on history, just like the Azuremyst Isle. The zone was formerly known as Silvergale.";
TriviaBot_Questions[7]['Answers'][574] = {"Bloodmyst",  "Bloodmyst Isle", "The bloodmyst Isle"};
TriviaBot_Questions[7]['Category'][574] = 1;
TriviaBot_Questions[7]['Points'][574] = 1;
TriviaBot_Questions[7]['Hints'][574] = {};

TriviaBot_Questions[7]['Question'][575] = "Guess the Zone: This zone has a micro-dungeon named 'The Vector Coil'. As the area suggest, The Vector Coil contains the vector coil of the dranei ship that crashed. An eredar here called Sionas, and is harvesting power from the coil itself.";
TriviaBot_Questions[7]['Answers'][575] = {"Bloodmyst",  "Bloodmyst Isle", "The bloodmyst Isle"};
TriviaBot_Questions[7]['Category'][575] = 1;
TriviaBot_Questions[7]['Points'][575] = 1;
TriviaBot_Questions[7]['Hints'][575] = {};

TriviaBot_Questions[7]['Question'][576] = "Guess the Zone: The night elfs controls this zone. The night elf sentinels patrols the road from Auberdine in this zone till Ashenvale to the south. A quest-chain here is to free the furbolgs from a satyr's corruption.";
TriviaBot_Questions[7]['Answers'][576] = {"Darkshore"};
TriviaBot_Questions[7]['Category'][576] = 1;
TriviaBot_Questions[7]['Points'][576] = 1;
TriviaBot_Questions[7]['Hints'][576] = {};

TriviaBot_Questions[7]['Question'][577] = "Guess the Zone: The Twilight Hammer has plenty of people in this zone. The Cult of the Dark strand also operates here. An Old God is rumored to have fallen in the Master's Glaive area of this zone. Onu refers to it as a 'Old God of the earth'.";
TriviaBot_Questions[7]['Answers'][577] = {"Darkshore"};
TriviaBot_Questions[7]['Category'][577] = 1;
TriviaBot_Questions[7]['Points'][577] = 1;
TriviaBot_Questions[7]['Hints'][577] = {};

TriviaBot_Questions[7]['Question'][578] = "Guess the Zone: This zone has been savaged by centaur's seaseless aggressions. The Kolkar, the Gelkis, the Magram, and the Maraudine centaurs fight each other as much as they do against the Horde and the Alliance of this zone.";
TriviaBot_Questions[7]['Answers'][578] = {"Desolace"};
TriviaBot_Questions[7]['Category'][578] = 1;
TriviaBot_Questions[7]['Points'][578] = 1;
TriviaBot_Questions[7]['Hints'][578] = {};

TriviaBot_Questions[7]['Question'][579] = "Guess the Zone: The Burning Blade's in this zone increases the risk of a region-wide demonic infestation, due to all the demonic beings they have summoned. The naga presence in the northwest of this zone also causes concern.";
TriviaBot_Questions[7]['Answers'][579] = {"Desolace"};
TriviaBot_Questions[7]['Category'][579] = 1;
TriviaBot_Questions[7]['Points'][579] = 1;
TriviaBot_Questions[7]['Hints'][579] = {};

TriviaBot_Questions[7]['Question'][580] = "Guess the Zone: This zone is named after Thrall's father, to honor him. The inhabitants of this zone is mostly harpies, makruras, quillboars, and tigers.";
TriviaBot_Questions[7]['Answers'][580] = {"Durotar"};
TriviaBot_Questions[7]['Category'][580] = 1;
TriviaBot_Questions[7]['Points'][580] = 1;
TriviaBot_Questions[7]['Hints'][580] = {};

TriviaBot_Questions[7]['Question'][581] = "Guess the Zone: This place contains the stonemaul ogres. One of the famous characters in this zone is Jaina Proudmoore. The zone contains creatures such as nagas, turtles, crocolisks, and spiders.";
TriviaBot_Questions[7]['Answers'][581] = {"Dustwallow marsh"};
TriviaBot_Questions[7]['Category'][581] = 1;
TriviaBot_Questions[7]['Points'][581] = 1;
TriviaBot_Questions[7]['Hints'][581] = {};

TriviaBot_Questions[7]['Question'][582] = "Guess the Zone: Sharks, dragonspawns, and raptors are some of the local inhabitants of this zone. This zone features a very popular pre-tbc instance, and the end boss of this instance has been 2manned.";
TriviaBot_Questions[7]['Answers'][582] = {"Dustwallow marsh"};
TriviaBot_Questions[7]['Category'][582] = 1;
TriviaBot_Questions[7]['Points'][582] = 1;
TriviaBot_Questions[7]['Hints'][582] = {};

TriviaBot_Questions[7]['Question'][583] = "Guess the Zone: Lord Illidan Stormrage obtained the skull of gul'dan here. This place is known for its corruption, which were caused by the Burning Legion. The Shadow Councill has a base of operations in this zone.";
TriviaBot_Questions[7]['Answers'][583] = {"Felwood"};
TriviaBot_Questions[7]['Category'][583] = 1;
TriviaBot_Questions[7]['Points'][583] = 1;
TriviaBot_Questions[7]['Hints'][583] = {};

TriviaBot_Questions[7]['Question'][584] = "Guess the Zone: This is the best zone to gather gromsblood in. You can also find lots of dreamfoil, and plaguebloom here. Some gold farmers farmed the angerclaw bears in this zone for money, pre-tbc due to their quick respawn.";
TriviaBot_Questions[7]['Answers'][584] = {"Felwood"};
TriviaBot_Questions[7]['Category'][584] = 1;
TriviaBot_Questions[7]['Points'][584] = 1;
TriviaBot_Questions[7]['Hints'][584] = {};

TriviaBot_Questions[7]['Question'][585] = "Guess the Zone: This zone holds many ancient ruins. The zone is famous for its ancient night elf city, which is now a instance. The zone is also one of the four locations which contain an emerald portal.";
TriviaBot_Questions[7]['Answers'][585] = {"Feralas"};
TriviaBot_Questions[7]['Category'][585] = 1;
TriviaBot_Questions[7]['Points'][585] = 1;
TriviaBot_Questions[7]['Hints'][585] = {};

TriviaBot_Questions[7]['Question'][586] = "Guess the Zone: Faeri dragons, and gnolls are two of the local inhabitants in this zone. The endgame guilds used to grind the raw meat of the Chimaeras in this zone in order to make the famous food, Dirge's Kickin' Chimaerok Chops.";
TriviaBot_Questions[7]['Answers'][586] = {"Feralas"};
TriviaBot_Questions[7]['Category'][586] = 1;
TriviaBot_Questions[7]['Points'][586] = 1;
TriviaBot_Questions[7]['Hints'][586] = {};

TriviaBot_Questions[7]['Question'][587] = "Guess the Zone: This zone contains the old world tree, and is currently unaccessible without special means.";
TriviaBot_Questions[7]['Answers'][587] = {"Mount Hyjal"};
TriviaBot_Questions[7]['Category'][587] = 1;
TriviaBot_Questions[7]['Points'][587] = 1;
TriviaBot_Questions[7]['Hints'][587] = {};

TriviaBot_Questions[7]['Question'][588] = "Guess the Zone: This zone is a haven for Druids and is the home of the Cenarion Circle. The conflict between the Alliance and the Horde is not tolerated by the protectors of this zone. This zone also features Omen during the Lunar Festival.";
TriviaBot_Questions[7]['Answers'][588] = {"Moonglade"};
TriviaBot_Questions[7]['Category'][588] = 1;
TriviaBot_Questions[7]['Points'][588] = 1;
TriviaBot_Questions[7]['Hints'][588] = {};

TriviaBot_Questions[7]['Question'][589] = "Guess the Zone: This zone is known for its nature-loving tribe people. This zone features a huge variety of animals. The Venture Co and the dwarves has intruded into this zone.";
TriviaBot_Questions[7]['Answers'][589] = {"Mulgore"};
TriviaBot_Questions[7]['Category'][589] = 1;
TriviaBot_Questions[7]['Points'][589] = 1;
TriviaBot_Questions[7]['Hints'][589] = {};

TriviaBot_Questions[7]['Question'][590] = "Guess the Zone: This zone contains the Bael'Dun Digsite, where dwarves scour the mountains for traces of their shrouded ancestry. Peacebloom and silverleaf is the local herbs around here. There is plenty of harpies in this zone.";
TriviaBot_Questions[7]['Answers'][590] = {"Mulgore"};
TriviaBot_Questions[7]['Category'][590] = 1;
TriviaBot_Questions[7]['Points'][590] = 1;
TriviaBot_Questions[7]['Hints'][590] = {};

TriviaBot_Questions[7]['Question'][591] = "Guess the Zone: This zone contains two high-end instances and was the location of a server wide event, more commonly known as the AQ War Effort. This zone also features extremely many insects.";
TriviaBot_Questions[7]['Answers'][591] = {"Silithus"};
TriviaBot_Questions[7]['Category'][591] = 1;
TriviaBot_Questions[7]['Points'][591] = 1;
TriviaBot_Questions[7]['Hints'][591] = {};

TriviaBot_Questions[7]['Question'][592] = "Guess the Zone: The wildlife here are mostly insects, snakes, and spiders. This zone has a world pvp event, and had many populare grinding places pre-tbc. The Cenarion Cirlce defends the local town here.";
TriviaBot_Questions[7]['Answers'][592] = {"Silithus"};
TriviaBot_Questions[7]['Category'][592] = 1;
TriviaBot_Questions[7]['Points'][592] = 1;
TriviaBot_Questions[7]['Hints'][592] = {};

TriviaBot_Questions[7]['Question'][593] = "Guess the Zone: This zone has huge problems with 'The Venture Co', who is trying to harvest the local forest here for profit. The Alliance can get here via the Talondeep Path.";
TriviaBot_Questions[7]['Answers'][593] = {"Stonetalon Mountains"};
TriviaBot_Questions[7]['Category'][593] = 1;
TriviaBot_Questions[7]['Points'][593] = 1;
TriviaBot_Questions[7]['Hints'][593] = {};

TriviaBot_Questions[7]['Question'][594] = "Guess the Zone: The inhabitants here are mostly harpies, goblins and fire elementals. You can mainly find copper veins here as a miner, with some occasional tin veins. One of the quests in this zone wants you to kill Besseleth, a huge spider.";
TriviaBot_Questions[7]['Answers'][594]= {"Stonetalon Mountains"};
TriviaBot_Questions[7]['Category'][594] = 1;
TriviaBot_Questions[7]['Points'][594] = 1;
TriviaBot_Questions[7]['Hints'][594] = {};

TriviaBot_Questions[7]['Question'][595] = "Guess the Zone: This zone contains one of the most liked mid level instances. This zone also contains a unaccessible location known as Uldum (very similar to Uldaman).";
TriviaBot_Questions[7]['Answers'][595] = {"Tanaris"};
TriviaBot_Questions[7]['Category'][595] = 1;
TriviaBot_Questions[7]['Points'][595] = 1;
TriviaBot_Questions[7]['Hints'][595] = {};

TriviaBot_Questions[7]['Question'][596] = "Guess the Zone: Furbolgs, grells, and nightsabers are some of the local inhabitants. This place is a nightmare for miners and for the Horde, as it's a hard zone to reach. This place is also the starting zone for one of the Alliance races.";
TriviaBot_Questions[7]['Answers'][596] = {"Teldrassil"};
TriviaBot_Questions[7]['Category'][596] = 1;
TriviaBot_Questions[7]['Points'][596] = 1;
TriviaBot_Questions[7]['Hints'][596] = {};

TriviaBot_Questions[7]['Question'][597] = "Guess the Zone: Dolanaar, and Starbreeze Village are some of the villages in this zone. You can find up to swiftthistle here as a herbalist, but not even one copper vein here as miner.";
TriviaBot_Questions[7]['Answers'][597] = {"Teldrassil"};
TriviaBot_Questions[7]['Category'][597] = 1;
TriviaBot_Questions[7]['Points'][597] = 1;
TriviaBot_Questions[7]['Hints'][597] = {};

TriviaBot_Questions[7]['Question'][598] = "Guess the Zone: A area in this zone is just as dangerous as Stranglethorn Vale, in terms of ganking, if not even more. Both the Alliance and the Horde goes here. This zone contains silithids, water elementals, turtles and wyverns.";
TriviaBot_Questions[7]['Answers'][598] = {"Thousand Needles"};
TriviaBot_Questions[7]['Category'][598] = 1;
TriviaBot_Questions[7]['Points'][598] = 1;
TriviaBot_Questions[7]['Hints'][598] = {};

TriviaBot_Questions[7]['Question'][599] = "Guess the Zone: Kobolds, earth elementals, carrion birds and wind serpents live here. The zone also features the Grimtotem clan. Tanaris lies north of this zone.";
TriviaBot_Questions[7]['Answers'][599] = {"Thousand Needles"};
TriviaBot_Questions[7]['Category'][599] = 1;
TriviaBot_Questions[7]['Points'][599] = 1;
TriviaBot_Questions[7]['Hints'][599] = {};

TriviaBot_Questions[7]['Question'][600] = "Guess the Zone: 'The night elf army was pushed back to this location. Something here prevented the Qiraji from being able to take the land. I do not quite understand this word but i belive it to mean 'God Lands'.'";
TriviaBot_Questions[7]['Answers'][600] = {"Un'Goro",  "Un'Goro Crater"};
TriviaBot_Questions[7]['Category'][600] = 1;
TriviaBot_Questions[7]['Points'][600] = 1;
TriviaBot_Questions[7]['Hints'][600] = {};

TriviaBot_Questions[7]['Question'][601] = "Where can you find Gri'lek?";
TriviaBot_Questions[7]['Answers'][601] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][601] = 1;
TriviaBot_Questions[7]['Points'][601] = 1;
TriviaBot_Questions[7]['Hints'][601] = {};

TriviaBot_Questions[7]['Question'][602] = "Where can you find Hazza'rah?";
TriviaBot_Questions[7]['Answers'][602] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][602] = 1;
TriviaBot_Questions[7]['Points'][602] = 1;
TriviaBot_Questions[7]['Hints'][602] = {};

TriviaBot_Questions[7]['Question'][603] = "Where can you find Wushoolay?";
TriviaBot_Questions[7]['Answers'][603] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][603] = 1;
TriviaBot_Questions[7]['Points'][603] = 1;
TriviaBot_Questions[7]['Hints'][603] = {};

TriviaBot_Questions[7]['Question'][604] = "Name the infamous troll player which leveled to 70 without using weapons or armors.";
TriviaBot_Questions[7]['Answers'][604] = {"Gutrot"};
TriviaBot_Questions[7]['Category'][604] = 1;
TriviaBot_Questions[7]['Points'][604] = 1;
TriviaBot_Questions[7]['Hints'][604] = {};

TriviaBot_Questions[7]['Question'][605] = "Where can you find Razorgore the Untamed?";
TriviaBot_Questions[7]['Answers'][605] = {"Blackwing Lair",  "BWL"};
TriviaBot_Questions[7]['Category'][605] = 1;
TriviaBot_Questions[7]['Points'][605] = 1;
TriviaBot_Questions[7]['Hints'][605] = {};

TriviaBot_Questions[7]['Question'][606] = "Where can you find Vaelastrasz the Corrupt?";
TriviaBot_Questions[7]['Answers'][606] = {"Blackwing Lair",  "BWL"};
TriviaBot_Questions[7]['Category'][606] = 1;
TriviaBot_Questions[7]['Points'][606] = 1;
TriviaBot_Questions[7]['Hints'][606] = {};

TriviaBot_Questions[7]['Question'][607] = "Where can you find Firemaw?";
TriviaBot_Questions[7]['Answers'][607] = {"Blackwing Lair",  "BWL"};
TriviaBot_Questions[7]['Category'][607] = 1;
TriviaBot_Questions[7]['Points'][607] = 1;
TriviaBot_Questions[7]['Hints'][607] = {};

TriviaBot_Questions[7]['Question'][608] = "Where can you find Ebonroc?";
TriviaBot_Questions[7]['Answers'][608] = {"Blackwing Lair",  "BWL"};
TriviaBot_Questions[7]['Category'][608] = 1;
TriviaBot_Questions[7]['Points'][608] = 1;
TriviaBot_Questions[7]['Hints'][608] = {};

TriviaBot_Questions[7]['Question'][609] = "Where can you find Flamegor?";
TriviaBot_Questions[7]['Answers'][609] = {"Blackwing Lair",  "BWL"};
TriviaBot_Questions[7]['Category'][609] = 1;
TriviaBot_Questions[7]['Points'][609] = 1;
TriviaBot_Questions[7]['Hints'][609] = {};

TriviaBot_Questions[7]['Question'][610] = "Where can you find Nefarian?";
TriviaBot_Questions[7]['Answers'][610] = {"Blackwing Lair",  "BWL"};
TriviaBot_Questions[7]['Category'][610] = 1;
TriviaBot_Questions[7]['Points'][610] = 1;
TriviaBot_Questions[7]['Hints'][610] = {};

TriviaBot_Questions[7]['Question'][611] = "Where can you find Master Elemental Shaper Krixix?";
TriviaBot_Questions[7]['Answers'][611] = {"Blackwing Lair",  "BWL"};
TriviaBot_Questions[7]['Category'][611] = 1;
TriviaBot_Questions[7]['Points'][611] = 1;
TriviaBot_Questions[7]['Hints'][611] = {};

TriviaBot_Questions[7]['Question'][612] = "In what zone lies The Ruins of Ahn'Qiraj?";
TriviaBot_Questions[7]['Answers'][612] = {"Silithus"};
TriviaBot_Questions[7]['Category'][612] = 1;
TriviaBot_Questions[7]['Points'][612] = 1;
TriviaBot_Questions[7]['Hints'][612] = {};

TriviaBot_Questions[7]['Question'][613] = "In what zone lies The Temple of Ahn'Qiraj?";
TriviaBot_Questions[7]['Answers'][613] = {"Silithus"};
TriviaBot_Questions[7]['Category'][613] = 1;
TriviaBot_Questions[7]['Points'][613] = 1;
TriviaBot_Questions[7]['Hints'][613] = {};

TriviaBot_Questions[7]['Question'][614] = "In what zone lies Blackwing Lair?";
TriviaBot_Questions[7]['Answers'][614] = {"Searing Gorge",  "Burning steppes"};
TriviaBot_Questions[7]['Category'][614] = 1;
TriviaBot_Questions[7]['Points'][614] = 1;
TriviaBot_Questions[7]['Hints'][614] = {};

TriviaBot_Questions[7]['Question'][615] = "Where can you find The Prophet Skeram?";
TriviaBot_Questions[7]['Answers'][615] = {"The temple of Ahn'Qiraj",  "AQ40", "AQ 40"};
TriviaBot_Questions[7]['Category'][615] = 1;
TriviaBot_Questions[7]['Points'][615] = 1;
TriviaBot_Questions[7]['Hints'][615] = {};

TriviaBot_Questions[7]['Question'][616] = "Where can you find the 'Bug Family' (Kri, Yauj, Vem)?";
TriviaBot_Questions[7]['Answers'][616] = {"The temple of Ahn'Qiraj",  "AQ40", "AQ 40"};
TriviaBot_Questions[7]['Category'][616] = 1;
TriviaBot_Questions[7]['Points'][616] = 1;
TriviaBot_Questions[7]['Hints'][616] = {};

TriviaBot_Questions[7]['Question'][617] = "Where can you find Battleguard Sartura?";
TriviaBot_Questions[7]['Answers'][617] = {"The temple of Ahn'Qiraj",  "AQ40", "AQ 40"};
TriviaBot_Questions[7]['Category'][617] = 1;
TriviaBot_Questions[7]['Points'][617] = 1;
TriviaBot_Questions[7]['Hints'][617] = {};

TriviaBot_Questions[7]['Question'][618] = "Where can you find Fankriss the Unyielding?";
TriviaBot_Questions[7]['Answers'][618] = {"The temple of Ahn'Qiraj",  "AQ40", "AQ 40"};
TriviaBot_Questions[7]['Category'][618] = 1;
TriviaBot_Questions[7]['Points'][618] = 1;
TriviaBot_Questions[7]['Hints'][618] = {};

TriviaBot_Questions[7]['Question'][619] = "Where can you find Viscidus?";
TriviaBot_Questions[7]['Answers'][619] = {"The temple of Ahn'Qiraj",  "AQ40", "AQ 40"};
TriviaBot_Questions[7]['Category'][619] = 1;
TriviaBot_Questions[7]['Points'][619] = 1;
TriviaBot_Questions[7]['Hints'][619] = {};

TriviaBot_Questions[7]['Question'][620] = "Where can you find Princess Huhuran?";
TriviaBot_Questions[7]['Answers'][620] = {"The temple of Ahn'Qiraj",  "AQ40", "AQ 40"};
TriviaBot_Questions[7]['Category'][620] = 1;
TriviaBot_Questions[7]['Points'][620] = 1;
TriviaBot_Questions[7]['Hints'][620] = {};

TriviaBot_Questions[7]['Question'][621] = "Where can you find the Twin Emperors?";
TriviaBot_Questions[7]['Answers'][621] = {"The temple of Ahn'Qiraj",  "AQ40", "AQ 40"};
TriviaBot_Questions[7]['Category'][621] = 1;
TriviaBot_Questions[7]['Points'][621] = 1;
TriviaBot_Questions[7]['Hints'][621] = {};

TriviaBot_Questions[7]['Question'][622] = "Who is the brother of Vek'nilash?";
TriviaBot_Questions[7]['Answers'][622] = {"Vek'lor"};
TriviaBot_Questions[7]['Category'][622] = 1;
TriviaBot_Questions[7]['Points'][622] = 1;
TriviaBot_Questions[7]['Hints'][622] = {};

TriviaBot_Questions[7]['Question'][623] = "Who is the brother of Vek'lor?";
TriviaBot_Questions[7]['Answers'][623] = {"Vek'nilash"};
TriviaBot_Questions[7]['Category'][623] = 1;
TriviaBot_Questions[7]['Points'][623] = 1;
TriviaBot_Questions[7]['Hints'][623] = {};

TriviaBot_Questions[7]['Question'][624] = "Where can you find Ouro?";
TriviaBot_Questions[7]['Answers'][624] = {"The temple of Ahn'Qiraj",  "AQ40", "AQ 40"};
TriviaBot_Questions[7]['Category'][624] = 1;
TriviaBot_Questions[7]['Points'][624] = 1;
TriviaBot_Questions[7]['Hints'][624] = {};

TriviaBot_Questions[7]['Question'][625] = "Where can you find C'thun?";
TriviaBot_Questions[7]['Answers'][625] = {"The temple of Ahn'Qiraj",  "AQ40", "AQ 40"};
TriviaBot_Questions[7]['Category'][625] = 1;
TriviaBot_Questions[7]['Points'][625] = 1;
TriviaBot_Questions[7]['Hints'][625] = {};

TriviaBot_Questions[7]['Question'][626] = "The war between the Qiraji and the rest of kalimdor was called 'The war of the ______ ______'.";
TriviaBot_Questions[7]['Answers'][626] = {"Shifting sands"};
TriviaBot_Questions[7]['Category'][626] = 1;
TriviaBot_Questions[7]['Points'][626] = 1;
TriviaBot_Questions[7]['Hints'][626] = {};

TriviaBot_Questions[7]['Question'][627] = "Where can you find Ayamiss the Hunter?";
TriviaBot_Questions[7]['Answers'][627] = {"Ruins of Ahn'Qiraj",  "AQ20", "AQ 20"};
TriviaBot_Questions[7]['Category'][627] = 1;
TriviaBot_Questions[7]['Points'][627] = 1;
TriviaBot_Questions[7]['Hints'][627] = {};

TriviaBot_Questions[7]['Question'][628] = "Where can you find Buru the Gorger?";
TriviaBot_Questions[7]['Answers'][628] = {"Ruins of Ahn'Qiraj",  "AQ20", "AQ 20"};
TriviaBot_Questions[7]['Category'][628] = 1;
TriviaBot_Questions[7]['Points'][628] = 1;
TriviaBot_Questions[7]['Hints'][628] = {};

TriviaBot_Questions[7]['Question'][629] = "Where can you find General Rajaxx?";
TriviaBot_Questions[7]['Answers'][629] = {"Ruins of Ahn'Qiraj",  "AQ20", "AQ 20"};
TriviaBot_Questions[7]['Category'][629] = 1;
TriviaBot_Questions[7]['Points'][629] = 1;
TriviaBot_Questions[7]['Hints'][629] = {};

TriviaBot_Questions[7]['Question'][630] = "Where can you find Kurinaxx?";
TriviaBot_Questions[7]['Answers'][630] = {"Ruins of Ahn'Qiraj",  "AQ20", "AQ 20"};
TriviaBot_Questions[7]['Category'][630] = 1;
TriviaBot_Questions[7]['Points'][630] = 1;
TriviaBot_Questions[7]['Hints'][630] = {};

TriviaBot_Questions[7]['Question'][631] = "Where can you find Moam?";
TriviaBot_Questions[7]['Answers'][631] = {"Ruins of Ahn'Qiraj",  "AQ20", "AQ 20"};
TriviaBot_Questions[7]['Category'][631] = 1;
TriviaBot_Questions[7]['Points'][631] = 1;
TriviaBot_Questions[7]['Hints'][631] = {};

TriviaBot_Questions[7]['Question'][632] = "Where can you find Ossirian the Unscarred?";
TriviaBot_Questions[7]['Answers'][632] = {"Ruins of Ahn'Qiraj",  "AQ20", "AQ 20"};
TriviaBot_Questions[7]['Category'][632] = 1;
TriviaBot_Questions[7]['Points'][632] = 1;
TriviaBot_Questions[7]['Hints'][632] = {};

TriviaBot_Questions[7]['Question'][633] = "In what content patch was Ahn'Qiraj released?";
TriviaBot_Questions[7]['Answers'][633] = {"1.9"};
TriviaBot_Questions[7]['Category'][633] = 1;
TriviaBot_Questions[7]['Points'][633] = 1;
TriviaBot_Questions[7]['Hints'][633] = {};

TriviaBot_Questions[7]['Question'][634] = "Northrend will certainly feature 'The Venture Co'. (True/False)?";
TriviaBot_Questions[7]['Answers'][634] = {"true"};
TriviaBot_Questions[7]['Category'][634] = 1;
TriviaBot_Questions[7]['Points'][634] = 1;
TriviaBot_Questions[7]['Hints'][634] = {};

TriviaBot_Questions[7]['Question'][635] = "In what content patch was Naxxramas released?";
TriviaBot_Questions[7]['Answers'][635] = {"1.11"};
TriviaBot_Questions[7]['Category'][635] = 1;
TriviaBot_Questions[7]['Points'][635] = 1;
TriviaBot_Questions[7]['Hints'][635] = {};

TriviaBot_Questions[7]['Question'][636] = "Where can you find Anub'Rekhan?";
TriviaBot_Questions[7]['Answers'][636] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][636] = 1;
TriviaBot_Questions[7]['Points'][636] = 1;
TriviaBot_Questions[7]['Hints'][636] = {};

TriviaBot_Questions[7]['Question'][637] = "Where can you find Grand Widow Faerlina?";
TriviaBot_Questions[7]['Answers'][637] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][637] = 1;
TriviaBot_Questions[7]['Points'][637] = 1;
TriviaBot_Questions[7]['Hints'][637] = {};

TriviaBot_Questions[7]['Question'][638] = "Where can you find Mr.Bigglesworth?";
TriviaBot_Questions[7]['Answers'][638] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][638] = 1;
TriviaBot_Questions[7]['Points'][638] = 1;
TriviaBot_Questions[7]['Hints'][638] = {};

TriviaBot_Questions[7]['Question'][639] = "Where can you find Maexxna?";
TriviaBot_Questions[7]['Answers'][639] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][639] = 1;
TriviaBot_Questions[7]['Points'][639] = 1;
TriviaBot_Questions[7]['Hints'][639] = {};

TriviaBot_Questions[7]['Question'][640] = "Where can you find Noth?";
TriviaBot_Questions[7]['Answers'][640] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][640] = 1;
TriviaBot_Questions[7]['Points'][640] = 1;
TriviaBot_Questions[7]['Hints'][640] = {};

TriviaBot_Questions[7]['Question'][641] = "Where can you find Heigan?";
TriviaBot_Questions[7]['Answers'][641] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][641] = 1;
TriviaBot_Questions[7]['Points'][641] = 1;
TriviaBot_Questions[7]['Hints'][641] = {};

TriviaBot_Questions[7]['Question'][642] = "Where can you find Loatheb?";
TriviaBot_Questions[7]['Answers'][642] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][642] = 1;
TriviaBot_Questions[7]['Points'][642] = 1;
TriviaBot_Questions[7]['Hints'][642] = {};

TriviaBot_Questions[7]['Question'][643] = "Where can you find Razuvious?";
TriviaBot_Questions[7]['Answers'][643] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][643] = 1;
TriviaBot_Questions[7]['Points'][643] = 1;
TriviaBot_Questions[7]['Hints'][643] = {};

TriviaBot_Questions[7]['Question'][644] = "Where can you find Gothik?";
TriviaBot_Questions[7]['Answers'][644] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][644] = 1;
TriviaBot_Questions[7]['Points'][644] = 1;
TriviaBot_Questions[7]['Hints'][644] = {};

TriviaBot_Questions[7]['Question'][645] = "Where can you find The Four Horsemen?";
TriviaBot_Questions[7]['Answers'][645] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][645] = 1;
TriviaBot_Questions[7]['Points'][645] = 1;
TriviaBot_Questions[7]['Hints'][645] = {};

TriviaBot_Questions[7]['Question'][646] = "Where can you find Patchwerk?";
TriviaBot_Questions[7]['Answers'][646] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][646] = 1;
TriviaBot_Questions[7]['Points'][646] = 1;
TriviaBot_Questions[7]['Hints'][646] = {};

TriviaBot_Questions[7]['Question'][647] = "Where can you find Grobbulus?";
TriviaBot_Questions[7]['Answers'][647] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][647] = 1;
TriviaBot_Questions[7]['Points'][647] = 1;
TriviaBot_Questions[7]['Hints'][647] = {};

TriviaBot_Questions[7]['Question'][648] = "Where can you find Gluth?";
TriviaBot_Questions[7]['Answers'][648] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][648] = 1;
TriviaBot_Questions[7]['Points'][648] = 1;
TriviaBot_Questions[7]['Hints'][648] = {};

TriviaBot_Questions[7]['Question'][649] = "Where can you find Thaddius?";
TriviaBot_Questions[7]['Answers'][649] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][649] = 1;
TriviaBot_Questions[7]['Points'][649] = 1;
TriviaBot_Questions[7]['Hints'][649] = {};

TriviaBot_Questions[7]['Question'][650] = "Where can you find Sapphiron?";
TriviaBot_Questions[7]['Answers'][650] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][650] = 1;
TriviaBot_Questions[7]['Points'][650] = 1;
TriviaBot_Questions[7]['Hints'][650] = {};

TriviaBot_Questions[7]['Question'][651] = "Where can you find Kel'Thuzad?";
TriviaBot_Questions[7]['Answers'][651] = {"Naxx",  "Naxxramas"};
TriviaBot_Questions[7]['Category'][651] = 1;
TriviaBot_Questions[7]['Points'][651] = 1;
TriviaBot_Questions[7]['Hints'][651] = {};

TriviaBot_Questions[7]['Question'][652] = "Who is Highlord Mograine's son?";
TriviaBot_Questions[7]['Answers'][652] = {"Renault",  "Renault Mograine"};
TriviaBot_Questions[7]['Category'][652] = 1;
TriviaBot_Questions[7]['Points'][652] = 1;
TriviaBot_Questions[7]['Hints'][652] = {};

TriviaBot_Questions[7]['Question'][653] = "You can find agents of Argent Dawn in Outland. (True/False)?";
TriviaBot_Questions[7]['Answers'][653] = {"False"};
TriviaBot_Questions[7]['Category'][653] = 1;
TriviaBot_Questions[7]['Points'][653] = 1;
TriviaBot_Questions[7]['Hints'][653] = {};

TriviaBot_Questions[7]['Question'][654] = "What is the firstname of the Scarlet Crusade's Ambassador, which was sent to discuss the Scourge Invasion?";
TriviaBot_Questions[7]['Answers'][654] = {"Marjhan"};
TriviaBot_Questions[7]['Category'][654] = 1;
TriviaBot_Questions[7]['Points'][654] = 1;
TriviaBot_Questions[7]['Hints'][654] = {};

TriviaBot_Questions[7]['Question'][655] = "How many Outland factions exists at the moment?";
TriviaBot_Questions[7]['Answers'][655] = {"15",  "fifteen"};
TriviaBot_Questions[7]['Category'][655] = 1;
TriviaBot_Questions[7]['Points'][655] = 1;
TriviaBot_Questions[7]['Hints'][655] = {};

TriviaBot_Questions[7]['Question'][656] = "How many Azeroth factions exists at the moment?";
TriviaBot_Questions[7]['Answers'][656] = {"29",  "twentynine"};
TriviaBot_Questions[7]['Category'][656] = 1;
TriviaBot_Questions[7]['Points'][656] = 1;
TriviaBot_Questions[7]['Hints'][656] = {};

TriviaBot_Questions[7]['Question'][657] = "The night elves were once called the ________.";
TriviaBot_Questions[7]['Answers'][657] = {"Kaldorei"};
TriviaBot_Questions[7]['Category'][657] = 1;
TriviaBot_Questions[7]['Points'][657] = 1;
TriviaBot_Questions[7]['Hints'][657] = {};

TriviaBot_Questions[7]['Question'][658] = "Some of the kaldorei's were transformed into naga's during the accident with the ____________________";
TriviaBot_Questions[7]['Answers'][658] = {"well of eternity"};
TriviaBot_Questions[7]['Category'][658] = 1;
TriviaBot_Questions[7]['Points'][658] = 1;
TriviaBot_Questions[7]['Hints'][658] = {};

TriviaBot_Questions[7]['Question'][659] = "The Well of Eternity left a permanent storm known as 'The __________'.";
TriviaBot_Questions[7]['Answers'][659] = {"Maelstrom"};
TriviaBot_Questions[7]['Category'][659] = 1;
TriviaBot_Questions[7]['Points'][659] = 1;
TriviaBot_Questions[7]['Hints'][659] = {};

TriviaBot_Questions[7]['Question'][660] = "The makrura is rumored to have a city named _______.";
TriviaBot_Questions[7]['Answers'][660] = {"Mak'aru"};
TriviaBot_Questions[7]['Category'][660] = 1;
TriviaBot_Questions[7]['Points'][660] = 1;
TriviaBot_Questions[7]['Hints'][660] = {};

TriviaBot_Questions[7]['Question'][661] = "The  _______ speaks in nerglish and are a race of humanoid lobsters who are constantly in war with the naga.";
TriviaBot_Questions[7]['Answers'][661] = {"Makrura"};
TriviaBot_Questions[7]['Category'][661] = 1;
TriviaBot_Questions[7]['Points'][661] = 1;
TriviaBot_Questions[7]['Hints'][661] = {};

TriviaBot_Questions[7]['Question'][662] = "It is rumored that ______ are the offsprings of gronns.";
TriviaBot_Questions[7]['Answers'][662] = {"Ogre",  "Ogres"};
TriviaBot_Questions[7]['Category'][662] = 1;
TriviaBot_Questions[7]['Points'][662] = 1;
TriviaBot_Questions[7]['Hints'][662] = {};

TriviaBot_Questions[7]['Question'][663] = "What is the name of the radio who produces shows such as 'EPIC', 'Blue plz', 'vendor trash', and others?";
TriviaBot_Questions[7]['Answers'][663] = {"wcradio",  "wowradio"};
TriviaBot_Questions[7]['Category'][663] = 1;
TriviaBot_Questions[7]['Points'][663] = 1;
TriviaBot_Questions[7]['Hints'][663] = {};

TriviaBot_Questions[7]['Question'][664] = "______ did the world first on Azgalor the pitlord.";
TriviaBot_Questions[7]['Answers'][664] = {"Curse"};
TriviaBot_Questions[7]['Category'][664] = 1;
TriviaBot_Questions[7]['Points'][664] = 1;
TriviaBot_Questions[7]['Hints'][664] = {};

TriviaBot_Questions[7]['Question'][665] = "What is the name of the guild which did the world first on Nefarian? (hint: Something that happens quite often in guilds is the guildname of this guild)";
TriviaBot_Questions[7]['Answers'][665] = {"Drama"};
TriviaBot_Questions[7]['Category'][665] = 1;
TriviaBot_Questions[7]['Points'][665] = 1;
TriviaBot_Questions[7]['Hints'][665] = {};

TriviaBot_Questions[7]['Question'][666] = "Death & Taxes did the world first on _______ in Karazhan.";
TriviaBot_Questions[7]['Answers'][666] = {"Nightbane"};
TriviaBot_Questions[7]['Category'][666] = 1;
TriviaBot_Questions[7]['Points'][666] = 1;
TriviaBot_Questions[7]['Hints'][666] = {};

TriviaBot_Questions[7]['Question'][667] = "Ascent did the world first on __________.";
TriviaBot_Questions[7]['Answers'][667] = {"Ragnaros"};
TriviaBot_Questions[7]['Category'][667] = 1;
TriviaBot_Questions[7]['Points'][667] = 1;
TriviaBot_Questions[7]['Hints'][667] = {};

TriviaBot_Questions[7]['Question'][668] = "What guild did the world first on Kel'Thuzad?";
TriviaBot_Questions[7]['Answers'][668] = {"Nihilum"};
TriviaBot_Questions[7]['Category'][668] = 1;
TriviaBot_Questions[7]['Points'][668] = 1;
TriviaBot_Questions[7]['Hints'][668] = {};

TriviaBot_Questions[7]['Question'][669] = "What guild did the world first on The Four Horsemen?";
TriviaBot_Questions[7]['Answers'][669] = {"Deathandtaxes",  "Death & Taxes", "Death&Taxes"};
TriviaBot_Questions[7]['Category'][669] = 1;
TriviaBot_Questions[7]['Points'][669] = 1;
TriviaBot_Questions[7]['Hints'][669] = {};

TriviaBot_Questions[7]['Question'][670] = "If you go where you are not supposed to (like, Mount Hyjal, which is not finished) you get a debuff called _______________ which teleports you away.";
TriviaBot_Questions[7]['Answers'][670] = {"no mans land",  "no man's land"};
TriviaBot_Questions[7]['Category'][670] = 1;
TriviaBot_Questions[7]['Points'][670] = 1;
TriviaBot_Questions[7]['Hints'][670] = {};

TriviaBot_Questions[7]['Question'][671] = "There is ______ holiday events in world of warcraft.";
TriviaBot_Questions[7]['Answers'][671] = {"ten",  "10"};
TriviaBot_Questions[7]['Category'][671] = 1;
TriviaBot_Questions[7]['Points'][671] = 1;
TriviaBot_Questions[7]['Hints'][671] = {};

TriviaBot_Questions[7]['Question'][672] = "What is the name of the player which got to 1-60 in 4 days and 20 hours before TBC came, and made a guide about it?";
TriviaBot_Questions[7]['Answers'][672] = {"Joana"};
TriviaBot_Questions[7]['Category'][672] = 1;
TriviaBot_Questions[7]['Points'][672] = 1;
TriviaBot_Questions[7]['Hints'][672] = {};

TriviaBot_Questions[7]['Question'][673] = "What is the name of the player who is famous for his leveling guides? (from 20-60 on both factions)";
TriviaBot_Questions[7]['Answers'][673] = {"Jame"};
TriviaBot_Questions[7]['Category'][673] = 1;
TriviaBot_Questions[7]['Points'][673] = 1;
TriviaBot_Questions[7]['Hints'][673] = {};

TriviaBot_Questions[7]['Question'][674] = "How many characters can you have per realm?";
TriviaBot_Questions[7]['Answers'][674] = {"ten",  "10"};
TriviaBot_Questions[7]['Category'][674] = 1;
TriviaBot_Questions[7]['Points'][674] = 1;
TriviaBot_Questions[7]['Hints'][674] = {};

TriviaBot_Questions[7]['Question'][675] = "The homeland of the goblins is called what?";
TriviaBot_Questions[7]['Answers'][675] = {"Kezan"};
TriviaBot_Questions[7]['Category'][675] = 1;
TriviaBot_Questions[7]['Points'][675] = 1;
TriviaBot_Questions[7]['Hints'][675] = {};

TriviaBot_Questions[7]['Question'][676] = "The goblin's capital city is called?";
TriviaBot_Questions[7]['Answers'][676] = {"Undermine",  "The Undermine"};
TriviaBot_Questions[7]['Category'][676] = 1;
TriviaBot_Questions[7]['Points'][676] = 1;
TriviaBot_Questions[7]['Hints'][676] = {};

TriviaBot_Questions[7]['Question'][677] = "How many troll empires has been known to exists?";
TriviaBot_Questions[7]['Answers'][677] = {"three",  "3"};
TriviaBot_Questions[7]['Category'][677] = 1;
TriviaBot_Questions[7]['Points'][677] = 1;
TriviaBot_Questions[7]['Hints'][677] = {};

TriviaBot_Questions[7]['Question'][678] = "How many troll tribes is known to exists?";
TriviaBot_Questions[7]['Answers'][678] = {"18",  "eighteen"};
TriviaBot_Questions[7]['Category'][678] = 1;
TriviaBot_Questions[7]['Points'][678] = 1;
TriviaBot_Questions[7]['Hints'][678] = {};

TriviaBot_Questions[7]['Question'][679] = "Where can you find Attunmen & Midnight?";
TriviaBot_Questions[7]['Answers'][679] = {"Karazhan",  "KZ", "Kara"};
TriviaBot_Questions[7]['Category'][679] = 1;
TriviaBot_Questions[7]['Points'][679] = 1;
TriviaBot_Questions[7]['Hints'][679] = {};

TriviaBot_Questions[7]['Question'][680] = "Where can you find Maiden of Virtue?";
TriviaBot_Questions[7]['Answers'][680] = {"Karazhan",  "KZ", "Kara"};
TriviaBot_Questions[7]['Category'][680] = 1;
TriviaBot_Questions[7]['Points'][680] = 1;
TriviaBot_Questions[7]['Hints'][680] = {};

TriviaBot_Questions[7]['Question'][681] = "Where can you find Curator?";
TriviaBot_Questions[7]['Answers'][681] = {"Karazhan",  "KZ", "Kara"};
TriviaBot_Questions[7]['Category'][681] = 1;
TriviaBot_Questions[7]['Points'][681] = 1;
TriviaBot_Questions[7]['Hints'][681] = {};

TriviaBot_Questions[7]['Question'][682] = "Where can you find Terestian Illhoof?";
TriviaBot_Questions[7]['Answers'][682] = {"Karazhan",  "KZ", "Kara"};
TriviaBot_Questions[7]['Category'][682] = 1;
TriviaBot_Questions[7]['Points'][682] = 1;
TriviaBot_Questions[7]['Hints'][682] = {};

TriviaBot_Questions[7]['Question'][683] = "Where can you find the shade of Aran?";
TriviaBot_Questions[7]['Answers'][683] = {"Karazhan",  "KZ", "Kara"};
TriviaBot_Questions[7]['Category'][683] = 1;
TriviaBot_Questions[7]['Points'][683] = 1;
TriviaBot_Questions[7]['Hints'][683] = {};

TriviaBot_Questions[7]['Question'][684] = "Where can you find Netherspite?";
TriviaBot_Questions[7]['Answers'][684] = {"Karazhan",  "KZ", "Kara"};
TriviaBot_Questions[7]['Category'][684] = 1;
TriviaBot_Questions[7]['Points'][684] = 1;
TriviaBot_Questions[7]['Hints'][684] = {};

TriviaBot_Questions[7]['Question'][685] = "Where can you find Nightbane?";
TriviaBot_Questions[7]['Answers'][685] = {"Karazhan",  "KZ", "Kara"};
TriviaBot_Questions[7]['Category'][685] = 1;
TriviaBot_Questions[7]['Points'][685] = 1;
TriviaBot_Questions[7]['Hints'][685] = {};

TriviaBot_Questions[7]['Question'][686] = "Where can you find Hyakiss the Lurker?";
TriviaBot_Questions[7]['Answers'][686] = {"Karazhan",  "KZ", "Kara"};
TriviaBot_Questions[7]['Category'][686] = 1;
TriviaBot_Questions[7]['Points'][686] = 1;
TriviaBot_Questions[7]['Hints'][686] = {};

TriviaBot_Questions[7]['Question'][687] = "Where can you find Rokad the Ravager?";
TriviaBot_Questions[7]['Answers'][687] = {"Karazhan",  "KZ", "Kara"};
TriviaBot_Questions[7]['Category'][687] = 1;
TriviaBot_Questions[7]['Points'][687] = 1;
TriviaBot_Questions[7]['Hints'][687] = {};

TriviaBot_Questions[7]['Question'][688] = "Where can you find Shadikith the Glider?";
TriviaBot_Questions[7]['Answers'][688] = {"Karazhan",  "KZ", "Kara"};
TriviaBot_Questions[7]['Category'][688] = 1;
TriviaBot_Questions[7]['Points'][688] = 1;
TriviaBot_Questions[7]['Hints'][688] = {};

TriviaBot_Questions[7]['Question'][689] = "Where can you find Hydross?";
TriviaBot_Questions[7]['Answers'][689] = {"Serpentshrine Cavern",  "SSC"};
TriviaBot_Questions[7]['Category'][689] = 1;
TriviaBot_Questions[7]['Points'][689] = 1;
TriviaBot_Questions[7]['Hints'][689] = {};

TriviaBot_Questions[7]['Question'][690] = "Where can you find 'The Lurker Below'?";
TriviaBot_Questions[7]['Answers'][690] = {"Serpentshrine Cavern",  "SSC"};
TriviaBot_Questions[7]['Category'][690] = 1;
TriviaBot_Questions[7]['Points'][690] = 1;
TriviaBot_Questions[7]['Hints'][690] = {};

TriviaBot_Questions[7]['Question'][691] = "Where can you find Leotheras?";
TriviaBot_Questions[7]['Answers'][691] = {"Serpentshrine Cavern",  "SSC"};
TriviaBot_Questions[7]['Category'][691] = 1;
TriviaBot_Questions[7]['Points'][691] = 1;
TriviaBot_Questions[7]['Hints'][691] = {};

TriviaBot_Questions[7]['Question'][692] = "Where can you find Karathress?";
TriviaBot_Questions[7]['Answers'][692] = {"Serpentshrine Cavern",  "SSC"};
TriviaBot_Questions[7]['Category'][692] = 1;
TriviaBot_Questions[7]['Points'][692] = 1;
TriviaBot_Questions[7]['Hints'][692] = {};

TriviaBot_Questions[7]['Question'][693] = "Where can you find Morogrim Tidewalker?";
TriviaBot_Questions[7]['Answers'][693] = {"Serpentshrine Cavern",  "SSC"};
TriviaBot_Questions[7]['Category'][693] = 1;
TriviaBot_Questions[7]['Points'][693] = 1;
TriviaBot_Questions[7]['Hints'][693] = {};

TriviaBot_Questions[7]['Question'][694] = "Where can you find Vashj?";
TriviaBot_Questions[7]['Answers'][694] = {"Serpentshrine Cavern",  "SSC"};
TriviaBot_Questions[7]['Category'][694] = 1;
TriviaBot_Questions[7]['Points'][694] = 1;
TriviaBot_Questions[7]['Hints'][694] = {};

TriviaBot_Questions[7]['Question'][695] = "When does the Harvest Festival start, in September?";
TriviaBot_Questions[7]['Answers'][695] = {"September 24th",  "24th september", "24th", "24"};
TriviaBot_Questions[7]['Category'][695] = 1;
TriviaBot_Questions[7]['Points'][695] = 1;
TriviaBot_Questions[7]['Hints'][695] = {};

TriviaBot_Questions[7]['Question'][696] = "When does the Feast of Winter Veil start, in December?";
TriviaBot_Questions[7]['Answers'][696] = {"December 22th",  "22th December", "22th", "22"};
TriviaBot_Questions[7]['Category'][696] = 1;
TriviaBot_Questions[7]['Points'][696] = 1;
TriviaBot_Questions[7]['Hints'][696] = {};

TriviaBot_Questions[7]['Question'][697] = "When does the Lunar Festival start, in February?";
TriviaBot_Questions[7]['Answers'][697] = {"February 16th",  "16th February", "16th", "16"};
TriviaBot_Questions[7]['Category'][697] = 1;
TriviaBot_Questions[7]['Points'][697] = 1;
TriviaBot_Questions[7]['Hints'][697] = {};

TriviaBot_Questions[7]['Question'][698] = "When does 'Love is in the Air' start, in February?";
TriviaBot_Questions[7]['Answers'][698] = {"February 11th",  "11th February", "11th", "11"};
TriviaBot_Questions[7]['Category'][698] = 1;
TriviaBot_Questions[7]['Points'][698] = 1;
TriviaBot_Questions[7]['Hints'][698] = {};

TriviaBot_Questions[7]['Question'][699] = "When does Noblegarden start, in April?";
TriviaBot_Questions[7]['Answers'][699] = {"April 15th",  "15th April", "15th", "15"};
TriviaBot_Questions[7]['Category'][699] = 1;
TriviaBot_Questions[7]['Points'][699] = 1;
TriviaBot_Questions[7]['Hints'][699] = {};

TriviaBot_Questions[7]['Question'][700] = "When does the Children's Week start, in May?";
TriviaBot_Questions[7]['Answers'][700] = {"May 22th",  "22th May", "22th", "22"};
TriviaBot_Questions[7]['Category'][700] = 1;
TriviaBot_Questions[7]['Points'][700] = 1;
TriviaBot_Questions[7]['Hints'][700] = {};

TriviaBot_Questions[7]['Question'][701] = "When does the Midsummer Fire Festival start, in June?";
TriviaBot_Questions[7]['Answers'][701] = {"June 21th",  "21th June", "21th", "21"};
TriviaBot_Questions[7]['Category'][701] = 1;
TriviaBot_Questions[7]['Points'][701] = 1;
TriviaBot_Questions[7]['Hints'][701] = {};

TriviaBot_Questions[7]['Question'][702] = "Where can you find Rage Winterchill?";
TriviaBot_Questions[7]['Answers'][702] = {"Battle for Mount Hyjal",  "Hyjal", "Hyjal Summit"};
TriviaBot_Questions[7]['Category'][702] = 1;
TriviaBot_Questions[7]['Points'][702] = 1;
TriviaBot_Questions[7]['Hints'][702] = {};

TriviaBot_Questions[7]['Question'][703] = "Where can you find Anetheron?";
TriviaBot_Questions[7]['Answers'][703] = {"Battle for Mount Hyjal",  "Hyjal", "Hyjal Summit"};
TriviaBot_Questions[7]['Category'][703] = 1;
TriviaBot_Questions[7]['Points'][703] = 1;
TriviaBot_Questions[7]['Hints'][703] = {};

TriviaBot_Questions[7]['Question'][704] = "Where can you find Kaz'rogal?";
TriviaBot_Questions[7]['Answers'][704] = {"Battle for Mount Hyjal",  "Hyjal", "Hyjal Summit"};
TriviaBot_Questions[7]['Category'][704] = 1;
TriviaBot_Questions[7]['Points'][704] = 1;
TriviaBot_Questions[7]['Hints'][704] = {};

TriviaBot_Questions[7]['Question'][705] = "Where can you find Azgalor?";
TriviaBot_Questions[7]['Answers'][705] = {"Battle for Mount Hyjal",  "Hyjal", "Hyjal Summit"};
TriviaBot_Questions[7]['Category'][705] = 1;
TriviaBot_Questions[7]['Points'][705] = 1;
TriviaBot_Questions[7]['Hints'][705] = {};

TriviaBot_Questions[7]['Question'][706] = "Where can you find Archimonde?";
TriviaBot_Questions[7]['Answers'][706] = {"Battle for Mount Hyjal", "Hyjal", "Hyjal Summit"};
TriviaBot_Questions[7]['Category'][706] = 1;
TriviaBot_Questions[7]['Points'][706] = 1;
TriviaBot_Questions[7]['Hints'][706] = {};

TriviaBot_Questions[7]['Question'][707] = "Where can you find Al'ar?";
TriviaBot_Questions[7]['Answers'][707] = {"The Eye", "Tempest keep"};
TriviaBot_Questions[7]['Category'][707] = 1;
TriviaBot_Questions[7]['Points'][707] = 1;
TriviaBot_Questions[7]['Hints'][707] = {};

TriviaBot_Questions[7]['Question'][708] = "Where can you find Void Reaver?";
TriviaBot_Questions[7]['Answers'][708] = {"The Eye", "Tempest keep"};
TriviaBot_Questions[7]['Category'][708] = 1;
TriviaBot_Questions[7]['Points'][708] = 1;
TriviaBot_Questions[7]['Hints'][708] = {};

TriviaBot_Questions[7]['Question'][709] = "Where can you find Solarian?";
TriviaBot_Questions[7]['Answers'][709] = {"The Eye", "Tempest keep"};
TriviaBot_Questions[7]['Category'][709] = 1;
TriviaBot_Questions[7]['Points'][709] = 1;
TriviaBot_Questions[7]['Hints'][709] = {};

TriviaBot_Questions[7]['Question'][710] = "Where can you find Kael'thas Sundstrider?";
TriviaBot_Questions[7]['Answers'][710] = {"The Eye", "Tempest keep"};
TriviaBot_Questions[7]['Category'][710] = 1;
TriviaBot_Questions[7]['Points'][710] = 1;
TriviaBot_Questions[7]['Hints'][710] = {};

TriviaBot_Questions[7]['Question'][711] = "Where can you find Naj'entus?";
TriviaBot_Questions[7]['Answers'][711] = {"Black Temple", "BT", "Black Temple"};
TriviaBot_Questions[7]['Category'][711] = 1;
TriviaBot_Questions[7]['Points'][711] = 1;
TriviaBot_Questions[7]['Hints'][711] = {};

TriviaBot_Questions[7]['Question'][712] = "Where can you find Supremus?";
TriviaBot_Questions[7]['Answers'][712] = {"Black Temple", "BT", "Black Temple"};
TriviaBot_Questions[7]['Category'][712] = 1;
TriviaBot_Questions[7]['Points'][712] = 1;
TriviaBot_Questions[7]['Hints'][712] = {};

TriviaBot_Questions[7]['Question'][713] = "Where can you find the Shade of Akama?";
TriviaBot_Questions[7]['Answers'][713] = {"Black Temple", "BT", "Black Temple"};
TriviaBot_Questions[7]['Category'][713] = 1;
TriviaBot_Questions[7]['Points'][713] = 1;
TriviaBot_Questions[7]['Hints'][713] = {};

TriviaBot_Questions[7]['Question'][714] = "Where can you find Teron Gorefiend?";
TriviaBot_Questions[7]['Answers'][714] = {"Black Temple", "BT", "Black Temple"};
TriviaBot_Questions[7]['Category'][714] = 1;
TriviaBot_Questions[7]['Points'][714] = 1;
TriviaBot_Questions[7]['Hints'][714] = {};

TriviaBot_Questions[7]['Question'][715] = "Where can you find Gurtogg Bloodboil?";
TriviaBot_Questions[7]['Answers'][715] = {"Black Temple", "BT", "Black Temple"};
TriviaBot_Questions[7]['Category'][715] = 1;
TriviaBot_Questions[7]['Points'][715] = 1;
TriviaBot_Questions[7]['Hints'][715] = {};

TriviaBot_Questions[7]['Question'][716] = "Where can you find the Reqliquary of Souls?";
TriviaBot_Questions[7]['Answers'][716] = {"Black Temple", "BT", "Black Temple"};
TriviaBot_Questions[7]['Category'][716] = 1;
TriviaBot_Questions[7]['Points'][716] = 1;
TriviaBot_Questions[7]['Hints'][716] = {};

TriviaBot_Questions[7]['Question'][717] = "Where can you find Mother Shahraz?";
TriviaBot_Questions[7]['Answers'][717] = {"Black Temple", "BT", "Black Temple"};
TriviaBot_Questions[7]['Category'][717] = 1;
TriviaBot_Questions[7]['Points'][717] = 1;
TriviaBot_Questions[7]['Hints'][717] = {};

TriviaBot_Questions[7]['Question'][718] = "Where can you find the Illidari Council?";
TriviaBot_Questions[7]['Answers'][718] = {"Black Temple", "BT", "Black Temple"};
TriviaBot_Questions[7]['Category'][718] = 1;
TriviaBot_Questions[7]['Points'][718] = 1;
TriviaBot_Questions[7]['Hints'][718] = {};

TriviaBot_Questions[7]['Question'][719] = "Where can you find Illidan Stormrage?";
TriviaBot_Questions[7]['Answers'][719] = {"Black Temple", "BT", "Black Temple"};
TriviaBot_Questions[7]['Category'][719] = 1;
TriviaBot_Questions[7]['Points'][719] = 1;
TriviaBot_Questions[7]['Hints'][719] = {};

TriviaBot_Questions[7]['Question'][720] = "Guess the Zone: This zone has lava elementals, spiders, and incendosaurs as its inhabitants. One of the quests in this zone is called 'What the Flux?'.";
TriviaBot_Questions[7]['Answers'][720] = {"Searing Gorge"};
TriviaBot_Questions[7]['Category'][720] = 1;
TriviaBot_Questions[7]['Points'][720] = 1;
TriviaBot_Questions[7]['Hints'][720] = {};

TriviaBot_Questions[7]['Question'][721] = "Guess the Zone: This zone has air elementals, crabs, blood elves, naga, and furbolgs as some of its inhabitants. Arcane storms strikes this peaceful zone, which lies west of darkshore.";
TriviaBot_Questions[7]['Answers'][721] = {"Azuremyst Isle",  "Azuremyst"};
TriviaBot_Questions[7]['Category'][721] = 1;
TriviaBot_Questions[7]['Points'][721] = 1;
TriviaBot_Questions[7]['Hints'][721] = {};

TriviaBot_Questions[7]['Question'][722] = "Guess the Zone: 'Here, young orcs, tauren, and trolls study Shamanism, Hunting, and the Ways of the Warrior'.";
TriviaBot_Questions[7]['Answers'][722] = {"Durotar"};
TriviaBot_Questions[7]['Category'][722] = 1;
TriviaBot_Questions[7]['Points'][722] = 1;
TriviaBot_Questions[7]['Hints'][722] = {};

TriviaBot_Questions[7]['Question'][723] = "Guess the Zone: The zone has the famous Serpent Lake, where four instances lies. The zone is also famous for one of its inhabitants, the Sporelings.";
TriviaBot_Questions[7]['Answers'][723] = {"Zangarmarsh"};
TriviaBot_Questions[7]['Category'][723] = 1;
TriviaBot_Questions[7]['Points'][723] = 1;
TriviaBot_Questions[7]['Hints'][723] = {};

TriviaBot_Questions[7]['Question'][724] = "Guess the Zone: This zone contains all kinds of elementals, from water to fire, from earth to air. When players try to explain this place, they often say its quite similar to Mulgore.";
TriviaBot_Questions[7]['Answers'][724] = {"Nagrand"};
TriviaBot_Questions[7]['Category'][724] = 1;
TriviaBot_Questions[7]['Points'][724] = 1;
TriviaBot_Questions[7]['Hints'][724] = {};

TriviaBot_Questions[7]['Question'][725] = "Guess the Zone: The zone is known for its local inhabitants, the wild talbuks and clefthoofs especially. Alot of ogres and gronns also live here.";
TriviaBot_Questions[7]['Answers'][725] = {"Nagrand"};
TriviaBot_Questions[7]['Category'][725] = 1;
TriviaBot_Questions[7]['Points'][725] = 1;
TriviaBot_Questions[7]['Hints'][725] = {};

TriviaBot_Questions[7]['Question'][726] = "Guess the Zone: This zone is known to be the 'Feralas of the Outland'. The local inhabitants in this zone are mainly the blood elves and the arrakoa. A NPC in this zone named Griftah is a well known scammer.";
TriviaBot_Questions[7]['Answers'][726] = {"Terokkar forest",  "Terokkar"};
TriviaBot_Questions[7]['Category'][726] = 1;
TriviaBot_Questions[7]['Points'][726] = 1;
TriviaBot_Questions[7]['Hints'][726] = {};

TriviaBot_Questions[7]['Question'][727] = "Guess the Zone: The Mok'Nathals live in this zone. The inhabitants here are mostly ogres, and etherals. The formula for +40 spell damage drops in this zone. ";
TriviaBot_Questions[7]['Answers'][727] = {"Blades Edge Mountains",  "Blade's Edge Mountains"};
TriviaBot_Questions[7]['Category'][727] = 1;
TriviaBot_Questions[7]['Points'][727] = 1;
TriviaBot_Questions[7]['Hints'][727] = {};

TriviaBot_Questions[7]['Question'][728] = "This zone has plenty of chimaeras, and ethereals as its inhabitants. There is one raid instance in this zone. You can find Rexxar in the Horde town of this place.";
TriviaBot_Questions[7]['Answers'][728] = {"Blades Edge Mountains",  "Blade's Edge Mountains"};
TriviaBot_Questions[7]['Category'][728] = 1;
TriviaBot_Questions[7]['Points'][728] = 1;
TriviaBot_Questions[7]['Hints'][728] = {};

TriviaBot_Questions[7]['Question'][729] = "When does Hallow's End start, in october?";
TriviaBot_Questions[7]['Answers'][729] = {"18",  "eighteenth", "18th"};
TriviaBot_Questions[7]['Category'][729] = 1;
TriviaBot_Questions[7]['Points'][729] = 1;
TriviaBot_Questions[7]['Hints'][729] = {};

TriviaBot_Questions[7]['Question'][730] = "Where can you find Renataki?";
TriviaBot_Questions[7]['Answers'][730] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][730] = 1;
TriviaBot_Questions[7]['Points'][730] = 1;
TriviaBot_Questions[7]['Hints'][730] = {};

TriviaBot_Questions[7]['Question'][731] = "The trolls in Zul'Aman are obviusly from the Amani empire, right? (True/False)?";
TriviaBot_Questions[7]['Answers'][731] = {"True"};
TriviaBot_Questions[7]['Category'][731] = 1;
TriviaBot_Questions[7]['Points'][731] = 1;
TriviaBot_Questions[7]['Hints'][731] = {};

TriviaBot_Questions[7]['Question'][732] = "What is Cenarius?";
TriviaBot_Questions[7]['Answers'][732] = {"A demigod",  "Demigod", "A demi-god"};
TriviaBot_Questions[7]['Category'][732] = 1;
TriviaBot_Questions[7]['Points'][732] = 1;
TriviaBot_Questions[7]['Hints'][732] = {};

TriviaBot_Questions[7]['Question'][733] = "Who sells Soap on a Rope, in Shattrath?";
TriviaBot_Questions[7]['Answers'][733] = {"Griftah"};
TriviaBot_Questions[7]['Category'][733] = 1;
TriviaBot_Questions[7]['Points'][733] = 1;
TriviaBot_Questions[7]['Hints'][733] = {};

TriviaBot_Questions[7]['Question'][734] = "What foe will you face the most in the expansion? (ex. Amani Empire)";
TriviaBot_Questions[7]['Answers'][734] = {"Scourge", "the Scourge"};
TriviaBot_Questions[7]['Category'][734] = 1;
TriviaBot_Questions[7]['Points'][734] = 1;
TriviaBot_Questions[7]['Hints'][734] = {};

TriviaBot_Questions[7]['Question'][735] = "How many new zones is comming with the expansion?";
TriviaBot_Questions[7]['Answers'][735] = {"10",  "Ten"};
TriviaBot_Questions[7]['Category'][735] = 1;
TriviaBot_Questions[7]['Points'][735] = 1;
TriviaBot_Questions[7]['Hints'][735] = {};

TriviaBot_Questions[7]['Question'][736] = "Guess the Zone: This zone will be revamped in patch 2.3, and will feature the new goblin town, Mudsprocket. 'The Missing Diplomat' quest-chain has been countinued aswell. A total of 60 new quests has been added to the zone.";
TriviaBot_Questions[7]['Answers'][736] = {"Dustwallow Marsh"};
TriviaBot_Questions[7]['Category'][736] = 1;
TriviaBot_Questions[7]['Points'][736] = 1;
TriviaBot_Questions[7]['Hints'][736] = {};

TriviaBot_Questions[7]['Question'][737] = "In patch 2.3 the dragons outside Onyxia's lair will no longer be elite. (True/False)?";
TriviaBot_Questions[7]['Answers'][737] = {"True"};
TriviaBot_Questions[7]['Category'][737] = 1;
TriviaBot_Questions[7]['Points'][737] = 1;
TriviaBot_Questions[7]['Hints'][737] = {};

TriviaBot_Questions[7]['Question'][738] = "Sholazar Basin will be one of the largest zones in Northrend.";
TriviaBot_Questions[7]['Answers'][738] = {"false"};
TriviaBot_Questions[7]['Category'][738] = 1;
TriviaBot_Questions[7]['Points'][738] = 1;
TriviaBot_Questions[7]['Hints'][738] = {};

TriviaBot_Questions[7]['Question'][739] = "The Borean Tundra and the ____________ will probably be the largest zones in Northrend.";
TriviaBot_Questions[7]['Answers'][739] = {"The Dragonblight",  "Dragonblight"};
TriviaBot_Questions[7]['Category'][739] = 1;
TriviaBot_Questions[7]['Points'][739] = 1;
TriviaBot_Questions[7]['Hints'][739] = {};

TriviaBot_Questions[7]['Question'][740] = "Lake Wintergrasp will feature a lot of ____________, because of the pvp-only uniqueness the zone has. (hint: Annother name of 'Outdoor PvP')";
TriviaBot_Questions[7]['Answers'][740] = {"world pvp"};
TriviaBot_Questions[7]['Category'][740] = 1;
TriviaBot_Questions[7]['Points'][740] = 1;
TriviaBot_Questions[7]['Hints'][740] = {};

TriviaBot_Questions[7]['Question'][741] = "The Borean Tundra will feature the Riplash Ruins, which lies near the end of the zone to the south. It has nerubian architecture but is not occupied by them anymore. What group is currently inhabiting it?";
TriviaBot_Questions[7]['Answers'][741] = {"The naga",  "The nagas", "naga", "nagas"};
TriviaBot_Questions[7]['Category'][741] = 1;
TriviaBot_Questions[7]['Points'][741] = 1;
TriviaBot_Questions[7]['Hints'][741] = {};

TriviaBot_Questions[7]['Question'][742] = "What is the naga's also known as? (like, Archimonde the Defiler)";
TriviaBot_Questions[7]['Answers'][742] = {"The terror of the tides",  "Terror of the tides", "The naga, Terror of the Tides"};
TriviaBot_Questions[7]['Category'][742] = 1;
TriviaBot_Questions[7]['Points'][742] = 1;
TriviaBot_Questions[7]['Hints'][742] = {};

TriviaBot_Questions[7]['Question'][743] = "____________ watches over the Dragonblight together with his dragonflight, to make sure that the remains are undisturbed.";
TriviaBot_Questions[7]['Answers'][743] = {"Malygos",  "Malygos the Spell-Weaver", "Malygos the Spell Weaver"};
TriviaBot_Questions[7]['Category'][743] = 1;
TriviaBot_Questions[7]['Points'][743] = 1;
TriviaBot_Questions[7]['Hints'][743] = {};

TriviaBot_Questions[7]['Question'][744] = "The Grizzly Hills in Northrend has how many furbolg tribes?";
TriviaBot_Questions[7]['Answers'][744] = {"4",  "four"};
TriviaBot_Questions[7]['Category'][744] = 1;
TriviaBot_Questions[7]['Points'][744] = 1;
TriviaBot_Questions[7]['Hints'][744] = {};

TriviaBot_Questions[7]['Question'][745] = "What is the furbolg capital in The Grizzly Hills called?";
TriviaBot_Questions[7]['Answers'][745] = {"Grizzlemaw",  "The Grizzlemaw"};
TriviaBot_Questions[7]['Category'][745] = 1;
TriviaBot_Questions[7]['Points'][745] = 1;
TriviaBot_Questions[7]['Hints'][745] = {};

TriviaBot_Questions[7]['Question'][746] = "How many furbolg tribes are known to exist?";
TriviaBot_Questions[7]['Answers'][746] = {"14",  "fourteen"};
TriviaBot_Questions[7]['Category'][746] = 1;
TriviaBot_Questions[7]['Points'][746] = 1;
TriviaBot_Questions[7]['Hints'][746] = {};

TriviaBot_Questions[7]['Question'][747] = "What new proffesion will be introduced in the expansion?";
TriviaBot_Questions[7]['Answers'][747] = {"Inscription"};
TriviaBot_Questions[7]['Category'][747] = 1;
TriviaBot_Questions[7]['Points'][747] = 1;
TriviaBot_Questions[7]['Hints'][747] = {};

TriviaBot_Questions[7]['Question'][748] = "What heroic class will be the first released?";
TriviaBot_Questions[7]['Answers'][748] = {"Death knight",  "The Death Kngiht"};
TriviaBot_Questions[7]['Category'][748] = 1;
TriviaBot_Questions[7]['Points'][748] = 1;
TriviaBot_Questions[7]['Hints'][748] = {};

TriviaBot_Questions[7]['Question'][749] = "What is the name of the undead settlement in Howling Fjord?";
TriviaBot_Questions[7]['Answers'][749] = {"New Agamand"};
TriviaBot_Questions[7]['Category'][749] = 1;
TriviaBot_Questions[7]['Points'][749] = 1;
TriviaBot_Questions[7]['Hints'][749] = {};

TriviaBot_Questions[7]['Question'][750] = "The taunka's were thought to be lost untill they were discovered by ___________________ and his orcs when they landed in Northrend. (the full name)";
TriviaBot_Questions[7]['Answers'][750] = {"Garrosh Hellscream"};
TriviaBot_Questions[7]['Category'][750] = 1;
TriviaBot_Questions[7]['Points'][750] = 1;
TriviaBot_Questions[7]['Hints'][750] = {};

TriviaBot_Questions[7]['Question'][751] = "The taunka are an ancient offshot of the _________.";
TriviaBot_Questions[7]['Answers'][751] = {"Tauren",  "Taurens"};
TriviaBot_Questions[7]['Category'][751] = 1;
TriviaBot_Questions[7]['Points'][751] = 1;
TriviaBot_Questions[7]['Hints'][751] = {};

TriviaBot_Questions[7]['Question'][752] = "The tuskarrs are a humanoid _______ race who live in Northrend.";
TriviaBot_Questions[7]['Answers'][752] = {"Walrus"};
TriviaBot_Questions[7]['Category'][752] = 1;
TriviaBot_Questions[7]['Points'][752] = 1;
TriviaBot_Questions[7]['Hints'][752] = {};

TriviaBot_Questions[7]['Question'][753] = "A race of humanoid spiders, is also known as the __________.";
TriviaBot_Questions[7]['Answers'][753] = {"Nerubians"};
TriviaBot_Questions[7]['Category'][753] = 1;
TriviaBot_Questions[7]['Points'][753] = 1;
TriviaBot_Questions[7]['Hints'][753] = {};

TriviaBot_Questions[7]['Question'][754] = "_________ was the former king of Azjol-Nerub. He now leads the undead nerubians.";
TriviaBot_Questions[7]['Answers'][754] = {"Anub'Arak"};
TriviaBot_Questions[7]['Category'][754] = 1;
TriviaBot_Questions[7]['Points'][754] = 1;
TriviaBot_Questions[7]['Hints'][754] = {};

TriviaBot_Questions[7]['Question'][755] = "The 'Knights of the Silver Hand' will make their return in the expansion. They are lead by the previously exiled Highlord ______ Fordring, which you can encounter ingame in the Eastern Plaguelands.";
TriviaBot_Questions[7]['Answers'][755] = {"Tirion"};
TriviaBot_Questions[7]['Category'][755] = 1;
TriviaBot_Questions[7]['Points'][755] = 1;
TriviaBot_Questions[7]['Hints'][755] = {};

TriviaBot_Questions[7]['Question'][756] = "In what zone lies Utgarde Keep?";
TriviaBot_Questions[7]['Answers'][756] = {"Howling Fjord"};
TriviaBot_Questions[7]['Category'][756] = 1;
TriviaBot_Questions[7]['Points'][756] = 1;
TriviaBot_Questions[7]['Hints'][756] = {};

TriviaBot_Questions[7]['Question'][757] = "The inhabitants of Utgarde Keep is known as the _______ and are formidable warriors. They are bent on proving their strength to the Lich King, who will only raise the most worthy of their warriors to serve him beyond the grave.";
TriviaBot_Questions[7]['Answers'][757] = {"Vrykuls",  "Vrykul's"};
TriviaBot_Questions[7]['Category'][757] = 1;
TriviaBot_Questions[7]['Points'][757] = 1;
TriviaBot_Questions[7]['Hints'][757] = {};

TriviaBot_Questions[7]['Question'][758] = "It is expected that atleast one instance in the Utgarde Keep will feature some _________.";
TriviaBot_Questions[7]['Answers'][758] = {"Undeads",  "Scourge"};
TriviaBot_Questions[7]['Category'][758] = 1;
TriviaBot_Questions[7]['Points'][758] = 1;
TriviaBot_Questions[7]['Hints'][758] = {};

TriviaBot_Questions[7]['Question'][759] = "Alliance can expect to finally see ______ Bronzebeard, the famous explorer. He will be critical in order to uncover the real truth of Azeroth.";
TriviaBot_Questions[7]['Answers'][759] = {"Brann"};
TriviaBot_Questions[7]['Category'][759] = 1;
TriviaBot_Questions[7]['Points'][759] = 1;
TriviaBot_Questions[7]['Hints'][759] = {};

TriviaBot_Questions[7]['Question'][760] = "The dwarves will discover the origin of life on Azeroth in the expansion. (True/False)?";
TriviaBot_Questions[7]['Answers'][760] = {"true"};
TriviaBot_Questions[7]['Category'][760] = 1;
TriviaBot_Questions[7]['Points'][760] = 1;
TriviaBot_Questions[7]['Hints'][760] = {};

TriviaBot_Questions[7]['Question'][761] = "The second instance in Utgarde Keep is called 'Utgarde _______', and is planned to be a level 80 5-man instance.";
TriviaBot_Questions[7]['Answers'][761] = {"Pinnacle"};
TriviaBot_Questions[7]['Category'][761] = 1;
TriviaBot_Questions[7]['Points'][761] = 1;
TriviaBot_Questions[7]['Hints'][761] = {};

TriviaBot_Questions[7]['Question'][762] = "Utgarde Keep will have a raiding instance that is similar to AQ in size. In here you will face the Utgarde Keep Champion, Gutrot Keleseth, as the last boss. He will fight with his fists just like the real Gutrot did, and wear no armor. (True/False)?";
TriviaBot_Questions[7]['Answers'][762] = {"False"};
TriviaBot_Questions[7]['Category'][762] = 1;
TriviaBot_Questions[7]['Points'][762] = 1;
TriviaBot_Questions[7]['Hints'][762] = {};

TriviaBot_Questions[7]['Question'][763] = "Utgarde Keep will be quite similar to the Hellfire Citadel. (True/False)?";
TriviaBot_Questions[7]['Answers'][763] = {"True"};
TriviaBot_Questions[7]['Category'][763] = 1;
TriviaBot_Questions[7]['Points'][763] = 1;
TriviaBot_Questions[7]['Hints'][763] = {};

TriviaBot_Questions[7]['Question'][763] = "The nexus has two 5man instances, and one 25man raid instance. In the raid instance you will face Malygos, also known as The Spell-Weaver. (True/False)?";
TriviaBot_Questions[7]['Answers'][763] = {"true"};
TriviaBot_Questions[7]['Category'][763] = 1;
TriviaBot_Questions[7]['Points'][763] = 1;
TriviaBot_Questions[7]['Hints'][763] = {};

TriviaBot_Questions[7]['Question'][764] = "The nexus is located in __________, the home of Malygos.";
TriviaBot_Questions[7]['Answers'][764] = {"Coldarra"};
TriviaBot_Questions[7]['Category'][764] = 1;
TriviaBot_Questions[7]['Points'][764] = 1;
TriviaBot_Questions[7]['Hints'][764] = {};

TriviaBot_Questions[7]['Question'][765] = "A scroll that was found in a Northrend ruin mentioned a spell that can remove the ________ from a huge number of undead creatures at the same time, putting the undead creatures permanently to rest.";
TriviaBot_Questions[7]['Answers'][765] = {"Undeath"};
TriviaBot_Questions[7]['Category'][765] = 1;
TriviaBot_Questions[7]['Points'][765] = 1;
TriviaBot_Questions[7]['Hints'][765] = {};

TriviaBot_Questions[7]['Question'][766] = "A 5man instance in The Nexus is called '____ Caverns'.";
TriviaBot_Questions[7]['Answers'][766] = {"ice"};
TriviaBot_Questions[7]['Category'][766] = 1;
TriviaBot_Questions[7]['Points'][766] = 1;
TriviaBot_Questions[7]['Hints'][766] = {};

TriviaBot_Questions[7]['Question'][767] = "The 25man raid instance in ____________ will be similar to Onyxia and Gruul. Here you will battle Malygos, the Dragon Aspect of Magic.";
TriviaBot_Questions[7]['Answers'][767] = {"The Nexus"};
TriviaBot_Questions[7]['Category'][767] = 1;
TriviaBot_Questions[7]['Points'][767] = 1;
TriviaBot_Questions[7]['Hints'][767] = {};

TriviaBot_Questions[7]['Question'][768] = "Where is Ulduar located, in Northrend?";
TriviaBot_Questions[7]['Answers'][768] = {"The Storm Peaks"};
TriviaBot_Questions[7]['Category'][768] = 1;
TriviaBot_Questions[7]['Points'][768] = 1;
TriviaBot_Questions[7]['Hints'][768] = {};

TriviaBot_Questions[7]['Question'][769] = "Ulduar is a titan ____.";
TriviaBot_Questions[7]['Answers'][769] = {"City"};
TriviaBot_Questions[7]['Category'][769] = 1;
TriviaBot_Questions[7]['Points'][769] = 1;
TriviaBot_Questions[7]['Hints'][769] = {};

TriviaBot_Questions[7]['Question'][770] = "It is rumored that it's probably in ________ that dwarves will learn the truth about Azeroth. In short, very much lore in it.";
TriviaBot_Questions[7]['Answers'][770] = {"Ulduar"};
TriviaBot_Questions[7]['Category'][770] = 1;
TriviaBot_Questions[7]['Points'][770] = 1;
TriviaBot_Questions[7]['Hints'][770] = {};

TriviaBot_Questions[7]['Question'][771] = "It is rumored that ________ has a great titan city, just like Ulduar.";
TriviaBot_Questions[7]['Answers'][771] = {"Uldum"};
TriviaBot_Questions[7]['Category'][771] = 1;
TriviaBot_Questions[7]['Points'][771] = 1;
TriviaBot_Questions[7]['Hints'][771] = {};

TriviaBot_Questions[7]['Question'][772] = "One of Azjol'Nerubs many mystery's is the __________ Ones.";
TriviaBot_Questions[7]['Answers'][772] = {"faceless"};
TriviaBot_Questions[7]['Category'][772] = 1;
TriviaBot_Questions[7]['Points'][772] = 1;
TriviaBot_Questions[7]['Hints'][772] = {};

TriviaBot_Questions[7]['Question'][773] = "It is not sure yet if ____________ will be killable or not.";
TriviaBot_Questions[7]['Answers'][773] = {"Lich King",  "The Lich King"};
TriviaBot_Questions[7]['Category'][773] = 1;
TriviaBot_Questions[7]['Points'][773] = 1;
TriviaBot_Questions[7]['Hints'][773] = {};

TriviaBot_Questions[7]['Question'][774] = "The seat of power of the Scourge, is the Frozen Throne. The Frozen Throne lies in the ________________.";
TriviaBot_Questions[7]['Answers'][774] = {"Icecrown glacier",  "The Icecrown glacier"};
TriviaBot_Questions[7]['Category'][774] = 1;
TriviaBot_Questions[7]['Points'][774] = 1;
TriviaBot_Questions[7]['Hints'][774] = {};

TriviaBot_Questions[7]['Question'][775] = "____________ is the new leader of Dalaran in the expansion.";
TriviaBot_Questions[7]['Answers'][775] = {"Rhonin"};
TriviaBot_Questions[7]['Category'][775] = 1;
TriviaBot_Questions[7]['Points'][775] = 1;
TriviaBot_Questions[7]['Hints'][775] = {};

TriviaBot_Questions[7]['Question'][776] = "Dalaran has been 'transported' to Northend and is a ________ town, even to the Horde.";
TriviaBot_Questions[7]['Answers'][776] = {"neutral"};
TriviaBot_Questions[7]['Category'][776] = 1;
TriviaBot_Questions[7]['Points'][776] = 1;
TriviaBot_Questions[7]['Hints'][776] = {};

TriviaBot_Questions[7]['Question'][777] = "________ in Northrend, will have one or two instances, just like Stormwind and Orgrimmar.";
TriviaBot_Questions[7]['Answers'][777] = {"Dalaran"};
TriviaBot_Questions[7]['Category'][777] = 1;
TriviaBot_Questions[7]['Points'][777] = 1;
TriviaBot_Questions[7]['Hints'][777] = {};

TriviaBot_Questions[7]['Question'][778] = "_________ Runeweaver is the current leader of Dalaran.";
TriviaBot_Questions[7]['Answers'][778] = {"Ansirem"};
TriviaBot_Questions[7]['Category'][778] = 1;
TriviaBot_Questions[7]['Points'][778] = 1;
TriviaBot_Questions[7]['Hints'][778] = {};

TriviaBot_Questions[7]['Question'][779] = "____________ will be retuned into a level 80 instance with appropiate loot, and be the entry-raid instance in the expansion. The attunement will be removed aswell.";
TriviaBot_Questions[7]['Answers'][779] = {"Naxxramas"};
TriviaBot_Questions[7]['Category'][779] = 1;
TriviaBot_Questions[7]['Points'][779] = 1;
TriviaBot_Questions[7]['Hints'][779] = {};

TriviaBot_Questions[7]['Question'][780] = "Caverns of Time: Culling of _______  is the new instance in CoT that will be added in the expansion. It will be a level 80 5-man instance that will be centered around helping Prince Arthas purge the plague infected populace of this place.";
TriviaBot_Questions[7]['Answers'][780] = {"Stratholme"};
TriviaBot_Questions[7]['Category'][780] = 1;
TriviaBot_Questions[7]['Points'][780] = 1;
TriviaBot_Questions[7]['Hints'][780] = {};

TriviaBot_Questions[7]['Question'][781] = "What is the name of the capital city that the ice trolls, also known as the Zul'Drak empire, has in Northrend?";
TriviaBot_Questions[7]['Answers'][781] = {"Gundrak"};
TriviaBot_Questions[7]['Category'][781] = 1;
TriviaBot_Questions[7]['Points'][781] = 1;
TriviaBot_Questions[7]['Hints'][781] = {};

TriviaBot_Questions[7]['Question'][782] = "The Bloodmar is a community of magnataurs. They are currently building their numbers and gathering resources in preperation for war on the other races close to their border. They are led by the mighty Grom'Thar the _______.";
TriviaBot_Questions[7]['Answers'][782] = {"Thunderbringer"};
TriviaBot_Questions[7]['Category'][782] = 1;
TriviaBot_Questions[7]['Points'][782] = 1;
TriviaBot_Questions[7]['Hints'][782] = {};

TriviaBot_Questions[7]['Question'][783] = "The Drak'Tharon Keep is a fort where Arthas stayed while searching for ______________, and is located in the Grizly Hills.";
TriviaBot_Questions[7]['Answers'][783] = {"Frostmourne"};
TriviaBot_Questions[7]['Category'][783] = 1;
TriviaBot_Questions[7]['Points'][783] = 1;
TriviaBot_Questions[7]['Hints'][783] = {};

TriviaBot_Questions[7]['Question'][784] = "The Drak'Tharon Keep originally belonged to the _________ trolls, but the Scourge drove them out and took their possesions, aswell as the fort. The Scourge now have a garrison here, which is holding the mountain passes.";
TriviaBot_Questions[7]['Answers'][784] = {"Drakkari"};
TriviaBot_Questions[7]['Category'][784] = 1;
TriviaBot_Questions[7]['Points'][784] = 1;
TriviaBot_Questions[7]['Hints'][784] = {};

TriviaBot_Questions[7]['Question'][785] = "The ____________ Keep is easily defended. It is said that the small group of scourge that is garrisoned there can easily hold the keep against forces ten times its size, especially since they dont need nourishment, like food or water.";
TriviaBot_Questions[7]['Answers'][785] = {"Drak'Tharon"};
TriviaBot_Questions[7]['Category'][785] = 1;
TriviaBot_Questions[7]['Points'][785] = 1;
TriviaBot_Questions[7]['Hints'][785] = {};

TriviaBot_Questions[7]['Question'][786] = "The Death Knight will just be the first of several upcoming ______ class. The current plan is to release one  _____ class per expansion pack.";
TriviaBot_Questions[7]['Answers'][786] = {"hero"};
TriviaBot_Questions[7]['Category'][786] = 1;
TriviaBot_Questions[7]['Points'][786] = 1;
TriviaBot_Questions[7]['Hints'][786] = {};

TriviaBot_Questions[7]['Question'][787] = "The Death Knight will start at a high level, around level __-60 is the current plan.";
TriviaBot_Questions[7]['Answers'][787] = {"55"};
TriviaBot_Questions[7]['Category'][787] = 1;
TriviaBot_Questions[7]['Points'][787] = 1;
TriviaBot_Questions[7]['Hints'][787] = {};

TriviaBot_Questions[7]['Question'][788] = "The Death Knights cant use shields. (True/False)?";
TriviaBot_Questions[7]['Answers'][788] = {"true"};
TriviaBot_Questions[7]['Category'][788] = 1;
TriviaBot_Questions[7]['Points'][788] = 1;
TriviaBot_Questions[7]['Hints'][788] = {};

TriviaBot_Questions[7]['Question'][789] = "The Death Knight uses ______ as their source of 'mana'. The _______ on their runeblades have charges, so they dont have unlimited mana precisely. Once thouse charges are out, they need to regenerate in order to get their abilities and spells back.";
TriviaBot_Questions[7]['Answers'][789] = {"runes"};
TriviaBot_Questions[7]['Category'][789] = 1;
TriviaBot_Questions[7]['Points'][789] = 1;
TriviaBot_Questions[7]['Hints'][789] = {};

TriviaBot_Questions[7]['Question'][790] = "Proffesions will have _____ skill points as limit in the expansion.";
TriviaBot_Questions[7]['Answers'][790] = {"450",  "four hundred fifty"};
TriviaBot_Questions[7]['Category'][790] = 1;
TriviaBot_Questions[7]['Points'][790] = 1;
TriviaBot_Questions[7]['Hints'][790] = {};

TriviaBot_Questions[7]['Question'][791] = "The riding skills will be _______ skill points as limit in the expansion.";
TriviaBot_Questions[7]['Answers'][791] = {"375"};
TriviaBot_Questions[7]['Category'][791] = 1;
TriviaBot_Questions[7]['Points'][791] = 1;
TriviaBot_Questions[7]['Hints'][791] = {}; 

TriviaBot_Questions[7]['Question'][792] = "In the expansion you are able to customize your characters with new hair styles and _______. Characters wont be able to have a 'plastic surgery', though. (hint: This can be 'triggered' by writing an emote)";
TriviaBot_Questions[7]['Answers'][792] = {"dances"};
TriviaBot_Questions[7]['Category'][792] = 1;
TriviaBot_Questions[7]['Points'][792] = 1;
TriviaBot_Questions[7]['Hints'][792] = {};

TriviaBot_Questions[7]['Question'][793] = "Blizzard hopes to bring the pvp to annother level with the new zone in the expansion, Lake __________. It will be the only-pvp zone in wow.";
TriviaBot_Questions[7]['Answers'][793] = {"Wintergrasp"};
TriviaBot_Questions[7]['Category'][793] = 1;
TriviaBot_Questions[7]['Points'][793] = 1;
TriviaBot_Questions[7]['Hints'][793] = {};

TriviaBot_Questions[7]['Question'][794] = "The expansion will introduce _____ weapons into the game, and atleast one new battleground.";
TriviaBot_Questions[7]['Answers'][794] = {"siege"};
TriviaBot_Questions[7]['Category'][794] = 1;
TriviaBot_Questions[7]['Points'][794] = 1;
TriviaBot_Questions[7]['Hints'][794] = {};

TriviaBot_Questions[7]['Question'][795] = "The art of Outland is going to return to the 'classical' Warcraft, and that is, ______ fantasy. The Outland art was high fantasy.";
TriviaBot_Questions[7]['Answers'][795] = {"gothic"};
TriviaBot_Questions[7]['Category'][795] = 1;
TriviaBot_Questions[7]['Points'][795] = 1;
TriviaBot_Questions[7]['Hints'][795] = {};

TriviaBot_Questions[7]['Question'][796] = "What is 'the roof of the world' refering to?";
TriviaBot_Questions[7]['Answers'][796] = {"Northrend"};
TriviaBot_Questions[7]['Category'][796] = 1;
TriviaBot_Questions[7]['Points'][796] = 1;
TriviaBot_Questions[7]['Hints'][796] = {};

TriviaBot_Questions[7]['Question'][797] = "In which patch was the voice chat implemented?";
TriviaBot_Questions[7]['Answers'][797] = {"2.2"};
TriviaBot_Questions[7]['Category'][797] = 1;
TriviaBot_Questions[7]['Points'][797] = 1;
TriviaBot_Questions[7]['Hints'][797] = {};

TriviaBot_Questions[7]['Question'][798] = "What is the name of the tuskar's capital city?";
TriviaBot_Questions[7]['Answers'][798] = {"Kaskala"};
TriviaBot_Questions[7]['Category'][798] = 1;
TriviaBot_Questions[7]['Points'][798] = 1;
TriviaBot_Questions[7]['Hints'][798] = {};

TriviaBot_Questions[7]['Question'][799] = "What is the Horde fortress called in Borean Tundra? (hint: Gromm Hellscream's clan)";
TriviaBot_Questions[7]['Answers'][799] = {"Warsong Hold"};
TriviaBot_Questions[7]['Category'][799] = 1;
TriviaBot_Questions[7]['Points'][799] = 1;
TriviaBot_Questions[7]['Hints'][799] = {};

TriviaBot_Questions[7]['Question'][800] = "The tuskarr have allied themselves with the Horde expedition, both because of their cultural similarities (__________ particulary) and to battle the naga who assaults them from the south.";
TriviaBot_Questions[7]['Answers'][800] = {"Shamanism"};
TriviaBot_Questions[7]['Category'][800] = 1;
TriviaBot_Questions[7]['Points'][800] = 1;
TriviaBot_Questions[7]['Hints'][800] = {};

TriviaBot_Questions[7]['Question'][801] = "The tuskarr's considers it a mark of _______ to give help to other tuskarr villages.";
TriviaBot_Questions[7]['Answers'][801] = {"honor"};
TriviaBot_Questions[7]['Category'][801] = 1;
TriviaBot_Questions[7]['Points'][801] = 1;
TriviaBot_Questions[7]['Hints'][801] = {};

TriviaBot_Questions[7]['Question'][802] = "The _____________ received its name because of the wind which races in from the sea on all three sides, producing a constant howl, like a maddened beast seeking its prey.";
TriviaBot_Questions[7]['Answers'][802] = {"Howling Fjord",  "The Howling Fjord"};
TriviaBot_Questions[7]['Category'][802] = 1;
TriviaBot_Questions[7]['Points'][802] = 1;
TriviaBot_Questions[7]['Hints'][802] = {};

TriviaBot_Questions[7]['Question'][803] = "Guess the Zone: Both the Horde and the Alliance are steadily assaulted in this zone, by the vrykuls. The ironforge prospectors in this zone has discovered a new race of iron dwarves which may hint to their own ancient origin.";
TriviaBot_Questions[7]['Answers'][803] = {"Howling Fjord",  "The Howling Fjord"};
TriviaBot_Questions[7]['Category'][803] = 1;
TriviaBot_Questions[7]['Points'][803] = 1;
TriviaBot_Questions[7]['Hints'][803] = {};

TriviaBot_Questions[7]['Question'][804] = "Guess the Zone: Sylvanas and the Forsaken in this zone has engineered a new plague, and is ready to strike at the Lich King. They have built a new town in this zone, named 'New Agamand'. It's there the testing beings.";
TriviaBot_Questions[7]['Answers'][804] = {"Howling Fjord",  "The Howling Fjord"};
TriviaBot_Questions[7]['Category'][804] = 1;
TriviaBot_Questions[7]['Points'][804] = 1;
TriviaBot_Questions[7]['Hints'][804] = {};

TriviaBot_Questions[7]['Question'][805] = "Guess the Zone: This zone is located at the far western edge of Northrend. The naga, and the Scourge are two of the local inhabitants. The Tuskarr are the dominant presence in this zone, and their capital city Kaskala is here aswell.";
TriviaBot_Questions[7]['Answers'][805] = {"Borean Tundra",  "The Borean Tundra"};
TriviaBot_Questions[7]['Category'][805] = 1;
TriviaBot_Questions[7]['Points'][805] = 1;
TriviaBot_Questions[7]['Hints'][805] = {};

TriviaBot_Questions[7]['Question'][806] = "Guess the Zone: The Drakkari Trolls, and the Blue Dragonflight occupies this zone, together with many other species. This zone is flat, wide, and cold. A solid sheet of ice covers the zone.";
TriviaBot_Questions[7]['Answers'][806] = {"Borean Tundra",  "The Borean Tundra"};
TriviaBot_Questions[7]['Category'][806] = 1;
TriviaBot_Questions[7]['Points'][806] = 1;
TriviaBot_Questions[7]['Hints'][806] = {};

TriviaBot_Questions[7]['Question'][807] = "Guess the Zone: This zone is perhaps the softest of all of the zones in Northrend. The trolls is only a minor nuisance and the Scourge comes here rarely. The Alliance Keep in this zone is called Justice Keep and the Horde town is called Warsong Hold.";
TriviaBot_Questions[7]['Answers'][807] = {"Borean Tundra",  "The Borean Tundra"};
TriviaBot_Questions[7]['Category'][807] = 1;
TriviaBot_Questions[7]['Points'][807] = 1;
TriviaBot_Questions[7]['Hints'][807] = {};

TriviaBot_Questions[7]['Question'][808] = "Guess the Zone: The humans of this zone was the first of all to fall victim to the plague. This zone is also a graveyard for dragons. Old dragon's come here in their final hours or days, to rest in peace.";
TriviaBot_Questions[7]['Answers'][808] = {"The Dragonblight"};
TriviaBot_Questions[7]['Category'][808] = 1;
TriviaBot_Questions[7]['Points'][808] = 1;
TriviaBot_Questions[7]['Hints'][808] = {};

TriviaBot_Questions[7]['Question'][809] = "Guess the Zone: Malygos and his Blue Dragonflight guards this zone fiercly. Undead animals also roams this land, attacking any living thing in sight. Travelers should try their best to avoid them.";
TriviaBot_Questions[7]['Answers'][809] = {"The Dragonblight"};
TriviaBot_Questions[7]['Category'][809] = 1;
TriviaBot_Questions[7]['Points'][809] = 1;
TriviaBot_Questions[7]['Hints'][809] = {};

TriviaBot_Questions[7]['Question'][810] = "Guess the Zone: The dragons of this zone, in the Wyrmrest temple, communicate regulary with their kin in Coldarra. This zone also features the Tauren outpost of Icemist village, which has been known for helping strangers in need.";
TriviaBot_Questions[7]['Answers'][810] = {"The Dragonblight"};
TriviaBot_Questions[7]['Category'][810] = 1;
TriviaBot_Questions[7]['Points'][810] = 1;
TriviaBot_Questions[7]['Hints'][810] = {};

TriviaBot_Questions[7]['Question'][811] = "Guess the Zone: The survivors of the fall of Azjol-Nerub has fled to the Sundered Monolith, a nerubian fortress in this zone. No one knows what their role will be in Northrend.";
TriviaBot_Questions[7]['Answers'][811] = {"The Dragonblight"};
TriviaBot_Questions[7]['Category'][811] = 1;
TriviaBot_Questions[7]['Points'][811] = 1;
TriviaBot_Questions[7]['Hints'][811] = {};

TriviaBot_Questions[7]['Question'][812] = "Guess the Zone: This zone is the home of the trolls of the Drakkari empire. Their capital city Gundrak lies is here, aswell. Most people avoids this zone, for good reasons.";
TriviaBot_Questions[7]['Answers'][812] = {"Zul'Drak"};
TriviaBot_Questions[7]['Category'][812] = 1;
TriviaBot_Questions[7]['Points'][812] = 1;
TriviaBot_Questions[7]['Hints'][812] = {};

TriviaBot_Questions[7]['Question'][813] = "Guess the Zone: This zone has excellent wildlife compared to most of the other zones in Northrend. The Scourge has so far not penetrated this zone to any degree, but a war between the Drakkari trolls here and the Scourge might be inevitable.";
TriviaBot_Questions[7]['Answers'][813] = {"Zul'Drak"};
TriviaBot_Questions[7]['Category'][813] = 1;
TriviaBot_Questions[7]['Points'][813] = 1;
TriviaBot_Questions[7]['Hints'][813] = {};

TriviaBot_Questions[7]['Question'][814] = "The leader of the drakkari tribes in Zul'Drak is called 'Frost King _____'.";
TriviaBot_Questions[7]['Answers'][814] = {"Malakk"};
TriviaBot_Questions[7]['Category'][814] = 1;
TriviaBot_Questions[7]['Points'][814] = 1;
TriviaBot_Questions[7]['Hints'][814] = {};

TriviaBot_Questions[7]['Question'][815] = "Guess the Zone: It's in this zone here the grizzlemaw furbolg made their capital city, Grizzlemaw. The grizzlemaw furbolgs claims they where the first people in these hills, just like the Drakkari.";
TriviaBot_Questions[7]['Answers'][815] = {"Grizzly Hills",  "The Grizzly Hills"};
TriviaBot_Questions[7]['Category'][815] = 1;
TriviaBot_Questions[7]['Points'][815] = 1;
TriviaBot_Questions[7]['Hints'][815] = {};

TriviaBot_Questions[7]['Question'][816] = "Guess the Zone: The dwarven settlement, Thor Modan, can be found in this zone. It is the ancient home of the iron dwarves. The furbolgs in this zone attacks this place frequently, because they think of the dwarves as graverobbers and trespassers.";
TriviaBot_Questions[7]['Answers'][816] = {"Grizzly Hills",  "The Grizzly Hills"};
TriviaBot_Questions[7]['Category'][816] = 1;
TriviaBot_Questions[7]['Points'][816] = 1;
TriviaBot_Questions[7]['Hints'][816] = {};

TriviaBot_Questions[7]['Question'][817] = "Guess the Zone: Drak'Tharon keep lies here. It's origin is from the Drakkari, and is very close to the border of Zul'Drak. The Scourge now occupies this keep, and can easily defend it from intruders.";
TriviaBot_Questions[7]['Answers'][817] = {"Grizzly Hills",  "The Grizzly Hills"};
TriviaBot_Questions[7]['Category'][817] = 1;
TriviaBot_Questions[7]['Points'][817] = 1;
TriviaBot_Questions[7]['Hints'][817] = {};

TriviaBot_Questions[7]['Question'][818] = "Guess the Zone: The furbolgs of this zone is not hostile unless someone enters their territory. The furbolgs are suprisingly friendly to travelers, aslong as they dont make any claims on anything in the hills. They are quite simple people actually.";
TriviaBot_Questions[7]['Answers'][818] = {"The Grizzly Hills"};
TriviaBot_Questions[7]['Category'][818] = 1;
TriviaBot_Questions[7]['Points'][818] = 1;
TriviaBot_Questions[7]['Hints'][818] = {};

TriviaBot_Questions[7]['Question'][819] = "Guess the Zone: The wendigo and the sasquatch are some of the local inhabitants in the zone. This zone is full of life, and has many animals, such as wolves, and foxes, and even snow owl's. The Drakkari hunts only rarely in this zone.";
TriviaBot_Questions[7]['Answers'][819] = {"Grizzly Hills",  "The Grizzly Hills"};
TriviaBot_Questions[7]['Category'][819] = 1;
TriviaBot_Questions[7]['Points'][819] = 1;
TriviaBot_Questions[7]['Hints'][819] = {};

TriviaBot_Questions[7]['Question'][820] = "Guess the Zone: This zone has a low Scourge presence, only enough to block the northwest corner of the zone. The zone is described as 'It's not a easy land by any stretch, but its handsome and fierce, and full of life'.";
TriviaBot_Questions[7]['Answers'][820] = {"Grizzly Hills",  "The Grizzly Hills"};
TriviaBot_Questions[7]['Category'][820] = 1;
TriviaBot_Questions[7]['Points'][820] = 1;
TriviaBot_Questions[7]['Hints'][820] = {};

TriviaBot_Questions[7]['Question'][821] = "Guess the Zone: The Venture Co is deforesting the land in this zone, which is located in Northrend. The furbolgs in this zone probably has some quests regarding them, since they are a shamanistic people. This zone has many animals.";
TriviaBot_Questions[7]['Answers'][821] = {"The Grizzly Hills",  "Grizzly Hills"};
TriviaBot_Questions[7]['Category'][821] = 1;
TriviaBot_Questions[7]['Points'][821] = 1;
TriviaBot_Questions[7]['Hints'][821] = {};

TriviaBot_Questions[7]['Question'][822] = "Azjol-Nerub is located underground. (True/False)?";
TriviaBot_Questions[7]['Answers'][822] = {"true"};
TriviaBot_Questions[7]['Category'][822] = 1;
TriviaBot_Questions[7]['Points'][822] = 1;
TriviaBot_Questions[7]['Hints'][822] = {};

TriviaBot_Questions[7]['Question'][823] = "Azjol-Nerub is also known as the ________ Kingdom.";
TriviaBot_Questions[7]['Answers'][823] = {"Spider"};
TriviaBot_Questions[7]['Category'][823] = 1;
TriviaBot_Questions[7]['Points'][823] = 1;
TriviaBot_Questions[7]['Hints'][823] = {};

TriviaBot_Questions[7]['Question'][824] = "Guess the Zone: There is a small dwarven camp named Doorward, inside this zone. Some years ago Arthas attacked it, on his way to the Lich King. Most of the people there were not mortally wounded though. This zone is completly filled with the Scourge.";
TriviaBot_Questions[7]['Answers'][824] = {"Azjol-nerub"};
TriviaBot_Questions[7]['Category'][824] = 1;
TriviaBot_Questions[7]['Points'][824] = 1;
TriviaBot_Questions[7]['Hints'][824] = {};

TriviaBot_Questions[7]['Question'][825] = "Guess the Zone: Brann Bronzebeard claims it might be possible for an Alliance with the surviving nerubians if one is willing to help them clear out the Scourge from their empire. This zone is also knwon as 'The Spider Kingdom'.";
TriviaBot_Questions[7]['Answers'][825] = {"Azjol-Nerub"};
TriviaBot_Questions[7]['Category'][825] = 1;
TriviaBot_Questions[7]['Points'][825] = 1;
TriviaBot_Questions[7]['Hints'][825] = {};

TriviaBot_Questions[7]['Question'][826] = "Guess the Zone: It is said that this zone contains an Old God, and that the mysterius Forgotten Ones and the Faceless Ones and are his servants. Baelgun Flamebeard, the new leader of Doorward, fiercly belives in this and vows to stop them.";
TriviaBot_Questions[7]['Answers'][826] = {"Azjol-Nerub"};
TriviaBot_Questions[7]['Category'][826] = 1;
TriviaBot_Questions[7]['Points'][826] = 1;
TriviaBot_Questions[7]['Hints'][826] = {};

TriviaBot_Questions[7]['Question'][827] = "Just like Un'Goro Crater, ___________ in Northrend is an anomoly.";
TriviaBot_Questions[7]['Answers'][827] = {"Sholazar Basin"};
TriviaBot_Questions[7]['Category'][827] = 1;
TriviaBot_Questions[7]['Points'][827] = 1;
TriviaBot_Questions[7]['Hints'][827] = {};

TriviaBot_Questions[7]['Question'][828] = "Guess the Zone: This zone is a tropical jungle in the midst of Northrend. This zone is tropical, and no one knows why. This zone is quite small compared to other zones in Northrend. It's about the same size as the Crystalsong Forest.";
TriviaBot_Questions[7]['Answers'][828] = {"Sholazar Basin"};
TriviaBot_Questions[7]['Category'][828] = 1;
TriviaBot_Questions[7]['Points'][828] = 1;
TriviaBot_Questions[7]['Hints'][828] = {};

TriviaBot_Questions[7]['Question'][829] = "Guess the Zone: This zone lies northwest of Borean Tundra. The zone contains very hot geysers and steam vents. So hot, that if you put your hands in one of them, your hands flesh would be incinerated instantly. The wildlife here is rich.";
TriviaBot_Questions[7]['Answers'][829] = {"Sholazar Basin"};
TriviaBot_Questions[7]['Category'][829] = 1;
TriviaBot_Questions[7]['Points'][829] = 1;
TriviaBot_Questions[7]['Hints'][829] = {};

TriviaBot_Questions[7]['Question'][830] = "Guess the Zone: A high elf scholar belived that the Titans used the ________________ as a testing ground. If that's true, then some of their experiments might remain. The zone would be a tresure trove of knowledge and power if that is the case.";
TriviaBot_Questions[7]['Answers'][830] = {"Sholazar Basin"};
TriviaBot_Questions[7]['Category'][830] = 1;
TriviaBot_Questions[7]['Points'][830] = 1;
TriviaBot_Questions[7]['Hints'][830] = {};

TriviaBot_Questions[7]['Question'][831] = "Guess the Zone: This zone is located in the north-east of Northrend. The mysterius storm giants live in the famous Titan city of Ulduar in this zone. The winds here are extremely violent and dangerous.";
TriviaBot_Questions[7]['Answers'][831] = {"The Storm Peaks",  "Storm Peaks"};
TriviaBot_Questions[7]['Category'][831] = 1;
TriviaBot_Questions[7]['Points'][831] = 1;
TriviaBot_Questions[7]['Hints'][831] = {};

TriviaBot_Questions[7]['Question'][832] = "Guess the Zone: It was here that Aegywynn, the Guardian of Tirisfal battled Sargeras, the lord of the Burning legion. The magnataurs and the wendigos are two of the local inhabitants in this zone.";
TriviaBot_Questions[7]['Answers'][832] = {"The Storm Peaks",  "Storm Peaks"};
TriviaBot_Questions[7]['Category'][832] = 1;
TriviaBot_Questions[7]['Points'][832] = 1;
TriviaBot_Questions[7]['Hints'][832] = {};

TriviaBot_Questions[7]['Question'][833] = "Guess the Zone: The Titans used to live here. They even created a city where they worked on their experiments. Many caves exists in this zone, and it is rumored that the titans themselves created them.";
TriviaBot_Questions[7]['Answers'][833] = {"The Storm Peaks",  "Storm Peaks"};
TriviaBot_Questions[7]['Category'][833] = 1;
TriviaBot_Questions[7]['Points'][833] = 1;
TriviaBot_Questions[7]['Hints'][833] = {};

TriviaBot_Questions[7]['Question'][834] = "Guess the Zone: This zone contains the largest glacier on Azeroth, and became infamous when Kil'jaeden hurled a certain being into the glacier.";
TriviaBot_Questions[7]['Answers'][834] = {"Icecrown Glacier",  "The Icecrown Glacier"};
TriviaBot_Questions[7]['Category'][834] = 1;
TriviaBot_Questions[7]['Points'][834] = 1;
TriviaBot_Questions[7]['Hints'][834] = {};

TriviaBot_Questions[7]['Question'][835] = "Guess the Zone: The Scarlet Crusade succeeded in approaching the stronghold in this zone once, but was in the end repelled by the Scourge. They lost countless men and women. In the end they only became scourge themselves, most probably.";
TriviaBot_Questions[7]['Answers'][835] = {"Icecrown Glacier",  "The Icecrown Glacier"};
TriviaBot_Questions[7]['Category'][835] = 1;
TriviaBot_Questions[7]['Points'][835] = 1;
TriviaBot_Questions[7]['Hints'][835] = {};

TriviaBot_Questions[7]['Question'][836] = "Guess the Zone: This zone has the largest scourge presence of them all, as this zone is the heart of the Scourge. Countless people have tried to destroy it from here, but were only added to their ranks in the end.";
TriviaBot_Questions[7]['Answers'][836] = {"Icecrown Glacier",  "The Icecrown Glacier"};
TriviaBot_Questions[7]['Category'][836] = 1;
TriviaBot_Questions[7]['Points'][836] = 1;
TriviaBot_Questions[7]['Hints'][836] = {};

TriviaBot_Questions[7]['Question'][837] = "Name the zone which is the only zone so far to be completly devoted to PvP, and nothing else.";
TriviaBot_Questions[7]['Answers'][837] = {"Lake Wintergrasp"};
TriviaBot_Questions[7]['Category'][837] = 1;
TriviaBot_Questions[7]['Points'][837] = 1;
TriviaBot_Questions[7]['Hints'][837] = {};

TriviaBot_Questions[7]['Question'][838] = "Guess the Zone: This zone is basicly a large frozen lake. Sometimes, local taurens and taunka's cut holes in the lake to spear-fish. It is very dangerous to fall down in the lake, as you will be rendered unconscious by the cold within 3-10 minutes.";
TriviaBot_Questions[7]['Answers'][838] = {"Lake Wintergrasp"};
TriviaBot_Questions[7]['Category'][838] = 1;
TriviaBot_Questions[7]['Points'][838] = 1;
TriviaBot_Questions[7]['Hints'][838] = {};

TriviaBot_Questions[7]['Question'][839] = "Dalaran has ties to the Old Horde. (True/False)?";
TriviaBot_Questions[7]['Answers'][839] = {"false"};
TriviaBot_Questions[7]['Category'][839] = 1;
TriviaBot_Questions[7]['Points'][839] = 1;
TriviaBot_Questions[7]['Hints'][839] = {};

TriviaBot_Questions[7]['Question'][840] = "You cant use the flying mount before you are around level 75~ in __________.";
TriviaBot_Questions[7]['Answers'][840] = {"Northrend"};
TriviaBot_Questions[7]['Category'][840] = 1;
TriviaBot_Questions[7]['Points'][840] = 1;
TriviaBot_Questions[7]['Hints'][840] = {};

TriviaBot_Questions[7]['Question'][841] = "The neutral town in Northrend is called __________. It was teleported to Northrend because of Malygos and and his war against magic users.";
TriviaBot_Questions[7]['Answers'][841] = {"Dalaran"};
TriviaBot_Questions[7]['Category'][841] = 1;
TriviaBot_Questions[7]['Points'][841] = 1;
TriviaBot_Questions[7]['Hints'][841] = {};

TriviaBot_Questions[7]['Question'][842] = "___________ has moved to the new Forsaken town in Northrend, New Agamand. Its in New Agamand the testing of the new plague will begin.";
TriviaBot_Questions[7]['Answers'][842] = {"Sylvanas"};
TriviaBot_Questions[7]['Category'][842] = 1;
TriviaBot_Questions[7]['Points'][842] = 1;
TriviaBot_Questions[7]['Hints'][842] = {};

TriviaBot_Questions[7]['Question'][843] = "In what patch will we see Zul'Aman?";
TriviaBot_Questions[7]['Answers'][843] = {"2.3"};
TriviaBot_Questions[7]['Category'][843] = 1;
TriviaBot_Questions[7]['Points'][843] = 1;
TriviaBot_Questions[7]['Hints'][843] = {};

TriviaBot_Questions[7]['Question'][844] = "The blue dragonkin's in _________ can now drop an Azure Whelp, a blue dragon pet.";
TriviaBot_Questions[7]['Answers'][844] = {"Azshara"};
TriviaBot_Questions[7]['Category'][844] = 1;
TriviaBot_Questions[7]['Points'][844] = 1;
TriviaBot_Questions[7]['Hints'][844] = {};

TriviaBot_Questions[7]['Question'][845] = "In the upcoming patch, quest givers availible with daily quests will now have a ______ exclamation point instead of a yellow one.";
TriviaBot_Questions[7]['Answers'][845] = {"blue"};
TriviaBot_Questions[7]['Category'][845] = 1;
TriviaBot_Questions[7]['Points'][845] = 1;
TriviaBot_Questions[7]['Hints'][845] = {};

TriviaBot_Questions[7]['Question'][846] = "In the upcoming patch, the Sporregar faction will sell a ________ pet at exalted.";
TriviaBot_Questions[7]['Answers'][846] = {"sporebat"};
TriviaBot_Questions[7]['Category'][846] = 1;
TriviaBot_Questions[7]['Points'][846] = 1;
TriviaBot_Questions[7]['Hints'][846] = {};

TriviaBot_Questions[7]['Question'][847] = "In the upcoming patch, how much vendor discount does exalted give, in percent?";
TriviaBot_Questions[7]['Answers'][847] = {"20%",  "twenty percent"};
TriviaBot_Questions[7]['Category'][847] = 1;
TriviaBot_Questions[7]['Points'][847] = 1;
TriviaBot_Questions[7]['Hints'][847] = {};

TriviaBot_Questions[7]['Question'][848] = "In the upcoming patch, the Alliance Brigadier Generals and the Horde Warbringers will give out ___________ daily quests.";
TriviaBot_Questions[7]['Answers'][848] = {"battleground",  "bg"};
TriviaBot_Questions[7]['Category'][848] = 1;
TriviaBot_Questions[7]['Points'][848] = 1;
TriviaBot_Questions[7]['Hints'][848] = {};

TriviaBot_Questions[7]['Question'][849] = "In the upcoming patch, __________________ will feature a major change. The Commanders and Lieutenants has left this battleground, in search for new battle opportunities. Also, the elite tag on most of the NPC's has been removed.";
TriviaBot_Questions[7]['Answers'][849] = {"The Alterac Valley",  "Alterac Valley", "AV"};
TriviaBot_Questions[7]['Category'][849] = 1;
TriviaBot_Questions[7]['Points'][849] = 1;
TriviaBot_Questions[7]['Hints'][849] = {};

TriviaBot_Questions[7]['Question'][850] = "In the upcoming patch, ____________ paladins will get seriusly revamped.";
TriviaBot_Questions[7]['Answers'][850] = {"Retribution",  "ret"};
TriviaBot_Questions[7]['Category'][850] = 1;
TriviaBot_Questions[7]['Points'][850] = 1;
TriviaBot_Questions[7]['Hints'][850] = {};

TriviaBot_Questions[7]['Question'][851] = "In the upcoming patch, the dressing room will feature a significant change. You can now see how you would look with items from __________.";
TriviaBot_Questions[7]['Answers'][851] = {"receipes"};
TriviaBot_Questions[7]['Category'][851] = 1;
TriviaBot_Questions[7]['Points'][851] = 1;
TriviaBot_Questions[7]['Hints'][851] = {};

TriviaBot_Questions[7]['Question'][852] = "In the upcoming patch, engineers can create flying machines to have as flying mounts. (True/False)?";
TriviaBot_Questions[7]['Answers'][852] = {"true"};
TriviaBot_Questions[7]['Category'][852] = 1;
TriviaBot_Questions[7]['Points'][852] = 1;
TriviaBot_Questions[7]['Hints'][852] = {};

TriviaBot_Questions[7]['Question'][852] = "In the upcoming patch, you can catch a fishing ________ which teaches you how to 'track fishing nodes' via fishing.";
TriviaBot_Questions[7]['Answers'][852] = {"journal"};
TriviaBot_Questions[7]['Category'][852] = 1;
TriviaBot_Questions[7]['Points'][852] = 1;
TriviaBot_Questions[7]['Hints'][852] = {};

TriviaBot_Questions[7]['Question'][852] = "In the upcoming patch, all old world dungeons have had their loot revisited. One change in that all boss loot will now be of _________ quaility.";
TriviaBot_Questions[7]['Answers'][852] = {"superior"};
TriviaBot_Questions[7]['Category'][852] = 1;
TriviaBot_Questions[7]['Points'][852] = 1;
TriviaBot_Questions[7]['Hints'][852] = {};

TriviaBot_Questions[7]['Question'][852] = "In the upcoming patch, the elite mobs outside the instances in _________ has been changed to non-elite. The trolls outside ZF will become non-elites, for example.";
TriviaBot_Questions[7]['Answers'][852] = {"Azeroth"};
TriviaBot_Questions[7]['Category'][852] = 1;
TriviaBot_Questions[7]['Points'][852] = 1;
TriviaBot_Questions[7]['Hints'][852] = {};

TriviaBot_Questions[7]['Question'][853] = "In the upcommming patch, the heroic keys has been changed from revered to __________ as requirement before you can buy.";
TriviaBot_Questions[7]['Answers'][853] = {"honored"};
TriviaBot_Questions[7]['Category'][853] = 1;
TriviaBot_Questions[7]['Points'][853] = 1;
TriviaBot_Questions[7]['Hints'][853] = {};

TriviaBot_Questions[7]['Question'][854] = "In the upcoming patch, a lot of the old world's dungeons has been changed. They have also made the instances narrower in level ranges. (True/False)?";
TriviaBot_Questions[7]['Answers'][854] = {"true"};
TriviaBot_Questions[7]['Category'][854] = 1;
TriviaBot_Questions[7]['Points'][854] = 1;
TriviaBot_Questions[7]['Hints'][854] = {};

TriviaBot_Questions[7]['Question'][855] = "In the upcoming patch, you can get daily quests for fishing. (True/False)?";
TriviaBot_Questions[7]['Answers'][855] = {"false"};
TriviaBot_Questions[7]['Category'][855] = 1;
TriviaBot_Questions[7]['Points'][855] = 1;
TriviaBot_Questions[7]['Hints'][855] = {};

TriviaBot_Questions[7]['Question'][856] = "In the upcoming patch, you can get ________________ for heroic and non-heroic dungeons in Outland.";
TriviaBot_Questions[7]['Answers'][856] = {"daily quests"};
TriviaBot_Questions[7]['Category'][856] = 1;
TriviaBot_Questions[7]['Points'][856] = 1;
TriviaBot_Questions[7]['Hints'][856] = {};

-- Naxxrammas

TriviaBot_Questions[7]['Question'][857] = "Naxxrammas was once an ancient ________ ziggurat, before it was pulled free from the ground by agents of the Lich King. It served as Kel'Thuzad's base of operations as he spread the plague. It's the home of Kel'Thuzad.";
TriviaBot_Questions[7]['Answers'][857] = {"nerubian"};
TriviaBot_Questions[7]['Category'][857] = 1;
TriviaBot_Questions[7]['Points'][857] = 1;
TriviaBot_Questions[7]['Hints'][857] = {};

TriviaBot_Questions[7]['Question'][858] = "What is the name of the legendary caster staff, in Naxxramas?";
TriviaBot_Questions[7]['Answers'][858] = {"Atiesh, Greatstaff of the Guardian",  "Atiesh"};
TriviaBot_Questions[7]['Category'][858] = 1;
TriviaBot_Questions[7]['Points'][858] = 1;
TriviaBot_Questions[7]['Hints'][858] = {};

TriviaBot_Questions[7]['Question'][859] = "Kel'Thuzad was formerly a sorcerer of ________.";
TriviaBot_Questions[7]['Answers'][859] = {"Dalaran"};
TriviaBot_Questions[7]['Category'][859] = 1;
TriviaBot_Questions[7]['Points'][859] = 1;
TriviaBot_Questions[7]['Hints'][859] = {};

TriviaBot_Questions[7]['Question'][860] = "No one have yet entered __________ and lived to tell the tale. (hint: The Dread Citadel)";
TriviaBot_Questions[7]['Answers'][860] = {"Naxxrammas",  "Naxx"};
TriviaBot_Questions[7]['Category'][860] = 1;
TriviaBot_Questions[7]['Points'][860] = 1;
TriviaBot_Questions[7]['Hints'][860] = {};

TriviaBot_Questions[7]['Question'][861] = "To enter Naxxramas you need to go into an open _________ in the middle of Plaguewood, which lies in the Eastern Plaguelands. From there you teleport yourself to Naxxramas, by standing on the main floor.";
TriviaBot_Questions[7]['Answers'][861] = {"ziggurat"};
TriviaBot_Questions[7]['Category'][861] = 1;
TriviaBot_Questions[7]['Points'][861] = 1;
TriviaBot_Questions[7]['Hints'][861] = {};

TriviaBot_Questions[7]['Question'][862] = "Naxxramas will be retuned for level 80. (True/False)?";
TriviaBot_Questions[7]['Answers'][862] = {"true"};
TriviaBot_Questions[7]['Category'][862] = 1;
TriviaBot_Questions[7]['Points'][862] = 1;
TriviaBot_Questions[7]['Hints'][862] = {};

TriviaBot_Questions[7]['Question'][863] = "Naxxramas has how many wings?";
TriviaBot_Questions[7]['Answers'][863] = {"4",  "four", "four wings", "4 wings"};
TriviaBot_Questions[7]['Category'][863] = 1;
TriviaBot_Questions[7]['Points'][863] = 1;
TriviaBot_Questions[7]['Hints'][863] = {};

TriviaBot_Questions[7]['Question'][864] = "Who is the last boss of the Spider Wing in Naxxramas?";
TriviaBot_Questions[7]['Answers'][864] = {"Maexxna"};
TriviaBot_Questions[7]['Category'][864] = 1;
TriviaBot_Questions[7]['Points'][864] = 1;
TriviaBot_Questions[7]['Hints'][864] = {};

TriviaBot_Questions[7]['Question'][865] = "Who is the last boss of the Plague Wing in Naxxramas?";
TriviaBot_Questions[7]['Answers'][865] = {"Loatheb"};
TriviaBot_Questions[7]['Category'][865] = 1;
TriviaBot_Questions[7]['Points'][865] = 1;
TriviaBot_Questions[7]['Hints'][865] = {};

TriviaBot_Questions[7]['Question'][866] = "What is the last bosses of the Deathknight wing called, in Naxxramas?";
TriviaBot_Questions[7]['Answers'][866] = {"The Four Horsemen"};
TriviaBot_Questions[7]['Category'][866] = 1;
TriviaBot_Questions[7]['Points'][866] = 1;
TriviaBot_Questions[7]['Hints'][866] = {};

TriviaBot_Questions[7]['Question'][867] = "Who is the last boss of the Abomination Wing in Naxxramas?";
TriviaBot_Questions[7]['Answers'][867] = {"Thaddius"};
TriviaBot_Questions[7]['Category'][867] = 1;
TriviaBot_Questions[7]['Points'][867] = 1;
TriviaBot_Questions[7]['Hints'][867] = {};

TriviaBot_Questions[7]['Question'][868] = "There is a night elf highborne inside Naxxramas, called _________ Tarsis Kir-Moldir.";
TriviaBot_Questions[7]['Answers'][868] = {"Archmage"};
TriviaBot_Questions[7]['Category'][868] = 1;
TriviaBot_Questions[7]['Points'][868] = 1;
TriviaBot_Questions[7]['Hints'][868] = {};

TriviaBot_Questions[7]['Question'][869] = "What is the cat inside Naxxramas called? if you kill it, Kel'Thuzad will curse you and you're raid.";
TriviaBot_Questions[7]['Answers'][869] = {"Bigglesworth",  "Mr. Bigglesworth"};
TriviaBot_Questions[7]['Category'][869] = 1;
TriviaBot_Questions[7]['Points'][869] = 1;
TriviaBot_Questions[7]['Hints'][869] = {};

TriviaBot_Questions[7]['Question'][870] = "Players will need resistance in every element in order to complete Naxxramas. (True/False)?";
TriviaBot_Questions[7]['Answers'][870] = {"false"};
TriviaBot_Questions[7]['Category'][870] = 1;
TriviaBot_Questions[7]['Points'][870] = 1;
TriviaBot_Questions[7]['Hints'][870] = {}; -- You dont _need_ nature resistance, or fire resistance (not sure about fire though) and perhaps arcane

TriviaBot_Questions[7]['Question'][871] = "You need to clear every wing before you can enter ________ Lair, in Naxxramas.";
TriviaBot_Questions[7]['Answers'][871] = {"Frostwyrm"};
TriviaBot_Questions[7]['Category'][871] = 1;
TriviaBot_Questions[7]['Points'][871] = 1;
TriviaBot_Questions[7]['Hints'][871] = {};

TriviaBot_Questions[7]['Question'][872] = "What dungeon tier drops in Naxxramas?";
TriviaBot_Questions[7]['Answers'][872] = {"Tier 3"};
TriviaBot_Questions[7]['Category'][872] = 1;
TriviaBot_Questions[7]['Points'][872] = 1;
TriviaBot_Questions[7]['Hints'][872] = {};

TriviaBot_Questions[7]['Question'][873] = "What can you find on the walls of each boss chamber and varius other places, in Naxxramas?";
TriviaBot_Questions[7]['Answers'][873] = {"Frozen Runes",  "Frozen Rune's"};
TriviaBot_Questions[7]['Category'][873] = 1;
TriviaBot_Questions[7]['Points'][873] = 1;
TriviaBot_Questions[7]['Hints'][873] = {};

TriviaBot_Questions[7]['Question'][874] = "Defrosting a frozen rune in Naxxramas with 'Word of _______' yields around 3 to 6 tradeable frozen runes. They can be used as a Greater Frost Protection Potion, or to craft epic frost resistance gear.";
TriviaBot_Questions[7]['Answers'][874] = {"Thawing"};
TriviaBot_Questions[7]['Category'][874] = 1;
TriviaBot_Questions[7]['Points'][874] = 1;
TriviaBot_Questions[7]['Hints'][874] = {};

TriviaBot_Questions[7]['Question'][875] = "You dont generally use the frozen rune's from Naxxramas, as it is considered too expensive. Instead, most guilds use them to create the epic _____ resistance gear for classes, which is needed for Sapphiron in Naxxramas.";
TriviaBot_Questions[7]['Answers'][875] = {"frost"};
TriviaBot_Questions[7]['Category'][875] = 1;
TriviaBot_Questions[7]['Points'][875] = 1;
TriviaBot_Questions[7]['Hints'][875] = {};

TriviaBot_Questions[7]['Question'][876] = "The epic frost resistance collection for Rogues is called _______. Guilds usually create them for Naxxramas.";
TriviaBot_Questions[7]['Answers'][876] = {"polar"};
TriviaBot_Questions[7]['Category'][876] = 1;
TriviaBot_Questions[7]['Points'][876] = 1;
TriviaBot_Questions[7]['Hints'][876] = {};

TriviaBot_Questions[7]['Question'][877] = "The epic frost resistance collection for Hunters is called ____________. Guilds usually create them for Naxxramas.";
TriviaBot_Questions[7]['Answers'][877] = {"Icy Scale"};
TriviaBot_Questions[7]['Category'][877] = 1;
TriviaBot_Questions[7]['Points'][877] = 1;
TriviaBot_Questions[7]['Hints'][877] = {};

TriviaBot_Questions[7]['Question'][878] = "The epic frost resistance collection for Mages, Priests, Warlocks is called __________. Guilds usually create them for Naxxramas.";
TriviaBot_Questions[7]['Answers'][878] = {"Glacial"};
TriviaBot_Questions[7]['Category'][878] = 1;
TriviaBot_Questions[7]['Points'][878] = 1;
TriviaBot_Questions[7]['Hints'][878] = {};

TriviaBot_Questions[7]['Question'][879] = "What boss is considered to be the easiest, in Naxxramas?";
TriviaBot_Questions[7]['Answers'][879] = {"Instructor Razuvious",  "Razuvious"};
TriviaBot_Questions[7]['Category'][879] = 1;
TriviaBot_Questions[7]['Points'][879] = 1;
TriviaBot_Questions[7]['Hints'][879] = {};

TriviaBot_Questions[7]['Question'][880] = "What boss in Naxxramas is considered a very hard 'gear check'?";
TriviaBot_Questions[7]['Answers'][880] = {"Patchwerk"};
TriviaBot_Questions[7]['Category'][880] = 1;
TriviaBot_Questions[7]['Points'][880] = 1;
TriviaBot_Questions[7]['Hints'][880] = {};

TriviaBot_Questions[7]['Question'][881] = "What boss is considered to be the second hardest in Naxxramas?";
TriviaBot_Questions[7]['Answers'][881] = {"The Four Horsemen"};
TriviaBot_Questions[7]['Category'][881] = 1;
TriviaBot_Questions[7]['Points'][881] = 1;
TriviaBot_Questions[7]['Hints'][881] = {};

TriviaBot_Questions[7]['Question'][882] = "What boss is considered to be the hardest of all in Naxxramas?";
TriviaBot_Questions[7]['Answers'][882] = {"Kel'Thuzad"};
TriviaBot_Questions[7]['Category'][882] = 1;
TriviaBot_Questions[7]['Points'][882] = 1;
TriviaBot_Questions[7]['Hints'][882] = {};

TriviaBot_Questions[7]['Question'][883] = "In what instance except Naxxramas, can Kel'Thuzad be found?";
TriviaBot_Questions[7]['Answers'][883] = {"Escape from Durnholde Keep",  "Durnholde", "Escape from Durnholde", "Old hillsbrad", "Old hillsbrad foothills"};
TriviaBot_Questions[7]['Category'][883] = 1;
TriviaBot_Questions[7]['Points'][883] = 1;
TriviaBot_Questions[7]['Hints'][883] = {};

TriviaBot_Questions[7]['Question'][884] = "In order to fight Sapphiron, you need to ring a bell inside Naxxramas. (True/False)?";
TriviaBot_Questions[7]['Answers'][884] = {"false"};
TriviaBot_Questions[7]['Category'][884] = 1;
TriviaBot_Questions[7]['Points'][884] = 1;
TriviaBot_Questions[7]['Hints'][884] = {};

TriviaBot_Questions[7]['Question'][885] = "What resistance do you need 150-200 of, in order to kill Sapphiron in Naxxramas? (atleast it was so, pre-bc)";
TriviaBot_Questions[7]['Answers'][885] = {"frost"};
TriviaBot_Questions[7]['Category'][885] = 1;
TriviaBot_Questions[7]['Points'][885] = 1;
TriviaBot_Questions[7]['Hints'][885] = {};

TriviaBot_Questions[7]['Question'][886] = "It is likely that the Ashbringer will be moved from Naxxramas till a instance in Utgarde Keep. (True/False)?";
TriviaBot_Questions[7]['Answers'][886] = {"true"};
TriviaBot_Questions[7]['Category'][886] = 1;
TriviaBot_Questions[7]['Points'][886] = 1;
TriviaBot_Questions[7]['Hints'][886] = {}; -- Tirion Fordring has a quest in Northrend regarding finding The Ashbringer.

TriviaBot_Questions[7]['Question'][887] = "What is the name of the boss which is considered 'free loot' by many people?";
TriviaBot_Questions[7]['Answers'][887] = {"Grobbulus"};
TriviaBot_Questions[7]['Category'][887] = 1;
TriviaBot_Questions[7]['Points'][887] = 1;
TriviaBot_Questions[7]['Hints'][887] = {};

TriviaBot_Questions[7]['Question'][888] = "_____________ in Naxxramas you need to kite, in order to defeat him. He is known to get bugged sometimes.";
TriviaBot_Questions[7]['Answers'][888] = {"Anub'Rekhan"};
TriviaBot_Questions[7]['Category'][888] = 1;
TriviaBot_Questions[7]['Points'][888] = 1;
TriviaBot_Questions[7]['Hints'][888] = {};

TriviaBot_Questions[7]['Question'][889] = "What is the mobs that spawns during the Anub'Rekhan fight called? (hint: the huge spiders, which you need to offtank and kill before you can countinue to DPS Anub'Rekhan)";
TriviaBot_Questions[7]['Answers'][889] = {"Crypt Guards",  "Crypt Guard"};
TriviaBot_Questions[7]['Category'][889] = 1;
TriviaBot_Questions[7]['Points'][889] = 1;
TriviaBot_Questions[7]['Hints'][889] = {};

TriviaBot_Questions[7]['Question'][890] = "What raiding instance is considered to be the 'best' ever created by Blizzard, atleast of the 40man instances?";
TriviaBot_Questions[7]['Answers'][890] = {"Naxxramas",  "Naxx"};
TriviaBot_Questions[7]['Category'][890] = 1;
TriviaBot_Questions[7]['Points'][890] = 1;
TriviaBot_Questions[7]['Hints'][890] = {};

TriviaBot_Questions[7]['Question'][891] = "What boss in Naxxramas casts Locust Swarm, the deadly 1200 dmg / 2sec dot which the tank must avoid at any cost?";
TriviaBot_Questions[7]['Answers'][891] = {"Anub'Rekhan"};
TriviaBot_Questions[7]['Category'][891] = 1;
TriviaBot_Questions[7]['Points'][891] = 1;
TriviaBot_Questions[7]['Hints'][891] = {};

TriviaBot_Questions[7]['Question'][892] = "What boss in Naxxramas can create Corpse Scarabs from the remains of dead Crypt Guards and dead players? (hint: These scarabs can never be allowed to hit the MT, due to the 'daze' effect which is devestating)";
TriviaBot_Questions[7]['Answers'][892] = {"Anub'Rekhan"};
TriviaBot_Questions[7]['Category'][892] = 1;
TriviaBot_Questions[7]['Points'][892] = 1;
TriviaBot_Questions[7]['Hints'][892] = {};

TriviaBot_Questions[7]['Question'][893] = "Quote: I hear little hearts beating. Yesss... beating faster now. Soon the beating will stop.";
TriviaBot_Questions[7]['Answers'][893] = {"Anub'Rekhan"};
TriviaBot_Questions[7]['Category'][893] = 1;
TriviaBot_Questions[7]['Points'][893] = 1;
TriviaBot_Questions[7]['Hints'][893] = {};

TriviaBot_Questions[7]['Question'][894] = "What boss casts Poison Bolt Volley in Naxxramas?";
TriviaBot_Questions[7]['Answers'][894] = {"Grand Widow Faerlina",  "Faerlina"};
TriviaBot_Questions[7]['Category'][894] = 1;
TriviaBot_Questions[7]['Points'][894] = 1;
TriviaBot_Questions[7]['Hints'][894] = {};

TriviaBot_Questions[7]['Question'][895] = "What boss has worshippers as adds in Naxxramas?";
TriviaBot_Questions[7]['Answers'][895] = {"Grand Widow Faerlina",  "Faerlina"};
TriviaBot_Questions[7]['Category'][895] = 1;
TriviaBot_Questions[7]['Points'][895] = 1;
TriviaBot_Questions[7]['Hints'][895] = {};

TriviaBot_Questions[7]['Question'][896] = "Quote: Your old lives, your mortal desires, mean nothing. You are acolytes of the master now, and you will serve the cause without question! The greatest glory is to die in the master's service!";
TriviaBot_Questions[7]['Answers'][896] = {"Grand Widow Faerlina",  "Faerlina"};
TriviaBot_Questions[7]['Category'][896] = 1;
TriviaBot_Questions[7]['Points'][896] = 1;
TriviaBot_Questions[7]['Hints'][896] = {};

TriviaBot_Questions[7]['Question'][897] = "What boss will 'cocoon' players, in Naxxramas?";
TriviaBot_Questions[7]['Answers'][897] = {"Maexxna"};
TriviaBot_Questions[7]['Category'][897] = 1;
TriviaBot_Questions[7]['Points'][897] = 1;
TriviaBot_Questions[7]['Hints'][897] = {};

TriviaBot_Questions[7]['Question'][898] = "What boss casts Web Sprays, in Naxxramas?";
TriviaBot_Questions[7]['Answers'][898] = {"Maexxna"};
TriviaBot_Questions[7]['Category'][898] = 1;
TriviaBot_Questions[7]['Points'][898] = 1;
TriviaBot_Questions[7]['Hints'][898] = {};

TriviaBot_Questions[7]['Question'][899] = "What boss in Naxxramas drops the Wraith blade, a caster sword?";
TriviaBot_Questions[7]['Answers'][899] = {"Maexxna"};
TriviaBot_Questions[7]['Category'][899] = 1;
TriviaBot_Questions[7]['Points'][899] = 1;
TriviaBot_Questions[7]['Hints'][899] = {};

TriviaBot_Questions[7]['Question'][900] = "What boss drops the epic T3 hands, in Naxxramas?";
TriviaBot_Questions[7]['Answers'][900] = {"Maexxna"};
TriviaBot_Questions[7]['Category'][900] = 1;
TriviaBot_Questions[7]['Points'][900] = 1;
TriviaBot_Questions[7]['Hints'][900] = {};


TriviaBot_Questions[7]['Question'][901] = "Noth the Plaguebringer were once a notable wizard and ________ of Dalaran. (hint: proffesion in wow)";
TriviaBot_Questions[7]['Answers'][901] = {"alchemist"};
TriviaBot_Questions[7]['Category'][901] = 1;
TriviaBot_Questions[7]['Points'][901] = 1;
TriviaBot_Questions[7]['Hints'][901] = {};

TriviaBot_Questions[7]['Question'][902] = "Kel'Thuzad froze ______________________'s heart in Naxxramas with cold magic, so that he would not have any feelings. This was needed, because of his guilt. He is now more undead then human.";
TriviaBot_Questions[7]['Answers'][902] = {"Noth the Plaguebringer",  "Noth"};
TriviaBot_Questions[7]['Category'][902] = 1;
TriviaBot_Questions[7]['Points'][902] = 1;
TriviaBot_Questions[7]['Hints'][902] = {};

TriviaBot_Questions[7]['Question'][903] = "What boss in Naxxramas casts Curse of the Plaguebringer, which must be decursed at all costs, otherwise the raid will most probably wipe?";
TriviaBot_Questions[7]['Answers'][903] = {"Noth the Plaguebringer",  "Noth"};
TriviaBot_Questions[7]['Category'][903] = 1;
TriviaBot_Questions[7]['Points'][903] = 1;
TriviaBot_Questions[7]['Hints'][903] = {};

TriviaBot_Questions[7]['Question'][904] = "Quote: Rise my soldiers! Rise, and fight once more!";
TriviaBot_Questions[7]['Answers'][904] = {"Noth the Plaguebringer",  "Noth"};
TriviaBot_Questions[7]['Category'][904] = 1;
TriviaBot_Questions[7]['Points'][904] = 1;
TriviaBot_Questions[7]['Hints'][904] = {};

TriviaBot_Questions[7]['Question'][905] = "Quote: Glory to the master!";
TriviaBot_Questions[7]['Answers'][905] = {"Noth the Plaguebringer",  "Noth"};
TriviaBot_Questions[7]['Category'][905] = 1;
TriviaBot_Questions[7]['Points'][905] = 1;
TriviaBot_Questions[7]['Hints'][905] = {};

TriviaBot_Questions[7]['Question'][906] = "What boss requires you to essentially 'dance' to avoid dying in Naxxramas?";
TriviaBot_Questions[7]['Answers'][906] = {"Heigan the Unclean",  "Heigan"};
TriviaBot_Questions[7]['Category'][906] = 1;
TriviaBot_Questions[7]['Points'][906] = 1;
TriviaBot_Questions[7]['Hints'][906] = {};

TriviaBot_Questions[7]['Question'][907] = "What boss in Naxxramas teleports three people to a tunnel occasionally?";
TriviaBot_Questions[7]['Answers'][907] = {"Heigan the Unclean",  "Heigan"};
TriviaBot_Questions[7]['Category'][907] = 1;
TriviaBot_Questions[7]['Points'][907] = 1;
TriviaBot_Questions[7]['Hints'][907] = {};

TriviaBot_Questions[7]['Question'][908] = "Quote: Close your eyes.. sleep";
TriviaBot_Questions[7]['Answers'][908] = {"Heigan the Unclean",  "Heigan"};
TriviaBot_Questions[7]['Category'][908] = 1;
TriviaBot_Questions[7]['Points'][908] = 1;
TriviaBot_Questions[7]['Hints'][908] = {};

TriviaBot_Questions[7]['Question'][909] = "Quote: The end is upon you.";
TriviaBot_Questions[7]['Answers'][909] = {"Heigan the Unclean",  "Heigan"};
TriviaBot_Questions[7]['Category'][909] = 1;
TriviaBot_Questions[7]['Points'][909] = 1;
TriviaBot_Questions[7]['Hints'][909] = {};

TriviaBot_Questions[7]['Question'][910] = "What boss in Naxxramas requires very good individual coordination from everyone?";
TriviaBot_Questions[7]['Answers'][910] = {"Heigan the Unclean",  "Heigan"};
TriviaBot_Questions[7]['Category'][910] = 1;
TriviaBot_Questions[7]['Points'][910] = 1;
TriviaBot_Questions[7]['Hints'][910] = {};

TriviaBot_Questions[7]['Question'][911] = "What boss in Naxxramas requires 3x Greater Shadow Protection Potions?";
TriviaBot_Questions[7]['Answers'][911] = {"Loatheb"};
TriviaBot_Questions[7]['Category'][911] = 1;
TriviaBot_Questions[7]['Points'][911] = 1;
TriviaBot_Questions[7]['Hints'][911] = {};

TriviaBot_Questions[7]['Question'][912] = "What boss casts Corrupted Mind, which makes you able to only cast one healing spell per minute, in Naxxramas?";
TriviaBot_Questions[7]['Answers'][912] = {"Loatheb"};
TriviaBot_Questions[7]['Category'][912] = 1;
TriviaBot_Questions[7]['Points'][912] = 1;
TriviaBot_Questions[7]['Hints'][912] = {};

TriviaBot_Questions[7]['Question'][913] = "What boss spawns spores, which upon killing grants five players the fungal bloom debuff? (increases you're crit and hit, and causes you to make no threat)";
TriviaBot_Questions[7]['Answers'][913] = {"Loatheb"};
TriviaBot_Questions[7]['Category'][913] = 1;
TriviaBot_Questions[7]['Points'][913] = 1;
TriviaBot_Questions[7]['Hints'][913] = {};

TriviaBot_Questions[7]['Question'][914] = "What boss in Naxxramas casts Unbalancing Strike, which need to be taken by one of his adds?";
TriviaBot_Questions[7]['Answers'][914] = {"Instructor Razuvious",  "Razuvious"};
TriviaBot_Questions[7]['Category'][914] = 1;
TriviaBot_Questions[7]['Points'][914] = 1;
TriviaBot_Questions[7]['Hints'][914] = {};

TriviaBot_Questions[7]['Question'][915] = "What boss in Naxxramas casts Disrupting Shout, which reduces the mana of everyone it hits by up to 4000 and deals twice the mana burned this way in damage?";
TriviaBot_Questions[7]['Answers'][915] = {"Instructor Razuvious",  "Razuvious"};
TriviaBot_Questions[7]['Category'][915] = 1;
TriviaBot_Questions[7]['Points'][915] = 1;
TriviaBot_Questions[7]['Hints'][915] = {};

TriviaBot_Questions[7]['Question'][916] = "Quote: The time for practice is over! Show me what you've learned!";
TriviaBot_Questions[7]['Answers'][916] = {"Instructor Razuvious",  "Razuvious"};
TriviaBot_Questions[7]['Category'][916] = 1;
TriviaBot_Questions[7]['Points'][916] = 1;
TriviaBot_Questions[7]['Hints'][916] = {};

TriviaBot_Questions[7]['Question'][917] = "Quote: Show me what you've got!";
TriviaBot_Questions[7]['Answers'][917] = {"Instructor Razuvious",  "Razuvious"};
TriviaBot_Questions[7]['Category'][917] = 1;
TriviaBot_Questions[7]['Points'][917] = 1;
TriviaBot_Questions[7]['Hints'][917] = {};

TriviaBot_Questions[7]['Question'][918] = "Quote: An honorable... death..";
TriviaBot_Questions[7]['Answers'][918] = {"Instructor Razuvious",  "Razuvious"};
TriviaBot_Questions[7]['Category'][918] = 1;
TriviaBot_Questions[7]['Points'][918] = 1;
TriviaBot_Questions[7]['Hints'][918] = {};

TriviaBot_Questions[7]['Question'][919] = "The bosses in Naxxramas can sometimes drop ______ of Atiesh. Sapphiron and Kel'Thuzad will never drop one, though.";
TriviaBot_Questions[7]['Answers'][919] = {"Splinter"};
TriviaBot_Questions[7]['Category'][919] = 1;
TriviaBot_Questions[7]['Points'][919] = 1;
TriviaBot_Questions[7]['Hints'][919] = {};

TriviaBot_Questions[7]['Question'][920] = "What boss in Naxxramas looks nearly identical to Heigan the Unclean?";
TriviaBot_Questions[7]['Answers'][920] = {"Gothik the Harvester",  "Gothik"};
TriviaBot_Questions[7]['Category'][920] = 1;
TriviaBot_Questions[7]['Points'][920] = 1;
TriviaBot_Questions[7]['Hints'][920] = {};

TriviaBot_Questions[7]['Question'][921] = "What boss in Naxxramas will have you kill Spectral Trainee's, Unrelenting Riders and other undeads, before you can face him?";
TriviaBot_Questions[7]['Answers'][921] = {"Gothik the Harvester",  "Gothik"};
TriviaBot_Questions[7]['Category'][921] = 1;
TriviaBot_Questions[7]['Points'][921] = 1;
TriviaBot_Questions[7]['Hints'][921] = {};

TriviaBot_Questions[7]['Question'][922] = "What boss in Naxxramas will casts Harvest Soul sometimes on the tank, which reduces stats by 10% and is stackable?";
TriviaBot_Questions[7]['Answers'][922] = {"Gothik the Harvester",  "Gothik"};
TriviaBot_Questions[7]['Category'][922] = 1;
TriviaBot_Questions[7]['Points'][922] = 1;
TriviaBot_Questions[7]['Hints'][922] = {};

TriviaBot_Questions[7]['Question'][923] = "Quote: Foolishly you have sought your own demise. Brazenly you have disregarded powers beyond your understanding. You have fought hard to invade the realm of the harvester. Now there is only one way out - to walk the lonely path of the damned.";
TriviaBot_Questions[7]['Answers'][923] = {"Gothik the Harvester",  "Gothik"};
TriviaBot_Questions[7]['Category'][923] = 1;
TriviaBot_Questions[7]['Points'][923] = 1;
TriviaBot_Questions[7]['Hints'][923] = {};

TriviaBot_Questions[7]['Question'][924] = "Quote: I have waited long enough! Now, you face the harvester of souls!";
TriviaBot_Questions[7]['Answers'][924] = {"Gothik the Harvester",  "Gothik"};
TriviaBot_Questions[7]['Category'][924] = 1;
TriviaBot_Questions[7]['Points'][924] = 1;
TriviaBot_Questions[7]['Hints'][924] = {};

TriviaBot_Questions[7]['Question'][925] = "The Four Horsemen are Highlord Mograine, Thane Korth'azz, Lady Blaumeux, and Sir _______. They are in service of the powerful lich, Kel'Thuzad.";
TriviaBot_Questions[7]['Answers'][925] = {"Zeliek"};
TriviaBot_Questions[7]['Category'][925] = 1;
TriviaBot_Questions[7]['Points'][925] = 1;
TriviaBot_Questions[7]['Hints'][925] = {};

TriviaBot_Questions[7]['Question'][926] = "Highlord Mograine's special ability in Naxxramas, is the _____________. It deals 2160-2640 frontload damage and a 4800/8 sec damage DoT. It is identical to Ragnaros's Elemental Fire, and can be mitigated by fire resist.";
TriviaBot_Questions[7]['Answers'][926] = {"Righteous Fire"};
TriviaBot_Questions[7]['Category'][926] = 1;
TriviaBot_Questions[7]['Points'][926] = 1;
TriviaBot_Questions[7]['Hints'][926] = {};

TriviaBot_Questions[7]['Question'][927] = "Thane Korth'azz's special ability in Naxxrams, is the ________. It deals roughly 14250-15750~ fire damage, which is shared between all people within 8 yards from where the meteor landed.";
TriviaBot_Questions[7]['Answers'][927] = {"Meteor"};
TriviaBot_Questions[7]['Category'][927] = 1;
TriviaBot_Questions[7]['Points'][927] = 1;
TriviaBot_Questions[7]['Hints'][927] = {};

TriviaBot_Questions[7]['Question'][928] = "Sir Zeliek's special ability is called ______________. It will chain around everyone within 5 yards of the last hitted target, so it's important too not get to close. It wont loop however, but it deals twice the damage each hit.";
TriviaBot_Questions[7]['Answers'][828] = {"Holy Wrath"};
TriviaBot_Questions[7]['Category'][828] = 1;
TriviaBot_Questions[7]['Points'][828] = 1;
TriviaBot_Questions[7]['Hints'][828] = {};

TriviaBot_Questions[7]['Question'][929] = "Lady Blaumeux's special ability in Naxxramas, is the ____________. It will summon an area of damage that deals shadow damage if you step into it. It has a small radius however, only 5~ yards. It lasts for 1 minute and 30 seconds.";
TriviaBot_Questions[7]['Answers'][929] = {"Void Zone"};
TriviaBot_Questions[7]['Category'][929] = 1;
TriviaBot_Questions[7]['Points'][929] = 1;
TriviaBot_Questions[7]['Hints'][929] = {};

TriviaBot_Questions[7]['Question'][930] = "Who drops the Ashbringer, in Naxxramas?";
TriviaBot_Questions[7]['Answers'][930] = {"Highlord Mograine"};
TriviaBot_Questions[7]['Category'][930] = 1;
TriviaBot_Questions[7]['Points'][930] = 1;
TriviaBot_Questions[7]['Hints'][930] = {};

TriviaBot_Questions[7]['Question'][931] = "You need to tank each of the horsemen seperately, in Naxxramas. (True/False)?";
TriviaBot_Questions[7]['Answers'][931] = {"True"};
TriviaBot_Questions[7]['Category'][931] = 1;
TriviaBot_Questions[7]['Points'][931] = 1;
TriviaBot_Questions[7]['Hints'][931] = {};

TriviaBot_Questions[7]['Question'][932] = "Quote: Life is meaningless. It is in death that we are truly tested.";
TriviaBot_Questions[7]['Answers'][932] = {"Highlord Mograine",  "Mograine"};
TriviaBot_Questions[7]['Category'][932] = 1;
TriviaBot_Questions[7]['Points'][932] = 1;
TriviaBot_Questions[7]['Hints'][932] = {};

TriviaBot_Questions[7]['Question'][933] = "Quote: The first kill goes to me! Anyone care to wager?";
TriviaBot_Questions[7]['Answers'][933] = {"Lady Blaumeux",  "Blaumeux"};
TriviaBot_Questions[7]['Category'][933] = 1;
TriviaBot_Questions[7]['Points'][933] = 1;
TriviaBot_Questions[7]['Hints'][933] = {};

TriviaBot_Questions[7]['Question'][934] = "Quote: I'm gonna enjoy killin' these slack-jawed daffodils!";
TriviaBot_Questions[7]['Answers'][934] = {"Thane Korth'azz",  "Thane Korthazz"};
TriviaBot_Questions[7]['Category'][934] = 1;
TriviaBot_Questions[7]['Points'][934] = 1;
TriviaBot_Questions[7]['Hints'][934] = {};

TriviaBot_Questions[7]['Question'][935] = "Quote: Do not continue! Turn back while there's still time!";
TriviaBot_Questions[7]['Answers'][935] = {"Sir Zeliek",  "Zeliek"};
TriviaBot_Questions[7]['Category'][935] = 1;
TriviaBot_Questions[7]['Points'][935] = 1;
TriviaBot_Questions[7]['Hints'][935] = {};

TriviaBot_Questions[7]['Question'][936] = "This boss in Naxxramas is a major difficulty for healers especially. The healing needs to be perfect for this boss, and the same with the DPS. This boss is the first boss of the Abonimation Wing.";
TriviaBot_Questions[7]['Answers'][936] = {"Patchwerk"};
TriviaBot_Questions[7]['Category'][936] = 1;
TriviaBot_Questions[7]['Points'][936] = 1;
TriviaBot_Questions[7]['Hints'][936] = {};

TriviaBot_Questions[7]['Question'][937] = "If this boss in Naxxramas enters a berserker rage, then the raid will have around 12 seconds max to kill him, before they are all dead.";
TriviaBot_Questions[7]['Answers'][937] = {"Patchwerk"};
TriviaBot_Questions[7]['Category'][937] = 1;
TriviaBot_Questions[7]['Points'][937] = 1;
TriviaBot_Questions[7]['Hints'][937] = {};

TriviaBot_Questions[7]['Question'][938] = "This boss in Naxxramas is known for its difficulty. This boss is probably the hardest of the first ones in each wing. His special ability 'Hateful Strike', can be devestating for the MT. This encounter is hard for every class.";
TriviaBot_Questions[7]['Answers'][938] = {"Patchwerk"};
TriviaBot_Questions[7]['Category'][938] = 1;
TriviaBot_Questions[7]['Points'][938] = 1;
TriviaBot_Questions[7]['Hints'][938] = {};

TriviaBot_Questions[7]['Question'][939] = "Patchwerk is an aggro-sensitive encounter. (True/False)?";
TriviaBot_Questions[7]['Answers'][939] = {"false"};
TriviaBot_Questions[7]['Category'][939] = 1;
TriviaBot_Questions[7]['Points'][939] = 1;
TriviaBot_Questions[7]['Hints'][939] = {};

TriviaBot_Questions[7]['Question'][940] = "Quote: No more play?";
TriviaBot_Questions[7]['Answers'][940] = {"Patchwerk"};
TriviaBot_Questions[7]['Category'][940] = 1;
TriviaBot_Questions[7]['Points'][940] = 1;
TriviaBot_Questions[7]['Hints'][940] = {};

TriviaBot_Questions[7]['Question'][941] = "Quote: _______ want to play.";
TriviaBot_Questions[7]['Answers'][941] = {"Patchwerk"};
TriviaBot_Questions[7]['Category'][941] = 1;
TriviaBot_Questions[7]['Points'][941] = 1;
TriviaBot_Questions[7]['Hints'][941] = {};

TriviaBot_Questions[7]['Question'][942] = "Quote: Kel'Thuzad make _______ his avatar of war!";
TriviaBot_Questions[7]['Answers'][942] = {"Patchwerk"};
TriviaBot_Questions[7]['Category'][942] = 1;
TriviaBot_Questions[7]['Points'][942] = 1;
TriviaBot_Questions[7]['Hints'][942] = {};

TriviaBot_Questions[7]['Question'][943] = "Quote: What happened to... Patch...";
TriviaBot_Questions[7]['Answers'][943] = {"Patchwerk"};
TriviaBot_Questions[7]['Category'][943] = 1;
TriviaBot_Questions[7]['Points'][943] = 1;
TriviaBot_Questions[7]['Hints'][943] = {};

TriviaBot_Questions[7]['Question'][944] = "Grobbulus and _________ drops the tier 3 shoulders.";
TriviaBot_Questions[7]['Answers'][944] = {"Patchwerk"};
TriviaBot_Questions[7]['Category'][944] = 1;
TriviaBot_Questions[7]['Points'][944] = 1;
TriviaBot_Questions[7]['Hints'][944] = {};

TriviaBot_Questions[7]['Question'][945] = "____________ in Naxxramas emits poision clouds which is 10 yards wide and deals a heavy ammount of nature damage if you stand in it. The MT for this boss needs to move steadily but slowly, to avoid them.";
TriviaBot_Questions[7]['Answers'][945] = {"Grobbulus"};
TriviaBot_Questions[7]['Category'][945] = 1;
TriviaBot_Questions[7]['Points'][945] = 1;
TriviaBot_Questions[7]['Hints'][945] = {};

TriviaBot_Questions[7]['Question'][946] = "What boss in Naxxramas is required to be ranged down, whilsts the meele deals with the slimes from this boss, when they spawn? (the meele players also helps out with the ranged dps, when there are no slimes up)";
TriviaBot_Questions[7]['Answers'][946] = {"Grobbulus"};
TriviaBot_Questions[7]['Category'][946] = 1;
TriviaBot_Questions[7]['Points'][946] = 1;
TriviaBot_Questions[7]['Hints'][946] = {};

TriviaBot_Questions[7]['Question'][947] = "What boss in Naxxramas drops The End of Dreams, a mace for druids?";
TriviaBot_Questions[7]['Answers'][947] = {"Grobbulus"};
TriviaBot_Questions[7]['Category'][947] = 1;
TriviaBot_Questions[7]['Points'][947] = 1;
TriviaBot_Questions[7]['Hints'][947] = {};

TriviaBot_Questions[7]['Question'][948] = "What boss in Naxxramas has a ability called 'Decimate', which is needed in order to kill him?";
TriviaBot_Questions[7]['Answers'][948] = {"Gluth"};
TriviaBot_Questions[7]['Category'][948] = 1;
TriviaBot_Questions[7]['Points'][948] = 1;
TriviaBot_Questions[7]['Hints'][948] = {};

TriviaBot_Questions[7]['Question'][949] = "What boss spawns a zombie every 10 seconds, which you need to kite for 105 seconds, together with the others that will spawn in that time?";
TriviaBot_Questions[7]['Answers'][949] = {"Gluth"};
TriviaBot_Questions[7]['Category'][949] = 1;
TriviaBot_Questions[7]['Points'][949] = 1;
TriviaBot_Questions[7]['Hints'][949] = {};

TriviaBot_Questions[7]['Question'][950] = "What boss has Enrage, Mortal Wound, Frenzy, Decimate, Terrifying Roar, and Devour Zombie as abilities, in Naxxramas?";
TriviaBot_Questions[7]['Answers'][950] = {"Gluth"};
TriviaBot_Questions[7]['Category'][950] = 1;
TriviaBot_Questions[7]['Points'][950] = 1;
TriviaBot_Questions[7]['Hints'][950] = {};

TriviaBot_Questions[7]['Question'][951] = "This boss will 'polarize' a raid group, making 50% negativily charged and 50% positively charged. They need to be seperated as fast as possible, otherwise they will deal 2k nature damage to all opposite-charged players within 10 yards.";
TriviaBot_Questions[7]['Answers'][951] = {"Thaddius"};
TriviaBot_Questions[7]['Category'][951] = 1;
TriviaBot_Questions[7]['Points'][951] = 1;
TriviaBot_Questions[7]['Hints'][951] = {};

TriviaBot_Questions[7]['Question'][952] = "If no one is in meele range of this boss, in Naxxramas, this boss will throw 'Ball Lightning' on players, dealing around 8k nature damage on every throw.";
TriviaBot_Questions[7]['Answers'][952] = {"Thaddius"};
TriviaBot_Questions[7]['Category'][952] = 1;
TriviaBot_Questions[7]['Points'][952] = 1;
TriviaBot_Questions[7]['Hints'][952] = {};

TriviaBot_Questions[7]['Question'][953] = "Only by splitting the raid in half can this boss in Naxxramas be killed. Some exceptions can probably be made, but not more then some few.";
TriviaBot_Questions[7]['Answers'][953] = {"Thaddius"};
TriviaBot_Questions[7]['Category'][953] = 1;
TriviaBot_Questions[7]['Points'][953] = 1;
TriviaBot_Questions[7]['Hints'][953] = {};

TriviaBot_Questions[7]['Question'][954] = "Quote: You are too late... I... must... OBEY!";
TriviaBot_Questions[7]['Answers'][954] = {"Thaddius"};
TriviaBot_Questions[7]['Category'][954] = 1;
TriviaBot_Questions[7]['Points'][954] = 1;
TriviaBot_Questions[7]['Hints'][954] = {};

TriviaBot_Questions[7]['Question'][955] = "Quote: Now YOU feel pain!";
TriviaBot_Questions[7]['Answers'][955] = {"Thaddius"};
TriviaBot_Questions[7]['Category'][955] = 1;
TriviaBot_Questions[7]['Points'][955] = 1;
TriviaBot_Questions[7]['Hints'][955] = {};

TriviaBot_Questions[7]['Question'][956] = "Quote: You die now!";
TriviaBot_Questions[7]['Answers'][956] = {"Thaddius"};
TriviaBot_Questions[7]['Category'][956] = 1;
TriviaBot_Questions[7]['Points'][956] = 1;
TriviaBot_Questions[7]['Hints'][956] = {};

TriviaBot_Questions[7]['Question'][957] = "What boss in Naxxramas drops the tier 3 headpieces?";
TriviaBot_Questions[7]['Answers'][957] = {"Thaddius"};
TriviaBot_Questions[7]['Category'][957] = 1;
TriviaBot_Questions[7]['Points'][957] = 1;
TriviaBot_Questions[7]['Hints'][957] = {};

TriviaBot_Questions[7]['Question'][958] = "What boss in Naxxramas casts Frost Breath? The boss will take a deep breath sometimes and breathe a cloud of frost which will slowly fall to the ground and explode, dealing 75k-125k when it touches it, in a 70 yard radius.";
TriviaBot_Questions[7]['Answers'][958] = {"Sapphiron"};
TriviaBot_Questions[7]['Category'][958] = 1;
TriviaBot_Questions[7]['Points'][958] = 1;
TriviaBot_Questions[7]['Hints'][958] = {};

TriviaBot_Questions[7]['Question'][959] = "On which boss in Naxxramas do you need to stay behind iceblocked individuals, to avoid dying?";
TriviaBot_Questions[7]['Answers'][959] = {"Sapphiron"};
TriviaBot_Questions[7]['Category'][959] = 1;
TriviaBot_Questions[7]['Points'][959] = 1;
TriviaBot_Questions[7]['Hints'][959] = {}; 

TriviaBot_Questions[7]['Question'][960] = "Sapphiron in Naxxramas was originally a blue dragon that was protecting Northrend, untill he was killed by _________ and his forces. He was resurrected as a undead shortly after, by Arthas.";
TriviaBot_Questions[7]['Answers'][960] = {"Arthas"};
TriviaBot_Questions[7]['Category'][960] = 1;
TriviaBot_Questions[7]['Points'][960] = 1;
TriviaBot_Questions[7]['Hints'][960] = {};

TriviaBot_Questions[7]['Question'][961] = "What boss drops 'The Face of Death', the best tanking shield availible pre-bc, in Naxxramas?";
TriviaBot_Questions[7]['Answers'][961] = {"Sapphiron"};
TriviaBot_Questions[7]['Category'][961] = 1;
TriviaBot_Questions[7]['Points'][961] = 1;
TriviaBot_Questions[7]['Hints'][961] = {};

TriviaBot_Questions[7]['Question'][962] = "Kel'Thuzad is immune to frost attacks. (True/False)?";
TriviaBot_Questions[7]['Answers'][962] = {"false"};
TriviaBot_Questions[7]['Category'][962] = 1;
TriviaBot_Questions[7]['Points'][962] = 1;
TriviaBot_Questions[7]['Hints'][962] = {};

TriviaBot_Questions[7]['Question'][963] = "The Four Horsemen drops the _______ of T3.";
TriviaBot_Questions[7]['Answers'][963] = {"chests"};
TriviaBot_Questions[7]['Category'][963] = 1;
TriviaBot_Questions[7]['Points'][963] = 1;
TriviaBot_Questions[7]['Hints'][963] = {};

TriviaBot_Questions[7]['Question'][964] = "Where can you find Carrion Spinners?";
TriviaBot_Questions[7]['Answers'][964] = {"Naxxramas",  "Naxx"};
TriviaBot_Questions[7]['Category'][964] = 1;
TriviaBot_Questions[7]['Points'][964] = 1;
TriviaBot_Questions[7]['Hints'][964] = {};

TriviaBot_Questions[7]['Question'][965] = "Quote: Do not rejoice... your victory is a hollow one... for I shall return with powers beyond your imagining!";
TriviaBot_Questions[7]['Answers'][965] = {"Kel'Thuzad"};
TriviaBot_Questions[7]['Category'][965] = 1;
TriviaBot_Questions[7]['Points'][965] = 1;
TriviaBot_Questions[7]['Hints'][965] = {};

TriviaBot_Questions[7]['Question'][966] = "Quote: The dark void awaits you!";
TriviaBot_Questions[7]['Answers'][966] = {"Kel'Thuzad"};
TriviaBot_Questions[7]['Category'][966] = 1;
TriviaBot_Questions[7]['Points'][966] = 1;
TriviaBot_Questions[7]['Hints'][966] = {};

TriviaBot_Questions[7]['Question'][967] = "Quote: Very well... warriors of the frozen wastes, rise up, I command you to fight, kill, and die for your master. Let none survive...";
TriviaBot_Questions[7]['Answers'][967] = {"The lich king",  "Lich king"};
TriviaBot_Questions[7]['Category'][967] = 1;
TriviaBot_Questions[7]['Points'][967] = 1;
TriviaBot_Questions[7]['Hints'][967] = {};

TriviaBot_Questions[7]['Question'][968] = "Quote: Fools, you think yourselves triumphant? You have only taken one step closer to the abyss!";
TriviaBot_Questions[7]['Answers'][968] = {"Kel'Thuzad"};
TriviaBot_Questions[7]['Category'][968] = 1;
TriviaBot_Questions[7]['Points'][968] = 1;
TriviaBot_Questions[7]['Hints'][968] = {};

TriviaBot_Questions[7]['Question'][969] = "What boss drops the rings of T3?";
TriviaBot_Questions[7]['Answers'][969] = {"Kel'Thuzad"};
TriviaBot_Questions[7]['Category'][969] = 1;
TriviaBot_Questions[7]['Points'][969] = 1;
TriviaBot_Questions[7]['Hints'][969] = {};

TriviaBot_Questions[7]['Question'][970] = "What boss in Naxxramas drops Fists of the Unrelenting, a Fury Warrior gauntlet?";
TriviaBot_Questions[7]['Answers'][970] = {"Sapphiron"};
TriviaBot_Questions[7]['Category'][970] = 1;
TriviaBot_Questions[7]['Points'][970] = 1;
TriviaBot_Questions[7]['Hints'][970] = {};

TriviaBot_Questions[7]['Question'][971] = "On stage three of this boss, this boss will summon five Guardians of Icecrown. They are tough and everytime they switch target, they gain a +15% more damage and +10% size buff. These buffs stacks, and remains throughout the encounter.";
TriviaBot_Questions[7]['Answers'][971] = {"Kel'Thuzad"};
TriviaBot_Questions[7]['Category'][971] = 1;
TriviaBot_Questions[7]['Points'][971] = 1;
TriviaBot_Questions[7]['Hints'][971] = {};

TriviaBot_Questions[7]['Question'][972] = "Who drops 'Might of Menethil', in Naxxramas?";
TriviaBot_Questions[7]['Answers'][972] = {"Kel'Thuzad"};
TriviaBot_Questions[7]['Category'][972] = 1;
TriviaBot_Questions[7]['Points'][972] = 1;
TriviaBot_Questions[7]['Hints'][972] = {};

TriviaBot_Questions[7]['Question'][973] = "You can find Archmage Tarsis Kir-Moldir in his tower, in Azshara. (True/False)?";
TriviaBot_Questions[7]['Answers'][973] = {"false"};
TriviaBot_Questions[7]['Category'][973] = 1;
TriviaBot_Questions[7]['Points'][973] = 1;
TriviaBot_Questions[7]['Hints'][973] = {};

TriviaBot_Questions[7]['Question'][974] = "Quote: The end is upon you!";
TriviaBot_Questions[7]['Answers'][974] = {"Kel'Thuzad"};
TriviaBot_Questions[7]['Category'][974] = 1;
TriviaBot_Questions[7]['Points'][974] = 1;
TriviaBot_Questions[7]['Hints'][974] = {};

TriviaBot_Questions[7]['Question'][975] = "What is the Warrior's tier 3 called?";
TriviaBot_Questions[7]['Answers'][975] = {"Dreadnaught"};
TriviaBot_Questions[7]['Category'][975] = 1;
TriviaBot_Questions[7]['Points'][975] = 1;
TriviaBot_Questions[7]['Hints'][975] = {};

TriviaBot_Questions[7]['Question'][976] = "What is the Mage's tier 3 called?";
TriviaBot_Questions[7]['Answers'][976] = {"Frostfire Regalia",  "Frostfire"};
TriviaBot_Questions[7]['Category'][976] = 1;
TriviaBot_Questions[7]['Points'][976] = 1;
TriviaBot_Questions[7]['Hints'][976] = {};

TriviaBot_Questions[7]['Question'][977] = "What is the Priest's tier 3 called?";
TriviaBot_Questions[7]['Answers'][977] = {"Vestments of Faith"};
TriviaBot_Questions[7]['Category'][977] = 1;
TriviaBot_Questions[7]['Points'][977] = 1;
TriviaBot_Questions[7]['Hints'][977] = {};

TriviaBot_Questions[7]['Question'][978] = "What is the Warlock's tier 3 called?";
TriviaBot_Questions[7]['Answers'][978] = {"Plagueheart Raiment",  "Plagueheart"};
TriviaBot_Questions[7]['Category'][978] = 1;
TriviaBot_Questions[7]['Points'][978] = 1;
TriviaBot_Questions[7]['Hints'][978] = {};

TriviaBot_Questions[7]['Question'][979] = "What is the Shaman's tier 3 called?";
TriviaBot_Questions[7]['Answers'][979] = {"The Earthshatterer",  "Earthshatterer"};
TriviaBot_Questions[7]['Category'][979] = 1;
TriviaBot_Questions[7]['Points'][979] = 1;
TriviaBot_Questions[7]['Hints'][979] = {};

TriviaBot_Questions[7]['Question'][980] = "What is the Paladin's tier 3 called?";
TriviaBot_Questions[7]['Answers'][980] = {"Redemption Armor",  "Redemption"};
TriviaBot_Questions[7]['Category'][980] = 1;
TriviaBot_Questions[7]['Points'][980] = 1;
TriviaBot_Questions[7]['Hints'][980] = {};

TriviaBot_Questions[7]['Question'][981] = "What is the Druid's tier 3 called?";
TriviaBot_Questions[7]['Answers'][981] = {"Dreamwalker Raiment", "Dreamwalker"};
TriviaBot_Questions[7]['Category'][981] = 1;
TriviaBot_Questions[7]['Points'][981] = 1;
TriviaBot_Questions[7]['Hints'][981] = {};

TriviaBot_Questions[7]['Question'][982] = "Who drops the 'Misplaced Servo Arm' in Naxxramas? (hint: a term used a lot in instances)";
TriviaBot_Questions[7]['Answers'][982] = {"trash mobs",  "trash"};
TriviaBot_Questions[7]['Category'][982] = 1;
TriviaBot_Questions[7]['Points'][982] = 1;
TriviaBot_Questions[7]['Hints'][982] = {};

TriviaBot_Questions[7]['Question'][983] = "Which bosses in Naxxramas drops the T3 feets? (name both, or one of them)";
TriviaBot_Questions[7]['Answers'][983] = {"Razuvious and Gothik",  "Instructor Razuvious and Gothik the Harvester", "Gothik and Razuvious", "Gothik the Harvester and Instructor Razuvious", "Gothik", "Gothik the Harvester", "Instructor Razuvious", "Razuvious"};
TriviaBot_Questions[7]['Category'][983] = 1;
TriviaBot_Questions[7]['Points'][983] = 1;
TriviaBot_Questions[7]['Hints'][983] = {};

TriviaBot_Questions[7]['Question'][984] = "What boss drops the T3 leggings, in Naxxramas?";
TriviaBot_Questions[7]['Answers'][984] = {"Loatheb"};
TriviaBot_Questions[7]['Category'][984] = 1;
TriviaBot_Questions[7]['Points'][984] = 1;
TriviaBot_Questions[7]['Hints'][984] = {};

TriviaBot_Questions[7]['Question'][985] = "Which bosses in Naxxramas drops the T3 waist? (name both, or one of them)";
TriviaBot_Questions[7]['Answers'][985] = {"Noth and Heigan",  "Noth the Plaguebringer and Heigan the Unclean", "Heigan and Noth", "Heigan the Unclean and Noth the Plaguebringer", "Noth", "Heigan", "Noth the Plaguebringer", "Heigan the Unclean"};
TriviaBot_Questions[7]['Category'][985] = 1;
TriviaBot_Questions[7]['Points'][985] = 1;
TriviaBot_Questions[7]['Hints'][985] = {};

TriviaBot_Questions[7]['Question'][986] = "What boss in Naxxramas drops the T3 headpieces?";
TriviaBot_Questions[7]['Answers'][986] = {"Thaddius"};
TriviaBot_Questions[7]['Category'][986] = 1;
TriviaBot_Questions[7]['Points'][986] = 1;
TriviaBot_Questions[7]['Hints'][986] = {};

TriviaBot_Questions[7]['Question'][987] = "What boss in Naxxramas can drop the Feet/Waist/Shoulder/Wrist of T3?";
TriviaBot_Questions[7]['Answers'][987] = {"Gluth"};
TriviaBot_Questions[7]['Category'][987] = 1;
TriviaBot_Questions[7]['Points'][987] = 1;
TriviaBot_Questions[7]['Hints'][987] = {};

TriviaBot_Questions[7]['Question'][988] = "Which bosses in Naxxramas drops the T3 shoulders? (name both)";
TriviaBot_Questions[7]['Answers'][988] = {"Patchwerk and Grobbulus",  "Grobbulus and Patchwerk"};
TriviaBot_Questions[7]['Category'][988] = 1;
TriviaBot_Questions[7]['Points'][988] = 1;
TriviaBot_Questions[7]['Hints'][988] = {};

TriviaBot_Questions[7]['Question'][989] = "Quote: Your fate is sealed!";
TriviaBot_Questions[7]['Answers'][989] = {"The Twin Emperors",  "Twin Emperors"};
TriviaBot_Questions[7]['Category'][989] = 1;
TriviaBot_Questions[7]['Points'][989] = 1;
TriviaBot_Questions[7]['Hints'][989] = {};

TriviaBot_Questions[7]['Question'][990] = "Quote: Your friends will abandon you.";
TriviaBot_Questions[7]['Answers'][990] = {"C'thun",  "Cthun"};
TriviaBot_Questions[7]['Category'][990] = 1;
TriviaBot_Questions[7]['Points'][990] = 1;
TriviaBot_Questions[7]['Hints'][990] = {};

TriviaBot_Questions[7]['Question'][991] = "Quote: Your heart will explode.";
TriviaBot_Questions[7]['Answers'][991] = {"C'thun",  "Cthun"};
TriviaBot_Questions[7]['Category'][991] = 1;
TriviaBot_Questions[7]['Points'][991] = 1;
TriviaBot_Questions[7]['Hints'][991] = {};

TriviaBot_Questions[7]['Question'][992] = "Quote: Death is close.";
TriviaBot_Questions[7]['Answers'][992] = {"C'thun",  "Cthun"};
TriviaBot_Questions[7]['Category'][992] = 1;
TriviaBot_Questions[7]['Points'][992] = 1;
TriviaBot_Questions[7]['Hints'][992] = {};

TriviaBot_Questions[7]['Question'][993] = "Quote: Tremble mortals, and despair! Doom has come to this world!";
TriviaBot_Questions[7]['Answers'][993] = {"Archimonde"};
TriviaBot_Questions[7]['Category'][993] = 1;
TriviaBot_Questions[7]['Points'][993] = 1;
TriviaBot_Questions[7]['Hints'][993] = {};

TriviaBot_Questions[7]['Question'][994] = "Quote: This world will burn!";
TriviaBot_Questions[7]['Answers'][994] = {"Archimonde"};
TriviaBot_Questions[7]['Category'][994] = 1;
TriviaBot_Questions[7]['Points'][994] = 1;
TriviaBot_Questions[7]['Hints'][994] = {};

TriviaBot_Questions[7]['Question'][995] = "Quote: I am the coming of the end ";
TriviaBot_Questions[7]['Answers'][995] = {"Archimonde"};
TriviaBot_Questions[7]['Category'][995] = 1;
TriviaBot_Questions[7]['Points'][995] = 1;
TriviaBot_Questions[7]['Hints'][995] = {};

TriviaBot_Questions[7]['Question'][996] = "Quote: Abandon all hope! The legion has returned to finish what was begun so many years ago. This time there will be no escape!";
TriviaBot_Questions[7]['Answers'][996] = {"Azgalor"};
TriviaBot_Questions[7]['Category'][996] = 1;
TriviaBot_Questions[7]['Points'][996] = 1;
TriviaBot_Questions[7]['Hints'][996] = {};

TriviaBot_Questions[7]['Question'][997] = "Quote: Cry for mercy! Your meaningless lives will soon be forfeit.";
TriviaBot_Questions[7]['Answers'][997] = {"Kaz'rogal"};
TriviaBot_Questions[7]['Category'][997] = 1;
TriviaBot_Questions[7]['Points'][997] = 1;
TriviaBot_Questions[7]['Hints'][997] = {};

TriviaBot_Questions[7]['Question'][998] = "Quote: You are defenders of a doomed world. Flee here and perhaps you will prolong your pathetic lives.";
TriviaBot_Questions[7]['Answers'][998] = {"Anetheron"};
TriviaBot_Questions[7]['Category'][998] = 1;
TriviaBot_Questions[7]['Points'][998] = 1;
TriviaBot_Questions[7]['Hints'][998] = {};

TriviaBot_Questions[7]['Question'][999] = "Quote: Succumb to the icy chill... of death!";
TriviaBot_Questions[7]['Answers'][999] = {"Rage Winterchill"};
TriviaBot_Questions[7]['Category'][999] = 1;
TriviaBot_Questions[7]['Points'][999] = 1;
TriviaBot_Questions[7]['Hints'][999] = {};

TriviaBot_Questions[7]['Question'][1000] = "Quote: Ashes to ashes, dust to dust.";
TriviaBot_Questions[7]['Answers'][1000] = {"Rage Winterchill"};
TriviaBot_Questions[7]['Category'][1000] = 1;
TriviaBot_Questions[7]['Points'][1000] = 1;
TriviaBot_Questions[7]['Hints'][1000] = {};

TriviaBot_Questions[7]['Question'][1001] = "Quote: My patience has run out! Die, die!";
TriviaBot_Questions[7]['Answers'][1001] = {"High Warlord Naj'entus",  "High Warlord Najentus", "Najentus"};
TriviaBot_Questions[7]['Category'][1001] = 1;
TriviaBot_Questions[7]['Points'][1001] = 1;
TriviaBot_Questions[7]['Hints'][1001] = {};

TriviaBot_Questions[7]['Question'][1002] = "Quote: YOU WILL SHOW THE PROPER RESPECT!";
TriviaBot_Questions[7]['Answers'][1002] = {"Teron Gorefiend"};
TriviaBot_Questions[7]['Category'][1002] = 1;
TriviaBot_Questions[7]['Points'][1002] = 1;
TriviaBot_Questions[7]['Hints'][1002] = {};

TriviaBot_Questions[7]['Question'][1003] = "Quote: I'll rip the meat from your bones!";
TriviaBot_Questions[7]['Answers'][1003] = {"Gurtogg Bloodboil"};
TriviaBot_Questions[7]['Category'][1003] = 1;
TriviaBot_Questions[7]['Points'][1003] = 1;
TriviaBot_Questions[7]['Hints'][1003] = {};

TriviaBot_Questions[7]['Question'][1004] = "Guess the Zone: Dreamfoil, and mountain silersage can be gathered here, as a herbalist. The fire elementals in this region is a popular grinding place for fire essences. Stegodons, gorillas, and bloodpetals are some of the local inhabitants.";
TriviaBot_Questions[7]['Answers'][1004] = {"Un'Goro",  "Un'Goro Crater"};
TriviaBot_Questions[7]['Category'][1004] = 1;
TriviaBot_Questions[7]['Points'][1004] = 1;
TriviaBot_Questions[7]['Hints'][1004] = {};

TriviaBot_Questions[7]['Question'][1005] = "Guess the Zone: Both the Steamwheedle Cartel and the night elfs has established a base in this region. The zone is rich on thorium veins for miners. The zone has quite a wildlife aswell, with its blue dragons, bears, and owls.";
TriviaBot_Questions[7]['Answers'][1005] = {"Winterspring"};
TriviaBot_Questions[7]['Category'][1005] = 1;
TriviaBot_Questions[7]['Points'][1005] = 1;
TriviaBot_Questions[7]['Hints'][1005] = {};

TriviaBot_Questions[7]['Question'][1006] = "Guess the Zone: The Eye of Shadow was grinded quite often in this zone, before the expansion came. As Alliance you can obtain the 'Reins of the Winterspring Frostsaber' in this zone.";
TriviaBot_Questions[7]['Answers'][1006] = {"Winterspring"};
TriviaBot_Questions[7]['Category'][1006] = 1;
TriviaBot_Questions[7]['Points'][1006] = 1;
TriviaBot_Questions[7]['Hints'][1006] = {};

TriviaBot_Questions[7]['Question'][1007] = "What is the highest speed you can obtain with a flying mount?";
TriviaBot_Questions[7]['Answers'][1007] = {"492%",  "492"};
TriviaBot_Questions[7]['Category'][1007] = 1;
TriviaBot_Questions[7]['Points'][1007] = 1;
TriviaBot_Questions[7]['Hints'][1007] = {};

TriviaBot_Questions[7]['Question'][1008] = "The epic frost resistance gear for Warriors is called _________. Guilds usually create them for Naxxramas.";
TriviaBot_Questions[7]['Answers'][1008] = {"Icebane"};
TriviaBot_Questions[7]['Category'][1008] = 1;
TriviaBot_Questions[7]['Points'][1008] = 1;
TriviaBot_Questions[7]['Hints'][1008] = {};

TriviaBot_Questions[7]['Question'][1009] = "How many people can you enter Tempest Keep with?";
TriviaBot_Questions[7]['Answers'][1009] = {"25"};
TriviaBot_Questions[7]['Category'][1009] = 1;
TriviaBot_Questions[7]['Points'][1009] = 1;
TriviaBot_Questions[7]['Hints'][1009] = {};

TriviaBot_Questions[7]['Question'][1010] = "How many people can you enter Karazhan with?";
TriviaBot_Questions[7]['Answers'][1010] = {"10",  "ten"};
TriviaBot_Questions[7]['Category'][1010] = 1;
TriviaBot_Questions[7]['Points'][1010] = 1;
TriviaBot_Questions[7]['Hints'][580] = {};

TriviaBot_Questions[7]['Question'][1011] = "The famous '______ on a stick' is widely known by nearly everyone in World of Warcaft.";
TriviaBot_Questions[7]['Answers'][1011] = {"Carrot"};
TriviaBot_Questions[7]['Category'][1011] = 1;
TriviaBot_Questions[7]['Points'][1011] = 1;
TriviaBot_Questions[7]['Hints'][1011] = {};

TriviaBot_Questions[7]['Question'][1012] = "The rare trinket that is obtainable by doing quests with the Netherwing faction, is called '________ Whip'.";
TriviaBot_Questions[7]['Answers'][1012] = {"Skybreaker"};
TriviaBot_Questions[7]['Category'][1012] = 1;
TriviaBot_Questions[7]['Points'][1012] = 1;
TriviaBot_Questions[7]['Hints'][1012] = {};

TriviaBot_Questions[7]['Question'][1013] = "Where can you find Lucifron?";
TriviaBot_Questions[7]['Answers'][1013] = {"Molten Core",  "MC"};
TriviaBot_Questions[7]['Category'][1013] = 1;
TriviaBot_Questions[7]['Points'][1013] = 1;
TriviaBot_Questions[7]['Hints'][1013] = {};

TriviaBot_Questions[7]['Question'][1014] = "Where can you find Magmadar?";
TriviaBot_Questions[7]['Answers'][1014] = {"Molten Core",  "MC"};
TriviaBot_Questions[7]['Category'][1014] = 1;
TriviaBot_Questions[7]['Points'][1014] = 1;
TriviaBot_Questions[7]['Hints'][1014] = {};

TriviaBot_Questions[7]['Question'][1015] = "Where can you find Gehennas?";
TriviaBot_Questions[7]['Answers'][1015] = {"Molten Core",  "MC"};
TriviaBot_Questions[7]['Category'][1015] = 1;
TriviaBot_Questions[7]['Points'][1015] = 1;
TriviaBot_Questions[7]['Hints'][1015] = {};

TriviaBot_Questions[7]['Question'][1016] = "Where is 'Edge of Madness'?";
TriviaBot_Questions[7]['Answers'][1016] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][1016] = 1;
TriviaBot_Questions[7]['Points'][1016] = 1;
TriviaBot_Questions[7]['Hints'][1016] = {};

TriviaBot_Questions[7]['Question'][1017] = "Where can you find Shazzrah?";
TriviaBot_Questions[7]['Answers'][1017] = {"Molten Core",  "MC"};
TriviaBot_Questions[7]['Category'][1017] = 1;
TriviaBot_Questions[7]['Points'][1017] = 1;
TriviaBot_Questions[7]['Hints'][1017] = {};

TriviaBot_Questions[7]['Question'][1018] = "Where can you find Golemagg the Incinerator?";
TriviaBot_Questions[7]['Answers'][1018] = {"Molten Core",  "MC"};
TriviaBot_Questions[7]['Category'][1018] = 1;
TriviaBot_Questions[7]['Points'][1018] = 1;
TriviaBot_Questions[7]['Hints'][1018] = {};

TriviaBot_Questions[7]['Question'][1019] = "Where can you find Sulfuron Harbringer?";
TriviaBot_Questions[7]['Answers'][1019] = {"Molten Core",  "MC"};
TriviaBot_Questions[7]['Category'][1019] = 1;
TriviaBot_Questions[7]['Points'][1019] = 1;
TriviaBot_Questions[7]['Hints'][1019] = {};

TriviaBot_Questions[7]['Question'][1020] = "Where can you find Majordomo Executus?";
TriviaBot_Questions[7]['Answers'][1020] = {"Molten Core",  "MC"};
TriviaBot_Questions[7]['Category'][1020] = 1;
TriviaBot_Questions[7]['Points'][1020] = 1;
TriviaBot_Questions[7]['Hints'][1020] = {};

TriviaBot_Questions[7]['Question'][1021] = "Where can you find the Old God's Lieutenant, Ragnaros?";
TriviaBot_Questions[7]['Answers'][1021] = {"Molten Core",  "MC"};
TriviaBot_Questions[7]['Category'][1021] = 1;
TriviaBot_Questions[7]['Points'][1021] = 1;
TriviaBot_Questions[7]['Hints'][1021] = {};

TriviaBot_Questions[7]['Question'][1022] = "Where can you find Bloodlord Mandokir?";
TriviaBot_Questions[7]['Answers'][1022] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][1022] = 1;
TriviaBot_Questions[7]['Points'][1022] = 1;
TriviaBot_Questions[7]['Hints'][1022] = {};

TriviaBot_Questions[7]['Question'][1023] = "Where can you find Gahz'ranka?";
TriviaBot_Questions[7]['Answers'][1023] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][1023] = 1;
TriviaBot_Questions[7]['Points'][1023] = 1;
TriviaBot_Questions[7]['Hints'][1023] = {};

TriviaBot_Questions[7]['Question'][1024] = "Where can you find Thekal?";
TriviaBot_Questions[7]['Answers'][1024] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][1024] = 1;
TriviaBot_Questions[7]['Points'][1024] = 1;
TriviaBot_Questions[7]['Hints'][1024] = {};

TriviaBot_Questions[7]['Question'][1025] = "Where can you find Venoxis?";
TriviaBot_Questions[7]['Answers'][1025] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][1025] = 1;
TriviaBot_Questions[7]['Points'][1025] = 1;
TriviaBot_Questions[7]['Hints'][1025] = {};

TriviaBot_Questions[7]['Question'][1026] = "Where can you find Arlokk?";
TriviaBot_Questions[7]['Answers'][1026] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][1026] = 1;
TriviaBot_Questions[7]['Points'][1026] = 1;
TriviaBot_Questions[7]['Hints'][1026] = {};

TriviaBot_Questions[7]['Question'][1027] = "Where can you find Jeklik?";
TriviaBot_Questions[7]['Answers'][1027] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][1027] = 1;
TriviaBot_Questions[7]['Points'][1027] = 1;
TriviaBot_Questions[7]['Hints'][1027] = {};

TriviaBot_Questions[7]['Question'][1028] = "Where can you find Mar'li?";
TriviaBot_Questions[7]['Answers'][1028] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][1028] = 1;
TriviaBot_Questions[7]['Points'][1028] = 1;
TriviaBot_Questions[7]['Hints'][1028] = {};

TriviaBot_Questions[7]['Question'][1029] = "Where can you find Jin'do the Hexxer?";
TriviaBot_Questions[7]['Answers'][1029] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][1029] = 1;
TriviaBot_Questions[7]['Points'][1029] = 1;
TriviaBot_Questions[7]['Hints'][1029] = {};

TriviaBot_Questions[7]['Question'][1030] = "Quote: You can have anything you desire... for a price.";
TriviaBot_Questions[7]['Answers'][1030] = {"Reliquary of Souls",  "Reliquary", "Essence of Souls"};
TriviaBot_Questions[7]['Category'][1030] = 1;
TriviaBot_Questions[7]['Points'][1030] = 1;
TriviaBot_Questions[7]['Hints'][1030] = {};

TriviaBot_Questions[7]['Question'][1031] = "Quote: So, business... or pleasure?";
TriviaBot_Questions[7]['Answers'][1031] = {"Mother Shahraz",  "Shahraz"};
TriviaBot_Questions[7]['Category'][1031] = 1;
TriviaBot_Questions[7]['Points'][1031] = 1;
TriviaBot_Questions[7]['Hints'][1031] = {};

TriviaBot_Questions[7]['Question'][1032] = "Quote: You're not cut out for this!";
TriviaBot_Questions[7]['Answers'][1032] = {"Illidari Council"};
TriviaBot_Questions[7]['Category'][1032] = 1;
TriviaBot_Questions[7]['Points'][1032] = 1;
TriviaBot_Questions[7]['Hints'][1032] = {};

TriviaBot_Questions[7]['Question'][1033] = "Quote: Behold the flames of Azzinoth!";
TriviaBot_Questions[7]['Answers'][1033] = {"Illidan Stormrage"};
TriviaBot_Questions[7]['Category'][1033] = 1;
TriviaBot_Questions[7]['Points'][1033] = 1;
TriviaBot_Questions[7]['Hints'][1033] = {};

TriviaBot_Questions[7]['Question'][1034] = "Naxxramas will become a 25man in the expansion. (True/False)?";
TriviaBot_Questions[7]['Answers'][1034] = {"true"};
TriviaBot_Questions[7]['Category'][1034] = 1;
TriviaBot_Questions[7]['Points'][1034] = 1;
TriviaBot_Questions[7]['Hints'][1034] = {};

TriviaBot_Questions[7]['Question'][1035] = "The nerubian spiderlords are followers of the __________ in Northrend.";
TriviaBot_Questions[7]['Answers'][1035] = {"Old Gods"};
TriviaBot_Questions[7]['Category'][1035] = 1;
TriviaBot_Questions[7]['Points'][1035] = 1;
TriviaBot_Questions[7]['Hints'][1035] = {};

TriviaBot_Questions[7]['Question'][1036] = "Quote: Shhh... it will all be over soon.";
TriviaBot_Questions[7]['Answers'][1036] = {"Anub'Rekhan" };
TriviaBot_Questions[7]['Category'][1036] = 1;
TriviaBot_Questions[7]['Points'][1036] = 1;
TriviaBot_Questions[7]['Hints'][1036] = {};

TriviaBot_Questions[7]['Question'][1037] = "Where can you find Hakkar the Soulflayer?";
TriviaBot_Questions[7]['Answers'][1037] = {"Zul'Gurub",  "ZG", "Zul Gurub"};
TriviaBot_Questions[7]['Category'][1037] = 1;
TriviaBot_Questions[7]['Points'][1037] = 1;
TriviaBot_Questions[7]['Hints'][1037] = {};