# ZooKeeper
<img src="http://i.gyazo.com/1dd2c766ccd26910f2e786e5a05da544.gif"/>
<img src="http://i.imgur.com/au0X2ML.png"/>

ZooKeeper is a TBC/WotLK AddOn. It can be used to overcome the ignore list size limitation or simply as another way to mute players, the whole with gorilla sound effects.
   
You can capture/release apes from the target frame, the chat frame and the Ape List accessible on Social (Friends tab). More settings will be added later.

## How to install
- Click on the green button "Clone or download"
- Select Download ZIP
- Extract this .zip file under 'Your_WoW_Directory\Interface\AddOns\\'
- Remove the "-master" from the folder name