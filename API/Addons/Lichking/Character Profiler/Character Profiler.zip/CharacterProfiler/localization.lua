RPGOCP_SAVE_TEXT		= "save";
RPGOCP_SAVE_TOOLTIP	= "Click to export your Character Profile";

local myLocale=GetLocale();
if(myLocale=="deDE") then
	RPGOCP_SAVE_TEXT		= "save";
elseif(myLocale=="frFR") then
	RPGOCP_SAVE_TEXT		= "save";
elseif(myLocale=="esES") then
	RPGOCP_SAVE_TEXT		= "save";
end
