Yata - Yet Another Totem Addon
==============================

What is Yata?
-------------

As its name says, Yata is an addon for Shaman!

Features
--------

- Popout bar
- Integration with the Blizzard multicast spells (e.g Call of the Elements)
- Totem sets
- Keybindings directly to totems or spell groups
- Weapon imbues bar
- Timers on the frame or bars
- Destroy totem / Totemic Call