local L = LibStub('AceLocale-3.0'):GetLocale('ProfessionsVault')
local addonName = L["ProfessionsVault"]
ProfessionsVault = LibStub("AceAddon-3.0"):NewAddon(addonName)
local addon = ProfessionsVault 
local AceGUI = LibStub("AceGUI-3.0")
local LDB = LibStub("LibDataBroker-1.1")
local minimapIcon = LibStub("LibDBIcon-1.0")
PV_svnrev = {}
PV_svnrev["ProfessionsVault.lua"] = tonumber(("$Revision: 62 $"):match("%d+"))
local DB_VERSION_MAJOR = 1
local DB_VERSION_MINOR = 2

local defaults = {
  profile = {
    debug = false, -- for addon debugging
    autoclose = false, -- close win after using a link
    tooltips = true, -- show tooltips in the ProfessionsVault window
    locked = false, -- frame lock
    recipetooltips = true, -- enhance recipe tooltips
    ahcolor = true,
    selfdata = true,
    altdata = true,
    otherdata = false,
    factiondata = false,
    pos = {
      height = 432,
      width  = 510,
      left   = 350,
      top    = 823,
    },
    treestatus = {
      treewidth = 230,
    },
    minimap = {
      hide = false,
    },
  }
}

local headerfont = GameFontHighlightLarge
local bodyfont = GameFontHighlightLarge
local profpages = false -- show a page for each profession
local activateontree = true
local ttwrapwidth = 50 -- tooltip wrap width, 0 for auto
local gamerankmax = 450
local usehashes = true
local einstein = L["All Recipes"]
local locale = GetLocale()
if locale == "enGB" then locale = "enUS" end

local COLOR_KNOWN = { r = 0.3, g = 0.3, b = 1.0 }
local COLOR_UNKWN = { r = 1.0, g = 0.7, b = 0.0 }
local COLOR_LEARN = { r = 0.3, g = 1.0, b = 0.3 }
local COLOR_SKILL = { r = 1.0, g = 1.0, b = 0.1 }
local COLOR_DUNNO = { r = 1.0, g = 0.1, b = 0.1 }

BINDING_NAME_PROFESSIONSVAULT = L["Show/Hide the ProfessionsVault window"]
BINDING_HEADER_PROFESSIONSVAULT = "ProfessionsVault"

local primaryProf = { 
        [2259] = 44, -- Alchemy
	[2018] = 87, -- Blacksmithing
	[7411] = 51, -- Enchanting
	[4036] = 51, -- Engineering
	[9134] = 0, -- Herbalism
	[45357] = 73, -- Inscription 
	[25229] = 84, -- Jewelcrafting 
	[2108] = 89, -- Leatherworking
	[2575] = 0, -- Mining
	[2656] = 1, -- Smelting
	[3908] = 73, -- Tailoring
}
local secondaryProf = { 
	[78670] = 1, -- Archaeology 
	[2550] = 31, -- Cooking
	[3273] = 6, -- First Aid 
	[7620] = 0, -- Fishing
}
local function translateIDs(t) 
  local r = {}
  for k,v in pairs(t) do
    local name, _, icon = GetSpellInfo(k)
    if not name then
      debug("Failed to find spellID "..k)
    else
      r[name] = {}
      r[name].icon = icon
      r[name].spellid = k
      r[name].patlen = v
    end
  end
  return r
end
primaryProf = translateIDs(primaryProf)
secondaryProf = translateIDs(secondaryProf)
local allProf = {}
local allProfSorted = {}
do 
  for p,v in pairs(primaryProf) do allProf[p]=v ; table.insert(allProfSorted, p) end
  table.sort(allProfSorted)
  local tmp = {}
  for p,v in pairs(secondaryProf) do allProf[p]=v ; table.insert(tmp, p)end
  table.sort(tmp)
  for _,v in ipairs(tmp) do table.insert(allProfSorted, v) end
  --myprint(allProfSorted)
end

local LFaction = {
  Alliance = FACTION_ALLIANCE,
  Horde = FACTION_HORDE
}

local DB, DBc, settings
local charName
local optionsFrame

local function chatMsg(msg)
     DEFAULT_CHAT_FRAME:AddMessage("\124cFF00FF00"..addonName.."\124r: "..msg)
end
local function debug(msg)
  if settings.debug then
     DEFAULT_CHAT_FRAME:AddMessage("\124cFFFF0000"..addonName.."\124r: "..msg)
  end
end

local function myOptions() 
return {
  type = "group",
  args = {
    debug = {
      name = L["Debug"],
      desc = L["Toggle debugging output"],
      type = "toggle",
      guiHidden = true,
      set = function(info,val) settings.debug = val end,
      get = function(info) return settings.debug end
    },
    reset = {
      name = L["Reset"],
      desc = L["Reset the database"],
      type = "execute",
      order = 120,
      func = function() addon:Reset(); end,
    },
    dump = {
      name = L["Dump"],
      desc = L["Dump the database to chat window"],
      type = "execute",
      guiHidden = true,
      func = function() addon:Dump()  end,
    },
    oheader = {
      name = L["General Options"],
      type = "header",
      cmdHidden = true,
      order = 0,
    },
    ttheader = {
      name = L["Actions"],
      type = "header",
      cmdHidden = true,
      order = 100,
    },
    aheader = {
      name = L["Recipe Options"],
      type = "header",
      cmdHidden = true,
      order = 40,
    },
    show = {
      name = L["Show"],
      desc = L["Show/Hide the ProfessionsVault window"],
      type = "execute",
      order = 110,
      func = function() addon:ToggleWindow()  end,
    },
    kheader = {
      name = L["Keybinding"],
      type = "header",
      cmdHidden = true,
      order = 200,
    },
    togglebind = {
      desc = L["Bind a key to toggle the ProfessionsVault window"],
      type = "keybinding",
      name = L["Show/Hide the ProfessionsVault window"],
      cmdHidden = true,
      order = 210,
      width = double,
      set = function(info,val) 
         local b1, b2 = GetBindingKey("PROFESSIONSVAULT")
         if b1 then SetBinding(b1) end
         if b2 then SetBinding(b2) end
         SetBinding(val, "PROFESSIONSVAULT") 
	 SaveBindings(GetCurrentBindingSet())
      end,
      get = function(info) return GetBindingKey("PROFESSIONSVAULT") end
    },
    config = {
      name = L["Config"],
      desc = L["Show the ProfessionsVault configuration window"],
      type = "execute",
      guiHidden = true,
      func = function() addon:Config()  end,
    },
    autoclose = {
      name = L["Autoclose"],
      desc = L["Automatically close the ProfessionsVault window when opening a profession"],
      type = "toggle",
      order = 10,
      set = function(info,val) settings.autoclose = val end,
      get = function(info) return settings.autoclose end
    },
    tooltips = {
      name = L["Tooltips"],
      desc = L["Show tooltips in the ProfessionsVault window"],
      type = "toggle",
      order = 30,
      set = function(info,val) settings.tooltips = val end,
      get = function(info) return settings.tooltips end
    },
    recipetooltips = {
      name = L["Recipe Tooltips"],
      desc = L["Enhance recipe tooltips with ProfessionsVault character data"],
      type = "toggle",
      order = 45,
      set = function(info,val) settings.recipetooltips = val ; addon:RefreshTooltips() end,
      get = function(info) return settings.recipetooltips end
    },
    ahcolor = {
      name = L["AH coloring"],
      desc = L["Color recipes in the AH window with ProfessionsVault character data"],
      type = "toggle",
      order = 46,
      set = function(info,val) settings.ahcolor = val ; addon:RefreshTooltips() end,
      get = function(info) return settings.ahcolor end
    },
    recipeself = {
      name = L["Include self"],
      desc = L["Include profession data from self"],
      type = "toggle",
      order = 47,
      disabled = function() return not settings.recipetooltips and not settings.ahcolor end,
      set = function(info,val) settings.selfdata = val ; addon:RefreshTooltips() end,
      get = function(info) return settings.selfdata end
    },
    recipealts = {
      name = L["Include alts"],
      desc = L["Include profession data from alts"],
      type = "toggle",
      order = 48,
      disabled = function() return not settings.recipetooltips and not settings.ahcolor end,
      set = function(info,val) settings.altdata = val ; addon:RefreshTooltips() end,
      get = function(info) return settings.altdata end
    },
    recipeothers = {
      name = L["Include others"],
      desc = L["Include profession data from non-alts"],
      type = "toggle",
      order = 49,
      disabled = function() return not settings.recipetooltips and not settings.ahcolor end,
      set = function(info,val) settings.otherdata = val ; addon:RefreshTooltips() end,
      get = function(info) return settings.otherdata end
    },
    recipefaction = {
      name = L["Include opposite faction"],
      desc = L["Include profession data from opposite faction"],
      type = "toggle",
      order = 50,
      disabled = function() return not settings.recipetooltips and not settings.ahcolor end,
      set = function(info,val) settings.factiondata = val ; addon:RefreshTooltips() end,
      get = function(info) return settings.factiondata end
    },
    minimap = {
      name = L["Minimap icon"],
      desc = L["Show minimap icon"],
      type = "toggle",
      order = 30,
      get = function(info) return not settings.minimap.hide end,
      set = function(info,val) 
                  settings.minimap.hide = not val
		  if settings.minimap.hide then
		    minimapIcon:Hide(addonName)
		  else
		    minimapIcon:Show(addonName)
		  end
            end
    },
  }
} 
end

function addon:RefreshChar()
  DB.chars[charName] = DB.chars[charName] or {}
  DBc = DB.chars[charName]
  DBc.data = DBc.data or {}
  DBc.data.name = charName
  DBc.data.faction = UnitFactionGroup("player")
  DBc.data.level = UnitLevel("player")
  DBc.data.class = UnitClass("player")
  DBc.data.scanned = DBc.data.scanned or false
  if DBc.data.alt == nil then
    DBc.data.alt = true
  end
end

function addon:RefreshConfig()
  debug("RefreshConfig")
  charName = UnitName("player")
  DB = self.db.realm
  DB.chars = DB.chars or {}

  settings = addon.db.profile
  addon.settings = settings
  settings.vermaj = settings.vermaj or DB_VERSION_MAJOR
  settings.vermin = settings.vermin or DB_VERSION_MINOR

  if settings.debug then
    PV = addon
  end

  addon:RefreshChar()
end

local function resetSettings() 
  debug("resetSettings")
  local ishown = InterfaceOptionsFrame:IsShown()
  local wshown = addon.gui and true
  if wshown then
    addon:ToggleWindow()
  end
  if ishown then
    InterfaceOptionsFrame:Hide();
  end
  for k,v in pairs(addon.db.profile) do
    addon.db.profile[k] = nil
  end
  for k,v in pairs(defaults.profile) do
    addon.db.profile[k] = v
  end
  addon:RefreshConfig()
  addon:AddEinstein()
  if ishown then
    InterfaceOptionsFrame_OpenToCategory(optionsFrame)
  end
  if wshown then
    addon:ToggleWindow()
  end
end

function addon:OnInitialize()
  self.db = LibStub("AceDB-3.0"):New("ProfessionsVaultDB", defaults)
  --LibStub("AceConfigRegistry-3.0"):ValidateOptionsTable(myOptions(), addonName)
  LibStub("AceConfig-3.0"):RegisterOptionsTable(addonName, myOptions(), {L["professionsvault"], L["pv"]})
  optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions(addonName)
  optionsFrame.default = resetSettings
  LibStub("AceEvent-3.0"):Embed(addon)
  settings = addon.db.profile

  debug("OnInitialize")

  addon:build_tables()

  self.db.RegisterCallback(self, "OnProfileChanged", "RefreshConfig")
  self.db.RegisterCallback(self, "OnProfileCopied", "RefreshConfig")
  self.db.RegisterCallback(self, "OnProfileReset", "RefreshConfig")
  self.db.RegisterCallback(self, "OnDatabaseReset", "RefreshConfig")
  self:RefreshConfig()
end

function addon:SetupVersion()
   local svnrev = 0
   PV_svnrev["X-Build"] = tonumber((GetAddOnMetadata("ProfessionsVault", "X-Build") or ""):match("%d+"))
   PV_svnrev["X-Revision"] = tonumber((GetAddOnMetadata("ProfessionsVault", "X-Revision") or ""):match("%d+"))
   for _,v in pairs(PV_svnrev) do -- determine highest file revision
     if v and v > svnrev then
       svnrev = v
     end
   end
   ProfessionsVault.revision = svnrev

   PV_svnrev["X-Curse-Packaged-Version"] = GetAddOnMetadata("ProfessionsVault", "X-Curse-Packaged-Version")
   PV_svnrev["Version"] = GetAddOnMetadata("ProfessionsVault", "Version")
   ProfessionsVault.version = PV_svnrev["X-Curse-Packaged-Version"] or PV_svnrev["Version"] or "@"
   if string.find(ProfessionsVault.version, "@") then -- dev copy uses "@.project-version.@"
      ProfessionsVault.version = "r"..svnrev
   end
end
local function PV_ShowTooltip(self,...)
        if addon.settings.recipetooltips or (addon.settings.ahcolor and self == addon.scantt) then
                addon:ShowTooltip(self)
        end
end
local function PV_ShowItemRefTooltip(cleanlink, link, button, frame)
        if addon.settings.recipetooltips and
	   (string.find(link,"\124Hitem:",1,true) or string.find(link,"\124Henchant:",1,true)) then
                addon:ShowTooltip(ItemRefTooltip)
        end
	if link and string.find(link, "\124Htrade:",1,true) then -- opened a tradeskill UI link
	   if addon.lastTSL == "ignore" then
	     addon.lastTSL = nil
	   else
	     addon.lastTSL = link
	   end
	   debug("Set addon.lastTSL = "..(addon.lastTSL or "nil"))
	   addon:UpdateTrade(false) 
	end
end
local function PV_AuctionScroll(...)
        if addon.settings.ahcolor then
	        addon:SetAuctionColors()
        end
end

function addon:ADDON_LOADED()
        if IsAddOnLoaded("Blizzard_AuctionUI") then
          hooksecurefunc("AuctionFrameBrowse_Update", PV_AuctionScroll)
        end
        if IsAddOnLoaded("Auc-Advanced") and not addon.AuctioneerAdv then
                if AucAdvanced.Settings.GetSetting("util.compactui.activated") then
                        debug("Auctioneer Advanced CompactUI detected")
                        addon.AuctioneerAdv = true
                end
        end
end

function addon:OnEnable()
  debug("OnEnable")

  self:SetupVersion()

  addon:AddEinstein()

  self:RegisterEvent("TRADE_SKILL_SHOW")
  self:RegisterEvent("ADDON_LOADED")
  addon:ADDON_LOADED() -- in case we are loaded late

  if true then
    local tthooks = {
	"SetAuctionItem", "SetAuctionSellItem", 
	"SetHyperlink", 
	"SetBagItem", 
	"SetTradePlayerItem",
	"SetLootItem", "SetLootRollItem", 
	"SetMerchantItem", "SetBuybackItem", 
	"SetSendMailItem", "SetInboxItem", 	
    }
    for _,hook in pairs(tthooks) do
      hooksecurefunc(GameTooltip, hook, PV_ShowTooltip)
    end
    hooksecurefunc(addon.scantt, "SetAuctionItem", PV_ShowTooltip)
    if AtlasLootTooltip then
      hooksecurefunc(AtlasLootTooltip, "SetHyperlink", PV_ShowTooltip)
      if AtlasLootTooltip.HookScript then -- all this just to help it resize properly
        local resizedammit = function () 
	  AtlasLootTooltip:SetSize(AtlasLootTooltip:GetSize())
	  AtlasLootTooltip:Show()
	end
        AtlasLootTooltip:HookScript("OnTooltipSetItem", resizedammit)
        AtlasLootTooltip:HookScript("OnTooltipSetSpell", resizedammit)
        AtlasLootTooltip:HookScript("OnSizeChanged", resizedammit)
        AtlasLootTooltip:HookScript("OnUpdate", resizedammit)
      end
    end
    hooksecurefunc("SetItemRef", PV_ShowItemRefTooltip)
    hooksecurefunc("GetGuildMemberRecipes", function () addon.lastTSL = nil end)
  else
    GameTooltip:HookScript("OnTooltipSetItem", PV_ShowTooltip)
    ItemRefTooltip:HookScript("OnTooltipSetItem", PV_ShowTooltip)
    if AtlasLootTooltip and AtlasLootTooltip.HookScript then
      AtlasLootTooltip:HookScript("OnTooltipSetItem", PV_ShowTooltip)
    end
  end


  --if not DBc.data.scanned then -- no professions registered on this toon
  --  addon:ScanProfessions()
  --end

  local PVLDB = LDB:NewDataObject(addonName, {
        type = "launcher",
        label = addonName,
        --icon = "Interface\\Icons\\spell_shadow_mindtwisting",
        --icon = "Interface\\Icons\\inv_misc_enggizmos_17",
        icon = "Interface\\Icons\\inv_scroll_03",
        OnClick = function(self, button)
                if button == "RightButton" then
			addon:Config()
                else
                        addon:ToggleWindow()
                end
        end,
        OnTooltipShow = function(tooltip)
                if tooltip and tooltip.AddLine and settings.tooltips then
                        tooltip:SetText(addonName.." "..ProfessionsVault.version)
                        tooltip:AddLine("|cffff8040"..L["Left Click"].."|r "..L["to toggle the window"])
                        tooltip:AddLine("|cffff8040"..L["Right Click"].."|r "..L["for config"])
                        tooltip:Show()
                end
        end,
  })

  settings.minimap = settings.minimap or {}
  minimapIcon:Register(addonName, PVLDB, settings.minimap)
  if settings.minimap.hide then
    minimapIcon:Hide(addonName)
  else
    minimapIcon:Show(addonName)
  end

end

function addon:TRADE_SKILL_SHOW()
  debug("TRADE_SKILL_SHOW")
  addon:UpdateTrade()
  if TradeSkillLinkNameButton and not addon.tslnhook then
    TradeSkillLinkNameButton:HookScript("OnUpdate", function(self) 
      local _, _, rm = GetTradeSkillLine()
      local isLinked, name = IsTradeSkillLinked()
      if rm == 0 or (isLinked and name == charName) then
        self:Hide()
        debug(self:GetName()..":Hide()")
      end
    end) 
    addon.tslnhook = true
  end
  if TradeSkillRankFrame and not addon.tsrfhook then
    TradeSkillRankFrame:HookScript("OnUpdate", function(self) 
      local name, r, rm = GetTradeSkillLine()
      local isLinked, name = IsTradeSkillLinked()
      if rm == 0 or (isLinked and name == charName) then
        self:Hide()
        debug(self:GetName()..":Hide()")
      end
    end) 
    addon.tsrfhook = true
  end
end

function addon:SaveButton()
  local button = addon.savebutton
  if not button then
     button = CreateFrame("Button",addonName.."SaveButton",TradeSkillFrame,"UIPanelButtonTemplate")
     button:SetText(L["Save"])
     if TradeSkillCancelButton then
        button:SetSize(TradeSkillCancelButton:GetSize())
     else
        button:SetSize(80,22)
     end
     button:SetScript("OnClick", function (self,button,down) addon:UpdateTrade(true) end)
     button:SetScript("OnEnter", function (self) 
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOMRIGHT");
        GameTooltip:SetText(L["Save this trade skill to ProfessionsVault"]);
        GameTooltip:Show()
     end)
     button:SetScript("OnLeave", function (self) GameTooltip:Hide() end)
     addon.savebutton = button
  end
  return button
end

function addon:UpdateTrade(force)
  addon:SaveButton():Hide()
  if IsTradeSkillGuild() then return end
  local pname, rank, rankmax = GetTradeSkillLine()
  local link = GetTradeSkillListLink()
  local linked, cname = IsTradeSkillLinked()
  local guid, guidname, class, race, spellid -- for linked only
  if not linked then
    cname = charName
  else
    link = addon.lastTSL
    if link then
      spellid, guid = string.match(link,"\124Htrade:(%d+):%d+:%d+:(%x+):")
    end
    if spellid and guid then 
      class,_,_,race,_,guidname = GetPlayerInfoByGUID(guid)
      local guidspell = GetSpellInfo(spellid)
      if guidname ~= cname or guidspell ~= pname then force = false end
    else
      force = false 
    end
    if link and guidname and guidname ~= charName then
      addon:SaveButton():SetPoint("BOTTOMLEFT",5,5)
      addon:SaveButton():Show()
    end
    if not force then
      debug("Ignoring "..(cname or "NIL").."'s "..pname);
      return
    end
  end
  if (pname and pname ~= "UNKNOWN") then
    if not link then
      if pname == GetSpellInfo(2575) then -- Rename mining to smelting
        pname = GetSpellInfo(2656)
      end
      chatMsg(format(L["Warning: Tradeskill %s has no link available to be used."]..L["This is a known Blizzard bug."],pname));
    end

    if not DB.chars[cname] then
      DB.chars[cname] = {}
    end
    local dbc = DB.chars[cname]
    if linked then
      dbc.data = dbc.data or {}
      dbc.data.name = cname
      local allianceRace = {
         ["Human"]=true, ["Dwarf"]=true, ["Gnome"]=true, ["NightElf"]=true, ["Draenei"]=true, ["Worgen"]=true
      }
      dbc.data.class = class
      dbc.data.faction = UnitFactionGroup(cname) -- may fail
                         or (race and ((allianceRace[race] and "Alliance") or "Horde"))
      local level = UnitLevel(cname) -- may fail
      if level > 0 then
        dbc.data.level = level
      end
    end

    local changestr = nil
    if not dbc[pname] then
      changestr = L["Saved %s's %s"]
    elseif dbc[pname].link ~= link then
      changestr = L["Saved %s's %s"]
      --changestr = L["Updated %s's %s"]
    end
    dbc[pname] = {}
    dbc[pname].link = link
    dbc[pname].rank = rank
    dbc[pname].rankmax = rankmax
    dbc[pname].lastupdate = time()
    debug("Saved "..cname.."'s "..pname);
    if changestr then
      chatMsg(format(changestr,cname,pname));
    end
    if linked then
      if addon.gui then
         addon:ToggleWindow()
         addon:ToggleWindow()
      end
    end
    addon:RefreshTooltips()
  end
end

-- traversal function for character table
local cnext_sorted_names = {}
local function cnext(t,i)
   -- return them in reverse order
   if #cnext_sorted_names == 0 then 
     return nil
   else
      local n = cnext_sorted_names[#cnext_sorted_names]
      table.remove(cnext_sorted_names, #cnext_sorted_names)
      return n, t[n]
   end
end
local function cpairs(t)
  cnext_sorted_names = {}
  for n,_ in pairs(t) do
    table.insert(cnext_sorted_names, n)
  end
  table.sort(cnext_sorted_names, function (a,b) return b == charName or (a ~= charName and a > b) end)
  --myprint(cnext_sorted_names)
  return cnext, t, nil
end

function addon:Dump()
  for cname,dbc in cpairs(DB.chars) do
    local data = dbc.data or {}
    chatMsg("-=- "..cname.." "..(data.level or "").." "..
            ((data.faction and LFaction[data.faction]) or "")..
	    " "..(data.class or "").." -=-")
    for _,pname in ipairs(allProfSorted) do
      if (dbc[pname]) then
        local pinfo = dbc[pname]
        local rank = pinfo.rank or "??"
        local rankmax = pinfo.rankmax or "??"
	local link = pinfo.link or "["..pname.."]"
        chatMsg(" "..link.."   ("..rank.."/"..rankmax..")")
      end
    end
  end
end

local function OnClose(widget)
  debug("OnClose")
  widget.frame:SetFrameStrata(widget.acegui_strata)
  addon:clearEscapeHandler(widget)
  addon:decustomizeLayout(widget)
  if settings.locked then
    addon:unlockWidget(addon.gui)
  end
  AceGUI:Release(widget)
  addon.gui = nil
end

local function cleanlink(link)
  local res = string.match(link,"|H(trade:[^|]+)|h")
  debug("cleanlink("..link..") => ".. res)
  return res
end

local function ActivateLink(cname,pname,link)
  debug("ActivateLink: "..cname.." "..(pname or ""))
  if GetMouseButtonClicked() == "RightButton" then
     addon:ShowDropdown(cname, pname)
  elseif IsShiftKeyDown() then
    local activeEditBox = ChatEdit_GetActiveWindow();
    if activeEditBox then
      if not pname then
        if cname == einstein then return end
        ChatEdit_InsertLink(cname)
        return
      elseif not link then
        chatMsg(format(L["Warning: Tradeskill %s has no link available to be used."]..L["This is a known Blizzard bug."],pname));
        return
      elseif (not ChatEdit_InsertLink(link) ) then
         debug("Failed to add tradeskill link to "..activeEditBox:GetName())
	 return
      end
    elseif not pname and cname ~= einstein then
        ChatFrame_SendTell(cname)
        return
    else
      return
    end
  else
    if not pname then
      return
    elseif cname == charName then
      CastSpellByName(pname)
    else
      local name, rank, rankmax = GetTradeSkillLine()
      local linked, linkedName = IsTradeSkillLinked()
      if linked and (linkedName == cname or (linkedName == charName and cname == einstein))
         and name and name == pname then -- already open so close it
        CloseTradeSkill()
      elseif not link then
        chatMsg(format(L["Warning: Tradeskill %s has no link available to be used."]..L["This is a known Blizzard bug."],pname));
      else -- open it (undocumented API - sshhh)
	if (cname == einstein) then 
	  addon.lastTSL = "ignore" 
	else
	  addon.lastTSL = nil
	end
        SetItemRef(cleanlink(link),link,"LeftButton",ChatFrame1)
      end
    end
  end
  if settings.autoclose then
    addon.gui:Hide()
  end
end

function addon:ScanProfessions()
  debug("ScanProfessions")
  CloseTradeSkill()
  DB.chars[charName] = {}
  addon:RefreshChar()
  local gotone = false
  for p in pairs(allProf) do
    if (allProf[p].patlen > 0) then
      CastSpellByName(p) 
      CloseTradeSkill()
      if DBc[p] then
        gotone = true
      end
    end
  end
  if gotone then
    chatMsg(L["Profession Scan complete!"])
    DBc.data.scanned = true
  else
    chatMsg(L["No professions detected! (try again later?)"])
  end
  if addon.gui then
    addon:ToggleWindow()
    addon:ToggleWindow()
  end
end

local function ProfTooltip(frame, cname, pname, pinfo)
   if not frame then
     debug("Missing frame on ProfTooltip")
     return
   end
   addon.gui:SetStatusText(cname.." / "..pname)
   if not settings.tooltips then 
     return
   end
   --GameTooltip:SetOwner(frame, "ANCHOR_CURSOR"); 
   GameTooltip:SetOwner(frame, "ANCHOR_BOTTOMRIGHT"); 
   if cname == einstein then
     GameTooltip:SetText(pname.." ("..einstein..")"); 
   else
     GameTooltip:SetText(pname.." ("..pinfo.rank.." / "..pinfo.rankmax..")"); 
   end

   if pinfo.lastupdate then
     GameTooltip:AddLine("|cff00ff00"..L["Last Scan"]..": "..date(nil,pinfo.lastupdate).."|r")
   end
   GameTooltip:AddLine("|cffff8040"..L["Left Click"].."|r "..L["to open"])
   GameTooltip:AddLine("|cffff8040"..L["Shift Left Click"].."|r "..L["to link in chat"])
   GameTooltip:AddLine("|cffff8040"..L["Right Click"].."|r "..L["for menu"])
   GameTooltip:Show() 
end

local function ProfIcon(cname,pname,pinfo)
  local icon = AceGUI:Create("Icon")
  icon:SetImage(allProf[pname].icon)
  --icon:SetImageSize(50,50)
  --icon:SetLabel("")
  icon.frame:RegisterForClicks("AnyDown") -- cheat to get right-clicks too
  icon:SetCallback("OnClick", function(button) ActivateLink(cname,pname,pinfo.link) end)
  icon:SetCallback("OnEnter", function(button) ProfTooltip(button.frame, cname, pname, pinfo) end)
  icon:SetCallback("OnLeave", function(button) addon.gui:SetStatusText(""); GameTooltip:Hide() end)
  return icon
end

local function MakeButton(text, fn) 
  local button = AceGUI:Create("Button")
  button:SetText(text)
  button:SetWidth(175)
  button:SetCallback("OnClick",fn)
  return button
end

local function parsePath(path)
  local cname, pname = ("\001"):split(path)
  return cname, pname
end

local function OnSelect(widget, event, value)
  local cname, pname = parsePath(value)
  if pname then
    debug("OnSelect: "..cname.." / "..pname)
    addon.gui:SetStatusText(cname.." / "..pname)
    settings.treepath = { cname , pname }
  else
    cname = value
    debug("OnSelect: "..cname)
    addon.gui:SetStatusText(cname)
    settings.treepath = { cname }
  end
  local dbc = DB.chars[cname]
  if not pname or not settings.profpages then
    widget:ReleaseChildren()
    widget:SetLayout("List") 
    -- body for a character
    local label = AceGUI:Create("Label")
    if cname == einstein then
      label:SetText(einstein.."\n")
    else
      label:SetText(format(L["%s's Professions"],cname).."\n")
    end
    label:SetFullWidth(true)
    label:SetFontObject(headerfont)
    widget:AddChild(label)
    if cname == charName and (not dbc.data or not dbc.data.scanned) then
      widget:AddChild(MakeButton(L["Scan My Professions"], function () addon:ScanProfessions(); end))
      return
    end
    --[[
    local altcheck = AceGUI:Create("CheckBox")
    altcheck:SetValue(dbc.data.alt == true)
    altcheck:SetType("checkbox")
    altcheck:SetDescription(L["Is an alt"])
    altcheck:SetCallback("OnValueChanged", function (val) dbc.data.alt = val end)
    widget:AddChild(altcheck)]]
    local scroller = AceGUI:Create("ScrollFrame")
    scroller:SetLayout("List")
    scroller:SetFullHeight(true)
    scroller:SetFullWidth(true)
    widget:AddChild(scroller)
    for i=1,2 do
      local label = AceGUI:Create("Label")
      label:SetText(i==1 and L["Primary"]..":\n" or L["Secondary"]..":\n")
      label:SetFontObject(bodyfont)
      scroller:AddChild(label)
      local body = AceGUI:Create("SimpleGroup")
      body:SetLayout("Flow")
      body:SetFullWidth(true)
      --body:SetAutoAdjustHeight(true)
      for pname in pairs((i==1 and primaryProf) or (i==2 and secondaryProf)) do
        if (dbc[pname]) then
	  local pinfo = dbc[pname]
          body:AddChild(ProfIcon(cname,pname,pinfo))
	end
      end
      scroller:AddChild(body)
    end
    return
  end

 
  local pinfo = DB.chars[cname][pname]

  widget:ReleaseChildren()
  widget:SetLayout("List") 
  
  -- body for a particular profession
  local header = AceGUI:Create("SimpleGroup")
  header:SetFullWidth(true)
  header:SetLayout("Flow") 
  header:AddChild(ProfIcon(cname,pname,pinfo))
  local label = AceGUI:Create("Label")
  label:SetText(cname.."'s "..pname.."\n")
  label:SetFontObject(headerfont)
  header:AddChild(label)
  widget:AddChild(header)

  local body = AceGUI:Create("SimpleGroup")
  body:SetFullWidth(true)
  local skill = AceGUI:Create("Label")
  skill:SetText("Skill level: "..pinfo.rank.." / "..pinfo.rankmax.."\n")
  skill:SetFontObject(bodyfont)
  skill:SetFullWidth(true)
  body:AddChild(skill)
  local link = AceGUI:Create("InteractiveLabel")
  link:SetCallback("OnClick", function(button) ActivateLink(cname,pname,pinfo.link) end)
  link:SetText("Skill link: "..pinfo.link)
  link:SetFontObject(bodyfont)
  link:SetFullWidth(true)
  body:AddChild(link)
  widget:AddChild(body)
end
----------------------------------------------------------------------------------
-- AceGUI hacks --

-- hack-around for the fact AceGUI:Frame is too stupid to resize its title area to fit the text
function addon:fixTitle() 
  local tit = nil
  for _,v in pairs({ addon.gui.frame:GetRegions() }) do 
     local w = v:GetWidth()
     if w > 90 and w < 110 then 
        v:SetWidth(200) 
	tit = v
	break;
     end 
  end
 if false then 
  -- adjust the drag handle - this part should work but doesnt
  for _,v in pairs({ addon.gui.frame:GetChildren() }) do 
     local  w = v:GetWidth()
     local  h = v:GetHeight()
     if w > 95 and w < 105 and h > 35 and h < 45 then 
        v:SetAllPoints(tit) 
        v:SetWidth(400) 
     end 
  end
 end
end 

-- hack-around for the fact AceGUI doesnt allow frame locking
function addon:lockWidget(widget) 
  widget.lockinfo = {}
  for _,v in pairs({ widget.frame:GetChildren() }) do 
     local md = v:GetScript("OnMouseDown")
     local mu = v:GetScript("OnMouseUp")
     if md and mu then
       table.insert(widget.lockinfo,{frame=v,OnMouseDown=md,OnMouseUp=mu})
       v:SetScript("OnMouseDown",function()end)
       v:SetScript("OnMouseUp",function()end)
     end
  end
end
function addon:unlockWidget(widget) 
  if widget.lockinfo then
    for _,li in pairs(widget.lockinfo) do 
      li.frame:SetScript("OnMouseDown",li.OnMouseDown)
      li.frame:SetScript("OnMouseUp",li.OnMouseUp)
    end
    widget.lockinfo = nil
  end
end

-- hack to hook the escape key for closing the window
function addon:setEscapeHandler(widget, fn)
  widget.origOnKeyDown = widget.frame:GetScript("OnKeyDown")
  widget.frame:SetScript("OnKeyDown", function(self,key) 
        if key == "ESCAPE" then 
	   fn()
	elseif widget.origOnKeyDown then
	   widget.origOnKeyDown(self,key)
	end 
     end)
  widget.frame:EnableKeyboard(true)
  widget.frame:SetPropagateKeyboardInput(true)
end
function addon:clearEscapeHandler(widget)
  widget.frame:SetScript("OnKeyDown", widget.origOnKeyDown)
  widget.frame:EnableKeyboard(false)
  widget.frame:SetPropagateKeyboardInput(false)
end
-- allow custom layout of children
function addon:customizeLayout(widget, fn, destructor)
  widget.origLayoutFinished = widget.LayoutFinished
  widget.customizationDestructor = destructor
  widget.LayoutFinished = function () if widget.origLayoutFinished then widget.origLayoutFinished() end ; fn(); end
end
function addon:decustomizeLayout(widget)
  if widget.LayoutFinished then
    widget.LayoutFinished = widget.origLayoutFinished
    widget.origLayoutFinished = nil
    if widget.customizationDestructor then
       widget.customizationDestructor()
       widget.customizationDestructor = nil
    end
  end
end
----------------------------------------------------------------------------------
function addon:MakeHeaderButton(img, imgH, clickfn)
  local button = AceGUI:Create("InteractiveLabel")

  button:SetImage(img)
  button:SetHighlight(imgH)
  button:SetImageSize(32,32)
  button:SetWidth(32)
  button:SetHeight(32)

  button:SetCallback("OnClick", clickfn)
  --button.frame:SetFrameStrata("MEDIUM")
  button.frame:SetParent(addon.gui.frame)
  button.frame:SetFrameLevel(1000)
  button.frame:Show()

  return button
end

local icon_close = "Interface\\Buttons\\UI-Panel-MinimizeButton-Up"
local icon_closeH = "Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight"
local icon_unlocked  = "Interface\\AddOns\\ProfessionsVault\\images\\LockButton-Unlocked"
local icon_locked  =   "Interface\\AddOns\\ProfessionsVault\\images\\LockButton-Locked"
function addon:ToggleLock(button)
  if settings.locked then
    debug("frame unlocked");
    settings.locked = false
    addon:unlockWidget(addon.gui)
    button:SetImage(icon_unlocked)
    button:SetHighlight(icon_closeH)
  else
    debug("frame locked");
    settings.locked = true
    addon:lockWidget(addon.gui)
    button:SetImage(icon_locked)
    button:SetHighlight(icon_closeH)
  end
end

function addon:CreateWindow()
  if addon.gui then
    return
  end
  local f = AceGUI:Create("Frame")
  addon.gui = f
  f:SetTitle(L["ProfessionsVault"].." "..ProfessionsVault.version)
  addon:fixTitle()
  f:SetCallback("OnClose", OnClose)
  f:SetLayout("Flow")
  f.frame:SetClampedToScreen(true)
  settings.pos = settings.pos or {}
  f:SetStatusTable(settings.pos)
  f:SetAutoAdjustHeight(true)
  f.acegui_strata = f.frame:GetFrameStrata()
  f.frame:SetFrameStrata("MEDIUM")

  --f:AddChild(MakeButton(L["Profession Pane"], function () ToggleSpellBook(BOOKTYPE_PROFESSION); end)) 
  f:AddChild(MakeButton(L["Scan My Professions"], function () addon:ScanProfessions(); end))
  f:AddChild(MakeButton(L["Config"], function () addon:Config(); end))

  local closeButton = addon:MakeHeaderButton(icon_close, icon_closeH,
                          function() addon:ToggleWindow() end)
  --f:AddChild(closeButton)
  local lockButton = addon:MakeHeaderButton(icon_unlocked, icon_closeH,
                          function(self) addon:ToggleLock(self) end)
  --f:AddChild(lockButton)
  addon:customizeLayout(f, function() 
     closeButton.frame:ClearAllPoints(); 
     closeButton:SetPoint("TOPRIGHT",f.frame,-5,-5)
     lockButton.frame:ClearAllPoints(); 
     lockButton:SetPoint("TOPRIGHT",closeButton.frame,"TOPLEFT",8,0)
  end, function() AceGUI:Release(closeButton); AceGUI:Release(lockButton) end)

  if settings.locked then
    settings.locked = false
    addon:ToggleLock(lockButton)
  end

  addon:setEscapeHandler(f, function() addon:ToggleWindow() end)

  local treedata = {}
  for cname,dbc in cpairs(DB.chars) do
    local ct = { value = cname, text = cname, visible = true,
                 icon = "Interface\\GossipFrame\\ActiveQuestIcon",
                 children = {} }
    --print(cname)
    if cname == einstein then
      ct.icon = "Interface\\Icons\\inv_misc_book_07"
    elseif dbc.data and dbc.data.faction and dbc.data.faction == "Horde" then
      ct.icon = "Interface\\TargetingFrame\\UI-PVP-Horde"
    elseif dbc.data and dbc.data.faction and dbc.data.faction == "Alliance" then
      ct.icon = "Interface\\TargetingFrame\\UI-PVP-Alliance"
    end
    for _,pname in ipairs(allProfSorted) do
      if (dbc[pname]) then
        local pinfo = dbc[pname]
        table.insert(ct.children, { value = pname, icon = allProf[pname].icon, visible = true,
                                      text = pname..
				      (cname == einstein and " ("..einstein..")" or
				      " ("..pinfo.rank.." / "..pinfo.rankmax..")") })
      end
    end
    if #ct.children > 0 or cname == charName then 
      table.insert(treedata, ct)
    end
  end
  if settings.debug and myprint then
    myprint(treedata)
  end

  local treebox = AceGUI:Create("SimpleGroup")
  treebox:SetLayout("Fill")
  treebox:SetFullWidth(true)
  treebox:SetFullHeight(true)
  f:AddChild(treebox)

  local tree = AceGUI:Create("TreeGroup")
  tree:SetFullWidth(true)
  treebox:AddChild(tree)
  tree:SetFullHeight(true)
  tree:SetFullHeight(false)
  tree:SetFullHeight(true)
  addon.tree = tree
  tree:SetAutoAdjustHeight(false)
  tree:SetTree(treedata)
  tree:SetCallback("OnGroupSelected", OnSelect)
  tree:SetCallback("OnClick", function (widget, event, path,...)
        local cname, pname = parsePath(path)
  	if activateontree then
  	  ActivateLink(cname,pname,pname and DB.chars[cname][pname].link)
  	end  
  end)
  tree:SetCallback("OnButtonEnter", function(button,event,path,frame) 
                   local cname, pname = parsePath(path)
		   addon.gui:SetStatusText(cname)
		   if pname then
                     ProfTooltip(frame, cname, pname, DB.chars[cname][pname]) 
		   elseif cname and settings.tooltips then
		     local data = DB.chars[cname].data
                     GameTooltip:SetOwner(frame, "ANCHOR_BOTTOMRIGHT");
                     GameTooltip:SetText(cname);
                     local text = ""
                     for _,stat in ipairs({"level","faction","class"}) do
		       local val = data[stat]
		       if stat == faction and val then val = LFaction[val] end
                       if data and val then
                          text = text..val.." "
                       end
                     end
                     if #text then
                        GameTooltip:AddLine(text)
                     end
                     GameTooltip:Show()
		   end
		   end)
  tree:SetCallback("OnButtonLeave", function() GameTooltip:Hide() end)
  tree:EnableButtonTooltips(false)
  settings.treestatus = settings.treestatus or {}
  tree:SetStatusTable(settings.treestatus)
  if settings.treepath then
    local oldact = activateontree
    activateontree = false
    tree:SelectByPath(unpack(settings.treepath))
    activateontree = oldact
  end
end

function addon:ToggleWindow()
  debug("ToggleWindow")

  if addon.gui then
    addon.gui:Hide()
  else
    addon:CreateWindow()
    addon.gui.frame:Raise()
  end
end

function addon:Reset() 
  if addon.gui then
    addon:ToggleWindow()
  end
  StaticPopup_Show("PROFESSIONSVAULT_RESET")
end

local function ResetConfirmed()
  addon.db:ResetDB() -- triggers RefreshConfig
  chatMsg(L["Reset complete."]); 
end

StaticPopupDialogs["PROFESSIONSVAULT_RESET"] = {
  text = L["Are you sure you want to reset the ProfessionsVault database and wipe all data?"],
  button1 = OKAY,
  button2 = CANCEL,
  OnAccept = ResetConfirmed,
  timeout = 0,
  whileDead = true,
  hideOnEscape = true,
}

function addon:Config() 
  if optionsFrame then
    if ( InterfaceOptionsFrame:IsShown() ) then
      InterfaceOptionsFrame:Hide();
    else
      InterfaceOptionsFrame_OpenToCategory(optionsFrame)
    end
  end
end
----------------------------------------------------------------------------
-- Testing code
----------------------------------------------------------------------------
function addon:fakeLink(profName, guid, spellid, rank, rankmax, patlen) 
  spellid = spellid or allProf[profName].spellid
  patlen = patlen or allProf[profName].patlen
  guid = guid or UnitGUID("player")
  rankmax = rankmax or gamerankmax
  rank = rank or rankmax
  guid = string.gsub(guid,"0x","")
  local known = string.rep("/",patlen)
  local link = 
         "\124cffffd000"..
         "\124Htrade:"..spellid..":"..rank..":"..rankmax..":"..
          guid..":"..known.."\124h["..profName.."]\124h"..
         "\124r"
  --print(i..": "..link)
  return link
end
function addon:fakeLinkScan(profName, guid, spellid, rank, rankmax) 
  CastSpellByName("Cooking")
  CloseTradeSkill()
  for i=0,200 do
    local link = addon:fakeLink(profName, guid, spellid, rank, rankmax, i)
    SetItemRef(cleanlink(link),link,"LeftButton",ChatFrame1)
    if GetTradeSkillLine() and IsTradeSkillLinked() then
      debug("Success at "..spellid.." "..i.." "..GetSpellInfo(spellid).." "..link)
      --printlink(link)
      break
    end
  end
end

function PV_linkscan(min,max) 
  local known = {}
  for k,v in pairs(allProf) do
      known[v.spellid] = k
  end
  for i=min,max do
    if known[i] and false then
      print("Skipping "..i.." "..known[i])
    else
      if i%100 == 0 then
        print("testing "..i)
      end
      addon:fakeLinkScan("linkscan",i)
    end
  end
  print("Scan complete: "..min..".."..max)
end

function addon:AddEinstein() -- a toon that knows all the patterns
  DB.chars[einstein] = {}
  local DBe = DB.chars[einstein]
  DBe.data = {}
  DBe.data.name = name
  --DBe.data.faction = UnitFactionGroup("player")
  --DBe.data.level = 1
  --DBe.data.class = UnitClass("player")
  DBe.data.scanned = true
  DBe.data.alt = false

  for _,pname in ipairs(allProfSorted) do
    if (allProf[pname].patlen > 1) then
      DBe[pname] = {
	rank = gamerankmax,
	rankmax = gamerankmax,
	link = addon:fakeLink(pname, nil, nil, 0, 0),
      }
    end
  end

end
----------------------------------------------------------------------------
-- Link manipulation
----------------------------------------------------------------------------
local function table_invert(t)
  local ret = {}
  for k,v in pairs(t) do
    if ret[v] then
      debug(format("Duplicate value %s in table_invert",v))
    end
    ret[v] = k
  end
  return ret
end

-- conjunctions used in transmute names that need to be normalized away
local xmute_conjunctions = {}
local xmute_token = strtrim(string.lower(L["Transmute"]))
if locale == "enUS" then 
  xmute_conjunctions = { " to " }
elseif locale == "deDE" then 
  xmute_conjunctions = { " zu ", " in " }
elseif locale == "esES" or locale == "esMX" then 
  xmute_conjunctions = { " a ", " en " }
elseif locale == "frFR" then 
  xmute_conjunctions = { " en ", " du ", " de ", " de la ", " de l'", " d'" }
elseif locale == "ruRU" then 
  xmute_conjunctions = { " \208\178 " }
else 
  xmute_conjunctions = { }
end
local figurine_token = strtrim(string.lower(L["Figurine"]))

local function normalize(spellname) -- normalize minor differences in spellnames
  if not spellname then return nil end
  spellname = string.lower(spellname)
  spellname = string.gsub(spellname, "%p", " ") -- punctuation
  if string.find(spellname, xmute_token) then -- Transmute spelling is a mess
    spellname = string.gsub(spellname, xmute_token, "") 
    for _,conj in pairs(xmute_conjunctions) do
      spellname = string.gsub(spellname, conj, " ")
    end
    spellname = xmute_token.." "..spellname
  end
  if locale == "frFR" then
    spellname = string.gsub(spellname, "enchantement", "ench")
  end
  spellname = string.gsub(spellname, figurine_token, " ") -- old-world figurines drop the token TODO: need more for ruRU
  spellname = string.gsub(spellname, "%s+", " ") -- extra space
  spellname = strtrim(spellname) -- extra space
  --if string.find(spellname, xmute_token) then   print(spellname) end
  return spellname
end

function addon:hash(str) -- a dumbed-down crc32
  str = tostring(str)
  local count = string.len(str)
  local val = tonumber(count)
  for i = 1,count do
    local byte = tonumber(string.byte(str,i))
    val = bit.bxor(bit.lshift(val,8), bit.lshift(bit.bxor(bit.rshift(val,24), byte),i%3))
  end
  return tonumber(val)
end

function addon:build_tables() 
  local start = GetTime()
  PV_code_to_bits = {}
  PV_bits_to_code = {}
  local bits = 0
  for charid=string.byte("A"),string.byte("Z") do
    PV_code_to_bits[string.char(charid)] = bits
    bits = bits + 1
  end
  for charid=string.byte("a"),string.byte("z") do
    PV_code_to_bits[string.char(charid)] = bits
    bits = bits + 1
  end
  for charid=string.byte("0"),string.byte("9") do
    PV_code_to_bits[string.char(charid)] = bits
    bits = bits + 1
  end
  PV_code_to_bits["+"] = bits
  bits = bits + 1
  PV_code_to_bits["/"] = bits
  bits = bits + 1
  assert(bits == 64)
  PV_bits_to_code = table_invert(PV_code_to_bits)

  addon.ttcache = addon.ttcache or {}

  PV_Exceptions_StoI = table_invert(PV_Exceptions_ItoS)


  -- localize the pattern database
  do
  if PV_PatDB and not PV_PatDBL then
    local md = PV_Data_VersionInfo
    assert(md)
    debug("Loading PV_PatDB v"..md.DBversion.."-"..md.DBrevision.." for client "..
            md.clientversion.."-"..md.clientbuild)
    local clientversion, clientbuild = GetBuildInfo()
    if clientversion ~= md.clientversion then
      local msg = L["WARNING: This version of ProfessionsVault was compiled for a different version of WoW (%s) than you are running (%s). Some features may be broken. Please download an update from %s"]
      msg = format(msg, format("%s-%d", md.clientversion, md.clientbuild),
                        format("%s-%d", clientversion, clientbuild),
                        "http://www.wowace.com/addons/professionsvault/")
      chatMsg(msg)
    end
    PV_PatDBL = {}
    for profname, pinfo in pairs(allProf) do
      local pid = pinfo.spellid
      if PV_PatDB[pid] then
        local parr = {}
	for spellid, bitidx in pairs(PV_PatDB[pid]) do
	  local spellname = GetSpellInfo(spellid)
	  spellname = normalize(spellname)
          if spellid == 0 then	  
	    parr[0] = bitidx -- metadata
	  elseif not spellname then
	    debug("ERROR: spellid not found: "..spellid)
	  else
	    local parridx
	    if PV_Exceptions_StoI[spellid] then
	      parridx = PV_Exceptions_StoI[spellid] 
	      if parr[parridx] then
	          chatMsg("ERROR: Duplicate exception: "..spellname.."  ("..spellid..")")
	      end
	    elseif usehashes then
	      parridx = addon:hash(spellname) 
	      if parr[parridx] then
	          chatMsg("ERROR: Duplicate spell or hash coll: "..spellname.."  ("..parridx..")")
	      end
	    else
	       parridx = spellname 
	       if parr[spellname] then
	          chatMsg("ERROR: Duplicate spellname: "..spellname)
	       end
	    end
	    parr[parridx] = bitidx
	  end
	end -- for spellid
	PV_PatDBL[pid] = parr
      end
    end -- for prof
    PV_PatDB = nil
    end
  end

  debug(format("build_tables: %.3f s", (GetTime()-start)/1000.0))
  collectgarbage("collect")
end 

function addon:link_bit(link, bitidx)
  local chunkid = math.floor(bitidx / 6)
  local chunkbit = bitidx % 6
  local databits = string.match(link, "\124Htrade:%d+:%d+:%d+:%x+:([^:]+)\124h")
  assert(chunkid <= #databits)
  local chunk = string.sub(databits, chunkid+1, chunkid+1)
  --print("chunk="..chunk)
  local bits = PV_code_to_bits[chunk]
  --print("bits="..bits)
  return bit.band(2^chunkbit, bits) > 0
end

function addon:singlebit_link(profName, bitidx, rank, rankmax, guid)
  local spellid = allProf[profName].spellid
  local patlen = allProf[profName].patlen
  guid = guid or UnitGUID("player")
  guid = string.gsub(guid,"0x","")
  rankmax = rankmax or 525
  rank = rank or rankmax
  local chunkid = math.floor(bitidx / 6)
  local chunkbit = bitidx % 6

  local bits = string.rep(PV_bits_to_code[0],chunkid) ..
               PV_bits_to_code[2^chunkbit] ..
               string.rep(PV_bits_to_code[0],patlen-chunkid-1)

  local link = "\124Htrade:"..spellid..":"..rank..":"..rankmax..":"..
          guid..":"..bits.."\124h["..profName.."]\124h"

  return link
end

function addon:populate_database(profName)
  CastSpellByName("Cooking")
  -- expand all window settings
  SetTradeSkillInvSlotFilter(0);
  SetTradeSkillSubClassFilter(0);
  SetTradeSkillItemNameFilter("");
  TradeSkillOnlyShowMakeable(false);
  TradeSkillOnlyShowSkillUps(false);
  CloseTradeSkill()

  local bitlen = allProf[profName].patlen*6
  local profid = allProf[profName].spellid
  local patcnt = 0
  local errcnt = 0
  local patDB = {}
  patDB[0] = {}
  local header = patDB[0]
  header.name = profName
  header.bitlen = bitlen
  header.scandate = date()
  header.version, header.build = GetBuildInfo()
  print("Scanning "..bitlen.." "..profName.." bits")
  for bitidx = 0,bitlen-1 do
    local link = addon:singlebit_link(profName, bitidx)
    --printlink(link)
    SetItemRef(cleanlink(link),link,"LeftButton",ChatFrame1)
    if GetTradeSkillLine() and IsTradeSkillLinked() then
      local num = GetNumTradeSkills()
      local idx = GetFirstTradeSkill()
      local skillName, skillType = GetTradeSkillInfo(idx)
      if (num == 0 or not skillName or not skillType or skillType == "header") then
        print(link.." bit "..bitidx..": empty bit")
      else
        local itemlink = GetTradeSkillItemLink(idx)
        local recipelink = GetTradeSkillRecipeLink(idx)

        local spellid = string.match(recipelink, "\124Henchant:(%d+)\124h")
        print(link.." bit "..bitidx..": "..skillName.." "..spellid.." "..itemlink.." "..recipelink)
        patcnt = patcnt + 1
        spellid = tonumber(spellid)
        if patDB[spellid] and patDB[spellid] ~= bitidx then
          print("ERROR: duplicate bit found at bit "..bitidx)
          errcnt = errcnt + 1 
        else
          patDB[spellid] = bitidx
        end
      end
    end
  end
  header["patcnt"] = patcnt
  print("Scanned "..bitlen.." "..profName.." bits, saved "..patcnt.." patterns, "..errcnt.." errors.")
 
  addon.db.global.patDB = addon.db.global.patDB or {}  
  addon.db.global.patDB[profid] = patDB
end

addon.scantt = CreateFrame("GameTooltip", "ProfessionsVault_Tooltip", UIParent, "GameTooltipTemplate")
addon.scantt:SetOwner(UIParent, "ANCHOR_NONE");

function addon:recipeClass()
  if not addon._recipeClass then
    addon._recipeClass = select(6,GetItemInfo(43017))
  end
  return addon._recipeClass 
end

function addon:RefreshTooltips() -- reset the tooltip state
  addon.ttcache = {} -- clear tooltip cache
  GameTooltip:Hide()
  ItemRefTooltip:Hide()
  if AtlasLootTooltip then AtlasLootTooltip:Hide() end
  addon:SetAuctionColors()
end

function addon:SetAuctionColors()
  --debug("SetAuctionColors()")

  local pageoffset = 0
  if not addon.AuctioneerAdv then
    pageoffset = (BrowseScrollFrame and FauxScrollFrame_GetOffset(BrowseScrollFrame)) or 0
  end
  local pagesz, totalsz = GetNumAuctionItems("list")
  for i = 1, pagesz do
     local itemlink, itemidx, iconTexture
     if addon.AuctioneerAdv then
       local button = getglobal("BrowseButton"..i)
       if button and button:IsVisible() and button.id then
         itemidx = button.id
         iconTexture = button.Icon
         --iconTexture = getglobal("AppraiserIconButton"..i)
	 if iconTexture then -- auctioneer doesn't reset colors
           iconTexture:SetVertexColor(1.0, 1.0, 1.0)
	 end
       end
     else
       itemidx = i+pageoffset
       iconTexture = getglobal("BrowseButton"..i.."ItemIconTexture")
     end

     if not itemidx then break end
     itemlink = GetAuctionItemLink("list", itemidx)
     if not iconTexture or not itemlink then break end

     local itemid = string.match(itemlink, "\124Hitem:(%d+):")
     itemid = itemid and tonumber(itemid) 
     if itemid then
          local _, _, _, _, _, itemtype, profName, _, _, _ = GetItemInfo(itemid)
          if itemtype == addon.recipeClass() then
            if not addon.ttcache[itemid] then
              debug("AH Scanning "..itemlink.." "..itemtype.." "..profName)
              addon.scantt:SetAuctionItem("list",itemidx)
            end
            local color = addon.ttcache[itemid] and addon.ttcache[itemid].ahcolor
            if color and addon.settings.ahcolor then -- second clause for RefreshTooltips
              debug("AH Coloring "..itemlink)
              iconTexture:SetVertexColor(color.r, color.g, color.b)
            end
          end
     end
  end

end

function addon:ShowTooltip(tt)
  local itemid, spellid, spellname
  local ttname = tt:GetName()
  if not ttname then return end

  local itemtext, itemlink = tt:GetItem()
  if itemtext and itemlink then -- recipe items
    local itemclass = select(6,GetItemInfo(itemlink))
    if not itemclass or (itemclass ~= addon.recipeClass()) then return end

    itemid = string.match(itemlink, "\124Hitem:(%d+):")
    itemid = itemid and tonumber(itemid)
  else -- recipe spells
    --string.match(itemlink, "\124Henchant:(%d+):")
    spellname, _, spellid = tt:GetSpell()
    if not spellname or not spellid then return end
    spellid = spellid and tonumber(spellid)
  end
  if not itemid and not spellid then return end
  local cacheid = itemid or spellid+1000000

  if addon.ttcache[cacheid] then -- read from cache
    if #addon.ttcache[cacheid] > 0 then
      tt:AddLine(" ")
    end
    for _,l in ipairs(addon.ttcache[cacheid]) do
     if ttwrapwidth == 0 then
      tt:AddLine(string.gsub(l.text,",",", "), l.color.r, l.color.g, l.color.b, true)
     else
      local txtc = { strsplit(",",l.text) }
      local t = ""
      for _,c in ipairs(txtc) do
        if #t + #c > ttwrapwidth then
          tt:AddLine(t..",", l.color.r, l.color.g, l.color.b)
          t = "           "..c
        elseif #t == 0 then
          t = c
        else
          t = t..", "..c
        end
      end -- for txtc
      if #t > 0 then
        tt:AddLine(t, l.color.r, l.color.g, l.color.b)
      end
     end 
    end -- for lines
    tt:Show()
    tt:Show()
  else -- build cache
    local profName, profLvl, profID
    if spellid then -- spell link
      local line = getglobal(ttname .. "TextLeft1")
      if not line then return end
      local text = line:GetText()
      if not text then return end
      profName = string.match(text, "^([^:]+): ")
      profID = allProf[profName] and allProf[profName].spellid
      profLvl = 0 -- TODO
    else -- item link
      spellname = string.match(itemtext, ":%s*(.+)$")
      if not spellname then return end

      for i=2,tt:NumLines() do
        local line = getglobal(ttname .. "TextLeft"..i)
        if not line then return end
        local text = line:GetText()
        if not text then return end
        profName, profLvl = string.match(text, strtrim(L["Requires"]).."%s*:?%s*(.+)%s+%((%d+)%)%s*$")
	if not profName then
          profName, profLvl = string.match(text, "(.+)%s+%((%d+)%)%s+"..strtrim(L["Requires"])) -- frFR
	end
	profName = profName and strtrim(profName)
        profLvl = profLvl and tonumber(profLvl)
        profID = allProf[profName] and allProf[profName].spellid
        if profName and profID and profLvl then break end
      end
    end 
    if not profName or not profID or not profLvl then return end
    debug(ttname..": "..profName.." ("..profLvl.."): "..spellname)
    local knownstr, learnstr, skillstr, dunnostr = "","","",""

    if not PV_PatDBL or not PV_PatDBL[profID] then return end
    spellname = normalize(spellname)
    local bitidx = PV_PatDBL[profID][(usehashes and addon:hash(spellname)) or spellname]
    -- some recipe names dont match their spell names, check for special cases
    if (not bitidx and itemid and PV_Exceptions_ItoS[itemid]) then
        --spellname = normalize(GetSpellInfo(PV_Exceptions_ItoS[itemid]))
        bitidx = PV_PatDBL[profID][itemid]
    end
    if (not bitidx and spellid and PV_Exceptions_StoI[spellid]) then
        --spellname = normalize(GetSpellInfo(spellid))
        bitidx = PV_PatDBL[profID][PV_Exceptions_StoI[spellid]]
    end
    if (not bitidx) then -- some recipe names dont match their spell names, grr
      chatMsg(format(L["ERROR: Missing entry in pattern database: %s Please report this bug!"],
            format("%d %s: %s",(itemid or spellid),profName,spellname)))
    end

    for cname,dbc in cpairs(DB.chars) do
      --print(cname)
      local isself = (cname == charName)
      local isalt = not isself and dbc.data and dbc.data.alt
      local isother = not isself and not isalt
      local difffaction = dbc.data and dbc.data.faction and dbc.data.faction ~= DBc.data.faction
      if (dbc[profName] and cname ~= einstein and
	  (not difffaction or settings.factiondata) and
	  ((isself and settings.selfdata) or
	   (isalt and settings.altdata) or
	   (isother and settings.otherdata))
         ) then
        local pinfo = dbc[profName]
        if (pinfo.rank < profLvl) then
           skillstr = skillstr..((#skillstr > 0 and ",") or "") .. cname .. " (" .. pinfo.rank .. ")"
        else 
	   if (not bitidx) then
             dunnostr = dunnostr..((#dunnostr > 0 and ",") or "") .. cname 
           elseif (addon:link_bit(pinfo.link, bitidx)) then
             knownstr = knownstr..((#knownstr > 0 and ",") or "") .. cname 
           else
             learnstr = learnstr..((#learnstr > 0 and ",") or "") .. cname 
           end
        end
      end
    end

    addon.ttcache[cacheid] = {}
    if #dunnostr > 0 then
      table.insert(addon.ttcache[cacheid], { text = L["Not sure"]..": "..dunnostr, color = COLOR_DUNNO })
      addon.ttcache[cacheid].ahcolor = COLOR_DUNNO
    end
    if #skillstr > 0 then
      table.insert(addon.ttcache[cacheid], { text = L["Skill too low"]..": "..skillstr, color = COLOR_SKILL })
      addon.ttcache[cacheid].ahcolor = COLOR_SKILL
    end
    if #knownstr > 0 then
      table.insert(addon.ttcache[cacheid], { text = L["Known"]..": "..knownstr, color = COLOR_KNOWN })
      addon.ttcache[cacheid].ahcolor = COLOR_KNOWN
    end
    if #learnstr > 0 and profLvl == 0 then
      table.insert(addon.ttcache[cacheid], { text = L["Not Known"]..": "..learnstr, color = COLOR_UNKWN })
      addon.ttcache[cacheid].ahcolor = COLOR_UNKWN
    elseif #learnstr > 0 then
      table.insert(addon.ttcache[cacheid], { text = L["Learnable"]..": "..learnstr, color = COLOR_LEARN })
      addon.ttcache[cacheid].ahcolor = COLOR_LEARN
    end
    addon:ShowTooltip(tt)
  end
end

addon.DropDownMenu = CreateFrame("Frame", addonName.."_DropDownMenu")
addon.DropDownMenu.displayMode = "MENU"
addon.DropDownMenu.onHide = function(...)
        MenuParent = nil
        MenuItem = nil
end

function addon:ShowDropdown(cname, pname)
        addon.DropDownMenu.cname = cname
        addon.DropDownMenu.pname = pname
        GameTooltip:Hide()
        HideDropDownMenu(1)
        ToggleDropDownMenu(1, nil, addon.DropDownMenu, "cursor", 0, 0)
end

local menuinfo = {}
addon.DropDownMenu.initialize = function(self, level)
        local cname, pname = addon.DropDownMenu.cname, addon.DropDownMenu.pname
        if not level then return end
        wipe(menuinfo)
        if level == 1 then
                -- Create the title of the menu
                menuinfo.isTitle = 1
                menuinfo.text = cname..((pname and (" / "..pname)) or "")
                menuinfo.notCheckable = 1
                UIDropDownMenu_AddButton(menuinfo, level)

                menuinfo.isTitle      = nil
                menuinfo.notCheckable = nil

                menuinfo.text = L["Whisper this player"]
                menuinfo.disabled = (cname == einstein)
                menuinfo.arg1 = nil
                menuinfo.func = function(button, arg1)
                        ChatFrame_SendTell(cname)
                      end
                UIDropDownMenu_AddButton(menuinfo, level)

                menuinfo.text = L["Invite this player"]
                menuinfo.disabled = (cname == einstein)
                menuinfo.arg1 = nil
                menuinfo.func = function(button, arg1)
                        InviteUnit(cname)
                      end
                UIDropDownMenu_AddButton(menuinfo, level)

                menuinfo.text = L["Delete this entry"]
                menuinfo.disabled = (cname == einstein)
                menuinfo.arg1 = nil
                menuinfo.func = function(button, arg1)
                        if pname then
                           DB.chars[cname][pname] = nil
                        else
                           DB.chars[cname] = nil
                           addon:RefreshChar()
                        end
                        if addon.gui then
                          addon:ToggleWindow()
                          settings.treepath = nil
                          addon:ToggleWindow()
                        end
                        end
                UIDropDownMenu_AddButton(menuinfo, level)

		if (not pname) then
                  menuinfo.text = L["Is an alt"]
                  menuinfo.disabled = (cname == einstein)
                  menuinfo.arg1 = nil
                  menuinfo.checked = (DB.chars[cname].data.alt == true)
                  menuinfo.func = function(button, arg1, arg2, checked)
		        checked = not checked
		        debug("Set cname alt flag to: "..(checked and "true" or "false"))
                        DB.chars[cname].data.alt = checked
			addon:RefreshTooltips()
                      end
                  UIDropDownMenu_AddButton(menuinfo, level)
		end

                -- Close menu item
                menuinfo.disabled     = nil
                menuinfo.text         = CLOSE
                menuinfo.func         = function() CloseDropDownMenus() end
                menuinfo.checked      = nil
                menuinfo.notCheckable = 1
                UIDropDownMenu_AddButton(menuinfo, level)
        end
end
