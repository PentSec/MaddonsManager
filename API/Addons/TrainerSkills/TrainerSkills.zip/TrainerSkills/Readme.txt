TrainerSkills by Razzer (http://wow.pchjaelp.dk)

If you like this mod please consider making a donation at http://wow.pchjaelp.dk

Installation:
Put the TrainerSkills folder into the \World of Warcraft\Interface\AddOns\ directory.

Useage:
Use the icon at the minimap or in titanpanel or type /ts or /trainerSkills or make a keybinding to bring up the trainerSkills frame.
For a list of all the slahscommands type /ts help
To get the trainerdata in the mod you only have to visit your trainers and it will automatically update the database.

If you encounter any errors or got some sugestions or comments please feel free to send me an e-mail: trainerskills@pchjaelp.dk


