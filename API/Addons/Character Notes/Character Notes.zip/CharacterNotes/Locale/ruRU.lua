local L = LibStub("AceLocale-3.0"):NewLocale("CharacterNotes", "ruRU", false)

if not L then return end


