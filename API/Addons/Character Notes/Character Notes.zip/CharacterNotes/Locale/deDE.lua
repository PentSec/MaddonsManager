local L = LibStub("AceLocale-3.0"):NewLocale("CharacterNotes", "deDE", false)

if not L then return end

L["Cancel"] = "Abbrechen"
L["Character Name"] = "Charaktername"
L["Character Notes"] = "Charakternotizen"
L["Clear"] = "Löschen"
L["Close"] = "Schließen"
L["Delete"] = "Löschen"
L["Delete Note"] = "Notiz löschen"
L["Deleted note for %s"] = "Notiz für %s gelöscht"
L["Edit"] = "Editieren"
L["Raid Members"] = "Schlachtzugmitglieder"
L["Right click"] = "Rechtsklick"
L["Save"] = "Speichern"
L["Search"] = "Suchen"
L["Show notes at logon"] = "Notizen beim Login anzeigen"
L["Show notes in tooltips"] = "Notizen in Tooltips anzeigen"
L["Show notes with who results"] = "Notizen bei /wer-Abragen anzeigen"
L["Toggle the minimap button"] = "Minimap-Symbol ein/ausblenden"
L["Tooltip Options"] = "Tooltip-Optionen"
L["to open/close the configuration."] = "um die Konfigurationen zu öffnen/schliessen."
L["to open/close the window"] = "um das Fenster zu öffnen/schliessen."

