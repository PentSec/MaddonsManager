--[[
MillHelp
Author: Michael Joseph Murray aka Lyte of Lothar(US)
$Revision: 94 $
$Date: 2010-07-26 19:31:24 +0000 (Mon, 26 Jul 2010) $
r94
contact: codemaster2010 AT gmail DOT com

Copyright (c) 2007-2010 Michael J. Murray aka Lyte of Lothar(US)
All rights reserved unless otherwise explicitly stated.
]]

local strformat = string.format
local strfind = string.find
local strsplit = strsplit

local fmtstring = "|cffffffff%s x%d (%s x%d)|r"

local warning1 = "Your item cache appears out of date, this is normal if there was a patch recently."
local warning2 = "Type /millhelp to query the server for the items."

if GetLocale() == "zhTW" then
	warning1 = "你的暫存物品連結已過期，如果遊戲最近曾經更新，這是正常的。"
	warning2 = "輸入 /millhelp 向伺服器查詢物品連結。"
elseif GetLocale() == "zhCN" then
	warning1 = "你的物品缓存已过期,如果最新有游戏补丁这个是正常的."
	warning2 = "输入/millhelp向服务器端查询这个物品."
elseif GetLocale() == "koKR" then
	warning1 = "당신의 아이템 저장소가 만료되었으며, 이것은 최근 패치로 인해 정상적입니다."
	warning2 = "/millhelp를 입력하면 아이템에 대해 서버에 요청합니다."
elseif GetLocale() == "ruRU" then
	warning1 = "Ваш кэш предметов устарел. Это нормально, если недавно был установлен патч."
	warning2 = "Введите /millhelp для запроса предметов с сервера."
elseif GetLocale() == "deDE" then
	warning1 = "Dein Itemcache scheint nicht aktuell zu sein, dies kommt vor wenn Du einen aktuellen patch eingespielt hast!"
	warning2 = "Gebe /millhelp ein, um den Server nach den Items abzufragen!"
end

local announcedCache = nil
local function warnCache()
	if not announcedCache then
		if MILLHELP_QUERY_FRAME and MILLHELP_QUERY_FRAME:IsVisible() then
			return
		else
			announcedCache = true
			ChatFrame1:AddMessage("|cff1eff00MillHelp_Glyphs|r: " .. warning1)
			ChatFrame1:AddMessage("|cff1eff00MillHelp_Glyphs|r: " .. warning2)
		end
	end
end

--glyphTable is a mapping of Glyph itemIDs to a comma separated
--string that contains an ink itemID and the number of inks required
local glyphTable = {
	--	Major Glyphs	--
	--Death Knight
	["43533"] = "43126,1", --anti-magic shell
	["43534"] = "43126,1", --blood boil
	["43826"] = "43124,1", --blood strike
	["43536"] = "43122,1", --bone shield
	["43537"] = "43126,1", --chains of ice
	["43538"] = "43126,1", --dark command
	["43542"] = "43126,1", --death and decay
	["43541"] = "43122,1", --death grip
	["43827"] = "43124,1", --death strike
	["43543"] = "43122,1", --frost strike
	["43545"] = "43126,1", --icebound fortitude
	["43546"] = "43122,1", --icy touch
	["43547"] = "43126,1", --obliterate
	["43548"] = "43124,1", --plague strike
	["43550"] = "43126,1", --rune strike
	["43825"] = "43124,1", --rune tap
	["43551"] = "43124,1", --scourge strike
	["43552"] = "43126,1", --strangulate
	["43549"] = "43124,1", --ghoul
	["43553"] = "43124,1", --unbreakable armor
	["43554"] = "43124,1", --vamperic blood
	--Patch 3.1 additions
	["45799"] = "43124,1", --dancing rune weapon
	["45804"] = "43122,1", --dark death
	["45805"] = "43122,1", --disease
	["45806"] = "43124,1", --howling blast
	["45800"] = "43124,1", --hungering cold
	["45803"] = "43124,1", --unholy blight
	--Druid
	["40924"] = "43116,1", --entangling roots
	["44928"] = "43126,1", --focus (starfall)
	["40896"] = "43124,1", --frenzied regen
	["40899"] = "43126,1", --growl
	["40914"] = "43116,1", --healing touch
	["40920"] = "43126,1", --hurricane
	["40908"] = "43126,1", --innervate
	["40919"] = "43118,1", --insect swarm
	["40915"] = "43126,1", --lifebloom
	["40900"] = "43126,1", --mangle
	["40897"] = "39774,1", --maul
	["40923"] = "43116,1", --moonfire
	["40903"] = "43124,1", --rake
	["40909"] = "43118,1", --rebirth
	["40912"] = "43126,1", --regrowth
	["40913"] = "39774,1", --rejuvenation
	["40902"] = "43120,1", --rip
	["40901"] = "43122,1", --shred
	["40921"] = "43126,1", --starfall
	["40916"] = "43120,1", --starfire
	["40906"] = "43126,1", --swiftmend
	["40922"] = "39774,1", --wrath
	--Patch 3.1 additions
	["45623"] = "43120,1", --barkskin
	["45601"] = "43124,1", --berserk
	["45622"] = "43122,1", --monsoon
	["45603"] = "43126,1", --nourish
	["45604"] = "43126,1", --savage roar
	["45602"] = "43124,1", --wild growth
	--Patch 3.2 addition
	["48720"] = "39774,1", --claw
	--Patch 3.3 additions
	["50125"] = "43127,1", --rapid rejuv
	--Hunter
	["42897"] = "43118,1", --aimed shot
	["42898"] = "43116,1", --arcane shot
	["42899"] = "43126,1", --aspect of the beast
	["42900"] = "43116,1", --aspect of the monkey
	["42901"] = "43126,1", --aspect of the viper
	["42902"] = "43126,1", --beastial wrath
	["42903"] = "43120,1", --deterrence
	["42904"] = "43120,1", --disengage
	["42905"] = "43122,1", --freezing trap
	["42906"] = "43124,1", --frost trap
	["42907"] = "39774,1", --hunter's mark
	["42908"] = "43116,1", --immolation trap
	["42909"] = "43126,1", --imp aspect of the hawk
	["42910"] = "43118,1", --multi-shot
	["42911"] = "43124,1", --rapid fire
	["42912"] = "39774,1", --serpent sting
	["42913"] = "43126,1", --snake trap
	["42914"] = "43126,1", --steady shot
	["42915"] = "43126,1", --true shot aura
	["42916"] = "43126,1", --volley
	["42917"] = "43126,1", --wyvern sting
	--Patch 3.1 additions
	["45625"] = "43124,1", --chimera shot
	["45731"] = "43124,1", --explosive shot
	["45733"] = "43118,1", --explosive trap
	["45732"] = "43126,1", --kill shot
	["45735"] = "39774,1", --raptor strike
	["45734"] = "43116,1", --scatter shot
	--Mage
	["44955"] = "43124,1", --Arcane Blast
	["42734"] = "43116,1", --Arcane Explosion
	["42735"] = "43116,1", --Arcane Missiles
	["42736"] = "43124,1", --Arcane Power
	["42737"] = "43116,1", --Blink
	["42738"] = "43118,1", --Evocation
	["42740"] = "43126,1", --Fire Blast
	["42739"] = "43126,1", --Fireball
	["42741"] = "39774,1", --Frost Nova
	["42742"] = "43126,1", --Frostbolt
	["44684"] = "43126,1", --Frostfire
	["42743"] = "39774,1", --Ice Armor
	["42744"] = "43120,1", --Ice Block
	["42745"] = "43126,1", --Ice Lance
	["42746"] = "43118,1", --Icy Veins
	["42747"] = "43120,1", --Imp Scorch
	["42748"] = "43126,1", --Invis
	["42749"] = "43124,1", --Mage Armor
	["42750"] = "43122,1", --Mana Gem
	["42751"] = "43126,1", --Molten Armor
	["42752"] = "43126,1", --Polymorph
	["42753"] = "43126,1", --Remove Curse
	["42754"] = "43126,1", --Water Elemental
	--Patch 3.1 additions
	["45738"] = "43124,1", --arcane barrage
	["45736"] = "43124,1", --deep freeze
	["45740"] = "43120,1", --ice barrier
	["45737"] = "43124,1", --living bomb
	["45739"] = "43126,1", --mirror image
	--Patch 3.3 additions
	["50045"] = "43124,1", --water elemental
	--Paladin
	["41101"] = "43126,1", --Avenger's Shield
	["41107"] = "43126,1", --Avenging Wrath
	["41104"] = "43118,1", --Cleansing
	["41099"] = "43120,1", --Consecration
	["41098"] = "43120,1", --Crusader Strike
	["41108"] = "43116,1", --Divinity
	["41103"] = "43122,1", --Exorcism
	["41105"] = "43124,1", --Flash of Light
	["41095"] = "39774,1", --Hammer of Justice
	["41097"] = "43126,1", --Hammer of Wrath
	["41106"] = "43116,1", --Holy Light
	["41092"] = "43116,1", --Judgement
	["41100"] = "43118,1", --Righteous Defense
	["43867"] = "43126,1", --Seal of Holy Wrath
	["41094"] = "43124,1", --Seal of Command
	["41110"] = "43126,1", --Seal of Light
	["43868"] = "43126,1", --Seal of Righteousness
	["43869"] = "43126,1", --Seal of Vengance
	["41109"] = "43126,1", --Seal of Wisdom
	["41096"] = "39774,1", --Spiritual Attunement
	["41102"] = "43126,1", --Turn Evil
	--Patch 3.1 additions
	["45741"] = "43124,1", --beacon of light
	["45745"] = "43126,1", --divine plea
	["45743"] = "43124,1", --divine storm
	["45742"] = "43124,1", --hammer of the righteous
	["45746"] = "43120,1", --holy shock
	["45747"] = "43116,1", --salvation
	["45744"] = "43126,1", --shield of righteousness
	--Priest
	["42396"] = "43126,1", --Circle of Healing
	["42397"] = "43120,1", --Dispel Magic
	["42398"] = "43116,1", --Fade
	["42399"] = "43122,1", --Fear Ward
	["42400"] = "43116,1", --Flash Heal
	["42401"] = "43124,1", --Holy Nova
	["42402"] = "43116,1", --Inner Fire
	["42403"] = "43126,1", --Lightwell
	["42404"] = "43126,1", --Mass Dispel
	["42405"] = "43126,1", --Mind Control
	["42406"] = "43124,1", --Mind Flay
	["42408"] = "39774,1", --PW: Shield
	["42409"] = "43126,1", --Prayer of Healing
	["42410"] = "39774,1", --Psychic Scream
	["42411"] = "43118,1", --Renew
	["42412"] = "43126,1", --Scourge Imprisonment
	["42407"] = "43126,1", --Shadow
	["42414"] = "43126,1", --SW: Death
	["42415"] = "43118,1", --SW: Pain
	["42416"] = "43120,1", --Smite
	["42417"] = "43126,1", --Spirit of Redemption
	--Patch 3.1 additions
	["45753"] = "43124,1", --dispersion
	["45755"] = "43124,1", --guardian spirit
	["45758"] = "43124,1", --hymn of hope
	["45757"] = "43126,1", --mind sear
	["45760"] = "43122,1", --pain suppression
	["45756"] = "43124,1", --penance
	--Rogue
	["42954"] = "43126,1", --Adrenaline Rush
	["42955"] = "43124,1", --Ambush
	["42956"] = "39774,1", --Backstab
	["42957"] = "43126,1", --Blade Flurry
	["42958"] = "43126,1", --Crip Poison
	["42959"] = "43126,1", --Deadly Throw
	["42960"] = "39774,1", --Evasion
	["42961"] = "43116,1", --Eviscerate
	["42962"] = "43116,1", --Expose Armor
	["42963"] = "43124,1", --Feint
	["42964"] = "43116,1", --Garrote
	["42965"] = "43126,1", --Ghostly Strike
	["42966"] = "43118,1", --Gouge
	["42967"] = "43126,1", --Hemorrhage
	["42968"] = "43126,1", --Preparation
	["42969"] = "43126,1", --Rupture
	["42970"] = "43118,1", --Sap
	["42972"] = "43120,1", --Sinister Strike
	["42973"] = "43120,1", --Slice and Dice
	["42974"] = "43122,1", --Sprint
	["42971"] = "43126,1", --Vigor
	--Patch 3.1 additions
	["45769"] = "43124,1", --cloak of shadows
	["45908"] = "43124,1", --envenom
	["45766"] = "43126,1", --fan of knives
	["45761"] = "43124,1", --hunger for blood
	["45762"] = "43124,1", --killing spree
	["45768"] = "43122,1", --mutilate
	["45764"] = "43124,1", --shadow dance
	["45767"] = "43126,1", --tricks of the trade
	--Shaman
	["41517"] = "43126,1", --Chain Heal
	["41518"] = "43126,1", --Chain Lightning
	["41527"] = "43124,1", --Earthliving Weapon
	["41552"] = "43126,1", --Elemental Mastery
	["41529"] = "43126,1", --Fire Elemental
	["41530"] = "43116,1", --Fire Nova
	["41531"] = "39774,1", --Flame Shock
	["41532"] = "43116,1", --Flametounge Weapon
	["41547"] = "43118,1", --Frost Shock
	["41533"] = "43120,1", --Healing Stream
	["41534"] = "43126,1", --Healing Wave
	["41524"] = "43126,1", --Lava
	["41540"] = "43118,1", --Lava Lash
	["41535"] = "43120,1", --Lesser Healing Wave
	["41536"] = "43116,1", --Lightning Bolt
	["41537"] = "39774,1", --Lightning Shield
	["41538"] = "43126,1", --Mana Tide
	["41526"] = "43126,1", --Shocking
	["41539"] = "43126,1", --Stormstrike
	["41541"] = "43122,1", --Water Mastery
	["41542"] = "43124,1", --Windfury Weapon
	--Patch 3.1 additions
	["45775"] = "43122,1", --earth shield
	["45771"] = "43124,1", --feral spirit
	["45777"] = "43126,1", --hex
	["45772"] = "43124,1", --riptide
	["45778"] = "39774,1", --stoneclaw totem
	["45770"] = "43124,1", --thunder
	["45776"] = "43122,1", --totem of wrath
	--Warlock
	["42453"] = "43124,1", --Banish
	["42454"] = "43126,1", --Conflagrate
	["42455"] = "39774,1", --Corruption
	["42456"] = "43126,1", --Curse of Agony
	["42457"] = "43126,1", --Death Coil
	["42458"] = "43116,1", --Fear
	["42459"] = "43126,1", --Felguard
	["42460"] = "43126,1", --Felhunter
	["42461"] = "43116,1", --Health Funnel
	["42462"] = "39774,1", --Healthstone
	["42463"] = "43126,1", --Howl of Terror
	["42464"] = "43126,1", --Immolate
	["42465"] = "43116,1", --Imp
	["42466"] = "43120,1", --Searing Pain
	["42467"] = "43118,1", --Shadow Bolt
	["42468"] = "43122,1", --Shadowburn
	["42469"] = "43126,1", --Siphon Life
	["42470"] = "43120,1", --Soulstone
	["42471"] = "43124,1", --Succubus
	["42472"] = "43126,1", --Unstable Affliction
	["42473"] = "43118,1", --Voidwalker
	--Patch 3.1 additions
	["45781"] = "43124,1", --chaos bolt
	["45782"] = "43126,1", --demonic circle
	["45779"] = "43124,1", --haunt
	["45785"] = "39774,1", --life tap
	["45780"] = "43124,1", --metamorphosis
	["45783"] = "43126,1", --shadowflame
	["45789"] = "43116,1", --soul link
	--Patch 3.3 additions
	["50077"] = "43127,1", --quick decay
	--Warrior
	["43420"] = "43120,1", --Barbaric Insults
	["43425"] = "43126,1", --Blocking
	["43412"] = "43126,1", --Bloodthirst
	["43414"] = "43120,1", --Cleaving
	["43415"] = "43126,1", --Devastate
	["43416"] = "43122,1", --Execution
	["43417"] = "43116,1", --Hamstring
	["43418"] = "39774,1", --Heroic Strike
	["43419"] = "43126,1", --Intervene
	["43426"] = "43126,1", --Last Stand
	["43421"] = "43126,1", --Mortal Strike
	["43422"] = "43118,1", --Overpower
	["43413"] = "39774,1", --Rapid Charge
	["43423"] = "43116,1", --Rending
	["43430"] = "43126,1", --Resonating Power
	["43424"] = "43118,1", --Revenge
	["43427"] = "43116,1", --Sunder Armor
	["43428"] = "43124,1", --Sweeping Strikes
	["43429"] = "43126,1", --Taunt
	["43431"] = "43126,1", --Victory Rush
	["43432"] = "43124,1", --Whirlwind
	--Patch 3.1 additions
	["45790"] = "43124,1", --bladestorm
	["45794"] = "43126,1", --enraged regeneration
	["45797"] = "43116,1", --shield wall
	["45792"] = "43124,1", --shockwave
	["45795"] = "43124,1", --spell reflection
	["45793"] = "43120,1", --vigilance
	--	Minor Glyphs	--
	--Death Knight
	["43535"] = "43124,1", --Blood Tap
	["43671"] = "43124,1", --Corpse Explosion
	["43539"] = "43124,1", --Death's Embrace
	["43544"] = "43124,1", --Horn of Winter
	["43672"] = "43124,1", --Pestilence
	["43673"] = "43124,1", --Raise Dead
	--Druid
	["43316"] = "43116,1", --Aquatic Form
	["43334"] = "43118,1", --Challenging Roar
	["43674"] = "43118,1", --Dash
	["43335"] = "39774,1", --Wild
	["43332"] = "39774,1", --Thorns
	["44922"] = "43126,1", --Typhoon
	["43331"] = "43116,1", --Unburdened Rebirth
	--Hunter
	["43351"] = "43118,1", --Feign Death
	["43350"] = "39774,1", --Mend Pet
	["43354"] = "39774,1", --Possessed Strength
	["43338"] = "39774,1", --Revive Pet
	["43356"] = "39774,1", --Scare Beast
	["43355"] = "43120,1", --Pack
	--Mage
	["43339"] = "39774,1", --Arcane Intelect
	["44920"] = "43126,1", --Blast Wave
	["43357"] = "43116,1", --Fire Ward
	["43359"] = "39774,1", --Frost Armor
	["43360"] = "43116,1", --Frost Ward
	["43364"] = "39774,1", --Slow Fall
	--["43362"] = "", --Bear Cub (Not implemented)
	["43361"] = "39774,1", --Penguin
	--Paladin
	["43365"] = "43116,1", --Kings
	["43340"] = "39774,1", --Might
	["43366"] = "39774,1", --Wisdom
	["43367"] = "39774,1", --Lay on Hands
	["43368"] = "43116,1", --Sense Undead
	["43369"] = "43118,1", --Wise
	--Priest
	["43342"] = "39774,1", --Fading
	["43371"] = "39774,1", --Fortitude
	["43370"] = "43118,1", --Levitate
	["43373"] = "43116,1", --Shackle Undead
	["43372"] = "43118,1", --Shadow Protection
	["43374"] = "43126,1", --Shadowfiend
	--Rogue
	["43379"] = "39774,1", --Blurred Speed
	["43376"] = "43116,1", --Distract
	["43377"] = "43116,1", --Pick Lock
	["43343"] = "39774,1", --Pick Pocket
	["43378"] = "43120,1", --Safe Fall
	["43380"] = "43116,1", --Vanish
	--Shaman
	["43381"] = "43118,1", --Astral Recall
	["43725"] = "43116,1", --Ghost Wolf
	["43385"] = "43118,1", --Renewed Life
	["44923"] = "43126,1", --Thunderstorm
	["43344"] = "43116,1", --Water Breathing
	["43386"] = "43116,1", --Water Shield
	["43388"] = "43118,1", --Water Walking
	--Warlock
	["43392"] = "43118,1", --Curse of Exhaustion
	["43390"] = "39774,1", --Drain Soul
	["43393"] = "43118,1", --Enslave Demon
	["43391"] = "43116,1", --Kilrogg
	["43394"] = "43126,1", --Souls
	["43389"] = "43116,1", --Unending Breath
	--Warrior
	["43395"] = "39774,1", --Battle
	["43396"] = "39774,1", --Bloodrage
	["43397"] = "39774,1", --Charge
	["43400"] = "43124,1", --Enduring Victory
	["43398"] = "43116,1", --Mocking Blow
	["43399"] = "39774,1", --Thunder Clap
	--Patch 3.2 additions
	["49084"] = "43126,1" --Command
}

--inkTable is a mapping of Ink itemIDs to a comma separated
--string that contains a pigment itemID and the number of pigments required
local inkTable = {
	["43120"] = "39340,2", --celestial ink (violet pigment)
	["43124"] = "39342,2", --ethereal ink (nether pigment)
	["43126"] = "39343,2", --ink of the sea (azure pigment)
	["43118"] = "39339,2", --jadefire ink (emerald pigment)
	["43116"] = "39338,2", --lion's ink (golden pigment)
	["39774"] = "39334,2", --midnight ink (dusky pigment)
	["43122"] = "39341,2", --shimmering ink (silvery pigment)
	["43127"] = "43109,2", --snofall ink (icy pigment)
}

local getGlyphString = setmetatable({}, {
	__index = function(t, k)
		local mats = glyphTable[k]
		--get the ink itemID and the number of inks
		local ink, numInk = strsplit(",", mats)
		--get the pigment itemID and number of pigments
		local pigment, num = strsplit(",", inkTable[ink])
		--convert the itemIDs into localized names via GII
		local pigmentName = GetItemInfo(tonumber(pigment))
		local inkName = GetItemInfo(tonumber(ink))
		
		--make sure the names are actually returned
		if inkName == nil or pigmentName == nil then
			warnCache()
			t[k] = nil
			return nil
		end
		
		t[k] = strformat(fmtstring, inkName, numInk, pigmentName, num*numInk)
		return t[k]
	end
})

local function AddGlyphInfo(frame, itemLink)
	local _, _, itemString = strfind(itemLink, "^|c%x+|H(.+)|h%[.+%]")
	if itemString then
		local _, itemID = strsplit(":", itemString)
		if itemID then
			--see if the itemID is a glyph
			if glyphTable[itemID] then
				frame:AddLine(getGlyphString[itemID])
			end
		end
	end
	
	frame:Show()
end

local function HookIt(tt)
	tt:HookScript("OnTooltipSetItem", function(self, ...)
		local itemLink = select(2, self:GetItem())
		if itemLink and GetItemInfo(itemLink) then
			AddGlyphInfo(self, itemLink)
		end
	end)
end

HookIt(GameTooltip)
HookIt(ItemRefTooltip)
