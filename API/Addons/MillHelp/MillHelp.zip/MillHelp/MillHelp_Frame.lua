--[[
MillHelp_Frame.lua
Author: Michael Joseph Murray aka Starinnia of Lothar(US) aka Lyte of Lothar(US)
Please see license.txt for details.
$Revision: 74 $
$Date: 2009-05-10 23:03:21 +0000 (Sun, 10 May 2009) $
r94
contact: codemaster2010 AT gmail DOT com

Copyright (c) 2007-2009 Michael J. Murray aka Starinnia of Lothar
All rights reserved unless otherwise explicitly stated.
]]
--bail if the frame exists already
if _G["MILLHELP_QUERY_FRAME"] then
	return
end

local millPanel

local UNKOWNTIP1 = "Unsafe Item"
local UNKOWNTIP2 = "ItemID: "
local UNKOWNTIP3 = "This item is unsafe. To view this item without the risk of disconnection, you need to have first seen it in the game world. This is a restriction enforced by Blizzard since Patch 1.10."
local UNKOWNTIP4 = "You can right-click to attempt to query the server.  You may be disconnected."

if GetLocale == "deDE" then
	UNKOWNTIP1 = "Unsicherer Gegenstand"
	UNKOWNTIP2 = "ItemID: "
	UNKOWNTIP3 = "Dieser Gegenstand ist unsicher. Um diesen Gegenstand sehen zu können ohne einen Verbindungsabbruch zu riskieren, musst Du ihn zunächst irgendwo im Spiel gesehen haben. Blizzard schreibt diese Einschränkung seit Patch 1.10 vor."
	UNKOWNTIP4 = "Du kannst versuchen per Rechtsklick eine Anfrage an den Server zu senden. Dies kann zu einem Verbindungsabbruch führen."
elseif GetLocale() == "zhTW" then
	UNKOWNTIP1 = "不安全的連結"
	UNKOWNTIP2 = "ItemID: "
	UNKOWNTIP3 = "這個物品連結並不安全. 為了避免發生與伺服器中斷連結, 你需要曾經在遊戲中看過這項物品. 這是暴雪公司自從1.10版本後所加入的限制."
	UNKOWNTIP4 = "你可以在不安全的連結上使用滑鼠右鍵, 向伺服器要求查看物品. 你可能與伺服器中斷連結!!"
elseif GetLocale() == "frFR" then
	UNKOWNTIP1 = "Objet peu sûr"
	UNKOWNTIP2 = "ObjetID: "
	UNKOWNTIP3 = "Cet objet n'est pas fiable.\nPour voir cet objet sans risque de déconnexion, vous devez l'avoir déjà vu une fois dans le jeu.\nCette restriction est imposée par Blizzard depuis la mise à jour 1.10."
	UNKOWNTIP4 = "Un clic-droit permet de tenter d'interroger le serveur.\nVous pouvez être déconnecté."
elseif GetLocale() == "koKR" then
	UNKOWNTIP1 = "알수없는 아이템"
	UNKOWNTIP2 = "ItemID: "
	UNKOWNTIP3 = "이 아이템은 존재하지 않습니다. 종료없이 이 아이템을 확인하기 위해서는 한번쯤 게임안에서 그것을 보아야합니다. 이것은 1.10 패치 이후 블리자드에 의하여 제한되었습니다."
	UNKOWNTIP4 = "당신은 서버로 부터 정보를 가져오기 위해 우-클릭을 할 수 있습니다. 강제 종료될 수 있습니다."
elseif GetLocale() == "ruRU" then
	UNKOWNTIP1 = "Небезопасный предмет"
	UNKOWNTIP2 = "ID предмета: "
	UNKOWNTIP3 = "Этот предмет небезопасен. Для того, чтобы посмотреть его без риска отсоединения от сервера, Вы должны сначала увидеть его в игре. Это ограничение было введено компанией Blizzard в патче 1.10."
	UNKOWNTIP4 = "Вы можете кликнуть правой кнопкой для попытки запроса информации с сервера. Помните, что это может привести к разрыву соединения с сервером."
elseif GetLocale() == "zhCN" then
	UNKOWNTIP1 = "不安全的物品"
	UNKOWNTIP2 = "物品编号: "
	UNKOWNTIP3 = "这个物品是不安全的.如果你想避免掉线,你需要在这个游戏世界看到过此物品.这是暴雪自补丁1.10后加入的限制."
	UNKOWNTIP4 = "你可以右键点击来尝试向服务器端查询.你可能会因此而掉线."
end

local itemList = {
	"39151", --alabaster
	"39334", --dusky
	"39338", --golden
	"39339", --emerald
	"39340", --violet
	"39341", --silvery
	"39342", --nether
	"39343", --azure
	"43104", --burnt
	"43103", --verdant
	"43107", --sapphire
	"43106", --ruby
	"43108", --ebon
	"43109", --icy
	"43105", --indigo
	"37101",--ivory ink 
	"39469", --moonglow ink
	"39774", --midnight ink
	"43115", --hunter's ink
	"43116", --lion's ink
	"43117", --dawnstar ink
	"43118", --jadefire ink
	"43119", --royal ink
	"43120", --celestial ink
	"43121", --fiery ink
	"43122", --shimmering ink
	"43123", --ink of the sky
	"43124", --ethereal ink
	"43125", --darkflame ink
	"43126", --ink of the sea
	"43127", -- snowfall ink
}

local function onEnter(frame)
	GameTooltip:SetOwner(frame, "ANCHOR_RIGHT")
	local itemID, itemName, itemLink, itemRarity
	itemID = frame:GetID()
	itemName, itemLink, itemRarity = GetItemInfo(itemID)
	if itemLink then
		GameTooltip:SetHyperlink(itemLink)
		frame:SetText(ITEM_QUALITY_COLORS[itemRarity].hex..itemName)
	else
		GameTooltip:SetHyperlink("item:"..itemID) --query
		GameTooltip:ClearLines()
		GameTooltip:AddLine(UNKOWNTIP1)
		GameTooltip:AddLine(UNKOWNTIP2..itemID)
		GameTooltip:AddLine(UNKOWNTIP3, 1, 1, 1, 1)
		GameTooltip:AddLine(UNKOWNTIP4, nil, nil, nil, 1)
	end
	GameTooltip:Show()
end

local function onLeave(frame)
	GameTooltip:Hide()
end

local function onClick(frame, button)
	local itemID = frame:GetID()
	if button == "RightButton" then
		GameTooltip:SetHyperlink("item:"..itemID) --query
	end
end

local function createItemButton(index, frame)
	local b = CreateFrame("BUTTON", nil, frame)
	
	b:SetWidth(125)
	b:SetHeight(16)
	
	if index == 1 then
		b:SetPoint("TOP", frame, "TOP", -90, -45)
	elseif index < 16 then
		b:SetPoint("TOP", frame.buttons[index-1], "BOTTOM", 0, -3)
	elseif index == 16 then
		b:SetPoint("TOP", frame, "TOP", 90, -45)
	elseif index > 16 then
		b:SetPoint("TOP", frame.buttons[index-1], "BOTTOM", 0, -3)
	end
	
	local itemID,itemName, itemLink, itemRarity
	itemID = itemList[index]
	itemName, itemLink, itemRarity = GetItemInfo(itemID)
	b:SetID(itemID)
	
	if itemName then
		b:SetText(ITEM_QUALITY_COLORS[itemRarity].hex..itemName)
	else
		b:SetText("|cFF3FFFBF"..UNKOWNTIP2..itemID.."|r")
	end
	
	b:SetScript("OnEnter", onEnter)
	b:SetScript("OnLeave", onLeave)
	b:SetScript("OnClick", onClick)
	b:RegisterForClicks("RightButtonUp")
	b:SetNormalFontObject("GameFontNormal")
	
	b:Show()
	
	return b
end

local function createPanel()
	millPanel = CreateFrame("FRAME", "MILLHELP_QUERY_FRAME", UIParent)
	--let the frame close with the esc key
	table.insert(UISpecialFrames, "MILLHELP_QUERY_FRAME")

	millPanel:SetWidth(325)
	millPanel:SetHeight(400)
	millPanel:SetPoint("CENTER", UIParent, "CENTER", 0, 100)

	millPanel:SetBackdrop({
		bgFile = [[Interface\Tooltips\UI-Tooltip-Background]],
		edgeFile = [[Interface\Tooltips\UI-Tooltip-Border]],
		tile = false, tileSize = 16, edgeSize = 16,
		insets = { left = 5, right = 5, top = 5, bottom = 5 }
	})

	millPanel:SetBackdropColor(0, 0, 0, .85)
	millPanel:EnableMouse(true)
	millPanel:Hide()
	millPanel.close = CreateFrame("BUTTON", nil, millPanel, "UIPanelCloseButton")
	millPanel.close:SetPoint("TOPRIGHT", millPanel, "TOPRIGHT")

	millPanel.title = millPanel:CreateFontString(nil, "OVERLAY")
	millPanel.title:SetFontObject("GameFontNormal")
	millPanel.title:SetText("|cffffffff     MillHelp")
	millPanel.title:SetHeight(16)
	millPanel.title:SetWidth(75)
	millPanel.title:SetPoint("TOP", millPanel, "TOP", 0, -10)

	--15 pigments and 16 inks
	millPanel.buttons = {}
	for i = 1, 31 do
		millPanel.buttons[i] = createItemButton(i, millPanel)
	end
	
	millPanel:Hide()
end

_G["SlashCmdList"]["MILLHELP_MAIN"] = function()
	if _G["MILLHELP_QUERY_FRAME"] then
		millPanel:Show()
	else
		createPanel()
		millPanel:Show()
	end
end
_G["SLASH_MILLHELP_MAIN1"] = "/millhelp"
