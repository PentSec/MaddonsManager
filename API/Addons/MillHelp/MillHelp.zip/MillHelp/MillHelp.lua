--[[
MillHelp.lua
Author: Michael Joseph Murray aka Lyte of Lothar(US)
$Revision: 94 $
$Date: 2010-07-26 19:31:24 +0000 (Mon, 26 Jul 2010) $
r94
contact: codemaster2010 AT gmail DOT com

Copyright (c) 2007-2010 Michael J. Murray aka Lyte of Lothar(US)
All rights reserved unless otherwise explicitly stated.
]]

local strformat = string.format
local strfind = string.find
local strsplit = strsplit

local header1 = "Milling:"
local northrend = "Northrend Herbs"
local outlands = "Outlands Herbs"
local tier1 = "Peacebloom, Silverleaf, Earthroot"
local tier2 = "Mageroyal, Briarthorn, Swiftthistle,\nBruiseweed, Stranglekelp"
local tier3 = "Wild Steelbloom, Grave Moss, Kingsblood, Liferoot"
local tier4 = "Fadeleaf, Goldthorn, Khadgar's Whisker,\nWintersbite"
local tier5 = "Firebloom, Purple Lotus, Arthas' Tears,\nSungrass, Blindweed, Ghost Mushroom,\nGromsblood"
local tier6 = "Golden Sansam, Dreamfoil, Mountain Silversage,\nPlaguebloom, Icecap"
local warning1 = "Your item cache appears out of date, this is normal if there was a patch recently."
local warning2 = "Type /millhelp to query the server for the items."

--localize the strings if we have translations
if GetLocale() == "deDE" then
	header1 = "Mahlen:"
	northrend = "Pflanzen Nordends"
	outlands = "Pflanzen der Scherbenwelt"
	tier1 = "Friedenblume, Silberblatt, Erdwurzel"
	tier2 = "Maguskonigskraut, Wilddornrose, Flitzdistel,\nBeulengras, Wurgetang"
	tier3 = "Wild stahlblume, Grabmoos, Konigsblut, Lebenswurz"
	tier4 = "Blassblatt, Golddorn, Khadgars Schnurrbart,\nWinterbiss"
	tier5 = "Feuerblute	, Lila Lotus, Arthas' Tranen,\nSonnengras, Blindkraut, Geisterpilz,\nGromsblut"
	tier6 = "Goldener Sansam, Traumblatt, Bergsilbersalbei,\nPestblute, Eiskappe"
	warning1 = "Dein Itemcache scheint nicht aktuell zu sein, dies kommt vor wenn Du einen aktuellen patch eingespielt hast!"
	warning2 = "Gebe /millhelp ein, um den Server nach den Items abzufragen!"
elseif GetLocale() == "esES" or GetLocale() == "esMX" then
	header1 = "Moler:"
	northrend = "Hierbas de Rasganorte"
	outlands = "Hierbas de Terrallende"
	tier1 = "Flor de paz, Hojaplata, Raiz de tierra"
	tier2 = "Marregal, Brezospina, Cardopresto,\nHierba cardenal, Alga estranguladora"
	tier3 = "Acerita salvaje, Musgo de tumba, Sangrerregia,\nVidarraiz"
	tier4 = "Palida, Espina de oro, Mostacho de Khadgar,\nIvernalia"
	tier5 = "Flor de Fuego, Loto cardeno, Lagrimas de Arthas,\nSolea, Carolina, Champinon fantasma,\nGromsamguina"
	tier6 = "Sansam dorado, Hojasueno, Salviargenta de montana,\nFlor de peste, Setelo"
elseif GetLocale() == "zhTW" then
	header1 = "研磨:"
	northrend = "北裂境草藥"
	outlands = "外域草藥"
	tier1 = "寧神花, 銀葉草, 地根草"
	tier2 = "魔皇草, 石南草, 雨燕草,\n跌打草, 荊棘藻"
	tier3 = "野鋼花, 墓地苔, 皇血草, 活根草"
	tier4 = "枯葉草, 金棘草, 卡德加的鬍鬚,\n冬刺草"
	tier5 = "火焰花, 紫蓮花, 阿薩斯之淚,\n太陽草, 盲目草, 鬼魂菇,\n格羅姆之血"
	tier6 = "黃金蔘, 夢葉草, 山鼠草,\n瘟疫花, 冰蓋草"
	warning1 = "你的暫存物品連結已過期，如果遊戲最近曾經更新，這是正常的。"
	warning2 = "輸入 /millhelp 向伺服器查詢物品連結。"
elseif GetLocale() == "frFR" then
	header1 = "Mouture:"
	northrend = "Herbes de Norfendre"
	outlands = "Herbes de l'Outreterre"
	tier1 = "Pacifique, Feuillargent, Terrestrine"
	tier2 = "Mage royal, Eglantine, Chardonnier,\nDoulourante, Etouffante"
	tier3 = "Acierite sauvage, Tombeline, Sang-royal, Vieterule"
	tier4 = "Palerette, Dorepine, Moustache de Khadgar,\nHivernale"
	tier5 = "Fleur de feu, Lotus pourpre, Larmes d'Arthas,\nSoleillette, Aveuglette, Champignon fantome,\nGromsang"
	tier6 = "Sansam dore, Feuillereve, Fleur de peste,\nSauge-argent des montagnes, Chapeglace"
elseif GetLocale() == "ruRU" then
	header1 = "Измельчение:"
	northrend = "Травы Нордскола"
	outlands = "Травы Запределья"
	tier1 = "Мироцвет, Сребролист, Земляной корень"
	tier2 = "Магороза, Остротерн, Скорополох,\nСинячник, Удавник"
	tier3 = "Дикий сталецвет, Могильный мох, Королевская кровь,\nКорень жизни"
	tier4 = "Бледнолист, Златошип, Кадгаров ус,\nМорозник"
	tier5 = "Огнецвет, Лиловый лотос, Слезы Артаса,\nСолнечник, Пастушья сумка, Призрачная поганка,\nКровь Грома"
	tier6 = "Золотой сансам, Снолист, Горный серебряный шалфей,\nЧумоцвет, Ледяной зев"
	warning1 = "Ваш кэш предметов устарел. Это нормально, если недавно был установлен патч."
	warning2 = "Введите /millhelp для запроса предметов с сервера."
elseif GetLocale() == "koKR" then
	header1 = "제분:"
	northrend = "노스렌드의 약초"
	outlands = "아웃랜드의 약초"
	tier1 = "평온초 꽃잎, 은엽수잎, 뱀뿌리"
	tier2 = "마법초 꽃잎, 찔레가시, 토끼엉겅퀴풀,\n생채기풀, 갈래물풀"
	tier3 = "야생 철쭉, 무덤이끼, 왕꽃잎풀, 생명의 뿌리"
	tier4 = "미명초잎, 황금가시, 카드가의 수염,\n겨울서리풀"
	tier5 = "화염초 꽃잎, 보라 연꽃, 아서스의 눈물,\n태양풀, 실명초, 유령버섯,\n그롬의 피"
	tier6 = "황금 산삼, 꿈풀, 은초롱이,\n역병초 꽃잎, 얼음송이"
	warning1 = "당신의 아이템 저장소가 만료되었으며, 이것은 최근 패치로 인해 정상적입니다."
	warning2 = "/millhelp를 입력하면 아이템에 대해 서버에 요청합니다."
elseif GetLocale() == "zhCN" then
	header1 = "研磨:"
	northrend = "诺森德草药"
	outlands = "外域草药"
	tier1 = "宁神花,银叶草,地根草"
	tier2 = "魔皇草,石南草,雨燕草,\n跌打草,荆棘藻"
	tier3 = "野钢花,墓地苔,皇血草,活根草"
	tier4 = "枯叶草,金棘草,卡德加的胡须,\n冬刺草"
	tier5 = "火焰花,紫莲花,阿尔萨斯之泪,\n太阳草,盲目草,幽灵菇,\n格罗姆之血"
	tier6 = "黄金参,梦叶草,山鼠草,\n瘟疫花,冰盖草"
	warning1 = "你的物品缓存已过期,如果最新有游戏补丁这个是正常的."
	warning2 = "输入/millhelp向服务器端查询这个物品."
end

local announcedCache = nil
local function warnCache()
	if not announcedCache then
		if MILLHELP_QUERY_FRAME and MILLHELP_QUERY_FRAME:IsVisible() then
			return
		else
			announcedCache = true
			ChatFrame1:AddMessage("|cff1eff00MillHelp|r: " .. warning1)
			ChatFrame1:AddMessage("|cff1eff00MillHelp|r: " .. warning2)
		end
	end
end

--a table of herb itemIDs to common pigment itemIDs
local commonPigments = {
	["2449"] = 39151, --alabaster
	["2447"] = 39151,
	["765"] = 39151,
	["785"] = 39334, --dusky
	["2450"] = 39334,
	["3820"] = 39334,
	["2452"] = 39334,
	["2453"] = 39334,
	["3357"] = 39338, --golden
	["3356"] = 39338,
	["3355"] = 39338,
	["3369"] = 39338,
	["3358"] = 39339, --emerald
	["3821"] = 39339,
	["3819"] = 39339,
	["3818"] = 39339,
	["4625"] = 39340, --violet
	["8831"] = 39340,
	["8836"] = 39340,
	["8838"] = 39340,
	["8839"] = 39340,
	["8845"] = 39340,
	["8846"] = 39340,
	["13464"] = 39341, --silvery
	["13463"] = 39341,
	["13465"] = 39341,
	["13466"] = 39341,
	["13467"] = 39341,
	["22787"] = 39342, --nether
	["22790"] = 39342,
	["22789"] = 39342,
	["22792"] = 39342,
	["22791"] = 39342,
	["22785"] = 39342,
	["22793"] = 39342,
	["22786"] = 39342,
	["36906"] = 39343, --azure
	["36905"] = 39343,
	["36901"] = 39343,
	["37921"] = 39343,
	["36904"] = 39343,
	["36903"] = 39343,
	["36907"] = 39343,
	["39970"] = 39343,
}

--a table of herb itemIDs to rare pigment itemIDs
local rarePigments = {
	["3356"] = 43104, --burnt
	["3357"] = 43104,
	["3369"] = 43104,
	["3355"] = 43104,
	["785"] = 43103, --verdant
	["2450"] = 43103,
	["2452"] = 43103,
	["2453"] = 43103,
	["3820"] = 43103,
	["13466"] = 43107, --sapphire
	["13465"] = 43107,
	["13467"] = 43107,
	["13464"] = 43107,
	["13463"] = 43107,
	["4625"] = 43106, --ruby
	["8831"] = 43106,
	["8836"] = 43106,
	["8838"] = 43106,
	["8839"] = 43106,
	["8845"] = 43106,
	["8846"] = 43106,
	["22791"] = 43108, --ebon
	["22793"] = 43108,
	["22792"] = 43108,
	["22790"] = 43108,
	["22789"] = 43108,
	["22786"] = 43108,
	["22785"] = 43108,
	["22787"] = 43108,
	["36903"] = 43109, --icy
	["36905"] = 43109,
	["36906"] = 43109,
	["36901"] = 43109,
	["37921"] = 43109,
	["36904"] = 43109,
	["36907"] = 43109,
	["39970"] = 43109,
	["3358"] = 43105, --indigo
	["3821"] = 43105,
	["3819"] = 43105,
	["3818"] = 43105,
}

--a table of ink itemIDs to herb sets
local inkTable = {
	["37101"] = tier1, --ivory ink (alabaster pigment)
	["39469"] = tier1, --moonglow ink (alabaster pigment)
	["39774"] = tier2, --midnight ink (dusky pigment)
	["43115"] = tier2, --hunter's ink (verdant pigment)
	["43116"] = tier3, --lion's ink (golden pigment)
	["43117"] = tier3, --dawnstar ink (burnt pigment)
	["43118"] = tier4, --jadefire ink (emerald pigment)
	["43119"] = tier4, --royal ink (indigo pigment)
	["43120"] = tier5, --celestial ink (violet pigment)
	["43121"] = tier5, --fiery ink (Ruby Pigment)
	["43122"] = tier6, --shimmering ink (silvery pigment)
	["43123"] = tier6, --ink of the sky (Saphire Pigment)
	["43124"] = outlands, --ethereal ink (nether pigment)
	["43125"] = outlands, --darkflame ink (ebon pigment)
	["43126"] = northrend, --ink of the sea (azure pigment)
	["43127"] = northrend, -- snowfall ink (icy pigment)
}

local inksToPigments = {
	["37101"] = 39151, --ivory ink (alabaster pigment)
	["39469"] = 39151, --moonglow ink (alabaster pigment)
	["39774"] = 39334, --midnight ink (dusky pigment)
	["43115"] = 43103, --hunter's ink (verdant pigment)
	["43116"] = 39338, --lion's ink (golden pigment)
	["43117"] = 43104, --dawnstar ink (burnt pigment)
	["43118"] = 39339, --jadefire ink (emerald pigment)
	["43119"] = 43105, --royal ink (indigo pigment)
	["43120"] = 39340, --celestial ink (violet pigment)
	["43121"] = 43106, --fiery ink (Ruby Pigment)
	["43122"] = 39341, --shimmering ink (silvery pigment)
	["43123"] = 43107, --ink of the sky (Saphire Pigment)
	["43124"] = 39342, --ethereal ink (nether pigment)
	["43125"] = 43108, --darkflame ink (ebon pigment)
	["43126"] = 39343, --ink of the sea (azure pigment)
	["43127"] = 43109, -- snowfall ink (icy pigment)
}

local pigmentsToInks = {
	["39151"] = 37101, --ivory ink (alabaster pigment)
	["39151"] = 39469, --moonglow ink (alabaster pigment)
	["39334"] = 39774, --midnight ink (dusky pigment)
	["43103"] = 43115, --hunter's ink (verdant pigment)
	["39338"] = 43116, --lion's ink (golden pigment)
	["43104"] = 43117, --dawnstar ink (burnt pigment)
	["39339"] = 43118, --jadefire ink (emerald pigment)
	["43105"] = 43119, --royal ink (indigo pigment)
	["39340"] = 43120, --celestial ink (violet pigment)
	["43106"] = 43121, --fiery ink (Ruby Pigment)
	["39341"] = 43122, --shimmering ink (silvery pigment)
	["43107"] = 43123, --ink of the sky (Saphire Pigment)
	["39342"] = 43124, --ethereal ink (nether pigment)
	["43108"] = 43125, --darkflame ink (ebon pigment)
	["39343"] = 43126, --ink of the sea (azure pigment)
	["43109"] = 43127, -- snowfall ink (icy pigment)
}

local getInscriptionInfo = setmetatable({}, {
	__index = function(t, k)
		local herbset = inkTable[k]
		local cPigment = commonPigments[k]
		local rPigment = rarePigments[k]
		local n1, n2, n3, n4
		
		--if herbset is not nil then the itemID belongs to an ink
		--and that means we need to add the needed pigment
		if herbset then
			local pigment = inksToPigments[k]
			n1 = GetItemInfo(pigment)
			--make sure the item returned a name, errors scare users
			if n1 == nil then
				warnCache()
				t[k] = nil
				return nil
			end
			t[k] = strformat("|cffffffff%s\n%s|r", n1, herbset)
		end
		--if rPigment is not nil then the itemID belongs to an herb with a rare pigment result
		--this automatically means that cPigment is not nil as well
		--we add a line to the tooltip for both pigments and a line for the two inks
		if rPigment then
			local cInk = pigmentsToInks[tostring(cPigment)]
			local rInk = pigmentsToInks[tostring(rPigment)]
			--make sure the item returned a name, errors scare users
			n1, n2, n3, n4 = GetItemInfo(cPigment), GetItemInfo(cInk), GetItemInfo(rPigment), GetItemInfo(rInk)
			if n1 == nil or n2 == nil or n3 == nil or n4 == nil then
				warnCache()
				t[k] = nil
				return nil
			end
			t[k] = strformat("|cffffffff%s (%s)|r\n|cff1eff00%s (%s)|r", n1, n2, n3, n4)
		--if rPigment is nil but cPigment is not nil
		--then the itemID is for a herb that makes the first two inks
		--so we just add the pigment to the tool tip and those two inks
		elseif cPigment then
			--make sure the item returned a name, errors scare users
			n1, n2, n3 = GetItemInfo(cPigment), GetItemInfo(37101), GetItemInfo(39469)
			if n1 == nil or n2 == nil or n3 == nil then
				warnCache()
				t[k] = nil
				return nil
			end
			t[k] = strformat("|cffffffff%s\n(%s, %s)|r", n1, n2, n3)
		end
		
		return t[k]
	end
})

local function AddMillingInfo(frame, itemLink)
	local _, _, itemString = strfind(itemLink, "^|c%x+|H(.+)|h%[.+%]")
	if itemString then
		local _, itemID = strsplit(":", itemString)
		if itemID then
			if inkTable[itemID] or rarePigments[itemID] or commonPigments[itemID] then
				if MILLHELP_HEADER then
					frame:AddLine(strformat("|cffffffff%s|r", header1))
				end
				frame:AddLine(getInscriptionInfo[itemID])
			end
		end
	end
	
	frame:Show()
end

local function HookIt(tt)
	tt:HookScript("OnTooltipSetItem", function(self, ...)
		local itemLink = select(2, self:GetItem())
		if itemLink and GetItemInfo(itemLink) then
			AddMillingInfo(self, itemLink)
		end
	end)
end

HookIt(GameTooltip)
HookIt(ItemRefTooltip)
