﻿local L = AceLibrary("AceLocale-2.2"):new("MBFFu")

L:RegisterTranslations("enUS", function() return {
	["|cff1eff00Left-Click|r |cffffffffShow/Hide MBF|r"] = true,
	["|cff1eff00Shift-LeftClick|r |cffffffffShow Config Screen|r"] = true,
} end)

L:RegisterTranslations("ruRU", function() return {
	["|cff1eff00Left-Click|r |cffffffffShow/Hide MBF|r"] = "|cff1eff00ЛКМ|r |cffffffffПоказать\Скрыть MBF|r",
	["|cff1eff00Shift-LeftClick|r |cffffffffShow Config Screen|r"] = "|cff1eff00Shift-ЛКМ|r |cffffffffПоказать настройки|r",
} end)