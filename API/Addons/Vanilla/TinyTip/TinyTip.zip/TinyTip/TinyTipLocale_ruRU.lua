-- Russian localization by Lichery

if GetLocale() == 'ruRU' then
	-- TinyTipUtil
	TinyTipLocale_InitDB1		= "Пустой профиль. Настройка по умолчанию..."
	TinyTipLocale_InitDB2		= "Настройка по умолчанию."
	TinyTipLocale_InitDB3		= "Обнаружена новая версия базы данных. Миграция..."
	TinyTipLocale_InitDB4		= "Миграция завершена."
	TinyTipLocale_InitDB5		= "Готов."

	TinyTipLocale_DefaultDB1	= "Все настройки возвращены к значениям по умолчанию."
	TinyTipLocale_DefaultDB2	= "Ошибка - несоответствие версии базы данных."

	-- TinyTip core
	TinyTipLocale_Tapped		= "Tapped"
end
