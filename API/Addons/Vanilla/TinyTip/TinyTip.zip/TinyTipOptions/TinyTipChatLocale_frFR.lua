--[[ TinyTip by Thrae
-- French Localization
-- Contributors:
--]]

if GetLocale() == "frFR" then
	-- NEED TRANSLATION
end
