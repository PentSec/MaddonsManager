# UnitFramesImproved_Vanilla

This addon is now put in rest mode. The addon is now part of my complete UI addon zUI https://github.com/Ko0z/zUI 
and will continue getting updates there.

<b>Dont forget to remove "-master" at the end of the folder name when you add it to your wow/interface/addons folder.</b>

<b>New Compact Mode for those who like a slim design.</b>
<a href="https://imgur.com/fbAcAe2"><img src="https://i.imgur.com/fbAcAe2.gif" title="source: imgur.com" /></a>

<a href="https://imgur.com/KCIdJFr"><img src="https://i.imgur.com/KCIdJFr.png" title="source: imgur.com" /></a>

<b>Official release version is now available. Druid and rogues can now see some QoL improvements such as ticking energy bar and separate mana bar. Hunters can now also see some improvements such as a mirrored pet frame</b>

<b>Backport of UnitFramesImproved to Vanilla with some QoL changes like dark mode and class portraits.</b>

<b>MobHealth3 is now embedded into this addon. MAKE SURE TO DISABLE MobHealth2 etc to prevent doubled target HP/MP text!</b>

Please do report any bugs you might encounter to the issues section.
If you have suggestions or ideas you're welcome to post them in the issues section as well.

<b>COMMANDS: </b>

<b>"/ufi"</b> to show Options

<a href="https://imgur.com/PSdpTpu"><img src="https://i.imgur.com/PSdpTpu.png" title="source: imgur.com" /></a>

Improved Pet Frame feature that shows the pet happiness by color in it's healthbar.

<a href="https://imgur.com/11BNbQj"><img src="https://i.imgur.com/11BNbQj.png" title="source: imgur.com" /></a>

