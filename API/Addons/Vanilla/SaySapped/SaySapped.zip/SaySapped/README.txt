SaySapped for WoW Vanilla 1.12.1

Says "Sapped!" to alert those around you whenever a rogue saps you.

Type "/saysapped" to toggle on and off.

Author: Coax - Anathema
Original idea: Bitbyte - Icecrown