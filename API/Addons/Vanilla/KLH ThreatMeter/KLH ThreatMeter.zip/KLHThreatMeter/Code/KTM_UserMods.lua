﻿--! This module references these other modules:

--! This module is referenced by these other modules:

local mod = klhtm
local me = {}
mod.user = me

--[[
UserMods.lua

This is a framework for making extensions to klhtm.

]]


------------------------------------------------------------------------
-- 						    Broodlord's MS							  --
------------------------------------------------------------------------

--[[

This sub-addon will record the values of Broodlord's Mortal Strike, with or without Demo Shout up

... if i ever complete it. 
]]
