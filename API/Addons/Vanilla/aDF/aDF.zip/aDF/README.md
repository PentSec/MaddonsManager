# aDF
A World of Warcraft 1.12 AddOn that tracks certain debuffs on your target
- Shift click to move the frame
- /adf for options

![UIExample](https://i.imgur.com/ujrAYkr.png)
