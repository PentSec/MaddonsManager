### Revision 4 (2024/11/09)
- Add locale modules for profession names
- Add GetCraftsByProfession() API
- Fix First Aid profession name
- Fix library in-memory upgrade process

### Revision 3 (2024/11/03)
- Add new Turtle WoW recipes for Vanilla professions
- Fix craft indentation
- Update some translations

### Revision 2 (2024/11/02)
- Disable debug mode

### Revision 1 (2024/11/02)
- Release the first version
