setfenv(1, MasterTradeSkills)

MtsAddonName = "MasterTradeSkills";
MtsAddonVersion = "2.3"
