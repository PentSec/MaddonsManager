![Aero](https://i.imgur.com/gE1cje2.gif)

# Aero

Adds animations to frames.

Credit: http://www.wowinterface.com/downloads/info17946-Aero.html

## Slash commands

/aero  
/aero `<seconds>` - Set the animation duration

## Install

1. [Download Aero](https://github.com/gashole/Aero/releases/download/current/Aero.zip)
2. Extract the zip to an easy to find location such as your Desktop
3. Move the Aero folder into your AddOns folder
