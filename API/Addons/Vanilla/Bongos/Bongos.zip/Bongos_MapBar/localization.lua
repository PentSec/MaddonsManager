--[[
	Bongos Stats Localization file
--]]

BONGOS_MAPBAR_SHOW_TITLE = "Show Title"
BONGOS_MAPBAR_SHOW_ZOOM = "Show Zoom Buttons"
BONGOS_MAPBAR_SHOW_TIME = "Show Time Indicator"