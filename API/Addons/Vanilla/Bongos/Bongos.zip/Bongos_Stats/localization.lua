--[[
	Bongos Stats Localization file
--]]

BINDING_HEADER_BSTATS = "Bongos Stats";
BINDING_NAME_BSTATSTOGGLE = "Toggle Bongos Stats";

BONGOS_STATS_SHOW_FPS = "Show Framerate"
BONGOS_STATS_SHOW_MEMORY = "Show Memory"
BONGOS_STATS_SHOW_LATENCY = "Show Latency"