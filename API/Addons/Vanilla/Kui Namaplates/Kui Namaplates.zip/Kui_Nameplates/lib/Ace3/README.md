# Ace3v
Vanilla WoW AddOn Library - Ace3

The goal of this project is to bring the Ace3 into vanilla wow. The author of the original Ace3 library is the Ace3 Development team.

Project current situation:

* All basic libraries are recoded so that they can be used in vanilla WOW

* Most of the AceGUI library are recoded, need furthur tests

* Added an additional lib AceCursor which is still under development, the purpose of this library is to implement the function GetCursorInfo of retail WoW
