Auctioneer	3.9.0.1000 (Kangaroo)
$Id: README.txt 656 2005-12-26 22:09:20Z mentalpower $
-------------------------------
FROM: http://auctioneeraddon.com/

