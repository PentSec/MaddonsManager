----------------------------------------------------------------------------
-----  AddOn:			ReadySetDing								--------		----> Insert some Warcraft 3 [Steam Tank] ASCII Art here ! <----
-----  Author:			Ketho (EU-Boulderfist Alliance CHN)			--------		   http://classic.battle.net/war3/human/units/siegeengine.shtml
-----  Creation Date:	2010.01.04 (4 January 2010)					--------
-----  Text Editor:		Notepad++									--------	http://notepad-plus.sourceforge.net/
------ # Version -----------------------------------------------------------
-----  ReadySetDing								 v0.52 [2010.09.04]	--------	http://wow.curse.com/downloads/wow-addons/details/readysetding.aspx
-----  Ace3 Development Framework				  r960 [2010.07.20]	--------	http://wow.curse.com/downloads/wow-addons/details/ace3.aspx
------ # Features ----------------------------------------------------------
-----  01  Announce Time Taken for Ding								--------
-----  02  Compare Leveling Speed*									--------
------- # Index ------------------------------------------------------------
-----  01  OPTIONS AND DEFAULT VARIABLES							--------	Line   31
-----  02  OnInitialize, OnEnable, OnDisable						--------	Line  324
-----  03  CALLBACK HANDLERS										--------	Line  404
-----  04  EVENT HANDLERS											--------	Line  497
----------------------------------------------------------------------------

--	Instance of AceAddon Class
ReadySetDing = LibStub("AceAddon-3.0"):NewAddon("ReadySetDing", "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("ReadySetDing", true)

--	Upvalues / Abbreviations / File-local Scope Variables
local _G = _G -- Faster access to global table (if its used more than even once .. in our case, zero)
local iconCropped = "0:0:64:64:4:60:4:60" -- Cropped(-4 px; 56x56 px) Texture UI escape sequence -- http://www.wowwiki.com/UI_escape_sequences
local TPM_currentLevelTime; local TPM_totalTime; local lastTPM_Time; local PMC_numPartyMembers; local currentLevelTimeSnapshot; local totalLevelTimeSnapshot; local timeDing; -- event + time variables
local throttle_randomLevel = 0; local throttle_randomTime = 0; local throttle_randomExampleTimeTotal = 0; local throttle_randomIcon1 = 0; local throttle_playSound = 0; -- throttle, manage/limit flow
local randomIcon1; local randomTime; local randomTimeTotal; local randomLevel2; local playerDinged; local soundDesc;

	-----------------------------------------------
	-----  01  OPTIONS AND DEFAULT VARIABLES  -----
	-----------------------------------------------
--- Blizzard GUI Options --- http://www.wowace.com/addons/ace3/pages/ace-config-3-0-options-tables/
local optionsMain = {
    type = 'group',
	name = "\124cffADFF2FReadySet\124r|cffFFFFFFDing|r |cffB6CA00v0.52|r                                |cffFFFFFF2010.09.04|r", -- Main Menu Header
	handler = ReadySetDing,
	args = {
		toggleEnableAddOn = {
			type = "toggle",
			order = 1,
			descStyle = "no tooltip plz",
			name = "|cff71D5FFEnable AddOn|r",
			get = function(info) return ReadySetDing.db.profile.enableAddOn end,
			set = function(info, value) ReadySetDing.db.profile.enableAddOn = value
				if ReadySetDing.db.profile.enableAddOn == true then ReadySetDing:Enable() -- Turn AddOn on
				elseif ReadySetDing.db.profile.enableAddOn == false then ReadySetDing:Disable() -- Turn AddOn off
				end
			end,
		},
		toggleNormalAnnounce = {
			type = "toggle",
			order = 3,
			descStyle = "no tooltip plz",
			name = "Announce to Say / |cffA8A8FFParty|r",
			get = function(info) return ReadySetDing.db.profile.normalAnnounce end,
			set = function(info, value) ReadySetDing.db.profile.normalAnnounce = value end,
			disabled = "OptionsDisabled",
		},
		toggleGuildAnnounce = {
			type = "toggle",
			order = 5,
			descStyle = "no tooltip plz",
			name = "Announce to |cff40FF40Guild|r",
			get = function(info) return ReadySetDing.db.profile.guildAnnounce end,
			set = function(info, value) ReadySetDing.db.profile.guildAnnounce = value end,
			disabled = function()
				if ReadySetDing.db.profile.enableAddOn == false or IsInGuild() ~= 1 then return true
				else return false
				end
			end,
		},
		toggleScreenshot = {
			type = "toggle",
			order = 2,
			descStyle = "no tooltip plz",
			name = "|TInterface\\Icons\\inv_misc_spyglass_03:22:22:"..iconCropped.."|t Take Screenshot",
			get = function(info) return ReadySetDing.db.profile.Screenshot end,
			set = function(info, value) ReadySetDing.db.profile.Screenshot = value end,
			disabled = "OptionsDisabled",
		},
		toggleDingEmote = {
			type = "toggle",
			order = 4,
			desc = "\"|cffB6CA00<Player> reached a new level. DING!|r\"",
			name = "|TInterface\\Icons\\Spell_Misc_EmotionHappy:22:22:"..iconCropped.."|t |cffFFFFFFDing|r Emote",
			get = function(info) return ReadySetDing.db.profile.dingEmote end,
			set = function(info, value) ReadySetDing.db.profile.dingEmote = value end,
			disabled = "OptionsDisabled",
		},
		toggleBNetBroadcast = {
			type = "toggle",
			order = 6,
			desc = "Not sure if your |cff71D5FFReal ID|r friends would appreciate it though |cffADFF2F(^_^)|r\n\n|cff71D5FFNote:|r The previous message will be restored/|cff71D5FFbroadcasted _again_|r!",
			name = function() if GetTime() > throttle_randomIcon1 then throttle_randomIcon1 = (GetTime() + 300); local a = math.random(1, 4)
				if	   a <= 2 then randomIcon1 = "PlusManz-BattleNet" -- 64px original size; ...\Data\enGB\patch-enGB-3.MPQ\Interface\FriendsFrame\PlusManz-BattleNet.blp
				elseif a == 3 then randomIcon1 = "Battlenet-WoWicon" -- 32px original size
				elseif a == 4 then randomIcon1 = "Battlenet-Sc2icon"
			end; end; return "|TInterface\\FriendsFrame\\"..randomIcon1..":24|t Broadcast to |cff71D5FFReal ID|r"; end,
			get = function(info) return ReadySetDing.db.profile.BNetBroadcast end,
			set = function(info, value) ReadySetDing.db.profile.BNetBroadcast = value end,
			disabled = "OptionsDisabled",
		},
		inputDingMessage = {
			type = "input",
			order = 7,
			width  = "full",
			name = " ", -- If it was like "" then "usage" wouldnt appear
			usage = "\n|cff58ACFA[LEVEL]|r = Your new level\n|cff58ACFA[TIME]|r = Time taken last level\n|cff58ACFA[TOTAL]|r = Total time taken\nMake sure to press |cffF6ADC6[Enter]|r |cffFFFFFF/|r |cffF6ADC6[Okay]|r",
			get = function(info) return ReadySetDing.db.profile.dingMessage end,
			set = function(info, value) ReadySetDing.db.profile.dingMessage = value
				if string.trim(ReadySetDing.db.profile.dingMessage) == "" then ReadySetDing.db.profile.dingMessage = "Ding! Level [LEVEL] in [TIME]"
				end RSD_validateDingMessage() -- Validate
			end,
			disabled = "OptionsDisabled",
		},
		descriptionExample = {
			type = "description",
			order = 9,
			name = function() return "|cffB6CA00Example:|r  "..RSD_ReplaceText(ReadySetDing.db.profile.dingMessage, "exampleDingMsg").."\n"; end,
		},
		headerTimePlayed = {
			type = "header",
			order = 10,
			name = function() if not TPM_currentLevelTime then return "** |cffBF0D0D[No /played Time Data Found]|r **" -- AddOn was turned off; no "TIME_PLAYED_MSG" event
				else return "|cffFFFFFF@|r |cff71D5FFLevel "..ReadySetDing.db.char.playerLevel.."|r|cffFFFFFF:|r  |cffB6CA00"..RSD_TimetoString(TPM_currentLevelTime + (GetTime() - lastTPM_Time)).."|r      |cffFFFFFFTotal:|r  |cff71D5FF"..RSD_TimetoString(TPM_totalTime + (GetTime() - lastTPM_Time)).."|r"
			end; end,
		},
		descriptionDingTimes = {
			type = "description",
			order = 11,
			name = function()
				if not ReadySetDing.db.char.levelHistoryStrJoin then ReadySetDing.db.char.levelHistoryStrJoin = "** |cffF6ADC6[No Levelup Data Found]|r **"; end
				if not ReadySetDing.db.char.levelHistory then ReadySetDing.db.char.levelHistory = {}; end -- Define array
				for i = 2, 80 do
					if ReadySetDing.db.char.timeDingList[i] then
						for j = 1, 20 do
							if not ReadySetDing.db.char.levelHistory[j] then ReadySetDing.db.char.levelHistory[j] = ""; end
							if ReadySetDing.db.char.levelCounterA == j then ReadySetDing.db.char.levelHistory[j] = "Level "..(i-1).." - |cff71D5FF"..i.."|r:  |cffB6CA00"..RSD_TimetoString(ReadySetDing.db.char.timeDingList[i]).."|r        Total:  |cff71D5FF"..RSD_TimetoString(ReadySetDing.db.char.totalTimeList[i]).."|r"
							end
						end
						ReadySetDing.db.char.levelHistoryStrJoin = string.join("\n", -- 1 long string with linebreaks( \n ) as delimiter
							ReadySetDing.db.char.levelHistory[1], ReadySetDing.db.char.levelHistory[2], ReadySetDing.db.char.levelHistory[3], ReadySetDing.db.char.levelHistory[4], ReadySetDing.db.char.levelHistory[5],
							ReadySetDing.db.char.levelHistory[6], ReadySetDing.db.char.levelHistory[7], ReadySetDing.db.char.levelHistory[8], ReadySetDing.db.char.levelHistory[9], ReadySetDing.db.char.levelHistory[10],
							ReadySetDing.db.char.levelHistory[11], ReadySetDing.db.char.levelHistory[12], ReadySetDing.db.char.levelHistory[13], ReadySetDing.db.char.levelHistory[14], ReadySetDing.db.char.levelHistory[15],
							ReadySetDing.db.char.levelHistory[16], ReadySetDing.db.char.levelHistory[17], ReadySetDing.db.char.levelHistory[18], ReadySetDing.db.char.levelHistory[19])
					end
				end
			return ReadySetDing.db.char.levelHistoryStrJoin
			end,
		},
	},
}

local optionsAdvanced = {
	type = "group",
	name = "",
	handler = ReadySetDing,
	args = {
		toggleSkipLevelAchievement = {
			type = "toggle",
			order = 1,
			width = "full",
			desc = "Skips announce for |cffB6CA00Level 10 / 20 / 30 / 40 / 50 / 60 / 70 / 80 / 85|r",
			name = "|TInterface\\Icons\\Achievement_Level_20:22:22:"..iconCropped.."|t |cffFFE4E1Skip Announce|r @ |cffFFFF00Level Achievements|r",
			get = function(info) return ReadySetDing.db.profile.skipLevelAchievement end,
			set = function(info, value) ReadySetDing.db.profile.skipLevelAchievement = value end,
			disabled = "OptionsDisabled",
		},
		toggleDebug = {
 			type = "toggle",
			order = 2,
			desc = "Gives some spammy feedback ...\nPlease use |cff71D5FFSwatter|r from |cff71D5FFAuctioneer|r for sending error logs",
			name = "|TInterface\\Icons\\INV_Misc_QuestionMark:22:22:"..iconCropped.."|t |cff71D5FFDebug Mode|r",
			get = function(info) return ReadySetDing.db.profile.Debug end,
			set = function(info, value) ReadySetDing.db.profile.Debug = value end,
			disabled = "OptionsDisabled",
		},
		rangeScreenshotDelay = {
			type = "range",
			order = 3,
			desc = "|cff71D5FFsoftMax|r = 2 seconds (|cffB6CA00Slider Input|r)\n|cff71D5FFmax|r = 60 seconds (|cffB6CA00Manual Input|r)",
			name = "|TInterface\\Icons\\inv_misc_spyglass_03:18:18:"..iconCropped.."|t |cffFFFFFF<Screenshot>|r Delay",
			get = function(info) return ReadySetDing.db.profile.screenshotDelay end,
			set = function(info, value) ReadySetDing.db.profile.screenshotDelay = value end,
			min = 0, softMin = 0,
			max = 60, softMax = 2,
			disabled = function() if ReadySetDing.db.profile.enableAddOn == false or ReadySetDing.db.profile.Screenshot == false then return true; else return false; end; end,
		},
		executePrintTimes = {
			type = "execute",
			order = 4,
			name = "|TInterface\\Icons\\INV_Misc_Note_01:18:18:"..iconCropped.."|t Print |cffFFFFFFDing Times|r",
			func = function()
				if not ReadySetDing.db.char.timeDingList or #(ReadySetDing.db.char.timeDingList) == 0 then ChatFrame1:AddMessage("|cffADFF2FReadySet|r|cffFFFFFFDing|r: ** |cffF6ADC6[No Levelup Data Found]|r **") -- http://www.wowwiki.com/API_getn
				end
				for i = 2, 80 do
					if ReadySetDing.db.char.timeDingList[i] then ChatFrame1:AddMessage("|cffADFF2FReadySet|r|cffFFFFFFDing|r: Level "..(i-1).." - |cff71D5FF"..i.."|r: |cffB6CA00"..RSD_TimetoString(ReadySetDing.db.char.timeDingList[i]).."|r   Total: |cff71D5FF"..RSD_TimetoString(ReadySetDing.db.char.totalTimeList[i]).."|r")
					end
				end
			end,
			disabled = "OptionsDisabled",
		},
		executePlaySound = {
			type = "execute",
			order = 5,
			name = "|TSPELLS\\HOLIDAYS\\Heart:18|t Play |cffADFF2F*|r|cffF6ADC6Sound|r|cffADFF2F*|r", -- ...\Data\common.MPQ\SPELLS\HOLIDAYS\Heart.blp
			func = function() -- yeah .. well .. was just a little bored, maybe a little easter egg \(n_n)/
				if GetTime() > throttle_playSound then throttle_playSound = (GetTime() + 3);
					local randomSound1 = math.random(1, 11); local descEnd = "|r|cffB6CA00.wav\")|r"; local descInterface = "/run |cffB6CA00PlaySoundFile(\"Sound\\\\Interface\\\\|r|cff71D5FF"; local descSpell = "/run |cffB6CA00PlaySoundFile(\"Sound\\\\Spells\\\\|r|cff71D5FF" -- "\\\\" -> \\
					if randomSound1 <= 10 then local randomSound2 = math.random(1, 10); -- For some reason the color UI escape code gets broken off by the 2nd one in soundDesc; had to do it again after that 2nd one
						if	   randomSound2 >= 1 and randomSound2 <= 3 then PlaySoundFile("Sound\\Interface\\LevelUp.wav"); soundDesc = descInterface.."LevelUp"..descEnd; -- ...\Data\common.MPQ\Sound\Interface\LevelUp.wav -- Player Leveled Up
						elseif randomSound2 >= 4 and randomSound2 <= 6 then PlaySoundFile("Sound\\Interface\\iQuestComplete.wav"); soundDesc = descInterface.."iQuestComplete"..descEnd; -- ...\Data\common.MPQ\Sound\Interface\iQuestComplete.wav -- Quest Comepleted
						elseif randomSound2 >= 7 and randomSound2 <= 8 then PlaySoundFile("Sound\\Spells\\AchievmentSound1.wav"); soundDesc = descSpell.."AchievmentSound1"..descEnd; -- ...\Data\common.MPQ\Sound\Spells\AchievmentSound1.wav -- Achievement Gained
						elseif randomSound2 >= 9 and randomSound2 <= 10 then PlaySoundFile("Sound\\Spells\\Resurrection.wav"); soundDesc = descSpell.."Resurrection"..descEnd; -- ...\Data\common.MPQ\Sound\Spells\Resurrection.wav -- Resurrection
						end
					else local randomSound3 = math.random(1, 4)
						if	   randomSound3 == 1 then local randomSound4 = math.random(1, 3); local a = "Sound\\Spells\\"
							if	   randomSound4 == 1 then PlaySoundFile(a.."ValentineFirework.wav"); soundDesc = descSpell.."ValentineFirework"..descEnd; -- ...\Data\common.MPQ\Sound\Spells\ValentineFirework.wav
							elseif randomSound4 == 2 then PlaySoundFile(a.."valentines_brokenheart.wav"); soundDesc = descSpell.."valentines_brokenheart"..descEnd;
							elseif randomSound4 == 3 then PlaySoundFile(a.."valentines_lookingforloveheart.wav"); soundDesc = descSpell.."valentines_lookingforloveheart"..descEnd;
							end
						elseif randomSound3 == 2 then local randomSound5 = math.random(1, 8); local b = "Sound\\Character\\BloodElf\\BloodElfFemale"; local descBelf = "/run |cffB6CA00PlaySoundFile(\"Sound\\\\Character\\\\BloodElf\\\\BloodElfFemale|r|cff71D5FF"
							if	   randomSound5 == 1 then PlaySoundFile(b.."Flirt01.wav"); soundDesc = descBelf.."Flirt01"..descEnd; -- ...\Data\enGB\patch-enGB.MPQ\Sound\Character\BloodElf\BloodElfFemaleFlirt01.wav
							elseif randomSound5 == 2 then PlaySoundFile(b.."Flirt02.wav"); soundDesc = descBelf.."Flirt02"..descEnd;
							elseif randomSound5 == 3 then PlaySoundFile(b.."Flirt04.wav"); soundDesc = descBelf.."Flirt04"..descEnd;
							elseif randomSound5 == 4 then PlaySoundFile(b.."Flirt05.wav"); soundDesc = descBelf.."Flirt05"..descEnd;
							elseif randomSound5 == 5 then PlaySoundFile(b.."Flirt10.wav"); soundDesc = descBelf.."Flirt10"..descEnd;
							elseif randomSound5 == 6 then PlaySoundFile(b.."Flirt11.wav"); soundDesc = descBelf.."Flirt11"..descEnd;
							elseif randomSound5 == 7 then PlaySoundFile(b.."Flirt13.wav"); soundDesc = descBelf.."Flirt13"..descEnd;
							elseif randomSound5 == 8 then PlaySoundFile(b.."Beg01.wav"); soundDesc = descBelf.."Beg01"..descEnd;
							end
						elseif randomSound3 == 3 then PlaySoundFile("Sound\\Creature\\Paletress\\AC_Paletress_Death01.wav"); soundDesc = "/run |cffB6CA00PlaySoundFile(\"Sound\\\\Creature\\\\Paletress\\\\|r|cff71D5FFAC_Paletress_Death01"..descEnd; -- ...\Data\enGB\patch-enGB.MPQ\Sound\Creature\Paletress\AC_Paletress_Death01.wav
						elseif randomSound3 == 4 then local randomSound6 = math.random(1, 8); local c = "Sound\\Creature\\Paletress\\AC_Paletress_Wound"; local descPaletress = "/run |cffB6CA00PlaySoundFile(\"Sound\\\\Creature\\\\Paletress\\\\|r|cff71D5FF"
							if	   randomSound6 == 1 then PlaySoundFile(c.."Light03.wav"); soundDesc = descPaletress.."****03"..descEnd;
							elseif randomSound6 == 2 then PlaySoundFile(c.."Medium01.wav"); soundDesc = descPaletress.."****01"..descEnd;
							elseif randomSound6 == 3 then PlaySoundFile(c.."Heavy01.wav"); soundDesc = descPaletress.."****01"..descEnd;
							elseif randomSound6 == 4 then PlaySoundFile(c.."Heavy02.wav"); soundDesc = descPaletress.."****02"..descEnd;
							elseif randomSound6 == 5 then PlaySoundFile(c.."Heavy03.wav"); soundDesc = descPaletress.."****03"..descEnd;
							elseif randomSound6 == 6 then PlaySoundFile(c.."Critical01.wav"); soundDesc = descPaletress.."****01"..descEnd;
							elseif randomSound6 == 7 then PlaySoundFile(c.."Critical02.wav"); soundDesc = descPaletress.."****02"..descEnd;
							elseif randomSound6 == 8 then PlaySoundFile(c.."Critical03.wav"); soundDesc = descPaletress.."****03"..descEnd;
							end
						end
					end
				end
			end,
			disabled = "OptionsDisabled",
		},
		descriptionPlaySound = {
			type = "description",
			order = 6,
			name = function() if GetTime() < throttle_playSound then return soundDesc else return ""; end; end, -- Sound Path Description
		},
		header01 = {
			type = "header",
			order = 7,
			name = "|cffADFF2FReadySet|r|cffFFFFFFDing|r by |cffFFFFFFKetho|r @ |cffB6CA00EU-Boulderfist|r",
		},
		descriptionCommands = {
			type = "description",
			order = 8,
			name = "|cffB6CA00Commands:|r |cff57A3FF/rsd|r, |cff57A3FF/readysetding|r",
		},
		descriptionAddOn = {
			type = "description",
			order = 9, -- the UI escape sequence gets broken off a lot down here ...
			name = "\n|cff87CEFAhttp://wow.|r|cffADFF2Fcurse|r|cff87CEFA.com/downloads/wow-addons/details/readysetding.aspx\nhttp://www.|r|cffADFF2Fwowinterface|r|cff87CEFA.com/downloads/info16220-ReadySetDing.html|r\nOfficial Thread: |cff87CEFAhttp://forums.|cffADFF2Fwowace|r|cff87CEFA.com/showthread.php?t=18511|r",
		},
		descriptionToDo = {
			type = "description",
			order = 10,
			name = "\n|cffB6CA00v0.52|r: Fixed Table of Contents (.TOC) Title; Added ReadySet7 Images\n\n|cffB6CA00To Do|r |cff71D5FFv0.6|r: Locales, Leveling Speed & Guild Member's Levels, Extra Custom Ding Message <Variables>\n\n\n\n\n\n\n",
		},
		descriptionIcon = {
			type = "description",
			order = 11,
			name = function() local a = "          "; if ReadySetDing.db.char.playerFaction == "Alliance" then return "|TInterface\\AddOns\\ReadySetDing\\Images\\Windows7:64:64:0:-60|t |TInterface\\AddOns\\ReadySetDing\\Images\\ReadySet7:32:128:0:-95|t"..a..a..a..a.."|TInterface\\FriendsFrame\\PlusManz-Alliance:96:96:25:-15|t" -- 64px original size; ...\Data\enGB\patch-enGB-3.MPQ\Interface\FriendsFrame\PlusManz-Alliance.blp
				elseif ReadySetDing.db.char.playerFaction == "Horde" then return "|TInterface\\AddOns\\ReadySetDing\\Images\\Windows7:64:64:0:-60|t |TInterface\\AddOns\\ReadySetDing\\Images\\ReadySet7:32:128:0:-95|t"..a..a..a..a.."|TInterface\\FriendsFrame\\PlusManz-Horde:96:96:25:-15|t"; end; end, -- spacing for design purpose
		},
	},
}

local optionsProfiles = { -- How to not show Profiles in a "group"? Its always shown in a tree/select/tab group .. then it gets a dark background
	type = "group",
	name = "",
	args = {
		profiles = {
			type = "group",
			name = "",
			inline = true,
			args = {
				profiles = {
					type = "group",
					name = "",
				},
			},
		},
	},
}

--	Blizzard GUI Defaults
local defaults = {
	profile = { -- "ReadySetDing.db.defaults.profile[]"
		enableAddOn = true,
		normalAnnounce = true,
		guildAnnounce = false,
		Screenshot = false,
		dingEmote = false,
		BNetBroadcast = false,
		dingMessage = "Ding! Level [LEVEL] in [TIME]",
		skipLevelAchievement = false,
		Debug = false, -- /run ReadySetDing.db.defaults.profile.Debug = true -- For Debug purpose
		screenshotDelay = 1,
	}, -- Shouldnt use an "execute" button option with "ReadySetDing.db:ResetDB("Default")" because that would also delete the preciousss Level Time data; Also cant use "ReadySetDing.db.profile:ResetDB("Default")" [Error: attempt to call method 'ResetDB' (a nil value)]
}

	--------------------------------------------------
	-----  02 OnInitialize, OnEnable, OnDisable  ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- 
	--------------------------------------------------
function ReadySetDing:OnInitialize() -- Called when the addon is loaded
--	Creates a new database object that can be used to handle database settings and profiles -- http://www.wowace.com/addons/ace3/pages/api/ace-db-3-0/
	self.db = LibStub("AceDB-3.0"):New("ReadySetDingDB", defaults, "Default")

--	Register a option table with the AceConfig registry -- http://www.wowace.com/addons/ace3/pages/api/ace-config-3-0/
	local optionsMainName = "Ready|cffADFF2FSet|r|cffFFFFFFDing|r  |TInterface\\Icons\\Spell_Holy_BorrowedTime:18:18:"..iconCropped.."|t"
	LibStub("AceConfig-3.0"):RegisterOptionsTable("appReadySetDing", optionsMain) -- Slash commands here are excluded
	self.optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("appReadySetDing", optionsMainName) -- Position: In Blizzard AddOn Options List; -- "self.optionsFrame" used for "InterfaceOptionsFrame_OpenToCategory"

--	Register an options table with the config registry -- http://www.wowace.com/addons/ace3/pages/api/ace-config-registry-3-0/
	local ACR = LibStub("AceConfigRegistry-3.0")
	ACR:RegisterOptionsTable("appRSD_Advanced", optionsAdvanced) -- LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable("appRSD_Advanced", optionsAdvanced)
	ACR:RegisterOptionsTable("appRSD_Profiles", optionsProfiles)

--	Add an option table into the Blizzard Interface Options panel -- http://www.wowace.com/addons/ace3/pages/api/ace-config-dialog-3-0/	
	local ACD = LibStub("AceConfigDialog-3.0")
	ACD:AddToBlizOptions("appRSD_Advanced", "|TInterface\\Icons\\Trade_Engineering:18:18:"..iconCropped.."|t Advanced", optionsMainName)
	ACD:AddToBlizOptions("appRSD_Profiles", "|TInterface\\Icons\\INV_Misc_Note_01:18:18:"..iconCropped.."|t Profiles", optionsMainName)
	
--	Get/Create a option table that you can use in your addon to control the profiles of AceDB-3.0 -- http://www.wowace.com/addons/ace3/pages/api/ace-dboptions-3-0/
	optionsProfiles.args.profiles.args.profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db) -- Dont rly understand the "group" it creates

--	Register chat commands -- http://www.wowace.com/addons/ace3/pages/api/ace-console-3-0/
	self:RegisterChatCommand("rsd", "slashCommand")
	self:RegisterChatCommand("readyset", "slashCommand")
	self:RegisterChatCommand("readysetding", "slashCommand")
	
--	Player Info; In the rare event the AddOn was set to Disabled on a profile before it even got to "OnEnable()" once; i.e. "self.db.profile.enableAddOn == false" and "self.db.char.playerLevel == nil"
	self.db.char.playerLevel = UnitLevel("player") -- Level of Player
	self.db.char.playerFaction, _ = UnitFactionGroup("player") -- Faction of Player

	if self.db.profile.enableAddOn == false then
		if self.db.profile.Debug == true then self:Print("Initialized, Disabling... (|cff71D5FFOnInitialize|r)") -- For Debug purpose
		end
		self:Disable() -- Turn AddOn off again at start if it was turned off at login/reload
	elseif self.db.profile.enableAddOn == true then
		if self.db.profile.Debug == true then self:Print("Initialized, Enabling... (|cff71D5FFOnInitialize|r)");
		end
	end
end

function ReadySetDing:OnEnable() -- Called when the addon is enabled
--	Subscribe to Events
	self:RegisterEvent("PLAYER_LEVEL_UP")
	self:RegisterEvent("TIME_PLAYED_MSG")
	self:RegisterEvent("PARTY_MEMBERS_CHANGED")
--	self:RegisterEvent("GUILD_ROSTER_UPDATE")

--	self.db.char.playerName = UnitName("player") -- Name of Player
--	local _, englishClassPlayer = UnitClass("player") -- Class of Player
--	local numGuildMembers = GetNumGuildMembers() -- Number of Guildmember
	
	self:ScheduleTimer(function() -- http://www.wowace.com/addons/ace3/pages/api/ace-timer-3-0/
		if self.db.profile.enableAddOn == true and not TPM_totalTime then RequestTimePlayed() -- If ReadySetDing was off at start and enabled afterwards, it has to request /played again, since it was Disabled() ...
			if self.db.profile.Debug == true then self:Print("Could not find the \"|cff71D5FFTIME_PLAYED_MSG|r\" evenr within the 7 seconds delay. Calling \"|cff71D5FFRequestTimePlayed()|r\"... (|cff71D5FFOnEnable|r)")
			end
		elseif self.db.profile.enableAddOn == true and TPM_totalTime and self.db.profile.Debug == true then
			self:Print("\"|cff71D5FFTIME_PLAYED_MSG|r\" event fired within the 7 seconds delay. Skipped \"|cff71D5FFRequestTimePlayed()|r\". (|cff71D5FFOnEnable|r)")
		end
	end, 7) -- Delay the request for 7seconds(slow computers need 3-5s), so that it waits for other AddOns first that want to request /played

--	Settings / Fixes
	if GetCVar("cameraDistanceMax") == "50" and self.db.profile.cameraDistanceMaxNotification ~= true then self.db.profile.cameraDistanceMaxNotification = true; -- Only show notification message once
		ChatFrame1:AddMessage("|cffFBDB00ReadySet|cffFFFFFFDing|r|r: Your |cff71D5FFCamera Distance|r is at the maximum distance( |cffB6CA0050|r ). Previously this AddOn forced you to be at the maximum distance. You can choose to reset it to default with |cffB6CA00/console cameraDistanceMax 15|r")
	end -- for morpheusdead  http://forums.wowace.com/showthread.php?p=305951

	if not self.db.char.timeDingList then self.db.char.timeDingList = {}; end -- Define array first
	if not self.db.char.totalTimeList then self.db.char.totalTimeList = {}; end -- It will be called from a lot of different places in this addon early on, so this place(OnEnable) should be ok?
	if self.db.profile.Debug == true then self:Print("Enabled (|cff71D5FFOnEnable|r)"); -- For Debug purpose
	end
end 

function ReadySetDing:OnDisable() -- Called when the addon is disabled
	self:UnregisterAllEvents() -- Unsubscribe from all Events
	if self.db.profile.Debug == true then self:Print("Disabled (|cff71D5FFOnDisable|r)"); end -- For Debug purpose
end

	-----------------------------------
	-----  03  CALLBACK HANDLERS  ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- 
	-----------------------------------

function ReadySetDing:slashCommand(input) -- Process the slash command ('input' contains whatever follows the slash command)
	if not input or string.trim(input) == "" then InterfaceOptionsFrame_OpenToCategory(self.optionsFrame)
	else InterfaceOptionsFrame_OpenToCategory(self.optionsFrame) -- Instead of: /readysetding "ChatCommand", it will always go to options, since I don't understand "HandleCommand" ..
	--	LibStub("AceConfigCmd-3.0").HandleCommand(ReadySetDing, "rsd", "appReadySetDing") -- no idea how this works -- http://www.wowace.com/addons/ace3/pages/api/ace-config-cmd-3-0/
	end
end

function ReadySetDing:OptionsDisabled() -- Disables(gray out) options when AddOn disabled
	if ReadySetDing.db.profile.enableAddOn == true then return false; else return true; end
end

function RSD_randomTime(info)
	if info == "exampleTimeTotal" then if GetTime() > throttle_randomExampleTimeTotal then throttle_randomExampleTimeTotal = (GetTime() + 60); randomTimeTotal = math.random(86400, 864000); end -- Between 1day and 10days
	else if GetTime() > throttle_randomTime then throttle_randomTime = (GetTime() + 60); randomTime = math.random(600, 14400); end; -- Between 10min and 4hours
	end
	if info == "exampleTimeTotal" then return randomTimeTotal; else return randomTime; end
end

function RSD_randomLevel()
	if GetTime() > throttle_randomLevel then throttle_randomLevel = (GetTime() + 60); local expansionLevel = GetAccountExpansionLevel()
		if	   expansionLevel == 3 then randomLevel2 = math.random(ReadySetDing.db.char.playerLevel, 85); -- Cataclysm
		elseif expansionLevel == 2 then randomLevel2 = math.random(ReadySetDing.db.char.playerLevel, 80); -- Wrath of the Lich King
		elseif expansionLevel == 1 then randomLevel2 = math.random(ReadySetDing.db.char.playerLevel, 70); -- The Burning Crusade
		elseif expansionLevel == 0 then randomLevel2 = math.random(ReadySetDing.db.char.playerLevel, 60); -- Classic / Vanilla
		end
	end return randomLevel2
end

function RSD_Screenshot() -- A little)(1-2seconds) delay to show the LevelUp animation and Ding message bubble
	if ReadySetDing.db.profile.Screenshot == true then ReadySetDing:ScheduleTimer(function() Screenshot(); end, ReadySetDing.db.profile.screenshotDelay); end
end

function RSD_validateDingMessage() -- No need for any input variables into the function, since theres only 1 single message to be validated
	local errorLevel; local errorTime; -- for [2010.05.23 WoWInterface: Nari] "Nice addon, but please make so that you dont have to put [TIME] and [LEVEL] in Ding Message"
	if string.find(ReadySetDing.db.profile.dingMessage, "%[LEVEL%]") == nil and string.find(ReadySetDing.db.profile.dingMessage, "%[level%]") == nil and string.find(ReadySetDing.db.profile.dingMessage, "%[Level%]") == nil then errorLevel = "|cff69CCF0[LEVEL]|r" else errorLevel = ""; end
	if string.find(ReadySetDing.db.profile.dingMessage, "%[TIME%]") == nil and string.find(ReadySetDing.db.profile.dingMessage, "%[time%]") == nil and string.find(ReadySetDing.db.profile.dingMessage, "%[Time]") == nil then errorTime = " |cff69CCF0[TIME]|r" else errorTime = ""; end
	if errorLevel ~= "" or errorTime ~= "" then ChatFrame1:AddMessage("|cffADFF2FReadySet|r|cffFFFFFFDing|r |cffFF0000Error:|r "..errorLevel..errorTime.." not found. Please ignore this if you choose to exclude it/them"); end -- yes, im still a noob (=.-)\
end

function RSD_ReplaceText(msg, msgtype) -- Maybe should try to learn this awesome ["dont use so damn much variables"] method ...
	if msgtype == "exampleDingMsg" then
		local exampleDingMsg1a = string.gsub(ReadySetDing.db.profile.dingMessage,"%[LEVEL%]", "|cffADFF2F"..RSD_randomLevel().."|r"); local exampleDingMsg1b = string.gsub(exampleDingMsg1a,"%[level%]", "|cffADFF2F"..RSD_randomLevel().."|r")
		local exampleDingMsg1c = string.gsub(exampleDingMsg1b,"%[Level%]", "|cffADFF2F"..RSD_randomLevel().."|r"); local exampleDingMsg2a = string.gsub(exampleDingMsg1c,"%[TIME%]", "|cff71D5FF"..RSD_TimetoString(RSD_randomTime()).."|r")
		local exampleDingMsg2b = string.gsub(exampleDingMsg2a,"%[time%]", "|cff71D5FF"..RSD_TimetoString(RSD_randomTime()).."|r"); local exampleDingMsg2c = string.gsub(exampleDingMsg2b,"%[Time%]", "|cff71D5FF"..RSD_TimetoString(RSD_randomTime()).."|r")
		local exampleDingMsg3a = string.gsub(exampleDingMsg2c,"%[TOTAL%]", "|cffB6CA00"..RSD_TimetoString(RSD_randomTime("exampleTimeTotal")).."|r"); local exampleDingMsg3b = string.gsub(exampleDingMsg3a,"%[total%]", "|cffB6CA00"..RSD_TimetoString(RSD_randomTime("exampleTimeTotal")).."|r");
		local exampleDingMsg3c = string.gsub(exampleDingMsg3b,"%[Total%]", "|cffB6CA00"..RSD_TimetoString(RSD_randomTime("exampleTimeTotal")).."|r")
		return exampleDingMsg3c	
	else
		local dingMsg1a = string.gsub(ReadySetDing.db.profile.dingMessage,"%[LEVEL%]", PLU_level); local dingMsg1b = string.gsub(dingMsg1a,"%[level%]", PLU_level); local dingMsg1c = string.gsub(dingMsg1b,"%[Level%]", PLU_level)
		local dingMsg2a = string.gsub(dingMsg1c,"%[TIME%]", RSD_TimetoString(timeDing)); local dingMsg2b = string.gsub(dingMsg2a,"%[time%]", RSD_TimetoString(timeDing)); local dingMsg2c = string.gsub(dingMsg2b,"%[Time%]", RSD_TimetoString(timeDing))
		local dingMsg3a = string.gsub(dingMsg2c,"%[TOTAL%]", RSD_TimetoString(TPM_totalTime)); local dingMsg3b = string.gsub(dingMsg3a,"%[total%]", RSD_TimetoString(TPM_totalTime)); local dingMsg3c = string.gsub(dingMsg3b,"%[Total%]", RSD_TimetoString(TPM_totalTime))
		return dingMsg3c;
	end
end

function RSD_TimetoString(time)
	local seconds = mod(floor(time),60)
	local minutes = mod(floor(time/60),60)
	local hours = mod(floor(time/3600),24)
	local days = floor(time/86400)
	if time >= 0 and time < 60 then
		if	   seconds > 1	then return seconds.." seconds" -- Recruit-a-Friend(RAF) level granting ..?
		elseif seconds == 1 then return seconds.." second"
		elseif seconds == 0 then return "an infinitesimal amount of time"; end -- I like PHD Comics (n_n) [2010.08.20 Instantaneous Property]
	elseif time >= 60 and time < 3600 then -- Should not use the operator in "~= 1" (not specific enough), but "> 1" or ">= 2" instead
		if	   minutes >= 2 and seconds >= 2  then return minutes.." minutes, "..seconds.." seconds" -- 2 most significant Units of Time
		elseif minutes == 1 and seconds >= 2  then return minutes.." minute, "..seconds.." seconds"
		elseif minutes >= 2 and seconds == 1 then return minutes.." minutes, "..seconds.." second"
		elseif minutes == 1 and seconds == 1 then return minutes.." minute, "..seconds.." second"
		elseif minutes == 1 and seconds == 0 then return minutes.." minute"
		elseif minutes >= 2 and seconds == 0 then return minutes.." minutes"; end
	elseif time >= 3600 and time < 86400 then
		if	   hours >= 2 and minutes >= 2  then return hours.." hours, "..minutes.." minutes"
		elseif hours == 1 and minutes >= 2  then return hours.." hour, "..minutes.." minutes"
		elseif hours >= 2 and minutes == 1 then return hours.." hours, "..minutes.." minute"
		elseif hours == 1 and minutes == 1 then return hours.." hour, "..minutes.." minute"
		elseif hours == 1 and minutes == 0 then return hours.." hour"
		elseif hours >= 2 and minutes == 0 then return hours.." hours"; end
	elseif time >= 86400 then
		if	   days >= 2 and hours >= 2	then return days.." days, "..hours.." hours"
		elseif days == 1 and hours >= 2	then return days.." day, "..hours.." hours"
		elseif days >= 2 and hours == 1 then return days.." days, "..hours.." hour"
		elseif days == 1 and hours == 1 then return days.." day, "..hours.." hour"
		elseif days == 1 and hours == 0 then return days.." day"
		elseif days >= 2 and hours == 0 then return days.." days"; end
	elseif time < 0 then return "|cffFF6347[Error:|r Time is Negative|cffFF6347]|r"
	end
end

	--------------------------------
	-----  04  EVENT HANDLERS  ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- -----  ----- 
	--------------------------------
function ReadySetDing:PLAYER_LEVEL_UP(event, ...)
	PLU_level, _, _, _, _, _, _, _, _ = select(1, ...) -- http://www.wowwiki.com/API_select
	playerDinged = true; RequestTimePlayed() -- /played -> "TIME_PLAYED_MSG" event
	if not self.db.char.levelCounterA or self.db.char.levelCounterA > 19 then self.db.char.levelCounterA = 0 -- Resets if leveled 20+ times
		if self.db.profile.Debug == true then self:Print("The LevelUp Counter doesn't exist yet, or exceeded 19; Changed back to 1."); end
	end self.db.char.levelCounterB = self.db.char.levelCounterA + 1; self.db.char.levelCounterA = self.db.char.levelCounterB
end

function ReadySetDing:TIME_PLAYED_MSG(event, ...)
	TPM_totalTime, TPM_currentLevelTime = select(1, ...); lastTPM_Time = GetTime()
	if playerDinged ~= true then currentLevelTimeSnapshot = TPM_currentLevelTime; totalLevelTimeSnapshot = TPM_totalTime -- Observe / Take a snapshot of the time
	elseif playerDinged == true and (TPM_currentLevelTime >= 0 and TPM_currentLevelTime <= 5) then -- 5 seconds grace period wherein the AddOn thinks the player has recently dinged
	--	01  First take the time played at the current level at any point observed (currentLevelTimeSnapshot)
	--	02	Then the difference between the Total Time @ LevelUp and the last Total Time observed; That is the other amount of time needed
		timeDing = currentLevelTimeSnapshot + (TPM_totalTime - totalLevelTimeSnapshot) -- [Time this Level @ Observation] + ([Total Time @ Ding] - [Total Time @ Observation])
		currentLevelTimeSnapshot = TPM_currentLevelTime; totalLevelTimeSnapshot = TPM_totalTime; playerDinged = false -- Refresh variables etc, otherwise the next LevelUp would be wrong
		if (self.db.profile.skipLevelAchievement == true and (string.sub(PLU_level, 2, 2) == "0" or PLU_level == 85)) or self.db.profile.skipLevelAchievement == false then -- [Skip Level Achievements] Condition
			if (select(2, IsInInstance())) == "none" and self.db.profile.normalAnnounce == true then
				if PMC_numPartyMembers and PMC_numPartyMembers >= 1 then SendChatMessage(RSD_ReplaceText(self.db.profile.dingMessage), "PARTY"); -- [Normal Announce: Party] Feature; find out first if in a party
				else SendChatMessage(RSD_ReplaceText(self.db.profile.dingMessage), "SAY"); -- [Normal Announce: Say] Feature
				end
			elseif (select(2, IsInInstance())) == "party" and self.db.profile.normalAnnounce == true then SendChatMessage(RSD_ReplaceText(self.db.profile.dingMessage), "PARTY"); -- [Normal Announce: Instance Party] Feature
			elseif (select(2, IsInInstance())) == "raid" and self.db.profile.normalAnnounce == true then SendChatMessage(RSD_ReplaceText(self.db.profile.dingMessage), "RAID"); -- [Normal Announce: Raid] Feature
			elseif (select(2, IsInInstance())) == "pvp" and self.db.profile.normalAnnounce == true then SendChatMessage(RSD_ReplaceText(self.db.profile.dingMessage), "BATTLEGROUND"); -- [Normal Announce: Battleground] Feature
			end
			if self.db.profile.guildAnnounce == true and IsInGuild() == 1 then SendChatMessage(RSD_ReplaceText(self.db.profile.dingMessage), "GUILD"); end -- Guild Announce Feature
			if self.db.profile.Screenshot == true then RSD_Screenshot(); end -- Screenshot Feature
			if self.db.profile.dingEmote == true then DoEmote("ding", "none"); end -- Ding Emote Feature
			if self.db.profile.BNetBroadcast == true then local broadcastMsg = (select(3, BNGetInfo())); BNSetCustomMessage(RSD_ReplaceText(self.db.profile.dingMessage)); BNSetCustomMessage(broadcastMsg); end -- Real ID Broadcast Feature -- Also try make a WoWWiki API stub for it ..\
		self.db.char.playerLevel = UnitLevel("player") -- Refresh Level of Player for accurate data for "RSD_randomLevel()"; the UnitLevel("player") doesnt update fast enough at the "PLAYER_LEVEL_UP" event ..
		end
	end
	for i = 2, 80 do -- Simple and nice piece of code (n_n)
		if PLU_level == i then -- Look for matching playerLevel and save it to the array
			self.db.char.timeDingList[i] = timeDing
			self.db.char.totalTimeList[i] = TPM_totalTime
		end
	end
end

function ReadySetDing:PARTY_MEMBERS_CHANGED() -- Event used to find out if in Party/Raid
	PMC_numPartyMembers = GetNumPartyMembers()
end

	-------------------------
	-----  END OF ADDON ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- ----- -----
	-------------------------
--[[
# Version History
	v0.52	2010.09.04  Fixed Table of Contents (.TOC) Title; Added ReadySet7 Images; Cleaned up [Advanced] Options tab
	v0.51	2010.09.04	Removed Camera Max Distance by request, Code refactoring(Variable Scoping)
	v0.5	2010.09.01	Added Ding Emote, Real ID Broadcast, Ding Summary
	v0.4	2010.03.18	Added Custom Ding Message, Screenshot option
	v0.3	2010.01.29	Added GUI Options, Slash Commands, embeded Ace3 libs
	v0.2	2010.01.10	Released again, made some (stupid?) error
	v0.1	2010.01.10	Release
# GetIconInfo cheatsheet
	/dump (select(10, GetItemInfo(28528)))
	/dump (select(3, GetSpellInfo(47788)))
	/dump (select(10, GetAchievementInfo(3456)))
	/dump (select(2, GetMacroInfo(2)))
	/run ChatFrame1:AddMessage("\124TInterface\\Icons\\INV_Misc_Rune_01:32\124t")
# Colors
	LightSkyBlue = #87CEFA; GreenYellow = #ADFF2F; Tomato = #FF6347; Nadeshiko Pink = #F6ADC6; Misty Rose = #FFE4E1; LightPink = #FFB6C1
	Item: Legendary = #FF8000; Epic == #A335EE; Blue = 0070DD; Green = #1EFF00; White = #FFFFFF; Gray = #9D9D9D
	Level Difference: Red = #FF2020; Orange = #FF8040; Yellow = #FFFF00; Green = #40C040; Gray = #808080; Hostile Reaction = #BF0D0D; Friendly Reaction = #57A3FF
	Profession = #FFD000; Achievement = #FFFF00; Talent = #4E96F7; Ability = #71D5FF
# Links
	General: WoWWiki					http://www.wowwiki.com/			http://www.wowwiki.com/User:Ketho
	General: Wowhead					http://www.wowhead.com/			http://www.wowhead.com/user=Ketho
	Lua: WowAce							http://www.wowace.com/			http://www.curseforge.com/profiles/Ketho/
	Lua: WoW Programming				http://wowprogramming.com/
	Lua: The Programming Language Lua	http://www.lua.org/
	Lua: lua-users						http://lua-users.org/
	AddOn: Curse						http://www.curse.com/			http://wow.curse.com/members/Ketho.aspx
	AddOn: WoWInterface					http://www.wowinterface.com/	http://www.wowinterface.com/forums/member.php?action=getinfo&userid=230732
	AddOn: WoWUI						http://wowui.incgamers.com/		http://wowui.incgamers.com/?p=profile&u=428922
	Debug: Swatter (from Auctioneer)	http://auctioneeraddon.com/dl/#release
	Debug: DevTools						http://www.wowinterface.com/downloads/info3999-DevTools.html
	Debug: Blizzard_DebugTools /dump	http://www.wowwiki.com/Blizzard_DebugTools
	Extract: Ladik's MPQ Editor			http://zezula.net/en/mpq/download.html
	.BLP: XnView						http://xnview.com/
	.BLP: BLP2PNG						http://www.wowinterface.com/downloads/info6127-BLP2PNG.html
	Windows 7:							http://www.microsoft.com/windows/build/
# ToDo
	01  Compare leveling speed with guild/server
	02  Add more variables for in Ding Message, i.e. Previous Level, Time Difference with last level, average level speed, current level speed
	03  Auto-Gratz to Party/Guild member ding -- no event that fires; use table to see difference?; have to check every x sec (with an event) for a difference in values
	04  Instance TimeRun announce (but for Leveling Instances only)
	FEAT1  Localization; Locales
	PROG1  Use case sensitive "patterns" better in -> string.upper() + string.sub to find it -> again but then in reverse -> replace with string.gsub now the position is known and its uppercase. kinda troublesome ....
	PROG2  Fix the way the profiles are in the options group, so they wont have dark background
	TEST1  Test if the levelCounter resets at 19 back to 1; Put it at 19 then ding
	FUN1   Take Icons from ...\Interface\GLUES\CHARACTERCREATE\ and use coords from CharacterCreate.lua for some character summary with icons
# Features/Done
	01  Ding Screenshot; Delayed by AceTimer with AceConfigDialog Range(slider)
	02  Real ID; Restore/broadcast previous Real ID Broadcast message
	03  Show /Played + LevelUp Times Summary in Menu
# miniFeatures/Done
	01  /Ding Emote
	02  Ding/Achievement Sounds Button + Easter Egg [Fun feature]
	OPTION1  option to disable ding for LV10,20,30,...  (Achievement levels)
	IDEA1  Ding Message Preview Description + Throttle random variables (less annoying)
	IDEA2  Show PlaySoundFile() path Description
# Code optimalizations
	PROG1  Use local variables(File-local Scope) instead of global variables where possible
	PROG2  Anything inside a function called i.e. "ReadySetDing:" can replace "ReadySetDing." with "self." instead
# Bugs / (to be / not) Fixed Bugs
	01  For some reason when the ding info gets shown just fine the "** |cffBF0D0D[No Levelup Data Found]|r **" The error gets shown as well as the level data [Fixed]
	02  Cant filter/block the "/played" message at start of game imho
# Considering / possible/useful/need?
	01  Random Custom Ding messages
	02  Interpolate level ding times
	03  Maybe dont have to request /played if Player is still the same level; need db.char; still need to request for accurate time
	04  To make the Ding Times list, most recent ding always on top when ding, make a1 = a2; a2 = a3; a3 = a4; ...; maybe too hard :S
	05  Announce /played -> rather not. Player can read it from Menu anyway
# Thoughts / Questions / History / Considering
	01  Forget about getglobal(), setglobal() and getfenv(); moreover since the first 2 will be decrepated in cataclysm. Use _G[] instead
	THOUGHT1  Dont really understand "AceTimer:TimeLeft(handle)" want to see how much time there was left on the "RequestTimePlayed()" delay
	HISTORY1  v0.4 didnt have any delay or waited for other leveling AddOns yet; and also no random times that kept changing
	CONSID1  Turn AddOn off, if player can't level anymore(max level according to their "expansionLevel"); actually better not do that, "self.db.profile.enableAddOn" is in the (default) AceDB profile; it would get too troublesome and inconsistent
# Learned Lessons / Minddump
	01  Cant use: array{}, AceDB, GET/SET straight in AceConfigDialog "description". Can use function instead though
	02	For some reason, the game did /played when I changed that specific code in AddOn and then alt-tabbed back into game. huh?!
	03	I put a "counter" in the wrong place. In the options instead of the LevelUp Event Handler/"PLAYER_LEVEL_UP"+"TIME_PLAYED_MSG"
	04	Saving ding level information everytime you ding, 1 by 1 ...
	05	Must find out how to: save a variable that changes if [i] changes or something ... -> Works with for "i = 1,3 do _G["blaat"..i] = i end" but it seems to only work in the LUA live demo ...
	07	Should not replace the short |cff71D5FF with a variable, because of the added "..spc.." the addon will have a minimal size decrease(40bytes~) 1 byte less for each replacement time
--]]