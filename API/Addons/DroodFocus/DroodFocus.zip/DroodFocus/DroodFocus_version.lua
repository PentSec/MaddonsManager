﻿----------------------------------------------------------------------------------------------------
-- DroodFocus 4.0.0 - version
-- Author : Meranannon - Discordia - Vol'jin (EU)
-- rev 1
----------------------------------------------------------------------------------------------------

DROODFOCUS_VERSION = "4.0.21"

-- version minimum pour la configuration, sinon reset total
DROODFOCUS_CONFIGVERSION = 409

DF_namespace = {}
