local spells = {
	19885, -- Track Hidden
	19883, -- Track Humanoids
	1494,  -- Track Beasts
	19878, -- Track Demons
	19880, -- Track Elementals
	19884, -- Track Undead
	19879, -- Track Dragonkin
	19882, -- Track Giants
	2580,  -- Find Minerals
	2383,  -- Find Herbs
	2481,  -- Find Trasure
	43308  -- Find Fish
}

local bar = ZActionBar_Create("ZTrack", spells, ZHunterModOptions, "ZHunterMod_Saved")