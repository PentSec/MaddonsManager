local spells = {
	34600, -- Snake Trap
	1499,  -- Freezing Trap
	13809, -- Frost Trap
	13795, -- Immolation Trap
	13813, -- Explosive Trap
	60192, -- Freezing Trap
	5384   -- Feign Death
}

local bar = ZActionBar_Create("ZTrap", spells, ZHunterModOptions, "ZHunterMod_Saved")