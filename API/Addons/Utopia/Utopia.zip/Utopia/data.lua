local Utopia = LibStub("AceAddon-3.0"):GetAddon("Utopia", true)
if (not Utopia) then
	return
end
Utopia:UpdateVersion("$Revision: 206 $")

local wowVersion = tonumber((select(2,GetBuildInfo())))

local L = LibStub("AceLocale-3.0"):GetLocale("Utopia")

-- All talent scans are done by name. No messing around with slot indexes etc.
-- Notable fields:
--		interested	- The types of player interested in seeing this icon (for the automatic icon selection)

Utopia.bloodlustID = UnitFactionGroup("player") == "Horde" and 2825 or 32182		-- Bloodlust/Heroism

-- Update for major patches:
Utopia.expectedTalentLengths = {
	PRIEST		= {28, 27, 27},
	DEATHKNIGHT	= {28, 29, 31},
	ROGUE		= {27, 28, 28},
	HUNTER		= {26, 27, 28},
	MAGE		= {30, 28, 28},
	PALADIN		= {26, 26, 26},
	WARRIOR		= {31, 27, 27},
	SHAMAN		= {25, 29, 26},
	WARLOCK		= {28, 27, 26},
	DRUID		= {28, 30, 27},
}

local identifyDrumsOfTheWild
do
	local markName, _, markTexture = GetSpellInfo(1126)	-- Mark of the Wild
	local giftName = GetSpellInfo(21849)				-- Gift of the Wild
	local giftNameDrums = GetSpellInfo(69381)			-- Gift of the Wild
	function identifyDrumsOfTheWild(unit)
		-- Have to do some special checking here if it's really Gift of the Wild or not
		-- Drums of Wild give a buff called Gift of the Wild, but the icon is from Mark of the Wild
		local name, rank, tex = UnitBuff(unit, giftNameDrums)
		if (name) then
			if (tex == markTexture and name == giftName) then
				return true
			end
		end
		return false, markName
	end
end

Utopia.buffs = {
	[L["Armor"]] = {
		icon = select(3, GetSpellInfo(48942)),
		attribute = L["Armor"],
		interested = "tank",
		spells = {
			[48942] = {										-- Devotion Aura
				class = "PALADIN",
				exclusive = "aura",
				rankLevels = {1, 10, 20, 30, 40, 50, 60, 70, 74, 79},
				amounts = {55, 160, 275, 390, 505, 620, 735, 861, 1015, 1205},
				rankIDs = {465, 10290, 643, 10291, 1032, 10292, 10293, 27149, 48941, 48942},
				improvedPercentagePerTalentPoint = 50/3,
				maxTalentPoints = 3,
				improved = 20138,							-- Improved Devotion Aura
				regex = true,
			},
		},
	},
	[L["Armor Totem"]] = {
		icon = select(3, GetSpellInfo(58754)),
		attribute = L["Armor"],
		interested = "tank",
		spells = {
			[58754] = {										-- Stoneskin
				class = "SHAMAN",
				totem = "earth",
				source = 8071,								-- Stoneskin Totem
				rankLevels = {4, 14, 24, 34, 44, 54, 63, 70, 73, 78},
				amounts = {95, 200, 310, 420, 530, 640, 750, 860, 980, 1150},
				rankIDs = {8071, 8154, 8155, 10406, 10407, 10408, 25508, 25509, 58751, 58753},
				improved = 16258,
				maxTalentPoints = 2,
				improvedPercentagePerTalentPoint = 10,
				regex = true,
			},
		},
	},
	[L["Attack Power"]] = {
		icon = select(3, GetSpellInfo(47436)),
		attribute = L["AP"],
		interested = "melee,tank",
		reportable = true,
		spells = {
			[47436] = {										-- Battle Shout
				class = "WARRIOR",
				exclusive = "warriorbuff",
				rankLevels = {1, 12, 22, 32, 42, 52, 60, 69, 78},
				amounts = {15, 35, 55, 85, 130, 185, 232, 305, 548},
				rankIDs = {6673, 5242, 6192, 11549, 11550, 11551, 25289, 2048, 47436},
				improvedPercentagePerTalentPoint = 5,
				maxTalentPoints = 5,
				improved = 12861,							-- Commanding Presence
				regex = 1,
			},
			[48932] = {										-- Blessing of Might
				alternate = 27141,							-- Greater Blessing of Might
				alternateOffset = 5,						-- How many ranks to add if it's the alternate spell
				class = "PALADIN",
				exclusive = "blessing",
				rankLevels = {4, 12, 22, 32, 42, 52, 60, 70, 73, 79},
				amounts = {20, 35, 55, 85, 130, 185, 232, 306, 410, 550},
				rankIDs = {19740, 19834, 19835, 19836, 19837, 19838, 25291, 27140, 48931, 48932},
				rankIDsAlternate = {25782, 25916, 27141, 48933, 48934},
				improvedPercentagePerTalentPoint = 25/2,
				maxTalentPoints = 2,
				improved = 20045,							-- Improved Blessing of Might
				regex = 1,
			},
		},
	},
	[L["Attack Power (%)"]] = {
		icon = select(3, GetSpellInfo(19506)),
		attribute = L["AP"],
		interested = "melee,tank",
		spells = {
			[19506] = {										-- Trueshot Aura
				class = "HUNTER",
				spec = "Marksmanship",
				amount = 10,
				amountType = "%",
				requiredTalent = 19506,						-- Trueshot Aura
				minLevel = 40,
			},
			[55972] = {										-- Abominable Might
				class = "DEATHKNIGHT",
				spec = "Blood",
				amount = 10,
				amountType = "%",
				requiredTalent = 53138,						-- Abomination's Might (Note the difference in name)
				minLevel = 35,
				temporary = true,
			},
			[30809] = {										-- Unleashed Rage
				class = "SHAMAN",
				spec = "Enhancement",
				amountPerTalentPoint = 10/3,
				maxTalentPoints = 3,
				amountType = "%",
				requiredTalent = 30809,
				minLevel = 35,
				temporary = true,
			},
		},
	},
	["Bloodlust/Heroism"] = {
		icon = select(3, GetSpellInfo(Utopia.bloodlustID)),
		attribute = L["Haste"],
		spells = {
			[Utopia.bloodlustID] = {						-- Bloodlust / Heroism
				class = "SHAMAN",
				amount = 30,
				amountType = "%",
				minLevel = 70,
				temporary = true,
			},
		},
	},
	[L["Crit Chance (Melee)"]] = {
		icon = select(3, GetSpellInfo(17007)),
		attribute = L["Melee Crit"],
		interested = "melee,tank",
		spells = {
			[17007] = {										-- Leader of the Pack
				class = "DRUID",
				spec = "Feral",
				amount = 5,
				amountType = "%",
				requiredTalent = 17007,						-- Leader of the Pack
				minLevel = 40,
			},
			[29801] = {										-- Rampage
				class = "WARRIOR",
				spec = "Fury",
				amount = 5,
				amountType = "%",
				requiredTalent = 29801,						-- Rampage
				minLevel = 50,
				temporary = true,
			},
		},
	},
	[L["Crit Chance (Spell)"]] = {
		icon = select(3, GetSpellInfo(24907)),
		attribute = L["Spell Crit"],
		interested = "caster,healer",
		spells = {
			[24907] = {										-- Moonkin Aura
				class = "DRUID",
				spec = "Balance",
				amount = 5,
				amountType = "%",
				requiredTalent = 24858,						-- Moonkin Form
				minLevel = 40,
			},
			[51470] = {										-- Elemental Oath
				class = "SHAMAN",
				spec = "Elemental",
				temp = true,
				amountPerTalentPoint = 2.5,
				maxTalentPoints = 2,
				amountType = "%",
				requiredTalent = 51470,						-- Elemental Oath
				minLevel = 45,
			},
		},
	},
	[L["Damage (%)"]] = {
		icon = select(3, GetSpellInfo(34460)),
		attribute = L["Damage Modifier"],
		attributeShort = L["Damage"],
		interested = "melee,caster",
		spells = {
			[34460] = {										-- Ferocious Inspiration
				class = "HUNTER",
				spec = "Beast Mastery",
				amountPerTalentPoint = 1,
				maxTalentPoints = 3,
				amountType = "%",
				temp = true,
				requiredTalent = 34460,						-- Ferocious Inspiration
				minLevel = 40,
				temporary = true,
			},
			[31869] = {										-- Sanctified Retribution
				class = "PALADIN",
				spec = "Retribution",
				amount = 3,
				amountType = "%",
				requiredTalent = 31869,						-- Sanctified Retribution
				minLevel = 30,
			},
		},
	},
	[L["Damage Reduction (%)"]] = {
		icon = select(3, GetSpellInfo(20911)),
		attribute = L["Damage Reduction"],
		attributeShort = L["Reduction"],
		interested = "tank",
		spells = {
			[20911] = {										-- Blessing of Sanctuary
				alternate = 25899,							-- Greater Blessing of Sanctuary
				class = "PALADIN",
				spec = "Protection",
				exclusive = "blessing",
				amount = 3,
				amountType = "%",
				requiredTalent = 20911,						-- Blessing of Sanctuary
				minLevel = 30,
			},
			[63944] = {										-- Renewed Hope
				class = "PRIEST",
				spec = "Discipline",
				amount = 3,
				amountType = "%",
				requiredTalent = 63944,						-- Renewed Hope
				minLevel = 45,
				temporary = true,
			},
		}
	},
	[L["Damage Reduction Physical (%)"]] = {
		icon = select(3, GetSpellInfo(16177)),
		attribute = L["Physical Damage Reduction"],
		attributeShort = L["Reduction"],
		interested = "tank",
		spells = {
			[16177] = {										-- Ancestral Fortitude
				class = "SHAMAN",
				spec = "Restoration",
				amountPerTalentPoint = 10/3,
				maxTalentPoints = 3,
				amountType = "%",
				requiredTalent = 16176,						-- Ancestral Healing
				minLevel = 20,
				temporary = true,
			},
			[15363] = {										-- Inspiration
				class = "PRIEST",
				spec = "Holy",
				amountPerTalentPoint = 10/3,
				maxTalentPoints = 3,
				amountType = "%",
				requiredTalent = 15363,						-- Inspiration
				minLevel = 20,
				temporary = true,
			},
		},
	},
	[L["Haste"]] = {
		icon = select(3, GetSpellInfo(53648)),
		attribute = L["Haste"],
		interested = "melee,caster,healer",
		spells = {
			[53648] = {										-- Swift Retribution
				class = "PALADIN",
				spec = "Retribution",
				amountPerTalentPoint = 1,
				maxTalentPoints = 3,
				amountType = "%",
				requiredTalent = 53648,						-- Swift Retribution
				minLevel = 50,
			},
			[48396] = {										-- Improved Moonkin Form
				class = "DRUID",
				spec = "Moonkin",
				amountPerTalentPoint = 1,
				maxTalentPoints = 3,
				amountType = "%",
				requiredTalent = 48396,						-- Improved Moonkin Form
				minLevel = 41,
			},
		},
	},
	[L["Haste (Melee)"]] = {
		icon = select(3, GetSpellInfo(55610)),
		attribute = L["Haste"],
		interested = "melee",
		spells = {
			[55610] = {										-- Improved Icy Talons
				alternate = 50887,							-- Icy Talons (The DK themself only get this aura)
				class = "DEATHKNIGHT",
				spec = "Frost",
				amount = 20,
				amountType = "%",
				temp = true,
				requiredTalent = 55610,						-- Improved Icy Talons
				minLevel = 55,
				temporary = true,
			},
			[8512] = {										-- Windfury Totem
				class = "SHAMAN",
				totem = "air",
				amount = 16,
				amountType = "%",
				improvedPercentagePerTalentPoint = 2,
				maxTalentPoints = 2,
				improved = 29193,							-- Improved Windfury Totem
				minLevel = 32,
				regex = true,
			},
		},
	},
	[L["Haste (Spell)"]] = {
		icon = select(3, GetSpellInfo(3738)),
		attribute = L["Haste"],
		interested = "caster,healer",
		spells = {
			[3738] = {										-- Wrath of Air Totem
				class = "SHAMAN",
				totem = "air",
				amount = 5,
				amountType = "%",
				minLevel = 64,
			},
		},
	},
	[L["Healing Received"]] = {
		icon = select(3, GetSpellInfo(33891)),
		attribute = L["Healing"],
		interested = "healer",
		spells = {
			[33891] = {										-- Tree of Life
				class = "DRUID",
				spec = "Restoration",
				amount = 6,
				amountType = "%",
				requiredTalent = 33891,						-- Tree of Life
				minLevel = 50,
			},
			[20140] = {										-- Improved Devotion Aura
				class = "PALADIN",
				spec = "Protection",
				amountPerTalentPoint = 2,
				maxTalentPoints = 3,
				amountType = "%",
				requiredTalent = 20140,						-- Improved Devotion Aura
				minLevel = 25,
			},
		},
	},
	[L["Health"]] = {
		icon = select(3, GetSpellInfo(47440)),
		attribute = L["Health"],
		interested = "tank,healer",
		spells = {
			[47982] = {										-- Blood Pact
				class = "WARLOCK",
				pet = L["Imp"],
				rankLevels = {4, 14, 26, 38, 50, 62, 74},
				amounts = {20, 70, 160, 270, 380, 660, 1330},
				rankIDs = {6307, 7804, 7805, 11766, 11767, 27268, 47982},
				improved = 18694,							-- Improved Imp
				improvedPercentagePerTalentPoint = 10,
				maxTalentPoints = 3,
				regex = true,
			},
			[47440] = {										-- Commanding Shout
				class = "WARRIOR",
				exclusive = "warriorbuff",
				rankLevels = {68, 74, 80},
				amounts = {1080, 1855, 2255},
				rankIDs = {469, 47439, 47440},
				improvedPercentagePerTalentPoint = 5,
				maxTalentPoints = 5,
				improved = 12861,							-- Commanding Presence
				regex = true,
			},
		},
	},
	[L["Intellect"]] = {
		icon = select(3, GetSpellInfo(42995)),
		attribute = L["Intellect"],
		interested = "manauser",
		reportable = true,
		spells = {
			[42995] = {										-- Arcane Intellect
				alternate = 27127,							-- Arcane Brilliance
				alternateOffset = 4,						-- How many ranks to add if it's the alternate spell
				class = "MAGE",
				rankLevels = {1, 14, 28, 42, 56, 70, 80},
				amounts = {2, 7, 15, 22, 31, 40, 60},
				rankIDs = {1459, 1460, 1461, 10156, 10157, 27126, 42995},
				rankIDsAlternate = {23028, 27127, 43002},
			},
			[61024] = {										-- Dalaran Intellect (Only Rank 7 exists)
				alternate = 61316,							-- Dalaran Brilliance (Only Rank 3 exists)
				alternateOffset = 4,
				class = "MAGE",
				rankLevels = {80, 80, 80, 80, 80, 80, 80},	-- Was changed to Rank 3 (from 1) with patch 3.1 ish,
				amounts = {60, 60, 60, 60, 60, 60, 60},		-- so we'll fill in the two dummy ones else it bugs
			},
			[57567] = {										-- Fel Intelligence
				class = "WARLOCK",
				pet = "Felhunter",
				rankLevels = {32, 42, 52, 62, 72},
				amounts = {12, 18, 25, 32, 48},
				rankIDs = {54424, 57564, 57565, 57566, 57567},
				improvedPercentagePerTalentPoint = 5,
				maxTalentPoints = 2,
				improved = 54038,							-- Improved Felhunter
				regex = 1,
			},
		},
	},
	[L["Mana Regen"]] = {
		icon = select(3, GetSpellInfo(48936)),
		attribute = L["mp5"],
		interested = "manauser",
		spells = {
			[48936] = {										-- Blessing of Wisdom
				alternate = 27143,							-- Greater Blessing of Wisdom
				alternateOffset = 4,						-- How many ranks to add if it's the alternate spell
				class = "PALADIN",
				exclusive = "blessing",
				rankLevels = {14, 24, 34, 44, 54, 60, 65, 71, 77},
				amounts = {10, 15, 20, 25, 30, 33, 41, 73, wowVersion >= 9868 and 92 or 91},
				rankIDs = {19742, 19850, 19852, 19853, 19854, 25290, 27142, 48935, 48936},
				rankIDsAlternate = {25894, 25918, 27143, 48937, 48938},
				improvedPercentagePerTalentPoint = 10,
				maxTalentPoints = 2,
				improved = 20245,							-- Improved Blessing of Wisdom
				regex = 1,
			},
			[58777] = {										-- Mana Spring
				class = "SHAMAN",
				totem = "water",
				rankLevels = {26, 36, 46, 56, 65, 71, 76, 80},
				amounts = {16, 21, 26, 31, 41, 73, 82, 91},
				rankIDs = {5675, 10495, 10496, 10497, 25570, 58771, 58773, 58774},
				improvedPercentagePerTalentPoint = 20/3,
				maxTalentPoints = 3,
				improved = 16187,							-- Restorative Totems
				regex = 1,
			},
		},
	},
	[GetSpellInfo(57669)] = {								-- Replenishment
		icon = select(3, GetSpellInfo(57669)),
		id = 57669,
		attribute = L["Mana Regen"],
		interested = "manauser",
		spells = {
			[53292] = {										-- Hunting Party
				alternate = 57669,							-- Replenishment
				class = "HUNTER",
				spec = "Survival",
				requiredTalent = 53292,						-- Hunting Party
				minLevel = 55,
				temporary = true,
			},
			[31878] = {										-- Judgements of the Wise
				alternate = 57669,							-- Replenishment
				class = "PALADIN",
				spec = "Retribution",
				requiredTalent = 31878,						-- Judgements of the Wise
				minLevel = 40,
				temporary = true,
			},
			[48160] = {										-- Vampiric Touch
				alternate = 57669,							-- Replenishment
				class = "PRIEST",
				spec = "Shadow",
				requiredTalent = 48160,						-- Vampiric Touch
				minLevel = 60,
				temporary = true,
			},
			[44561] = {										-- Enduring Winter
				alternate = 57669,							-- Replenishment
				class = "MAGE",
				spec = "Frost",
				requiredTalent = 44561,						-- Enduring Winter
				minLevel = 50,
				temporary = true,
			},
			[54118] = {										-- Improved Soul Leech
				alternate = 57669,							-- Replenishment
				class = "WARLOCK",
				spec = "Destruction",
				requiredTalent = 54118,						-- Improved Soul Leech
				minLevel = 45,
				temporary = true,
			},
		},
	},
	[L["Spell Power"]] = {
		icon = select(3, GetSpellInfo(57722)),
		attribute = L["Spell Power"],
		interested = "manauser",
		spells = {
			[47240] = {										-- Demonic Pact (Temp Buff)
				class = "WARLOCK",
				pet = "any",
				amountPerTalentPoint = 2,
				maxTalentPoints = 5,
				amountType = "%",
				temp = true,
				requiredTalent = 47240,						-- Demonic Pact
				minLevel = 55,
			},
			[58656] = {										-- Flametongue Totem
				class = "SHAMAN",
				totem = "fire",
				rankLevels = {28, 38, 48, 58, 67, 71, 75, 80},
				amounts = {25, 37, 49, 62, 73, 106, 122, 144},
				rankIDs = {8227, 8249, 10526, 16387, 25557, 58649, 58652, 58656},
				improvedPercentagePerTalentPoint = 5,
				maxTalentPoints = 3,
				improved = 52456,							-- Enhancing Totems
				regex = true,
			},
			[57722] = {										-- Totem of Wrath
				class = "SHAMAN",
				totem = "fire",
				spec = "Elemental",
				rankLevels = {50, 60, 70, 80},
				amounts = {100, 120, 140, 280},
				rankIDs = {30706, 57720, 57721, 57722},
				requiredTalent = 57722,						-- Totem of Wrath
			},
		},
	},
	[L["Spirit"]] = {
		icon = select(3, GetSpellInfo(48073)),
		attribute = L["Spirit"],
		interested = "healer",
		reportable = true,
		spells = {
			[48073] = {										-- Divine Spirit
				alternate = 32999,							-- Prayer of Spirit
				alternateOffset = 3,						-- How many ranks to add if it's the alternate spell
				class = "PRIEST",
				rankLevels = {30, 40, 50, 60, 70, 80},
				amounts = {17, 23, 33, 40, 50, 80},
				rankIDs = {14752, 14818, 14819, 27841, 25312, 48073},
				rankIDsAlternate = {27681, 32999, 48074},
				regex = true,
			},
			[57567] = {										-- Fel Intelligence
				class = "WARLOCK",
				pet = "Felhunter",
				rankLevels = {32, 42, 52, 62, 72},
				amounts = {18, 26, 32, 40, 64},
				rankIDs = {54424, 57564, 57565, 57566, 57567},
				improvedPercentagePerTalentPoint = 5,
				maxTalentPoints = 2,
				improved = 54038,							-- Improved Felhunter
				regex = true,
			},
		},
	},
	[L["Stamina"]] = {
		icon = select(3, GetSpellInfo(48161)),
		attribute = L["Stamina"],
		interested = "tank,healer",
		raidbuff = true,
		reportable = true,
		spells = {
			[48161] = {										-- Power Word: Fortitude
				alternate = 25392,							-- Prayer of Fortitude
				alternateOffset = 4,						-- How many ranks to add if it's the alternate spell
				class = "PRIEST",
				rankLevels = {1, 12, 24, 36, 48, 60, 70, 80},
				amounts = {3, 8, 20, 32, 43, 54, 79, 165},
				rankIDs = {1243, 1244, 1245, 2791, 10937, 10938, 25389, 48161},
				rankIDsAlternate = {21562, 21564, 25392, 48162},
				improvedPercentagePerTalentPoint = 15,
				maxTalentPoints = 2,
				improved = 14767,							-- Improved Power Word: Fortitude
				regex = true,
			},
			[69377] = {										-- Fortitude
				amount = 165,
				runescroll = 49632,							-- Runescroll of Fortitude
				minLevel = 80,
			}
		},
	},
	[L["Stat Add"]] = {
		icon = select(3, GetSpellInfo(48469)),
		attribute = L["Stats"],
		raidbuff = true,
		reportable = true,
		spells = {
			[48469] = {										-- Mark of the Wild
				alternate = 26991,							-- Gift of the Wild
				alternateOffset = 5,						-- How many ranks to add if it's the alternate spell
				class = "DRUID",
				rankLevels = {1, 10, 20, 30, 40, 50, 60, 70, 80},
				amounts = {0, 2, 4, 6, 8, 10, 12, 14, 37},
				rankIDs = {1126, 5232, 6756, 5234, 8907, 9884, 9885, 26990, 48469},
				rankIDsAlternate = {21849, 21850, 26991, 48470},
				improvedPercentagePerTalentPoint = 20,
				maxTalentPoints = 2,
				improved = 17051,							-- Improved Mark of the Wild
				regex = "TALENT",							-- Change all figures in tooltip by amount given on talents
				identify = function(unit)
					if (identifyDrumsOfTheWild(unit)) then
						return false, (GetSpellInfo(69381))
					end
					return true
				end,
			},
			[69381] = {										-- Gift of the Wild
				amount = 37,
				identify = identifyDrumsOfTheWild,
				runescroll = 49634,											-- Drums of the Wild
				minLevel = 80,
			},
		},
	},
	[L["Stat Multiplier"]] = {
		icon = select(3, GetSpellInfo(20217)),
		attribute = L["Stats"],
		reportable = true,
		raidbuff = true,
		spells = {
			[20217] = {										-- Blessing of Kings
				alternate = 25898,							-- Greater Blessing of Kings
				class = "PALADIN",
				exclusive = "blessing",
				amount = 10,
				amountType = "%",
				minLevel = 20,
			},
			[69378] = {										-- Blessing of Forgotten Kings
				amount = 8,
				amountType = "%",
				runescroll = 49633,							-- Drums of Forgotten Kings
				minLevel = 80,
			},
		},
	},
	[L["Strength & Agility"]] = {
		icon = select(3, GetSpellInfo(58643)),
		attribute = L["Str & Agi"],
		interested = "melee,tank",
		spells = {
			[58646] = {										-- Strength of Earth (not Strength of Earth Totem, which is different)
				class = "SHAMAN",
				totem = "earth",
				source = 8075,								-- Strength of Earth Totem
				rankLevels = {10, 24, 38, 52, 60, 65, 75, 80},
				amounts = {10, 20, 36, 61, 77, 86, 115, 155},
				rankIDs = {8075, 8160, 8161, 10442, 25361, 25528, 57622, 58643},
				improvedPercentagePerTalentPoint = 5,
				maxTalentPoints = 3,
				improved = 52456,							-- Enhancing Totems
				regex = true,
			},
			[57623] = {										-- Horn of Winter
				class = "DEATHKNIGHT",
				rankLevels = {65, 75},
				amounts = {86, 155},
				rankIDs = {57330, 57623},
				regex = true,
			},
		},
	},
}

if (wowVersion >= 10554) then
	Utopia.buffs[L["Damage (%)"]].spells[31583] = {		-- Arcane Empowerment
		class = "MAGE",
		spec = "Arcane",
		amountPerTalentPoint = 1,
		maxTalentPoints = 3,
		amountType = "%",
		temp = true,
		requiredTalent = 31583,						-- Arcane Empowerment
		minLevel = 30,
	}
end

Utopia.debuffs = {
	[L["Armor (Major)"]] = {
		icon = select(3, GetSpellInfo(47467)),
		attribute = L["Armor"],
		interested = "melee,tank",
		spells = {
			[8647] = {										-- Expose Armor
				class = "ROGUE",
				amount = 20,
				amountType = "%",
				minLevel = 14,
			},
			[7386] = {										-- Sunder Armor
				class = "WARRIOR",
				amountPerStack = 4,
				amountType = "%",
				maxStacks = 5,
				minLevel = 10,
			},
			[55754] = {										-- Acid Spit
				class = "HUNTER",
				spec = "Beast Mastery",
				pet = L["Worm"],
				amountPerStack = 10,
				amountType = "%",
				maxStacks = 2,
				minLevel = 60,								-- Pets have this at level 1, but hunter needs to be able to use Exotic pets
			},
		},
	},
	[L["Armor (Minor)"]] = {
		icon = select(3, GetSpellInfo(770)),
		attribute = L["Armor"],
		interested = "melee,tank",
		reportable = true,
		spells = {
			[50511] = {										-- Curse of Weakness
				class = "WARLOCK",
				amount = 5,
				amountType = "%",
				exclusive = "curse",
				minLevel = 4,
				priority = 2,
			},
			[770] = {										-- Faerie Fire
				class = "DRUID",
				amount = 5,
				amountType = "%",
				minLevel = 18,
				priority = 1,
			},
			[16857] = {										-- Faerie Fire (Feral)
				class = "DRUID",
				amount = 5,
				amountType = "%",
				minLevel = 18,
				priority = 1,
			},
			[56631] = {										-- Sting
				class = "HUNTER",
				amount = 5,
				amountType = "%",
				pet = L["Wasp"],
				temporary = true,
				priority = 1,
			},
		},
	},
	[L["Attack Power"]] = {
		icon = select(3, GetSpellInfo(47437)),
		attribute = L["Attack Power"],
		interested = "tank",
		spells = {
			[50511] = {										-- Curse of Weakness
				class = "WARLOCK",
				rankLevels = {4, 12, 22, 32, 42, 52, 61, 69, 71},
				amounts = {21, 41, 64, 82, 123, 163, 257, 350, 478},
				ranksIDs = {702, 1108, 6205, 7646, 11707, 11708, 27224, 30909, 50511},
				spec = "Affliction",
				improvedPercentagePerTalentPoint = 10,
				maxTalentPoints = 2,
				improved = 18179,							-- Frailty
				exclusive = "curse",
				regex = true,
			},
			[48560] = {										-- Demoralizing Roar
				class = "DRUID",
				rankLevels = {10, 20, 32, 42, 52, 62, 71, 77},
				amounts = {31, 51, 68, 103, 138, 220, 299, 408},
				ranksIDs = {99, 1735, 9490, 9747, 9898, 26998, 48559, 48560},
				spec = "Feral",
				improvedPercentagePerTalentPoint = 8,
				maxTalentPoints = 5,
				improved = 16862,							-- Feral Aggression
				regex = true,
			},
			[47437] = {										-- Demoralizing Shout
				class = "WARRIOR",
				rankLevels = {14, 24, 34, 44, 54, 62, 70, 79},
				amounts = {35, 55, 70, 105, 140, 220, 300, 418},
				ranksIDs = {1160, 6190, 11554, 11555, 11556, 25202, 25203, 47437},
				spec = "Fury",
				improvedPercentagePerTalentPoint = 8,
				maxTalentPoints = 5,
				improved = 12879,							-- Improved Demoralizing Shout
				regex = true,
			},
			[55487] = {										-- Demoralizing Screech
				class = "HUNTER",
				rankLevels = {1, 16, 32, 48, 64, 80},
				amounts = {25, 45, 70, 100, 210, 410},
				ranksIDs = {24423, 24577, 24578, 24579, 27051, 55487},
				pet = L["Bird of Prey"],
				regex = true,
			},
			[26016] = {										-- Vindication
				class = "PALADIN",
				--amountPerTalentPoint = 23,					-- Base value
				--amountPerTalentPoint = 287,					-- Level 80 value
				amountPerTalentPoint =
					function(unit)
						local level = unit and UnitLevel(unit)
						if (not level or level < 1) then
							level = 80
						end
						return level * 3.3 + 23
					end,
				maxTalentPoints = 2,
				spec = "Retribution",
				requiredTalent = 26016,						-- Vindication
			},
		},
	},
	[L["Bleed Damage"]] = {
		icon = select(3, GetSpellInfo(48564)),
		interested = "melee,tank",
		spells = {
			[33917] = {										-- Mangle
				class = "DRUID",
				amount = 30,
				amountType = "%",
				spec = "Feral",
				requiredTalent = 33917,						-- Mangle
				minLevel = 50,
			},
			[46855] = {										-- Trauma
				class = "WARRIOR",
				amount = 30,
				amountType = "%",
				spec = "Arms",
				requiredTalent = 46855,						-- Trauma
				minLevel = 35,
			},
			[57386] = {										-- Stampede
				class = "HUNTER",
				spec = "Beast Mastery",
				amount = 25,
				amountType = "%",
				pet = L["Rhino"],
			},
		},
	},
	[L["Cast Speed Slow"]] = {
		icon = select(3, GetSpellInfo(5761)),
		interested = "tank",
		exclude = function(unit) return UnitPowerMax(unit, 0) == 0 end,
		spells = {
			[11719] = {										-- Curse of Tongues
				class = "WARLOCK",
				rankLevels = {26, 50},
				amounts = {25, 30},
				rankIDs = {1714, 11719},
				amountType = "%",
				exclusive = "curse",
			},
			[5761] = {										-- Mind-numbing Poison
				class = "ROGUE",
				amount = 30,
				amountType = "%",
				minLevel = 24,
			},
			[58611] = {										-- Lava Breath
				class = "HUNTER",
				amount = 25,
				amountType = "%",
				spec = "Beast Mastery",
				requiredTalent = 53270,						-- Beast Mastery
				pet = L["Core Hound"],
				temporary = true,
			},
			[31589] = {										-- Slow
				class = "MAGE",
				spec = "Arcane",
				requiredTalent = 31589,						-- Slow
				amount = 30,
				amountType = "%",
				minLevel = 50,
			},
		},
	},
	[L["Critical Strike Chance Taken"]] = {
		icon = select(3, GetSpellInfo(58410)),
		interested = "melee,tank,caster",
		spells = {
			[54499] = {										-- Heart of the Crusader (buff name)
				class = "PALADIN",
				spec = "Retribution",
				maxTalentPoints = 3,
				amountPerTalentPoint = 1,
				amountType = "%",
				requiredTalent = 20337,						-- Heart of the Crusader (talent name)
				minLevel = 15,
			},
			[58410] = {										-- Master Poisoner
				class = "ROGUE",
				spec = "Assassination",
				maxTalentPoints = 3,
				amountPerTalentPoint = 1,
				amountType = "%",
				requiredTalent = 58410,						-- Master Poisoner
				minLevel = 50,
			},
			[30706] = {										-- Totem of Wrath
				class = "SHAMAN",
				totem = "fire",
				spec = "Elemental",
				amount = 3,
				amountType = "%",
				requiredTalent = 30706,						-- Totem of Wrath
				rankLevels = {50, 60, 70, 80},
				rankIDs = {30706, 57720, 57721, 57722},
				minLevel = 50,
			},
		},
	},
	[L["Healing Taken"]] = {
		icon = select(3, GetSpellInfo(47486)),
		interested = "tank",
		spells = {
			[49050] = {										-- Aimed Shot
				class = "HUNTER",
				spec = "Marksmanship",
				amount = 50,
				amountType = "%",
				requiredTalent = 49050,						-- Aimed Shot
				minLevel = 20,
			},
			[46911] = {										-- Furious Attacks
				class = "WARRIOR",
				spec = "Fury",
				amountPerStack = 25,
				maxStacks = 2,
				amountType = "%",
				requiredTalent = 46911,						-- Furious Attacks
				minLevel = 45,
			},
			[47486] = {										-- Mortal Strike
				class = "WARRIOR",
				spec = "Arms",
				amount = 50,
				amountType = "%",
				requiredTalent = 47486,						-- Mortal Strike
				minLevel = 40,
			},
			[13218] = {										-- Wound Poison (unranked name)
				class = "ROGUE",
				amount = 50,
				amountType = "%",
				minLevel = 32,
			},
			[7321] = {										-- Chilled
				class = "MAGE",
				spec = "Frost",
				amountPerTalentPoint = 20 / 3,
				maxTalentPoints = 3,
				amountType = "%",
				requiredTalent = 12571,						-- Permafrost
				minLevel = 15,
			},
			[48301] = {										-- Mind Trauma
				class = "PRIEST",
				spec = "Shadow",
				amount = 20,
				amountType = "%",
				requiredTalent = 15316,						-- Improved Mind Blast
				minLevel = 20,
			}
		},
	},
	[L["Health Restore"]] = {
		icon = select(3, GetSpellInfo(20271)),
		interested = "tank,healer",
		reportable = true,
		spells = {
			[20271] = {										-- Judgement of Light
				class = "PALADIN",
				exclusive = "judge",
				minLevel = 4,
			},
		},
	},
	[L["Mana Restore"]] = {
		icon = select(3, GetSpellInfo(53408)),
		interested = "manauser",
		reportable = true,
		spells = {
			[53408] = {										-- Judgement of Wisdom
				class = "PALADIN",
				exclusive = "judge",
				minLevel = 12,
			},
		},		
	},
	[L["Melee Attack Speed Slow"]] = {
		icon = select(3, GetSpellInfo(47502)),
		interested = "tank",
		spells = {
			[55095] = {										-- Frost Fever
				class = "DEATHKNIGHT",
				spec = "Frost",
				amount = 14,
				amountType = "%",
				improvedAmountPerTalentPoint = 2,
				maxTalentPoints = 3,
				improved = 51456,							-- Improved Icy Touch
				minLevel = 55,
				regex = true,
			},
			[48485] = {										-- Infected Wounds
				class = "DRUID",
				spec = "Feral",
				maxStacks = 2,
				amountPerTalentPoint = 10/3,
				amountType = "%",
				maxTalentPoints = 3,
				requiredTalent = 48485,						-- Infected Wounds
				minLevel = 45,
				regex = true,
			},
			[53696] = {										-- Judgements of the Just
				class = "PALADIN",
				spec = "Protection",
				amountPerTalentPoint = 10,
				amountType = "%",
				maxTalentPoints = 2,
				requiredTalent = 53696,						-- Judgements of the Just
				minLevel = 55,
				regex = true,
			},
			[47502] = {										-- Thunder Clap
				class = "WARRIOR",
				spec = "Protection",
				amount = 10,
				amountType = "%",
				maxTalentPoints = 3,
				improvedAmountPerTalentPoint = 10/3,
				improved = 12666,							-- Improved Thunder Clap
				minLevel = 10,
				regex = true,
			},
			[8042] = {										-- Earth Shock
				class = "SHAMAN",
				amount = 10,
				amountType = "%",
				improvedAmountPerTalentPoint = 5,
				maxTalentPoints = 2,
				improved = 51523,							-- Earthen Power (as of patch 3.2.2)
				minLevel = 20,
				regex = true,
			},
		},
	},
	[L["Melee Hit Chance Reduction"]] = {
		icon = select(3, GetSpellInfo(48468)),
		interested = "tank",
		spells = {
			[48468] = {										-- Insect Swarm
				class = "DRUID",
				excludingGlyph = 54830,						-- Glyph of Insect Swarm (removes the hit effect)
				amount = 3,
				amountType = "%",
				requiredTalent = 48468,						-- Insect Swarm
				minLevel = 30,
			},
			[3043] = {										-- Scorpid Sting
				class = "HUNTER",
				amount = 3,
				amountType = "%",
				minLevel = 22,
			},
		},
	},
	[L["Physical Vulnerability"]] = {
		icon = select(3, GetSpellInfo(58413)),
		interested = "tank,melee",
		spells = {
			[29859] = {										-- Blood Frenzy
				class = "WARRIOR",
				spec = "Arms",
				amountPerTalentPoint = 2,
				amountType = "%",
				maxTalentPoints = 2,
				requiredTalent = 29859,						-- Blood Frenzy
				minLevel = 50,
			},
			[58413] = {										-- Savage Combat
				class = "ROGUE",
				spec = "Combat",
				amountPerTalentPoint = 2,
				amountType = "%",
				maxTalentPoints = 2,
				requiredTalent = 58413,						-- Savage Combat
				minLevel = 50,
			},
		},
	},
	[L["Spell Critical Strike Chance"]] = {
		icon = select(3, GetSpellInfo(12873)),
		interested = "caster",
		spells = {
			[12873] = {										-- Improved Scorch
				class = "MAGE",
				spec = "Fire",
				amount			= wowVersion > 10505 and 5 or nil,		-- WoW 3.3 always applies 5% debuff
				amountPerStack	= wowVersion <= 10505 and 1 or nil,		-- WoW 3.2 applies 1% per stack
				maxStacks		= wowVersion <= 10505 and 5 or nil,
				amountType = "%",
				maxTalentPoints = 3,
				requiredTalent = 12873,						-- Improved Scorch
				minLevel = 25,
				regex = true,
			},
			[28593] = {										-- Winter's Chill
				class = "MAGE",
				spec = "Frost",
				amountPerStack = 1,
				maxStacks = 5,
				amountType = "%",
				maxTalentPoints = 3,
				requiredTalent = 28593,						-- Winter's Chill
				minLevel = 35,
				regex = true,
			},
			[17800] = {										-- Shadow Mastery
				class = "WARLOCK",
				spec = "Destruction",
				amount= 5,
				amountType = "%",
				maxTalentPoints = 5,
				requiredTalent = 17803,						-- Improved Shadow Bolt
				minLevel = 35,
				regex = true,
			},
		},
	},
	[L["Spell Damage Taken"]] = {
		icon = select(3, GetSpellInfo(47865)),
		interested = "caster",
		spells = {
			[47865] = {										-- Curse of the Elements
				class = "WARLOCK",
				spec = "Affliction",
				amount = 13,
				amountType = "%",
				exclusive = "curse",
				minLevel = 32,
			},
			[48511] = {										-- Earth and Moon
				class = "DRUID",
				spec = "Balance",
				amountPerTalentPoint = 13/3,
				amountType = "%",
				maxTalentPoints = 3,
				requiredTalent = 48511,						-- Earth and Moon
				minLevel = 55,
			},
			[51735] = {										-- Ebon Plague
				class = "DEATHKNIGHT",
				spec = "Unholy",
				amountPerTalentPoint = 13/3,
				amountType = "%",
				maxTalentPoints = 3,
				requiredTalent = 51161,						-- Ebon Plaguebringer
				minLevel = 55,
			},
		},
	},
	[L["Spell Hit Chance Taken"]] = {
		icon = select(3, GetSpellInfo(33193)),
		interested = "caster",
		spells = {
			[33602] = {										-- Improved Faerie Fire
				class = "DRUID",
				spec = "Balance",
				amountPerTalentPoint = 1,
				amountType = "%",
				maxTalentPoints = 3,
				requiredTalent = 33602,						-- Improved Faerie Fire
				minLevel = 40,
			},
			[33193] = {										-- Misery
				class = "PRIEST",
				spec = "Shadow",
				amount = 3,
				amountType = "%",
				requiredTalent = 33193,						-- Misery
				minLevel = 45,
			},
		},
	},
}

-- Buffs we want to enhance the tooltips for, but are not showing them in the icon grid
Utopia.otherBuffs = {
	[54043] = {									-- Retribution Aura
		rankLevels = {16, 26, 36, 46, 56, 66, 76},
		amounts = {10, 18, 27, 37, 48, 62, 112},
		exclusive = "aura",
		improved = 31869,						-- Sanctified Retribution
		improvedPercentagePerTalentPoint = 50,
		maxTalentPoints = 1,
		regex = true,
	},
	[19746] = {									-- Concentration Aura
		amount = 35,
		amountType = "%",
		exclusive = "aura",
		improved = 20254,						-- Improved Concentration Aura
		improvedPercentagePerTalentPoint = 5,
		maxTalentPoints = 3,
		regex = true,
	},
	[48943] = {exclusive = "aura"},				-- Shadow Resistance Aura
	[48945] = {exclusive = "aura"},				-- Frost Resistance Aura
	[48947] = {exclusive = "aura"},				-- Fire Resistance Aura
	--[32223] = {exclusive = "aura"},				-- Crusader Aura (leave this one out, on purpose)

	-- Debuffs
	[603] = {exclusive = "curse"},				-- Curse of Doom
	[980] = {exclusive = "curse"},				-- Curse of Agony
	[1010] = {exclusive = "curse"},				-- Curse of Idiocy

	-- Totems
	[8185] = {totem = "water"},					-- Fire Resistance
	[8182] = {totem = "fire"},					-- Frost Resistance
	[10596] = {totem = "air"},					-- Nature Resistance
}

-- Mapping spells. These don't actually appear on the target, but are
-- 'hidden' auras that we have to infer, often given as an additional
-- effect to a spell.  (With the exception of Wound Poison which is a
-- straight mapping to cope with the varying names)

do
	local paladinAuraList = {
		[GetSpellInfo(48942)] = true,		-- Devotion Aura
		[GetSpellInfo(54043)] = true,		-- Retribution Aura
		[GetSpellInfo(19746)] = true,		-- Concentration Aura
		[GetSpellInfo(48943)] = true,		-- Shadow Resistance Aura
		[GetSpellInfo(48945)] = true,		-- Frost Resistance Aura
		[GetSpellInfo(48947)] = true,		-- Fire Resistance Aura
		[GetSpellInfo(32223)] = true,		-- Crusader Aura
	}

	Utopia.mapping = {
		[GetSpellInfo(13218)] = {					-- Wound Poison (unranked name)
			class = "ROGUE",
			type = "map",
			list = {
				[GetSpellInfo(13225)] = true,		-- Wound Poison II
				[GetSpellInfo(13226)] = true,		-- Wound Poison III
				[GetSpellInfo(13227)] = true,		-- Wound Poison IV
				[GetSpellInfo(27188)] = true,		-- Wound Poison V
				[GetSpellInfo(57977)] = true,		-- Wound Poison VI
				[GetSpellInfo(57978)] = true,		-- Wound Poison VII
			},
		},

		[GetSpellInfo(2818)] = {					-- Deadly Poison (unranked name)
			class = "ROGUE",						-- Mapping for Master Poisoner to work
			type = "map",
			list = {
				[GetSpellInfo(2819)] = true,		-- Deadly Poison II
				[GetSpellInfo(11353)] = true,		-- Deadly Poison III
				[GetSpellInfo(11354)] = true,		-- Deadly Poison IV
				[GetSpellInfo(25349)] = true,		-- Deadly Poison V
				[GetSpellInfo(26968)] = true,		-- Deadly Poison VI
				[GetSpellInfo(27187)] = true,		-- Deadly Poison VII
				[GetSpellInfo(57969)] = true,		-- Deadly Poison VIII
				[GetSpellInfo(57970)] = true,		-- Deadly Poison IX
			},
		},

		[GetSpellInfo(58410)] = {					-- Master Poisoner
			class = "ROGUE",
			requiredTalent = GetSpellInfo(58410),	-- Master Poisoner
			type = "trigger",
			list = {
				[GetSpellInfo(3408)] = true,		-- Crippling Poison
				[GetSpellInfo(41190)] = true,		-- Mind-numbing Poison
				[GetSpellInfo(13218)] = true,		-- Wound Poison
				[GetSpellInfo(2818)] = true,		-- Deadly Poison
			},
		},

		[GetSpellInfo(53696)] = {					-- Judgements of the Just
			class = "PALADIN",
			requiredTalent = GetSpellInfo(53696),	-- Judgements of the Just
			type = "trigger",
			list = {
				[GetSpellInfo(53408)] = true,		-- Judgement of Wisdom
				[GetSpellInfo(20271)] = true,		-- Judgement of Light
				[GetSpellInfo(53407)] = true,		-- Judgement of Justice
			},
		},

		[GetSpellInfo(20140)] = {					-- Improved Devotion Aura
			class = "PALADIN",
			requiredTalent = GetSpellInfo(20140),	-- Improved Devotion Aura
			type = "trigger",
			list = paladinAuraList,
		},

		[GetSpellInfo(53648)] = {					-- Swift Retribution
			class = "PALADIN",
			requiredTalent = GetSpellInfo(53648),	-- Swift Retribution
			type = "trigger",
			list = paladinAuraList,
		},

		[GetSpellInfo(31869)] = {					-- Sanctified Retribution
			class = "PALADIN",
			requiredTalent = GetSpellInfo(31869),	-- Sanctified Retribution
			type = "trigger",
			list = paladinAuraList,
		},

		[GetSpellInfo(33602)] = {					-- Improved Faerie Fire
			class = "DRUID",
			requiredTalent = GetSpellInfo(33602),	-- Improved Faerie Fire
			type = "trigger",
			list = {
				[GetSpellInfo(770)] = true,			-- Faerie Fire
				[GetSpellInfo(16857)] = true,		-- Faerie Fire (Feral)
			},
		},

		[GetSpellInfo(48396)] = {					-- Improved Moonkin Form
			class = "DRUID",
			requiredTalent = GetSpellInfo(48396),	-- Moonkin Aura
			list = {
				[GetSpellInfo(24907)] = true,		-- Moonkin Aura
			}
		},

		[GetSpellInfo(33917)] = {
			class = "DRUID",
			requiredTalent = GetSpellInfo(33917),
			type = "trigger",
			list = {
				[GetSpellInfo(48564)] = true,		-- Mangle - Bear
				[GetSpellInfo(48566)] = true,		-- Mangle - Cat
			},
		},
	}
end

--[===[@debug@
for Type,data in pairs(Utopia.debuffs) do
	assert(type(Type) == "string")
	assert(data.spells)
	for spellID,info in pairs(data.spells) do
		assert(info.class)
		assert(type(spellID) == "number")
		if (info.amount) then
			assert(type(info.amount) == "number")
		elseif (info.amountsPerStack) then
			assert(info.rankLevels)
			assert(#info.amountsPerStack == #info.rankLevels)
		elseif (info.amounts) then
			assert(type(info.amounts) == "table")
			assert(info.rankLevels)
			assert(#info.amounts == #info.rankLevels)
		end
		if (info.rankIDs) then
			if (info.amounts) then
				assert(#info.rankIDs == #info.amounts)
			end
			if (info.rankLevels) then
				assert(#info.rankIDs == #info.rankLevels)
			end
			local spellName = GetSpellInfo(spellID)
			local n = GetSpellInfo(info.rankIDs[1])
			for i,id in ipairs(info.rankIDs) do
				if (GetSpellInfo(id) ~= spellName) then
					error(format("Utopia: [%q].rankIDs[%d] (%d) ~= %q", spellName, i, id, n))
				end
			end
			if (info.rankIDsAlternate) then
				assert(type(info.alternateOffset) == "number")
				assert(#info.rankIDsAlternate == #info.rankIDs + info.alternateOffset)
				n = GetSpellInfo(info.rankIDsAlternate[1])
				for i,id in ipairs(info.rankIDs) do
					if (GetSpellInfo(id) ~= n) then
						error(format("[%q].rankIDsAlternate[%d] (%d) ~= %q", spellName, i, id, n))
					end
				end
			end
		end
	end
end

for name,data in pairs(Utopia.mapping) do
	assert(data.class)
	assert(data.list)
	for spellName,True in pairs(data.list) do
		assert(type(spellName) == "string")
		assert(True)
	end
end

-- ValidateAgainstClassData
-- Checks maxTalentPoints values read from actual live talents by LGT against maxTalentPoints we have specified in our data

local LGT = LibStub("LibGroupTalents-1.0")

local function validateSub(mode, class)
	for cat,info in pairs(Utopia[mode]) do
		for id,spellInfo in pairs(info.spells) do
			if (spellInfo.class == class and LGT.classTalentData[spellInfo.class]) then
				if (spellInfo.maxTalentPoints) then
					local maxRank = LGT:GetClassTalentInfo(spellInfo.class, spellInfo.requiredTalent or spellInfo.improved)
					if (maxRank) then
						if (maxRank ~= spellInfo.maxTalentPoints) then
							error(format("Utopia.%s[%q].spells[%q].maxTalentPoints = %d. Live data = %d", mode, cat, spellInfo.requiredTalent or spellInfo.improved or "nil", spellInfo.maxTalentPoints, maxRank))
						end
					else
						error(format("Did not find talent called %s in %s data", spellInfo.requiredTalent or spellInfo.improved or "nil", spellInfo.class))
					end
				end
			end
		end
	end
end

function Utopia:ValidateAgainstClassData(class)
	validateSub("buffs", class)
	validateSub("debuffs", class)
end
--@end-debug@]===]
