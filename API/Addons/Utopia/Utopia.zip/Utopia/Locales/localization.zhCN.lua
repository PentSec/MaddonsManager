﻿local L = LibStub("AceLocale-3.0"):NewLocale("Utopia", "zhCN", true)
if not L then return end

L["Core Hound"] = "熔火恶犬" -- Needs review
L["Felhunter"] = "地狱猎犬" -- Needs review
L["Imp"] = "小鬼" -- Needs review
L["Sporebat"] = "孢子蝠" -- Needs review

