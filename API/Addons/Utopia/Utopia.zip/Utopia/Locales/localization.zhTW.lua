﻿local L = LibStub("AceLocale-3.0"):NewLocale("Utopia", "zhTW", true)
if not L then return end

L["%.1f mins"] = "%.1f 分"
L["Always Show"] = "總是顯示"
L["  by %s"] = "由%s"
L["  by %s (%s's pet)"] = "由 %s (%s的寵物)"
L["|cFF00FF00Ready!|r (%s)"] = "|cFF00FF00準備!|r (%s)"
L["|cFFFF8080Cooldown:|r %s"] = "|cFFFF8080冷卻:|r %s"
L["Core Hound"] = "熔核犬" -- Needs review
L["%d secs"] = "%d 秒"
L["%d%% without %s debuff"] = "%d%% 沒有 %s debuff"
L["Felhunter"] = "惡魔獵犬" -- Needs review
L["Icon Options"] = "圖示選項"
L["Icons"] = "圖示"
L["Icon Settings"] = "圖示設置"
L["Icon Size"] = "圖示尺寸"
L["Ignore Options"] = "忽略選項"
L["Imp"] = "小鬼" -- Needs review
L["%s changed talent set from |cFFFFFF80%s|r (%d/%d/%d) to |cFFFFFF80%s|r (%d/%d/%d)"] = "%s 已更改天賦設置從 |cFFFFFF80%s|r (%d/%d/%d) 到 |cFFFFFF80%s|r (%d/%d/%d)"
L["%s changed talent set from |cFFFFFF80%s|r to |cFFFFFF80%s|r"] = "%s 已更改天賦設置從 |cFFFFFF80%s|r 到 |cFFFFFF80%s|r"
L["%s changed talent set to |cFFFFFF80%s|r"] = "%s 已更改天賦設置至 |cFFFFFF80%s|r"
L["Search"] = "搜尋"
L["%s from %s"] = "%s 來自 %s"
L["Sporebat"] = "孢子蝙蝠" -- Needs review

