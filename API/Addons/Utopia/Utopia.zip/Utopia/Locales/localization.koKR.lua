﻿local L = LibStub("AceLocale-3.0"):NewLocale("Utopia", "koKR", true)
if not L then return end

L["Core Hound"] = "심장부 사냥개" -- Needs review
L["Felhunter"] = "지옥사냥개" -- Needs review
L["Imp"] = "임프" -- Needs review
L["Sporebat"] = "포자날개" -- Needs review

