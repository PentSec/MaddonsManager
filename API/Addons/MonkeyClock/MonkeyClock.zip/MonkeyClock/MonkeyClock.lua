-- OnLoad Function
function MonkeyClock_OnLoad(self)
	-- register events
	self:RegisterEvent("VARIABLES_LOADED")
end

-- OnEvent Function
function MonkeyClock_OnEvent(self, event)
	if (event == "VARIABLES_LOADED") then
		MonkeyClock_Init()
	end
end

-- OnUpdate Function
function MonkeyClock_OnUpdate(self, elapsed)
	-- how long since the last update?
	MonkeyClockTemp.deltaTime = MonkeyClockTemp.deltaTime + elapsed
	
	-- is it time for an update?
	if (MonkeyClockTemp.deltaTime > 1.0) then
		-- check the alarm
		MonkeyClock_AlarmCheck()
		
		-- Set the text for the clock
		MonkeyClockText:SetText(MonkeyClock_GetTimeText())
		MonkeyClockTemp.deltaTime = 0
	end
end

function MonkeyClock_AlarmCheck()
	local	iAlarmHour = MonkeyClockVars.alarmHour.value
	local	iAlarmMinute = MonkeyClockVars.alarmMinute.value
	
	local	iHour, iMinute = GetGameTime()
	
	iHour = iHour + MonkeyClockVars.hourOffset.value
	iMinute = iMinute + MonkeyClockVars.minuteOffset.value
	
	-- fix up the hours and mins
	if (iMinute > 59) then
		iMinute = iMinute - 60
		iHour = iHour + 1
	elseif (iMinute < 0) then
		iMinute = 60 + iMinute
		iHour = iHour - 1
	end
	if (iHour > 23) then
		iHour = iHour - 24
	elseif (iHour < 0) then
		iHour = 24 + iHour
	end
	
	-- considering the clock updates once every 1 second,
	-- this condition should always catch the alarm unless loading time interfers
	if ((iMinute == iAlarmMinute) and (iHour == iAlarmHour)) then
		if ((MonkeyClockTemp.prevAlarmHour ~= iHour) or (MonkeyClockTemp.prevAlarmMinute ~= iMinute)) then
			-- alarm hasn't rung yet
			MonkeyClockTemp.prevAlarmHour = iHour
			MonkeyClockTemp.prevAlarmMinute = iMinute
			
			if (MonkeyClockVars.useChatAlarm == true) then
				if (DEFAULT_CHAT_FRAME) then
					DEFAULT_CHAT_FRAME:AddMessage(MONKEYCLOCK_CONFIRM_ALARM .. "\n")
				end
			end
			
			if (MonkeyClockVars.useDialogAlarm == true) then
				StaticPopup_Show("MONKEYCLOCK_ALARM")
			end
		end
	end
end

-- called when the user snoozes
function MonkeyClock_AlarmSnooze()
	local	iAlarmHour = MonkeyClockVars.alarmHour.value
	local	iAlarmMinute = MonkeyClockVars.alarmMinute.value
	
	iAlarmMinute = iAlarmMinute + MonkeyClockVars.snoozeMinutes.value
	
	-- fix up the hours and mins
	if (iAlarmMinute > 59) then
		iAlarmMinute = iAlarmMinute - 60
		iAlarmHour = iAlarmHour + 1
	elseif (iAlarmMinute < 0) then
		iAlarmMinute = 60 + iAlarmMinute
		iAlarmHour = iAlarmHour - 1
	end
	if (iAlarmHour > 23) then
		iAlarmHour = iAlarmHour - 24
	elseif (iAlarmHour < 0) then
		iAlarmHour = 24 + iAlarmHour
	end
	
	MonkeyClockVars.alarmHour = iAlarmHour
	MonkeyClockVars.alarmMinute = iAlarmMinute
end

function MonkeyClock_OnMouseDown(self, button)
	if (button == "LeftButton" and MonkeyClockVars.frameLocked == false) then
		MonkeyClockFrame:StartMoving()
		return
	end
	-- right button on the title or frame opens up the Blizzard Options
	if (button == "RightButton") then
		if (MonkeyClockVars.rightClickOpensConfig == true) then
			InterfaceOptionsFrame_OpenToCategory("MonkeyClock")
		end
	end
end


function MonkeyClock_OnMouseUp(self, button)
	if (button == "LeftButton") then
		MonkeyClockFrame:StopMovingOrSizing()
	end
end

-- This function returns the time in a human readable string
function MonkeyClock_GetTimeText()
	local iHour, iMinute = GetGameTime()
	local bPM
	
	-- offset the local time from server time
	iHour = iHour + MonkeyClockVars.hourOffset.value
	iMinute = iMinute + MonkeyClockVars.minuteOffset.value
	
	-- fix up the hours and mins
	if (iMinute > 59) then
		iMinute = iMinute - 60
		iHour = iHour + 1
	elseif (iMinute < 0) then
		iMinute = 60 + iMinute
		iHour = iHour - 1
	end
	if (iHour > 23) then
		iHour = iHour - 24
	elseif (iHour < 0) then
		iHour = 24 + iHour
	end
	
	-- format the return string according to config settings
	if (MonkeyClockVars.use24) then
		return format(TEXT(TIME_TWENTYFOURHOURS), iHour, iMinute)
	else
		if (iHour >= 12) then
			bPM = 1
			iHour = iHour - 12
		else
			bPM = 0
		end
		if (iHour == 0) then
			iHour = 12
		end
		if (bPM == 1) then
			return format(TEXT(TIME_TWELVEHOURPM), iHour, iMinute)
		else
			return format(TEXT(TIME_TWELVEHOURAM), iHour, iMinute)
		end
	end
end

function MonkeyClock_shown_Changed()
	if (MonkeyClockVars.shown == false) then
		MonkeyClockFrame:Hide()
	else
		local var = MonkeyClockVars.frameColour
		MonkeyClockFrame:SetBackdropColor(var.r, var.g, var.b, var.a)
		MonkeyClockFrame:Show()
	end
end

function MonkeyClock_frameColour_Changed(prevColour)
	local var = MonkeyClockVars.frameColour
	if (prevColour) then
		var.r = prevColour.r
		var.g = prevColour.g
		var.b = prevColour.b
	else
		var.a = OpacitySliderFrame:GetValue()
		var.r, var.g, var.b = ColorPickerFrame:GetColorRGB()
	end
	getglobal("MonkeyClockC1_ColourBnt_SwatchTexture"):SetVertexColor(var.r, var.g, var.b)
	MonkeyClockFrame:SetBackdropColor(var.r, var.g, var.b, var.a)
end

function MonkeyClock_showBorder_Changed()
	local var = MonkeyClockVars.borderColour
	if (MonkeyClockVars.showBorder == false) then
		MonkeyClockFrame:SetBackdropBorderColor(0.0, 0.0, 0.0, 0.0)
	else
		MonkeyClockFrame:SetBackdropBorderColor(var.r, var.g, var.b)
	end
end

function MonkeyClock_borderColour_Changed(prevColour)
	local var = MonkeyClockVars.borderColour
	if (prevColour) then
		var.r = prevColour.r
		var.g = prevColour.g
		var.b = prevColour.b
	else
		var.r, var.g, var.b = ColorPickerFrame:GetColorRGB()
	end
	MonkeyClockVars.showBorder = true
	MonkeyClockCB2:SetChecked(MonkeyClockVars.showBorder)
	getglobal("MonkeyClockC2_ColourBnt_SwatchTexture"):SetVertexColor(var.r, var.g, var.b)
	MonkeyClockFrame:SetBackdropBorderColor(var.r, var.g, var.b)
end

function MonkeyClock_frameLocked_Changed()
	if (MonkeyClockVars.frameLocked == false and MonkeyClockFrame:IsVisible()) then
		MonkeyClockFrame:Hide()
		MonkeyClockResizerBtn:Show()
		MonkeyClockFrame:Show()
	elseif (MonkeyClockVars.frameLocked == false) then
		MonkeyClockResizerBtn:Show()
	elseif (MonkeyClockVars.frameLocked == true) then
		MonkeyClockResizerBtn:Hide()
	end
end

function MonkeyClock_use24_Changed()
	MonkeyClockText:SetText(MonkeyClock_GetTimeText())
end

function MonkeyClock_hourOffset_Changed()
	MonkeyClockText:SetText(MonkeyClock_GetTimeText())
end

function MonkeyClock_minuteOffset_Changed()
	MonkeyClockText:SetText(MonkeyClock_GetTimeText())
end

function MonkeyClockResizerBtn_OnMouseDown(self, button)
	if (button == "LeftButton") then
		this:GetParent():StartSizing()
	end
end

function MonkeyClockResizerBtn_OnMouseUp(self, button)
	if (button == "LeftButton") then
		this:GetParent():StopMovingOrSizing()
	end
end
