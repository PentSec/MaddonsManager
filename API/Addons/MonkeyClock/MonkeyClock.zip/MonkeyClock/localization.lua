-- English

-- MonkeyClock config variables descritions
MONKEYCLOCK_GENERAL_OPTIONS				= "General Options:"
MONKEYCLOCK_shown_DESC					= "Enable MonkeyClock"
MONKEYCLOCK_frameColour_DESC			= "Frame Color"
MONKEYCLOCK_showBorder_DESC				= "Display the border"
MONKEYCLOCK_borderColour_DESC			= "Border Color"
MONKEYCLOCK_frameLocked_DESC			= "Lock the frame position"
MONKEYCLOCK_use24_DESC					= "Use 24 hour format"
MONKEYCLOCK_useChatAlarm_DESC			= "Use the chat alarm notification"
MONKEYCLOCK_useDialogAlarm_DESC			= "Use the dialog alarm notification"
MONKEYCLOCK_MISC_OPTIONS				= "Miscellaneous Options:"
MONKEYCLOCK_rightClickOpensConfig_DESC	= "Right mouse click opens the config frame"
MONKEYCLOCK_hourOffset_DESC				= "Hour offset"
MONKEYCLOCK_minuteOffset_DESC			= "Minute offset"
MONKEYCLOCK_alarmHour_DESC				= "The alarm hour"
MONKEYCLOCK_alarmMinute_DESC			= "The alarm minute"
MONKEYCLOCK_snoozeMinutes_DESC			= "The amount of snooze minutes"

MONKEYCLOCK_CONFIRM_ALARM				= "The MonkeyClock alarm has gone off."
MONKEYCLOCK_SNOOZE						= "Snooze"
