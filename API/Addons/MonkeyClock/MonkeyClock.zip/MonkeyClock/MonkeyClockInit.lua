StaticPopupDialogs["MONKEYCLOCK_ALARM"] = {
	text = TEXT(MONKEYCLOCK_CONFIRM_ALARM),
	button1 = TEXT(MONKEYCLOCK_SNOOZE),
	button2 = TEXT(OKAY),
	OnAccept = function()
		MonkeyClock_AlarmSnooze()
	end,
	timeout = 0
}

-- Script array, not saved
MonkeyClockTemp = {}
MonkeyClockTemp.deltaTime = 0
-- used to prevent the alarm from ringing twice
MonkeyClockTemp.prevAlarmHour = nil
MonkeyClockTemp.prevAlarmMinute = nil

function MonkeyClock_Init()
	
	MonkeyClockFrame:SetMinResize(20, 20)
	
	if (MonkeyClockVars == nil) then
	MonkeyClockVars = {
		shown = true,
		showBorder = true,
		frameLocked = false,
		use24 = false,
		useChatAlarm = false,
		useDialogAlarm = false,
		rightClickOpensConfig = true,
		hourOffset = {
			value = 0,
			min = -12,
			max = 12,
			step = 1,
			},
		minuteOffset = {
			value = 0,
			min = -59,
			max = 59,
			step = 1,
			},
		alarmHour = {
			value = 0,
			min = 0,
			max = 23,
			step = 1,
			},
		alarmMinute = {
			value = 0,
			min = 0,
			max = 59,
			step = 1,
			},
		snoozeMinutes = {
			value = 5,
			min = 1,
			max = 45,
			step = 1,
			},
		frameColour = {
			r = 0,
			g = 0,
			b = 0,
			a = 1,
			},
		borderColour = {
			r = 1,
			g = 0.7,
			b = 0
			},
	}
	end
	
	MonkeyClockFrame:SetBackdropBorderColor(MonkeyClockVars.borderColour.r, MonkeyClockVars.borderColour.g, MonkeyClockVars.borderColour.b)
	
	MonkeyClock_shown_Changed()
	MonkeyClock_showBorder_Changed()
	MonkeyClock_frameLocked_Changed()
	
	local MonkeyClockOptions = CreateFrame("FRAME", "MonkeyClockOptions")
	MonkeyClockOptions.name = GetAddOnMetadata("MonkeyClock", "Title")
	MonkeyClockOptions.default = function (self) MonkeyClock_ResetConfig() end
	MonkeyClockOptions.refresh = function (self) MonkeyClock_RefreshConfig() end
	InterfaceOptions_AddCategory(MonkeyClockOptions)
	
	local MonkeyClockOptionsHeader = MonkeyClockOptions:CreateFontString(nil, "ARTWORK")
	MonkeyClockOptionsHeader:SetFontObject(GameFontNormalLarge)
	MonkeyClockOptionsHeader:SetPoint("TOPLEFT", 16, -16)
	MonkeyClockOptionsHeader:SetText(GetAddOnMetadata("MonkeyClock", "Title") .. " " .. GetAddOnMetadata("MonkeyClock", "Version"))
	
	local MonkeyClockGeneral = MonkeyClockOptions:CreateFontString(nil, "ARTWORK")
	MonkeyClockGeneral:SetFontObject(GameFontWhite)
	MonkeyClockGeneral:SetPoint("TOPLEFT", MonkeyClockOptionsHeader, "BOTTOMLEFT", 0, -6)
	MonkeyClockGeneral:SetText(MONKEYCLOCK_GENERAL_OPTIONS)
	
	local MonkeyClockCB1 = CreateFrame("CheckButton", "MonkeyClockCB1", MonkeyClockOptions, "OptionsCheckButtonTemplate")
	MonkeyClockCB1:SetPoint("TOPLEFT", MonkeyClockGeneral, "BOTTOMLEFT", 2, -4)
	MonkeyClockCB1:SetScript("OnClick", function(self) MonkeyClockVars.shown = (not MonkeyClockVars.shown)
																MonkeyClock_shown_Changed() end)
	MonkeyClockCB1Text:SetText(MONKEYCLOCK_shown_DESC)
	
	MonkeyClockC1 = CreateFrame("Button", "MonkeyClockC1" .. "_ColourBnt", MonkeyClockOptions, "MonkeyColourButtonTemplate")
	MonkeyClockC1:SetPoint("TOPLEFT", MonkeyClockGeneral, "BOTTOMLEFT", 175, -8)
	getglobal("MonkeyClockC1" .. "_ColourBnt_Text"):SetText(MONKEYCLOCK_frameColour_DESC)
	getglobal("MonkeyClockC1" .. "_ColourBnt_BorderTexture"):SetVertexColor(1.0, 1.0, 1.0)
	MonkeyClockC1:SetScript("OnClick", function(self) local colour = MonkeyClockVars.frameColour
		ColorPickerFrame:Hide()
		ColorPickerFrame.func = MonkeyClock_frameColour_Changed
		ColorPickerFrame.cancelFunc = MonkeyClock_frameColour_Changed
		ColorPickerFrame.opacityFunc = MonkeyClock_frameColour_Changed
		ColorPickerFrame.hasOpacity = true
		ColorPickerFrame.opacity = colour.a
		ColorPickerFrame:SetColorRGB(colour.r, colour.g, colour.b)
		ColorPickerFrame.previousValues = {r = colour.r, g = colour.g, b = colour.b, a = colour.a}
		ColorPickerFrame:Show()
	end)
	
	local MonkeyClockCB2 = CreateFrame("CheckButton", "MonkeyClockCB2", MonkeyClockOptions, "OptionsCheckButtonTemplate")
	MonkeyClockCB2:SetPoint("TOPLEFT", MonkeyClockCB1, "BOTTOMLEFT", 0, -4)
	MonkeyClockCB2:SetScript("OnClick", function(self) MonkeyClockVars.showBorder = (not MonkeyClockVars.showBorder)
																MonkeyClock_showBorder_Changed() end)
	MonkeyClockCB2Text:SetText(MONKEYCLOCK_showBorder_DESC)
	
	MonkeyClockC2 = CreateFrame("Button", "MonkeyClockC2" .. "_ColourBnt", MonkeyClockOptions, "MonkeyColourButtonTemplate")
	MonkeyClockC2:SetPoint("TOPLEFT", MonkeyClockCB1, "BOTTOMLEFT", 173, -8)
	getglobal("MonkeyClockC2" .. "_ColourBnt_Text"):SetText(MONKEYCLOCK_borderColour_DESC)
	getglobal("MonkeyClockC2" .. "_ColourBnt_BorderTexture"):SetVertexColor(1.0, 1.0, 1.0)
	MonkeyClockC2:SetScript("OnClick", function(self) local colour = MonkeyClockVars.borderColour
		ColorPickerFrame:Hide()
		ColorPickerFrame.func = MonkeyClock_borderColour_Changed
		ColorPickerFrame.cancelFunc = MonkeyClock_borderColour_Changed
		ColorPickerFrame.opacityFunc = nil
		ColorPickerFrame.hasOpacity = false
		ColorPickerFrame:SetColorRGB(colour.r, colour.g, colour.b)
		ColorPickerFrame.previousValues = {r = colour.r, g = colour.g, b = colour.b}
		ColorPickerFrame:Show()
	end)
	
	local MonkeyClockCB3 = CreateFrame("CheckButton", "MonkeyClockCB3", MonkeyClockOptions, "OptionsCheckButtonTemplate")
	MonkeyClockCB3:SetPoint("TOPLEFT", MonkeyClockCB2, "BOTTOMLEFT", 0, -4)
	MonkeyClockCB3:SetScript("OnClick", function(self) MonkeyClockVars.frameLocked = (not MonkeyClockVars.frameLocked)
																MonkeyClock_frameLocked_Changed() end)
	MonkeyClockCB3Text:SetText(MONKEYCLOCK_frameLocked_DESC)
	
	local MonkeyClockCB4 = CreateFrame("CheckButton", "MonkeyClockCB4", MonkeyClockOptions, "OptionsCheckButtonTemplate")
	MonkeyClockCB4:SetPoint("TOPLEFT", MonkeyClockCB3, "BOTTOMLEFT", 0, -4)
	MonkeyClockCB4:SetScript("OnClick", function(self) MonkeyClockVars.use24 = (not MonkeyClockVars.use24)
																MonkeyClock_use24_Changed() end)
	MonkeyClockCB4Text:SetText(MONKEYCLOCK_use24_DESC)
	
	local MonkeyClockCB5 = CreateFrame("CheckButton", "MonkeyClockCB5", MonkeyClockOptions, "OptionsCheckButtonTemplate")
	MonkeyClockCB5:SetPoint("TOPLEFT", MonkeyClockCB4, "BOTTOMLEFT", 0, -4)
	MonkeyClockCB5:SetScript("OnClick", function(self) MonkeyClockVars.useChatAlarm = (not MonkeyClockVars.useChatAlarm) end)
	MonkeyClockCB5Text:SetText(MONKEYCLOCK_useChatAlarm_DESC)
	
	local MonkeyClockCB6 = CreateFrame("CheckButton", "MonkeyClockCB6", MonkeyClockOptions, "OptionsCheckButtonTemplate")
	MonkeyClockCB6:SetPoint("TOPLEFT", MonkeyClockCB5, "BOTTOMLEFT", 0, -4)
	MonkeyClockCB6:SetScript("OnClick", function(self) MonkeyClockVars.useDialogAlarm = (not MonkeyClockVars.useDialogAlarm) end)
	MonkeyClockCB6Text:SetText(MONKEYCLOCK_useDialogAlarm_DESC)
	
	local MonkeyClockMisc = MonkeyClockOptions:CreateFontString(nil, "ARTWORK")
	MonkeyClockMisc:SetFontObject(GameFontWhite)
	MonkeyClockMisc:SetPoint("TOPLEFT", MonkeyClockCB6, "BOTTOMLEFT", -2, -4)
	MonkeyClockMisc:SetText(MONKEYCLOCK_MISC_OPTIONS)
	
	local MonkeyClockCB7 = CreateFrame("CheckButton", "MonkeyClockCB7", MonkeyClockOptions, "OptionsCheckButtonTemplate")
	MonkeyClockCB7:SetPoint("TOPLEFT", MonkeyClockMisc, "BOTTOMLEFT", 2, -4)
	MonkeyClockCB7:SetScript("OnClick", function(self) MonkeyClockVars.rightClickOpensConfig = (not MonkeyClockVars.rightClickOpensConfig) end)
	MonkeyClockCB7Text:SetText(MONKEYCLOCK_rightClickOpensConfig_DESC)
	
	MonkeyClockS1 = CreateFrame("Slider", "MonkeyClockS1", MonkeyClockOptions, "OptionsSliderTemplate")
	MonkeyClockS1:SetPoint("TOPLEFT", MonkeyClockCB7, "BOTTOMLEFT", 0, -20)
	MonkeyClockS1:SetScript("OnValueChanged", function(self, value) MonkeyClockVars.hourOffset.value = value MonkeyClock_hourOffset_Changed()
		getglobal(MonkeyClockS1:GetName().."Text"):SetText(MONKEYCLOCK_hourOffset_DESC .. " (" .. MonkeyClockVars.hourOffset.value .. ")")
	end)
	MonkeyClockS1:SetMinMaxValues(MonkeyClockVars.hourOffset.min, MonkeyClockVars.hourOffset.max)
	MonkeyClockS1:SetValueStep(MonkeyClockVars.hourOffset.step)
	MonkeyClockS1:SetValue(MonkeyClockVars.hourOffset.value)
	MonkeyClockS1Text:SetFontObject(GameFontNormal)
	MonkeyClockS1Text:SetText(MONKEYCLOCK_hourOffset_DESC .. " (" .. MonkeyClockVars.hourOffset.value .. ")")
	getglobal(MonkeyClockS1:GetName().."Low"):SetText(MonkeyClockVars.hourOffset.min)
	getglobal(MonkeyClockS1:GetName().."High"):SetText(MonkeyClockVars.hourOffset.max)
	
	MonkeyClockS2 = CreateFrame("Slider", "MonkeyClockS2", MonkeyClockOptions, "OptionsSliderTemplate")
	MonkeyClockS2:SetPoint("TOPLEFT", MonkeyClockCB7, "BOTTOMLEFT", 175, -20)
	MonkeyClockS2:SetScript("OnValueChanged", function(self, value) MonkeyClockVars.minuteOffset.value = value MonkeyClock_minuteOffset_Changed()
		getglobal(MonkeyClockS2:GetName().."Text"):SetText(MONKEYCLOCK_minuteOffset_DESC .. " (" .. MonkeyClockVars.minuteOffset.value .. ")")
	end)
	MonkeyClockS2:SetMinMaxValues(MonkeyClockVars.minuteOffset.min, MonkeyClockVars.minuteOffset.max)
	MonkeyClockS2:SetValueStep(MonkeyClockVars.minuteOffset.step)
	MonkeyClockS2:SetValue(MonkeyClockVars.minuteOffset.value)
	MonkeyClockS2Text:SetFontObject(GameFontNormal)
	MonkeyClockS2Text:SetText(MONKEYCLOCK_minuteOffset_DESC .. " (" .. MonkeyClockVars.minuteOffset.value .. ")")
	getglobal(MonkeyClockS2:GetName().."Low"):SetText(MonkeyClockVars.minuteOffset.min)
	getglobal(MonkeyClockS2:GetName().."High"):SetText(MonkeyClockVars.minuteOffset.max)
	
	MonkeyClockS3 = CreateFrame("Slider", "MonkeyClockS3", MonkeyClockOptions, "OptionsSliderTemplate")
	MonkeyClockS3:SetPoint("TOPLEFT", MonkeyClockS1, "BOTTOMLEFT", 0, -25)
	MonkeyClockS3:SetScript("OnValueChanged", function(self, value) MonkeyClockVars.alarmHour.value = value 
		getglobal(MonkeyClockS3:GetName().."Text"):SetText(MONKEYCLOCK_alarmHour_DESC .. " (" .. MonkeyClockVars.alarmHour.value .. ")")
	end)
	MonkeyClockS3:SetMinMaxValues(MonkeyClockVars.alarmHour.min, MonkeyClockVars.alarmHour.max)
	MonkeyClockS3:SetValueStep(MonkeyClockVars.alarmHour.step)
	MonkeyClockS3:SetValue(MonkeyClockVars.alarmHour.value)
	MonkeyClockS3Text:SetFontObject(GameFontNormal)
	MonkeyClockS3Text:SetText(MONKEYCLOCK_alarmHour_DESC .. " (" .. MonkeyClockVars.alarmHour.value .. ")")
	getglobal(MonkeyClockS3:GetName().."Low"):SetText(MonkeyClockVars.alarmHour.min)
	getglobal(MonkeyClockS3:GetName().."High"):SetText(MonkeyClockVars.alarmHour.max)
	
	MonkeyClockS4 = CreateFrame("Slider", "MonkeyClockS4", MonkeyClockOptions, "OptionsSliderTemplate")
	MonkeyClockS4:SetPoint("TOPLEFT", MonkeyClockS1, "BOTTOMLEFT", 175, -25)
	MonkeyClockS4:SetScript("OnValueChanged", function(self, value) MonkeyClockVars.alarmMinute.value = value
		getglobal(MonkeyClockS4:GetName().."Text"):SetText(MONKEYCLOCK_alarmMinute_DESC .. " (" .. MonkeyClockVars.alarmMinute.value .. ")")
	end)
	MonkeyClockS4:SetMinMaxValues(MonkeyClockVars.alarmMinute.min, MonkeyClockVars.alarmMinute.max)
	MonkeyClockS4:SetValueStep(MonkeyClockVars.alarmMinute.step)
	MonkeyClockS4:SetValue(MonkeyClockVars.alarmMinute.value)
	MonkeyClockS4Text:SetFontObject(GameFontNormal)
	MonkeyClockS4Text:SetText(MONKEYCLOCK_alarmMinute_DESC .. " (" .. MonkeyClockVars.alarmMinute.value .. ")")
	getglobal(MonkeyClockS4:GetName().."Low"):SetText(MonkeyClockVars.alarmMinute.min)
	getglobal(MonkeyClockS4:GetName().."High"):SetText(MonkeyClockVars.alarmMinute.max)
	
	MonkeyClockS5 = CreateFrame("Slider", "MonkeyClockS5", MonkeyClockOptions, "OptionsSliderTemplate")
	MonkeyClockS5:SetPoint("TOPLEFT", MonkeyClockS3, "BOTTOMLEFT", 0, -25)
	MonkeyClockS5:SetWidth(320)
	MonkeyClockS5:SetScript("OnValueChanged", function(self, value) MonkeyClockVars.snoozeMinutes.value = value
		getglobal(MonkeyClockS5:GetName().."Text"):SetText(MONKEYCLOCK_snoozeMinutes_DESC .. " (" .. MonkeyClockVars.snoozeMinutes.value .. ")")
	end)
	MonkeyClockS5:SetMinMaxValues(MonkeyClockVars.snoozeMinutes.min, MonkeyClockVars.snoozeMinutes.max)
	MonkeyClockS5:SetValueStep(MonkeyClockVars.snoozeMinutes.step)
	MonkeyClockS5:SetValue(MonkeyClockVars.snoozeMinutes.value)
	MonkeyClockS5Text:SetFontObject(GameFontNormal)
	MonkeyClockS5Text:SetText(MONKEYCLOCK_snoozeMinutes_DESC .. " (" .. MonkeyClockVars.snoozeMinutes.value .. ")")
	getglobal(MonkeyClockS5:GetName().."Low"):SetText(MonkeyClockVars.snoozeMinutes.min)
	getglobal(MonkeyClockS5:GetName().."High"):SetText(MonkeyClockVars.snoozeMinutes.max)
end

function MonkeyClock_ResetConfig()
	MonkeyClockVars.shown = true
	MonkeyClockVars.frameColour.r = 0
	MonkeyClockVars.frameColour.g = 0
	MonkeyClockVars.frameColour.b = 0
	MonkeyClockVars.frameColour.a = 1
	MonkeyClockVars.showBorder = true
	MonkeyClockVars.borderColour.r = 1
	MonkeyClockVars.borderColour.g = 0.7
	MonkeyClockVars.borderColour.b = 0
	MonkeyClockVars.frameLocked = false
	MonkeyClockVars.use24 = false
	MonkeyClockVars.useChatAlarm = false
	MonkeyClockVars.useDialogAlarm = false
	MonkeyClockVars.rightClickOpensConfig = true
	
	MonkeyClockS1:SetValue(0)
	MonkeyClockS2:SetValue(0)
	MonkeyClockS3:SetValue(0)
	MonkeyClockS4:SetValue(0)
	MonkeyClockS5:SetValue(5)
	
	MonkeyClockFrame:SetHeight(30)
	MonkeyClockFrame:SetWidth(110)
	MonkeyClockFrame:ClearAllPoints()
	MonkeyClockFrame:SetPoint("TOP", nil, "TOP", 0, -16)
	
	MonkeyClockFrame:SetBackdropBorderColor(MonkeyClockVars.borderColour.r, MonkeyClockVars.borderColour.g, MonkeyClockVars.borderColour.b)
	
	MonkeyClock_shown_Changed()
	MonkeyClock_showBorder_Changed()
	MonkeyClock_frameLocked_Changed()
end

function MonkeyClock_RefreshConfig()
	MonkeyClockCB1:SetChecked(MonkeyClockVars.shown)
	MonkeyClockCB2:SetChecked(MonkeyClockVars.showBorder)
	MonkeyClockCB3:SetChecked(MonkeyClockVars.frameLocked)
	MonkeyClockCB4:SetChecked(MonkeyClockVars.use24)
	MonkeyClockCB5:SetChecked(MonkeyClockVars.useChatAlarm)
	MonkeyClockCB6:SetChecked(MonkeyClockVars.useDialogAlarm)
	MonkeyClockCB7:SetChecked(MonkeyClockVars.rightClickOpensConfig)
	
	getglobal("MonkeyClockC1_ColourBnt_SwatchTexture"):SetVertexColor(MonkeyClockVars.frameColour.r, MonkeyClockVars.frameColour.g, MonkeyClockVars.frameColour.b)
	getglobal("MonkeyClockC2_ColourBnt_SwatchTexture"):SetVertexColor(MonkeyClockVars.borderColour.r, MonkeyClockVars.borderColour.g, MonkeyClockVars.borderColour.b)
end