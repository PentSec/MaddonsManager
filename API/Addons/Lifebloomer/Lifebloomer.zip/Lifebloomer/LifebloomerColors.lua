﻿
function Lifebloomer_OnLoad_Colors()
	if not LBSaved.RaidIconAlpha then
		LBSaved.RaidIconAlpha = 0.75
	end

	if LBColors then
		local i = 1;
		LifebloomerMainFrameUnitFrame1:SetBackdropColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
		local i = 2;
		LifebloomerMainFrameUnitFrame1HPBar:SetStatusBarColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
		local i = 3;
		LifebloomerMainFrameUnitFrame1LBBar:SetStatusBarColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
		local i = 4;
		LifebloomerMainFrameUnitFrame1RejuvBar:SetStatusBarColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
		local i = 5;
		LifebloomerMainFrameUnitFrame1RegroBar:SetStatusBarColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
		if LBColors[14] then
			local i = 14;
			LifebloomerMainFrameUnitFrame1LBBarNumber:SetTextColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
			local i = 15;
			LifebloomerMainFrameUnitFrame1LBBarTimer:SetTextColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
			if LBColors[16] then
				local i = 16;
				LifebloomerMainFrameUnitFrame1WildBar:SetStatusBarColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
			else
			--Wild Growth
				LBColors[16] = {};
				LBColors[16].R = 1;
				LBColors[16].G = 1;
				LBColors[16].B = 0;
				LBColors[16].A = 1;
			end

                        if LBColors[17] then
				local i = 17;
				LifebloomerMainFrameUnitFrame1AbolishBar:SetStatusBarColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
                        else
                        --Abolish Poison
                                LBColors[17] = {};
                                LBColors[17].R = 0;
                                LBColors[17].G = 1;
                                LBColors[17].B = 0.5;
                                LBColors[17].A = 1;
                        end
		else
			--Boarder
				LBColors[6] = {};
				LBColors[6].R = 1;
				LBColors[6].G = 1;
				LBColors[6].B = 1;
				LBColors[6].A = 0.75;
			--Cursed
				LBColors[7] = {};
				LBColors[7].R = 1;
				LBColors[7].G = 0;
				LBColors[7].B = 1;
				LBColors[7].A = 0.75;
			--Poisoned
				LBColors[8] = {};
				LBColors[8].R = 0;
				LBColors[8].G = 1;
				LBColors[8].B = 0;
				LBColors[8].A = 0.75;
			--Curse + Poison
				LBColors[9] = {};
				LBColors[9].R = 1;
				LBColors[9].G = 0;
				LBColors[9].B = 0;
				LBColors[9].A = 0.75;
			--In Range
				LBColors[10] = {};
				LBColors[10].R = 0;
				LBColors[10].G = 0.1;
				LBColors[10].B = 0;
				LBColors[10].A = 0.5;
			--Out of Range
				LBColors[11] = {};
				LBColors[11].R = 0.5;
				LBColors[11].G = 0;
				LBColors[11].B = 0;
				LBColors[11].A = 1;
			--Has Agro
				LBColors[12] = {};
				LBColors[12].R = 1;
				LBColors[12].G = 1;
				LBColors[12].B = 0;
				LBColors[12].A = 1;
			--No Agro
				LBColors[13] = {};
				LBColors[13].R = 0;
				LBColors[13].G = 1;
				LBColors[13].B = 1;
				LBColors[13].A = 1;
			--LB Count
				LBColors[14] = {};
				LBColors[14].R = 1;
				LBColors[14].G = 1;
				LBColors[14].B = 1;
				LBColors[14].A = 1;
			--LB Timer
				LBColors[15] = {};
				LBColors[15].R = 1;
				LBColors[15].G = 1;
				LBColors[15].B = 1;
				LBColors[15].A = 1;
			--Wild Growth
				LBColors[16] = {};
				LBColors[16].R = 1;
				LBColors[16].G = 1;
				LBColors[16].B = 0;
				LBColors[16].A = 1;
                        --Abolish Poison
                                LBColors[17] = {};
                                LBColors[17].R = 0;
                                LBColors[17].G = 1;
                                LBColors[17].B = 0.5;
                                LBColors[17].A = 1;
		end
	else
		LBColors = {};
	--Background
		LBColors[1] = {};
		LBColors[1].R = 0;
		LBColors[1].G = 0;
		LBColors[1].B = 0;
		LBColors[1].A = .25;
	--Health
		LBColors[2] = {};
		LBColors[2].R = 0;
		LBColors[2].G = 1;
		LBColors[2].B = 0;
		LBColors[2].A = 1;
	--Lifebloom
		LBColors[3] = {};
		LBColors[3].R = 0;
		LBColors[3].G = .4;
		LBColors[3].B = 1;
		LBColors[3].A = 0.88;
	--Rejuv
		LBColors[4] = {};
		LBColors[4].R = .78;
		LBColors[4].G = 0;
		LBColors[4].B = .78;
		LBColors[4].A = 1;
	--Regrowth
		LBColors[5] = {};
		LBColors[5].R = 0;
		LBColors[5].G = 1;
		LBColors[5].B = 0;
		LBColors[5].A = 1;
	--Boarder ******************************************************************
		LBColors[6] = {};
		LBColors[6].R = 1;
		LBColors[6].G = 1;
		LBColors[6].B = 1;
		LBColors[6].A = 0.75;
	--Cursed
		LBColors[7] = {};
		LBColors[7].R = 1;
		LBColors[7].G = 0;
		LBColors[7].B = 1;
		LBColors[7].A = 0.75;
	--Poisoned
		LBColors[8] = {};
		LBColors[8].R = 0;
		LBColors[8].G = 1;
		LBColors[8].B = 0;
		LBColors[8].A = 0.75;
	--Curse + Poison
		LBColors[9] = {};
		LBColors[9].R = 1;
		LBColors[9].G = 0;
		LBColors[9].B = 0;
		LBColors[9].A = 0.75;
	--In Range
		LBColors[10] = {};
		LBColors[10].R = 0;
		LBColors[10].G = 0.1;
		LBColors[10].B = 0;
		LBColors[10].A = 0.5;
	--Out of Range
		LBColors[11] = {};
		LBColors[11].R = 0.5;
		LBColors[11].G = 0;
		LBColors[11].B = 0;
		LBColors[11].A = 1;
	--Has Agro
		LBColors[12] = {};
		LBColors[12].R = 1;
		LBColors[12].G = 1;
		LBColors[12].B = 0;
		LBColors[12].A = 1;
	--No Agro
		LBColors[13] = {};
		LBColors[13].R = 0;
		LBColors[13].G = 1;
		LBColors[13].B = 1;
		LBColors[13].A = 1;
	--LB Count
		LBColors[14] = {};
		LBColors[14].R = 1;
		LBColors[14].G = 1;
		LBColors[14].B = 1;
		LBColors[14].A = 1;
	--LB Timer
		LBColors[15] = {};
		LBColors[15].R = 1;
		LBColors[15].G = 1;
		LBColors[15].B = 1;
		LBColors[15].A = 1;
	--Wild Growth
		LBColors[16] = {};
		LBColors[16].R = 1;
		LBColors[16].G = 1;
		LBColors[16].B = 0;
		LBColors[16].A = 1;
        --Abolish Poison
		LBColors[17] = {};
		LBColors[17].R = 0;
		LBColors[17].G = 1;
		LBColors[17].B = 0.5;
		LBColors[17].A = 1;
	end
	
	LB_Buffer.LBColors = {};
	LB_Buffer.LBColors = Lifebloomer_deepcopy(LBColors);
	LB_Buffer.Debuff = 0;		-- 0: none, 1: curse, 2: poison, 3: both
	LB_Buffer.Range = 1;		-- 0: out, 1: in
	LB_Buffer.Agro = 0;			-- 0: no, 1: yes
	Lifebloomer_SetColors_Sample();
end

function Lifebloomer_SetColors_Sample()
	local i = 1;
	LifebloomerOptionsAppearanceSample:SetBackdropColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	LifebloomerOptionsDimensionsSample:SetBackdropColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	local i = 2;
	LifebloomerOptionsAppearanceSampleHPBar:SetStatusBarColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	LifebloomerOptionsDimensionsSampleHPBar:SetStatusBarColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	local i = 3;
	LifebloomerOptionsAppearanceSampleLBBar:SetStatusBarColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	LifebloomerOptionsDimensionsSampleLBBar:SetStatusBarColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	local i = 4;
	LifebloomerOptionsAppearanceSampleRejuvBar:SetStatusBarColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	LifebloomerOptionsDimensionsSampleRejuvBar:SetStatusBarColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	local i = 5;
	LifebloomerOptionsAppearanceSampleRegroBar:SetStatusBarColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	LifebloomerOptionsDimensionsSampleRegroBar:SetStatusBarColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	local i = 6 + LB_Buffer.Debuff;
	LifebloomerOptionsAppearanceSample:SetBackdropBorderColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	LifebloomerOptionsDimensionsSample:SetBackdropBorderColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	local i = 11 - LB_Buffer.Range;
	LifebloomerOptionsAppearanceSampleHPBarName:SetTextColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	LifebloomerOptionsDimensionsSampleHPBarName:SetTextColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	local i = 13 - LB_Buffer.Agro;
	LifebloomerOptionsAppearanceSampleHPBarDTPS:SetTextColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	LifebloomerOptionsDimensionsSampleHPBarDTPS:SetTextColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	local i = 14;
	LifebloomerOptionsAppearanceSampleLBBarNumber:SetTextColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	LifebloomerOptionsDimensionsSampleLBBarNumber:SetTextColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	local i = 15;
	LifebloomerOptionsAppearanceSampleLBBarTimer:SetTextColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	LifebloomerOptionsDimensionsSampleLBBarTimer:SetTextColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	local i = 16;
	LifebloomerOptionsAppearanceSampleWildBar:SetStatusBarColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	LifebloomerOptionsDimensionsSampleWildBar:SetStatusBarColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	local i = 17;
	LifebloomerOptionsAppearanceSampleAbolishBar:SetStatusBarColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	LifebloomerOptionsDimensionsSampleAbolishBar:SetStatusBarColor(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	for i=1, 17, 1 do
		getglobal("LifebloomerOptionsAppearanceTexture"..i.."Texture"):SetTexture(LB_Buffer.LBColors[i].R, LB_Buffer.LBColors[i].G, LB_Buffer.LBColors[i].B, LB_Buffer.LBColors[i].A);
	end
end

function Lifebloomer_Color(preval)
	if not preval then
		LB_Buffer.LBColors[LBColorID].R, LB_Buffer.LBColors[LBColorID].G, LB_Buffer.LBColors[LBColorID].B = ColorPickerFrame:GetColorRGB();
	else
		LB_Buffer.LBColors[LBColorID].R, LB_Buffer.LBColors[LBColorID].G, LB_Buffer.LBColors[LBColorID].B, LB_Buffer.LBColors[LBColorID].A = unpack(preval);
	end
	Lifebloomer_SetColors_Sample();
end

function Lifebloomer_Opacity()
	LB_Buffer.LBColors[LBColorID].A = OpacitySliderFrame:GetValue();
	Lifebloomer_SetColors_Sample();
end

function Lifebloomer_SetColors()
	local n = getn(LBV) + LBVFF;
	while n > 0 do
		local i = 1;
		getglobal("LifebloomerMainFrameUnitFrame"..n):SetBackdropColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
		local i = 2;
		getglobal("LifebloomerMainFrameUnitFrame"..n.."HPBar"):SetStatusBarColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
		local i = 3;
		getglobal("LifebloomerMainFrameUnitFrame"..n.."LBBar"):SetStatusBarColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
		local i = 4;
		getglobal("LifebloomerMainFrameUnitFrame"..n.."RejuvBar"):SetStatusBarColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
		local i = 5;
		getglobal("LifebloomerMainFrameUnitFrame"..n.."RegroBar"):SetStatusBarColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
		local i = 14;
		getglobal("LifebloomerMainFrameUnitFrame"..n.."LBBarNumber"):SetTextColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
		local i = 16;
		getglobal("LifebloomerMainFrameUnitFrame"..n.."WildBar"):SetStatusBarColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
		local i = 17;
		getglobal("LifebloomerMainFrameUnitFrame"..n.."AbolishBar"):SetStatusBarColor(LBColors[i].R, LBColors[i].G, LBColors[i].B, LBColors[i].A);
		n = n - 1;
	end
	Lifebloomer_RefreshAllRaidIcons();
end

function Lifebloomer_OptionsAppearance_Accept()
	LBColors = Lifebloomer_deepcopy(LB_Buffer.LBColors);
	Lifebloomer_SetColors();
end

function Lifebloomer_OptionsAppearance_Cancel()
	LB_Buffer.LBColors = Lifebloomer_deepcopy(LBColors);
	Lifebloomer_SetColors_Sample();
end

function Lifebloomer_OptionsAppearance_Default()
--Background
	LB_Buffer.LBColors[1].R = 0;
	LB_Buffer.LBColors[1].G = 0;
	LB_Buffer.LBColors[1].B = 0;
	LB_Buffer.LBColors[1].A = .25;
--Health
	LB_Buffer.LBColors[2].R = 0;
	LB_Buffer.LBColors[2].G = 1;
	LB_Buffer.LBColors[2].B = 0;
	LB_Buffer.LBColors[2].A = 1;
--Lifebloom
	LB_Buffer.LBColors[3].R = 0;
	LB_Buffer.LBColors[3].G = .4;
	LB_Buffer.LBColors[3].B = 1;
	LB_Buffer.LBColors[3].A = 0.88;
--Rejuv
	LB_Buffer.LBColors[4].R = .78;
	LB_Buffer.LBColors[4].G = 0;
	LB_Buffer.LBColors[4].B = .78;
	LB_Buffer.LBColors[4].A = 1;
--Regrowth
	LB_Buffer.LBColors[5].R = 0;
	LB_Buffer.LBColors[5].G = 1;
	LB_Buffer.LBColors[5].B = 0;
	LB_Buffer.LBColors[5].A = 1;
--Boarder
	LB_Buffer.LBColors[6].R = 1;
	LB_Buffer.LBColors[6].G = 1;
	LB_Buffer.LBColors[6].B = 1;
	LB_Buffer.LBColors[6].A = 0.75;
--Cursed
	LB_Buffer.LBColors[7].R = 1;
	LB_Buffer.LBColors[7].G = 0;
	LB_Buffer.LBColors[7].B = 1;
	LB_Buffer.LBColors[7].A = 0.75;
--Poisoned
	LB_Buffer.LBColors[8].R = 0;
	LB_Buffer.LBColors[8].G = 1;
	LB_Buffer.LBColors[8].B = 0;
	LB_Buffer.LBColors[8].A = 0.75;
--Curse + Poison
	LB_Buffer.LBColors[9].R = 1;
	LB_Buffer.LBColors[9].G = 0;
	LB_Buffer.LBColors[9].B = 0;
	LB_Buffer.LBColors[9].A = 0.75;
--In Range
	LB_Buffer.LBColors[10].R = 0;
	LB_Buffer.LBColors[10].G = 0.1;
	LB_Buffer.LBColors[10].B = 0;
	LB_Buffer.LBColors[10].A = 0.5;
--Out of Range
	LB_Buffer.LBColors[11].R = 0.5;
	LB_Buffer.LBColors[11].G = 0;
	LB_Buffer.LBColors[11].B = 0;
	LB_Buffer.LBColors[11].A = 1;
--Has Agro
	LB_Buffer.LBColors[12].R = 1;
	LB_Buffer.LBColors[12].G = 1;
	LB_Buffer.LBColors[12].B = 0;
	LB_Buffer.LBColors[12].A = 1;
--No Agro
	LB_Buffer.LBColors[13].R = 0;
	LB_Buffer.LBColors[13].G = 1;
	LB_Buffer.LBColors[13].B = 1;
	LB_Buffer.LBColors[13].A = 1;
--LB Count
	LB_Buffer.LBColors[14].R = 1;
	LB_Buffer.LBColors[14].G = 1;
	LB_Buffer.LBColors[14].B = 1;
	LB_Buffer.LBColors[14].A = 1;
--LB Timer
	LB_Buffer.LBColors[15].R = 1;
	LB_Buffer.LBColors[15].G = 1;
	LB_Buffer.LBColors[15].B = 1;
	LB_Buffer.LBColors[15].A = 1;
--Wild Growth
	LB_Buffer.LBColors[16] = {};
	LB_Buffer.LBColors[16].R = 1;
	LB_Buffer.LBColors[16].G = 1;
	LB_Buffer.LBColors[16].B = 0;
	LB_Buffer.LBColors[16].A = 1;
--Condition Settings
	LB_Buffer.Debuff = 0;		-- 0: none, 1: curse, 2: poison, 3: both
	LB_Buffer.Range = 1;		-- 0: out, 1: in
	LB_Buffer.Agro = 0;			-- 0: no, 1: yes
	
	Lifebloomer_SetColors_Sample();
end

-- vim: sw=8 sts=8 noexpandtab 
