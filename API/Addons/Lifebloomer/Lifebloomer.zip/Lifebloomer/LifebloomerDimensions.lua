﻿
function Lifebloomer_OnLoad_Dimensions()
	if LBDim then
		if LBDim.wild then
		else
			LBDim.wild = 2;
			if LBDim.rej then
			else
				LBDim.rej = 2;
				LBDim.reg = 2;
				LBDim.wild = 2;
			end
		end
                if not LBDim.fpc then
                  LBDim.fpc = 5;
                end
                if not LBDim.hs then
                  LBDim.hs = 8;
                end
                if not LBDim.abolish then
                  LBDim.abolish = 2;
                end
	else
		LBDim = {};
		LBDim.h = 40;
		LBDim.w = 180;
		LBDim.s = 0;
                LBDim.hs = 8; -- Horizontal separation
                LBDim.fpc = 5; -- Frames per Column
		LBDim.rej = 2;
		LBDim.reg = 2;
		LBDim.wild = 2;
                LBDim.abolish = 2;
	end
	
	LB_Buffer.LBDim = {};
	LB_Buffer.LBDim = Lifebloomer_deepcopy(LBDim);
	
	Lifebloomer_AdjustH_Sample();
	Lifebloomer_AdjustW_Sample();
	--Lifebloomer_AdjustS_Sample();
	Lifebloomer_AdjustRejuv_Sample();
	Lifebloomer_AdjustRegro_Sample();
	Lifebloomer_AdjustWild_Sample();
	Lifebloomer_AdjustAbolish_Sample();
	
	Lifebloomer_AdjustH();
	Lifebloomer_AdjustW();
	Lifebloomer_AdjustS();
	Lifebloomer_AdjustRejuv();
	Lifebloomer_AdjustRegro();
	Lifebloomer_AdjustWild();
	Lifebloomer_AdjustAbolish();
end

function Lifebloomer_AdjustH_Sample()
	LifebloomerOptionsDimensionsSample:SetHeight(LB_Buffer.LBDim.h);
end

function Lifebloomer_AdjustH()
	local nv = getn(LBV);
	local n = nv + LBVFF;
	while n > 0 do
		getglobal("LifebloomerMainFrameUnitFrame"..n):SetHeight(LBDim.h);
		getglobal("LifebloomerMainFrameUnitFrame"..n.."TargetButton"):SetHeight((LBDim.h-10)/3);
		getglobal("LifebloomerMainFrameUnitFrame"..n.."TargetButton"):SetWidth((LBDim.h-10)/3);
		getglobal("LifebloomerMainFrameUnitFrame"..n.."ReduceButton"):SetHeight((LBDim.h-10)/3);
		getglobal("LifebloomerMainFrameUnitFrame"..n.."ReduceButton"):SetWidth((LBDim.h-10)/3);
		getglobal("LifebloomerMainFrameUnitFrame"..n.."IncreaseButton"):SetHeight((LBDim.h-10)/3);
		getglobal("LifebloomerMainFrameUnitFrame"..n.."IncreaseButton"):SetWidth((LBDim.h-10)/3);
		n = n - 1;
	end
        if LBDim.fpc > 0 then
                LifebloomerMainFrame:SetHeight(16 + (LBDim.h * min(nv, LBDim.fpc)) + (LBDim.s * (min(nv, LBDim.fpc) - 1)));
        else
                -- If fpc == 0 then revert to old method of setting height
                LifebloomerMainFrame:SetHeight(16 + (LBDim.h * nv) + (LBDim.s * (nv - 1)));
        end
end

function Lifebloomer_AdjustW_Sample()
	LifebloomerOptionsDimensionsSample:SetWidth(LB_Buffer.LBDim.w);
	LifebloomerOptionsDimensionsSampleLBBarGCD:ClearAllPoints();
	LifebloomerOptionsDimensionsSampleLBBarGCD:SetPoint("TOP", "LifebloomerOptionsDimensionsSampleLBBar", "TOPLEFT", LB_Buffer.LBDim.w*(1.5*(100-GetCombatRatingBonus(20))/100)/7, -1);
	LifebloomerOptionsDimensionsSampleLBBarGCD:SetPoint("BOTTOM", "LifebloomerOptionsDimensionsSampleLBBar", "BOTTOMLEFT", LB_Buffer.LBDim.w*(1.5*(100-GetCombatRatingBonus(20))/100)/7, 1);
end

function Lifebloomer_AdjustW()
	local nv = getn(LBV);
	local n = nv + LBVFF;
	while n > 0 do
		local self = getglobal("LifebloomerMainFrameUnitFrame"..n)
		self:SetWidth(LBDim.w);
		getglobal("LifebloomerMainFrameUnitFrame"..n.."LBBarGCD"):ClearAllPoints();
		getglobal("LifebloomerMainFrameUnitFrame"..n.."LBBarGCD"):SetPoint("TOP", "LifebloomerMainFrameUnitFrame"..n.."LBBar", "TOPLEFT", (LBDim.w-10)/self.LBMax*LB_GCD_Time, -1);
		getglobal("LifebloomerMainFrameUnitFrame"..n.."LBBarGCD"):SetPoint("BOTTOM", "LifebloomerMainFrameUnitFrame"..n.."LBBar", "BOTTOMLEFT", (LBDim.w-10)/self.LBMax*LB_GCD_Time, 1);
		n = n - 1;
	end
        -- Leaving this for now -- let the GCD frame sweep across only the first column.
	LifebloomerMainFrame:SetWidth(LBDim.w);
	--LifebloomerMainFrame:SetWidth(ceil(nv / LBDim.fpc) * LBDim.w + ((ceil(nv / LBDim.fpc) - 1) * LBDim.hs));
end

function Lifebloomer_AdjustS_Sample()
	local nv = getn(LBV);
	local n = nv + LBVFF;
	while n > 1 do
		getglobal("LifebloomerMainFrameUnitFrame"..n):ClearAllPoints();
                -- If frames-per-column is non-zero then use modular arithmetic to wrap frames into columns.
                if LBDim.fpc > 0 and n > 1 and (n % LBDim.fpc == 1 or LBDim.fpc == 1) then
                  getglobal("LifebloomerMainFrameUnitFrame"..n):SetPoint("LEFT", "LifebloomerMainFrameUnitFrame"..(n-LBDim.fpc), "RIGHT", LBDim.hs, 0);
                else
		  getglobal("LifebloomerMainFrameUnitFrame"..n):SetPoint("TOP", "LifebloomerMainFrameUnitFrame"..(n-1), "BOTTOM", 0, -LBDim.s);
                end
		n = n - 1;
	end
        if LBDim.fpc > 0 then
                LifebloomerMainFrame:SetHeight(16 + (LBDim.h * min(nv, LBDim.fpc)) + (LBDim.s * (min(nv, LBDim.fpc) - 1)));
        else
                -- If fpc == 0 then revert to old method of setting height
                LifebloomerMainFrame:SetHeight(16 + (LBDim.h * nv) + (LBDim.s * (nv - 1)));
        end
end

function Lifebloomer_AdjustS()
	local nv = getn(LBV);
	local n = nv + LBVFF;
	while n > 1 do
		getglobal("LifebloomerMainFrameUnitFrame"..n):ClearAllPoints();
                -- If frames-per-column is non-zero then use modular arithmetic to wrap frames into columns.
                if LBDim.fpc > 0 and n > 1 and (n % LBDim.fpc == 1 or LBDim.fpc == 1) then
                  getglobal("LifebloomerMainFrameUnitFrame"..n):SetPoint("LEFT", "LifebloomerMainFrameUnitFrame"..(n-LBDim.fpc), "RIGHT", LBDim.hs, 0);
                else
		  getglobal("LifebloomerMainFrameUnitFrame"..n):SetPoint("TOP", "LifebloomerMainFrameUnitFrame"..(n-1), "BOTTOM", 0, -LBDim.s);
                end
		n = n - 1;
	end
        if LBDim.fpc > 0 then
                LifebloomerMainFrame:SetHeight(16 + (LBDim.h * min(nv, LBDim.fpc)) + (LBDim.s * (min(nv, LBDim.fpc) - 1)));
        else
                -- If fpc == 0 then revert to old method of setting height
                LifebloomerMainFrame:SetHeight(16 + (LBDim.h * nv) + (LBDim.s * (nv - 1)));
        end
end

function Lifebloomer_AdjustRejuv_Sample()
	if LB_Buffer.LBDim.rej == 0 then
		LifebloomerOptionsDimensionsSampleRejuvBar:Hide();
		LifebloomerOptionsAppearanceSampleRejuvBar:Hide();
	else
		LifebloomerOptionsDimensionsSampleRejuvBar:Show();
		LifebloomerOptionsAppearanceSampleRejuvBar:Show();
		LifebloomerOptionsDimensionsSampleRejuvBar:SetHeight(LB_Buffer.LBDim.rej);
		LifebloomerOptionsAppearanceSampleRejuvBar:SetHeight(LB_Buffer.LBDim.rej);
	end
end

function Lifebloomer_AdjustRejuv()
	local nv = getn(LBV);
	local n = nv + LBVFF;
	while n > 0 do
		if LBDim.rej == 0 then
			getglobal("LifebloomerMainFrameUnitFrame"..n.."RejuvBar"):Hide();
		else
			getglobal("LifebloomerMainFrameUnitFrame"..n.."RejuvBar"):Show();
			getglobal("LifebloomerMainFrameUnitFrame"..n.."RejuvBar"):SetHeight(LBDim.rej);
		end
		n = n - 1;
	end
end

function Lifebloomer_AdjustRegro_Sample()
	if LB_Buffer.LBDim.reg == 0 then
		LifebloomerOptionsDimensionsSampleRegroBar:Hide();
		LifebloomerOptionsAppearanceSampleRegroBar:Hide();
	else
		LifebloomerOptionsDimensionsSampleRegroBar:Show();
		LifebloomerOptionsAppearanceSampleRegroBar:Show();
		LifebloomerOptionsDimensionsSampleRegroBar:SetHeight(LB_Buffer.LBDim.reg);
		LifebloomerOptionsAppearanceSampleRegroBar:SetHeight(LB_Buffer.LBDim.reg);
	end
end

function Lifebloomer_AdjustRegro()
	local nv = getn(LBV);
	local n = nv + LBVFF;
	while n > 0 do
		if LBDim.reg == 0 then
			getglobal("LifebloomerMainFrameUnitFrame"..n.."RegroBar"):Hide();
		else
			getglobal("LifebloomerMainFrameUnitFrame"..n.."RegroBar"):Show();
			getglobal("LifebloomerMainFrameUnitFrame"..n.."RegroBar"):SetHeight(LBDim.reg);
		end
		n = n - 1;
	end
end

function Lifebloomer_AdjustWild_Sample()
	if LB_Buffer.LBDim.wild == 0 then
		LifebloomerOptionsDimensionsSampleWildBar:Hide();
		LifebloomerOptionsAppearanceSampleWildBar:Hide();
	else
		LifebloomerOptionsDimensionsSampleWildBar:Show();
		LifebloomerOptionsAppearanceSampleWildBar:Show();
		LifebloomerOptionsDimensionsSampleWildBar:SetHeight(LB_Buffer.LBDim.wild);
		LifebloomerOptionsAppearanceSampleWildBar:SetHeight(LB_Buffer.LBDim.wild);
	end
end

function Lifebloomer_AdjustWild()
	local nv = getn(LBV);
	local n = nv + LBVFF;
	while n > 0 do
		if LBDim.reg == 0 then
			getglobal("LifebloomerMainFrameUnitFrame"..n.."WildBar"):Hide();
		else
			getglobal("LifebloomerMainFrameUnitFrame"..n.."WildBar"):Show();
			getglobal("LifebloomerMainFrameUnitFrame"..n.."WildBar"):SetHeight(LBDim.wild);
		end
		n = n - 1;
	end
end

function Lifebloomer_AdjustAbolish_Sample()
	if LB_Buffer.LBDim.abolish == 0 then
		LifebloomerOptionsDimensionsSampleAbolishBar:Hide();
		LifebloomerOptionsAppearanceSampleAbolishBar:Hide();
	else
		LifebloomerOptionsDimensionsSampleAbolishBar:Show();
		LifebloomerOptionsAppearanceSampleAbolishBar:Show();
		LifebloomerOptionsDimensionsSampleAbolishBar:SetHeight(LB_Buffer.LBDim.abolish);
		LifebloomerOptionsAppearanceSampleAbolishBar:SetHeight(LB_Buffer.LBDim.abolish);
	end
end

function Lifebloomer_AdjustAbolish()
	local nv = getn(LBV);
	local n = nv + LBVFF;
	while n > 0 do
		if LBDim.reg == 0 then
			getglobal("LifebloomerMainFrameUnitFrame"..n.."AbolishBar"):Hide();
		else
			getglobal("LifebloomerMainFrameUnitFrame"..n.."AbolishBar"):Show();
			getglobal("LifebloomerMainFrameUnitFrame"..n.."AbolishBar"):SetHeight(LBDim.abolish);
		end
		n = n - 1;
	end
end

function Lifebloomer_OptionsDimensions_Accept()
	LBDim = Lifebloomer_deepcopy(LB_Buffer.LBDim);
	Lifebloomer_AdjustH();
	Lifebloomer_AdjustW();
	Lifebloomer_AdjustS();
	Lifebloomer_AdjustRejuv();
	Lifebloomer_AdjustRegro();
	Lifebloomer_AdjustWild();
	Lifebloomer_AdjustAbolish();
end

function Lifebloomer_OptionsDimensions_Cancel()
	LB_Buffer.LBDim = Lifebloomer_deepcopy(LBDim);
	Lifebloomer_AdjustH();
	Lifebloomer_AdjustW();
	Lifebloomer_AdjustS();
	Lifebloomer_AdjustRejuv();
	Lifebloomer_AdjustRegro();
	Lifebloomer_AdjustWild();
	Lifebloomer_AdjustAbolish();
end

function Lifebloomer_OptionsDimensions_Default()
	LB_Buffer.LBDim.h = 40;
	LB_Buffer.LBDim.w = 180;
	LB_Buffer.LBDim.s = 0;
	LB_Buffer.LBDim.hs = 8;
	LB_Buffer.LBDim.fpc = 5;
	LB_Buffer.LBDim.rej = 2;
	LB_Buffer.LBDim.reg = 2;
	LB_Buffer.LBDim.wild = 2;
	LifebloomerOptionsDimensionsVerticalSlider:SetValue(LB_Buffer.LBDim.h);
	LifebloomerOptionsDimensionsHorizontalSlider:SetValue(LB_Buffer.LBDim.w);
	LifebloomerOptionsDimensionsSpacingSlider:SetValue(LB_Buffer.LBDim.s);
	LifebloomerOptionsDimensionsRejuvSlider:SetValue(LB_Buffer.LBDim.rej);
	LifebloomerOptionsDimensionsRegrowthSlider:SetValue(LB_Buffer.LBDim.reg);
	LifebloomerOptionsDimensionsWildSlider:SetValue(LB_Buffer.LBDim.wild);
	Lifebloomer_AdjustH_Sample();
	Lifebloomer_AdjustW_Sample();
	Lifebloomer_AdjustS_Sample();
	Lifebloomer_AdjustRejuv_Sample();
	Lifebloomer_AdjustRegro_Sample();
	Lifebloomer_AdjustWild_Sample();
	Lifebloomer_AdjustAbolish_Sample();
end
-- vim: sw=8 sts=8 noexpandtab 
