Lang\Localization.br.lua
Lang\Localization.cn.lua
Lang\Localization.de.lua
Lang\Localization.es.lua
Lang\Localization.fr.lua
Lang\Localization.kr.lua
Lang\Localization.ru.lua
Lang\Localization.tw.lua