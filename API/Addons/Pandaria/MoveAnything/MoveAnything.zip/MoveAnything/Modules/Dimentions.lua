local MovAny = _G.MovAny
local MOVANY = _G.MOVANY
local _