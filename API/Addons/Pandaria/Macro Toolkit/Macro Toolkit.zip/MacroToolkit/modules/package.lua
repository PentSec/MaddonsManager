MacroToolkit = select(2, ...)
MacroToolkit.frame = CreateFrame("Frame")
