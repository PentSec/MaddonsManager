﻿if GetLocale() == "deDE" then


function psealocale()


	charakillintime = "Voraussetzungen erfuellt! Toete den Boss mit 3 Stacks Blitzladung (30 Sekunden uebrig)!"
	charakillintime2 = "Voraussetzung erfuellt! Toetet den Boss wenn er den Buff hat (20 Sek uebrig)!"
	-- chhrbrannyell = ""
	chratitle = "   Cataclysm Heroisch"
	crraraidpartachloc1 = "Statischer Schock!"
	crraraidpartachloc2 = "Giftbombe!"
	crraraidpartachloc3 = "Arkaner Annihilator!"
	crraraidpartachloc4 = "Flammenwerfer!"
	crratitle = "    Cataclysm Raids"
	icratitle = "    Eiskrone" -- Needs review
	icravalitriayell1 = "Ich habe ein Portal in den Traum geöffnet. Darin liegt Eure Erlösung, Helden..."
	icravalitriayell2 = "ICH BIN GEHEILT! Ysera, erlaubt mir diese üblen Kreaturen zu beseitigen!"
	nrallbuttonmaint = "Zonenliste"
	nrallbuttontak = "Taktiken"
	nxraonyemote = "atmet tief ein"
	nxraonyxiab = "Onyxia"
	nxratitle = "    Naxxramas + andere Mini WotLK Schlachtzuege" -- Needs review
	phratitle = "    Pandaria Heroics"
	prratitle = "    Pandaria Schlachtzuege"
	psbuttonoff = "Stop"
	psbuttonon = "Start"
	pseaaddonmy = "AddOn"
	pseaaddonoff = "AUS"
	pseaaddonok = "Okay"
	pseaaddonon = "Addon aktivieren"
	pseaaddonon2 = "AN"
	pseachangeall = "Umkehren"
	pseachatlist1 = "raid"
	pseachatlist2 = "Raid Warnung"
	pseachatlist3 = "Offizier"
	pseachatlist4 = "Gruppe"
	pseachatlist5 = "Gilde"
	pseachatlist6 = "Sagen"
	pseachatlist7 = "Schreien"
	pseachatlist8 = "An sich selbst"
	pseadisableall = "Alles deaktivieren"
	pseaenableall = "Alles aktivieren"
	psealeftmenu1 = "Addon"
	psealeftmenu11 = "Verfolgung nach Fehlschlag"
	psealeftmenu3 = "Naxxramas"
	psealeftmenu31 = "Naxxramas + andere Minischlachtzuege aus WotLK"
	psealeftmenu4 = "WotLK Instanzen"
	psealeftmenu5 = "Ulduar"
	psealeftmenu6 = "Eiskronenzitadelle"
	psealeftmenucata = "Cata Heroisch"
	psealeftmenucata2 = "Cata Raids"
	psealeftmenupanda = "Panda Heroics"
	psealeftmenupanda2 = "Panda Schlachtzuege"
	psealeftmenupanda3 = "Panda Szenarien"
	pseamanyachtitle = "    Erfolg nach einem Fehlschlag weiterhin beobachten"
	pseamimifailloc1 = "Bombot!"
	pseamimifailloc2 = "Rocket Strike!" -- Needs review
	pseamimifailloc3 = "Meins!" -- Needs review
	pseamimifailloc5 = "Teil fehlgeschlagen!" -- Needs review
	pseamoduleload = "Geladene Module:"
	pseamodulenotload = "Fehler beim Laden der Module:"
	pseaoldmodules = "Alte Module"
	pseaoldmodules2 = "   Alte Module"
	pseapartfailedloc = "Teil ist fehlgeschlagen!"
	pseapsaddonanet = "Fehler! Das Addon 'PhoenixStyle' ist nicht installiert."
	pseapsaddonanet2 = "Sie koennen es auf www.phoenixstyle.com runterladen."
	pseareports = "- Kanal in welchem die Warnungen ausgegeben werden"
	pseashownames = "Den Grund (Spielername etc.) anzeigen wieso das Achievement nicht geschafft wurde"
	pseashowveren = "Berichten, wenn eine aktuellere Version in Gruppe/Schlachtzug gefunden wurde"
	pseasoundoptions1 = "Spiele Sound wenn Erfolg fehlgeschlagen"
	pseasoundoptions2 = "Spiele Sound wenn Voraussetzungen erfuellt"
	pseasoundoptions3 = "Spiele Sound wenn ich den Erfolg benoetige"
	pseasoundoptions6 = "Master Modus, spiele Sound wenn In-Game Sound deaktiviert ist"
	pseatreb2 = "Anforderungen erfuellt! Vernichtet den Boss jetzt!"
	pseatreb4 = "fehlgeschlagen!"
	pseatrebulda2 = "Toetet das letzte Monster und danach den Boss!"
	pseauierror = "    Fehler!"
	pseauierroraddonoff = "Fehler! Das Addon ist deaktiviert - dieses Modul ist nicht verfuegbar!"
	pseauinomodule1 = "    Fehler! Modul ist nicht installiert!"
	pseauinomodule2 = "Fehler! Ausgewaehltes Modul ist nicht installiert!"
	pseaulduarkolf1 = "Add wurde getoetet!" -- Needs review
	pseaulduarkolf2 = "ist nicht abgeschlossen wenn Du den Boss jetzt toetest!" -- Needs review
	pseaulduartitle = "    Ulduar"
	PSFeaserver = "ru-Gordunni"
	psmoduletxtoff = "Modul ist deaktiviert"
	psmoduletxton = "Modul ist aktiviert"
	psoldvertxt = "(veraltet)"
	pzratitle = "    Pandaria Szenarien"
	racolor1 = "rot"
	racolor2 = "schwarz"
	racolor3 = "gelb"
	racolor5 = "gruen"
	racolor6 = "lila"
	racolorcomb = "eine Kombination uebrig"
	radatabrokervart = "Click = Anzeigen | Verstecken"
	radeathwingemote1 = " rollt links!" -- Needs review
	radeathwingemote2 = " rollt rechts!" -- Needs review
	raerroraddoninst = "Fehler! Addon ist nicht installiert, Du musst es herunterladen und installieren:"
	raerrormodulereq = "Zusaetzliches Modul benoetigt:"
	raiccof = "von"
	raiccused = "betreten"
	ramainbattleground = "Schlachtfeld"
	ramainbattlegroundopt = "Zeige Erfolgsliste auch im Schlachtfeld (wenn es fuer Raids aktiviert ist)"
	ramaintrackingtitle = "Verfolgung"
	ramanyachtitinfo = "Wenn ein Erfolg fehlschlaegt ist seine beobachtung bist zum Kampfende gesperrt. Dieses Modul setzt die Sperre zurueck. Dies erfolgt in"
	ramanyachtitinfo2 = "nach der Benachrichtigung. Lege die Anzahl der Zuruecksetzungen pro Kampf fest und druecke auf 'Start'. Dieses Modul wird nach dem Logout automatisch deaktiviert."
	ramanyachtitinfoq = "Zuruecksetzung erfolgt "
	ramanyachtitinfoq2 = "mal in diesem Kampf. Du kannst das hier aendern:"
	ramanyplayers = "viele Spieler"
	raminibuttset = "Minimap Button anzeigen"
	ramodulnotblock = "die Ueberpruefung wird nicht geblockt"
	ranewversfound = "|cff00ff00Achtung!|r Es wurde eine neuere Version des Addons |cff00ff00'RaidAchievement'|r gefunden. Es wird empfohlen das Addon ueber www.phoenixstyle.com zu aktualisieren."
	-- ranotsure = ""
	raragnaachtxt1 = "toete Boss um es zu kriegen!"
	raragnaachtxt2 = "Anforderungen erfuellt! Du hast %s Sek. um den Boss zu toeten! Pruefe deine Timer in deinem BossMod."
	rasec = "sek."
	raspectext = "Zu grosse Kampfzone. Fordert mehr Addons im Raid!" -- Needs review
	ravalitnottrack = "keine Verfolgung im heroischen Modus durch das Addon"
	rayard = "yd"
	whraaddkilled1 = "Mob wurde getoetet!"
	whraaddkilled2 = "wird nicht erfuellt, wenn der Boss jetzt getoetet wird!"
	whrabrann = "Brann Bronzebart"
	-- whrabrannemo = ""
	whrabrannemo2 = "Tresor deaktiviert. Beginne Speicherloeschung und" -- Needs review
	-- whragundemo = ""
	whratitle = "    WotLK Heroics"




end





end