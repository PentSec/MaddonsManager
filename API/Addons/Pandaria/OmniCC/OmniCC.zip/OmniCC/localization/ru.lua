if GetLocale() ~= 'ruRU' then return end
local L = OMNICC_LOCALS

-- effect names
L.Updated = "Обновлено до v%s"
L.Pulse = "Импульс"
L.Shine = "Блеск"