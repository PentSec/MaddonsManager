﻿if GetLocale() == "deDE" then


function pslocalepanda1()

	pszzpandaaddopttxt1 = "(wenn mehr als 1 Spieler es bekommt)"
	pszzpandaaddopttxt10 = "Schaden von |s4id130395|id (falsche Versteinerung, keine 3 sec)"
	pszzpandaaddopttxt11 = "Wieviele ticks von |sid116040|id oder |sid116365|id wärend |sid115856|id"
	pszzpandaaddopttxt12 = "Nicht ausgewichene ticks unter" -- Needs review
	pszzpandaaddopttxt13 = "Berichte info wenn jemand starb durch"
	pszzpandaaddopttxt14 = "spieler starben durch"
	pszzpandaaddopttxt15 = "KEIN Schaden"
	pszzpandaaddopttxt16 = "nur 2 und 3"
	pszzpandaaddopttxt17 = "Schaden am Raid"
	pszzpandaaddopttxt18 = "entferne debuff info"
	pszzpandaaddopttxt19 = "Schaden gemacht"
	pszzpandaaddopttxt2 = "info über schaden und heilung von Lebendiger Amber nach seinem tod"
	pszzpandaaddopttxt20 = "Zeitmesser  unter"
	pszzpandaaddopttxt21 = "wenn mehr als 1 Spieler es bekommt"
	pszzpandaaddopttxt22 = "Überflüssig"
	pszzpandaaddopttxt23 = "starb ohne"
	pszzpandaaddopttxt24 = "Spieler mit buff in der Nähe (yd)"
	pszzpandaaddopttxt25 = "hat NICHT"
	pszzpandaaddopttxt26 = "anstatt von"
	pszzpandaaddopttxt27 = "Zu nah:"
	pszzpandaaddopttxt28 = "Wer schaden bekam:"
	pszzpandaaddopttxt29 = "Info über (wenn der Raid mehr als 300k dmg bekommen hat)"
	pszzpandaaddopttxt3 = "wer die explosion verursachte"
	pszzpandaaddopttxt30 = "phase"
	pszzpandaaddopttxt31 = "(wenn mehr als %s spieler es bekommen)"
	pszzpandaaddopttxt32 = "zeige wer die schnellsten läufer in der letzten phase waren"
	pszzpandaaddopttxt33 = "Die schnellsten läufer waren"
	-- pszzpandaaddopttxt34 = ""
	pszzpandaaddopttxt35 = "Entzaubert"
	pszzpandaaddopttxt36 = "Geheilt"
	pszzpandaaddopttxt37 = "Wenn der boss mit der geringsten HP von |sid117283|id geheilt wurde - Zeige Info"
	pszzpandaaddopttxt38 = "Berichte wenn der Boss schaden von |sid123012|id erhalten hat"
	pszzpandaaddopttxt39 = "KEINE ENTZAUBERUNG"
	pszzpandaaddopttxt4 = "Heilung an amber"
	pszzpandaaddopttxt40 = "Max stacks von %s"
	pszzpandaaddopttxt41 = "Top schaden in |sid123461|id Phase" -- Needs review
	pszzpandaaddopttxt5 = "Info über alle |sid130395|id"
	pszzpandaaddopttxt6 = "Anzahl der ticks von |sid130395|id in anderen Versteinerungen als Jaspis (nicht die ersten 3 sek)"
	pszzpandaaddopttxt7 = "Ticks mit falscher Versteinerung"
	pszzpandaaddopttxt8 = "Zeit mit Ketten"
	pszzpandaaddopttxt9 = "Erhaltener schaden"
	pszzpandabossname31 = "Die Steinwache"
	pszzpandabossname34 = "Die Geisterkönige"
	pszzpandabossname36 = "Will des Kaisers"
	pszzpandabossname41 = "Beschützer des Endlosen"
	pszzpandanotcounttick1 = "Nicht den ersten tick zählen von"


end


end