﻿if GetLocale() == "frFR" then

function pslocalepanda1()


end

end