﻿if GetLocale() == "esMX" then

function pslocalepanda1()

end

end