﻿if GetLocale() == "esES" then

function pslocalepanda1()

end

end