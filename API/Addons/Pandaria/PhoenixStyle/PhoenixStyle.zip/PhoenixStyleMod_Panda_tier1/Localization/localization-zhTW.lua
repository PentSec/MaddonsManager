﻿if GetLocale() == "zhTW" then


function pslocalepanda1()

	pszzpandaaddopttxt1 = "(如果不只1個人中)" -- Needs review
	pszzpandaaddopttxt10 = "傷害來自|s4id130395|id(不計碧玉石化和前3秒)"
	pszzpandaaddopttxt11 = "當|sid115856|id啟動時，承受|sid116040|id或|sid116365|id的傷害次數" -- Needs review
	pszzpandaaddopttxt12 = "未迴避傷害於" -- Needs review
	pszzpandaaddopttxt13 = "發布訊息若有人死於" -- Needs review
	pszzpandaaddopttxt14 = "人死於" -- Needs review
	pszzpandaaddopttxt15 = "未分攤" -- Needs review
	pszzpandaaddopttxt16 = "只計第2和第3下" -- Needs review
	pszzpandaaddopttxt17 = "對團隊造成傷害" -- Needs review
	pszzpandaaddopttxt18 = "驅散狀態訊息" -- Needs review
	pszzpandaaddopttxt19 = "造成傷害" -- Needs review
	pszzpandaaddopttxt2 = "關於活化琥珀爆炸後造成的傷害和治療訊息" -- Needs review
	pszzpandaaddopttxt20 = "影響的時間" -- Needs review
	pszzpandaaddopttxt21 = "如果不只1個人中" -- Needs review
	pszzpandaaddopttxt22 = "多餘的" -- Needs review
	pszzpandaaddopttxt23 = "死亡而沒有" -- Needs review
	pszzpandaaddopttxt24 = "玩家位於定音區附近(碼)" -- Needs review
	pszzpandaaddopttxt25 = "沒有" -- Needs review
	pszzpandaaddopttxt26 = "而不是" -- Needs review
	pszzpandaaddopttxt27 = "太近:" -- Needs review
	pszzpandaaddopttxt28 = "誰受到傷害:" -- Needs review
	pszzpandaaddopttxt29 = "關於%s的訊息(如果對團隊造成30萬以上傷害)" -- Needs review
	pszzpandaaddopttxt3 = "誰引爆" -- Needs review
	pszzpandaaddopttxt30 = "階段" -- Needs review
	pszzpandaaddopttxt31 = "(如果不只%s人中)" -- Needs review
	pszzpandaaddopttxt32 = "發布誰是最後階段最快的跑者" -- Needs review
	pszzpandaaddopttxt33 = "最快的跑者是" -- Needs review
	pszzpandaaddopttxt34 = "位於" -- Needs review
	pszzpandaaddopttxt35 = "驅散" -- Needs review
	pszzpandaaddopttxt36 = "治療" -- Needs review
	pszzpandaaddopttxt37 = "提示當最低血量的首領受到|sid117283|id的治療" -- Needs review
	pszzpandaaddopttxt38 = "提示當首領受到|sid123012|id的傷害" -- Needs review
	pszzpandaaddopttxt39 = "未驅散" -- Needs review
	pszzpandaaddopttxt4 = "治療活化琥珀" -- Needs review
	pszzpandaaddopttxt40 = "堆疊最多次的%s" -- Needs review
	pszzpandaaddopttxt41 = "在|sid123461|id階段造成最多的傷害" -- Needs review
	pszzpandaaddopttxt42 = "誰破壞|sid122224|id控場(因傷害)" -- Needs review
	pszzpandaaddopttxt43 = "打破了" -- Needs review
	pszzpandaaddopttxt44 = "被控制" -- Needs review
	pszzpandaaddopttxt45 = "對帶有|sid121949|id狀態玩家的總治療量(總數與次數)" -- Needs review
	pszzpandaaddopttxt46 = "治療|sid121949|id(總數-次數)" -- Needs review
	pszzpandaaddopttxt47 = "對|sid122370|id狀態的玩家造成的總傷害" -- Needs review
	pszzpandaaddopttxt48 = "對|sid122370|id的玩家造成最多傷害" -- Needs review
	pszzpandaaddopttxt49 = "在玩家|sid122370|id效果結束後，發布對該玩家造成的傷害" -- Needs review
	pszzpandaaddopttxt5 = "所有關於|sid130395|id的訊息" -- Needs review
	pszzpandaaddopttxt50 = "提示誰驅散了|sid122370|id" -- Needs review
	pszzpandaaddopttxt6 = "非碧玉石化時|sid130395|id的傷害次數(不計前3秒)" -- Needs review
	pszzpandaaddopttxt7 = "非碧玉石化時的傷害次數" -- Needs review
	pszzpandaaddopttxt8 = "鎖鏈持續時間" -- Needs review
	pszzpandaaddopttxt9 = "承受傷害" -- Needs review
	pszzpandabossname31 = "石衛士"
	pszzpandabossname34 = "帝王之魂"
	pszzpandabossname36 = "大帝之志"
	pszzpandabossname41 = "豐泉守衛者"
	pszzpandanotcounttick1 = "不計第一跳傷害的" -- Needs review

end

end