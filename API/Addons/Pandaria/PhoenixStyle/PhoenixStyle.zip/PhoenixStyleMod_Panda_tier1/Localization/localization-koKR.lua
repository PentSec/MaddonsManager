﻿if GetLocale() == "koKR" then

function pslocalepanda1()

end

end