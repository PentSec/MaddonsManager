﻿if GetLocale() == "koKR" then

function pslocalepanda3()

end

end