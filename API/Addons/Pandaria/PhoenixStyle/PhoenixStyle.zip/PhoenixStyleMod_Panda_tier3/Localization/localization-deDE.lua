﻿if GetLocale() == "deDE" then


function pslocalepanda3()



end


end