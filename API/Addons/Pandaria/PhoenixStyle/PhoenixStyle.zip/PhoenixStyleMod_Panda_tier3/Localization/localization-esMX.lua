﻿if GetLocale() == "esMX" then

function pslocalepanda3()

end

end