﻿


function pslocalepandam3()

pscmrlastmoduleloadtxtp1		= "Pandaria raids, tier 3"

pszzpandatuaddopttxt1	  = "Report if more than 1 player got |sid142849|id"
pszzpandatuaddopttxt2   = "Got melee swings"
pszzpandatuaddopttxt3   = "Direct damage to"

end

