﻿if GetLocale() == "koKR" then

function pslocalepanda2()

end

end