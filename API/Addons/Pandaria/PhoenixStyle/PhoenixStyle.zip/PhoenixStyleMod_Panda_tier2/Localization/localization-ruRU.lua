﻿if GetLocale() == "ruRU" then


function pslocalepanda2()

pscmrlastmoduleloadtxtp1		= "Рейды Пандарии, патч 2"


pszzpandattaddopttxt1	  = "Сообщать если кто умер от"
pszzpandattaddopttxt2   = "Макс. стаков %s"
pszzpandattaddopttxt3    = "инфо по снятию дебафа"
pszzpandattaddopttxt4   = "Отображать дополнительное инфо, если босс отлечился от духа"
pszzpandattaddopttxt5   = "Урон от |sid138319|id во время |sid134380|id"
pszzpandattaddopttxt6   = "во время"
pszzpandattaddopttxt7		= "игроков получило лишний урон. Аддон не смог определить ближайших"
pszzpandattaddopttxt8		= "получили %s вместо"
pszzpandattaddopttxt9		= "Ближе чем 8 м"
pszzpandattaddopttxt10    = "Снял"

pszzpandattaddopttxt12    = "игроков умерло от"
pszzpandattaddopttxt13    = "НЕТ урона"
pszzpandattaddopttxt14    = "Плохие дебафы"
pszzpandattaddopttxt15    = "Хороше дебафы"
pszzpandattaddopttxt16    = "Лечение от"

end


end