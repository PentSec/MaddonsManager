﻿if GetLocale() == "deDE" then


function pslocalepanda2()



end


end