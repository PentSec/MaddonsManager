﻿if GetLocale() == "zhCN" then


function pslocalepanda2()

	pszzpandattaddopttxt1 = "报告信息，如果有人死于"
	pszzpandattaddopttxt10 = "驱散"
	pszzpandattaddopttxt12 = "玩家都死于"
	pszzpandattaddopttxt13 = "没有受到伤害"
	pszzpandattaddopttxt14 = "有害变异效果"
	pszzpandattaddopttxt15 = "有益变异效果"
	pszzpandattaddopttxt16 = "治疗自"
	pszzpandattaddopttxt2 = "堆叠最多的%s"
	pszzpandattaddopttxt3 = "移除减益的信息"
	pszzpandattaddopttxt4 = "如果首领因受到祝福的神灵获得治疗，显示额外信息"
	pszzpandattaddopttxt5 = "在|sid134380|id期间死于|sid138319|id"
	pszzpandattaddopttxt6 = "在" -- Needs review
	pszzpandattaddopttxt7 = "名玩家受到额外伤害. 插件没有发现谁的距离小于8码"
	pszzpandattaddopttxt8 = "击中了%s 个人除去" -- Needs review
	pszzpandattaddopttxt9 = "距离小于8码"


end

end