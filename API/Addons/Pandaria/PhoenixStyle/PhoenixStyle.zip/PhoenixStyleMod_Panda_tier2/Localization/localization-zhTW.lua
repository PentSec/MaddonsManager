﻿if GetLocale() == "zhTW" then


function pslocalepanda2()

	pszzpandattaddopttxt1 = "提示當有人死於" -- Needs review
	pszzpandattaddopttxt10 = "驅散" -- Needs review
	pszzpandattaddopttxt12 = "玩家都死於" -- Needs review
	pszzpandattaddopttxt13 = "沒有受到傷害" -- Needs review
	pszzpandattaddopttxt14 = "有害變異效果" -- Needs review
	pszzpandattaddopttxt15 = "有益變異效果" -- Needs review
	pszzpandattaddopttxt16 = "治療自" -- Needs review
	pszzpandattaddopttxt2 = "堆疊最多次的%s" -- Needs review
	pszzpandattaddopttxt3 = "驅散debuff訊息" -- Needs review
	pszzpandattaddopttxt4 = "提示首領獲得神佑的羅亞魂靈的治療" -- Needs review
	pszzpandattaddopttxt5 = "在|sid134380|id期間受到|sid138319|id的傷害" -- Needs review
	pszzpandattaddopttxt6 = "在" -- Needs review
	pszzpandattaddopttxt7 = "個玩家受到額外傷害。插件沒有在8碼內發現其他人。" -- Needs review
	pszzpandattaddopttxt8 = "擊中了%s個人除去" -- Needs review
	pszzpandattaddopttxt9 = "距離小於8碼" -- Needs review

end

end