﻿if GetLocale() == "ptBR" then


function pslocale()




end


end