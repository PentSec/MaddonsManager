﻿if GetLocale() == "esMX" then


function pslocale()

psmainbattlegr1				= "Valle de Alterac"
psmainbattlegr2				= "Cuenca de Arathi"
psmainbattlegr3				= "Ojo de la Tormenta"
psmainbattlegr4				= "Isla de la Conquista"
psmainbattlegr5				= "Playa de los Ancestros"
psmainbattlegr6				= "La Batalla por Gilneas"
psmainbattlegr7				= "Cumbres Gemelas"
psmainbattlegr8				= "Garganta Grito de Guerra"

end


end