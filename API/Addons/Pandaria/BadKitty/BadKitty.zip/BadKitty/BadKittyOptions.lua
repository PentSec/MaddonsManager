--instantiate functions
--local SetupOptions
----

local _

function BK_OptionsLoad(panel)
	SlashCmdList["BADKITTY"] = BK_Slashes
	SLASH_BADKITTY1 = "/badkitty"
	SLASH_BADKITTY2 = "/bk"
	panel.name = "BadKitty"
	InterfaceOptions_AddCategory(panel)
	--BK_LoadChild(_G["BKOptionsWarning"],"Warning Options")
	--BK_SetupOptions()
end

function BK_LoadChild(panel,name)	--Only for children!
	panel.name = name
	panel.parent = "BadKitty"
	InterfaceOptions_AddCategory(panel)
end

function BK_Slashes(msg)
	if msg=="lock" or msg=="move" then
		BK_Move()
	else
		BK_OpenOptions() 
	end
end

function BK_OpenOptions()
	InterfaceOptionsFrame_OpenToCategory(BKOptionsWarning) --so the tabs are expanded when opened
	InterfaceOptionsFrame_OpenToCategory(BKOptions)
end

function BK_SizeWarnings()
	BKSettings["warningsize"] = BKOptionsWarningSize:GetValue()
	BK_Refresh()
end

function BK_WarningFont()
	BKSettings["warningfont"] = BKOptionsWarningFont:GetValue()
	BK_Refresh()
end

function BK_BarFont()
	BKSettings["barfont"] = BKOptionsBarColorFont:GetValue()
	BK_Refresh()
end

function BK_WarningShape()
	BKSettings["warninglayout"]["size"] = BKOptionsWarningShape:GetValue()
	BK_Refresh()
end

function BK_SetColumnRadio()	--warning shape
	if BKSettings["warninglayout"]["direction"]=="c" then 
		BKOptionsWarningDirectionC:SetChecked(1) 
	else 
		BKOptionsWarningDirectionC:SetChecked(0) 
	end
end

function BK_SetRowRadio()	--warning shape
	if BKSettings["warninglayout"]["direction"]=="r" then 
		BKOptionsWarningDirectionR:SetChecked(1) 
	else 
		BKOptionsWarningDirectionR:SetChecked(0) 
	end
end

function BK_CheckRadios()	--updates BKSettings with the warning shape direction
	if BKOptionsWarningDirectionC:GetChecked() then
		BKSettings["warninglayout"]["direction"]="c"
	else
		BKSettings["warninglayout"]["direction"]="r"
	end
	BK_Refresh()
end

--if you look closely at the next two functions...they're set up retarded.
--something was acting weird with pairs(), so I was forced to do the iteration this way.
--function BK_ToggleCatSpell(spell,switch)
--	local spell = spell
--	if switch then
--		for j,_ in pairs(BKSettings["barorder"]) do
--			i=strsub(j,6)
--			if BKSettings["barorder"]["BKBar"..i]==spell then
--				return
--			end
--		end
--		for j,_ in pairs(BKSettings["barorder"]) do
--			i=strsub(j,6)
--			if not BKSettings["baron"][spell] then
--				BKSettings["baron"][spell]=true
--				break
--			end
--		end
--	else
--		for j,_ in pairs(BKSettings["barorder"]) do
--			i=strsub(j,6)
--			if BKSettings["baron"][spell] then
--				BKSettings["baron"][spell]=false
--				--while true do
--				--	if not BKSettings["barorder"]["BKBar"..i+1]then 
--				--		BKSettings["barorder"]["BKBar"..i]="no"
--				--		break 
--				--	end
--				--	BKSettings["barorder"]["BKBar"..i]=BKSettings["barorder"]["BKBar"..i+1]
--				--	i=i+1
--				--end
--				break
--			end
--		end
--	end
--	BK_Refresh()
--end	
function BK_ToggleCatSpell(spell,switch)
	if switch then
		BKSettings["baron"][spell]=true
	else
		BKSettings["baron"][spell]=false
	end
end

function BK_ToggleBearSpell(spell,switch)
	if switch then
		BKSettings["bearbaron"][spell]=true
	else
		BKSettings["bearbaron"][spell]=false
	end
end

function BK_UpdateBars() --takes BKCatSpells and pushes it to the options window, ["barorder"] and barOrder
	local i = 1	 --also updates the color picker button
	while true do
		if i>#(BKSettings["barorder"]) then break end
		_G["BKOptionsBarToggle"..i.."Text"]:SetText(BKSettings["barorder"]["BKBar"..i])
		_G["BKOptionsBarColor"..i.."Texture"]:SetTexture(BKSettings["barcolor"][BKSettings["barorder"]["BKBar"..i]][1],BKSettings["barcolor"][BKSettings["barorder"]["BKBar"..i]][3],BKSettings["barcolor"][BKSettings["barorder"]["BKBar"..i]][3])
		i=i+1
	end
	--i=1
	--local slist ={} 
 	--for i,j in pairs(BKSettings["barorder"]) do
	--	slist[j]=i
	--end
	--while true do
	--	if i>#(BKSettings["barorder"]) then break end
	--		if slist[BKSettings["barorder"]["BKBar"..i]] then
	--			BKSettings["barorder"]["BKBar"..i]=BKSettings["barorder"]["BKBar"..i]
	--		end
	--	i=i+1
	--end
	barOrder=BKSettings["barorder"]
end

-- checks if a bar is turned off, makes a check to reflect it
function BK_CheckBars()
	for j,spell in pairs(BKSettings["barorder"]) do
		i=strsub(j,6)
		if BKSettings["baron"][spell] then
			_G["BKOptionsBarToggle"..i]:SetChecked(1)
		else
			_G["BKOptionsBarToggle"..i]:SetChecked(0)
		end
	end
	for j,spell in pairs(BKSettings["bearbarorder"]) do
		i=strsub(j,6)
		if BKSettings["bearbaron"][spell] then
			_G["BKOptionsBarBearToggle"..i]:SetChecked(1)
		else
			_G["BKOptionsBarBearToggle"..i]:SetChecked(0)
		end
	end
	BK_Refresh()
end

--runs through the cat bar checks and makes them happen
function BK_PushCatChecks()
	local i=1
	local _G = getfenv()
	for j,_ in pairs(BKSettings["barorder"]) do
		i=strsub(j,6)
		if _G["BKOptionsBarToggle"..i]:GetChecked() then
			BK_ToggleCatSpell(BKSettings["barorder"]["BKBar"..i],1)
		else
			BK_ToggleCatSpell(BKSettings["barorder"]["BKBar"..i],nil)
		end
	end
	--BK_BarPersonality()
	BK_Refresh()
end

function BK_PushBearChecks()
	local i=1
	local _G = getfenv()
	for j,_ in pairs(BKSettings["bearbarorder"]) do
		i=strsub(j,6)
		if _G["BKOptionsBarBearToggle"..i]:GetChecked() then
			BK_ToggleBearSpell(BKSettings["bearbarorder"]["BKBar"..i],1)
		else
			BK_ToggleBearSpell(BKSettings["bearbarorder"]["BKBar"..i],nil)
		end
	end
	BK_BarPersonality()
	BK_Refresh()
end

function BKB()
	local i =1
	while true do
		if BKSettings["barorder"]["BKBar"..i] then
			BKO("BKBar"..i.." "..BKSettings["barorder"]["BKBar"..i])
		else
			break
		end
		i=i+1
	end
end

function BK_MoveWarningUp(i)
	--if not _G["BKOptionsWarningOnOff"..i]:GetChecked() then
	--	_G["BKOptionsWarningOnOff"..i]:SetChecked(1)
	--end
	local text = _G["BKOptionsWarningOnOff"..i.."Text"]:GetText()
	local temp = _G["BKOptionsWarningOnOff"..(i-1).."Text"]:GetText()
	local one = _G["BKOptionsWarningOnOff"..i]:GetChecked()
	local two = _G["BKOptionsWarningOnOff"..(i-1)]:GetChecked()
	_G["BKOptionsWarningOnOff"..i]:SetChecked(two)
	_G["BKOptionsWarningOnOff"..(i-1)]:SetChecked(one)
	if BKSettings["warnorder"][text]~="no" then
		BKSettings["warnorder"][text] = i-1
	else
		BKSettings["warnorder"][text] = "no"
	end
	if BKSettings["warnorder"][temp]~="no" then
		BKSettings["warnorder"][temp] = i
	else
		BKSettings["warnorder"][temp] = "no"
	end
	BK_CheckWarnings()
	BK_Refresh()
end

function BK_MoveWarningDown(i)
	--if not _G["BKOptionsWarningOnOff"..i]:GetChecked() then
	--	_G["BKOptionsWarningOnOff"..i]:SetChecked(1)
	--end
	local text = _G["BKOptionsWarningOnOff"..i.."Text"]:GetText()
	local temp = _G["BKOptionsWarningOnOff"..(i+1).."Text"]:GetText()
	local one = _G["BKOptionsWarningOnOff"..i]:GetChecked()
	local two = _G["BKOptionsWarningOnOff"..(i+1)]:GetChecked()
	_G["BKOptionsWarningOnOff"..i]:SetChecked(two)
	_G["BKOptionsWarningOnOff"..(i+1)]:SetChecked(one)
	if BKSettings["warnorder"][text]~="no" then
		BKSettings["warnorder"][text] = i+1
	else
		BKSettings["warnorder"][text] = "no"
	end
	if BKSettings["warnorder"][temp]~="no" then
		BKSettings["warnorder"][temp] = i
	else
		BKSettings["warnorder"][temp] = "no"
	end
	BK_CheckWarnings()
	BK_Refresh()
end

function BK_MoveWarningBearUp(i)
	local text = _G["BKOptionsWarningBearOnOff"..i.."Text"]:GetText()
	local temp = _G["BKOptionsWarningBearOnOff"..(i-1).."Text"]:GetText()
	local one = _G["BKOptionsWarningBearOnOff"..i]:GetChecked()
	local two = _G["BKOptionsWarningBearOnOff"..(i-1)]:GetChecked()
	_G["BKOptionsWarningBearOnOff"..i]:SetChecked(two)
	_G["BKOptionsWarningBearOnOff"..(i-1)]:SetChecked(one)
	if BKSettings["bearwarnorder"][text]~="no" then
		BKSettings["bearwarnorder"][text] = i-1
	else
		BKSettings["bearwarnorder"][text] = "no"
	end
	if BKSettings["bearwarnorder"][temp]~="no" then
		BKSettings["bearwarnorder"][temp] = i
	else
		BKSettings["bearwarnorder"][temp] = "no"
	end
	BK_CheckWarnings()
	BK_Refresh()
end

function BK_MoveWarningBearDown(i)
	local text = _G["BKOptionsWarningBearOnOff"..i.."Text"]:GetText()
	local temp = _G["BKOptionsWarningBearOnOff"..(i+1).."Text"]:GetText()
	local one = _G["BKOptionsWarningBearOnOff"..i]:GetChecked()
	local two = _G["BKOptionsWarningBearOnOff"..(i+1)]:GetChecked()
	_G["BKOptionsWarningBearOnOff"..i]:SetChecked(two)
	_G["BKOptionsWarningBearOnOff"..(i+1)]:SetChecked(one)
	if BKSettings["bearwarnorder"][text]~="no" then
		BKSettings["bearwarnorder"][text] = i+1
	else
		BKSettings["bearwarnorder"][text] = "no"
	end
	if BKSettings["bearwarnorder"][temp]~="no" then
		BKSettings["bearwarnorder"][temp] = i
	else
		BKSettings["bearwarnorder"][temp] = "no"
	end
	BK_CheckWarnings()
	BK_Refresh()
end

function BK_MoveBarUp(i)
	--if not _G["BKOptionsBarToggle"..i]:GetChecked() then
	--	_G["BKOptionsBarToggle"..i]:SetChecked(1)
	--end
	local text = _G["BKOptionsBarToggle"..i.."Text"]:GetText()
	local temp = _G["BKOptionsBarToggle"..(i-1).."Text"]:GetText()
	local one = _G["BKOptionsBarToggle"..i]:GetChecked()
	local two = _G["BKOptionsBarToggle"..(i-1)]:GetChecked()
	BKSettings["barorder"]["BKBar"..i-1] = text 
	BKSettings["barorder"]["BKBar"..i] = temp
	_G["BKOptionsBarToggle"..i.."Text"]:SetText(temp)
	_G["BKOptionsBarToggle"..(i-1).."Text"]:SetText(text)
	--BKCatSpells[i-1]=text
	--BKCatSpells[i]=temp
	--BK_UpdateBars()
	_G["BKOptionsBarToggle"..i]:SetChecked(two)
	_G["BKOptionsBarToggle"..(i-1)]:SetChecked(one)
	BK_CheckBars()
	BK_PushCatChecks()
	BK_BarPersonality()
	BK_Refresh()
end

function BK_MoveBarDown(i)
	--if not _G["BKOptionsBarToggle"..i]:GetChecked() then
	--	_G["BKOptionsBarToggle"..i]:SetChecked(1)
	--end
	local text = _G["BKOptionsBarToggle"..i.."Text"]:GetText()
	local temp = _G["BKOptionsBarToggle"..(i+1).."Text"]:GetText()
	local one = _G["BKOptionsBarToggle"..i]:GetChecked()
	local two = _G["BKOptionsBarToggle"..(i+1)]:GetChecked()
	BKSettings["barorder"]["BKBar"..i+1] = text
	BKSettings["barorder"]["BKBar"..i] = temp
	_G["BKOptionsBarToggle"..i.."Text"]:SetText(temp)
	_G["BKOptionsBarToggle"..(i+1).."Text"]:SetText(text)
	--BKCatSpells[i+1]=text
	--BKCatSpells[i]=temp
	--BK_UpdateBars()
	_G["BKOptionsBarToggle"..i]:SetChecked(two)
	_G["BKOptionsBarToggle"..(i+1)]:SetChecked(one)
	BK_CheckBars()
	BK_PushCatChecks()
	BK_Refresh()
	BK_BarPersonality()
end

function BK_MoveBarBearUp(i)
	--if not _G["BKOptionsBarToggle"..i]:GetChecked() then
	--	_G["BKOptionsBarToggle"..i]:SetChecked(1)
	--end
	local text = _G["BKOptionsBarBearToggle"..i.."Text"]:GetText()
	local temp = _G["BKOptionsBarBearToggle"..(i-1).."Text"]:GetText()
	local one = _G["BKOptionsBarBearToggle"..i]:GetChecked()
	local two = _G["BKOptionsBarBearToggle"..(i-1)]:GetChecked()
	BKSettings["bearbarorder"]["BKBar"..i-1] = text 
	BKSettings["bearbarorder"]["BKBar"..i] = temp
	_G["BKOptionsBarBearToggle"..i.."Text"]:SetText(temp)
	_G["BKOptionsBarBearToggle"..(i-1).."Text"]:SetText(text)
	--BKCatSpells[i-1]=text
	--BKCatSpells[i]=temp
	--BK_UpdateBars()
	_G["BKOptionsBarBearToggle"..i]:SetChecked(two)
	_G["BKOptionsBarBearToggle"..(i-1)]:SetChecked(one)
	BK_CheckBars()
	BK_PushBearChecks()
	BK_BarPersonality()
	BK_Refresh()
end

function BK_MoveBarBearDown(i)
	--if not _G["BKOptionsBarToggle"..i]:GetChecked() then
	--	_G["BKOptionsBarToggle"..i]:SetChecked(1)
	--end
	local text = _G["BKOptionsBarBearToggle"..i.."Text"]:GetText()
	local temp = _G["BKOptionsBarBearToggle"..(i+1).."Text"]:GetText()
	local one = _G["BKOptionsBarBearToggle"..i]:GetChecked()
	local two = _G["BKOptionsBarBearToggle"..(i+1)]:GetChecked()
	BKSettings["bearbarorder"]["BKBar"..i+1] = text
	BKSettings["bearbarorder"]["BKBar"..i] = temp
	_G["BKOptionsBarBearToggle"..i.."Text"]:SetText(temp)
	_G["BKOptionsBarBearToggle"..(i+1).."Text"]:SetText(text)
	--BKCatSpells[i+1]=text
	--BKCatSpells[i]=temp
	--BK_UpdateBars()
	_G["BKOptionsBarBearToggle"..i]:SetChecked(two)
	_G["BKOptionsBarBearToggle"..(i+1)]:SetChecked(one)
	BK_CheckBars()
	BK_PushBearChecks()
	BK_Refresh()
	BK_BarPersonality()
end

function BK_CheckWarnings()
	local i = 1
	local nos = {}
	local nonums = {}
	while true do
		if not _G["BKOptionsWarningOnOff"..i] then break end
		_G["BKOptionsWarningOnOff"..i]:SetChecked(0)
		nonums[i]=1
		i = i+1
	end
	for spell,frame in pairs(BKSettings["warnorder"]) do
		if frame~="no" then
			_G["BKOptionsWarningOnOff"..frame.."Text"]:SetText(spell)
			_G["BKOptionsWarningOnOff"..frame]:SetChecked(1)
			nonums[frame]=0
		else
			tinsert(nos,spell)
		end
	end
	for frame,bool in pairs(nonums) do
		if bool==1 then
			local spell = tremove(nos)
			_G["BKOptionsWarningOnOff"..frame.."Text"]:SetText(spell)
			_G["BKOptionsWarningOnOff"..frame]:SetChecked(0)
		end
	end
		
	i = 1
	nos = {}
	nonums = {}
	while true do
		if not _G["BKOptionsWarningBearOnOff"..i] then break end
		_G["BKOptionsWarningBearOnOff"..i]:SetChecked(0)
		nonums[i]=1
		i = i+1
	end
	for spell,frame in pairs(BKSettings["bearwarnorder"]) do
		if frame~="no" then
			_G["BKOptionsWarningBearOnOff"..frame.."Text"]:SetText(spell)
			_G["BKOptionsWarningBearOnOff"..frame]:SetChecked(1)
			nonums[frame]=0
		else
			tinsert(nos,spell)
		end
	end
	for frame,bool in pairs(nonums) do
		if bool==1 then
			local spell = tremove(nos)
			_G["BKOptionsWarningBearOnOff"..frame.."Text"]:SetText(spell)
			_G["BKOptionsWarningBearOnOff"..frame]:SetChecked(0)
		end
	end
end

function BK_ToggleWarning(i)
	local text = _G["BKOptionsWarningOnOff"..i.."Text"]:GetText()
	if not _G["BKOptionsWarningOnOff"..i]:GetChecked() then
		BKSettings["warnorder"][text] = "no"
	else
		BKSettings["warnorder"][text] = i
	end
	BK_Refresh()
end

function BK_ToggleBearWarning(i)
	local text = _G["BKOptionsWarningBearOnOff"..i.."Text"]:GetText()
	if not _G["BKOptionsWarningBearOnOff"..i]:GetChecked() then
		BKSettings["bearwarnorder"][text] = "no"
	else
		BKSettings["bearwarnorder"][text] = i
	end
	BK_Refresh()
end

function BK_ToggleBar(i) --This function is causing issues, possibly.
	local text = _G["BKOptionsBarToggle"..i.."Text"]:GetText()
	if not _G["BKOptionsBarToggle"..i]:GetChecked() then
		BKSettings["baron"][text] = false
	else
		BKSettings["baron"][text] = true
	end
	BK_Refresh()
	BK_BarPersonality()
end

function BK_ToggleBarBear(i) --This function is causing issues, possibly.
	local text = _G["BKOptionsBarBearToggle"..i.."Text"]:GetText()
	if not _G["BKOptionsBarBearToggle"..i]:GetChecked() then
		BKSettings["bearbaron"][text] = false
	else
		BKSettings["bearbaron"][text] = true
	end
	BK_BarPersonality()
	BK_Refresh()
end

function BK_BarBackgroundOpacity()
	BKSettings["barbackalpha"] = BKOptionsBarColorBackgroundOpacity:GetValue()
	BK_Refresh()
end

function BK_BarOpacity()
	BKSettings["baralpha"] = BKOptionsBarColorOpacity:GetValue()
	BK_Refresh()
end

function BK_WarningOpacity()
	BKSettings["warningalpha"] = BKOptionsWarningOpacity:GetValue()
	BK_Refresh()
end

function BK_BarLock()
	BKSettings["barlock"] = BKOptionsBarLock:GetChecked()
	if not BKSettings["barlock"] then 
		_G["BKOptionsBarDown1"]:Disable()
		_G["BKOptionsBarBearDown1"]:Disable()
		_G["BKOptionsBarZero"]:Disable()
		for j,_ in pairs(BKSettings["barorder"]) do
			i=strsub(j,6)
			if i~="1" then
				_G["BKOptionsBarDown"..i]:Disable()
				_G["BKOptionsBarUp"..i]:Disable()
			end
		end
		for j,_ in pairs(BKSettings["bearbarorder"]) do
			i=strsub(j,6)
			if i~="1" then
				_G["BKOptionsBarBearDown"..i]:Disable()
				_G["BKOptionsBarBearUp"..i]:Disable()
			end
		end
	else
		_G["BKOptionsBarDown1"]:Enable()
		_G["BKOptionsBarBearDown1"]:Enable()
		_G["BKOptionsBarZero"]:Enable()
		for j,_ in pairs(BKSettings["barorder"]) do
			i=strsub(j,6)
			if i~="1" then
				_G["BKOptionsBarDown"..i]:Enable()
				_G["BKOptionsBarUp"..i]:Enable()
			end
		end
		for j,_ in pairs(BKSettings["bearbarorder"]) do
			i=strsub(j,6)
			if i~="1" then
				_G["BKOptionsBarBearDown"..i]:Enable()
				_G["BKOptionsBarBearUp"..i]:Enable()
			end
		end
	end
end

function BK_PickColor(list)
	local r,g,b=unpack(list)
	ColorPickerFrame:SetColorRGB(r,g,b)
	ColorPickerFrame.hasOpacity = nil
	ColorPickerFrame.func, ColorPickerFrame.cancelFunc = BK_Callback,BK_Callback
	ColorPickerFrame:Hide()
	ColorPickerFrame:Show()
end

function BK_PickBearColor(list)
	local r,g,b=unpack(list)
	ColorPickerFrame:SetColorRGB(r,g,b)
	ColorPickerFrame.hasOpacity = nil
	ColorPickerFrame.func, ColorPickerFrame.cancelFunc = BK_BearCallback,BK_BearCallback
	ColorPickerFrame:Hide()
	ColorPickerFrame:Show()
end

function BK_Callback(restore)
	local r,g,b
	if restore then
		r,g,b=unpack(restore)
	else
		r,g,b=ColorPickerFrame:GetColorRGB()
	end
	BKSettings["barcolor"][BKColoredSpell]={r,g,b}
	BK_Refresh()
end

function BK_BearCallback(restore)
	local r,g,b
	if restore then
		r,g,b=unpack(restore)
	else
		r,g,b=ColorPickerFrame:GetColorRGB()
	end
	BKSettings["bearbarcolor"][BKColoredSpell]={r,g,b}
	BK_Refresh()
end

function BK_DoColors(spell)
	BKColoredSpell = spell
	BK_PickColor(BKSettings["barcolor"][spell])
end

function BK_DoBearColors(spell)
	BKColoredSpell = spell
	BK_PickBearColor(BKSettings["bearbarcolor"][spell])
end

function BK_ShowColors(frame,spell)
	frame:SetTexture(BKSettings["barcolor"][spell][1],BKSettings["barcolor"][spell][2],BKSettings["barcolor"][spell][3])
end

function BK_ShowBearColors(frame,spell)
	frame:SetTexture(BKSettings["bearbarcolor"][spell][1],BKSettings["bearbarcolor"][spell][2],BKSettings["bearbarcolor"][spell][3])
end

function BK_SetupOptions() --it's local (but not right now)
	local _G = getfenv()
	----Main Window----
	BKOptionsMove:SetText("MOVE THEM FRAMES")
	BKOptionsMove:SetHeight(40)
	BKOptionsMove:SetWidth(200)
	BKOptionsMove:ClearAllPoints()
	BKOptionsMove:SetPoint("BOTTOM",BKOptions,"BOTTOM",-125,50)
	BKOptionsMove:SetScript("OnClick",BK_Move)
	
	BKOptionsReset:SetText("RESET THEM OPTIONS")
	BKOptionsReset:SetHeight(40)
	BKOptionsReset:SetWidth(200)
	BKOptionsReset:ClearAllPoints()
	BKOptionsReset:SetPoint("BOTTOM",BKOptions,"BOTTOM",125,50)
	BKOptionsReset:SetScript("OnClick",BKDefaultSettings)
	----Warning Window----
	BKOptionsWarning:CreateFontString("BKOptionsWarningSizeTitle","OVERLAY","GameFontNormalSmall")
	BKOptionsWarning:CreateFontString("BKOptionsWarningFontTitle","OVERLAY","GameFontNormalSmall")
	BKOptionsWarning:CreateFontString("BKOptionsWarningShapeTitle","OVERLAY","GameFontNormalSmall")
	BKOptionsWarning:CreateFontString("BKOptionsWarningOpacityTitle","OVERLAY","GameFontNormalSmall")
	BKOptionsWarning:CreateFontString("BKOptionsWarningCatTitle","OVERLAY","GameFontNormalSmall")
	BKOptionsWarning:CreateFontString("BKOptionsWarningBearTitle","OVERLAY","GameFontNormalSmall")
	BKOptionsWarning:CreateFontString("BKOptionsWarningThresholdTitle","OVERLAY","GameFontNormalSmall")
	
	BKOptionsWarningCatToggle:ClearAllPoints()
	BKOptionsWarningCatToggle:SetPoint("TOPLEFT",BKOptionsWarning,"TOPLEFT",20,-150)
	BKOptionsWarningCatToggle:CreateTexture("BKOptionsWarningCatToggleText","OVERLAY")
	BKOptionsWarningCatToggleText:SetText("Cat Warnings")
	BKOptionsWarningCatToggle:SetScript("OnShow",function() BKOptionsWarningCatToggle:SetChecked(BKSettings["catwarningson"]); BK_Refresh() end)
	BKOptionsWarningCatToggle:SetScript("OnClick",function() BKSettings["catwarningson"]=BKOptionsWarningCatToggle:GetChecked(); BK_Refresh() end)
	
	BKOptionsWarningBearToggle:ClearAllPoints()
	BKOptionsWarningBearToggle:SetPoint("TOPLEFT",BKOptionsWarning,"TOPLEFT",300,-150)
	BKOptionsWarningBearToggle:CreateTexture("BKOptionsWarningBearToggleText","OVERLAY")
	BKOptionsWarningBearToggleText:SetText("Bear Warnings")
	BKOptionsWarningBearToggle:SetScript("OnShow",function() BKOptionsWarningBearToggle:SetChecked(BKSettings["bearwarningson"]); BK_Refresh() end)
	BKOptionsWarningBearToggle:SetScript("OnClick",function() BKSettings["bearwarningson"]=BKOptionsWarningBearToggle:GetChecked(); BK_Refresh() end)

	BKOptionsWarningCatTitle:ClearAllPoints()
	BKOptionsWarningCatTitle:SetPoint("CENTER",BKOptionsWarningCatToggle,"CENTER",30,30)
	BKOptionsWarningCatTitle:SetText("CAT")
	BKOptionsWarningCatTitle:SetFont("Fonts\\FRIZQT__.TTF",30)

	BKOptionsWarningBearTitle:ClearAllPoints()
	BKOptionsWarningBearTitle:SetPoint("CENTER",BKOptionsWarningBearToggle,"CENTER",30,30)
	BKOptionsWarningBearTitle:SetText("BEAR")
	BKOptionsWarningBearTitle:SetFont("Fonts\\FRIZQT__.TTF",30)

	BKOptionsWarningSizeTitle:SetText("Warning Size")
	BKOptionsWarningSize:ClearAllPoints()
	BKOptionsWarningSize:SetPoint("TOPLEFT",BKOptionsWarning,"TOPLEFT",20,-25)
	BKOptionsWarningSizeTitle:SetPoint("BOTTOM",BKOptionsWarningSize,"TOP",-20,0)
	BKOptionsWarningSize:SetValue(BKSettings["warningsize"])
	BKOptionsWarningSize:SetScript("OnValueChanged",BK_SizeWarnings)
	BKOptionsWarningSize:SetScript("OnUpdate",function() BKOptionsWarningSizeText:SetText(floor(BKSettings["warningsize"])) end)
	
	BKOptionsWarningOpacityTitle:SetText("Warning Opacity")
	BKOptionsWarningOpacity:ClearAllPoints()
	BKOptionsWarningOpacity:SetPoint("TOPLEFT",BKOptionsWarning,"TOPLEFT",200,-55)
	BKOptionsWarningOpacityTitle:SetPoint("BOTTOM",BKOptionsWarningOpacity,"TOP",-20,0)
	BKOptionsWarningOpacity:SetScript("OnValueChanged",BK_WarningOpacity)
	BKOptionsWarningOpacity:SetMinMaxValues(0,1)
	BKOptionsWarningOpacity:SetValueStep(0.01)
	BKOptionsWarningOpacity:SetScript("OnShow",function () BKOptionsWarningOpacity:SetValue(BKSettings["warningalpha"]) end)
	BKOptionsWarningOpacity:SetScript("OnUpdate",function() BKOptionsWarningOpacityText:SetText(floor(100*BKSettings["warningalpha"])/100) end)

	BKOptionsWarningFontTitle:SetText("Warning Font Size")
	BKOptionsWarningFont:ClearAllPoints()
	BKOptionsWarningFont:SetPoint("TOPLEFT",BKOptionsWarning,"TOPLEFT",200,-25)
	BKOptionsWarningFontTitle:SetPoint("BOTTOM",BKOptionsWarningFont,"TOP",-20,0)
	BKOptionsWarningFont:SetValue(BKSettings["warningfont"])
	BKOptionsWarningFont:SetScript("OnValueChanged",BK_WarningFont)
	BKOptionsWarningFont:SetMinMaxValues(0,36)
	BKOptionsWarningFont:SetScript("OnUpdate",function() BKOptionsWarningFontText:SetText(floor(BKSettings["warningfont"])) end)

	BKOptionsWarningThresholdTitle:SetText("Warning Threshold")
	BKOptionsWarningThreshold:ClearAllPoints()
	BKOptionsWarningThreshold:SetPoint("TOPLEFT",BKOptionsWarning,"TOPLEFT",380,-25)
	BKOptionsWarningThresholdTitle:SetPoint("BOTTOM",BKOptionsWarningThreshold,"TOP",-20,0)
	BKOptionsWarningThreshold:SetScript("OnValueChanged",BK_WarningThreshold) --THIS IS IN BadKitty.lua
	BKOptionsWarningThreshold:SetScript("OnShow",function() BKOptionsWarningThreshold:SetValue(BKSettings["warntime"][MANGLE_CAT]) end)
	BKOptionsWarningThreshold:SetMinMaxValues(0,30)
	BKOptionsWarningThreshold:SetScript("OnUpdate",function() BKOptionsWarningThresholdText:SetText(floor(BKSettings["warntime"][MANGLE_CAT])) end)
	
	BKOptionsWarningShapeTitle:SetText("# of Columns/Rows")
	BKOptionsWarningShape:ClearAllPoints()
	BKOptionsWarningShape:SetPoint("TOPLEFT",BKOptionsWarning,"TOPLEFT",20,-55)
	BKOptionsWarningShapeTitle:SetPoint("BOTTOM",BKOptionsWarningShape,"TOP",-20,0)
	BKOptionsWarningShape:SetValue(BKSettings["warninglayout"]["size"])
	BKOptionsWarningShape:SetMinMaxValues(1,12)
	BKOptionsWarningShape:SetValueStep(1)
	BKOptionsWarningShape:SetScript("OnShow",function() BKOptionsWarningShape:SetValue(BKSettings["warninglayout"]["size"]) end)
	BKOptionsWarningShape:SetScript("OnValueChanged",BK_WarningShape)
	BKOptionsWarningShape:SetScript("OnUpdate",function() BKOptionsWarningShapeText:SetText(BKSettings["warninglayout"]["size"]) end)
	
	BKOptionsWarningDirectionC:CreateTexture("BKOptionsWarningDirectionCText","OVERLAY")
	BKOptionsWarningDirectionCText:SetText("Columns")
	BKOptionsWarningDirectionC:SetPoint("TOP",BKOptionsWarningShape,"BOTTOMLEFT")
	BKOptionsWarningDirectionC:SetScript("OnShow",BK_SetColumnRadio)
	BKOptionsWarningDirectionC:SetScript("OnClick",function() BKOptionsWarningDirectionR:SetChecked(0); BK_CheckRadios() end)
	
	BKOptionsWarningDirectionR:CreateTexture("BKOptionsWarningDirectionRText","OVERLAY")
	BKOptionsWarningDirectionRText:SetText("Rows")
	BKOptionsWarningDirectionR:SetPoint("TOP",BKOptionsWarningShape,"BOTTOMLEFT",90,0)
	BKOptionsWarningDirectionR:SetScript("OnShow",BK_SetRowRadio)
	BKOptionsWarningDirectionR:SetScript("OnClick",function() BKOptionsWarningDirectionC:SetChecked(0); BK_CheckRadios() end)
	
	local i=1
	local x = 20
	local y = -200
	while true do
		if not _G["BKOptionsWarningOnOff"..i] then break end
		_G["BKOptionsWarningOnOff"..i]:CreateTexture("BKOptionsWarningOnOff"..i.."Text","OVERLAY")
		_G["BKOptionsWarningOnOff"..i.."Text"]:ClearAllPoints()
		_G["BKOptionsWarningOnOff"..i.."Text"]:SetPoint("LEFT","BKOptionsWarningOnOff"..i,"RIGHT",40,0)
		_G["BKOptionsWarningOnOff"..i]:ClearAllPoints()
		_G["BKOptionsWarningDown"..i]:ClearAllPoints()
		_G["BKOptionsWarningUp"..i]:ClearAllPoints()
		_G["BKOptionsWarningOnOff"..i]:SetPoint("TOPLEFT",BKOptionsWarning,"TOPLEFT",x,y)
		_G["BKOptionsWarningDown"..i]:SetPoint("TOPLEFT",BKOptionsWarning,"TOPLEFT",x+30,y-8)
		_G["BKOptionsWarningUp"..i]:SetPoint("TOPLEFT",BKOptionsWarning,"TOPLEFT",x+50,y-8)
		if i==1 then _G["BKOptionsWarningOnOff"..i]:SetScript("OnShow",BK_CheckWarnings) end
		_G["BKOptionsWarningOnOff"..i]:SetScript("OnClick",BK_ToggleWarning)		
		y = y-30
		i = i+1
	end
	i=1
	x = 300
	y = -200
	while true do
		if not _G["BKOptionsWarningBearOnOff"..i] then break end
		_G["BKOptionsWarningBearOnOff"..i]:CreateTexture("BKOptionsWarningBearOnOff"..i.."Text","OVERLAY")
		_G["BKOptionsWarningBearOnOff"..i.."Text"]:ClearAllPoints()
		_G["BKOptionsWarningBearOnOff"..i.."Text"]:SetPoint("LEFT","BKOptionsWarningBearOnOff"..i,"RIGHT",40,0)
		_G["BKOptionsWarningBearOnOff"..i]:ClearAllPoints()
		_G["BKOptionsWarningBearDown"..i]:ClearAllPoints()
		_G["BKOptionsWarningBearUp"..i]:ClearAllPoints()
		_G["BKOptionsWarningBearOnOff"..i]:SetPoint("TOPLEFT",BKOptionsWarning,"TOPLEFT",x,y)
		_G["BKOptionsWarningBearDown"..i]:SetPoint("TOPLEFT",BKOptionsWarning,"TOPLEFT",x+30,y-8)
		_G["BKOptionsWarningBearUp"..i]:SetPoint("TOPLEFT",BKOptionsWarning,"TOPLEFT",x+50,y-8)
		if i==1 then _G["BKOptionsWarningBearOnOff"..i]:SetScript("OnShow",BK_CheckWarnings) end
		_G["BKOptionsWarningBearOnOff"..i]:SetScript("OnClick",BK_ToggleBearWarning)		
		y = y-30
		i = i+1
	end
	--grrrrrrrrrrrrrrrrrrr
	--_G["BKOptionsWarningUp1"]:SetScript("OnClick",BK_MoveWarningUp(1))		--can't go higher!
	BKOptionsWarningUp1:Hide()
	_G["BKOptionsWarningDown1"]:SetScript("OnClick",function() BK_MoveWarningDown(1) end)
	_G["BKOptionsWarningUp2"]:SetScript("OnClick",function() BK_MoveWarningUp(2) end)
	_G["BKOptionsWarningDown2"]:SetScript("OnClick",function() BK_MoveWarningDown(2) end)
	_G["BKOptionsWarningUp3"]:SetScript("OnClick",function() BK_MoveWarningUp(3) end)
	_G["BKOptionsWarningDown3"]:SetScript("OnClick",function() BK_MoveWarningDown(3) end)
	_G["BKOptionsWarningUp4"]:SetScript("OnClick",function() BK_MoveWarningUp(4) end)
	_G["BKOptionsWarningDown4"]:SetScript("OnClick",function() BK_MoveWarningDown(4) end)
	_G["BKOptionsWarningUp5"]:SetScript("OnClick",function() BK_MoveWarningUp(5) end)
	_G["BKOptionsWarningDown5"]:SetScript("OnClick",function() BK_MoveWarningDown(5) end)
	_G["BKOptionsWarningUp6"]:SetScript("OnClick",function() BK_MoveWarningUp(6) end)
	_G["BKOptionsWarningDown6"]:SetScript("OnClick",function() BK_MoveWarningDown(6) end)
	_G["BKOptionsWarningUp7"]:SetScript("OnClick",function() BK_MoveWarningUp(7) end)
	_G["BKOptionsWarningDown7"]:SetScript("OnClick",function() BK_MoveWarningDown(7) end)
	_G["BKOptionsWarningUp8"]:SetScript("OnClick",function() BK_MoveWarningUp(8) end)
	_G["BKOptionsWarningDown8"]:SetScript("OnClick",function() BK_MoveWarningDown(8) end)
	_G["BKOptionsWarningUp9"]:SetScript("OnClick",function() BK_MoveWarningUp(9) end)
	_G["BKOptionsWarningDown9"]:SetScript("OnClick",function() BK_MoveWarningDown(9) end)
	--_G["BKOptionsWarningUp10"]:SetScript("OnClick",function() BK_MoveWarningUp(10) end)
	--_G["BKOptionsWarningDown10"]:SetScript("OnClick",BK_MoveWarningDown(1))	--can't go lower!
	BKOptionsWarningDown9:Hide()
	_G["BKOptionsWarningOnOff1"]:SetScript("OnClick",function() BK_ToggleWarning(1) end)
	_G["BKOptionsWarningOnOff2"]:SetScript("OnClick",function() BK_ToggleWarning(2) end)
	_G["BKOptionsWarningOnOff3"]:SetScript("OnClick",function() BK_ToggleWarning(3) end)
	_G["BKOptionsWarningOnOff4"]:SetScript("OnClick",function() BK_ToggleWarning(4) end)
	_G["BKOptionsWarningOnOff5"]:SetScript("OnClick",function() BK_ToggleWarning(5) end)
	_G["BKOptionsWarningOnOff6"]:SetScript("OnClick",function() BK_ToggleWarning(6) end)
	_G["BKOptionsWarningOnOff7"]:SetScript("OnClick",function() BK_ToggleWarning(7) end)
	_G["BKOptionsWarningOnOff8"]:SetScript("OnClick",function() BK_ToggleWarning(8) end)
	_G["BKOptionsWarningOnOff9"]:SetScript("OnClick",function() BK_ToggleWarning(9) end)
	--_G["BKOptionsWarningOnOff10"]:SetScript("OnClick",function() BK_ToggleWarning(10) end)
	
	--_G["BKOptionsWarningBearUp1"]:SetScript("OnClick",BK_MoveWarningUp(1))		--can't go higher!
	BKOptionsWarningBearUp1:Hide()
	_G["BKOptionsWarningBearDown1"]:SetScript("OnClick",function() BK_MoveWarningBearDown(1) end)
	_G["BKOptionsWarningBearUp2"]:SetScript("OnClick",function() BK_MoveWarningBearUp(2) end)
	_G["BKOptionsWarningBearDown2"]:SetScript("OnClick",function() BK_MoveWarningBearDown(2) end)
	_G["BKOptionsWarningBearUp3"]:SetScript("OnClick",function() BK_MoveWarningBearUp(3) end)
	_G["BKOptionsWarningBearDown3"]:SetScript("OnClick",function() BK_MoveWarningBearDown(3) end)
	_G["BKOptionsWarningBearUp4"]:SetScript("OnClick",function() BK_MoveWarningBearUp(4) end)
	_G["BKOptionsWarningBearDown4"]:SetScript("OnClick",function() BK_MoveWarningBearDown(4) end)
	_G["BKOptionsWarningBearUp5"]:SetScript("OnClick",function() BK_MoveWarningBearUp(5) end)
	_G["BKOptionsWarningBearDown5"]:SetScript("OnClick",function() BK_MoveWarningBearDown(5) end)
	_G["BKOptionsWarningBearUp6"]:SetScript("OnClick",function() BK_MoveWarningBearUp(6) end)
	_G["BKOptionsWarningBearDown6"]:SetScript("OnClick",function() BK_MoveWarningBearDown(6) end)
	_G["BKOptionsWarningBearUp7"]:SetScript("OnClick",function() BK_MoveWarningBearUp(7) end)
	_G["BKOptionsWarningBearDown7"]:SetScript("OnClick",function() BK_MoveWarningBearDown(7) end)
	_G["BKOptionsWarningBearUp8"]:SetScript("OnClick",function() BK_MoveWarningBearUp(8) end)
	_G["BKOptionsWarningBearDown8"]:SetScript("OnClick",function() BK_MoveWarningBearDown(8) end)
	_G["BKOptionsWarningBearUp9"]:SetScript("OnClick",function() BK_MoveWarningBearUp(9) end)
	--_G["BKOptionsWarningBearDown9"]:SetScript("OnClick",BK_MoveWarningBearDown(1))	--can't go lower!
	BKOptionsWarningBearDown9:Hide()
	_G["BKOptionsWarningBearOnOff1"]:SetScript("OnClick",function() BK_ToggleBearWarning(1) end)
	_G["BKOptionsWarningBearOnOff2"]:SetScript("OnClick",function() BK_ToggleBearWarning(2) end)
	_G["BKOptionsWarningBearOnOff3"]:SetScript("OnClick",function() BK_ToggleBearWarning(3) end)
	_G["BKOptionsWarningBearOnOff4"]:SetScript("OnClick",function() BK_ToggleBearWarning(4) end)
	_G["BKOptionsWarningBearOnOff5"]:SetScript("OnClick",function() BK_ToggleBearWarning(5) end)
	_G["BKOptionsWarningBearOnOff6"]:SetScript("OnClick",function() BK_ToggleBearWarning(6) end)
	_G["BKOptionsWarningBearOnOff7"]:SetScript("OnClick",function() BK_ToggleBearWarning(7) end)
	_G["BKOptionsWarningBearOnOff8"]:SetScript("OnClick",function() BK_ToggleBearWarning(8) end)
	_G["BKOptionsWarningBearOnOff9"]:SetScript("OnClick",function() BK_ToggleBearWarning(9) end)

	----Bar Window----
	BKOptionsBar:CreateFontString("BKOptionsBarCatTitle","OVERLAY","GameFontNormalSmall")
	BKOptionsBar:CreateFontString("BKOptionsBarBearTitle","OVERLAY","GameFontNormalSmall")
	BKOptionsBar:CreateFontString("BKOptionsBarToggles","OVERLAY","GameFontNormalLarge")
	
	BKOptionsBarToggles:ClearAllPoints()
	BKOptionsBarToggles:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",20,-120)
	--BKOptionsBarToggles:SetText("REPLACE THIS")
	
	BKOptionsBarCatToggle:ClearAllPoints()
	BKOptionsBarCatToggle:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",20,-150)
	BKOptionsBarCatToggle:CreateTexture("BKOptionsBarCatToggleText","OVERLAY")
	BKOptionsBarCatToggleText:SetText("Cat Bars")
	BKOptionsBarCatToggle:SetScript("OnShow",function() BKOptionsBarCatToggle:SetChecked(BKSettings["catbarson"]); BK_Refresh() end)
	BKOptionsBarCatToggle:SetScript("OnClick",function() BKSettings["catbarson"]=BKOptionsBarCatToggle:GetChecked() end)

	BKOptionsBarCatTitle:ClearAllPoints()
	BKOptionsBarCatTitle:SetPoint("CENTER",BKOptionsBarCatToggle,"CENTER",30,30)
	BKOptionsBarCatTitle:SetText("CAT")
	BKOptionsBarCatTitle:SetFont("Fonts\\FRIZQT__.TTF",30)

	BKOptionsBarBearToggle:ClearAllPoints()
	BKOptionsBarBearToggle:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",300,-150)
	BKOptionsBarBearToggle:CreateTexture("BKOptionsBarBearToggleText","OVERLAY")
	BKOptionsBarBearToggleText:SetText("Bear Bars")
	BKOptionsBarBearToggle:SetScript("OnShow",function() BKOptionsBarBearToggle:SetChecked(BKSettings["bearbarson"]); BK_Refresh() end)
	BKOptionsBarBearToggle:SetScript("OnClick",function() BKSettings["bearbarson"]=BKOptionsBarBearToggle:GetChecked() end)

	BKOptionsBarBearTitle:ClearAllPoints()
	BKOptionsBarBearTitle:SetPoint("CENTER",BKOptionsBarBearToggle,"CENTER",30,30)
	BKOptionsBarBearTitle:SetText("BEAR")
	BKOptionsBarBearTitle:SetFont("Fonts\\FRIZQT__.TTF",30)
	
	BKOptionsBarCombat:ClearAllPoints()
	BKOptionsBarCombat:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",380,-17)
	BKOptionsBarCombat:CreateTexture("BKOptionsBarCombatText","OVERLAY")
	BKOptionsBarCombatText:SetText("Hidden Out of Combat")
	BKOptionsBarCombat:SetScript("OnShow",function() BKOptionsBarCombat:SetChecked(BKSettings["barcombat"]); BK_Refresh() end)
	BKOptionsBarCombat:SetScript("OnClick",function() BKSettings["barcombat"]=BKOptionsBarCombat:GetChecked() end)
	
	BKOptionsBarScaleOn:ClearAllPoints()
	BKOptionsBarScaleOn:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",380,-55)
	BKOptionsBarScaleOn:CreateTexture("BKOptionsBarScaleOnText","OVERLAY")
	BKOptionsBarScaleOnText:SetText("Bars Scale with Cooldown Length")
	BKOptionsBarScaleOn:SetScript("OnShow",function() BKOptionsBarScaleOn:SetChecked(BKSettings["barscale"]); BK_Refresh() end)
	BKOptionsBarScaleOn:SetScript("OnClick",function() BKOptionsBarScaleOff:SetChecked(0); BKOptionsBarScaleOn:SetChecked(1); BKSettings["barscale"]=true end)
	
	BKOptionsBarScaleOff:ClearAllPoints()
	BKOptionsBarScaleOff:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",380,-80)
	BKOptionsBarScaleOff:CreateTexture("BKOptionsBarScaleOffText","OVERLAY")
	BKOptionsBarScaleOffText:SetText("Bar Length Set to            Seconds")
	BKOptionsBarScaleOff:SetScript("OnShow",function() BKOptionsBarScaleOff:SetChecked(not BKSettings["barscale"]); BK_Refresh() end)
	BKOptionsBarScaleOff:SetScript("OnClick",function() BKOptionsBarScaleOn:SetChecked(0); BKOptionsBarScaleOff:SetChecked(1); BKSettings["barscale"]=false end)
	
	BKOptionsBarLength:ClearAllPoints()
	BKOptionsBarLength:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",490,-75)
	BKOptionsBarLength:SetHeight(25)
	BKOptionsBarLength:SetWidth(35)
	BKOptionsBarLength:SetMaxLetters(3)
	BKOptionsBarLength:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
									edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
									tile = true, tileSize = 16, edgeSize = 16, 
									insets = { left = 4, right = 4, top = 4, bottom = 4 }})
	BKOptionsBarLength:SetBackdropColor(0,0,0,0)
	BKOptionsBarLength:SetAutoFocus(false)
	BKOptionsBarLength:SetNumeric()
	BKOptionsBarLength:SetTextInsets(5,0,0,0)
	BKOptionsBarLength:SetScript("OnShow",function() BKOptionsBarLength:SetText(BKSettings["barlength"]) end)
	BKOptionsBarLength:SetScript("OnEnterPressed",function() BKOptionsBarLength:ClearFocus() end)
	BKOptionsBarLength:SetScript("OnEscapePressed",function() BKOptionsBarLength:ClearFocus() end)
	BKOptionsBarLength:SetScript("OnTextChanged",function() BKSettings["barlength"]=BKOptionsBarLength:GetNumber() end)

	BKOptionsBarLock:ClearAllPoints()
	BKOptionsBarLock:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",60,-80)
	BKOptionsBarLock:CreateTexture("BKOptionsBarLockText","OVERLAY")
	BKOptionsBarLockText:SetText("Static Bar Order")
	BKOptionsBarLock:SetScript("OnShow",function() BKOptionsBarLock:SetChecked(BKSettings["barlock"]); BK_Refresh(); BK_BarLock() end)
	BKOptionsBarLock:SetScript("OnClick",BK_BarLock)
	
	BKOptionsBarZero:ClearAllPoints()
	BKOptionsBarZero:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",190,-80)
	BKOptionsBarZero:CreateTexture("BKOptionsBarZeroText","OVERLAY")
	BKOptionsBarZeroText:SetText("Visible When Zero")
	BKOptionsBarZero:SetScript("OnShow",function() BKOptionsBarZero:SetChecked(BKSettings["barzero"]); end)
	BKOptionsBarZero:SetScript("OnClick",function() if BKOptionsBarZero:GetChecked() then BKSettings["barzero"]=true; else BKSettings["barzero"]=false end end)

	--local i=1
	local y = -200
	local x = 20
	for j,_ in pairs(BKSettings["barorder"]) do
		i=strsub(j,6)
		_G["BKOptionsBarToggle"..i]:ClearAllPoints()
		_G["BKOptionsBarToggle"..i]:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",x,y-(30*(i-1)))
		_G["BKOptionsBarToggle"..i]:CreateTexture("BKOptionsBarToggle"..i.."Text","OVERLAY")
		_G["BKOptionsBarToggle"..i.."Text"]:SetText(BKSettings["barorder"]["BKBar"..i])
		_G["BKOptionsBarToggle"..i.."Text"]:ClearAllPoints()
		_G["BKOptionsBarToggle"..i.."Text"]:SetPoint("LEFT","BKOptionsBarToggle"..i,"RIGHT",40,0)
		_G["BKOptionsBarDown"..i]:ClearAllPoints()
		_G["BKOptionsBarUp"..i]:ClearAllPoints()
		_G["BKOptionsBarDown"..i]:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",x+30,y-(30*(i-1))-8)
		_G["BKOptionsBarUp"..i]:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",x+50,y-(30*(i-1))-8)
		if i=="1" then 
			_G["BKOptionsBarToggle1"]:SetScript("OnShow",BK_CheckBars) 
			--_G["BKOptionsBarColor1"]:SetScript("OnShow",BK_BarUpdate)
		end
		_G["BKOptionsBarToggle"..i]:SetScript("OnClick",BK_PushCatChecks)
		--y = y - 25
	end

	y = -200
	x = 300
	for j,_ in pairs(BKSettings["bearbarorder"]) do
		i=strsub(j,6)
		_G["BKOptionsBarBearToggle"..i]:ClearAllPoints()
		_G["BKOptionsBarBearToggle"..i]:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",x,y-(30*(i-1)))
		_G["BKOptionsBarBearToggle"..i]:CreateTexture("BKOptionsBarToggle"..i.."Text","OVERLAY")
		_G["BKOptionsBarBearToggle"..i.."Text"]:SetText(BKSettings["bearbarorder"]["BKBar"..i])
		_G["BKOptionsBarBearToggle"..i.."Text"]:ClearAllPoints()
		_G["BKOptionsBarBearToggle"..i.."Text"]:SetPoint("LEFT","BKOptionsBarBearToggle"..i,"RIGHT",40,0)
		_G["BKOptionsBarBearDown"..i]:ClearAllPoints()
		_G["BKOptionsBarBearUp"..i]:ClearAllPoints()
		_G["BKOptionsBarBearDown"..i]:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",x+30,y-(30*(i-1))-8)
		_G["BKOptionsBarBearUp"..i]:SetPoint("TOPLEFT",BKOptionsBar,"TOPLEFT",x+50,y-(30*(i-1))-8)
		if i=="1" then 
			_G["BKOptionsBarBearToggle1"]:SetScript("OnShow",BK_CheckBars) 
			--_G["BKOptionsBarColor1"]:SetScript("OnShow",BK_BarUpdate)
		end
		_G["BKOptionsBarBearToggle"..i]:SetScript("OnClick",BK_PushBearChecks)
		--y = y - 25
	end
	--grrrrrrrrrrrrrrrrrrr
	--_G["BKOptionsBarUp1"]:SetScript("OnClick",BK_MoveBarUp(1))		--can't go higher!
	BKOptionsBarUp1:Hide()
	_G["BKOptionsBarDown1"]:SetScript("OnClick",function() BK_MoveBarDown(1) end)
	_G["BKOptionsBarUp2"]:SetScript("OnClick",function() BK_MoveBarUp(2) end)
	_G["BKOptionsBarDown2"]:SetScript("OnClick",function() BK_MoveBarDown(2) end)
	_G["BKOptionsBarUp3"]:SetScript("OnClick",function() BK_MoveBarUp(3) end)
	_G["BKOptionsBarDown3"]:SetScript("OnClick",function() BK_MoveBarDown(3) end)
	_G["BKOptionsBarUp4"]:SetScript("OnClick",function() BK_MoveBarUp(4) end)
	_G["BKOptionsBarDown4"]:SetScript("OnClick",function() BK_MoveBarDown(4) end)
	_G["BKOptionsBarUp5"]:SetScript("OnClick",function() BK_MoveBarUp(5) end)
	_G["BKOptionsBarDown5"]:SetScript("OnClick",function() BK_MoveBarDown(5) end)
	_G["BKOptionsBarUp6"]:SetScript("OnClick",function() BK_MoveBarUp(6) end)
	_G["BKOptionsBarDown6"]:SetScript("OnClick",function() BK_MoveBarDown(6) end)
	_G["BKOptionsBarUp7"]:SetScript("OnClick",function() BK_MoveBarUp(7) end)
	_G["BKOptionsBarDown7"]:SetScript("OnClick",function() BK_MoveBarDown(7) end)
	_G["BKOptionsBarUp8"]:SetScript("OnClick",function() BK_MoveBarUp(8) end)
	_G["BKOptionsBarDown8"]:SetScript("OnClick",function() BK_MoveBarDown(8) end)
	_G["BKOptionsBarUp9"]:SetScript("OnClick",function() BK_MoveBarUp(9) end)
	_G["BKOptionsBarDown9"]:SetScript("OnClick",function() BK_MoveBarDown(9) end)
	_G["BKOptionsBarUp10"]:SetScript("OnClick",function() BK_MoveBarUp(10) end)
	_G["BKOptionsBarDown10"]:SetScript("OnClick",function() BK_MoveBarDown(10) end)
	_G["BKOptionsBarUp11"]:SetScript("OnClick",function() BK_MoveBarUp(11) end)
	_G["BKOptionsBarDown11"]:SetScript("OnClick",function() BK_MoveBarDown(11) end)
	--_G["BKOptionsBarUp12"]:SetScript("OnClick",function() BK_MoveBarUp(12) end)
	--_G["BKOptionsBarDown12"]:SetScript("OnClick",BK_MoveBarDown(1))	--can't go lower!
	BKOptionsBarDown11:Hide()
	_G["BKOptionsBarToggle1"]:SetScript("OnClick",function() BK_ToggleBar(1) end)
	_G["BKOptionsBarToggle2"]:SetScript("OnClick",function() BK_ToggleBar(2) end)
	_G["BKOptionsBarToggle3"]:SetScript("OnClick",function() BK_ToggleBar(3) end)
	_G["BKOptionsBarToggle4"]:SetScript("OnClick",function() BK_ToggleBar(4) end)
	_G["BKOptionsBarToggle5"]:SetScript("OnClick",function() BK_ToggleBar(5) end)
	_G["BKOptionsBarToggle6"]:SetScript("OnClick",function() BK_ToggleBar(6) end)
	_G["BKOptionsBarToggle7"]:SetScript("OnClick",function() BK_ToggleBar(7) end)
	_G["BKOptionsBarToggle8"]:SetScript("OnClick",function() BK_ToggleBar(8) end)
	_G["BKOptionsBarToggle9"]:SetScript("OnClick",function() BK_ToggleBar(9) end)
	_G["BKOptionsBarToggle10"]:SetScript("OnClick",function() BK_ToggleBar(10) end)
	_G["BKOptionsBarToggle11"]:SetScript("OnClick",function() BK_ToggleBar(11) end)
	_G["BKOptionsBarToggle12"]:SetScript("OnClick",function() BK_ToggleBar(12) end)
	
	--_G["BKOptionsBarBearUp1"]:SetScript("OnClick",BK_MoveBarUp(1))		--can't go higher!
	BKOptionsBarBearUp1:Hide()
	_G["BKOptionsBarBearDown1"]:SetScript("OnClick",function() BK_MoveBarBearDown(1) end)
	_G["BKOptionsBarBearUp2"]:SetScript("OnClick",function() BK_MoveBarBearUp(2) end)
	_G["BKOptionsBarBearDown2"]:SetScript("OnClick",function() BK_MoveBarBearDown(2) end)
	_G["BKOptionsBarBearUp3"]:SetScript("OnClick",function() BK_MoveBarBearUp(3) end)
	_G["BKOptionsBarBearDown3"]:SetScript("OnClick",function() BK_MoveBarBearDown(3) end)
	_G["BKOptionsBarBearUp4"]:SetScript("OnClick",function() BK_MoveBarBearUp(4) end)
	_G["BKOptionsBarBearDown4"]:SetScript("OnClick",function() BK_MoveBarBearDown(4) end)
	_G["BKOptionsBarBearUp5"]:SetScript("OnClick",function() BK_MoveBarBearUp(5) end)
	_G["BKOptionsBarBearDown5"]:SetScript("OnClick",function() BK_MoveBarBearDown(5) end)
	_G["BKOptionsBarBearUp6"]:SetScript("OnClick",function() BK_MoveBarBearUp(6) end)
	_G["BKOptionsBarBearDown6"]:SetScript("OnClick",function() BK_MoveBarBearDown(6) end)
	_G["BKOptionsBarBearUp7"]:SetScript("OnClick",function() BK_MoveBarBearUp(7) end)
	_G["BKOptionsBarBearDown7"]:SetScript("OnClick",function() BK_MoveBarBearDown(7) end)
	_G["BKOptionsBarBearUp8"]:SetScript("OnClick",function() BK_MoveBarBearUp(8) end)
	_G["BKOptionsBarBearDown8"]:SetScript("OnClick",function() BK_MoveBarBearDown(8) end)
	_G["BKOptionsBarBearUp9"]:SetScript("OnClick",function() BK_MoveBarBearUp(9) end)
	--_G["BKOptionsBarBearDown9"]:SetScript("OnClick",BK_MoveBarBearDown(1))	--can't go lower!
	BKOptionsBarBearDown9:Hide()
	_G["BKOptionsBarBearToggle1"]:SetScript("OnClick",function() BK_ToggleBarBear(1) end)
	_G["BKOptionsBarBearToggle2"]:SetScript("OnClick",function() BK_ToggleBarBear(2) end)
	_G["BKOptionsBarBearToggle3"]:SetScript("OnClick",function() BK_ToggleBarBear(3) end)
	_G["BKOptionsBarBearToggle4"]:SetScript("OnClick",function() BK_ToggleBarBear(4) end)
	_G["BKOptionsBarBearToggle5"]:SetScript("OnClick",function() BK_ToggleBarBear(5) end)
	_G["BKOptionsBarBearToggle6"]:SetScript("OnClick",function() BK_ToggleBarBear(6) end)
	_G["BKOptionsBarBearToggle7"]:SetScript("OnClick",function() BK_ToggleBarBear(7) end)
	_G["BKOptionsBarBearToggle8"]:SetScript("OnClick",function() BK_ToggleBarBear(8) end)
	_G["BKOptionsBarBearToggle9"]:SetScript("OnClick",function() BK_ToggleBarBear(9) end)

	--visuals window--
	BKOptionsBarColor:CreateFontString("BKOptionsBarColorCatTitle","OVERLAY","GameFontNormalLarge")
	BKOptionsBarColor:CreateFontString("BKOptionsBarColorBearTitle","OVERLAY","GameFontNormalLarge")
	BKOptionsBarColor:CreateFontString("BKOptionsBarColorBackgroundOpacityTitle","OVERLAY","GameFontNormalSmall")
	--BKOptionsBarColor:CreateFontString("BKOptionsBarColorBackgroundOpacityText","OVERLAY","GameFontNormalSmall")
	BKOptionsBarColor:CreateFontString("BKOptionsBarColorOpacityTitle","OVERLAY","GameFontNormalSmall")
	--BKOptionsBarColor:CreateFontString("BKOptionsBarColorOpacityText","OVERLAY","GameFontNormalSmall")
	BKOptionsBarColor:CreateFontString("BKOptionsBarColorFontTitle","OVERLAY","GameFontNormalSmall")
	BKOptionsBarColor:CreateFontString("BKOptionsBarColorWidthTitle","OVERLAY","GameFontNormalSmall")
	BKOptionsBarColor:CreateFontString("BKOptionsBarColorHeightTitle","OVERLAY","GameFontNormalSmall")
	BKOptionsBarColor:CreateFontString("BadKittyOptionsTextureMenuTitle","OVERLAY","GameFontNormalSmall")

	_G["BKOptionsBarColor1"]:SetScript("OnClick",function() BKColoredSpell=barOrder["BKBar1"]; BK_PickColor(BKSettings["barcolor"][barOrder["BKBar1"]])  end)
	_G["BKOptionsBarColorBear1"]:SetScript("OnClick",function() BKColoredSpell=barOrder["BKBar1"]; BK_PickColor(BKSettings["barcolor"][barOrder["BKBar1"]])  end)
	i = 1
	y=-170
	x=190
	while true do
		if not _G["BKOptionsBarColor"..i] then 
			if i>100 then break end
			i=100 --this is for the font bar, which is 20
		end
		_G["BKOptionsBarColor"..i]:ClearAllPoints()
		_G["BKOptionsBarColor"..i]:SetPoint("TOPLEFT","BKOptionsBarColor","TOPLEFT",x,y-(30*i))
		_G["BKOptionsBarColor"..i]:CreateTexture("BKOptionsBarColor"..i.."Texture","OVERLAY")
		_G["BKOptionsBarColor"..i.."Texture"]:SetHeight(25)
		_G["BKOptionsBarColor"..i.."Texture"]:SetWidth(25)
		_G["BKOptionsBarColor"..i.."Texture"]:SetTexture(1,0,0)
		_G["BKOptionsBarColor"..i.."Texture"]:ClearAllPoints()
		_G["BKOptionsBarColor"..i.."Texture"]:SetPoint("TOPLEFT","BKOptionsBarColor"..i,"TOPLEFT")
		_G["BKOptionsBarColor"..i]:CreateFontString("BKOptionsBarColor"..i.."Text","OVERLAY","GameFontNormalSmall")
		_G["BKOptionsBarColor"..i.."Text"]:SetText("hai")
		_G["BKOptionsBarColor"..i.."Text"]:ClearAllPoints()
		_G["BKOptionsBarColor"..i.."Text"]:SetPoint("RIGHT","BKOptionsBarColor"..i.."Texture","LEFT")
		_G["BKOptionsBarColor"..i.."Text"]:SetFont("Fonts\\FRIZQT__.TTF",15)
		_G["BKOptionsBarColor"..i]:SetHeight(25)
		_G["BKOptionsBarColor"..i]:SetWidth(25)
		_G["BKOptionsBarColor"..i]:Show()
		i = i+1
	end
	i = 1
	y=-170
	x=290
	while true do
		if not _G["BKOptionsBarColorBear"..i] then 
			break
		end
		_G["BKOptionsBarColorBear"..i]:ClearAllPoints()
		_G["BKOptionsBarColorBear"..i]:SetPoint("TOPLEFT","BKOptionsBarColor","TOPLEFT",x,y-(30*i))
		_G["BKOptionsBarColorBear"..i]:CreateTexture("BKOptionsBarColorBear"..i.."Texture","OVERLAY")
		_G["BKOptionsBarColorBear"..i.."Texture"]:SetHeight(25)
		_G["BKOptionsBarColorBear"..i.."Texture"]:SetWidth(25)
		_G["BKOptionsBarColorBear"..i.."Texture"]:SetTexture(1,0,0)
		_G["BKOptionsBarColorBear"..i.."Texture"]:ClearAllPoints()
		_G["BKOptionsBarColorBear"..i.."Texture"]:SetPoint("TOPLEFT","BKOptionsBarColorBear"..i,"TOPLEFT")
		_G["BKOptionsBarColorBear"..i]:CreateFontString("BKOptionsBarColorBear"..i.."Text","OVERLAY","GameFontNormalSmall")
		_G["BKOptionsBarColorBear"..i.."Text"]:SetText("hai")
		_G["BKOptionsBarColorBear"..i.."Text"]:ClearAllPoints()
		_G["BKOptionsBarColorBear"..i.."Text"]:SetPoint("LEFT","BKOptionsBarColorBear"..i.."Texture","RIGHT")
		_G["BKOptionsBarColorBear"..i.."Text"]:SetFont("Fonts\\FRIZQT__.TTF",15)
		_G["BKOptionsBarColorBear"..i]:SetHeight(25)
		_G["BKOptionsBarColorBear"..i]:SetWidth(25)
		_G["BKOptionsBarColorBear"..i]:Show()
		i = i+1
	end
	
	BKOptionsBarColorBackgroundOpacityTitle:SetText("Background Opacity")
	BKOptionsBarColorBackgroundOpacity:ClearAllPoints()
	BKOptionsBarColorBackgroundOpacity:SetPoint("TOPLEFT",BKOptionsBarColor,"TOPLEFT",20,-25)
	BKOptionsBarColorBackgroundOpacityTitle:SetPoint("BOTTOM",BKOptionsBarColorBackgroundOpacity,"TOP",-20,0)
	BKOptionsBarColorBackgroundOpacity:SetScript("OnValueChanged",BK_BarBackgroundOpacity)
	BKOptionsBarColorBackgroundOpacity:SetMinMaxValues(0,1)
	BKOptionsBarColorBackgroundOpacity:SetValueStep(0.01)
	BKOptionsBarColorBackgroundOpacity:SetScript("OnShow",function () BKOptionsBarColorBackgroundOpacity:SetValue(BKSettings["barbackalpha"]) end)
	BKOptionsBarColorBackgroundOpacity:SetScript("OnUpdate",function() BKOptionsBarColorBackgroundOpacityText:SetText(floor(100*BKSettings["barbackalpha"])/100) end)
	
	BKOptionsBarColorOpacityTitle:SetText("Bar Opacity")
	BKOptionsBarColorOpacity:ClearAllPoints()
	BKOptionsBarColorOpacity:SetPoint("TOPLEFT",BKOptionsBarColor,"TOPLEFT",20,-55)
	BKOptionsBarColorOpacityTitle:SetPoint("BOTTOM",BKOptionsBarColorOpacity,"TOP",-20,0)
	BKOptionsBarColorOpacity:SetScript("OnValueChanged",BK_BarOpacity)
	BKOptionsBarColorOpacity:SetMinMaxValues(0,1)
	BKOptionsBarColorOpacity:SetValueStep(0.01)
	BKOptionsBarColorOpacity:SetScript("OnShow",function () BKOptionsBarColorOpacity:SetValue(BKSettings["baralpha"]) end)
	BKOptionsBarColorOpacity:SetScript("OnUpdate",function() BKOptionsBarColorOpacityText:SetText(floor(100*BKSettings["baralpha"])/100) end)

	BKOptionsBarColorFontTitle:SetText("Bar Font")
	BKOptionsBarColorFont:ClearAllPoints()
	BKOptionsBarColorFont:SetPoint("TOPLEFT",BKOptionsBarColor,"TOPLEFT",20,-85)
	BKOptionsBarColorFontTitle:SetPoint("BOTTOM",BKOptionsBarColorFont,"TOP",-20,0)
	BKOptionsBarColorFont:SetValue(BKSettings["barfont"])
	BKOptionsBarColorFont:SetScript("OnValueChanged",BK_BarFont)
	BKOptionsBarColorFont:SetMinMaxValues(0,36)
	BKOptionsBarColorFont:SetScript("OnUpdate",function() BKOptionsBarColorFontText:SetText(floor(BKSettings["barfont"])) end)
	
	BKOptionsBarColorWidthTitle:SetText("Bar Width")
	BKOptionsBarColorWidth:ClearAllPoints()
	BKOptionsBarColorWidth:SetPoint("TOPLEFT",BKOptionsBarColor,"TOPLEFT",200,-25)
	BKOptionsBarColorWidthTitle:SetPoint("BOTTOM",BKOptionsBarColorWidth,"TOP",-20,0)
	BKOptionsBarColorWidth:SetValue(BKSettings["barwidth"])
	BKOptionsBarColorWidth:SetScript("OnValueChanged",function() BKSettings["barwidth"]=BKOptionsBarColorWidth:GetValue(); BK_Refresh() end)
	BKOptionsBarColorWidth:SetScript("OnUpdate",function() BKOptionsBarColorWidthText:SetText(floor(BKSettings["barwidth"])) end)
	BKOptionsBarColorWidth:SetMinMaxValues(75,300)
	
	BKOptionsBarColorHeightTitle:SetText("Bar Height")
	BKOptionsBarColorHeight:ClearAllPoints()
	BKOptionsBarColorHeight:SetPoint("TOPLEFT",BKOptionsBarColor,"TOPLEFT",200,-55)
	BKOptionsBarColorHeightTitle:SetPoint("BOTTOM",BKOptionsBarColorHeight,"TOP",-20,0)
	BKOptionsBarColorHeight:SetValue(BKSettings["barheight"])
	BKOptionsBarColorHeight:SetScript("OnValueChanged",function() BKSettings["barheight"]=BKOptionsBarColorHeight:GetValue(); BK_Refresh() end)
	BKOptionsBarColorHeight:SetScript("OnUpdate",function() BKOptionsBarColorHeightText:SetText(floor(BKSettings["barheight"])) end)
	BKOptionsBarColorHeight:SetMinMaxValues(5,100)
	
	BKOptionsBarColorCatTitle:SetText("CAT")
	BKOptionsBarColorCatTitle:ClearAllPoints()
	BKOptionsBarColorCatTitle:SetPoint("CENTER",BKOptionsBarColor1,"CENTER",-30,30)
	BKOptionsBarColorCatTitle:SetFont("Fonts\\FRIZQT__.TTF",30)
	BKOptionsBarColorBearTitle:SetText("BEAR")
	BKOptionsBarColorBearTitle:ClearAllPoints()
	BKOptionsBarColorBearTitle:SetPoint("CENTER",BKOptionsBarColorBear1,"CENTER",30,30)
	BKOptionsBarColorBearTitle:SetFont("Fonts\\FRIZQT__.TTF",30)

  local function ExampleBar()
    BKOptionsBarColorExample:SetPoint("TOP",BKOptionsBarColor,"TOPLEFT",500,-55)
    BKOptionsBarColorExample:SetWidth(BKSettings["barwidth"])
    BKOptionsBarColorExample:SetHeight(BKSettings["barheight"])
    BKOptionsBarColorExampleBar:SetWidth(BKSettings["barwidth"]-BKSettings["barheight"])--for the icon
    BKOptionsBarColorExampleBar:SetHeight(BKSettings["barheight"])
    BKOptionsBarColorExampleIcon:SetWidth(BKSettings["barheight"])
    BKOptionsBarColorExampleIcon:SetHeight(BKSettings["barheight"])
    BKOptionsBarColorExampleBar_Background:SetTexture(0,0,0,BKSettings["barbackalpha"])
    BKOptionsBarColorExampleBarText:SetFont("Fonts\\FRIZQT__.TTF",BKSettings["barfont"])
    BKOptionsBarColorExampleBarSecs:SetFont("Fonts\\FRIZQT__.TTF",BKSettings["barfont"])
    BKOptionsBarColorExampleBarText:SetTextColor(BKSettings["barcolor"]["font"][1],BKSettings["barcolor"]["font"][2],BKSettings["barcolor"]["font"][3])
    BKOptionsBarColorExampleBarSecs:SetTextColor(BKSettings["barcolor"]["font"][1],BKSettings["barcolor"]["font"][2],BKSettings["barcolor"]["font"][3])
    BKOptionsBarColorExampleBar:SetStatusBarTexture(BKSettings["bartexture"])
    BKOptionsBarColorExampleBar:SetStatusBarColor(BKSettings["barcolor"][WEAKENED_ARMOR][1],BKSettings["barcolor"][WEAKENED_ARMOR][2],BKSettings["barcolor"][WEAKENED_ARMOR][3])
    --BKOptionsBarColorExampleBar:SetHeight(BKSettings["barheight"])
    BKOptionsBarColorExampleIcon:SetBackdrop({bgFile="Interface/Icons/Ability_Druid_Mangle2"})
    BKOptionsBarColorExampleBarText:SetText("Example")
    BKOptionsBarColorExampleBarSecs:SetText(20)
  end
  ExampleBar()
  BKOptionsBarColorExample:SetScript("OnUpdate",ExampleBar)

	_G["BKOptionsBarColor100"]:ClearAllPoints()
	_G["BKOptionsBarColor100"]:SetPoint("TOPLEFT","BKOptionsBarColor","TOPLEFT",320,-82)
	_G["BKOptionsBarColor100Text"]:SetText("Bar Text Color")
	_G["BKOptionsBarColor100"]:SetScript("OnClick",function() BK_DoColors("font") end)
	_G["BKOptionsBarColor100"]:SetScript("OnUpdate",function() BK_ShowColors(BKOptionsBarColor100Texture,"font") end)
	
	_G["BKOptionsBarColor1Text"]:SetText(WEAKENED_ARMOR)
	_G["BKOptionsBarColor1"]:SetScript("OnClick",function() BK_DoColors(WEAKENED_ARMOR) end)
	_G["BKOptionsBarColor1"]:SetScript("OnUpdate",function() BK_ShowColors(BKOptionsBarColor1Texture,WEAKENED_ARMOR) end)
	_G["BKOptionsBarColor2Text"]:SetText(SAVAGE_ROAR)
	_G["BKOptionsBarColor2"]:SetScript("OnClick",function() BK_DoColors(SAVAGE_ROAR) end)
	_G["BKOptionsBarColor2"]:SetScript("OnUpdate",function() BK_ShowColors(BKOptionsBarColor2Texture,SAVAGE_ROAR) end)
	_G["BKOptionsBarColor3Text"]:SetText(RAKE)
	_G["BKOptionsBarColor3"]:SetScript("OnClick",function() BK_DoColors(RAKE) end)
	_G["BKOptionsBarColor3"]:SetScript("OnUpdate",function() BK_ShowColors(BKOptionsBarColor3Texture,RAKE) end)
	_G["BKOptionsBarColor4Text"]:SetText(RIP)
	_G["BKOptionsBarColor4"]:SetScript("OnClick",function() BK_DoColors(RIP) end)
	_G["BKOptionsBarColor4"]:SetScript("OnUpdate",function() BK_ShowColors(BKOptionsBarColor4Texture,RIP) end)
	_G["BKOptionsBarColor5Text"]:SetText(TIGERS_FURY)
	_G["BKOptionsBarColor5"]:SetScript("OnClick",function() BK_DoColors(TIGERS_FURY) end)
	_G["BKOptionsBarColor5"]:SetScript("OnUpdate",function() BK_ShowColors(BKOptionsBarColor5Texture,TIGERS_FURY) end)
	_G["BKOptionsBarColor6Text"]:SetText(BERSERK)
	_G["BKOptionsBarColor6"]:SetScript("OnClick",function() BK_DoColors(BERSERK) end)
	_G["BKOptionsBarColor6"]:SetScript("OnUpdate",function() BK_ShowColors(BKOptionsBarColor6Texture,BERSERK) end)
	_G["BKOptionsBarColor7Text"]:SetText(CLEARCASTING)
	_G["BKOptionsBarColor7"]:SetScript("OnClick",function() BK_DoColors(CLEARCASTING) end)
	_G["BKOptionsBarColor7"]:SetScript("OnUpdate",function() BK_ShowColors(BKOptionsBarColor7Texture,CLEARCASTING) end)
	_G["BKOptionsBarColor8Text"]:SetText(PREDATORS_SWIFTNESS)
	_G["BKOptionsBarColor8"]:SetScript("OnClick",function() BK_DoColors(PREDATORS_SWIFTNESS) end)
	_G["BKOptionsBarColor8"]:SetScript("OnUpdate",function() BK_ShowColors(BKOptionsBarColor8Texture,PREDATORS_SWIFTNESS) end)
	_G["BKOptionsBarColor9Text"]:SetText(ENERGY)
	_G["BKOptionsBarColor9"]:SetScript("OnClick",function() BK_DoColors(ENERGY) end)
	_G["BKOptionsBarColor9"]:SetScript("OnUpdate",function() BK_ShowColors(BKOptionsBarColor9Texture,ENERGY) end)
	_G["BKOptionsBarColor10Text"]:SetText(COMBO)
	_G["BKOptionsBarColor10"]:SetScript("OnClick",function() BK_DoColors(COMBO) end)
	_G["BKOptionsBarColor10"]:SetScript("OnUpdate",function() BK_ShowColors(BKOptionsBarColor10Texture,COMBO) end)

	_G["BKOptionsBarColorBear1Text"]:SetText(MANGLE_CAT)
	_G["BKOptionsBarColorBear1"]:SetScript("OnClick",function() BK_DoBearColors(MANGLE_CAT) end)
	_G["BKOptionsBarColorBear1"]:SetScript("OnUpdate",function() BK_ShowBearColors(BKOptionsBarColorBear1Texture,MANGLE_CAT) end)
	_G["BKOptionsBarColorBear2Text"]:SetText(SAVAGE_DEFENSE)
	_G["BKOptionsBarColorBear2"]:SetScript("OnClick",function() BK_DoBearColors(SAVAGE_DEFENSE) end)
	_G["BKOptionsBarColorBear2"]:SetScript("OnUpdate",function() BK_ShowBearColors(BKOptionsBarColorBear2Texture,SAVAGE_DEFENSE) end)
	_G["BKOptionsBarColorBear3Text"]:SetText(LACERATE)
	_G["BKOptionsBarColorBear3"]:SetScript("OnClick",function() BK_DoBearColors(LACERATE) end)
	_G["BKOptionsBarColorBear3"]:SetScript("OnUpdate",function() BK_ShowBearColors(BKOptionsBarColorBear3Texture,LACERATE) end)
	_G["BKOptionsBarColorBear4Text"]:SetText(THRASH)
	_G["BKOptionsBarColorBear4"]:SetScript("OnClick",function() BK_DoBearColors(THRASH) end)
	_G["BKOptionsBarColorBear4"]:SetScript("OnUpdate",function() BK_ShowBearColors(BKOptionsBarColorBear4Texture,THRASH) end)
	_G["BKOptionsBarColorBear5Text"]:SetText(BARKSKIN)
	_G["BKOptionsBarColorBear5"]:SetScript("OnClick",function() BK_DoBearColors(BARKSKIN) end)
	_G["BKOptionsBarColorBear5"]:SetScript("OnUpdate",function() BK_ShowBearColors(BKOptionsBarColorBear5Texture,BARKSKIN) end)
	_G["BKOptionsBarColorBear6Text"]:SetText(WEAKENED_ARMOR)
	_G["BKOptionsBarColorBear6"]:SetScript("OnClick",function() BK_DoBearColors(WEAKENED_ARMOR) end)
	_G["BKOptionsBarColorBear6"]:SetScript("OnUpdate",function() BK_ShowBearColors(BKOptionsBarColorBear6Texture,WEAKENED_ARMOR) end)
	_G["BKOptionsBarColorBear7Text"]:SetText(BERSERK)
	_G["BKOptionsBarColorBear7"]:SetScript("OnClick",function() BK_DoBearColors(BERSERK) end)
	_G["BKOptionsBarColorBear7"]:SetScript("OnUpdate",function() BK_ShowBearColors(BKOptionsBarColorBear7Texture,BERSERK) end)
	_G["BKOptionsBarColorBear8Text"]:SetText(CLEARCASTING)
	_G["BKOptionsBarColorBear8"]:SetScript("OnClick",function() BK_DoBearColors(CLEARCASTING) end)
	_G["BKOptionsBarColorBear8"]:SetScript("OnUpdate",function() BK_ShowBearColors(BKOptionsBarColorBear8Texture,CLEARCASTING) end)
	_G["BKOptionsBarColorBear9Text"]:SetText(MIGHT_OF_URSOC)
	_G["BKOptionsBarColorBear9"]:SetScript("OnClick",function() BK_DoBearColors(MIGHT_OF_URSOC) end)
	_G["BKOptionsBarColorBear9"]:SetScript("OnUpdate",function() BK_ShowBearColors(BKOptionsBarColorBear9Texture,MIGHT_OF_URSOC) end)

  BK_TextureMenuMake()
end


function BK_TextureMenuInit()
	level = 1
	local info = UIDropDownMenu_CreateInfo();
	info.text = "Blizzard"; --the text of the menu item
	info.value = [[Interface/TargetingFrame/UI-StatusBar]]; -- the value of the menu item. This can be a string also.
	info.func = BK_TextureClick; --sets the function to execute when this item is clicked
	info.owner = BadKittyOptionsTextureMenu; --binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menues.
  info.notCheckable = true
  info.arg1 = info.text
  info.arg2 = info.value
	--info.checked = nil; --initially set the menu item to being unchecked with a yellow tick
	info.icon = [[Interface/TargetingFrame/UI-StatusBar]]; --we can use this to set an icon for the drop down menu item to accompany the text
	UIDropDownMenu_AddButton(info, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu
	
	info.text = "Aluminium";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\Aluminium]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\Aluminium]];
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "Armory";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\Armory]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\Armory]];
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "BantoBar";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\BantoBar.tga]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\BantoBar]];
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "Glaze2";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\Glaze2]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\Glaze2]];
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "Gloss";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\Gloss]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\Gloss]];
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "Graphite";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\Graphite]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\Graphite]];
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "Grid";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\Grid]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\Grid]];
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "Healbot";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\Healbot]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\Healbot]];
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "LiteStep";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\LiteStep]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\LiteStep]];
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "Minimalist";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\Minimalist]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\Minimalist]];
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "Otravi";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\Otravi]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\Otravi]];
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "Outline";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\Outline]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\Outline]];
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "Perl";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\Perl]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\Perl]];
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "Round";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\Round]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\Round]];
	UIDropDownMenu_AddButton(info, level);
	
	info.text = "Smooth";
  info.arg1 = info.text
	info.value = [[Interface\Addons\BadKitty\bars\Smooth]];
  info.arg2 = info.value
	info.icon = [[Interface\Addons\BadKitty\bars\Smooth]];
	UIDropDownMenu_AddButton(info, level);
	
end

function BK_TextureClick(info,name,value)
	UIDropDownMenu_SetSelectedValue(BadKittyOptionsTextureMenu, value)
	BadKittyBarTexture = UIDropDownMenu_GetSelectedValue(BadKittyOptionsTextureMenu)
  UIDropDownMenu_SetText(BadKittyOptionsTextureMenu,name)
  BKSettings["bartexture"]=value
  BKSettings["bartexturename"]=name
  BK_Refresh()
end

function BK_TextureMenuMake()
	BadKittyOptionsTextureMenu:SetPoint("TOPLEFT",BKOptionsBarColor,450,-20)
	BadKittyOptionsTextureMenuTitle:SetPoint("RIGHT",BadKittyOptionsTextureMenu,"LEFT",10,0)
	BadKittyOptionsTextureMenuTitle:SetText("Bar Texture")
	BadKittyOptionsTextureMenuTitle:SetFont("Fonts\\FRIZQT__.TTF",12)
	UIDropDownMenu_Initialize(BadKittyOptionsTextureMenu,BK_TextureMenuInit)
  BadKittyOptionsTextureMenu:SetScript("OnClick",function() ToggleDropDownMenu(1, nil, BadKittyOptionsTextureMenu, BadKittyOptionsTextureMenu, 0, 0); end)
	UIDropDownMenu_SetWidth(BadKittyOptionsTextureMenu,100)
  UIDropDownMenu_SetText(BadKittyOptionsTextureMenu,BKSettings["bartexturename"])
  UIDropDownMenu_JustifyText(BadKittyOptionsTextureMenu,"LEFT")
end

BKtwopointfive = "BADKITTY 2.5\
\
In Feral: Mangle has been removed. Weakened Armor has replaced Faerie\
Fire.\
\
In Guardian: Mangle now tracks the CD, not the debuff. Demo Roar\
has been removed. Weakened Armor has replaced Faerie Fire. Might\
of Ursoc has been added. Thrash now tracks the debuff instead of\
the CD.\
\
If you receive errors on login, there was a problem migrating\
over the options, and you should reset them with the button below.\
\
I have more planned for the coming weeks, including Symbiosis support\
and an options overhaul. Suggestions for new functionality are\
encouraged. Contact me on Curse.com or in-game (Anatinus, Horde US-Gul'dan).\
"

BKtwopointfour = "BADKITTY 2.4: EXTREME MoP BETA EDITION\
\
At present, BadKitty functions as it did before the MoP patch.\
The only changes so far are the removal of spells and abilities\
that no longer exist; These were the cause of errors. Things like\
Mangle are still there, but no longer have any meaning. Just\
ignore or remove them in the Options Menu.\
\
Beyond these fixes, no new abilities have been added, nor new\
functionality accounted for. I am in the process of adding them\
in a way that doesn't cause problems down the road. If you have\
any opinions or suggestions about how you'd like to see the\
new abilities implemented, now is the time to voice them. Tell\
me on Curse.com or in-game (Anatinus, Horde US-Gul'dan).\
"

BKtwopointthree = "BADKITTY 2.3.0\
-Faerie Fire now correctly refreshes\
-Added option for Bar Opacity\
-Added a Bar Texture option so you can make your UI look more unified.\
-Moved the Bar Options around some. Go check it out!\
"
BKtwopointtwo = "BADKITTY 2.2.0!\
-Bear Form tracking is back!  This includes Mangle, Faerie Fire, Demo Roar, Lacerate,\
Pulverize, Berserk, Barkskin, and Thrash.\
-Warning threshold can, once again, be adjusted.\
-The length of the bars (when not scaling with cooldown) can be adjusted.\
-Fixed several memory leaks.\
-Fixed innumerable bugs.\
-Moved the options windows around a tad.\
"
BKtwopointonepointseven = "BADKITTY 2.1.7\
\
A few minor additions:\
-Warning opacity can now be changed\
-MOVE THEM FRAMES Button added\
"

BKtwopointonepointthree = "BADKITTY 2.1.3\
\
-BadKitty works on multiple targets again\
-bars shouldn't break when you change their order in the\
options\
-bars once again decrease continuously"
BKtwopointone = "BADKITTY 2.1.0\
\
FIXES:\
-Memory leak is gone\
-Rake and Rip work properly with other Ferals\
-Various minor tweaks\
\
NEW STUFF:\
-Energy and Combo Point bars are back\
-Bar and bar text  colors are adjustable again\
\
Type /bk move in the chat window to move the frames around."
BKtwopointzeropointfour = "BADKITTY 2.0.4.\
\
Static bar order (pre-Cata functionality) is back!\
Check it in Bar Options.\
\
-Anatinus"

BKtwopointzeropointtwo = "BADKITTY 2.0.2. Stuff's gettin' added!\
\
Since the last update, I've put back in:\
-Predator's Swiftness Awareness\
-Ravage/Stampede Awareness\
-Warning layout and order adjustment\
-Bar height adjustment\
-Option to turn off bars scaling based on spell\
-Option to hide bars out of combat\
-Bar font size adjustment\
-Bars have an optional background haze\
\
\
BadKitty is still missing:\
-Shred/Rip Glyph\
-Bar locking (like the old BadKitty)\
-Color adjustments for everything\
-Bear form\
-Faerie Fire stacking (maybe)\
\
Updates are still rolling.  Thanks for being patient.\
\
-Anatinus"

BKtwopointzeropointone = "BADKITTY 2.0.1.  Like BadKitty 2.0.0, there's still a lot missing,\
but not everything!\
\
The following things work:\
Warnings and Bars for Mangle/Trauma/Hemo, Savage Roar, Rake,\
Rip, Berserk, Tiger's Fury, Faerie Fire, OOC.\
-Situationally-changing bar order\
-Frame movement\
-Warning size and text adjustment\
-Bar width adjustment\
-Bar hiding\
-The bars have names, now\
\
\
Stuff that still doesn't work includes:\
-Shred/Rip Glyph\
-Ravage/Stampede awareness\
-Warning layout\
-Bar Locking (like the old BadKitty)\
-Bear functionality\
-Color adjustments (for everything)\
-Any other option I didn't mention\
\
Updates are still rolling.  Keep checking.\
\
-Anatinus"

BKtwopointzero = "This is a super mega alpha version of BadKitty 2.  It's missing a lot, \
but everything presently implemented should work.\
\
This includes:\
-Full warning and bar tracking of Mangle/Trauma/Hemorrhage,\
Savage Roar, Berserk, Tiger's Fury, Faerie Fire, Rake, Rip,\
and Omen of Clarity.\
-Situationally-changing bar order\
-Frame movement\
\
The following things DON'T work yet:\
-Changing the order of Warnings\
-Ravage and Stampede\
-The Shred Glyph\
-Warning layout\
-Warning and Bar size\
-Bar locking (like the old BadKitty)\
-Font size and color adjustment for every frame\
-Bar color adjustment\
-Bear functionality\
-All other options I haven't mentioned\
\
I'll be working on getting everything back in over the \
next few weeks.  I really appreciate the positive feedback\
I've been receiving, and apologize for making you wait.\
\
--Anatinus\
\
PS: Oh, and as always, if you have a comment or suggestion,\
send it my way ;)"

