--DO THIS SHIT, TOO:
--make it easy to add new moves/hots etc
--document, document, document
--drop the trink/wep/chant shit
--replace ^ with customizable monitors
--warning thresholds for each individual spell
--options menu is going to be fun...
--cat charge?
--moonkin?  tree?
--have dedicated proc frames
--

local _ --ugh

function BKO(text)
	DEFAULT_CHAT_FRAME:AddMessage(text)
end

local BKUnpacked = {}
function BKUnpack(list)
	for i,j in pairs(list) do
		BKUnpacked[i]=j
	end
	return BKUnpacked
end

--Settings
BKSettings = {}

--Locale-specific spell naming
local function BadKitty_GetSpellNameById(spellId)
	if (spellId == nil) then
		return nil
	end
	local spellName, _, _, _, _, _, _, _, _ = GetSpellInfo(spellId)
	return spellName
end
MANGLE_CAT = BadKitty_GetSpellNameById(33876)
MANGLE_BEAR = BadKitty_GetSpellNameById(33878)
SAVAGE_ROAR = BadKitty_GetSpellNameById(52610)
CLEARCASTING = BadKitty_GetSpellNameById(16870)
RAKE = BadKitty_GetSpellNameById(59881)
RIP = BadKitty_GetSpellNameById(1079)
FAERIE_FIRE = BadKitty_GetSpellNameById(770)
TIGERS_FURY = BadKitty_GetSpellNameById(5217)
SHRED = BadKitty_GetSpellNameById(5221)
PREDATORS_SWIFTNESS = BadKitty_GetSpellNameById(69369)
ENERGY = "Energy"
COMBO = "Combo"
LACERATE = BadKitty_GetSpellNameById(33745)
DEMO_ROAR = BadKitty_GetSpellNameById(99)
--DEMO_SHOUT = BadKitty_GetSpellNameById(1160)
BARKSKIN = BadKitty_GetSpellNameById(22812)
BERSERK = BadKitty_GetSpellNameById(50334)
CHARGE = BadKitty_GetSpellNameById(49376)
VINDICATION = BadKitty_GetSpellNameById(26017)
THRASH = BadKitty_GetSpellNameById(77758)
WEAKENED_ARMOR = BadKitty_GetSpellNameById(113746)
WEAKENED_BLOWS = BadKitty_GetSpellNameById(115798)
SAVAGE_DEFENSE = BadKitty_GetSpellNameById(62606)
MIGHT_OF_URSOC = BadKitty_GetSpellNameById(106922)

--spell-specific images
local ICONS = {}
ICONS[MANGLE_CAT] = "Interface/Icons/Ability_Druid_Mangle2"
ICONS[SAVAGE_ROAR] = "Interface/Icons/Ability_Druid_SkinTeeth"
ICONS[CLEARCASTING] = "Interface/Icons/Spell_Shadow_ManaBurn"
ICONS[RAKE] = "Interface/Icons/Ability_Druid_Disembowel"
ICONS[RIP] = "Interface/Icons/Ability_GhoulFrenzy"
ICONS[FAERIE_FIRE] = "Interface/Icons/Spell_Nature_FaerieFire"
ICONS[TIGERS_FURY] = "Interface/Icons/Ability_Mount_JungleTiger"
ICONS[BERSERK] = "Interface/Icons/Ability_Druid_Berserk"
ICONS[PREDATORS_SWIFTNESS]="Interface/Icons/Ability_Hunter_Pet_Cat"
ICONS[ENERGY]="Interface/Icons/Ability_Druid_Catform"
ICONS[COMBO]="Interface/Icons/Inv_Jewelcrafting_Gem_28"
ICONS[LACERATE] = "Interface/Icons/Ability_Druid_Lacerate"
--ICONS[DEMO_ROAR] = "Interface/Icons/Ability_Druid_Demoralizingroar"
ICONS[BARKSKIN] = "Interface/Icons/Spell_Nature_Stoneclawtotem"
ICONS[THRASH] = "Interface/Icons/spell_druid_thrash"
ICONS[SAVAGE_DEFENSE] = "Interface/Icons/ability_racial_cannibalize"
ICONS[MIGHT_OF_URSOC] = "Interface/Icons/spell_druid_mightofursoc"

ICONS[WEAKENED_ARMOR] = ICONS[FAERIE_FIRE]



--List of the spells that are for cat.  needed for the options window. order doesn't matter but indexes are needed
BKCatSpells ={}
BKCatSpells[1] = SAVAGE_ROAR
BKCatSpells[2] = CLEARCASTING
BKCatSpells[3] = RIP
BKCatSpells[4] = RAKE
BKCatSpells[5] = WEAKENED_ARMOR
BKCatSpells[6] = TIGERS_FURY
BKCatSpells[7] = BERSERK
BKCatSpells[8] = PREDATORS_SWIFTNESS
BKCatSpells[9] = ENERGY
BKCatSpells[10] = COMBO
BKCatSpells[11] = COMBO

--List of the spells that are for bear.  needed for the options window. order doesn't matter but indexes are needed
BKBearSpells ={}
BKBearSpells[1] = MANGLE_CAT
BKBearSpells[2] = LACERATE
BKBearSpells[3] = CLEARCASTING
BKBearSpells[5] = BARKSKIN
BKBearSpells[6] = WEAKENED_ARMOR
BKBearSpells[7] = SAVAGE_DEFENSE
BKBearSpells[8] = BERSERK
BKBearSpells[4] = THRASH
BKBearSpells[9] = MIGHT_OF_URSOC

--Where all "data" is stored.  Accessed by frame updaters.  TF, Zerk, etc have their CDs stored here.
local timers = {}
timers[MANGLE_CAT] = 0
--timers[MANGLE_BEAR] = 0	--these are unused, cuz all "mangle" gets put together
timers[WEAKENED_ARMOR] = 0
timers[SAVAGE_ROAR] = 0
timers[CLEARCASTING] = 0
timers[RAKE] = 0
timers[RIP] = 0
timers[FAERIE_FIRE] = 0
timers[LACERATE] = 0
--timers[DEMO_ROAR] = 0
--timers[DEMO_SHOUT] = 0
timers[TIGERS_FURY] = 0
timers[BARKSKIN] = 0
timers[BERSERK] = 0
timers[SHRED] = 0
timers[CHARGE] = 0
timers[VINDICATION] = 0
timers[PREDATORS_SWIFTNESS] = 0
timers[ENERGY] = 0
timers[COMBO] = 0
--timers[PULVERIZE] = 0
timers[THRASH] = 0
timers[SAVAGE_DEFENSE] = 0
timers[MIGHT_OF_URSOC] = 0

--these hold the displayed (integered) and bar lengthening time-to-0 timers for each spell.
--they are modified from timers[] by Timerize() and used all over the place
local floorTimes = {}
local fTimes = {}

--These are used for bar max values
local durations = {}
durations[MANGLE_CAT] = 30
--durations[MANGLE_BEAR] = 0	--these are unused, cuz all "mangle" gets put together
durations[WEAKENED_ARMOR] = 0
durations[SAVAGE_ROAR] = 30
durations[CLEARCASTING] = 30
durations[RAKE] = 30
durations[RIP] = 30
durations[FAERIE_FIRE] = 30
durations[LACERATE] = 30
--durations[DEMO_ROAR] = 30
--durations[DEMO_SHOUT] = 30
durations[TIGERS_FURY] = 30
durations[BARKSKIN] = 30
durations[BERSERK] = 180
durations[SHRED] = 30
durations[CHARGE] = 30
durations[VINDICATION] = 30
durations[PREDATORS_SWIFTNESS] = 10
durations[ENERGY]=100
durations[COMBO]=5
--durations[PULVERIZE]=18
durations[THRASH]=15 
durations[SAVAGE_DEFENSE]=9
durations[MIGHT_OF_URSOC]=180

--Procs, plus TF/Zerk buffs.  This will be added to in-game when/if necessary.  These values ARE updated though
local procs = {}
procs[TIGERS_FURY] = 0
procs[BERSERK] = 0
procs[PREDATORS_SWIFTNESS] = 0
procs[BARKSKIN]=0


--orders the functions called on spell events by spell name
local spellFunctions = {}

--These are lists of the frames
BKWarningList = {}
BKBarList = {}
BKWarningTextList = {}
BKBarTextList = {}
BKBarSecsList = {}
BKBarIconList = {}
BKBarBarList = {}

--these hold the present state of each bar and warning, to minimize SetAlpha etc calls
BKBarState = {}
BKWarningState = {}

local getBarOrder;
--keeps the true, dynamic order of the bars.  The "set" order is in BKSettings
local barOrder = {} 
local lastBarOrder = barOrder
local bearBarOrder = {} 
local lastBearBarOrder = bearbarOrder

--when did the frames last get set to movable?
local barMove = 0


--Make the frames
local test = CreateFrame("Frame",nil,UiParent,"derp")
test:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
test:RegisterEvent("VARIABLES_LOADED")
test:RegisterEvent("PLAYER_TARGET_CHANGED")
test:RegisterEvent("PLAYER_REGEN_DISABLED")
test:SetAlpha(0)
--script registration happens below
test:Show()

local spell,frame,time,i,j

function BKDefaultSettings()
  wipe(BKSettings)

	BKSettings["version"] = 20508		--abcde = a.bc.de		
	BKSettings["warnorder"] = {}		--order spells appear in the warning grid
	BKSettings["bearwarnorder"] = {}
	BKSettings["warntime"] = {}			--"warning threshold"
	BKSettings["offcolor"] = {1,0,0}	--warning color when the spell is at 0
	BKSettings["oncolor"] = {0,1,0}		--warning color when the spell is a proc and is up
	BKSettings["barorder"] = {}			--order of the spell bars set by user.  Dynamic "true" order is held in barOrder
	BKSettings["bearbarorder"] = {}
	BKSettings["baron"] = {}		--Which bars are turned on?
	BKSettings["bearbaron"] = {}
	BKSettings["bartime"] = {}			--a warning threshold for the bars!  HOW NOVEL.
	BKSettings["barheight"] = 15		--these next three are self explanatory.
	BKSettings["barwidth"] = 100
	BKSettings["warningsize"] = 50
	BKSettings["warningfont"] = 35
	BKSettings["warningalpha"] = 0.75
	BKSettings["barfont"] = 10
	BKSettings["bargrowth"] = "up"		--which way do the bars grow?
	BKSettings["catbarson"] = true		--bars visible in cat
	BKSettings["catwarningson"] = true	--warnings visible in cat
	BKSettings["bearbarson"] = true		--bars visible in bear
	BKSettings["bearwarningson"] = true	--warnings visible in bear
	BKSettings["warningloc"] = {500,500}
	BKSettings["barloc"] = {500,500}
	BKSettings["warninglayout"] = {}
	BKSettings["barbackalpha"] = 0.5	--bar background opacity
  BKSettings["baralpha"] = 1
	BKSettings["barcombat"] = true		--true if the bars are HIDDEN out of combat
	BKSettings["barscale"] = true		--true if bars scale with CD length
	BKSettings["barlength"] = 30		--if barscale is false, this is used for all lengths
	BKSettings["barlock"] = false		--true if the bar order is static
	BKSettings["barzero"] = true		--bars always show up?
	BKSettings["barcolor"]= {}
	BKSettings["bearbarcolor"]= {}

  BKSettings["bartexture"] = [[Interface\Addons\BadKitty\bars\BantoBar.tga]]
  BKSettings["bartexturename"] = "BantoBar"

	
	BKSettings["warninglayout"]["direction"] = "c"
	BKSettings["warninglayout"]["size"] = 3
	
	--Fill all the list-based defaults--
	BKSettings["warnorder"][SAVAGE_ROAR] = 1
	BKSettings["warnorder"][RAKE] = 2
	BKSettings["warnorder"][RIP] = 3
	BKSettings["warnorder"][CLEARCASTING] = 4
	BKSettings["warnorder"][BERSERK] = 5
	BKSettings["warnorder"][WEAKENED_ARMOR] = 6
	BKSettings["warnorder"][TIGERS_FURY] = 7
	BKSettings["warnorder"][PREDATORS_SWIFTNESS] = 8
	BKSettings["warnorder"][THRASH] = 9
	
	BKSettings["bearwarnorder"][MANGLE_CAT] = 1
	BKSettings["bearwarnorder"][SAVAGE_DEFENSE] = 2
	BKSettings["bearwarnorder"][LACERATE] = 3
	BKSettings["bearwarnorder"][CLEARCASTING] = 5
	BKSettings["bearwarnorder"][BERSERK] = 6
	BKSettings["bearwarnorder"][WEAKENED_ARMOR] = 7
	BKSettings["bearwarnorder"][BARKSKIN] = 8
	BKSettings["bearwarnorder"][THRASH] = 4
	BKSettings["bearwarnorder"][MIGHT_OF_URSOC] = 9

	for spell,_ in pairs(timers) do
		BKSettings["warntime"][spell] = 5
	end
	
	for spell,_ in pairs(timers) do
		BKSettings["bartime"][spell] = 30
	end
	
	BKSettings["barorder"]["BKBar1"] = SAVAGE_ROAR
	BKSettings["barorder"]["BKBar2"] = RAKE
	BKSettings["barorder"]["BKBar3"] = RIP
	BKSettings["barorder"]["BKBar4"] = TIGERS_FURY	
	BKSettings["barorder"]["BKBar5"] = WEAKENED_ARMOR
	BKSettings["barorder"]["BKBar6"] = BERSERK
	BKSettings["barorder"]["BKBar7"] = CLEARCASTING
	BKSettings["barorder"]["BKBar8"] = PREDATORS_SWIFTNESS
	BKSettings["barorder"]["BKBar9"] = ENERGY
	BKSettings["barorder"]["BKBar10"] = COMBO
	BKSettings["barorder"]["BKBar11"] = THRASH

	BKSettings["bearbarorder"]["BKBar1"] = MANGLE_CAT
	BKSettings["bearbarorder"]["BKBar2"] = SAVAGE_DEFENSE
	BKSettings["bearbarorder"]["BKBar3"] = LACERATE
	BKSettings["bearbarorder"]["BKBar5"] = BARKSKIN
	BKSettings["bearbarorder"]["BKBar6"] = WEAKENED_ARMOR
	BKSettings["bearbarorder"]["BKBar7"] = BERSERK
	BKSettings["bearbarorder"]["BKBar8"] = CLEARCASTING
	BKSettings["bearbarorder"]["BKBar4"] = THRASH
	BKSettings["bearbarorder"]["BKBar9"] = MIGHT_OF_URSOC

	BKSettings["baron"][WEAKENED_ARMOR] = true
	BKSettings["baron"][SAVAGE_ROAR] = true
	BKSettings["baron"][RAKE] = true
	BKSettings["baron"][RIP] = true
	BKSettings["baron"][TIGERS_FURY] = true
	BKSettings["baron"][BERSERK] = true
	BKSettings["baron"][CLEARCASTING] = true
	BKSettings["baron"][PREDATORS_SWIFTNESS] = true
	BKSettings["baron"][ENERGY] = true
	BKSettings["baron"][COMBO] = true
	BKSettings["baron"][THRASH] = true
	
	BKSettings["bearbaron"][MANGLE_CAT] = true
	BKSettings["bearbaron"][SAVAGE_DEFENSE] = true
	BKSettings["bearbaron"][LACERATE] = true
	BKSettings["bearbaron"][BARKSKIN] = true
	BKSettings["bearbaron"][WEAKENED_ARMOR] = true
	BKSettings["bearbaron"][BERSERK] = true
	BKSettings["bearbaron"][CLEARCASTING] = true
	BKSettings["bearbaron"][THRASH] = true
	BKSettings["bearbaron"][MIGHT_OF_URSOC] = true

	--'export' it so it can be played with
	--barOrder = BKSettings["barorder"]
	exportBarOrder(3)
	--bearBarOrder = BKSettings["bearbarorder"]
	exportBarOrder(1)

	BKSettings["barcolor"][WEAKENED_ARMOR] = {1,0,0}
	BKSettings["barcolor"][SAVAGE_ROAR] = {0,1,1}
	BKSettings["barcolor"][RAKE] = {1,0,0}
	BKSettings["barcolor"][RIP] = {1,0,0}
	BKSettings["barcolor"][TIGERS_FURY] = {1,1,0}
	BKSettings["barcolor"][BERSERK] = {1,0,0}
	BKSettings["barcolor"][CLEARCASTING] = {0,1,0}
	BKSettings["barcolor"][PREDATORS_SWIFTNESS] = {0,1,0}
	BKSettings["barcolor"][ENERGY] = {0,1,1}
	BKSettings["barcolor"][COMBO] = {1,1,0}
	BKSettings["barcolor"][THRASH] = {1,0,0}
	BKSettings["barcolor"]["font"] = {1,1,0}

	BKSettings["bearbarcolor"][MANGLE_CAT] = {1,0,0}
	BKSettings["bearbarcolor"][SAVAGE_DEFENSE] = {0,1,1}
	BKSettings["bearbarcolor"][LACERATE] = {1,0,0}
	BKSettings["bearbarcolor"][BARKSKIN] = {1,1,0}
	BKSettings["bearbarcolor"][WEAKENED_ARMOR] = {1,0,0}
	BKSettings["bearbarcolor"][BERSERK] = {1,0,0}
	BKSettings["bearbarcolor"][CLEARCASTING] = {0,1,0}
	BKSettings["bearbarcolor"][THRASH] = {0,1,0}
	BKSettings["bearbarcolor"][MIGHT_OF_URSOC] = {0,1,0}

end

--this holds the present spell being color-changed
BKColoredSpell=MANGLE_CAT

local function OnLoad()
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	self:RegisterEvent("VARIABLES_LOADED");
	self:RegisterEvent("ADDON_LOADED");
	self:RegisterEvent("PLAYER_TARGET_CHANGED")
	self:RegisterEvent("PLAYER_REGEN_DISABLED")
end

local function CheckVersion()
	if not BKSettings["version"] or BKSettings["version"]<20501 then
		BKDefaultSettings()
  else
    if BKSettings["version"]<20502 then
      BKSettings["catwarningson"] = true
      BKSettings["bearwarningson"] = true
      BKSettings["catbarson"] = true
      BKSettings["bearbarson"] = true
    end
    if BKSettings["version"]<20503 then
      BKSettings["version"]=20503
      BKSettings["warnorder"][THRASH] = 9
      BKSettings["barcolor"][THRASH] = {1,0,0}
      BKSettings["baron"][THRASH] = true
      BKSettings["barorder"]["BKBar11"] = THRASH
    end
    BKSettings["version"]=20508
  end
end

--called when changing targets.
local function RecheckSpells()
	local spellsToIgnore = {SAVAGE_ROAR,BERSERK,TIGERS_FURY,CLEARCASTING,BARKSKIN,SHRED,PREDATORS_SWIFTNESS}
	local fake = {}
	for spell,_ in pairs(timers) do --clear everything
		if not tContains(spellsToIgnore,spell) then 
			fake[5] = UnitName("player") --yes this is inaccurate, but it won't change anything
			fake[4] = UnitGUID("player")
			fake[8] = UnitGUID("target")
			fake[2] = "SPELL_AURA_REMOVED"
			fake[13] = spell
			if spellFunctions[spell] then
				spellFunctions[spell](0,fake[2],0,fake[4],fake[5],0,0,fake[8],0,0,0,0,fake[13])
			end
		end
	end
	for spell,_ in pairs(timers) do --put everything back
		if not tContains(spellsToIgnore,spell) then 
			local name,_,_,_,_,_,_, unitid,_,_, spellId  = UnitDebuff("target",spell)
			if name and unitid then
				fake[5] = UnitName(unitid)
				fake[4] = UnitGUID(unitid)
				fake[8] = UnitGUID("target")
				fake[2] = "SPELL_AURA_APPLIED"
				fake[13] = spell
				if spellFunctions[spell] then
					spellFunctions[spell](0,fake[2],0,fake[4],fake[5],0,0,fake[8],0,0,0,0,fake[13])
				end
			end
		end
	end
	wipe(fake)
	wipe(spellsToIgnore)
end

--local BarPersonality
--
local FFHack

local function CheckIfDruid()
  local _,c,_=UnitClass("player")
  if c~="DRUID" then 
    test:UnregisterAllEvents()
    test:SetScript("OnUpdate",nil)
    test:SetScript("OnEvent",nil)
    return false
  else
    return true
  end
end

local function OnEvent(self,event,...)
	if 		event=="VARIABLES_LOADED" then
    CheckVersion()
    if CheckIfDruid() then
      BK_LoadFrames()
      BK_Refresh()
      BK_SetupOptions()
    end
	elseif 	event=="ADDON_LOADED" then
	
	elseif	event=="PLAYER_TARGET_CHANGED" then
		RecheckSpells()
	elseif	event=="PLAYER_REGEN_DISABLED" then
		lastBarOrder=barOrder
		lastBearBarOrder=bearBarOrder
		BK_BarPersonality() --to make sure the icons redraw properly
	elseif	event=="COMBAT_LOG_EVENT_UNFILTERED" then
		local spellname = select(13,...)
		if spellFunctions[spellname] then
			spellFunctions[spellname](...)
		end
	end
	
end

local FUFrame

local function Timerize()  --this just takes timers[] and makes rounded/not rounded lists of time-to-0
	--for spell,expirationTime in pairs(timers) do
	time = GetTime()
	wipe(floorTimes)
	wipe(fTimes)
	for i,j in pairs(timers) do
		if j-time<=0 then 
			floorTimes[i]=0
			fTimes[i]=0
		elseif j-time<1 then 
			floorTimes[i]=floor(10*(j-time))/10
			fTimes[i]=j-time
		else 
			floorTimes[i]=floor(j-time)
			fTimes[i]=j-time
		end
	end
	floorTimes[ENERGY]=timers[ENERGY]
	floorTimes[COMBO]=timers[COMBO]
	fTimes[ENERGY]=timers[ENERGY]
	fTimes[COMBO]=timers[COMBO]
end

local function UpdateEnergy()
	timers[ENERGY] = UnitPower("player",3)
	durations[ENERGY]=UnitPowerMax("player",3)
end

local function UpdateCPs()
	timers[COMBO]=GetComboPoints("player","target")
end

local spelltype,user,spellname,tarid,userid

local function UpdateAura(target,spell,spelltype)
	--only works for "target" or "player", and debuffs and buffs respectively.  I wanted it to be more flexible
	--but UnitAura was being a dickhole
	if spelltype=="SPELL_CAST_SUCCESS" or spelltype=="SPELL_AURA_APPLIED" or spelltype=="SPELL_AURA_APPLIED_DOSE" or spelltype=="SPELL_AURA_REFRESH" or spelltype=="SPELL_PERIODIC_DAMAGE" then
		if target=="player" then
			_,_,_,_,_,duration, expirationTime, unitCaster,_,_,_ = UnitBuff(target,spell) 
		else
			_,_,_,_,_,duration, expirationTime, unitCaster,_,_,_ = UnitDebuff(target,spell) 
		end
		if unitCaster~="player" then return end
		if expirationTime then
			timers[spell] = expirationTime
			durations[spell] = duration
		end
	elseif spelltype=="SPELL_AURA_REMOVED" then
		if target=="player" then
			_,_,_,_,_,_, expirationTime,_,_,_,_ = UnitBuff(target,spell) 
		else
			_,_,_,_,_,_, expirationTime, unitCaster,_,_,_ = UnitDebuff(target,spell) 
		end
		--if unitCaster~="player" then return end --causes changing targets to be dumb...
		if expirationTime and unitCaster=="player" then
			timers[spell] = expirationTime
		else
			timers[spell] = 0
		end
	end	
end

local function TFCooldown()
	if IsUsableSpell(TIGERS_FURY) then
		start, cd, enable = GetSpellCooldown(TIGERS_FURY)
		timers[TIGERS_FURY] = start+cd
	end
end

local function BarkskinCooldown()
	if IsUsableSpell(BARKSKIN) then
		start, cd, enable = GetSpellCooldown(BARKSKIN)
		timers[BARKSKIN] = start+cd
	end
end

local function ThrashCooldown()
	if IsUsableSpell(THRASH) then
		start, cd, enable = GetSpellCooldown(THRASH)
		if cd>2 then --oh god.
			timers[THRASH] = start+6 --this is almost worse than the Berserk bullshit I did below
		end
	end
end

local function BerserkCooldown()
	if IsUsableSpell(BERSERK) then
		start, cd, enable = GetSpellCooldown(BERSERK)
		if cd<=1.5 then 		--this is because the GCD shows up in this spell, not really happy about it
			--don't do anything
		else 
			timers[BERSERK] = start+cd 
		end
	end
end

local function MangleCooldown()
	if IsUsableSpell(MANGLE_CAT) then
		start, cd, enable = GetSpellCooldown(MANGLE_CAT)
    if cd>0 and cd<=1.5 then --sigh
      --don't do anything
    else
      timers[MANGLE_CAT] = start+cd
    end
	end
end

local function MoUCooldown()
	if IsUsableSpell(MIGHT_OF_URSOC) then
		start, cd, enable = GetSpellCooldown(MIGHT_OF_URSOC)
		if cd<=1.5 then 		--this is because the GCD shows up in this spell, not really happy about it
			--don't do anything
		else 
			timers[MIGHT_OF_URSOC] = start+cd 
		end
	end
end

local function SavageDefenseCooldown()
	if IsUsableSpell(SAVAGE_DEFENSE) then
		local current, maxx, last, cd = GetSpellCharges(SAVAGE_DEFENSE)
    if current == 0 then 
      timers[SAVAGE_DEFENSE]=last+cd
    else
      timers[SAVAGE_DEFENSE] = 0
    end
	end
end

local function MangleEvent(...)
	spelltype = select(2,...)
	user = select(5,...)
	tarid = select(8,...)
	spellname = select(13,...)
	if tarid ~= UnitGUID("target") then return end
	--this is pretty much UpdateAura, but forces the spell to be recorded as MANGLE_CAT, even if it's bear or trauma or buttwarts
	if spelltype=="SPELL_AURA_APPLIED" or spelltype=="SPELL_AURA_REFRESH" then
		_,_,_,_,_,duration, expirationTime,_,_,_,_ = UnitDebuff("target",spellname) 
		if expirationTime then
			timers[MANGLE_CAT] = expirationTime
			durations[MANGLE_CAT] = duration
		end
	elseif spelltype=="SPELL_AURA_REMOVED" then
		_,_,_,_,_,duration, expirationTime,_,_,_,_ = UnitDebuff("target",spellname)
		if expirationTime then
			timers[MANGLE_CAT] = expirationTime
		else
			timers[MANGLE_CAT] = 0
		end
	end	
end

local function SavageRoarEvent(...)
	userid = select(4,...)
	spelltype = select(2,...)
	if userid~=UnitGUID("player") then return end
	UpdateAura("player",SAVAGE_ROAR,spelltype)
  --BKO(spelltype)
end

local function SavageDefenseEvent(...)
	userid = select(4,...)
	spelltype = select(2,...)
	if userid~=UnitGUID("player") then return end
	UpdateAura("player",SAVAGE_DEFENSE,spelltype)
  --BKO(spelltype)
end

local function RakeEvent(...)
	userid = select(4,...)
	spelltype = select(2,...)
	if userid~=UnitGUID("player") then return end
	UpdateAura("target",RAKE,spelltype)
end

local function RipEvent(...)
	userid = select(4,...)
	spelltype = select(2,...)
	if userid~=UnitGUID("player") then return end
	UpdateAura("target",RIP,spelltype)
	--ADD SHRED GLYPH CODE
end

local function ClearcastingEvent(...)
	userid = select(4,...)
	spelltype = select(2,...)
	if userid~=UnitGUID("player") then return end
	UpdateAura("player",CLEARCASTING,spelltype)
end

--THIS DOESN'T WORK FOR REFRESHES.
--Refreshing FF doesn't throw an event so it can't be caught cleanly. 
--I use FFHack() to fix this.
local function FFEvent(...)
	spelltype = select(2,...)
	user = select(5,...)
	tarid = select(8,...)
	spellname = select(13,...)
	if tarid ~= UnitGUID("target") then return end
	if spelltype=="SPELL_AURA_REMOVED" then
		_,_,_,_,_,_, expirationTime,_,_,_,_ = UnitDebuff("target",FAERIE_FIRE)
		if expirationTime then
			timers[FAERIE_FIRE] = expirationTime
		else
			timers[FAERIE_FIRE] = 0
		end
  elseif spelltype=="SPELL_AURA_APPLIED" or spelltype=="SPELL_AURA_REFRESH" or spelltype=="SPELL_AURA_APPLIED_DOSE" then
		_,_,_,_,_,duration, expirationTime,_,_,_,_ = UnitDebuff("target",FAERIE_FIRE) 
		if expirationTime then
			timers[FAERIE_FIRE] = expirationTime
			durations[FAERIE_FIRE] = duration
		end
	end	
end

--local
function FFHack()
		_,_,_,_,_,duration, expirationTime,_,_,_,_ = UnitDebuff("target",FAERIE_FIRE) 
		if expirationTime then
			timers[FAERIE_FIRE] = expirationTime
			durations[FAERIE_FIRE] = duration
		end
end

--local
function WeakenedArmorHack()
		_,_,_,_,_,duration, expirationTime,_,_,_,_ = UnitDebuff("target",WEAKENED_ARMOR)
		if expirationTime then
			timers[WEAKENED_ARMOR] = expirationTime
			durations[WEAKENED_ARMOR] = duration
		end
end

local function WeakenedArmorEvent(...)
	spelltype = select(2,...)
	user = select(5,...)
	tarid = select(8,...)
	spellname = select(13,...)
	if tarid ~= UnitGUID("target") then return end
	if spelltype=="SPELL_AURA_REMOVED" then
		_,_,_,_,_,_, expirationTime,_,_,_,_ = UnitDebuff("target",WEAKENED_ARMOR)
		if expirationTime then
			timers[WEAKENED_ARMOR] = expirationTime
		else
			timers[WEAKENED_ARMOR] = 0
		end
  elseif spelltype=="SPELL_AURA_APPLIED" or spelltype=="SPELL_AURA_REFRESH" or spelltype=="SPELL_AURA_APPLIED_DOSE" then
		_,_,_,_,_,duration, expirationTime,_,_,_,_ = UnitDebuff("target",WEAKENED_ARMOR)
		if expirationTime then
			timers[WEAKENED_ARMOR] = expirationTime
			durations[WEAKENED_ARMOR] = duration
		end
	end	
end

local function TFEvent(...)
	userid = select(4,...)
	spelltype = select(2,...)
	if userid ~= UnitGUID("player") then return end
	--It's UpdateAura, except updates procs[] instead of timers[]
	if spelltype=="SPELL_AURA_APPLIED" or spelltype=="SPELL_AURA_REFRESH" then
		_,_,_,_,_,duration, expirationTime,_,_,_,_ = UnitBuff("player",TIGERS_FURY) 
		if expirationTime then
			procs[TIGERS_FURY] = expirationTime
			durations[TIGERS_FURY] = duration
		end
	elseif spelltype=="SPELL_AURA_REMOVED" then
		_,_,_,_,_,_, expirationTime,_,_,_,_ = UnitBuff("player",TIGERS_FURY)
		if expirationTime then
			procs[TIGERS_FURY] = expirationTime
		else
			procs[TIGERS_FURY] = 0
		end
	end	
	TFCooldown()
end

local function BerserkEvent(...)
	userid = select(4,...)
	spelltype = select(2,...)
	if userid ~= UnitGUID("player") then return end
	--It's UpdateAura, except updates procs[] instead of timers[]
	if spelltype=="SPELL_AURA_APPLIED" or spelltype=="SPELL_AURA_REFRESH" then
		_,_,_,_,_,duration, expirationTime,_,_,_,_ = UnitBuff("player",BERSERK) 
		if expirationTime then
			procs[BERSERK] = expirationTime
			durations[BERSERK] = duration
		end
	elseif spelltype=="SPELL_AURA_REMOVED" then
		_,_,_,_,_,_, expirationTime,_,_,_,_ = UnitBuff("player",BERSERK)
		if expirationTime then
			procs[BERSERK] = expirationTime
		else
			procs[BERSERK] = 0
		end
	end	
	BerserkCooldown()
end

local function BarkskinEvent(...)
	userid = select(4,...)
	spelltype = select(2,...)
	if userid ~= UnitGUID("player") then return end
	--It's UpdateAura, except updates procs[] instead of timers[]
	if spelltype=="SPELL_AURA_APPLIED" or spelltype=="SPELL_AURA_REFRESH" then
		_,_,_,_,_,duration, expirationTime,_,_,_,_ = UnitBuff("player",BARKSKIN) 
		if expirationTime then
			procs[BARKSKIN] = expirationTime
			durations[BARKSKIN] = duration
		end
	elseif spelltype=="SPELL_AURA_REMOVED" then
		_,_,_,_,_,_, expirationTime,_,_,_,_ = UnitBuff("player",BARKSKIN)
		if expirationTime then
			procs[BARKSKIN] = expirationTime
		else
			procs[BARKSKIN] = 0
		end
	end	
	BarkskinCooldown()
end

local function ThrashEvent(...)
	spelltype = select(2,...)
	user = select(5,...)
	tarid = select(8,...)
	spellname = select(13,...)
	if tarid ~= UnitGUID("target") then return end
	if spelltype=="SPELL_AURA_REMOVED" then
		_,_,_,_,_,_, expirationTime,_,_,_,_ = UnitDebuff("target",THRASH)
		if expirationTime then
			timers[THRASH] = expirationTime
		else
			timers[THRASH] = 0
		end
  elseif spelltype=="SPELL_AURA_APPLIED" or spelltype=="SPELL_AURA_REFRESH" or spelltype=="SPELL_AURA_APPLIED_DOSE" then
		_,_,_,_,_,duration, expirationTime,_,_,_,_ = UnitDebuff("target",THRASH) 
		if expirationTime then
			timers[THRASH] = expirationTime
			durations[THRASH] = duration
		end
	end	
end

local function PSEvent(...)
	userid = select(4,...)
	spelltype = select(2,...)
	if userid~=UnitGUID("player") then return end
	UpdateAura("player",PREDATORS_SWIFTNESS,spelltype)
end

local function ShredEvent(...)
	userid = select(4,...)
	spelltype = select(2,...)
	if userid~=UnitGUID("player") then return end
	if spelltype == "SPELL_CAST_SUCCESS" then
		UpdateAura("target",RIP,"SPELL_AURA_APPLIED")
	end
end

local function LacerateEvent(...)
	userid = select(4,...)
	spelltype = select(2,...)
	if userid~=UnitGUID("player") then return end
	UpdateAura("target",LACERATE,spelltype)
end


Timerize()

local BAOVal = {}
local BAOUsed = {}
local BAOTimes = {}
local BAOForm,BAOUseds,place
local BarAutoOrder; 	--ugh declarations
local FrameUpdate;
local FullFrameUpdate;

local function OnUpdate()
  --FFHack() --urgh
  WeakenedArmorHack()
	TFCooldown()
	BerserkCooldown()
	BarkskinCooldown()
	--ThrashCooldown()
  MangleCooldown()
  MoUCooldown()
	UpdateEnergy()
	UpdateCPs()
	Timerize()
	BarAutoOrder()
	--BK_BarPersonality()
	FrameUpdate()
	--check for moving bars and let-em move if they are
	time = GetTime()
	if barMove+10>time then
		BKMoveBarText:SetText("Move the bars! "..floor(barMove+10-time))
		BKMoveWarningText:SetText("Move the warnings! "..floor(barMove+10-time))
	elseif barMove>0 and not MouseIsOver(BKMoveWarning) and not MouseIsOver(BKMoveBar) then
		BKMoveBarText:SetText("")
		BKMoveWarningText:SetText("")
		BKMoveBar:Hide()
		BKMoveWarning:Hide()
		BKMoveBar:EnableMouse(false)
		BKMoveWarning:EnableMouse(false)
		--local btop= BKBar1:GetTop()
		--local bleft= BKBar1:GetLeft()
		--local wtop= BKWarning1:GetTop()
		--local wleft= BKWarning1:GetLeft()
		BKSettings["barloc"] = {BKBar1:GetLeft(),BKBar1:GetTop()}
		BKSettings["warningloc"] = {BKWarning1:GetLeft(),BKWarning1:GetTop()}
		barMove = 0
	end
end

--script registration happens here
test:SetScript("OnEvent",OnEvent)
test:SetScript("OnUpdate",OnUpdate)

--Each spell caught in the combat event will call an associated function
--that does all the parsing and stuff.  They are initialized here.

--spellFunctions[MANGLE_CAT] = MangleCooldown
--spellFunctions[MANGLE_BEAR] = MangleEvent
spellFunctions[SAVAGE_ROAR] = SavageRoarEvent
spellFunctions[RAKE] = RakeEvent
spellFunctions[RIP] = RipEvent
spellFunctions[CLEARCASTING] = ClearcastingEvent
--spellFunctions[FAERIE_FIRE] = FFEvent
spellFunctions[FAERIE_FIRE] = WeakenedArmorEvent
spellFunctions[WEAKENED_ARMOR] = WeakenedArmorEvent
spellFunctions[BERSERK] = BerserkEvent
spellFunctions[TIGERS_FURY] = TFEvent
spellFunctions[PREDATORS_SWIFTNESS] = PSEvent
spellFunctions[SHRED] = ShredEvent
spellFunctions[LACERATE] = LacerateEvent
--spellFunctions[PULVERIZE] = PulverizeEvent
spellFunctions[BARKSKIN] = BarkskinEvent
--spellFunctions[DEMO_ROAR] = DemoRoarEvent
--spellFunctions[DEMO_SHOUT] = DemoRoarEvent
spellFunctions[VINDICATION] = DemoRoarEvent
spellFunctions[THRASH] = ThrashEvent
spellFunctions[SAVAGE_DEFENSE] = SavageDefenseEvent

--------------------------------------
--Interface stuff
--------------------------------------

local HSList = {} --used for the Hide/Show Warnings/Bars functions

local function HideWarnings()
	HSList = BKWarningList
	for j,_ in pairs(HSList) do
		if j~="no" then 
			BKWarningList[j]:SetAlpha(0)
			--_G[j]:SetAlpha(0)
		end
	end
end

local function ShowWarnings()
	if GetShapeshiftForm(true)==3 then 
		HSList = BKSettings["warnorder"]
	elseif GetShapeshiftForm(true)==1 then
		HSList = BKSettings["bearwarnorder"]
	else
		return
	end
	for i,j in pairs(HSList) do
		if j~="no" then 
			BKWarningList["BKWarning"..j]:SetAlpha(BKSettings["warningalpha"])
			--_G["BKWarning"..j]:SetAlpha(0.5)
		end
	end
end

function BK_HideBars()
	HSList = BKBarList
	for i,j in pairs(HSList) do
		_G[i]:Hide()
		_G[i.."Icon"]:Hide()
		_G[i.."Bar"]:Hide()
	end
end

function BK_ShowBars()
	local onlist
	if GetShapeshiftForm(true)==3 then 
		HSList = BKSettings["barorder"]
		onlist = BKSettings["baron"]
	elseif GetShapeshiftForm(true)==1 then
		HSList = BKSettings["bearbarorder"]
		onlist = BKSettings["bearbaron"]
	else
		return
	end
	for i,j in pairs(HSList) do
		if onlist[j] then 
			_G[i]:Show()
			_G[i.."Icon"]:Show()
			_G[i.."Bar"]:Show()
		--[[else
			_G[i]:Hide()
			_G[i.."Icon"]:Hide()
			_G[i.."Bar"]:Hide()]]
		end
	end
end

local function BarLayout()
	--organizes the locations and layout of the bars and their icons, not based on spells
	iter = 0
	for i,_ in pairs(BKBarList) do 
		iter = iter + 1				--doing this a stupid way so the frames are done in order
		_G["BKBar"..iter.."Bar_Background"]:SetTexture(0,0,0,BKSettings["barbackalpha"])
		_G["BKBar"..iter]:ClearAllPoints()
		if iter==1 then
			_G["BKBar"..iter]:SetPoint("CENTER")
		else		
			_G["BKBar"..iter]:SetPoint("BOTTOM",_G["BKBar"..(iter-1)],"TOP")
		end
		_G[i.."Bar"]:SetMinMaxValues(0,30)	--I may put this somewhere else, be aware
	end
end

local function WarningLayout()
	local f = 1
	while true do
		if not _G["BKWarning"..f] then break end
		_G["BKWarning"..f]:ClearAllPoints()
		f = f+1
	end
	BKWarning1:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",BKSettings["warningloc"][1],BKSettings["warningloc"][2])
	local i = 2
	local n = 1
	local count = 0
	if BKSettings["warninglayout"]["direction"]=="r" then
		while true do
			if not _G["BKWarning"..i] then break end
			if n==BKSettings["warninglayout"]["size"] then
				_G["BKWarning"..i]:SetPoint("LEFT","BKWarning"..(1+BKSettings["warninglayout"]["size"]*count),"RIGHT")
				count = count+1
				n = 1
			else
				_G["BKWarning"..i]:SetPoint("TOP","BKWarning"..(i-1),"BOTTOM")
				n = n+1
			end
			i = i+1
		end
	else	--"c"
		while true do
			if not _G["BKWarning"..i] then break end
			if n==BKSettings["warninglayout"]["size"] then
				_G["BKWarning"..i]:SetPoint("TOP","BKWarning"..(1+BKSettings["warninglayout"]["size"]*count),"BOTTOM")
				count = count+1
				n = 1
			else
				_G["BKWarning"..i]:SetPoint("LEFT","BKWarning"..(i-1),"RIGHT")
				n = n+1
			end
			i = i+1
		end
	end
end

--this function is to force a change in the warning spell order.  For switching forms, etc, FrameUpdate() handles it.
function BK_WarningPersonality()
	if GetShapeshiftForm(true)==3 then
		for spell,frame in pairs(BKSettings["warnorder"]) do
			if frame~="no" then
				_G["BKWarning"..frame]:SetBackdrop({bgFile=ICONS[spell]})
			else
				--_G["BKWarning"..frame]:SetAlpha(0)
			end
		end
	elseif GetShapeshiftForm(true)==1 then
		for spell,frame in pairs(BKSettings["bearwarnorder"]) do
			if frame~="no" then
				_G["BKWarning"..frame]:SetBackdrop({bgFile=ICONS[spell]})
			else
				--_G["BKWarning"..frame]:SetAlpha(0)
			end
		end
	end
	FullFrameUpdate()
end

local function oBarPersonality()
	local _G = _G
	for frame,spell in pairs(barOrder) do
		if spell=="no" then
			_G[frame]:Hide()
		else
			_G[frame.."Icon"]:SetBackdrop({bgFile=ICONS[spell]})
			_G[frame.."Bar"]:SetStatusBarColor(BKSettings["barcolor"][spell][1],BKSettings["barcolor"][spell][2],BKSettings["barcolor"][spell][3])
		end
	end
end

function BK_BarPersonality() --local
	form = GetShapeshiftForm(true)
	if form==3 then
		--if not lastBarOrder then lastBarOrder = barOrder end
		--if lastBarOrder==barOrder then
			--return
		--end
		for frame,spell in pairs(barOrder) do
			--if lastBarOrder[frame]~=spell then
				BKBarIconList[frame]:SetBackdrop({bgFile=ICONS[spell]})
				BKBarTextList[frame]:SetText(spell)
				BKBarBarList[frame]:SetStatusBarColor(BKSettings["barcolor"][spell][1],BKSettings["barcolor"][spell][2],BKSettings["barcolor"][spell][3],BKSettings["baralpha"])
				BKBarBarList[frame]:SetMinMaxValues(0,durations[spell])
			--end
		end
	elseif form==1 then
		if not lastBearBarOrder then lastBearBarOrder = bearBarOrder end
		--if lastBearBarOrder==bearBarOrder then
			--return
		--end
		for frame,spell in pairs(bearBarOrder) do
			--if lastBearBarOrder[frame]~=spell then
				BKBarIconList[frame]:SetBackdrop({bgFile=ICONS[spell]})
				BKBarTextList[frame]:SetText(spell)
				BKBarBarList[frame]:SetStatusBarColor(BKSettings["bearbarcolor"][spell][1],BKSettings["bearbarcolor"][spell][2],BKSettings["bearbarcolor"][spell][3],BKSettings["baralpha"])
				BKBarBarList[frame]:SetMinMaxValues(0,durations[spell])
			--end
		end
	else
		return
	end
end



function BarAutoOrder()		--it's local
	if not BKSettings["barlock"] then
		BAOForm = GetShapeshiftForm(true)
		BAOUseds = 0
		wipe(BAOUsed)
		wipe(BAOVal)
		if BAOForm == 3 then
			if BKSettings["baron"][ENERGY] then fTimes[ENERGY]=2000 end
			if BKSettings["baron"][COMBO] then fTimes[COMBO]=2000 end
			for frame,sp1 in pairs(barOrder) do
				if BKSettings["baron"][sp1] then
					BAOUsed[sp1] = frame
					BAOUseds=BAOUseds+1 --ugh
				end
			end
		elseif BAOForm==1 then
			for frame,sp1 in pairs(bearBarOrder) do
				if BKSettings["bearbaron"][sp1] then
					BAOUsed[sp1] = frame
					BAOUseds=BAOUseds+1 --ugh
				end
			end
		else
			return
		end
		for sp1,frame in pairs(BAOUsed) do
			place = 1
			--if not BKSettings["baron"][sp1] then --put a dummy spell in fTimes, make it last
			--	fTimes[sp1]=-10000
			--	BAOOffset = BAOOffset+1
			--end
			for sp2,t in pairs(fTimes) do
				if sp2~=sp1 and BAOUsed[sp2] and fTimes[sp1]<=t then
					place = place + 1
				end
			end
			while BAOVal["BKBar"..place] do
				place = place - 1
			end
			BAOVal["BKBar"..place] = sp1
		end
		if BAOVal["BKBar0"] then
			BAOVal["BKBar0"]=nil
		end
		if BAOForm==3 then
			wipe(barOrder)
			for i,j in pairs(BAOVal) do
				barOrder[i]=j
			end
		elseif BAOForm==1 then
			wipe(bearBarOrder)
			for i,j in pairs(BAOVal) do
				bearBarOrder[i]=j
			end
		end
	else
		if BAOForm==3 then
			--barOrder=BKSettings["barorder"]
			exportBarOrder(3)
		elseif BAOForm==1 then
			--bearBarOrder = BKSettings["bearbarorder"]
			exportBarOrder(1)
		end
	end
end

--UNUSED FUNCTION, NOT UPDATED FOR BEAR SHIT
function BK_BarSync() --Makes sure BKCatSpells and barorder are on the same page
	local i=1
	local tempSpells = {}
	local tempNos = {}
	while i<=#(BKCatSpells) do
		if BKSettings["barorder"]["BKBar"..i]=="no" then
			BKCatSpells[i]="no"
		else
			tinsert(tempSpells, BKCatSpells[i])
			BKCatSpells[i]=BKSettings["barorder"]["BKBar"..i]
		end
		i=i+1
	end
	--wipe(tempSpells)
	--wipe(tempNos)
end

function BK_LoadFrames()
	for i=1,12 do
		CreateFrame("Frame","BKWarning"..i,UIParent,"BKWarningTemplate")
		CreateFrame("Frame","BKBar"..i,UIParent,"BKBarTemplate")
		BKWarningList["BKWarning"..i]=_G["BKWarning"..i]
		BKWarningTextList["BKWarning"..i]=_G["BKWarning"..i.."Text"]
		BKBarList["BKBar"..i]=_G["BKBar"..i]
		BKBarTextList["BKBar"..i]=_G["BKBar"..i.."BarText"]
		BKBarSecsList["BKBar"..i]=_G["BKBar"..i.."BarSecs"]
		BKBarIconList["BKBar"..i]=_G["BKBar"..i.."Icon"]
		BKBarBarList["BKBar"..i]=_G["BKBar"..i.."Bar"]
	end
	local warn = CreateFrame("Frame","BKMoveWarning",UIParent,"BKMoveTemplate")
	local bar = CreateFrame("Frame","BKMoveBar",UIParent,"BKMoveTemplate")
	warn:ClearAllPoints()
	warn:SetPoint("TOPLEFT","BKWarning1","TOPLEFT")
	bar:ClearAllPoints()
	bar:SetPoint("BOTTOMLEFT","BKBar1","BOTTOMLEFT")
	bar:Hide()
	warn:Hide()
	bar:SetScript("OnMouseDown",function () BKBar1:StartMoving() end)
	bar:SetScript("OnMouseUp",function () BKBar1:StopMovingOrSizing() end)
	bar:SetScript("OnDragStop",function () BKBar1:StopMovingOrSizing() end)
	warn:SetScript("OnMouseDown",function () BKWarning1:StartMoving() end)
	warn:SetScript("OnMouseUp",function () BKWarning1:StopMovingOrSizing() end)
	warn:SetScript("OnDragStop",function () BKWarning1:StopMovingOrSizing() end)
	WarningLayout()
	BarLayout()
	BK_WarningPersonality()
	BK_BarPersonality()
	BK_ShowBars()
	BK_HideBars()
	--HideWarnings()
	--ShowWarnings()
	BKWarning1:ClearAllPoints()
	BKWarning1:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",BKSettings["warningloc"][1],BKSettings["warningloc"][2])
	BKBar1:ClearAllPoints()
	BKBar1:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",BKSettings["barloc"][1],BKSettings["barloc"][2])
	
	--BK_BarSync()
	BKO("BadKitty is installed!  Access the options window with /bk.  Move frames with /bk move.")
end

local FUForm,FUBar,FUSpell,FUFrame,FUTime,FUBarSecs,FUBarText

function FullFrameUpdate()	--it's local
	--Display timers on the warnings
	--local _G = _G
	BK_BarPersonality()
	FUTime = GetTime()
	FUForm = GetShapeshiftForm(true)
	if FUForm==3 or FUForm==1 then
		if FUForm==3 then
			--warnorder = BKSettings["warnorder"]
			--barson = BKSettings["catbarson"]
			--baron = BKSettings["baron"]
			--order = barOrder
		elseif FUForm==1 then
			--warnorder = BKSettings["bearwarnorder"]
			--barson = BKSettings["bearbarson"]
			--baron = BKSettings["bearbaron"]
			--order = bearBarOrder
		else
			return
		end
		if (function() if FUForm==3 then return BKSettings["catwarningson"] else return BKSettings["bearwarningson"] end end)() then
			i=1
			while true do
				if not BKWarningList["BKWarning"..i] then break end
				BKWarningList["BKWarning"..i]:SetAlpha(0)
				i = i+1
			end
			for FUSpell,FUFrame in (function() if FUForm==3 then return pairs(BKSettings["warnorder"]) else return pairs(BKSettings["bearwarnorder"]) end end)() do
				if FUFrame~="no" then
					FUFrame = "BKWarning"..FUFrame
					if FUSpell==CLEARCASTING or FUSpell==PREDATORS_SWIFTNESS then
						if floorTimes[FUSpell]==0 then	---this is a straight-up hack for OOC.  Needs to be replaced long term because it's ugly.
							BKWarningList[FUFrame]:SetAlpha(0)
						else
							BKWarningList[FUFrame]:SetAlpha(BKSettings["warningalpha"]) 
							BKWarningTextList[FUFrame]:SetText(floorTimes[FUSpell])
							BKWarningList[FUFrame]:SetBackdropColor(1,1,1,BKSettings["warningalpha"])
						end
					else
						if floorTimes[FUSpell]==0 then
							BKWarningTextList[FUFrame]:SetText("")
						else
							BKWarningTextList[FUFrame]:SetText(floorTimes[FUSpell])
						end
						if floorTimes[FUSpell]<BKSettings["warntime"][FUSpell] and floorTimes[FUSpell]>0 then  --about to fall off
							BKWarningList[FUFrame]:SetAlpha(BKSettings["warningalpha"]) --replace with the setting!
							BKWarningList[FUFrame]:SetBackdropColor(1,1,1)
						elseif floorTimes[FUSpell]==0 then	--felled off
							BKWarningList[FUFrame]:SetBackdropColor(BKSettings["offcolor"][1],BKSettings["offcolor"][2],BKSettings["offcolor"][3])
							BKWarningList[FUFrame]:SetAlpha(BKSettings["warningalpha"]) --replace with the setting!
						else						--up and has time left
							BKWarningList[FUFrame]:SetAlpha(0)
						end
					end
					if not InCombatLockdown() then	--out of combat
						BKWarningList[FUFrame]:SetAlpha(0) --can't use Hide() because then we can't move them out of combat.  Dunno why that is.
					else
						--w_G[FUFrame]:SetAlpha(0.5) --replace with the setting!
					end
				end
			end
		else
			HideWarnings()
		end
		--display timers on the bars (and disappeared them if needed)
		if (function() if FUForm==3 then return BKSettings["catbarson"] else return BKSettings["bearbarson"] end end)() then
			for FUBar,FUSpell in (function() if FUForm==3 then return pairs(barOrder) else return pairs(bearBarOrder) end end)() do
				if (function() if FUForm==3 then return BKSettings["baron"] else return BKSettings["bearbaron"] end end)()[FUSpell] then
					if BKSettings["barscale"] then
						BKBarBarList[FUBar]:SetMinMaxValues(0,durations[FUSpell])
					else
						BKBarBarList[FUBar]:SetMinMaxValues(0,BKSettings["barlength"])
					end
					if FUSpell==ENERGY or FUSpell==COMBO then
						BKBarSecsList[FUBar]:SetText(timers[FUSpell])	
						BKBarTextList[FUBar]:SetText(FUSpell)
						BKBarBarList[FUBar]:SetValue(timers[FUSpell])
						BKBarBarList[FUBar]:SetMinMaxValues(0,durations[FUSpell])
						BKBarIconList[FUBar]:SetBackdrop({bgFile=ICONS[FUSpell]})
						BKBarBarList[FUBar]:SetStatusBarColor(BKSettings["barcolor"][FUSpell][1],BKSettings["barcolor"][FUSpell][2],BKSettings["barcolor"][FUSpell][3])
					else
						BKBarSecsList[FUBar]:SetText(floorTimes[FUSpell])	
						BKBarTextList[FUBar]:SetText(FUSpell)
						--_G[bar.."Bar"]:SetValue(ftimes[FUSpell])--note, that's times, not floorTimes.  We want it to scale more than once per second
						BKBarBarList[FUBar]:SetValue(timers[FUSpell]-FUTime)
					end
					if floorTimes[FUSpell]==0 and not BKSettings["barzero"] then 
						BKBarList[FUBar]:Hide()
						BKBarIconList[FUBar]:Hide()
						BKBarBarList[FUBar]:Hide()
					else
						BKBarList[FUBar]:Show()
						BKBarIconList[FUBar]:Show()
						BKBarBarList[FUBar]:Show()
					end
					if floorTimes[FUSpell]==0 and not BKSettings["barlock"] then
						BKBarBarList[FUBar]:Hide()
						BKBarIconList[FUBar]:Hide()
						BKBarBarList[FUBar]:Hide()
					end
					if FUSpell==ENERGY or FUSpell==COMBO then
						BKBarList[FUBar]:Show()
						BKBarIconList[FUBar]:Show()
						BKBarBarList[FUBar]:Show()
					end
				end
				if not InCombatLockdown() and BKSettings["barcombat"] then
					BKBarList[FUBar]:Hide()
					BKBarIconList[FUBar]:Hide()
					BKBarBarList[FUBar]:Hide()
				end
			end
		else
			BK_HideBars()
		end
		
	else
		BK_HideBars()
		HideWarnings()
	end
	for name,frame in pairs(BKBarList) do
		if frame:IsShown() then
			BKBarState[name]=1
		else
			BKBarState[name]=0
		end
	end
	for name,frame in pairs(BKWarningList) do
		if frame:GetAlpha()==0 then
			BKWarningState[name]=0 --hidden
		else 
			_,_,j = frame:GetBackdropColor()
			if j>0.99 then
				BKWarningState[name]=1 --on and ticking (full color)
			else
				BKWarningState[name]=2 --on but red
			end
		end
	end
end

function BBO()
	for f,s in pairs(barOrder) do
		BKO(f.." "..s)
	end
end

function FrameUpdate()	--it's local
	local state =0
	local bgInfo = {};
	if GetShapeshiftForm(true)==3 then
		if BKSettings["catwarningson"] then
			for spell,frame in pairs(BKSettings["warnorder"]) do
				frame = "BKWarning"..frame
				if frame~="BKWarningno" then
					if floorTimes[spell]==0 then
						if spell==CLEARCASTING or spell==PREDATORS_SWIFTNESS then
							state=0
						else
							state=2
						end
					elseif floorTimes[spell]<BKSettings["warntime"][spell] then
						state=1
					else
						state=0
					end
					if not InCombatLockdown() then
						state=0
					end
					if not BKWarningState[frame] then
						BK_WarningPersonality()
						return
					end
					if state==1 then
						BKWarningTextList[frame]:SetText(floorTimes[spell])
					end
					if BKWarningState[frame]~=state then
						if state==0 then
							BKWarningList[frame]:SetAlpha(0) 
							BKWarningState[frame]=state
						else
							bgInfo = BKWarningList[frame]:GetBackdrop()
							if bgInfo["bgFile"]~=ICONS[spell] then --make sure all the tiles draw correctly
								BKWarningList[frame]:SetBackdrop({bgFile=ICONS[spell]})
								BKWarningState[spell]=0
							end 
							wipe(bgInfo)
							if state==1 then
								BKWarningList[frame]:SetAlpha(BKSettings["warningalpha"]) 
								BKWarningTextList[frame]:SetText(floorTimes[spell])
								BKWarningList[frame]:SetBackdropColor(1,1,1,BKSettings["warningalpha"])
								BKWarningState[frame]=state
							else
								BKWarningList[frame]:SetAlpha(BKSettings["warningalpha"]) 
								BKWarningTextList[frame]:SetText("")
								BKWarningList[frame]:SetBackdropColor(1,0,0,BKSettings["warningalpha"])
								BKWarningState[frame]=state
							end
						end
					end
				end
			end
		end
		if BKSettings["catbarson"] then
			for frame,spell in pairs(barOrder) do
				if BKSettings["barscale"] then
					BKBarBarList[frame]:SetMinMaxValues(0,durations[spell])
				else
					BKBarBarList[frame]:SetMinMaxValues(0,BKSettings["barlength"])
				end
				if InCombatLockdown() or not BKSettings["barcombat"] then
					if BKSettings["baron"][spell] then
						if floorTimes[spell]==0 then
							if BKSettings["barzero"] and BKSettings["barlock"] then
								state=1
							else
								state=0
							end
						else
							state=1
						end
						if spell==ENERGY or spell==COMBO then
							state=1
						end
					else
						state=0
					end
				else
					state=0
				end
				if not BKBarState[frame] then
					BK_WarningPersonality()
					return
				end
				if BKBarState[frame]~=state then
					if state==0 then
						BKBarList[frame]:Hide()
						BKBarIconList[frame]:Hide()
						BKBarBarList[frame]:Hide()
						BKBarState[frame]=state
					else
						BKBarList[frame]:Show()
						BKBarIconList[frame]:Show()
						BKBarBarList[frame]:Show()
						BKBarState[frame]=state
					end
				end
				if state==1 then
					BKBarSecsList[frame]:SetText(floorTimes[spell])	
					BKBarBarList[frame]:SetValue(fTimes[spell])
					if spell==ENERGY or spell==COMBO then
						BKBarBarList[frame]:SetValue(timers[spell])
					end
					if BKBarTextList[frame]:GetText()~=spell then
						BKBarTextList[frame]:SetText(spell)
						BKBarIconList[frame]:SetBackdrop({bgFile=ICONS[spell]})
						BKBarBarList[frame]:SetStatusBarColor(BKSettings["barcolor"][spell][1],BKSettings["barcolor"][spell][2],BKSettings["barcolor"][spell][3])
						BKBarBarList[frame]:SetMinMaxValues(0,durations[spell])
					end
				end
			end
		else
			for i,j in pairs(BKBarList) do
				if BKBarState[i]~=0 then
					BKBarList[i]:Hide()
					BKBarIconList[i]:Hide()
					BKBarBarList[i]:Hide()
					BKBarState[i]=state
					BKBarState[i]=0
				end
			end
		end
	elseif GetShapeshiftForm(true)==1 then
		if BKSettings["bearwarningson"] then
			for spell,frame in pairs(BKSettings["bearwarnorder"]) do
				frame="BKWarning"..frame
				if frame~="BKWarningno" then
					if BKWarningList[frame]:GetBackdrop()["bgFile"]~=ICONS[spell] then --make sure all the tiles draw correctly
						BKWarningList[frame]:SetBackdrop({bgFile=ICONS[spell]})
						BKWarningState[spell]=0
						BKWarningList[frame]:SetAlpha(0)
					end
					if floorTimes[spell]==0 then
						if spell==CLEARCASTING or spell==PREDATORS_SWIFTNESS then
							state=0
						else
							state=2
						end
					elseif floorTimes[spell]<BKSettings["warntime"][spell] then
						state=1
					else
						state=0
					end
					if not InCombatLockdown() then
						state=0
					end
					if frame~="BKWarningno" and not BKWarningState[frame] then
						BK_WarningPersonality()
						return
					end
					if state==1 then
						BKWarningTextList[frame]:SetText(floorTimes[spell])
					end
					if BKWarningState[frame]~=state then
						if state==0 then
							BKWarningList[frame]:SetAlpha(0) 
							BKWarningState[frame]=state
						else
							bgInfo = BKWarningList[frame]:GetBackdrop()
							if bgInfo["bgFile"]~=ICONS[spell] then --make sure all the tiles draw correctly
								BKWarningList[frame]:SetBackdrop({bgFile=ICONS[spell]})
								BKWarningState[spell]=0
							end 
							wipe(bgInfo)
							if state==1 then
								BKWarningList[frame]:SetAlpha(BKSettings["warningalpha"]) 
								BKWarningTextList[frame]:SetText(floorTimes[spell])
								BKWarningList[frame]:SetBackdropColor(1,1,1,BKSettings["warningalpha"])
								BKWarningState[frame]=state
							else
								BKWarningList[frame]:SetAlpha(BKSettings["warningalpha"]) 
								BKWarningTextList[frame]:SetText("")
								BKWarningList[frame]:SetBackdropColor(1,0,0,BKSettings["warningalpha"])
								BKWarningState[frame]=state
							end
						end
					end
				end
			end
		end
		if BKSettings["bearbarson"] then
			for frame,spell in pairs(bearBarOrder) do
				if BKSettings["barscale"] then
					BKBarBarList[frame]:SetMinMaxValues(0,durations[spell])
				else
					BKBarBarList[frame]:SetMinMaxValues(0,BKSettings["barlength"])
				end
				if InCombatLockdown() or not BKSettings["barcombat"] then
					if BKSettings["bearbaron"][spell] then
						if floorTimes[spell]==0 then
							if BKSettings["barzero"] and BKSettings["barlock"] then
								state=1
							else
								state=0
							end
						else
							state=1
						end
						if spell==ENERGY or spell==COMBO then
							state=1
						end
					else
						state=0
					end
				else
					state=0
				end
				if not BKBarState[frame] then
					FullFrameUpdate()
					return
				end
				if BKBarState[frame]~=state then
					if state==0 then
						BKBarList[frame]:Hide()
						BKBarIconList[frame]:Hide()
						BKBarBarList[frame]:Hide()
						BKBarState[frame]=state
					else
						BKBarList[frame]:Show()
						BKBarIconList[frame]:Show()
						BKBarBarList[frame]:Show()
						BKBarState[frame]=state
					end
				end
				if state==1 then
					BKBarSecsList[frame]:SetText(floorTimes[spell])	
					BKBarBarList[frame]:SetValue(fTimes[spell])
					if spell==ENERGY or spell==COMBO then
						BKBarBarList[frame]:SetValue(timers[spell])
					end
					if BKBarTextList[frame]:GetText()~=spell then
						BKBarTextList[frame]:SetText(spell)
						BKBarIconList[frame]:SetBackdrop({bgFile=ICONS[spell]})
						BKBarBarList[frame]:SetStatusBarColor(BKSettings["bearbarcolor"][spell][1],BKSettings["bearbarcolor"][spell][2],BKSettings["bearbarcolor"][spell][3])
						BKBarBarList[frame]:SetMinMaxValues(0,durations[spell])
					end
				end
			end
		else
			for i,j in pairs(BKBarList) do
				if BKBarState[i]~=0 then
					BKBarList[i]:Hide()
					BKBarIconList[i]:Hide()
					BKBarBarList[i]:Hide()
					BKBarState[i]=state
					BKBarState[i]=0
				end
			end
		end
	else
		for i,j in pairs(BKBarList) do
			if BKBarState[i]~=0 then
				BKBarList[i]:Hide()
				BKBarIconList[i]:Hide()
				BKBarBarList[i]:Hide()
				BKBarState[i]=state
				BKBarState[i]=0
			end
		end
		for i,j in pairs(BKWarningList) do
			j:SetAlpha(0)
			BKWarningState[i]=0
		end
	end
end

function BK_Refresh()
	local i = 1
	while true do
		if not _G["BKWarning"..i] then break end
		_G["BKWarning"..i]:SetWidth(BKSettings["warningsize"])
		_G["BKWarning"..i]:SetHeight(BKSettings["warningsize"])
	--	_G["BKWarning"..i]:SetAlpha(BKSettings["warningalpha"])
		_G["BKWarning"..i.."Text"]:SetFont("Fonts\\FRIZQT__.TTF",BKSettings["warningfont"])
		i = i+1
	end
	i=1
	--barOrder = BKSettings["barorder"]
	exportBarOrder(3)
	--bearBarOrder = BKSettings["bearbarorder"]
	exportBarOrder(1)
	BarAutoOrder()
	while true do
		if not _G["BKBar"..i] then break end
		_G["BKBar"..i]:SetWidth(BKSettings["barwidth"])
		_G["BKBar"..i]:SetHeight(BKSettings["barheight"])
		_G["BKBar"..i.."Bar"]:SetWidth(BKSettings["barwidth"]-BKSettings["barheight"])--for the icon
		_G["BKBar"..i.."Bar"]:SetHeight(BKSettings["barheight"])
		_G["BKBar"..i.."Icon"]:SetWidth(BKSettings["barheight"])
		_G["BKBar"..i.."Icon"]:SetHeight(BKSettings["barheight"])
		_G["BKBar"..i.."Bar_Background"]:SetTexture(0,0,0,BKSettings["barbackalpha"])
		_G["BKBar"..i.."BarText"]:SetFont("Fonts\\FRIZQT__.TTF",BKSettings["barfont"])
		_G["BKBar"..i.."BarSecs"]:SetFont("Fonts\\FRIZQT__.TTF",BKSettings["barfont"])
		_G["BKBar"..i.."BarText"]:SetTextColor(BKSettings["barcolor"]["font"][1],BKSettings["barcolor"]["font"][2],BKSettings["barcolor"]["font"][3])
		_G["BKBar"..i.."BarSecs"]:SetTextColor(BKSettings["barcolor"]["font"][1],BKSettings["barcolor"]["font"][2],BKSettings["barcolor"]["font"][3])
    _G["BKBar"..i.."Bar"]:SetStatusBarTexture(BKSettings["bartexture"])
		_G["BKBar"..i.."Bar"]:SetHeight(BKSettings["barheight"])
		i = i+1
	end
	WarningLayout()
	BK_WarningPersonality()
	BK_BarPersonality()
	--BK_HideBars()
	--BK_ShowBars()
end

function BK_Move()
	--how many bars do we have to make the frame fit?
	local barcount = 0
	for _,j in pairs(barOrder) do
		if BKSettings["baron"][j] then
			barcount = barcount +1
		end
	end
	--resize bar and warning move frames
	BKMoveBar:SetWidth(BKSettings["barheight"]+BKSettings["barwidth"]) --bar width plus the icon width, which is the bar height
	BKMoveBar:SetHeight(BKSettings["barheight"]*barcount)
	BKMoveWarning:SetWidth(BKSettings["warningsize"]*3)		--3 is a hack for now, fix it to take into account warning orientation
	BKMoveWarning:SetHeight(BKSettings["warningsize"]*3)
	
	--make sure the bar frame is actually where the bars go
	BKMoveBar:ClearAllPoints()
	if BKSettings["bargrowth"]=="up" then
		BKMoveBar:SetPoint("BOTTOMLEFT","BKBar1","BOTTOMLEFT")
	else
		BKMoveBar:SetPoint("TOPLEFT","BKBar1","TOPLEFT")
	end
	barMove = GetTime()
	BKMoveWarning:Show()
	BKMoveBar:Show()
	BKMoveBar:EnableMouse(true)
	BKMoveWarning:EnableMouse(true)
end

function exportBarOrder(form) --local
	if form==3 then
		wipe(barOrder)
		for s,f in pairs(BKSettings["barorder"]) do
			barOrder[s]=f
		end
	elseif form==1 then
		wipe(bearBarOrder)
		for s,f in pairs(BKSettings["bearbarorder"]) do
			bearBarOrder[s]=f
		end
	end
end

function BK_WarningThreshold()
	for i,_ in pairs(timers) do
		BKSettings["warntime"][i]=BKOptionsWarningThreshold:GetValue()
	end
end

