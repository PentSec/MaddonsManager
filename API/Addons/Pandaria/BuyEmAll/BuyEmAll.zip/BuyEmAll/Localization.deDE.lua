﻿-- Thanks to JokerGermany and Lysandro!

if GetLocale() == "deDE" then
	BUYEMALL_LOCALS = {
	MAX 			= "Max",
	STACK 		    = "Stack",
	CONFIRM 		= "Bist du sicher das du\n %d × %s kaufen willst?",
	STACK_PURCH	    = "Stack kaufen/auffüllen",
	STACK_SIZE 		= "Stack größe",
	PARTIAL 		= "Benötig um Stack auzufüllen",
	MAX_PURCH 		= "Größt möglcher Einkauf",
	FIT 			= "Du hast Platz für",
	AFFORD 			= "Du kannst dir leisten",
	AVAILABLE 		= "Der Verkäufer hat",
}
end

local L = BUYEMALL_LOCALS;