﻿-- Thanks to q09q09 and networm!

if GetLocale() == "zhCN" then
	BUYEMALL_LOCALS = {
	MAX				= "最多",
	STACK			= "一组",
	CONFIRM			= "是否要买\n%2$s × %1$d个？",
	STACK_PURCH		= "按组购买",
	STACK_SIZE		= "每组数量",
	PARTIAL			= "整组差值",
	MAX_PURCH		= "最多购买",
	FIT				= "背包最多存放",
	AFFORD			= "现金最多购买",
	AVAILABLE		= "商人存货数量",
}
end

local L = BUYEMALL_LOCALS;