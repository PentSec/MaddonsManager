# Kiwi Farm

## [1.80](https://github.com/michaelnpsp/KiwiFarm/tree/1.80) (2024-11-07)
[Full Changelog](https://github.com/michaelnpsp/KiwiFarm/compare/1.79...1.80) [Previous Releases](https://github.com/michaelnpsp/KiwiFarm/releases)

- Added RECrystallize action house scanner addon price sources.  
