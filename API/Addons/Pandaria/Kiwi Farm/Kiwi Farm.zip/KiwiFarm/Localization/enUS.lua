
local L = LibStub('AceLocale-3.0'):NewLocale('KiwiFarm', 'enUS', true, true)
if not L then return end

