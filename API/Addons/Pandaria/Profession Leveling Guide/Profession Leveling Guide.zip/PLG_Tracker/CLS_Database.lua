--------------------------------------------------------------------
-- Profession Leveling Guide Reagent Tracker - Database
--------------------------------------------------------------------
local _, Addon = ...
local Database = Addon:NewModule("Database")

---------------------------
-- check bags for items
---------------------------
function Database:getItemCount(name)
	PLG:Debug("Function","Database:getItemCount("..name..")")
	local quantity = 0
	for bag = 0, 4 do
		for slot = 1, GetContainerNumSlots(bag) do
			if GetContainerItemID(bag, slot) then
				local n, _ = GetItemInfo(GetContainerItemID(bag, slot))
				if name == n then
					quantity = quantity + select(2,GetContainerItemInfo(bag, slot));
				end
			end
		end
	end
	return quantity
end

---------------------------
-- update all have item counts (call from bag_update)
---------------------------
function Database:Update(event)
	if not Addon.updating then
		PLG:Debug("Function","Database:Update")
		Addon.updating = true
		--print(tostring(event))
		for profession, objective in pairs(Addon.DB) do
			for key, value in pairs(objective) do
				local have, need = unpack(value)
				have = self:getItemCount(key)
				Addon.DB[profession][key] = { have, need }
			end
		end	
		WatchFrame_Update()
		self:Save()
		Addon.updating = nil
	end
end

---------------------------
-- add an objective
---------------------------
function Database:Add(key,item,need)
	PLG:Debug("Function","Database:Add("..key..","..item..","..need..")")
	if key ~= "UNKNOWN" then
		if not Addon.DB[key] then Addon.DB[key] = {} end --create key
		Addon.DB[key][item] = { self:getItemCount(item), need }
	end
end

---------------------------
-- remove a profession
---------------------------
function Database:Delete(key)
	PLG:Debug("Function","Database:Delete("..key..")")
	Addon.DB[key] = nil
	self:Update()
end

---------------------------
-- wipe db
---------------------------
function Database:Clear()
	PLG:Debug("Function","Database:Clear")
	wipe(Addon.DB)
	self:Update()
end

---------------------------
-- Create initial data
---------------------------
function Database:Create()
	PLG:Debug("Function","Database:Create")
	if #PLG.Professions == 0 then PLG.Professions = { GetProfessions() } end
	for i=1, #PLG.Professions do		
		if PLG.Professions[i] ~= nil then
			local pName, _, earned, total, _, _, skillLine, _ = GetProfessionInfo(PLG.Professions[i])
			Addon.DB[pName] = {}
		end
	end
	self.Save()
end

---------------------------
-- load data
---------------------------
function Database:Load()
	PLG:Debug("Function","Database:Load")
	Addon.DB = PLGT_DB; 
	self:Update()
end

---------------------------
-- save data
---------------------------
function Database:Save()
	PLG:Debug("Function","Database:Save")
	PLGT_DB = Addon.DB
end