--------------------------------------------------------------------
-- Profession Leveling Guide Reagent Tracker - Interface
--------------------------------------------------------------------
local _, Addon = ...
local Interface = Addon:NewModule("Interface")
local Database = Addon.Database
local Tracker = Addon.Tracker

---------------------------
-- Initialize class
---------------------------
function Interface:init()
	PLG:Debug("Function","Interface:init")
	self:createCheckbox()
	self:createButton()
end

---------------------------
-- get reagents to add to database
---------------------------
function Interface:getReagents()
	PLG:Debug("Function","Interface:getReagents")
	local profession, _ = GetTradeSkillLine()
	local hasItems = false
	-- delete objectives for profession
	Addon.DB[profession] = nil 
	-- iterate reagent icons
	for i=1,8 do
		if ( _G["PLG_Reagent"..i.."_Frame"]:IsShown() ) then
			local item = _G["PLG_Reagent"..i.."_Text"]:GetText()
			if _G["PLG_Reagent"..i.."_Count"]:GetText() then
				local ARR = { strsplit("/", _G["PLG_Reagent"..i.."_Count"]:GetText()) }
				Database:Add(profession,item,tonumber(ARR[2]))	
				hasItems = true
			end
		end
	end
	-- no reagents
	if not hasItems then
		if _G["PLG_Instructions_Text"]:GetText() == PLG.msgs.ERR_LEARN then
			Database:Add(profession,"See your trainer",0)
		end
		if _G["PLG_Instructions_Text"]:GetText() == PLG.msgs.ERR_LEARNVEND then
			local name = "a vendor"
			local sID, keep, npcID, questID, sTotal, pEarned, pTotal = unpack(PLG:getData())			
			if questID then -- quest tooltip			
				local quest1, NPC1, npc1h, npc1a, _ = unpack(PLG.Vendors[2][questID]) -- get quest data
				if not NPC1 then NPC1 = PLG:getCondition(PLG.pFaction == "Horde", npc1h, npc1a) end -- get NPC1 ID
				name, _, location, _ = unpack(PLG.Vendors[1][NPC1])
			elseif npcID then -- vendor tooltip
				name, _, location, _ = unpack(PLG.Vendors[1][npcID])
			end
			if location then
				name = name.." in "..GetMapNameByID(location)
			end
			Database:Add(profession,"Find "..name,0)
		end
	end
end

---------------------------
-- create the checkbox on PLG to work with watchframe dropdown
---------------------------
function Interface:createCheckbox()
	self["Tracking"] = CreateFrame("CheckButton", "PLG_Tracking", PLG.backframe, "InterfaceOptionsCheckButtonTemplate")
	self["Tracking"]:SetPoint("BOTTOMLEFT", PLG.backframe, "BOTTOMLEFT", 8, 1)
	_G["PLG_TrackingText"]:SetText(PLG.colors.YELLOW..PLG.labels.TRACKING)		
	self["Tracking"]:SetScript("OnMouseDown", function()
		Tracker:Toggle(true)
	end)
	self["Tracking"]:SetScript("OnEnter", function()
		SetCursor("CAST_CURSOR")
		self:showGameTooltip("PLG_Tracking", PLG.tooltips.TRACKING)
	end)
	self["Tracking"]:SetScript("OnLeave", function()
		SetCursor("POINT_CURSOR")
		GameTooltip:Hide() 
	end)
end


---------------------------
-- create the checkbox on PLG to work with watchframe dropdown
---------------------------
function Interface:createButton()
	self["ClearTracking"] = CreateFrame("BUTTON", "PLG_ClearTracking", PLG.backframe, "UIPanelButtonTemplate")
	self["ClearTracking"]:SetPoint("BOTTOMRIGHT", PLG.backframe, "BOTTOMRIGHT", -5, 5)
	self["ClearTracking"]:SetText(PLG.colors.YELLOW..PLG.labels.CLRTRACKING)		
	self["ClearTracking"]:SetWidth(self["ClearTracking"]:GetTextWidth()+24)		
	self["ClearTracking"]:SetHeight(22)
	self["ClearTracking"]:SetScript("OnClick", function()
		Database:Clear()
	end)
	self["ClearTracking"]:SetScript("OnEnter", function()
		SetCursor("CAST_CURSOR")
		self:showGameTooltip("PLG_Tracking", PLG.tooltips.CLRTRACKING)
	end)
	self["ClearTracking"]:SetScript("OnLeave", function()
		SetCursor("POINT_CURSOR")
		GameTooltip:Hide() 
	end)
end

---------------------------
-- show simple tooltip
---------------------------
function Interface:showGameTooltip(owner, text)
	PLG:Debug("Function","Interface:showGameTooltip")
	GameTooltip:ClearLines()
	GameTooltip:SetOwner(_G[owner], "ANCHOR_TOPLEFT");
	GameTooltip:AddLine(text)			
	GameTooltip:Show(); 	
end

