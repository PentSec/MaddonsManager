--------------------------------------------------------------------
-- Profession Leveling Guide Reagent Tracker - WatchFrame Class
--------------------------------------------------------------------
local _, Addon = ...
local Tracker = Addon:NewModule("Tracker")


---------------------------
-- initialize class
---------------------------
function Tracker:init()
	PLG:Debug("Function","Tracker:init")
	self.OL = {};
	self.CPO = 8;
	self.OLI = 1;
	self.DASH_NONE = 0;
	self.DASH_SHOW = 1;
	self.DASH_HIDE = 2;
	self.DASH_ICON = 3;
	self.IS_HEADER = true;
	self.hideTracker = false;	
	self:HOOK()
end

---------------------------
-- Hook WatchFrame Options Dropdown
---------------------------
function Tracker:HOOK()
	PLG:Debug("Function","Tracker:HOOK")
	hooksecurefunc(WatchFrameHeaderDropDown, "initialize", function()
		self:setOptions()
	end)
	WatchFrame_AddObjectiveHandler(function(...) return self:DISPLAY(...) end);
end

---------------------------
-- get or create a line
---------------------------
function Tracker:GET ()
	PLG:Debug("Function","Tracker:GET")
    local line = self.OL[self.OLI];
    if ( not line ) then
        self.OL[self.OLI] = WatchFrame.lineCache:GetFrame();
        line = self.OL[self.OLI];
    end 
    line:Reset();
    self.OLI = self.OLI + 1;
    return line;
end
 
---------------------------
-- reset line index
---------------------------
function Tracker:RESET ()
	PLG:Debug("Function","Tracker:RESET")
    self.OLI = 1;
end

---------------------------
-- remove unused lines
---------------------------
function Tracker:RELEASE ()
	PLG:Debug("Function","Tracker:RELEASE")
    local line
    for i = self.OLI, #self.OL do
        line = self.OL[i];
        line:Hide();
        line.frameCache:ReleaseFrame(line);
        self.OL[i] = nil;
    end
end

---------------------------
-- display the objective
---------------------------
function Tracker:SETO(title, previousLine, lineFrame, nextAnchor) 
	PLG:Debug("Function","Tracker:SETO("..title..")")  
	-- get the line
	local line = self:GET();
	-- set the line in watchframe
	WatchFrame_SetLine(line, previousLine, -WATCHFRAME_QUEST_OFFSET, self.IS_HEADER, title, self.DASH_NONE);
	-- first line, set points
	if ( not previousLine ) then
		line:SetPoint("RIGHT", lineFrame, "RIGHT", 0, 0);
		line:SetPoint("LEFT", lineFrame, "LEFT", 0, 0);
		if (nextAnchor) then
			line:SetPoint("TOP", nextAnchor, "BOTTOM", 0, -WATCHFRAME_TYPE_OFFSET);
		else
			line:SetPoint("TOP", lineFrame, "TOP", 0, -WATCHFRAME_INITIAL_OFFSET);
		end
	end
	-- line color
	line.text:SetTextColor(1,1,0);
	-- show it
	line:Show();
	return line
end

---------------------------
-- display the criteria
---------------------------
function Tracker:SETC(data, previousLine) 
	PLG:Debug("Function","Tracker:SETC")
    local numCriteria, criteriaDisplayed = 0, 0;
	
	-- for each criteria
	for k,v in pairs(data) do
		numCriteria = numCriteria + 1
		local quantity, totalQuantity = unpack(v)		
		local dash = self.DASH_SHOW;
		local criteriaString, criteriaCompleted; 
		
		-- have some, equal to or more than needed, complete this objective
		if quantity and quantity >= totalQuantity then criteriaCompleted = true end
		-- need = 0, new recipe, go to trainer.
		if totalQuantity == 0 then
			criteriaString = k;
			dash = self.DASH_SHOW;		
		-- completed or more criteria than allowed - do not display
		elseif ( criteriaCompleted or ( criteriaDisplayed > self.CPO and not criteriaCompleted ) ) then
			criteriaString = nil;
			dash = DASH_NONE;
		-- reached the max criteria with more to go - display elipse
		elseif ( criteriaDisplayed == self.CPO and numCriteria > (self.CPO + 1) ) then
			criteriaString = "...";
			dash = self.DASH_HIDE;
		-- show criteria
		else
			criteriaString = quantity.."/"..totalQuantity.." "..k;
			dash = self.DASH_SHOW;
		end
		-- set up the line
		if ( criteriaString ) then
			local line = self:GET();
			WatchFrame_SetLine(line, previousLine, WATCHFRAMELINES_FONTSPACING, not self.IS_HEADER, criteriaString, dash);
			previousLine = line;
			criteriaDisplayed = criteriaDisplayed + 1;	
			-- line color
			line.text:SetTextColor(1,1,1);
			-- show it
			line:Show();
		end
	end
	-- have all the mats
	if numCriteria > 0 and criteriaDisplayed == 0 then	
		local line = self:GET();
		local criteriaString = "Make recipes";	
		local dash = self.DASH_SHOW;
		WatchFrame_SetLine(line, previousLine, WATCHFRAMELINES_FONTSPACING, not self.IS_HEADER, criteriaString, dash);
		previousLine = line;
		criteriaDisplayed = criteriaDisplayed + 1;	
		-- line color
		line.text:SetTextColor(1,1,1);
		-- show it
		line:Show();
	end
	return criteriaDisplayed, previousLine
end

---------------------------
-- display line frames
---------------------------
function Tracker:DISPLAY (lineFrame, nextAnchor, maxHeight, frameWidth, ...)
	PLG:Debug("Function","Tracker:DISPLAY")
    local _;
    local line, previousLine, numTrackedObjectives, criteriaDisplayed = nil, nil, 0, 0;   
	-- reset count
	self:RESET(); 
	
	-- if toggle on
	if ( not self.hideTracker ) then
		-- number of objectives to return
		numTrackedObjectives = #Addon.DB
		-- for each objective
		for k,v in pairs(Addon.DB) do	
			-- create the objective
			origPreviousLine = previousLine
			line = self:SETO(k, previousLine, lineFrame, nextAnchor)  
			criteriaDisplayed, previousLine = self:SETC(v, line) 			
			-- no criteria, hide objective
			if criteriaDisplayed == 0 then
				line:Hide()
				previousLine = origPreviousLine
			end		
		end
	end
 
	self:RELEASE();
    return previousLine or nextAnchor, 0, numTrackedObjectives, 0;
end

---------------------------
-- WatchFrame Options Dropdown Button
---------------------------
function Tracker:setOptions()
	PLG:Debug("Function","Tracker:setOptions")
	UIDropDownMenu_AddButton {
		text = PLG.labels.REAGENTS,
		checked = not self.hideTracker,
		func = function() self:Toggle() end,
		isNotRadio = true
	}
end

---------------------------
-- Show/Hide Objectives
---------------------------
function Tracker:Toggle(fromCB)
	PLG:Debug("Function","Tracker:Toggle")
	self.hideTracker = not self.hideTracker
	if self.hideTracker then
		self:RELEASE();
		self:RESET();
	end
	WatchFrame_Update()
	PLG_Local.hideTracker = self.hideTracker
	if not fromCB then
		Addon.Interface.Tracking:SetChecked(not self.hideTracker)	
	end
end

---------------------------
-- load visible state
---------------------------
function Tracker:Load()
	PLG:Debug("Function","Tracker:Load")
	self.hideTracker = PLG_Local.hideTracker
	Addon.Interface.Tracking:SetChecked(not self.hideTracker)
end
