local ADDON, Addon = ... -- PLG_Tracker, {}

---------------------------
-- Addon global DB
---------------------------
Addon.DB = {}
Addon.loaded = nil
Addon.updating = nil

---------------------------
-- Associate a local module with addon
---------------------------
function Addon:NewModule(name)
	self[name] = {}
	return self[name]
end

---------------------------
-- debug db
---------------------------
function Addon:PrintData()
	for profession, objective in pairs(Addon.DB) do
		print("|cff00ffff"..profession.."|r = {")
		for key, value in pairs(objective) do
			local have, need = unpack(value)
			print("  [|cffff7700"..key.."|r] = {")
			print("    have = |cfffff000"..have.."|r,")
			print("    need = |cfffff000"..need.."|r,")
			print("  }")
		end
		print("}")
	end
end

---------------------------
-- create a global
---------------------------
_G[ADDON] = Addon