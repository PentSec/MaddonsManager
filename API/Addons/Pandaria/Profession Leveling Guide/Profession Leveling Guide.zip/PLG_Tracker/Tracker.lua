--------------------------------------------------------------------
-- Profession Leveling Guide Reagent Tracker - Core
--------------------------------------------------------------------
local _, Addon = ...
local Tracker = Addon.Tracker
local Database = Addon.Database
local Interface = Addon.Interface

---------------------------
-- Interface startup
---------------------------
function Addon:initialize()
	PLG:Debug("Function","Addon:initialize")
	
	-- create checkbox
	Interface:init()
	
	-- hook to watch frame
	Tracker:init()	
	
	-- hook into PLG update to change need
	--hooksecurefunc(PLG,"TRADE_SKILL_SHOW",function() Interface:getReagents(); Database:Update() end)
	hooksecurefunc(PLG,"TRADE_SKILL_UPDATE",function() Interface:getReagents(); Database:Update() end)
	
	-- create event handler frame
	self.EventFrame = CreateFrame("Frame")
		
	-- hook events to frame
	self.EventFrame:RegisterEvent("ADDON_LOADED")
	self.EventFrame:RegisterEvent("BAG_UPDATE")	
		
	-- onevent
	self.EventFrame:SetScript("OnEvent", function(self, event, arg1, arg2, arg3, arg4)
		-- addon first load, set variable
		if event=="ADDON_LOADED" and arg1 == "PLG_Tracker" then		
			--load the DB
			if PLGT_DB then
				Database:Load()
			else
				Database:Create()
			end
			
			-- load the options and watch frame state
			if PLG_Local then
				Tracker:Load()
			else
				PLG_Local = {}
				PLG_Local.hideTracker = false
				Tracker:Load()
			end		
			Addon.loaded = true		
		elseif Addon.loaded and event=="BAG_UPDATE" then
			if not InCombatLockdown() then	
				Database:Update(event)
			end	
		end
	end)
	
end

-- run if no carbonite
if not IsAddOnLoaded("Carbonite.Quests") then
	Addon:initialize()
end


