
local _,L = ...
local rematch = Rematch

function rematch:InitCurrent()
	rematch.header.text:SetText(L["Current Battle Pets"])

	for i=1,3 do
		rematch.current.pets[i].menu = "current"
		if rematch.WoDBuild then
			rematch.current.pets[i].shine:SetDrawEdge(false)
			rematch.current.pets[i].shine:SetDrawSwipe(false)
		end
	end

	-- there's no event for when loadout pets change (really!) so we hooksecurefunc them
	hooksecurefunc(C_PetJournal,"SetAbility",rematch.StartPetsChanging)
	hooksecurefunc(C_PetJournal,"SetPetLoadOutInfo",rematch.StartPetsChanging)

	rematch.current.levelingNavigator.prev.icon:SetTexture("Interface\\Icons\\misc_arrowleft")
	rematch.current.levelingNavigator.next.icon:SetTexture("Interface\\Icons\\misc_arrowright")
end

function rematch:CurrentPetOnReceiveDrag()
	local petID = rematch:GetCursorPetID()
	if petID then
		if rematch:IsCurrentLevelingPet(self.petID) and rematch:PetCanLevel(petID) then
			rematch:StartLevelingPet(petID) -- if a pet that can level is being dropped on current leveling pet
		else
			rematch:LoadPetSlot(self:GetID(),petID)
		end
		ClearCursor()
	end
end

function rematch:CurrentPetOnEnter()
	rematch:ShowFloatingPetCard(rematch:GetPetID(self.petID),self)
	if rematch:IsCurrentLevelingPet(self.petID) and #RematchSettings.LevelingQueue>1 then
		local nav = rematch.current.levelingNavigator
		nav.timer = 0
		nav:SetParent(self)
		nav:SetPoint("TOP",self,"BOTTOM",0,3)
		nav:SetFrameLevel(self:GetFrameLevel()+3)
		nav:Show()
	end
end

function rematch:UpdateCurrentPets()

	rematch:WipePetFrames(rematch.current.pets)

	if select(2,C_PetJournal.GetNumPets())==0 then
		-- if pets not loaded, come back in half a second to try again
		rematch:StartTimer("PetsRanAway",0.5,rematch.UpdateCurrentPets)
		return
	end

	local ability = rematch.info
	local petID

	for i=1,3 do
		local button = rematch.current.pets[i]
		petID, ability[1],ability[2],ability[3] = C_PetJournal.GetPetLoadOutInfo(i)
		if petID then
			button.petID = petID
			local speciesID,_,level,xp,xpmax,_,_,_,icon = C_PetJournal.GetPetInfoByPetID(petID)
			-- update this pet's icon
		  button.icon:SetTexture(icon)
			button.icon:Show()
			-- update this pet's abilities
			for j=1,3 do
				button.abilities[j].abilityID = ability[j]
				button.abilities[j].icon:SetTexture((select(2,C_PetJournal.GetPetAbilityInfo(ability[j]))))
				button.abilities[j].icon:Show()
				-- confirm pet is high enough to have this ability
				local canUseAbility,abilityLevel
				wipe(rematch.abilityList)
				C_PetJournal.GetPetAbilityList(speciesID,rematch.abilityList,rematch.levelList)
				for k=1,#rematch.abilityList do
					if ability[j]==rematch.abilityList[k] then
						abilityLevel = rematch.levelList[k]
						if level>=abilityLevel then
							-- they have this ability and they're high enough to use it
							canUseAbility = true
						end
						break
					end
				end
				if canUseAbility then
					button.abilities[j].icon:SetVertexColor(1,1,1)
					button.abilities[j].icon:SetDesaturated(false)
					button.abilities[j].level:Hide()
				else
					button.abilities[j].icon:SetVertexColor(.3,.3,.3)
					button.abilities[j].icon:SetDesaturated(true)
					button.abilities[j].level:SetText(abilityLevel)
					button.abilities[j].level:Show()
				end
				button.abilities[j].canUse = canUseAbility
			end
			-- xp bar: update+show xp bar if pet is less than 25, hide if pet is 25
			local notMax = level<25
			if notMax then
				button.healthBG:SetPoint("TOPLEFT",button,"BOTTOMLEFT",2,0)
				button.xp:SetWidth(xp>0 and 38*(xp/xpmax) or 1)
				button.level.text:SetText(level)
			else
				button.healthBG:SetPoint("TOPLEFT",button,"BOTTOMLEFT",2,-4)
			end
			button.xpBG:SetShown(notMax)
			button.xp:SetShown(notMax)
			button.level:SetShown(notMax)
			-- update hp and whether pet is dead
			local hp,hpmax = C_PetJournal.GetPetStats(petID)
			if hp>0 then
				button.health:SetWidth(hp>0 and 38*(hp/hpmax) or 1)
			end
			button.dead:SetShown(hp==0)
			button.healthBG:Show()
			button.health:SetShown(hp>0)
		else
			button.petID = rematch.emptyPetID
			button.xpBG:Hide()
			button.xp:Hide()
			button.level:Hide()
			button.healthBG:Hide()
			button.health:Hide()
		end
	end
	rematch:UpdateCurrentLevelingBorders()
end

function rematch:UpdateCurrentLevelingBorders()
	local levelingPetID = rematch:GetCurrentLevelingPet()
	for i=1,3 do
		local petID = C_PetJournal.GetPetLoadOutInfo(i)
		rematch.current.pets[i].leveling:SetShown(petID and petID==levelingPetID)
	end
end

-- called from a hooksecurefunc of SetAbility and SetPetLoadOutInfo. update 0.1 seconds
-- after they begin to allow multiple simultaneous changes to happen before doing an update
function rematch:StartPetsChanging()
	if not rematch.loadInProgress then -- and rematch:IsVisible()
		rematch:StartTimer("PetsChanging",0.1,rematch.FinishPetsChanging)
	end
end

-- runs 0.1 seconds after pets/abilities change, primarily calls an UpdateWindow
-- but also does extra processing if AutoAlways enabled to see if any pets really changed
function rematch:FinishPetsChanging()
	local settings = RematchSettings
	if settings.AutoAlways and type(settings.loadedTeamTable)=="table" then
		local info = rematch.info
		for i=1,3 do
			info[1],info[2],info[3],info[4] = C_PetJournal.GetPetLoadOutInfo(i)
			for j=1,4 do
				local id = settings.loadedTeamTable[i][j] -- can be petID or abilityID
				if id and info[j]~=id then
					settings.loadedTeamName = nil -- something legitimately changed, "forget" team currently loaded
					settings.loadedNpcID = nil
				end
			end
		end
	end
	if rematch:IsVisible() then
		rematch:UpdateWindow()
	end
end

function rematch:CurrentAbilityOnEnter()
	if self.abilityID and self.arrow then
		self.arrow:Show()
	end
	rematch.ShowAbilityCard(self,self:GetParent().petID,self.abilityID)
end

function rematch:CurrentAbilityOnLeave()
	if self.arrow then
		self.arrow:Hide()
	end
	rematch:HideAbilityCard()
end

function rematch:CurrentAbilityOnClick()
	local flyout = RematchAbilityFlyout
	local petSlot = self:GetParent():GetID()
	local abilitySlot = self:GetID()
	if IsModifiedClick("CHATLINK") then
		rematch:ChatLinkAbility(self:GetParent().petID,self.abilityID)
	elseif flyout.petSlot==petSlot and flyout.abilitySlot==abilitySlot then
		flyout:Hide()
		self.arrow:Show()
	else
		local petID = self:GetParent().petID
		if petID and petID~=rematch.emptyPetID then
			self.arrow:Hide()
			flyout.petSlot = petSlot
			flyout.abilitySlot = abilitySlot
			flyout:SetParent(self)
			flyout:SetPoint("RIGHT",self,"LEFT")
			flyout.petID = petID
			rematch:FillFlyout(petSlot,abilitySlot)
			flyout.timer = 0
			flyout:Show()
		end
	end
end

function rematch:FlyoutOnHide()
	self.petSlot = nil
	self.abilitySlot = nil
end

function rematch:FlyoutButtonOnClick()
	if IsModifiedClick("CHATLINK") then
		rematch:ChatLinkAbility(self:GetParent().petID,self.abilityID)
	elseif self.canUse then
		local parent = self:GetParent()
		C_PetJournal.SetAbility(parent.petSlot,parent.abilitySlot,self.abilityID)
		parent:Hide()
		if PetJournal then
			PetJournal_UpdatePetLoadOut() -- update petjournal if it's open
		end
	end
end

function rematch:FlyoutOnUpdate(elapsed)
	self.timer = self.timer + elapsed
	if self.timer > 0.75 then
		self:Hide()
	elseif MouseIsOver(self) or MouseIsOver(self:GetParent()) then
		self.timer = 0
	end
end

function rematch:FillFlyout(petSlot,abilitySlot)
	local flyout = RematchAbilityFlyout
	local petID = C_PetJournal.GetPetLoadOutInfo(petSlot)
	local speciesID,_,level = C_PetJournal.GetPetInfoByPetID(petID)
	C_PetJournal.GetPetAbilityList(speciesID,rematch.abilityList,rematch.levelList)

	for i=1,2 do
		local button = flyout.ability[i]
		local listIndex = (i-1)*3+abilitySlot
		local abilityID = rematch.abilityList[listIndex]

		local _,icon = C_PetJournal.GetPetAbilityInfo(abilityID)
		button.abilityID = rematch.abilityList[listIndex]
		button.icon:SetTexture(icon)
		if level>=rematch.levelList[listIndex] then
			button.level:Hide()
			button.icon:SetVertexColor(1,1,1)
			button.icon:SetDesaturated(false)
			button.canUse = true
		else
			button.level:SetText(rematch.levelList[listIndex])
			button.level:Show()
			button.icon:SetVertexColor(.3,.3,.3)
			button.icon:SetDesaturated(true)
			button.canUse = nil
		end
	end
end

function rematch:LevelingNavigatorOnUpdate(elapsed)
	if MouseIsOver(self) or MouseIsOver(self:GetParent()) then
		self.timer = 0
	else
		self.timer = self.timer + elapsed
		if self.timer > 0.3 then
			self:Hide()
		end
	end
end
