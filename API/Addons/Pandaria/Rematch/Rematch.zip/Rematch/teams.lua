--[[ teams are saved in RematchSaved (saved local) in this format:

	["team name"] = {
		{petID,abilityID,abilityID,abilityID,speciesID}, -- petID can be a speciesID (number) if missing
		{petID,abilityID,abilityID,abilityID,speciesID},
		{petID,abilityID,abilityID,abilityID,speciesID},
		npcID, -- nil or number
		tab, -- nil or tab number (1-8)
		minLevel, -- nil or minimum leveling pet level
		maxLevel, -- nil or maximum leveling pet level
		notes, -- nil or string max 255 characters
	}

	petID of 0 notes a leveling pet.
]]

local _,L = ...
local rematch = Rematch
local settings
local teams = rematch.drawer.teams
local saved

teams.teamList = {} -- numerically indexed list of team names to list
teams.searchTabsFound = {} -- indexed by tab number, where search results are found

function rematch:InitTeams()
	settings = RematchSettings
	if not settings.TeamGroups or #settings.TeamGroups==0 then
		settings.TeamGroups = {{GENERAL,"Interface\\Icons\\PetJournalPortrait"}}
	end
	saved = RematchSaved
	saved["~temp~"] = nil
	settings.SelectedTab = settings.SelectedTab or 1
	for i=1,8 do
		teams.tabScrollFrame.tabChildFrame.tabs[i]:RegisterForClicks("AnyUp")
	end
	rematch:UpdateTeamTabs()

	-- setup teams list scrollFrame
	local scrollFrame = teams.list.scrollFrame
	scrollFrame.update = rematch.UpdateTeamList
	HybridScrollFrame_CreateButtons(scrollFrame, "RematchTeamListButtonTemplate")

	RematchTeamCard:SetFrameLevel(4)
	RematchTeamCard.lockFrame:SetFrameLevel(1)

	teams.import.icon:SetTexture("Interface\\Icons\\INV_Inscription_RunescrollOfFortitude_Blue")
	teams.import.tooltipTitle = L["Import"]

end

function rematch:UpdateTeams()
	rematch:PopulateTeamList()
	rematch:UpdateTeamTabs()
	rematch:UpdateTeamList()
end

function rematch:UpdateTeamTabs()
	local groups = settings.TeamGroups
	if not groups[settings.SelectedTab] then
		settings.SelectedTab = 1
	end
	local searching = teams.searchText and true
	local numGroups = #groups
	for i=1,8 do
		local tab = teams.tabScrollFrame.tabChildFrame.tabs[i]
		tab:SetShown(i<=(numGroups+1))
		tab:SetChecked(i==settings.SelectedTab and not searching)
		if i==(numGroups+1) then
			tab.icon:SetTexture("Interface\\AddOns\\Rematch\\textures\\newteam")
			tab.name = nil
		elseif i<=numGroups then
			tab.icon:SetTexture(groups[i][2])
			tab.name = groups[i][1]
			if searching then -- dim tabs that are not part of search results
				local tabFound = teams.searchTabsFound[i]
				tab.icon:SetDesaturated(not tabFound)
				tab.icon:SetVertexColor(tabFound and 1 or .5, tabFound and 1 or .5, tabFound and 1 or .5)
			else -- or light them all up if not searching
				tab.icon:SetDesaturated(false)
				tab.icon:SetVertexColor(1,1,1)
			end
		end
	end
end

function rematch:TeamTabButtonOnClick(button)
	rematch:HideDialogs()
	self:SetChecked(0)
	rematch:ClearSearchBox(teams.searchBox)
	local index = self:GetID()
	if not self.name then
		if button~="RightButton" then
			rematch:ShowTeamTabEditDialog(index,L["New Tab"],"Interface\\Icons\\INV_Misc_QuestionMark")
		end
	else
		if index~=1 or button~="RightButton" then
			rematch:SelectTeamTab(index)
		end
		if button=="RightButton" then
			if index~=1 then
				rematch:SetMenuSubject(index)
				rematch:ShowMenu("teamTab","cursor")
			else
				rematch:UpdateTeamTabs()
			end
		end
	end
end

function rematch:TeamTabButtonOnMouseDown(button)
	local index = self:GetID()
	if button~="RightButton" or (index>1 and index<=#settings.TeamGroups) then
		self.icon:SetSize(28,28)
	end
end

function rematch:TeamTabButtonOnEnter()
	local index = self:GetID()
	if settings.TeamGroups[index] then
		rematch:ShowTooltip(settings.TeamGroups[index][1])
	else
		rematch:ShowTooltip(L["New Tab"],L["Create a new tab."])
	end
end

function rematch:SelectTeamTab(index)
	local scrollToTop = settings.SelectedTab ~= index
	settings.SelectedTab = index
	rematch:UpdateTeams()
	if scrollToTop then
		rematch:ListScrollToTop(teams.list.scrollFrame)
	end
end

--[[ Dialogs for tabs ]]

-- hybridscrollframe update for icon list in tab edit dialog
function rematch:UpdateTeamTabEditIconList()
	local data = teams.iconChoices
	local numData = ceil(#data/6)
	local scrollFrame = rematch.dialog.iconPicker.scrollFrame
	local offset = HybridScrollFrame_GetOffset(scrollFrame)
	local buttons = scrollFrame.buttons
	local selectedIcon = rematch.dialog.slot.icon:GetTexture()
	for i=1,#buttons do
		local index = i + offset
		local button = buttons[i]
		if ( index <= numData) then
			for j=1,6 do
				local subbutton = button.icons[j]
				local iconFilename = data[(index-1)*6+j]
				if iconFilename then
					if type(iconFilename)=="number" then
						subbutton.icon:SetToFileData(iconFilename)
					else
						subbutton.icon:SetTexture("INTERFACE\\ICONS\\"..iconFilename)
					end
					subbutton.selected:SetShown(subbutton.icon:GetTexture()==selectedIcon)
					subbutton:Show()
				else
					subbutton:Hide()
				end
			end
			button:Show()
		else
			button:Hide()
		end
	end

	HybridScrollFrame_Update(scrollFrame,32*numData,32)
end

-- shows tab edit dialog
function rematch:ShowTeamTabEditDialog(index,name,icon)

	if rematch:IsDialogOpen("EditTab") and rematch.dialog.index==index then
		rematch:HideDialogs()
		return
	end

	local dialog = rematch:ShowDialog("EditTab",278,name,L["Choose a name and icon."],rematch.TeamTabEditDialogAccept)
	dialog.index = index

	dialog.slot:SetPoint("TOPLEFT",16,-20)
	dialog.slot.icon:SetTexture(icon)
	dialog.slot:Show()

	dialog.editBox:SetPoint("LEFT",dialog.slot,"RIGHT",10,0)
	dialog.editBox:SetText(name)
	dialog.editBox:SetScript("OnTextChanged",rematch.DialogEditBoxOnTextChanged)
	dialog.editBox:Show()

	if not dialog.iconPicker then
		dialog.iconPicker = CreateFrame("Frame","RematchTeamTabIconList",dialog,"RematchListTemplate")
		rematch:RegisterDialogWidget("iconPicker")
		dialog.iconPicker:SetSize(226,168)
		local scrollFrame = dialog.iconPicker.scrollFrame
		scrollFrame:SetHeight(168) -- 5 buttons*32 buttonHeight
		scrollFrame.update = rematch.UpdateTeamTabEditIconList
		HybridScrollFrame_CreateButtons(scrollFrame, "RematchTabIconPickerTemplate")
	end

	dialog.iconPicker:SetPoint("TOP",0,-64)
	dialog.iconPicker:Show()
	teams.iconChoices = teams.iconChoices or {}
	wipe(teams.iconChoices)
	GetMacroIcons(teams.iconChoices)

	rematch:UpdateTeamTabEditIconList()
end

-- when user clicks accept button
function rematch:TeamTabEditDialogAccept()
	local index = rematch.dialog.index
	settings.TeamGroups[index] = {rematch.dialog.editBox:GetText(),rematch.dialog.slot.icon:GetTexture()}
	rematch:SelectTeamTab(index)
	rematch:HideDialogs()
end

-- when an icon in iconpicker clicked
function rematch:TeamTabIconPickerOnClick()
	local texture = self.icon:GetTexture()
	rematch.dialog.slot.icon:SetTexture(texture)
	rematch:UpdateTeamTabEditIconList()
end

function rematch:ShowTeamTabDeleteDialog(index,name,icon)
	local dialog = rematch:ShowDialog("DeleteTab",120,name,L["Delete this tab?"],rematch.DeleteTeamTab)
	dialog.slot:SetPoint("TOPLEFT",12,-24)
	dialog.slot.icon:SetTexture(icon)
	dialog.slot:Show()
	dialog.text:SetSize(180,70)
	dialog.text:SetPoint("LEFT",dialog.slot,"RIGHT",4,0)
	dialog.text:SetText(L["Teams in this tab will be moved to the General tab."])
	dialog.text:Show()
	dialog.index = index
end

function rematch:DeleteTeamTab(index)
	if type(index)~="number" then
		index = rematch.dialog.index
	end
	if not index or index<2 or index>#settings.TeamGroups then
		return
	end
	tremove(settings.TeamGroups,index) -- remove tab from TeamGroups
	-- now go through teams and adjust group/tab where necessary
	for teamName,teamData in pairs(saved) do
		local teamTab = teamData[5]
		if teamTab==index then -- team is in tab being deleted
			teamData[5] = nil -- remove group from team, so it lists in general
		elseif teamTab and teamTab>index then -- team is in a tab after the one being delete
			teamData[5] = teamData[5]-1 -- decrement group number
		end
	end
	rematch:SelectTeamTab(1)
end

function rematch:SwapTeamTabs(index1,index2)
	for teamName,teamData in pairs(saved) do
		local teamTab = teamData[5]
		if teamTab==index1 then
			teamData[5] = index2
		elseif teamTab==index2 then
			teamData[5] = index1
		end
	end
	local groups = settings.TeamGroups
	local name,icon = groups[index1][1], groups[index1][2]
	groups[index1][1] = groups[index2][1]
	groups[index1][2] = groups[index2][2]
	groups[index2][1] = name
	groups[index2][2] = icon
end

--[[ Team List ]]

-- populates teams.teamList with teamNames in the selected tab
function rematch:PopulateTeamList()
	local list = teams.teamList
	wipe(list)
	if teams.searchText then -- if anything in searchbox, populate from search results
		rematch:PopulateTeamSearchResults()
	else -- otherwise populate with matching tabs
		local selectedTab = settings.SelectedTab
		local numTabs = #settings.TeamGroups
		for teamName,teamData in pairs(saved) do
			local teamTab = teamData[5]
			if teamTab and teamTab>numTabs then
				saved[teamName][5] = nil
				teamTab = nil
			end
			if teamTab and teamTab==selectedTab then
				tinsert(list,teamName)
			elseif not teamTab and selectedTab==1 then
				tinsert(list,teamName)
			end
		end
	end
	table.sort(list,function(e1,e2) return e1:lower()<e2:lower() end)
end

function rematch:UpdateTeamList()
	local data = teams.teamList
	local numData = #data
	local scrollFrame = teams.list.scrollFrame
	local offset = HybridScrollFrame_GetOffset(scrollFrame)
	local buttons = scrollFrame.buttons

	for i=1, #buttons do
		local index = i + offset
		local button = buttons[i]
		if ( index <= numData) then
			local teamName = data[index]
			local teamData = saved[teamName]
			button.name:SetText(teamName)
			button.teamName = teamName
			button.index = index
			if teamName==settings.loadedTeamName then
				button.back:SetGradientAlpha("VERTICAL",.35,.65,1,1, .35,.65,1,0)
			else
				button.back:SetGradientAlpha("VERTICAL",.35,.35,.35,1,.35,.35,.35,0)
			end
			for j=1,3 do
				local petID = teamData[j][1]
				local speciesID = teamData[j][5]
				if petID==0 then
					icon = rematch.levelingIcon
				elseif speciesID or type(petID)=="number" then
					icon = select(2,C_PetJournal.GetPetInfoBySpeciesID(type(petID)=="number" and petID or speciesID))
				else
					icon = "Interface\\Buttons\\UI-PageButton-Background"
				end
				button.pets[j]:SetTexture(icon)
			end
			if teamData[4] then
				button.name:SetTextColor(1,1,1)
			else
				button.name:SetTextColor(1,.82,0)
			end
			button:Show()
		else
			button:Hide()
		end
	end

	HybridScrollFrame_Update(scrollFrame,28*numData,28)
end

function rematch:TeamListOnClick(button)
	if button=="RightButton" then
		rematch:SetMenuSubject(self.teamName)
		rematch:ShowMenu("teamList","cursor")
	elseif settings.OneClickLoad then
		rematch:LoadTeam(self.teamName)
	else
		local card = RematchTeamCard
		rematch:LockTeamCard()
		if self.teamName ~= card.teamName then
			rematch.TeamListOnEnter(self,true)
			rematch:LockTeamCard()
		end
	end
end

function rematch:TeamListOnDoubleClick()
	rematch:LoadTeam(self.teamName)
	RematchTeamCard:Hide()
end

function rematch:TeamListOnEnter(force)
	local card = RematchTeamCard
	if not card.locked or force then
		rematch:SmartAnchor(card,self)
		rematch:FillPetFramesFromTeam(card.pets,self.teamName)
		card.name:SetText(self.teamName)
		SetPortraitToTexture(card.icon,settings.TeamGroups[saved[self.teamName][5] or 1][2])
		card.teamName = self.teamName
		card:Show()
	end
end

function rematch:TeamListOnLeave()
	if not RematchTeamCard.locked then
		RematchTeamCard:Hide()
	end
end

function rematch:LockTeamCard()
	local card = RematchTeamCard
	card.locked = not card.locked
	card.lockFrame:SetShown(card.locked)
end

function rematch:TeamCardOnHide()
	self.locked = nil
	self.lockFrame:Hide()
	rematch:HideFloatingPetCard(true)
end

-- goes through a team and confirms pets are valid petIDs
-- if not, it will convert them to a speciesID and look for an owned pet that's not already on the team
function rematch:ValidateTeam(team)
	if type(team)=="string" then
		team = saved[team]
	end
	if not team then
		return false
	end
	-- first see if there are any duplicate petIDs
	for i=2,3 do
		for j=1,i-1 do
			local petID = team[i][1]
			if petID==team[j][1] and type(petID)=="string" and petID~=rematch.emptyPetID then
				team[i][1] = team[i][5] -- duplicate petID, change to speciesID
			end
		end
	end
	-- now change any invalid petIDs to speciesIDs
	for i=1,3 do
		local petID = team[i][1]
		if type(petID)=="string" and petID~=rematch.emptyPetID then -- if a "real" petID
			if rematch.WoDBuild and not petID:match("BattlePet") then
				team[i][1] = team[i][5]
			elseif C_PetJournal.PetIsRevoked(petID) then
				team[i][1] = team[i][5]
			elseif not C_PetJournal.GetPetInfoByPetID(petID) then
				team[i][1] = team[i][5] -- invalid petID, change to speciesID
			end
		end
	end
	-- now look for any speciesIDs and find the best pet for them
	for i=1,3 do
		local petID = team[i][1]
		if type(petID)=="number" and petID~=0 then -- if petID is a speciesID
			local newPetID = rematch:FindBestPetForTeam(petID,i,team)
			if newPetID then
				team[i][1] = newPetID -- we found a petID! :D
			end
		end
	end
end

-- for team searches and InATeam/NotInATeam filter, we'll be looking through teams
-- that have maybe not been interacted; once a session, go through and validate them all
function rematch:ValidateAllTeams()
	if not rematch.allTeamsValidated then
		for teamName in pairs(saved) do
			rematch:ValidateTeam(teamName)
		end
		rematch.allTeamsValidated = true
	end
end

function rematch:ShowLoadDialog(teamName)
	if not teamName or not saved[teamName] then
		return
	end
	rematch:HideDialogs()

	local dialog = rematch:ShowDialog("LoadTeam",128,teamName,L["Load this team?"])

	dialog.team:SetPoint("TOP",0,-24)
	dialog.team:Show()

	dialog.accept:SetScript("OnClick",function() rematch:LoadTeam(teamName) end)

	rematch:FillPetFramesFromTeam(dialog.team.pets,teamName)
end

-- finds the best pet that doesn't occupy one of the other pet slots
function rematch:FindBestPetForTeam(speciesID,index,teamTable)
	if index==1 then
		return rematch:FindBestPetID(speciesID,teamTable[2][1],teamTable[3][1])
	elseif index==2 then
		return rematch:FindBestPetID(speciesID,teamTable[1][1],teamTable[3][1])
	else
		return rematch:FindBestPetID(speciesID,teamTable[1][1],teamTable[2][1])
	end
end

function rematch:FillPetFramesFromTeam(pets,team)
	if type(team)=="string" then
		team = saved[team]
	end
	if not team then
		return
	end
	rematch:ValidateTeam(team)
	rematch:WipePetFrames(pets)

	for i=1,3 do
		local petID = team[i][1]
		local icon,missing = rematch:GetPetIDIcon(petID)
		if icon then
			pets[i].petID = petID
			pets[i].icon:SetTexture(icon)
			pets[i].icon:Show()
			pets[i].icon:SetDesaturated(missing)
			pets[i].leveling:SetShown(petID==0)
			for j=1,3 do
				local abilityID = team[i][j+1] or 0
				local _,_,icon = C_PetBattles.GetAbilityInfoByID(abilityID)
				if icon then
					pets[i].abilities[j].abilityID = abilityID
					pets[i].abilities[j].icon:SetTexture(icon)
					pets[i].abilities[j].icon:Show()
					pets[i].abilities[j].icon:SetDesaturated(missing)
				end
			end
		end
	end
end

function rematch:ScrollToTeam(teamName)
	for i=1,#teams.teamList do
		if teams.teamList[i]==teamName then
			rematch:ListScrollToIndex(teams.list.scrollFrame,i)
			return
		end
	end
end

function rematch:ShowRenameDialog(teamName)

	local dialog = rematch:ShowDialog("RenameTeam",154,teamName,L["Rename this team?"],rematch.RenameAccept)
	dialog.team:SetPoint("TOP",0,-24)
	dialog.team:Show()
	rematch:FillPetFramesFromTeam(dialog.team.pets,teamName)

	dialog.editBox:SetPoint("TOP",dialog.team,"BOTTOM",0,-8)
	dialog.editBox:SetText(teamName)
	dialog.editBox:SetScript("OnTextChanged",rematch.RenameOnTextChanged)
	dialog.editBox:Show()

	dialog.teamName = teamName
	dialog.npcID = saved[teamName][4]

end

function rematch:RenameOnTextChanged()
	local teamName = self:GetText()
	local dialog = rematch.dialog
	local nameTaken = saved[teamName] and teamName~=dialog.teamName
	rematch:SetAcceptEnabled(teamName:len()>0 and not nameTaken)
	if nameTaken then
		dialog.warning:SetPoint("TOP",dialog.editBox,"BOTTOM",0,-4)
		dialog.warning.text:SetText(L["A team already has this name."])
		dialog.warning:Show()
		dialog:SetHeight(178)
	else
		dialog.warning:Hide()
		dialog:SetHeight(154)
	end
end

function rematch:RenameAccept()
	local dialog = rematch.dialog
	local oldTeamName = dialog.teamName
	local newTeamName = dialog.editBox:GetText()
	rematch:SaveTeamFromPetFrames(newTeamName,dialog.npcID,dialog.team.pets)
	saved[oldTeamName] = nil
	if settings.loadedTeamName==oldTeamName then
		settings.loadedTeamName = newTeamName
	end
	rematch:UpdateWindow()
	rematch:ScrollToTeam(newTeamName)
end

--[[ Search Box ]]

function rematch:TeamSearchBoxOnTextChanged()
	local text = self:GetText()
	if text:len()>0 and text~=SEARCH then
		teams.searchText = rematch:DesensitizedText(text)
	else
		teams.searchText = nil
	end
	rematch:UpdateTeams()
end

-- fills teams.teamList with teams that meet the search criterea
function rematch:PopulateTeamSearchResults()
	local list = teams.teamList
	local search = teams.searchText
	wipe(teams.searchTabsFound)
	rematch:ValidateAllTeams()
	for teamName,teamData in pairs(saved) do
		local teamTab = teamData[5]
		local found
		if teamName:match(search) then -- search is part of team name
			found = true
		else
			local info = rematch.info
			for i=1,3 do -- look for search as part of a pet or ability in the team
				local petID = teamData[i][1]
				if type(petID)=="string" and petID~=rematch.emptyPetID then
					local _,customName,_,_,_,_,_,realName = C_PetJournal.GetPetInfoByPetID(petID)
					if (customName and customName:match(search)) or (realName and realName:match(search)) then
						found = true
						break
					end
				end
			end
		end
		if found then
			tinsert(list,teamName)
			teams.searchTabsFound[teamTab or 1] = true
		end
	end
end

function rematch:ReloadTeam()
	local teamName = settings.loadedTeamName
	if teamName and saved[teamName] then
		rematch:LoadTeam(teamName)
	end
end
