Rematch is an addon to help manage battle pet teams and pets.

Its primary purpose is to store and recall battle pet teams for targets. For instance:

- When you target Aki the Chosen, bring up the Rematch window and hit Save, you can save in her name the pets you have out.
- When you return to Aki another day, you can target her, bring up the window and it will offer you those saved pets to load.

New in 3.0.14

- Fix for error when a team fails to load.

New in 3.0.13

- Fix for unnecessary prompts when leveling pet changes and 'Always show or load' is checked in options.
- If window was up before prompting for a load due to 'Always show or load' in an auto load, it should remain up after the load.
- If 'Always show or load' is not enabled, a new Reload button is added to main window for reloading the current team to its saved pets and abilities.
- Import button moved to top of Teams tab when Reload button is enabled (while 'Always show or load' unchecked).
- 6.0/WoD fix for auto load and targets with saved npcID.
- 6.0/WoD fix for "shine" animation on pets loading and queue operations.

How to Use

You can summon the Rematch window several ways:
- Set a key binding from options.
- /rematch command.
- The Rematch button at the bottom of the pet journal.
- 'Use Minimap Button' in options will create a minimap button.
- From its LDB button if you use a Broker infobar addon.
- Have 'Auto Show' checked in options and target something for which you have a saved team that's not already loaded.

Saving a Team

As mentioned at the top, this addon's primary purpose is to save for targets. Target an NPC, click Save, and you will be prompted to save in their name.

If you choose to keep the target's name for the team, then you'll be offered that team to load when you return to it another day.  Within options you can choose to make Rematch automatically pop up when you return to that target, or you can make the team load immediately without messing around with the addon at all.

When a team is saved with an NPC targeted, or when saving over an existing team that was initially created at the target, the team's name will be white and it will react only to that specific instance of the NPC.

If you manually name a team named after an NPC without it targeted, or you got the team from elsewhere without targeting information saved, its name will be gold and it will react to any copies of that NPC you run across in the world.

You're also free to save without regard for target.  Name your team anything you want and you can return to the teams tab later to load it back from the Teams tab.

Teams

When teams are saved, they're stored in the Teams tab.
- To load a team manually, double click it.
- You can create up to 7 additional tabs in addition to the default General team tab.
- When a team is saved, it will go to the current tab. You can change the current tab while saving at the bottom of the save dialog.
- All team names are unique, even across tabs. If you have "Aki the Chosen" in a tab named "Dailies", and you save "Aki the Chosen" in General, it will move that team to General and save it there.  (But don't worry, if the teams are sufficiently different, it will ask for confirmation first).
- Right-click a tab to change its name or icon, delete it (or re-order tabs if you've created more than one).
- When a tab is deleted, all teams within the tab are moved to the General tab.
- You can right-click a team to do various things as well, such as renaming, deleting or sharing it.
- You can bind a key to open the Teams tab directly.

Pets

The Pets tab contains a pet browser and a leveling queue.

Just about anyplace you see a pet, you can double-click it to summon the pet, or dismiss it if it was already out.

The "tooltip" for pets is a pet card with stats:
- Hold Alt to flip the card over for more about your pet.
- Click the pet to lock the card in place so you can mouseover abilities.
- When the card is locked it has a wooden frame around it. You can unlock it several ways: clicking one of the little screws in a corner, clicking the pet again from where you locked it, hitting ESCape or any other major interaction with the addon.
- You can shift+click pets and abilities to chat.

Some advantages the built-in pet browser has over the default pet journal:
- You can search the names of abilities or text within abilities.
- You can search for level and stat ranges.
- In addition to filtering pets by type, you can filter by 'Strong vs': if you filter Strong vs Dragonkin, it will list all pets with Magic attacks.
- You can also filter to pets that are Tough vs a type of attack: filtering Tough vs Elemental will list all critters.
- A 'Type Bar' to filter by the various types without going through the dropdown menus.
- A counter at the bottom of the browser tells you how many pets are listed: search level=25 and you'll see how many level 25 pets you own.

To clear filters, you can click the little X button in the search box or the type bar, or you can click the X along the bottom when filters are applied.  You can also click 'Reset All' within the filters menu.

Searches

In the search bar of the pet browser, you can not only search for names of pets and their source, but you can also search for:

- Names of abilities ("Call Lightning")
- Text within abilities ("Bleed")
- Level ranges ("level=25" or "level>10" or "level=8-13")
- Stat ranges ("health>700" or "speed=250-350" or "power>=276")

Also:

- Searches are not case sensitive. "Bleed" will work just as well as "bleed" or "BLEED".
- You can hit "Fill" on the leveling queue to add one of each species from your search results to the leveling queue.
- When you look at the pet card, abilities that contain the search text will be marked with a gold ring.
- You can also search levels, stats and text simultaneously:
"bleed health>700 level<25" : Pets with Bleed in text that have over 700hp and are under 25.
"level<25 bleed health>700" : Same thing. The order of search isn't important.
"health>700 <25 bleed" : Same again. If a stat doesn't appear with a < > or =, it assumes level.

Leveling Pets

Thanks to suggestions from Behub, Aloek and others, Rematch has a robust system to make leveling pets easy.

In the Pets tab there is a leveling slot with a shiny gold border. You can drag a pet here to mark it as your leveling pet. (You can also right-click a pet elsewhere like in the journal and choose 'Start Leveling')

- Any teams saved with a leveling pet will reserve that pet's slot for future leveling pets.
- When you see a shiny gold border around a pet anywhere in Rematch, it means that is a leveling pet.

So if you save teams for various tamers with the leveling pet loaded, when you return to those tamers later with a different leveling pet, it will load that new leveling pet in their saved places.

The Leveling Queue

In addition to the gold-bordered leveling slot, there is a leveling queue you can store any number of pets that you intend to level.

As soon as your current leveling pet reaches 25 (grats!), if there are any leveling pets waiting it will swap the top-most pet in the queue to the leveling slot.

From the gear button to the right of the leveling slot you can:
- Sort the queue by level: Ascending (level 1 to 25), Descending (25 to 1) or Median (closest to level 10.5).
- Create your own order by dragging pets around and inserting them between other pets, or by right-clicking a pet and choosing the move options.
- Use the Auto Rotate option to move to a new pet in the queue after each successful pet battle.
- Fill the queue from pets in the browser. For instance, search "21-24", filter for Rare and hit Fill to add 21-24 rare pets to the leveling queue.
- Empty the queue. It will ask for confirmation before clearing the queue.
- If you want to switch to another pet for one fight without changing the order, double-click the pet in the queue.  You can drag it to the leveling slot or right-click the pet and choose Start Leveling.
- If the current leveling pet is loaded, you can navigate around the queue with previous/next buttons when you mouseover the leveling pet.

Sharing Teams

There are two ways to share battle pet teams when you right-click it in the Teams tab:

Send will send a team to someone online on your faction.
- When a user receives a team that you Send, they'll receive a popup displaying the team with the option to save it.  If they're in combat or they have another team waiting (or a similar dialog up) it will inform you that they're busy and you should try again later.
- To send a team cross-realm, include their name, such as Gello-Hyjal.
- In options you can choose to block incoming pets if you'd like.

Export will create a WeakAuras-like text string that you can copy to the clipboard.
- You can paste the team anywhere else: in an email, on forums, in a text file, etc.
- Any other Rematch user can use this string to Import the same team. The Import button is in the bottomright of the main window.

If you receive or import a team that includes pets you don't have, that's fine. They'll be greyed out and only the pets you have will attempt to load. You can keep the team as is for the day when you get the pet, or you can choose to save over it if you find a suitable substitute for the missing pet.

Note: Battle.net and RealID are not totally supported yet. At present there's a test mode you can try if you'd like.  If both you and your battle.net friend have the option enabled, it will attempt to send via the team via battle.net.

Also, there's a known issue with the first Send sometimes failing if you haven't been in direct /whispers with a far-away/cross-realm player. If a recipient fails to receive a team the first time you've tried, try again. It should work for the rest of the session.

Other addons

A major goal with this addon was to make it behave well regardless of what other battle pet addons you're using.

In some cases, it even takes advantage of the awesome addons others have created. For instance:
- If you have the addon Battle Pet Breed ID enabled, pets will display breed information. If you click a pet and mouseover its stats, you can see all possible breeds for the pet.
- If you have the addon Pet Battle Teams enabled, there will be a button at the end of options to import your teams from PBT.
- If you choose to continue using PBT alongside Rematch (many do!), make sure you lock your PBT teams or auto save in PBT is disabled. The default behavior of PBT is to change the pets in your currently-selected team to whatever is loaded.
ogether if you choose.
- If you have a Broker infobar addon, it will create a button on your bars to toggle Rematch.

Note for users of Rematch on the beta Warlords of Draenor client

- If you know how, you can copy your live Rematch SavedVariable to the beta to get all your teams on the beta client. The contents of your leveling queue will not carry over, unfortunately. That part is a work in progress.
- I've noticed some pets on live were revoked when copied to beta (the pet store ones mostly). Revoked pets are now greyed out in Rematch and treated as if you don't have them.
- I've not found a way to empty a pet slot in WoD. Until it can be figured out, the "Empty Missing" option is turned off and removed from options and from the right-click menu of your current pets.
- Teams that contain saved empty slots will simply ignore those slots and leave whatever was loaded in that slot's place.
- If you encounter a bug or unexpected behavior, please mention that it was on the WoD beta client.

If you have any comments, suggestions or bugs to report feel free to post them here in the comments. Thanks!

Special thanks to those providing translations to other clients!
deDE: Tonyleila at wowinterface (Leilameda at EU-Anetheron)
zhCN: Zkpjy at wowinterface
zhTW: Leg883 at curse
esES and esMX: Phanx at curse

09/25/2014 3.0.14 fix for error when a team fails to load
09/20/2014 3.0.13 fix for extra prompts for loading when leveling pet changes with 'Always show or load', window remains up after loading from said prompt, import button moved to teams tab, reload button added to main window, WoD fixes: fix for auto load and targets with saved npcIDs, fix for cooldown "shine" animation
09/18/2014 3.0.12 various WoD fixes: new petID formats, search box, tab icon chooser, key binding jump button
09/07/2014 3.0.11 options reworked, search bar added to teams tab, new options Reverse Dialog Direction, Larget list Text, browser filters In A Team/Not In A Team
09/01/2014 3.0.10 show on injured for 100% or below, bug fix type bar buttons, bug fix scrollbar inactive at end of lists, new option Auto Show->Stay after loading, new option Auto Load->Show after loading, esES and esMX localization
08/19/2014 3.0.9 toc reverted to 50400 for MoP, WoD-only bug fix for npc id recognition, new option "Show dialogs at side"
08/13/2014 3.0.8 bug fix for slots emptied if leveling queue is empty and loaded team contains a leveling pet, zhTW and zhCN localizaion update.
08/09/2014 3.0.7 bug fix for leveling pets causing window to show on load, missing pet popup dialog, DontWarnMissing option to turn off dialog, zhCN localization, localization template now includes new/depreciated strings
08/07/2014 3.0.6 WoD support, revoked pets are treated as missing pets
08/06/2014 3.0.5 Auto Load will only load on first interaction with a saved target, further interactions will prompt for load
08/05/2014 3.0.4 "new" options Jump To Key, Auto Load-> On Target Only, Always Show or Load, dialogs no longer overlap, ESC bug fixes, auto-shown windows dismiss when team loads, zhTW localization, removed lastOffered system
08/01/2014 3.0.3 reworked esc system (removed uispecialframe handling); window will reappear after a pet battle only if it was up when battle started; removed StayOnTarget option; zhCN localization
07/30/2014 3.0.2 auto load/auto show disabled during pet battles, attempting to load a team during combat or pet battle will wait until afterwards
07/28/2014 3.0.1 fix for team loading when window hidden, fix for dead pets not loading
07/28/2014 3.0.0 rewritten UI, Pets and Teams tab, resize grip for window, many other changes
07/02/2014 2.4.9 zhTW and zhCN update, Rebuild Teams button added, removed team validation on login
06/16/2014 2.4.8 enable Auto Rotate auto-selects topmost leveling pet, some tweaks to how moving pets in the queue work, new browser filter Only Tradable.
06/05/2014 2.4.7 localization updates for zhTW and zhCN.
06/02/2014 2.4.6 ability tooltips now look more like pet cards, new options Larger Pet Cards and Show on Injured, show window if a pet is missing when team loads, update for zhTW, zhCN
05/29/2014 2.4.5 import PBT team button, localization method reworked, updates for zhTW and zhCN.
05/27/2014 2.4.4 only battle pets option added for real
05/26/2014 2.4.3 level internally classified as a stat for more standard behavior, ability to search for text+stats together, browser options: wide search bar, use type bar, only battle pets, update for zhTW locale
05/24/2014 2.4.2 journal button now attaches to chain of anchors ending at the find battle button, zhTW localization by leg883, hide journal option, minimap button, key binding option button, find battle button
05/18/2014 2.4.1 zhCN localization, show on any pets dead after load complete, added stat compare search, added xp bar on pets with partial levels in queue
05/16/2014 2.4.0 leveling queue revamp, tooltips added, LDB support, pet card health shows health/max when hurt
04/06/2014 2.3.8 localization updates for zhTW, zhCN and deDE clients
04/03/2014 2.3.7 new OnlyLeveling filter option, new Close Pet Journal option, sort order saved to savedvar
03/30/2014 2.3.6 zhTW localization, fix for current zone in kun-lai summit
03/29/2014 2.3.5 options panel changed to scrollable list, deDE localization, zhCN localization 
03/21/2014 2.3.4 strings separated out to localization files
03/17/2014 2.3.3 search hits highlights on pet card, typebar radio buttons turned to tabs, all three type modes can be filtered simultaneously, dropdown type menu behavior made same as typebar, fix for non-battle pets having wrong damage taken for their type, strong/tough searches no longer include non-battle pets, buttons added to browser scrollbar to scroll to top and bottom
03/09/2014 2.3.2 fix for 'start leveling' in pet journal, double-click in browser to summon/dismiss pets, browser pets marked if dead, possible fix for a scrollframe bug (when scrollbar disabled move offset to 0 if not already there)
03/08/2014 2.3.1 removed portrait mask for ability icons on default ability tooltip, jump to key only if no modifier down, added link to chat for browser pets, browser opens back up after journal closes (if it was up before), favorite filter turned into a soft filter
03/07/2014 2.3.0 new pet browser, pet card lock/mouseover mechanism, SmartAnchor system references the main window instead of relativeTo, Jump to Team changed to Jump to Key, species aren't filled when when caging a species that has multiples in a saved team, fix for abilities not linking from current pets
02/22/2014 2.2.9 new option StayForBattle, added "weak vs" row to hints window, SmartAnchor system for pet card and tooltips, reworked dropdown menu build to make options more consistent, added Swap with Next in Queue to dropdown, added pullout side panel for leveling pet/queue auto load, added option ShowSidePanel to enable side panel
02/19/2014 2.2.8 window hides when a battle starts/returns after, fix for 5.4.7 patch and revoked pets
02/11/2014 2.2.7 fix for pet names on leveling slot/queue right-click menu, pets in the journal show an icon if they're a leveling pet, leveling icon changed, when queue is empty 'Put Leveling Pet Here' still given as an option but disabled, removed highlight texture from saved pets
02/01/2014 2.2.6 when pets are loaded, there is no longer an effort to have loaded teams move into first slots, but instead to the slots they were saved, fix for dead X icon persisting on empty slots, auto load only fires once per encounter with a saved target, added AutoLoad->AutoLoadAlways option, added AutoLoad->EmptyMissing option, fixed minor xml errors, fix for current header not being draggable, pet loading more rigorous (checks if pet/ability needs loading, verifies it loaded, sets up a reload in 0.3 seconds or after battle if failed), /rematch import converts empty slots to leveling pets and turns on 'Empty Missing', /rematch import over to overwrite existing teams, /rematch help
01/29/2014 2.2.5 fix for right-click menu on leveling slot
01/29/2014 2.2.4 species ID is saved with teams and used when the pet ID is no longer valid, 'Send to End of Queue' option added for current leveling pets, full support for empty slots, petload process changed from OnUpdate one swap per frame to all swaps at once
01/25/2014 2.2.3 rename/send/export/delete moved to right-click of a team; fix for current team title not updating if pets don't change, fix for ESC sometimes failing with unexpected UISpecialFrame entry, possible fix for pet loading issue
01/18/2014 2.2.2 ESC system switched from UISpecialFrames to propagated keys, "Current Battle Pets" header will show last loaded team (if current pets are still last loaded team), teams can be renamed, hitting a letter over teams will jump to a team that begins with that letter, new toggle auto load binding
01/10/2014 2.2.1 changed 'frame' to 'rematch' in RematchSharedDropDown CreateFrame
01/10/2014 2.2.0 code restructured, UI/ESCable system reworked, saved pet section collapses, Lock Drawer option, esc clears selected team, auto-show/load will not dismiss the window if it was up already, 'Use Leveling Pet' added to right-click menu of current pets that can't level, save button is 'Save As' when it will ask for a name, help button and help plates
12/14/2013 2.1.5a fix for ability icons made too big from today's update oops
12/14/2013 2.1.5 'Add to Leveling Queue' option added for journal pet menus to send to end of queue, removed 5.4.1 taint bug fix, queue only processes when out of combat/pet battle
12/06/2013 2.1.4 auto upgrade (aka best of species) option added
11/29/2013 2.1.3 leveling queue system, right-click menus added to journal current pets and leveling pets, level displayed on current pets under 25
11/07/2013 2.1.2 confirmation on save/import/receive over existing teams, confirmation on delete, option to disable confirmations, changed icon of the pullout button, new option: Auto Load->On Mouseover to auto load teams on mouseover instead of target
11/04/2013 2.1.1 caged pets replaced by their species in saved teams, fix for auto load preventing opening window, petsNeedLoading will take leveling pets into account
11/03/2013 2.1.0 removed lock system, replaced with leveling slot system; pet journal onshow HookScript instead of SetScript; removed requirement for selected team to be scrolled in to save/delete; saveAs will allow saving over a team with same name
10/29/2013 2.0.10 fix for taint issue with microbuttons: setfenv onshow to empty UpdateMicroButtons()
10/28/2013 2.0.9 removed visibility requirement to update pet journal loadouts
10/27/2013 2.0.8 fix for disconnect bug when dragging pets to a saved slot; PetBattleTeam migration moved to /rematch migrate
10/27/2013 2.0.7 rematch button on pet journal will move based on the existence of other buttons along the bottom
10/24/2013 2.0.6 if 'Auto Show' and 'Lock Window' are both checked, window will remain after pets load; all three slots can be locked; auto show/load trigger more intelligently with locked pets; added Rematch button to pet journal; ability tooltip mouse disabled; holding Shift will let you move the window while it's locked; 'Keep Companion' system reworked around UNIT_PET with a timeout
10/18/2013 2.0.5 fix for saving low level pets caused by fix from last update
10/18/2013 2.0.4 low level pets with abilities higher than they can use will load the lower tier ability instead, low level current pets only show abilities they can use, team loads taking too long will stop trying, BAG_UPDATE throttled
10/18/2013 2.0.3 rewrite: new UI, new options, custom teams, send/import/export teams
09/11/2013 1.0.5 toc update for 5.4
08/06/2013 1.0.4 fix for saved pets caged or missing
05/21/2013 1.0.3 toc update for 5.3
03/16/2013 1.0.2 added 'Auto Show' option, changed UI a bit
03/13/2013 1.0.1 initial release