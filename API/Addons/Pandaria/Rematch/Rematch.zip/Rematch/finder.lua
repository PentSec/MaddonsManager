-- rematch:FindBestPetID(speciesID[,otherthanPetID1,otherthanPetID2]) takes a
-- speciesID and finds the best petID (level first, then rarity) if available.

local rematch = Rematch

rematch.finderPets = {}
rematch.finderNeedsUpdate = nil -- set in PET_JOURNAL_LIST_UPDATE when we need to update foundSpecies

if rematch.WoDBuild then
	rematch.finderFlags = {
		[LE_PET_JOURNAL_FLAG_COLLECTED]=true,
		[LE_PET_JOURNAL_FLAG_NOT_COLLECTED]=true
	}
else
	rematch.finderFlags = {
		[LE_PET_JOURNAL_FLAG_COLLECTED]=true,
		[LE_PET_JOURNAL_FLAG_FAVORITES]=false,
		[LE_PET_JOURNAL_FLAG_NOT_COLLECTED]=true
	}
end
rematch.finderFilters = { flags={}, types={}, sources={} }

-- fills rematch.finderPets with a list of all owned petIDs sorted by
-- descending level (and descending rarity)
function rematch:UpdateFinder()

	if not rematch.finderNeedsUpdate then
		return -- data made should be current, don't recreate it
	end

	-- this function *always* causes PJLU to fire in the next frame;
	-- since a PJLU can cause other addons to react with their own, we'll unregister
	-- rematch from the event for 0.1 seconds to ignore its consequences
	rematch:UnregisterEvent("PET_JOURNAL_LIST_UPDATE")
	rematch:StartTimer("FinderBlackout",0.1,function() rematch:RegisterEvent("PET_JOURNAL_LIST_UPDATE") end)

	-- backup default filters (we don't touch roster at all)
	local filters = rematch.finderFilters
	for flag in pairs(rematch.finderFlags) do
		filters.flags[flag] = not C_PetJournal.IsFlagFiltered(flag)
	end
	for i=1,C_PetJournal.GetNumPetSources() do
		filters.sources[i] = not C_PetJournal.IsPetSourceFiltered(i)
	end
	for i=1,C_PetJournal.GetNumPetTypes() do
		filters.types[i] = not C_PetJournal.IsPetTypeFiltered(i)
	end

	-- expand all filters so all pets are in journal
	C_PetJournal.ClearSearchFilter() -- not going to both restoring search
	for flag,value in pairs(rematch.finderFlags) do
		C_PetJournal.SetFlagFilter(flag,value)
	end
	C_PetJournal.AddAllPetSourcesFilter()
	C_PetJournal.AddAllPetTypesFilter()

	-- fill finderPets with all owned petIDs
	wipe(rematch.finderPets)
	for i=1,C_PetJournal.GetNumPets() do
		local petID,speciesID = C_PetJournal.GetPetInfoByIndex(i)
		if petID then
			tinsert(rematch.finderPets,petID)
		end
	end

	-- restore filters to their backed-up state
	for flag in pairs(rematch.finderFlags) do
		C_PetJournal.SetFlagFilter(flag,filters.flags[flag])
	end
	for i=1,C_PetJournal.GetNumPetSources() do
		C_PetJournal.SetPetSourceFilter(i,filters.sources[i])
	end
	for i=1,C_PetJournal.GetNumPetTypes() do
		C_PetJournal.SetPetTypeFilter(i,filters.types[i])
	end

	-- now sort finderPets by level/rarity
	local GetPetInfoByPetID = C_PetJournal.GetPetInfoByPetID
	local GetPetStats = C_PetJournal.GetPetStats
	table.sort(rematch.finderPets,function(e1,e2)
		if e1 and not e2 then
			return true
		elseif e2 and not e1 then
			return false
		else
			local _,_,level1 = GetPetInfoByPetID(e1)
			local _,_,level2 = GetPetInfoByPetID(e2)
			if level1>level2 then -- level descending
				return true
			elseif level1<level2 then
				return false
			else -- levels are equal
				local _,_,_,_,rarity1 = GetPetStats(e1)
				local _,_,_,_,rarity2 = GetPetStats(e2)
				return rarity1>rarity2 -- rarity descending
			end
		end
	end)

	rematch.finderNeedsUpdate = nil
end

-- finds best owned pet of speciesID that isn't pet1 or pet2 (if defined)
function rematch:FindBestPetID(speciesID,pet1,pet2)
	rematch:UpdateFinder()
	for i=1,#rematch.finderPets do
		local petID = rematch.finderPets[i]
		local candidateSpeciesID = C_PetJournal.GetPetInfoByPetID(petID)
		if candidateSpeciesID==speciesID and petID~=pet1 and petID~=pet2 and not C_PetJournal.PetIsRevoked(petID) then
			return petID
		end
	end
end

function rematch:ConvertMoPToWoDPetID(petID)

end

--[[
0x00000000029FB505
0x00000000029FB4F8
0x00000000029FB5D5
0x00000000029FB517
0x00000000029FB43F
0x00000000029FB3C2
0x00000000029FB5D8
0x00000000029FB5EF
0x00000000029FB586
0x00000000029FB432
0x00000000029FB45F
0x00000000029FB4DE
0x00000000029FB411
0x00000000029FB3BC
0x00000000029FB4FD
0x00000000029FB423
0x00000000029FB4F6
0x00000000029FB50E
0x00000000029FB430
0x0000000000000000

0x00000000029FB434
BattlePet:0:0000029FB434

BattlePet:0:000000000000

BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4
BattlePet:0:0000020B26C4


]]
