--Credits: Awaited (永霜@TW-Wrathbringer)

if GetLocale() ~= "zhTW" then return end

local L = NugComboBar.L

--L["Specialization-specific"] = ...
L["Character-specific"] = "角色限定"
L["Switch between global/character configuration"] = "選擇角色限定或全域設定"
L["Scale"] = "大小"
L["Anchorpoint"] = "瞄點"
L["Unlock"] = "解鎖"
L["Unlock dragging anchor"] = "解鎖"
L["Lock"] = "鎖定"
L["Lock dragging anchor"] = "鎖定"
L["General"] = "綜合"
L["Show Empty"] = "非使用時顯示"
L["Keep when there's no points"] = "非使用時顯示"
L["Fade out"] = "淡出"
L["Disable Default"] = "停用魔獸內建顯示"
L["Hides default combat point (and other) frames"] = "停用魔獸內建顯示"
L["(Color settings only available in 2D mode)"] = "(自訂顏色只適用於靜態模組)"
L["2D Mode"] = "靜態模組"
L["3D Mode"] = "動態模組"
L["2D Mode settings"] = "靜態模組設定"
L["3D Mode settings"] = "動態模組設定"
L["Preset"] = "動態效果"
L["All Points"] = "為所有點設定同一顏色"
L["Disable for current character or spec"] = ""
L["ReloadUI"] = "重載介面"
L["Disabled"] = "停用插件"