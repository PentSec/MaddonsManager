﻿if ( GetLocale() ~= "deDE" ) then
  return ;
end
-- Missing translation
ENCHANTED = "Verzaubert:"