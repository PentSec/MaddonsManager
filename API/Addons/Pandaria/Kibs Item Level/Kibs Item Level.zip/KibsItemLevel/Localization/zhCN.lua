﻿if ( GetLocale() ~= "zhCN" ) then
  return ;
end
-- Missing translation
ENCHANTED = "附魔:"