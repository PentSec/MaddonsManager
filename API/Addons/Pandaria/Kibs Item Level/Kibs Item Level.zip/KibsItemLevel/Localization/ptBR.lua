﻿if ( GetLocale() ~= "ptBR" ) then
  return ;
end
-- Missing translation
ENCHANTED = "Encantado:"