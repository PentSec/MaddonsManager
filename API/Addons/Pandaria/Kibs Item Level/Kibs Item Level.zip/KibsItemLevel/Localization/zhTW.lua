﻿if ( GetLocale() ~= "zhTW" ) then
  return ;
end
-- Missing translation
ENCHANTED = "附魔:"