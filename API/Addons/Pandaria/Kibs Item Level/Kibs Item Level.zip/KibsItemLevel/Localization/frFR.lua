﻿if ( GetLocale() ~= "frFR" ) then
  return ;
end
ENCHANTED = "Enchanté:"