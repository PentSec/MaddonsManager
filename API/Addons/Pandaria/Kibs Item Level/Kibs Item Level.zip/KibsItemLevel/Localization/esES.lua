﻿if ( GetLocale() ~= "esES" ) then
  return ;
end
ENCHANTED = "Encantado:"