﻿if ( GetLocale() ~= "itIT" ) then
  return ;
end
ENCHANTED = "Incantato:"