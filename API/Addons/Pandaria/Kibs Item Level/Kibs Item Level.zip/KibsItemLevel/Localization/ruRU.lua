﻿if ( GetLocale() ~= "ruRU" ) then
  return ;
end
ENCHANTED = "Зачаровано:"