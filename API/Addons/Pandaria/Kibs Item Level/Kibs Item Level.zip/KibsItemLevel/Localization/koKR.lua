﻿if ( GetLocale() ~= "itIT" ) then
  return ;
end
-- Missing translation
ENCHANTED = "마법부여:"