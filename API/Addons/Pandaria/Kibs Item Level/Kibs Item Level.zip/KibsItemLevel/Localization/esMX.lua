﻿if ( GetLocale() ~= "esMX" ) then
  return ;
end
ENCHANTED = "Encantado:"