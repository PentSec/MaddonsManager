﻿-- Local stuff
if (GetLocale() == "itIT") then

XPERL_RAID_MONITOR_TITLE		= "Monitor Lancio |c00A04040(BETA)|r"
XPERL_RAID_MONITOR_TOTALS		= "Abilita la visualizzazione delle statistiche"

XPERL_RAID_MONITOR_STATS_RAID_MANA	= "Mana Incursione"
XPERL_RAID_MONITOR_STATS_HIGH_MANA	= "Mana Alto"
XPERL_RAID_MONITOR_STATS_LOW_MANA	= "Mana Basso"
XPERL_RAID_MONITOR_STATS_RAID_HEALTH	= "Vita Incursione"

XPERL_MONITOR_LEFTCLICK			= "|c00FFFFFFClick Sinistro|r per %s"
XPERL_MONITOR_RIGHTCLICK		= "|c00FFFFFFClick Destro|r per %s"
XPERL_MONITOR_CLICKCAST			= "lancia |c0000FF00%s|r"
XPERL_MONITOR_CLICKTARGET		= "|c00FFFF80bersaglia|r"

XPERL_MONITOR_INNERVATE			= "Innervazione"
XPERL_MONITOR_MANATIDE			= "Mana Tide Totem"

XPERL_LOC_OOR				= "N/D"

end