local Aloft = Aloft
if not Aloft then return end
local AloftModules = AloftModules
if not AloftModules then return end
local AloftLocale = AloftLocale
if not AloftLocale then return end

-----------------------------------------------------------------------------

AloftModules:AddInitializer("AloftArenaID", function()

-----------------------------------------------------------------------------

local L = AloftLocale.AloftArenaID
if not L then return end

local AloftArenaID = Aloft:GetModule("ArenaID")
if not AloftArenaID then return end

local SML = LibStub("LibSharedMedia-3.0")

-----------------------------------------------------------------------------

Aloft.Options.args.arenaID =
{
	type = 'group',
	name = L["Arena ID"],
	desc = L["Arena ID placement options"],
	disabled = function(i) return not Aloft:IsEnabled() or not AloftArenaID:IsEnabled() or not AloftArenaID.db or not AloftArenaID.db.profile end,
	args =
	{
		enable =
		{
			type = 'toggle',
			width = 'full',
			name = L["Enable"],
			desc = L["Enable arena ID display on the nameplate"],
			get = function(i) return AloftArenaID.db.profile.enable end,
			set = function(i, v) AloftArenaID.db.profile.enable = v AloftArenaID:UpdateAll() end,
			order = 1,
		},
		style =
		{
			type = 'select',
			width = 'full',
			name = L["Style"],
			desc = L["Sets the arena ID graphic style"],
			order = 3,
			disabled = function(i) return not AloftArenaID.db.profile.enable end,
			get = function(i)
				for k, v in pairs(Aloft.Options.args.arenaID.args.style.values) do
					if v == AloftArenaID.db.profile.style then
						-- ChatFrame7:AddMessage("Aloft.Options.args.arenaID.args.style.get(): " .. tostring(k))
						return k
					end
				end
			end,
			set = function(i, v)
				AloftArenaID.db.profile.style = Aloft.Options.args.arenaID.args.style.values[v]
				-- ChatFrame7:AddMessage("Aloft.Options.args.arenaID.args.style.set(): " .. tostring(AloftArenaID.db.profile.style))
				AloftArenaID:UpdateAll()
			end,
			values = SML:List("icon"),
		},
		color =
		{
			type = 'color',
			width = 'full',
			name = L["Color"],
			desc = L["Sets the arena ID graphic color"],
			order = 4,
			disabled = function(i) return not AloftArenaID.db.profile.enable end,
			get = function(i) return unpack(AloftArenaID.db.profile.color) end,
			set = function(i, r, g, b, a) AloftArenaID.db.profile.color = { r, g, b, a, } AloftArenaID:UpdateAll() end,
			hasAlpha = true,
		},
		size =
		{
			type = 'range',
			width = 'full',
			name = L["Size"],
			desc = L["Size in pixels of the arena ID graphic"],
			order = 5,
			min = 4,
			max = 64,
			step = 1,
			disabled = function(i) return not AloftArenaID.db.profile.enable end,
			get = function(i) return AloftArenaID.db.profile.size end,
			set = function(i, v) AloftArenaID.db.profile.size = v AloftArenaID:UpdateAll() end,
		},
		position =
		{
			type = 'group',
			name = L["Position"],
			desc = L["Adjust arena ID position"],
			disabled = function(i) return not Aloft:IsEnabled() or not AloftArenaID:IsEnabled() or not AloftArenaID.db or not AloftArenaID.db.profile or not AloftArenaID.db.profile.enable end,
			order = 6,
			args =
			{
				anchor = {
					type = 'select',
					width = 'full',
					name = L["Anchor"],
					desc = L["Sets the anchor for the arena ID"],
					get = function(i) return AloftArenaID.db.profile.point end,
					set = function(i, v) AloftArenaID.db.profile.point = v AloftArenaID:UpdateAll() end,
					values = {["TOPLEFT"] = L["TOPLEFT"], ["TOP"] = L["TOP"], ["TOPRIGHT"] = L["TOPRIGHT"], ["LEFT"] = L["LEFT"], ["CENTER"] = L["CENTER"], ["RIGHT"] = L["RIGHT"], ["BOTTOMLEFT"] = L["BOTTOMLEFT"], ["BOTTOM"] = L["BOTTOM"], ["BOTTOMRIGHT"] = L["BOTTOMRIGHT"]},
				},
				anchorto = {
					type = 'select',
					width = 'full',
					name = L["Anchor To"],
					desc = L["Sets the relative point on the health bar to anchor the arena ID"],
					get = function(i) return AloftArenaID.db.profile.relativeToPoint end,
					set = function(i, v) AloftArenaID.db.profile.relativeToPoint = v AloftArenaID:UpdateAll() end,
					values = {["TOPLEFT"] = L["TOPLEFT"], ["TOP"] = L["TOP"], ["TOPRIGHT"] = L["TOPRIGHT"], ["LEFT"] = L["LEFT"], ["CENTER"] = L["CENTER"], ["RIGHT"] = L["RIGHT"], ["BOTTOMLEFT"] = L["BOTTOMLEFT"], ["BOTTOM"] = L["BOTTOM"], ["BOTTOMRIGHT"] = L["BOTTOMRIGHT"]},
				},
				offsetX =
				{
					type = 'range',
					width = 'full',
					name = L["X Offset"],
					desc = L["X offset of the arena ID"],
					min = -128,
					max = 128,
					step = 1,
					get = function(i) return AloftArenaID.db.profile.offsetX end,
					set = function(i, v) AloftArenaID.db.profile.offsetX = v AloftArenaID:UpdateAll() end
				},
				offsetY =
				{
					type = 'range',
					width = 'full',
					name = L["Y Offset"],
					desc = L["Y offset of the arena ID"],
					min = -128,
					max = 128,
					step = 1,
					get = function(i) return AloftArenaID.db.profile.offsetY end,
					set = function(i, v) AloftArenaID.db.profile.offsetY = v AloftArenaID:UpdateAll() end
				},
			},
		},
		typeface =
		{
			type = "group",
			name = L["Typeface"],
			desc = L["Arena ID typeface options"],
			order = 7,
			disabled = function(i) return not Aloft:IsEnabled() or not AloftArenaID:IsEnabled() or not AloftArenaID.db or not AloftArenaID.db.profile or not AloftArenaID.db.profile.enable end,
			args =
			{
				font =
				{
					type = 'select',
					width = 'full',
					name = L["Font"],
					desc = L["Sets the font for arena ID text"],
					get = function(i)
						for k, v in pairs(Aloft.Options.args.arenaID.args.typeface.args.font.values) do
							if v == AloftArenaID.db.profile.text.font then
								return k
							end
						end
					end,
					set = function(i, v)
						AloftArenaID.db.profile.text.font = Aloft.Options.args.arenaID.args.typeface.args.font.values[v]
						AloftArenaID:UpdateAll()
					end,
					values = SML:List("font"),
				},
				fontSize =
				{
					type = 'range',
					width = 'full',
					name = L["Font Size"],
					desc = L["Sets the font height of the arena ID text"],
					max = 16,
					min = 5,
					step = 1,
					get = function(i) return AloftArenaID.db.profile.text.fontSize end,
					set = function(i, value) AloftArenaID.db.profile.text.fontSize = value AloftArenaID:UpdateAll() end
				},
				shadow =
				{
					type = 'toggle',
					width = 'full',
					name = L["Font Shadow"],
					desc = L["Show font shadow on arena ID text"],
					get = function(i) return AloftArenaID.db.profile.text.shadow end,
					set = function(i, v) AloftArenaID.db.profile.text.shadow = v AloftArenaID:UpdateAll() end
				},
				outline =
				{
					type = 'select',
					width = 'full',
					name = L["Outline"],
					desc = L["Sets the outline for arena ID text"],
					get = function(i) return AloftArenaID.db.profile.text.outline end,
					set = function(i, value) AloftArenaID.db.profile.text.outline = value AloftArenaID:UpdateAll() end,
					values = { [""] = L["None"], ["OUTLINE"] = L["Normal"], ["THICKOUTLINE"] = L["Thick"] },
				},
				color =
				{
					type = 'color',
					width = 'full',
					name = L["Color"],
					desc = L["Sets the arena ID text color"],
					order = 1,
					get = function(i) return unpack(AloftArenaID.db.profile.text.color) end,
					set = function(i, r, g, b, a) AloftArenaID.db.profile.text.color = { r, g, b, a, } AloftArenaID:UpdateAll() end,
					hasAlpha = true,
				},
				offsetX =
				{
					type = 'range',
					width = 'full',
					name = L["X Offset"],
					desc = L["X offset of the arena ID text"],
					min = -128,
					max = 128,
					step = 1,
					get = function(i) return AloftArenaID.db.profile.text.offsetX end,
					set = function(i, v) AloftArenaID.db.profile.text.offsetX = v AloftArenaID:UpdateAll() end
				},
				offsetY =
				{
					type = 'range',
					width = 'full',
					name = L["Y Offset"],
					desc = L["Y offset of the arena ID text"],
					min = -128,
					max = 128,
					step = 1,
					get = function(i) return AloftArenaID.db.profile.text.offsetY end,
					set = function(i, v) AloftArenaID.db.profile.text.offsetY = v AloftArenaID:UpdateAll() end
				},
			},
		},
	},
}

-----------------------------------------------------------------------------

end)
