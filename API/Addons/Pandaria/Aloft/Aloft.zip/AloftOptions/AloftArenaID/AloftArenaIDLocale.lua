local Aloft = Aloft
if not Aloft then return end
local AloftModules = AloftModules
if not AloftModules then return end
local AloftLocale = AloftLocale
if not AloftLocale then return end

-----------------------------------------------------------------------------

local mL = AloftLocale.AloftModules
if not mL then return end

local L = { }

-----------------------------------------------------------------------------

AloftModules:AddInitializer("AloftArenaID", function()

-----------------------------------------------------------------------------

-- TODO: on the surface, this wastes space in the enUS locale; the metatable could just return the canonical string as the localization;
--       BUT, this serves as a default locale, and also will permit the metatable to check/notify on missing locale strings

--[[ enUS ]] L["Arena ID"] = "Arena ID"
--[[ enUS ]] L["Arena ID placement options"] = "Arena ID placement options"
--[[ enUS ]] L["Enable"] = "Enable"
--[[ enUS ]] L["Enable arena ID display on the nameplate"] = "Enable arena ID display on the nameplate"

--[[ enUS ]] L["Alpha"] = "Alpha"
--[[ enUS ]] L["Sets the arena ID alpha"] = "Sets the arena ID alpha"
--[[ enUS ]] L["Style"] = "Style"
--[[ enUS ]] L["Sets the arena ID graphic style"] = "Sets the arena ID graphic style"
--[[ enUS ]] L["Color"] = "Color"
--[[ enUS ]] L["Sets the arena ID graphic color"] = "Sets the arena ID graphic color"
--[[ enUS ]] L["Size"] = "Size"
--[[ enUS ]] L["Size in pixels of the arena ID graphic"] = "Size in pixels of the arena ID graphic"

--[[ enUS ]] L["Position"] = "Position"
--[[ enUS ]] L["Adjust arena ID position"] = "Adjust arena ID position"
--[[ enUS ]] L["X Offset"] = "X Offset"
--[[ enUS ]] L["X offset of the arena ID"] = "X offset of the arena ID"
--[[ enUS ]] L["Y Offset"] = "Y Offset"
--[[ enUS ]] L["Y offset of the arena ID"] = "Y offset of the arena ID"
--[[ enUS ]] L["Anchor"] = "Anchor"
--[[ enUS ]] L["Sets the anchor for the arena ID"] = "Sets the anchor for the arena ID"
--[[ enUS ]] L["Anchor To"] = "Anchor To"
--[[ enUS ]] L["Sets the relative point on the health bar to anchor the arena ID"] = "Sets the relative point on the health bar to anchor the arena ID"

--[[ enUS ]] L["Typeface"] = "Typeface"
--[[ enUS ]] L["Arena ID typeface options"] = "Arena ID typeface options"
--[[ enUS ]] L["Font"] = "Font"
--[[ enUS ]] L["Sets the font for arena ID text"] = "Sets the font for arena ID text"
--[[ enUS ]] L["Font Size"] = "Font Size"
--[[ enUS ]] L["Sets the font height of the arena ID text"] = "Sets the font height of the arena ID text"
--[[ enUS ]] L["Font Shadow"] = "Font Shadow"
--[[ enUS ]] L["Show font shadow on arena ID text"] = "Show font shadow on arena ID text"
--[[ enUS ]] L["Outline"] = "Outline"
--[[ enUS ]] L["Sets the outline for arena ID text"] = "Sets the outline for arena ID text"
--[[ enUS ]] L["Sets the arena ID text color"] = "Sets the arena ID text color"
--[[ enUS ]] L["X offset of the arena ID text"] = "X offset of the arena ID text"
--[[ enUS ]] L["Y offset of the arena ID text"] = "Y offset of the arena ID text"

--[[ enUS ]] L["None"] = "None"
--[[ enUS ]] L["Normal"] = "Normal"
--[[ enUS ]] L["Thick"] = "Thick"

--[[ enUS ]] L["TOPLEFT"] = "TOPLEFT"
--[[ enUS ]] L["TOP"] = "TOP"
--[[ enUS ]] L["TOPRIGHT"] = "TOPRIGHT"
--[[ enUS ]] L["LEFT"] = "LEFT"
--[[ enUS ]] L["CENTER"] = "CENTER"
--[[ enUS ]] L["RIGHT"] = "RIGHT"
--[[ enUS ]] L["BOTTOMLEFT"] = "BOTTOMLEFT"
--[[ enUS ]] L["BOTTOM"] = "BOTTOM"
--[[ enUS ]] L["BOTTOMRIGHT"] = "BOTTOMRIGHT"

-----------------------------------------------------------------------------

end)

--[[ enUS ]] mL["AloftArenaID"] = "AloftArenaID"
--[[ enUS ]] mL["Display arena IDs on nameplates"] = "Display arena IDs on nameplates"

-----------------------------------------------------------------------------

local locale = GetLocale()

-----------------------------------------------------------------------------

if (locale == "koKR") then

-----------------------------------------------------------------------------

AloftModules:AddInitializer("AloftArenaID", function()

-----------------------------------------------------------------------------

--[[ koKR ]] L["Arena ID"] = "Arena ID"
--[[ koKR ]] L["Arena ID placement options"] = "Arena ID placement options"
--[[ koKR ]] L["Enable"] = "사용"
--[[ koKR ]] L["Enable arena ID display on the nameplate"] = "Enable arena ID display on the nameplate"

--[[ koKR ]] L["Alpha"] = "투명도"
--[[ koKR ]] L["Sets the arena ID alpha"] = "Sets the arena ID alpha"
--[[ koKR ]] L["Style"] = "Style"
--[[ koKR ]] L["Sets the arena ID graphic style"] = "Sets the arena ID graphic style"
--[[ koKR ]] L["Color"] = "Color"
--[[ koKR ]] L["Sets the arena ID graphic color"] = "Sets the arena ID graphic color"
--[[ koKR ]] L["Size"] = "크기"
--[[ koKR ]] L["Size in pixels of the arena ID graphic"] = "Size in pixels of the arena ID graphic"

--[[ koKR ]] L["Position"] = "위치"
--[[ koKR ]] L["Adjust arena ID position"] = "Adjust arena ID position"
--[[ koKR ]] L["X Offset"] = "X 좌표"
--[[ koKR ]] L["X offset of the arena ID"] = "X offset of the arena ID"
--[[ koKR ]] L["Y Offset"] = "Y 좌표"
--[[ koKR ]] L["Y offset of the arena ID"] = "Y offset of the arena ID"
--[[ koKR ]] L["Anchor"] = "앵커"
--[[ koKR ]] L["Sets the anchor for the arena ID"] = "Sets the anchor for the arena ID"
--[[ koKR ]] L["Anchor To"] = "앵커 위치"
--[[ koKR ]] L["Sets the relative point on the health bar to anchor the arena ID"] = "Sets the relative point on the health bar to anchor the arena ID"

--[[ koKR ]] L["Typeface"] = "Typeface"
--[[ koKR ]] L["Arena ID typeface options"] = "Arena ID typeface options"
--[[ koKR ]] L["Font"] = "Font"
--[[ koKR ]] L["Sets the font for arena ID text"] = "Sets the font for arena ID text"
--[[ koKR ]] L["Font Size"] = "Font Size"
--[[ koKR ]] L["Sets the font height of the arena ID text"] = "Sets the font height of the arena ID text"
--[[ koKR ]] L["Font Shadow"] = "Font Shadow"
--[[ koKR ]] L["Show font shadow on arena ID text"] = "Show font shadow on arena ID text"
--[[ koKR ]] L["Outline"] = "Outline"
--[[ koKR ]] L["Sets the outline for arena ID text"] = "Sets the outline for arena ID text"
--[[ koKR ]] L["Sets the arena ID text color"] = "Sets the arena ID text color"
--[[ koKR ]] L["X offset of the arena ID text"] = "X offset of the arena ID text"
--[[ koKR ]] L["Y offset of the arena ID text"] = "Y offset of the arena ID text"

--[[ koKR ]] L["None"] = "없음"
--[[ koKR ]] L["Normal"] = "보통"
--[[ koKR ]] L["Thick"] = "굵게"

--[[ koKR ]] L["TOPLEFT"] = "좌측 상단"
--[[ koKR ]] L["TOP"] = "상단"
--[[ koKR ]] L["TOPRIGHT"] = "우측 상단"
--[[ koKR ]] L["LEFT"] = "좌측"
--[[ koKR ]] L["CENTER"] = "가운데"
--[[ koKR ]] L["RIGHT"] = "우측"
--[[ koKR ]] L["BOTTOMLEFT"] = "좌측 하단"
--[[ koKR ]] L["BOTTOM"] = "하단"
--[[ koKR ]] L["BOTTOMRIGHT"] = "우측 하단"

-----------------------------------------------------------------------------

end)

--[[ koKR ]] mL["AloftArenaID"] = "AloftArenaID"
--[[ koKR ]] mL["Display arena IDs on nameplates"] = "Display arena IDs on nameplates"

-----------------------------------------------------------------------------

elseif (locale == "ruRU") then

-----------------------------------------------------------------------------

AloftModules:AddInitializer("AloftArenaID", function()

-----------------------------------------------------------------------------

--[[ ruRU ]] L["Arena ID"] = "Arena ID"
--[[ ruRU ]] L["Arena ID placement options"] = "Arena ID placement options"
--[[ ruRU ]] L["Enable"] = "Включить"
--[[ ruRU ]] L["Enable arena ID display on the nameplate"] = "Enable arena ID display on the nameplate"

--[[ ruRU ]] L["Alpha"] = "Прозрачность"
--[[ ruRU ]] L["Sets the arena ID alpha"] = "Sets the arena ID alpha"
--[[ ruRU ]] L["Style"] = "Style"
--[[ ruRU ]] L["Sets the arena ID graphic style"] = "Sets the arena ID graphic style"
--[[ ruRU ]] L["Color"] = "Color"
--[[ ruRU ]] L["Sets the arena ID graphic color"] = "Sets the arena ID graphic color"
--[[ ruRU ]] L["Size"] = "Размер"
--[[ ruRU ]] L["Size in pixels of the arena ID graphic"] = "Size in pixels of the arena ID graphic"

--[[ ruRU ]] L["Position"] = "Позиция"
--[[ ruRU ]] L["Adjust arena ID position"] = "Adjust arena ID position"
--[[ ruRU ]] L["X Offset"] = "Смещение по X"
--[[ ruRU ]] L["X offset of the arena ID"] = "X offset of the arena ID"
--[[ ruRU ]] L["Y Offset"] = "Смещение по Y"
--[[ ruRU ]] L["Y offset of the arena ID"] = "Y offset of the arena ID"
--[[ ruRU ]] L["Anchor"] = "Точка прикрепления"
--[[ ruRU ]] L["Sets the anchor for the arena ID"] = "Sets the anchor for the arena ID"
--[[ ruRU ]] L["Anchor To"] = "Прикрепить к"
--[[ ruRU ]] L["Sets the relative point on the health bar to anchor the arena ID"] = "Sets the relative point on the health bar to anchor the arena ID"

--[[ ruRU ]] L["Typeface"] = "Typeface"
--[[ ruRU ]] L["Arena ID typeface options"] = "Arena ID typeface options"
--[[ ruRU ]] L["Font"] = "Font"
--[[ ruRU ]] L["Sets the font for arena ID text"] = "Sets the font for arena ID text"
--[[ ruRU ]] L["Font Size"] = "Font Size"
--[[ ruRU ]] L["Sets the font height of the arena ID text"] = "Sets the font height of the arena ID text"
--[[ ruRU ]] L["Font Shadow"] = "Font Shadow"
--[[ ruRU ]] L["Show font shadow on arena ID text"] = "Show font shadow on arena ID text"
--[[ ruRU ]] L["Outline"] = "Outline"
--[[ ruRU ]] L["Sets the outline for arena ID text"] = "Sets the outline for arena ID text"
--[[ ruRU ]] L["Sets the arena ID text color"] = "Sets the arena ID text color"
--[[ ruRU ]] L["X offset of the arena ID text"] = "X offset of the arena ID text"
--[[ ruRU ]] L["Y offset of the arena ID text"] = "Y offset of the arena ID text"

--[[ ruRU ]] L["None"] = "Нет"
--[[ ruRU ]] L["Normal"] = "Обычно"
--[[ ruRU ]] L["Thick"] = "Жирный"

--[[ ruRU ]] L["TOPLEFT"] = "ВВЕРХУ-СЛЕВА"
--[[ ruRU ]] L["TOP"] = "ВВЕРХУ"
--[[ ruRU ]] L["TOPRIGHT"] = "ВВЕРХУ-СПРАВА"
--[[ ruRU ]] L["LEFT"] = "СЛЕВА"
--[[ ruRU ]] L["CENTER"] = "ПО ЦЕНТРУ"
--[[ ruRU ]] L["RIGHT"] = "СПРАВА"
--[[ ruRU ]] L["BOTTOMLEFT"] = "СНИЗУ-СЛЕВА"
--[[ ruRU ]] L["BOTTOM"] = "СНИЗУ"
--[[ ruRU ]] L["BOTTOMRIGHT"] = "СНИЗУ-СПРАВА"

-----------------------------------------------------------------------------

end)

--[[ ruRU ]] mL["AloftArenaID"] = "AloftArenaID"
--[[ ruRU ]] mL["Display arena IDs on nameplates"] = "Display arena IDs on nameplates"

-----------------------------------------------------------------------------

elseif (locale == "zhCN") then

-----------------------------------------------------------------------------

AloftModules:AddInitializer("AloftArenaID", function()

-----------------------------------------------------------------------------

--[[ zhCN ]] L["Arena ID"] = "Arena ID"
--[[ zhCN ]] L["Arena ID placement options"] = "Arena ID placement options"
--[[ zhCN ]] L["Enable"] = "启用"
--[[ zhCN ]] L["Enable arena ID display on the nameplate"] = "Enable arena ID display on the nameplate"

--[[ zhCN ]] L["Alpha"] = "透明度"
--[[ zhCN ]] L["Sets the arena ID alpha"] = "Sets the arena ID alpha"
--[[ zhCN ]] L["Style"] = "Style"
--[[ zhCN ]] L["Sets the arena ID graphic style"] = "Sets the arena ID graphic style"
--[[ zhCN ]] L["Color"] = "Color"
--[[ zhCN ]] L["Sets the arena ID graphic color"] = "Sets the arena ID graphic color"
--[[ zhCN ]] L["Size"] = "尺寸"
--[[ zhCN ]] L["Size in pixels of the arena ID graphic"] = "Size in pixels of the arena ID graphic"

--[[ zhCN ]] L["Position"] = "位置"
--[[ zhCN ]] L["Adjust arena ID position"] = "Adjust arena ID position"
--[[ zhCN ]] L["X Offset"] = "X轴偏移"
--[[ zhCN ]] L["X offset of the arena ID"] = "X offset of the arena ID"
--[[ zhCN ]] L["Y Offset"] = "Y轴偏移"
--[[ zhCN ]] L["Y offset of the arena ID"] = "Y offset of the arena ID"
--[[ zhCN ]] L["Anchor"] = "锚点"
--[[ zhCN ]] L["Sets the anchor for the arena ID"] = "Sets the anchor for the arena ID"
--[[ zhCN ]] L["Anchor To"] = "固定在"
--[[ zhCN ]] L["Sets the relative point on the health bar to anchor the arena ID"] = "Sets the relative point on the health bar to anchor the arena ID"

--[[ zhCN ]] L["Typeface"] = "Typeface"
--[[ zhCN ]] L["Arena ID typeface options"] = "Arena ID typeface options"
--[[ zhCN ]] L["Font"] = "Font"
--[[ zhCN ]] L["Sets the font for arena ID text"] = "Sets the font for arena ID text"
--[[ zhCN ]] L["Font Size"] = "Font Size"
--[[ zhCN ]] L["Sets the font height of the arena ID text"] = "Sets the font height of the arena ID text"
--[[ zhCN ]] L["Font Shadow"] = "Font Shadow"
--[[ zhCN ]] L["Show font shadow on arena ID text"] = "Show font shadow on arena ID text"
--[[ zhCN ]] L["Outline"] = "Outline"
--[[ zhCN ]] L["Sets the outline for arena ID text"] = "Sets the outline for arena ID text"
--[[ zhCN ]] L["Sets the arena ID text color"] = "Sets the arena ID text color"
--[[ zhCN ]] L["X offset of the arena ID text"] = "X offset of the arena ID text"
--[[ zhCN ]] L["Y offset of the arena ID text"] = "Y offset of the arena ID text"

--[[ zhCN ]] L["None"] = "无"
--[[ zhCN ]] L["Normal"] = "正常"
--[[ zhCN ]] L["Thick"] = "粗"

--[[ zhCN ]] L["TOPLEFT"] = "左上"
--[[ zhCN ]] L["TOP"] = "上"
--[[ zhCN ]] L["TOPRIGHT"] = "右上"
--[[ zhCN ]] L["LEFT"] = "左"
--[[ zhCN ]] L["CENTER"] = "中"
--[[ zhCN ]] L["RIGHT"] = "右"
--[[ zhCN ]] L["BOTTOMLEFT"] = "左下"
--[[ zhCN ]] L["BOTTOM"] = "下"
--[[ zhCN ]] L["BOTTOMRIGHT"] = "右下"

-----------------------------------------------------------------------------

end)

--[[ zhCN ]] mL["AloftArenaID"] = "AloftArenaID"
--[[ zhCN ]] mL["Display arena IDs on nameplates"] = "Display arena IDs on nameplates"

-----------------------------------------------------------------------------

elseif (locale == "zhTW") then

-----------------------------------------------------------------------------

AloftModules:AddInitializer("AloftArenaID", function()

-----------------------------------------------------------------------------

--[[ zhTW ]] L["Arena ID"] = "Arena ID"
--[[ zhTW ]] L["Arena ID placement options"] = "Arena ID placement options"
--[[ zhTW ]] L["Enable"] = "啟用"
--[[ zhTW ]] L["Enable arena ID display on the nameplate"] = "Enable arena ID display on the nameplate"

--[[ zhTW ]] L["Alpha"] = "透明度"
--[[ zhTW ]] L["Sets the arena ID alpha"] = "Sets the arena ID alpha"
--[[ zhTW ]] L["Style"] = "Style"
--[[ zhTW ]] L["Sets the arena ID graphic style"] = "Sets the arena ID graphic style"
--[[ zhTW ]] L["Color"] = "Color"
--[[ zhTW ]] L["Sets the arena ID graphic color"] = "Sets the arena ID graphic color"
--[[ zhTW ]] L["Size"] = "大小"
--[[ zhTW ]] L["Size in pixels of the arena ID graphic"] = "Size in pixels of the arena ID graphic"

--[[ zhTW ]] L["Position"] = "位置"
--[[ zhTW ]] L["Adjust arena ID position"] = "Adjust arena ID position"
--[[ zhTW ]] L["X Offset"] = "X偏移"
--[[ zhTW ]] L["X offset of the arena ID"] = "X offset of the arena ID"
--[[ zhTW ]] L["Y Offset"] = "Y偏移"
--[[ zhTW ]] L["Y offset of the arena ID"] = "Y offset of the arena ID"
--[[ zhTW ]] L["Anchor"] = "錨點"
--[[ zhTW ]] L["Sets the anchor for the arena ID"] = "Sets the anchor for the arena ID"
--[[ zhTW ]] L["Anchor To"] = "錨點到"
--[[ zhTW ]] L["Sets the relative point on the health bar to anchor the arena ID"] = "Sets the relative point on the health bar to anchor the arena ID"

--[[ zhTW ]] L["Typeface"] = "Typeface"
--[[ zhTW ]] L["Arena ID typeface options"] = "Arena ID typeface options"
--[[ zhTW ]] L["Font"] = "Font"
--[[ zhTW ]] L["Sets the font for arena ID text"] = "Sets the font for arena ID text"
--[[ zhTW ]] L["Font Size"] = "Font Size"
--[[ zhTW ]] L["Sets the font height of the arena ID text"] = "Sets the font height of the arena ID text"
--[[ zhTW ]] L["Font Shadow"] = "Font Shadow"
--[[ zhTW ]] L["Show font shadow on arena ID text"] = "Show font shadow on arena ID text"
--[[ zhTW ]] L["Outline"] = "Outline"
--[[ zhTW ]] L["Sets the outline for arena ID text"] = "Sets the outline for arena ID text"
--[[ zhTW ]] L["Sets the arena ID text color"] = "Sets the arena ID text color"
--[[ zhTW ]] L["X offset of the arena ID text"] = "X offset of the arena ID text"
--[[ zhTW ]] L["Y offset of the arena ID text"] = "Y offset of the arena ID text"

--[[ zhTW ]] L["None"] = "無"
--[[ zhTW ]] L["Normal"] = "正常"
--[[ zhTW ]] L["Thick"] = "粗"

--[[ zhTW ]] L["TOPLEFT"] = "上左"
--[[ zhTW ]] L["TOP"] = "上"
--[[ zhTW ]] L["TOPRIGHT"] = "上右"
--[[ zhTW ]] L["LEFT"] = "左"
--[[ zhTW ]] L["CENTER"] = "中"
--[[ zhTW ]] L["RIGHT"] = "右"
--[[ zhTW ]] L["BOTTOMLEFT"] = "下左"
--[[ zhTW ]] L["BOTTOM"] = "下"
--[[ zhTW ]] L["BOTTOMRIGHT"] = "下右"

-----------------------------------------------------------------------------

end)

--[[ zhTW ]] mL["AloftArenaID"] = "AloftArenaID"
--[[ zhTW ]] mL["Display arena IDs on nameplates"] = "Display arena IDs on nameplates"

-----------------------------------------------------------------------------

end

-----------------------------------------------------------------------------

AloftModules:AddInitializer("AloftArenaID", function()

-----------------------------------------------------------------------------

AloftLocale.AloftArenaID = setmetatable(L, { __index = function(t, k) rawset(t, k, k) error("Aloft: No translation found for '" .. k .. "'") return k end })
L = nil

-----------------------------------------------------------------------------

end)
