local Aloft = Aloft
if not Aloft then return end

-----------------------------------------------------------------------------

local MAJOR_VERSION = "5.2.8" 
local MINOR_VERSION = ("$Revision: 476 $"):match("%d+")
local locale = GetLocale()

Aloft.version = MAJOR_VERSION .. "-" .. MINOR_VERSION .. "-" .. locale

-----------------------------------------------------------------------------
