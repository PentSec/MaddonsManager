local Aloft = Aloft
if not Aloft then return end

-----------------------------------------------------------------------------

local AloftCastBar = Aloft:GetModule("CastBar") -- always on
if not AloftCastBar then return end

local AloftSpellIcon = Aloft:NewModule("SpellIcon", Aloft, "AceEvent-3.0")

local SML = LibStub("LibSharedMedia-3.0")

-----------------------------------------------------------------------------

AloftSpellIcon.namespace = "spellIcon"
AloftSpellIcon.defaults =
{
	profile =
	{
		enable			= true,
		point			= "LEFT",
		relativeToPoint	= "LEFT",
		offsetX			= 0,
		offsetY			= 0,
		size			= 11,

		nointerShield	= true,
		nointerStyle	= "SQUARE",
		nointerColor	= { 1.0, 1.0, 1.0, 0.65 }, -- white
		nointerScale	= 2.5,
		nointerOffsetX	= 0,
		nointerOffsetY	= 0,
	},
}

-----------------------------------------------------------------------------

-- textures for shield graphic
SML:Register("shield",	"ROUND",			[[Interface\Addons\Aloft\Textures\RndNoInterrupt]])
SML:Register("shield",	"SQUARE",			[[Interface\Addons\Aloft\Textures\SqrNoInterrupt]])
SML:Register("shield",	"BLIZZARD",			[[Interface\CastingBar\UI-CastingBar-Arena-Shield]])

local configSpellIconTexture = [[Interface\Icons\Spell_Nature_Polymorph]]

-----------------------------------------------------------------------------

function AloftSpellIcon:UpdateAll()
	if Aloft:IsConfigModeEnabled() then
		local aloftData = Aloft:GetTargetNameplate()
		if aloftData then
			self:OnCastFrameShow("AloftSpellIcon:UpdateAll", aloftData)
		end
	end
end

-----------------------------------------------------------------------------

function AloftSpellIcon:OnInitialize()
	if self.db ~= Aloft.AloftDB:GetNamespace(self.namespace, true) then self.db = Aloft.AloftDB:RegisterNamespace(self.namespace, self.defaults) end

	self.initialized = true
end

function AloftSpellIcon:OnEnable()
	-- Ace3 now calls OnInitialize only if the addon is available at time of ADDON_LOADED?
	if not self.initialized then self:OnInitialize() end

	self:UnregisterAllEvents()
	self:UnregisterAllMessages()
	self:CancelAllTimers()

	self:RegisterMessage("Aloft:OnNameplateHide", "OnNameplateHide")
	self:RegisterMessage("Aloft:OnCastBarShow", "OnCastBarShow")
	self:RegisterMessage("Aloft:OnCastBarHide", "OnCastBarHide")
	self:RegisterMessage("Aloft:OnCastBarValueChanged", "Update")
	self:UpdateAll()
end

function AloftSpellIcon:OnDisable()
	self:UnregisterAllEvents()
	self:UnregisterAllMessages()
	self:CancelAllTimers()

	for aloftData in Aloft:IterateNameplates() do
		local bSpellIconRegion = aloftData.spellIconRegion

		bSpellIconRegion:ClearAllPoints()
		bSpellIconRegion:SetPoint("CENTER", aloftData.nameplateFrame, "BOTTOMLEFT", 13.33, 10.29)
		bSpellIconRegion:SetWidth(14.5)
		bSpellIconRegion:SetHeight(14.5)
		bSpellIconRegion:SetParent(aloftData.nameplateFrame)

		if spellIconRegion then
			spellIconRegion:Hide()

			-- ChatFrame7:AddMessage("AloftSpellIcon:OnDisable(): hide " .. tostring(aloftData.name))
		end
		if noInterruptRegion then
			noInterruptRegion:Hide()
		end
	end
end

function AloftSpellIcon:OnNameplateShow(message, aloftData)
end

function AloftSpellIcon:OnNameplateHide(message, aloftData)
end

-- TODO: propagate this to name text, level text, boss icon, and/or other "default" nameplate components as needed
function AloftSpellIcon:GetInset(aloftData, noInterrupt)
	if noInterrupt then
		return ((AloftCastBar.db.profile.border ~= "None") and 4) or 0
	else
		return ((AloftCastBar.db.profile.nointerBorder ~= "None") and 4) or 0
	end
end

function AloftSpellIcon:OnCastBarShow(message, aloftData)
	-- ChatFrame7:AddMessage("AloftSpellIcon:OnCastFrameShow(): enter " .. tostring(aloftData.name))
	-- ChatFrame7:AddMessage("AloftSpellIcon:OnCastFrameShow(): enter " .. tostring(aloftData.name) .. "/" .. tostring(aloftData) .. "/" .. tostring(aloftData.layoutFrame) .. "/" .. tostring(noInterruptRegion) .. "/" .. tostring(aloftData.spellIconRegion))
	-- if Aloft:IsConfigModeEnabled() and (aloftData.isTarget or aloftData:IsTarget()) then ChatFrame7:AddMessage("AloftSpellIcon:OnCastFrameShow(): config enter " .. tostring(aloftData.name) .. "/" .. tostring(Aloft:IsConfigModeEnabled()) .. "/" .. tostring(aloftData.isTarget or aloftData:IsTarget())) end

	local castBar = aloftData.castBar
	local bSpellIconRegion = castBar.spellIconRegion
	if bSpellIconRegion then
		 -- always hide the Blizzard spell icon, regardless of other outcome;
		 -- the texture is overwritten by Blizzard, so we use alpha here
		bSpellIconRegion:SetAlpha(0)
	end

	if self.db.profile.enable and AloftCastBar:IsDisplayEnabled() then
		-- ChatFrame7:AddMessage("AloftSpellIcon:OnCastFrameShow(): enable " .. tostring(aloftData.name))
		local noInterrupt = castBar.castBarShieldRegion:IsShown()
		local castFrame = AloftCastBar:AcquireCastFrame(aloftData, noInterrupt)
		if castFrame then
			local texture = (Aloft:IsConfigModeEnabled() and (aloftData.isTarget or aloftData:IsTarget()) and configSpellIconTexture) or (bSpellIconRegion and bSpellIconRegion.GetTexture and bSpellIconRegion:GetTexture())

			local spellIconRegion = castFrame.spellIconRegion
			if not spellIconRegion then
				spellIconRegion = castFrame:CreateTexture(nil, "OVERLAY")
				spellIconRegion:SetBlendMode("DISABLE")

				castFrame.spellIconRegion = spellIconRegion
				spellIconRegion.castFrame = castFrame
			end

			spellIconRegion:SetTexture(texture)
			spellIconRegion:SetWidth(self.db.profile.size)
			spellIconRegion:SetHeight(self.db.profile.size)
			-- ChatFrame7:AddMessage("AloftSpellIcon:OnCastFrameShow(): spell icon initialized " .. ("|T%s:0|t"):format(texture) .. "/" .. ("|T%s:0|t"):format(spellIconRegion:GetTexture(texture)))

			local inset = self:GetInset(aloftData, noInterrupt)
			local hinset, vinset = Aloft:AdjustFrame(inset, self.db.profile.relativeToPoint)

			self:PlaceFrame(spellIconRegion, castFrame, self.db.profile, hinset, vinset)

			if self.db.profile.nointerShield then
				local noInterruptRegion = castFrame.noInterruptRegion
				if not noInterruptRegion then
					noInterruptRegion = castFrame:CreateTexture(nil, "BORDER")
					noInterruptRegion:SetBlendMode("BLEND")

					castFrame.noInterruptRegion = noInterruptRegion
					noInterruptRegion.castFrame = castFrame
				end

				-- the noInterrupt graphic is a shield-like graphic that centers on the spell icon.
				local noITexture = SML:Fetch("shield", self.db.profile.nointerStyle)
				-- ChatFrame7:AddMessage("AloftSpellIcon:OnCastFrameShow(): " .. tostring(aloftData.name) .. "/" .. tostring(self.db.profile.nointerStyle) .. "/" .. tostring(noITexture))

				noInterruptRegion:SetTexture(noITexture)
				noInterruptRegion:SetVertexColor(unpack(self.db.profile.nointerColor))

				noInterruptRegion:ClearAllPoints()
				noInterruptRegion:SetWidth(self.db.profile.nointerScale * self.db.profile.size)
				noInterruptRegion:SetHeight(self.db.profile.nointerScale * self.db.profile.size)
				noInterruptRegion:SetPoint("CENTER", spellIconRegion, "CENTER", self.db.profile.nointerOffsetX, self.db.profile.nointerOffsetY)
				noInterruptRegion:SetAlpha(1.0)

				-- ChatFrame7:AddMessage("AloftSpellIcon:OnCastFrameShow() show noInterruptRegion " .. tostring(noInterruptRegion:IsVisible()) .. "/" .. tostring(noInterruptRegion:IsShown()) .. "/" .. tostring(noInterruptRegion:GetParent() and noInterruptRegion:GetParent():IsVisible()) .. "/" .. tostring(noInterruptRegion:GetParent() and noInterruptRegion:GetParent():IsShown()) .. "/" .. tostring(texture) .. "/" .. tostring(noInterruptRegion:GetTexture()))
			end
			-- ChatFrame7:AddMessage("AloftSpellIcon:OnCastFrameShow(): noInterrupt " .. tostring(castFrame.noInterrupt))
		end
		-- ChatFrame7:AddMessage("AloftSpellIcon:OnCastFrameShow(): layout " .. tostring(aloftData.name) .. "/" .. tostring(aloftData) .. "/" .. tostring(layoutFrame) .. "/" .. tostring(noInterruptRegion) .. "/" .. tostring(spellIconRegion))
		-- ChatFrame7:AddMessage("AloftSpellIcon:OnCastFrameShow(): " .. tostring(aloftData.name) .. "/" .. tostring(aloftData.layoutFrame and aloftData.layoutFrame:GetFrameLevel()) .. "/" .. tostring(castFrame and castFrame:GetFrameLevel()))
	end
end

function AloftSpellIcon:OnCastBarHide(message, aloftData)
	-- ChatFrame7:AddMessage("AloftSpellIcon:OnCastFrameHide(): hide " .. tostring(aloftData.name))

	local castFrame = aloftData.castFrame
	local noInterruptRegion = castFrame and castFrame.noInterruptRegion
	local spellIconRegion = castFrame and castFrame.spellIconRegion

	if noInterruptRegion then
		noInterruptRegion:Hide()
	end

	if spellIconRegion then
		spellIconRegion:Hide()

		-- ChatFrame7:AddMessage("AloftSpellIcon:OnCastFrameHide(): hide " .. tostring(aloftData.name))
	end

	local castBar = aloftData.castBar
	local bSpellIconRegion = castBar.spellIconRegion
	if bSpellIconRegion then bSpellIconRegion:SetAlpha(0.0) end
end

function AloftSpellIcon:Update(message, aloftData)
	-- ChatFrame7:AddMessage("AloftSpellIcon:OnCastFrameShow(): enter " .. tostring(aloftData.name))
	-- if Aloft:IsConfigModeEnabled() and (aloftData.isTarget or aloftData:IsTarget()) then ChatFrame7:AddMessage("AloftSpellIcon:Update(): config enter " .. tostring(aloftData.name) .. "/" .. tostring(Aloft:IsConfigModeEnabled()) .. "/" .. tostring(aloftData.isTarget or aloftData:IsTarget()) .. "/" .. tostring(aloftData.spellIconRegion) .. "/" .. tostring(noInterruptRegion) .. "/" .. tostring(self.db.profile.enable) .. "/" .. tostring(AloftCastBar:IsDisplayEnabled())) end

	local castBar = aloftData.castBar
	local bSpellIconRegion = castBar.spellIconRegion
	if bSpellIconRegion then bSpellIconRegion:SetAlpha(0.0) end -- always hide the Blizzard spell icon, regardless of other outcome

	if self.db.profile.enable and AloftCastBar:IsDisplayEnabled() then
		local castFrame = aloftData.castFrame
		local spellIconRegion = castFrame and castFrame.spellIconRegion
		local noInterruptRegion = castFrame and castFrame.noInterruptRegion

		-- ChatFrame7:AddMessage("AloftSpellIcon:Update(): step 1 " .. tostring(aloftData.name) .. "/" .. tostring(self.db.profile.enable) .. "/" .. tostring(AloftCastBar:IsDisplayEnabled()) .. "/" .. tostring(spellIconRegion) .. "/" .. tostring(noInterruptRegion))
		 if spellIconRegion or noInterruptRegion then
			-- ChatFrame7:AddMessage("AloftSpellIcon:Update(): step 2 " .. tostring(aloftData.name) .. "/" .. tostring(spellIconRegion) .. "/" .. tostring(noInterruptRegion) .. "/" .. tostring(aloftData.alphaOverride) .. "/" .. tostring(castFrame and castFrame:IsVisible()))
			if (not aloftData.alphaOverride or aloftData.alphaOverride > 0) and castFrame:IsVisible() then
				-- ChatFrame7:AddMessage("AloftSpellIcon:OnCastFrameShow(): " .. tostring(aloftData.name) .. "/" .. tostring(spellIconRegion) .. "/" .. tostring(noInterruptRegion) .. "/" .. tostring(castFrame.noInterrupt))
				-- ChatFrame7:AddMessage("AloftSpellIcon:Update(): step 3 " .. tostring(aloftData.name) .. "/" .. tostring(aloftData.alphaOverride) .. "/" .. tostring(castFrame) .. "/" .. tostring(castFrame and castFrame:IsVisible()))

				-- NOTE: looks like Blizzard may at least partially re-assemble the default spell icon region on every frame; hide regularly
				local texture = (Aloft:IsConfigModeEnabled() and (aloftData.isTarget or aloftData:IsTarget()) and configSpellIconTexture) or (bSpellIconRegion and bSpellIconRegion.GetTexture and bSpellIconRegion:GetTexture())

				if spellIconRegion then
					spellIconRegion:SetParent(castFrame)
					spellIconRegion:SetTexture(texture) -- re-initialize spell icon texture regularly (in case the spell being cast changes without detection)
					spellIconRegion:Show()

					-- ChatFrame7:AddMessage("AloftSpellIcon:Update(): show " .. tostring(aloftData.name) .. "/" .. tostring(spellIconRegion:IsVisible()) .. "/" .. tostring(spellIconRegion:GetAlpha()) .. "/" .. ("|T%s:0|t"):format(spellIconRegion:GetTexture(texture)))
				end

				-- ChatFrame7:AddMessage("AloftSpellIcon:Update(): noInterrupt " .. tostring(aloftData.name) .. "/" .. tostring(castFrame.noInterrupt))
				if noInterruptRegion then
					if castFrame.noInterrupt and self.db.profile.nointerShield then
						noInterruptRegion:Show()
					else
						noInterruptRegion:Hide()
					end
				end

				-- ChatFrame7:AddMessage("AloftSpellIcon:Update(): show " .. tostring(aloftData.name))
				-- if Aloft:IsConfigModeEnabled() and (aloftData.isTarget or aloftData:IsTarget()) then ChatFrame7:AddMessage("AloftSpellIcon:Update(): config " .. tostring(aloftData.name) .. "/" .. tostring(castFrame.noInterrupt) .. "/" .. tostring(spellIconRegion and spellIconRegion:IsVisible()) .. "/" .. tostring(noInterruptRegion and noInterruptRegion:IsVisible())) end
				return
			else
				-- ChatFrame7:AddMessage("AloftSpellIcon:Update(): " .. tostring(aloftData.name) .. "/" .. tostring(aloftData.layoutFrame and aloftData.layoutFrame:GetFrameLevel()) .. "/" .. tostring(castFrame and castFrame:GetFrameLevel()))
			end
		end
	else
		-- ChatFrame7:AddMessage("AloftSpellIcon:Update(): disabled")
	end

	self:OnCastBarHide(message, aloftData)
end

-----------------------------------------------------------------------------
