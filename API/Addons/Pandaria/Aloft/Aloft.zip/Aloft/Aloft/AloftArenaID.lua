local Aloft = Aloft
if not Aloft then return end
local AloftModules = AloftModules
if not AloftModules then return end

-----------------------------------------------------------------------------

AloftModules:AddInitializer("AloftArenaID", function()

-----------------------------------------------------------------------------

local AloftArenaID = Aloft:NewModule("ArenaID", Aloft, "AceEvent-3.0", "AceTimer-3.0")
AloftArenaID.dynamic = "AloftArenaID"

local SML = LibStub("LibSharedMedia-3.0")

-----------------------------------------------------------------------------

AloftArenaID.namespace = "arenaID"
AloftArenaID.defaults =
{
	profile =
	{
		enable			= true,
		style			= "HARD_SOLID_CIRCLE",
		size			= 16,
		color			= { 1, 0, 0, 1, },
		point			= "LEFT",
		relativeToPoint	= "RIGHT",
		offsetX			= 4,
		offsetY			= 0,
		text			=
		{
			enable			= true, -- overloading Aloft:PlaceFrame(); the user cannot access this
			font			= "Arial Narrow",
			color			= { 1, 1, 1, 1, }, -- font color, for Aloft:PrepareText()
			fontSize		= 11,
			shadow			= false,
			outline			= "OUTLINE",
			point			= "CENTER",
			relativeToPoint	= "CENTER",
			offsetX			= 1,
			offsetY			= 0,
		},
	},
}

-----------------------------------------------------------------------------

local inArena = false
local arenaNames = { }

local CreateFrame = CreateFrame
local GetNumArenaOpponentSpecs = GetNumArenaOpponentSpecs
local UnitName = UnitName

-----------------------------------------------------------------------------

-- textures for icon graphic
SML:Register("icon",	"HARD_OUTLINE_CIRCLE",			[[Interface\Addons\Aloft\Textures\HardOutlineCircleIcon]])
SML:Register("icon",	"HARD_OUTLINE_SQUARE",			[[Interface\Addons\Aloft\Textures\HardOutlineSquareIcon]])
SML:Register("icon",	"HARD_SOLID_CIRCLE",			[[Interface\Addons\Aloft\Textures\HardSolidCircleIcon]])
SML:Register("icon",	"HARD_SOLID_SQUARE",			[[Interface\Addons\Aloft\Textures\HardSolidSquareIcon]])
SML:Register("icon",	"SOFT_OUTLINE_CIRCLE",			[[Interface\Addons\Aloft\Textures\SoftOutlineCircleIcon]])
SML:Register("icon",	"SOFT_OUTLINE_SQUARE",			[[Interface\Addons\Aloft\Textures\SoftOutlineSquareIcon]])
SML:Register("icon",	"SOFT_SOLID_CIRCLE",			[[Interface\Addons\Aloft\Textures\SoftSolidCircleIcon]])
SML:Register("icon",	"SOFT_SOLID_SQUARE",			[[Interface\Addons\Aloft\Textures\SoftSolidSquareIcon]])

-----------------------------------------------------------------------------

local unpack = unpack

-----------------------------------------------------------------------------

function AloftArenaID:OnInitialize()
	if self.db ~= Aloft.AloftDB:GetNamespace(self.namespace, true) then self.db = Aloft.AloftDB:RegisterNamespace(self.namespace, self.defaults) end

	self.initialized = true
end

function AloftArenaID:OnEnable()
	-- Ace3 now calls OnInitialize only if the addon is available at time of ADDON_LOADED?
	if not self.initialized then self:OnInitialize() end

	self:UpdateAll()
end

function AloftArenaID:OnDisable()
	self:UnregisterAllEvents()
	self:UnregisterAllMessages()
	self:CancelAllTimers()

	for aloftData in Aloft:IterateNameplates() do
		local layoutFrame = aloftData.layoutFrame
		local arenaIDFrame = layoutFrame and layoutFrame.arenaIDFrame
		if arenaIDFrame then
			arenaIDFrame:Hide()
		end
	end
end

-----------------------------------------------------------------------------

function AloftArenaID:UpdateAll()
	for aloftData in Aloft:IterateNameplates() do
		self:Update(aloftData)
	end
	if self.db.profile and self.db.profile.enable then
		for layoutFrame in pairs(Aloft.layoutFramePool) do
			local arenaIDFrame = layoutFrame.arenaIDFrame
			if arenaIDFrame then
				self:PlaceFrame(arenaIDFrame, layoutFrame, self.db.profile, 0, 0)
			end
		end
	end

	self:RegisterEvents()
end

function AloftArenaID:Update(aloftData)
	-- enabled, in an arena, and aloftData has a class (to differentiate from pets)
	local isConfig = Aloft:IsConfigModeEnabled() and (aloftData.isTarget or aloftData:IsTarget())
	if self.db.profile and self.db.profile.enable and ((inArena and aloftData.class) or isConfig) then
		-- if the name on the nameplate corresponds to a known "arena ID"
		local arenaID = arenaNames[aloftData.name]
		if arenaID or isConfig then
			local arenaIDFrame = self:SetupFrame("AloftArenaID:Update", aloftData)
			local arenaIDText = arenaIDFrame.arenaIDText

			arenaIDText:SetText(arenaID or (isConfig and "0") or "")
			arenaIDFrame:Show()

			-- ChatFrame7:AddMessage("AloftArenaID:Update(): show " .. tostring(aloftData.name) .. "/" .. tostring(arenaIDText:GetText()) .. "/" .. tostring(arenaID) .. "/" ..
			--	tostring(arenaIDFrame:GetSize()) .. "/" .. tostring(arenaIDFrame.arenaIDRegion:GetSize()) .. "/" .. tostring(arenaIDFrame:IsVisible()) .. "/" .. tostring(arenaIDFrame.arenaIDRegion:IsVisible()))

			return
		end
	end

	-- ChatFrame7:AddMessage("AloftArenaID:Update(): hide " .. tostring(aloftData.name))
	self:OnNameplateHide("AloftArenaID:Update", aloftData)
end

-----------------------------------------------------------------------------

function AloftArenaID:RegisterEvents()
	self:UnregisterAllEvents()
	self:UnregisterAllMessages()
	self:CancelAllTimers()

	if self.db.profile and self.db.profile.enable then
		self:RegisterMessage("Aloft:SetupFrame", "SetupFrame")
		self:RegisterMessage("Aloft:OnNameplateShow", "OnNameplateShow")
		self:RegisterMessage("Aloft:OnNameplateHide", "OnNameplateHide")
		self:RegisterMessage("Aloft:OnIsTargetDataChanged", "OnIsTargetDataChanged")
		self:RegisterMessage("Aloft:OnConfigModeChanged", "OnConfigModeChanged")

		self:RegisterEvent("UNIT_NAME_UPDATE", "OnUnitNameUpdate")
		self:RegisterEvent("ARENA_OPPONENT_UPDATE", "OnArenaOpponentUpdate")
		self:RegisterEvent("ARENA_PREP_OPPONENT_SPECIALIZATIONS", "OnZoneChanged")
		self:RegisterEvent("ZONE_CHANGED_NEW_AREA", "OnZoneChanged")
		self:RegisterEvent("PLAYER_ENTERING_WORLD", "OnZoneChanged")
	end
end

function AloftArenaID:RequiresData()
	self:RegisterEvents()
end

-----------------------------------------------------------------------------

function AloftArenaID:SetupFrame(message, aloftData)
	local layoutFrame = aloftData.layoutFrame
	if not layoutFrame then
		layoutFrame = Aloft:AcquireLayoutFrame(aloftData)
	end
	local arenaIDFrame = layoutFrame.arenaIDFrame

	-- Check if this nameplate already has an arena ID assigned to it
	local arenaIDText
	local arenaIDRegion
	if not arenaIDFrame then
		local nameplateFrame = aloftData.nameplateFrame

		-- create the arena ID frame
		arenaIDFrame = CreateFrame("Frame", nil, layoutFrame)
		arenaIDFrame:SetFrameLevel(nameplateFrame:GetFrameLevel() + 2)
		-- arenaIDFrame:SetAlpha(1)

		-- create/initialize texture region
		arenaIDRegion = arenaIDFrame:CreateTexture(nil, "ARTWORK")
		arenaIDRegion:SetAllPoints(arenaIDFrame) -- NOTE: this is important; w/o it, the region dimensions to nothing and does not show
		arenaIDRegion:SetBlendMode("BLEND")
		-- arenaIDRegion:SetAlpha(1)
		arenaIDRegion:Show() -- always shown

		-- create/initialize FontString
		arenaIDText = arenaIDFrame:CreateFontString(nil, "OVERLAY")
		arenaIDText:Show() -- always shown

		-- glue together frame
		arenaIDFrame.arenaIDRegion = arenaIDRegion
		arenaIDRegion.arenaIDFrame = arenaIDFrame

		arenaIDFrame.arenaIDText = arenaIDText
		arenaIDText.arenaIDFrame = arenaIDFrame

		layoutFrame.arenaIDFrame = arenaIDFrame
		arenaIDFrame.layoutFrame = layoutFrame
	else
		arenaIDRegion = arenaIDFrame.arenaIDRegion
		arenaIDText = arenaIDFrame.arenaIDText
	end

	arenaIDRegion:SetTexture(SML:Fetch("icon", self.db.profile.style))
	arenaIDRegion:SetVertexColor(unpack(self.db.profile.color))

	--[[
	if Aloft:IsConfigModeEnabled() then
		local r, g, b, a = arenaIDRegion:GetVertexColor()
		ChatFrame7:AddMessage("AloftArenaID:SetupFrame(): " .. tostring(aloftData.name) .. "/" .. tostring(aloftData.isTarget) .. "/" .. tostring(arenaIDRegion:GetTexture()) .. "/" ..
			tostring(floor(r*256)) .. "." .. tostring(floor(g*256)) .. "." .. tostring(floor(b*256)) .. "." .. tostring(floor(a*256)))
	end
	]]

	self:PlaceFrame(arenaIDText, arenaIDFrame, self.db.profile.text, 0, 0)
	self:PlaceFrame(arenaIDFrame, layoutFrame, self.db.profile, 0, 0)
	self:PrepareText(arenaIDText, self.db.profile.text)

	return arenaIDFrame
end

-----------------------------------------------------------------------------

function AloftArenaID:OnUnitNameUpdate(event, unitid)
	-- ChatFrame7:AddMessage("AloftArenaID:OnUnitNameUpdate(): " .. tostring(unitid and UnitName(unitid)) .. "/" .. tostring(unitid))
	self:OnZoneChanged(event)
end

function AloftArenaID:OnArenaOpponentUpdate(event, unitid, type)
	-- ChatFrame7:AddMessage("AloftArenaID:OnArenaOpponentUpdate(): " .. tostring(unitid and UnitName(unitid)) .. "/" .. tostring(unitid) .. "/" .. tostring(type))
	self:OnZoneChanged(event)
end

function AloftArenaID:OnZoneChanged(event)
	local place = Aloft:GetPlace()
	inArena = (place == "arena") or nil
	-- ChatFrame7:AddMessage("AloftArenaID:OnPlayerEnteringWorld(): " .. tostring(place) .. "/" .. tostring(inArena))

	arenaNames = { } -- zap the table
	if inArena then
		-- map unit names to their "arena ID", via the arena unitid
		local numOpp = GetNumArenaOpponentSpecs()
		for i=1,numOpp do
			local suffix = tostring(i)
			local unitid = "arena" .. suffix
			local unitName = UnitName(unitid)
			if unitName then
				arenaNames[unitName] = suffix
			end
			-- ChatFrame7:AddMessage("AloftArenaID:OnPlayerEnteringWorld(): add " .. tostring(unitid) .. "/" .. tostring(unitName) .. "/" .. tostring(suffix))
		end
	-- else
		-- ChatFrame7:AddMessage("AloftArenaID:OnPlayerEnteringWorld(): clear")
	end

	self:UpdateAll()
end

function AloftArenaID:OnNameplateShow(message, aloftData)
	self:Update(aloftData)
end

function AloftArenaID:OnNameplateHide(message, aloftData)
	local layoutFrame = aloftData.layoutFrame
	local arenaIDFrame = layoutFrame and layoutFrame.arenaIDFrame
	if arenaIDFrame then
		local arenaIDText = arenaIDFrame.arenaIDText

		arenaIDText:SetText("")
		arenaIDFrame:Hide()
	end
end

function AloftArenaID:OnIsTargetDataChanged(message, aloftData)
	-- ChatFrame7:AddMessage("AloftArenaID:OnIsTargetDataChanged(): enter " .. tostring(aloftData.name) .. "/" .. tostring(aloftData.isTarget))
	self:ScheduleTimer(function(aloftData) AloftArenaID:Update(aloftData) end, 0.0, aloftData) -- next frame
end

function AloftArenaID:OnConfigModeChanged(message)
	local aloftData = Aloft:GetTargetNameplate()
	if aloftData then
		self:Update(aloftData)
	end
end

-----------------------------------------------------------------------------

end)
