local Aloft = Aloft
if not Aloft then return end
local AloftModules = AloftModules
if not AloftModules then return end

-----------------------------------------------------------------------------

AloftModules:AddInitializer("AloftCastBarTimeText", function()

-----------------------------------------------------------------------------

local AloftCastBar = Aloft:GetModule("CastBar") -- always on
if not AloftCastBar then return end

local AloftCastBarTimeText = Aloft:NewModule("CastBarTimeText", Aloft, "AceEvent-3.0")
AloftCastBarTimeText.dynamic = "AloftCastBarTimeText"

-----------------------------------------------------------------------------

AloftCastBarTimeText.namespace = "castBarTimeText"
AloftCastBarTimeText.defaults =
{
	profile =
	{
		enable			= true,
		font			= "Arial Narrow",
		fontSize		= 9,
		shadow			= true,
		alignment		= "RIGHT",
		outline			= "",
		offsets =
		{
			left		= 0,
			right		= -5,
			vertical	= 0,
		},
		color			= { 1, 1, 1, 1 },
	},
}

-----------------------------------------------------------------------------

function AloftCastBarTimeText:Update()
	self:RegisterEvents()

	if self.db.profile.enable then
		for aloftData in Aloft:IterateVisibleNameplates() do
			self:SetupFrame("AloftCastBarTimeText:Update", aloftData)
		end
	end
end

-----------------------------------------------------------------------------

function AloftCastBarTimeText:RegisterEvents()
	self:UnregisterAllEvents()
	self:UnregisterAllMessages()
	self:CancelAllTimers()

	if self.db.profile.enable then
		self:RegisterMessage("Aloft:SetupFrame", "SetupFrame")
		self:RegisterMessage("Aloft:OnNameplateHide", "OnNameplateHide")
		self:RegisterMessage("Aloft:OnCastBarShow", "OnCastBarShow")
		self:RegisterMessage("Aloft:OnCastBarHide", "OnCastBarHide")
		self:RegisterMessage("Aloft:OnCastBarValueChanged", "UpdateText")
	end
end

-----------------------------------------------------------------------------

function AloftCastBarTimeText:OnInitialize()
	if self.db ~= Aloft.AloftDB:GetNamespace(self.namespace, true) then self.db = Aloft.AloftDB:RegisterNamespace(self.namespace, self.defaults) end

	self.initialized = true
end

function AloftCastBarTimeText:OnEnable()
	-- Ace3 now calls OnInitialize only if the addon is available at time of ADDON_LOADED?
	if not self.initialized then self:OnInitialize() end

	self:UnregisterAllEvents()
	self:UnregisterAllMessages()
	self:CancelAllTimers()

	self:RegisterMessage("Aloft:SetAll", function(message, type, value)
		if AloftCastBarTimeText.db.profile[type] then
			AloftCastBarTimeText.db.profile[type] = value
			self:Update()
		end
	end)

	self:Update()
end

function AloftCastBarTimeText:OnDisable()
	self:UnregisterAllEvents()
	self:UnregisterAllMessages()
	self:CancelAllTimers()
end

function AloftCastBarTimeText:SetupFrame(message, aloftData)
	if not self.db.profile.enable or not AloftCastBar:IsDisplayEnabled() then return nil end

	local castFrame = aloftData.castFrame
	if castFrame then
		local spellTimeText = castFrame.spellTimeText
		if not spellTimeText then
			spellTimeText = castFrame:CreateFontString(nil, "OVERLAY")

			castFrame.spellTimeText = spellTimeText
			spellTimeText.castFrame = castFrame
		end

		self:PrepareText(spellTimeText, self.db.profile)

		spellTimeText:ClearAllPoints()
		spellTimeText:SetPoint("TOPLEFT", castFrame, "TOPLEFT", self.db.profile.offsets.left, self.db.profile.offsets.vertical)
		spellTimeText:SetPoint("BOTTOMRIGHT", castFrame, "BOTTOMRIGHT", self.db.profile.offsets.right, self.db.profile.offsets.vertical)
		spellTimeText:SetText("")

		spellTimeText:Hide() -- TODO: kludgy

		return spellTimeText
	end

	return nil
end

function AloftCastBarTimeText:UpdateText(message, aloftData)
	local text = ""
	local castBar = aloftData.castBar
	if Aloft:IsConfigModeEnabled() and (aloftData.isTarget or aloftData:IsTarget()) then
		text = "0.00"
	elseif self.db.profile.enable and AloftCastBar:IsDisplayEnabled() then
		text = ("%.2f"):format(castBar:GetValue())
		-- ChatFrame7:AddMessage("AloftCastBarTimeText:UpdateText(): val " .. tostring(aloftData.name) .. "/" .. tostring(castBar:GetValue()) .. "/" .. tostring(text))
	end

	if self.db.profile.enable and AloftCastBar:IsDisplayEnabled() then
		local spellTimeText = self:SetupFrame(message, aloftData)
		if text and spellTimeText then	
			spellTimeText:SetText(text)
			spellTimeText:Show()

			-- ChatFrame7:AddMessage("AloftCastBarTimeText:UpdateText(): text " .. tostring(aloftData.name)  .. "/" .. tostring(text).. "/" .. tostring(spellTimeText:GetText()))
			-- if Aloft:IsConfigModeEnabled() and (aloftData.isTarget or aloftData:IsTarget()) then ChatFrame7:AddMessage("AloftCastBarTimeText:UpdateText(): config " .. tostring(aloftData.name)) end

			return
		end
	end

	self:OnCastBarHide(message, aloftData)
end

function AloftCastBarTimeText:OnNameplateHide(message, aloftData)
	self:OnCastBarHide(message, aloftData)
end

function AloftCastBarTimeText:OnCastBarShow(message, aloftData)
	-- ChatFrame7:AddMessage("AloftCastBarTimeText:OnCastFrameShow(): enter " .. tostring(aloftData.name))

	if self.db.profile.enable and AloftCastBar:IsDisplayEnabled() then
		local spellTimeText = self:SetupFrame(message, aloftData)
		if spellTimeText then
			spellTimeText:Show()
			return
		end
	end

	self:OnCastBarHide(message, aloftData)
end

function AloftCastBarTimeText:OnCastBarHide(message, aloftData)
	-- ChatFrame7:AddMessage("AloftCastBarTimeText:OnCastFrameHide(): hide")

	local spellTimeText = self:SetupFrame(message, aloftData)
	if spellTimeText then
		spellTimeText:Hide()
	end
end

-----------------------------------------------------------------------------

end)
