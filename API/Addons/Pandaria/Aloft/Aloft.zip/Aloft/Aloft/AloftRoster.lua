--[[
Basically lifted from RosterLib-2.1r90093. per http://forums.wowace.com/showthread.php?p=226766, LibRoster-3.0 is a non-starter
]]

--[[
Name: Roster-2.1
Revision: $Revision: 93 $
X-ReleaseDate: $Date: 2008-11-22 23:06:16 +0000 (Sat, 22 Nov 2008) $
Author: Maia (maia.proudmoore@gmail.com)
Website: http://www.wowace.com/
Documentation: http://www.wowace.com/wiki/Roster-2.1
SVN: http://svn.wowace.com/wowace/trunk/RosterLib/
Description: Party/raid roster management
Dependencies: AceLibrary, AceOO-2.0, AceEvent-2.0
]]

local Aloft = Aloft
if not Aloft then return end

local error = error
local GetNumSubgroupMembers = GetNumSubgroupMembers
local GetNumGroupMembers = GetNumGroupMembers
local UnitIsGroupLeader = UnitIsGroupLeader

local AloftRoster = Aloft:NewModule("Roster", Aloft, "AceEvent-3.0", "AceTimer-3.0")

local unknownUnits = {}
local roster
local new, del
do
	local cache = setmetatable({}, {__mode='k'})
	function new()
		local t = next(cache)
		if t then
			cache[t] = nil
			return t
		else
			return {}
		end
	end
	
	function del(t)
		for k in pairs(t) do
			t[k] = nil
		end
		cache[t] = true
		return nil
	end
end

local LegitimateUnits = {player = true, pet = true, playerpet = true, target = true, focus = true, mouseover = true, npc = true, NPC = true, vehicle = true}
for i = 1, 4 do
	LegitimateUnits["party" .. i] = true
	LegitimateUnits["partypet" .. i] = true
	LegitimateUnits["party" .. i .. "pet"] = true
end
for i = 1, 40 do
	LegitimateUnits["raid" .. i] = true
	LegitimateUnits["raidpet" .. i] = true
	LegitimateUnits["raid" .. i .. "pet"] = true
end
for i = 1, 5 do
	LegitimateUnits["arena" .. i] = true
	LegitimateUnits["arena" .. i .. "pet"] = true
end
--[[ these are legitimate units, just not ones for which we want to track pets, etc
for i = 1, 4 do
	LegitimateUnits["boss" .. i] = true
end
]]

setmetatable(LegitimateUnits, {__index=function(self, key)
	if type(key) ~= "string" then
		return false
	end
	if key:find("target$") and not key:find("^npc") then
		local value = self[key:sub(1, -7)]
		self[key] = value
		return value
	end
	self[key] = false
	return false
end})

------------------------------------------------
-- Internal functions
------------------------------------------------

function AloftRoster:OnEnable()
	if not self.roster then self.roster = {} end
	roster = self.roster

	self:SendMessage("AloftRoster_Enabled")

	-- self:RegisterEvent("RAID_ROSTER_UPDATE", "OnRaidRosterUpdate")
	-- self:RegisterEvent("PARTY_MEMBERS_CHANGED", "OnPartyMembersChanged")
	self:RegisterEvent("GROUP_ROSTER_UPDATE", "OnGroupRosterUpdate")
	self:RegisterEvent("UNIT_PET", "OnUnitPet")

	self:ScanFullRoster()
end

function AloftRoster:OnDisable()
	self:UnregisterAllEvents()
	self:UnregisterAllMessages()
	self:CancelAllTimers()
end

function AloftRoster:OnGroupRosterUpdate(event)
	self:ScheduleTimer(function() AloftRoster:ScanFullRoster() end, 0.2)
end

--[[ TODO: dead code, get rid of it
function AloftRoster:OnRaidRosterUpdate(event)
	self:ScheduleTimer(function() AloftRoster:ScanFullRoster() end, 0.2)
end

function AloftRoster:OnPartyMembersChanged(event)
	self:ScheduleTimer(function() AloftRoster:ScanFullRoster() end, 0.2)
end
]]

function AloftRoster:OnUnitPet(event, unitid)
	-- apparently some boss encounters can generate the UNIT_PET event (reported by Myster); insure this is a legitimate unitid
	if LegitimateUnits[unitid] then
		self:ScheduleTimer(function() AloftRoster:ScanPet(unitid) end, 0.2)
	end
end

------------------------------------------------
-- Unit iterator
------------------------------------------------

local UnitIterator
do
	local rmem, pmem, step, count
	local function SelfIterator()
		while step do
			local unit
			if step == 1 then
				-- STEP 1: player
				unit = "player"
				step = 2
			elseif step == 2 then
				-- STEP 2: pet
				unit = "pet"
				step = nil
			end
			if unit and UnitExists(unit) then return unit end
		end
	end

	local function SelfAndPartyIterator()
		while step do
			local unit
			if step <= 2 then
				unit = SelfIterator()
				if not step then step = 3 end
			elseif step == 3 then
				-- STEP 3: party units
				unit = string.format("party%d", count)
				step = 4
			elseif step == 4 then
				-- STEP 4: party pets
				unit = string.format("partypet%d", count)
				count = count + 1
				step = count <= pmem and 3 or nil
			end
			if unit and UnitExists(unit) then return unit end
		end
	end

	local function RaidIterator()
		while step do
			local unit
			if step == 1 then
				-- STEP 1: raid units
				unit = string.format("raid%d", count)
				step = 2
			elseif step == 2 then
				-- STEP 2: raid pets
				unit = string.format("raidpet%d", count)
				count = count + 1
				step = count <= rmem and 1 or nil
			end
			if unit and UnitExists(unit) then return unit end
		end
	end

	function UnitIterator()
		rmem = GetNumGroupMembers()
		step = 1
		if rmem == 0 then
			pmem = GetNumSubgroupMembers()
			if pmem == 0 then
				return SelfIterator, false
			else
				count = 1
				return SelfAndPartyIterator, false
			end
		else
			count = 1
			return RaidIterator, true
		end
	end
end

------------------------------------------------
-- Roster code
------------------------------------------------

local rosterScanCache = {}
function AloftRoster:ScanFullRoster()
	local changed
	local it, isInRaid = UnitIterator()
	-- save all units we currently have, this way we can check who to remove from roster later.
	for name in pairs(roster) do
		rosterScanCache[name] = true
	end
	-- update data
	for unitid in it do
		local name, unitchanged = self:CreateOrUpdateUnit(unitid, isInRaid)
		-- we successfully added a unit, so we don't need to remove it next step
		if name then
			rosterScanCache[name] = nil
			if unitchanged then
				changed = true
			end
		end
	end
	-- clear units we had in roster that either left the raid or are unknown for some reason.
	for name in pairs(rosterScanCache) do
		self:RemoveUnit(name)
		rosterScanCache[name] = nil
		changed = true
	end
	self:ProcessRoster()
	if changed then
		self:SendMessage("AloftRoster_RosterUpdated")
	end
end


local function ProcessPet(unitid)
	if not unitid then return nil end
	local changed

	if not UnitExists(unitid) then
		unknownUnits[unitid] = nil
		-- find the pet in the roster we need to delete
		for _,u in pairs(roster) do
			if u.unitid == unitid then
				AloftRoster:RemoveUnit(u.name)
				changed = true
			end
		end
	else
		changed = select(2, AloftRoster:CreateOrUpdateUnit(unitid))
	end
	AloftRoster:ProcessRoster()

	return changed
end

function AloftRoster:ScanPet(owner_list)
	local changed
	if owner_list then
		if type(owner_list) == "string" then
			local unitid = self:GetPetFromOwner(owner_list)
			changed = ProcessPet(unitid)
		elseif type(owner_list) == "table" then
			for owner in pairs(owner_list) do
				local unitid = self:GetPetFromOwner(owner)
				changed = ProcessPet(unitid)
			end
		end
	end
	if changed then
		self:SendMessage("AloftRoster_RosterUpdated")
	end
end


function AloftRoster:GetPetFromOwner(id)
	-- convert party3 crap to raid IDs when in raid.
	local owner = self:GetUnitIDFromUnit(id)
	if not owner then return end

	-- get ID
	if owner:find("raid") then
		return owner:gsub("raid", "raidpet")
	elseif owner:find("party") then
		return owner:gsub("party", "partypet")
	elseif owner == "player" then
		return "pet"
	else
		return nil
	end
end


function AloftRoster:ScanUnknownUnits()
	local changed
	for unitid in pairs(unknownUnits) do
		local name, c
		if UnitExists(unitid) then
			name, c = self:CreateOrUpdateUnit(unitid)
		else
			unknownUnits[unitid] = nil
		end
		-- some pets never have a name. too bad for them, farewell!
		if not name and unitid:find("pet") then
			unknownUnits[unitid] = nil
		else
			changed = changed or c
		end
	end
	self:ProcessRoster()
	if changed then
		self:SendMessage("AloftRoster_RosterUpdated")
	end
end


function AloftRoster:ProcessRoster()
	if next(unknownUnits, nil) then
		self:CancelAllTimers()
		self:ScheduleTimer(function() AloftRoster:ScanUnknownUnits() end, 1)
	end
end


function AloftRoster:CreateOrUpdateUnit(unitid, isInRaid)
	if not LegitimateUnits[unitid] then
		error(("Bad argument #2 to 'CreateOrUpdateUnit'. %q is not a legitimate UnitID."):format(unitid))
	end
	-- check for name
	local name = UnitName(unitid)
	if name and name ~= UNKNOWNOBJECT and name ~= UKNOWNBEING then
		local unit = roster[name]
		local isPet = unitid:find("pet")

		-- clear stuff
		unknownUnits[unitid] = nil
		-- return if a pet attempts to replace a player name
		-- this doesnt fix the problem with 2 pets overwriting each other FIXME
		if isPet and unit and unit.class ~= "PET" then
			return name
		end
		-- save old data if existing
		local old_name, old_unitid, old_class, old_rank, old_subgroup, old_online, old_role, old_ML
		if unit then
			old_name     = unit.name
			old_unitid   = unit.unitid
			old_class    = unit.class
			old_rank     = unit.rank
			old_subgroup = unit.subgroup
			old_online   = unit.online
			old_role     = unit.role
			old_ML       = unit.ML
		else
			-- object
			unit = new()
			roster[name] = unit
		end

		local new_name, new_unitid, new_class, new_rank, new_subgroup, new_online, new_role, new_ML

		-- name
		new_name = name
		-- unitid
		new_unitid = unitid
		-- class
		if isPet then
			new_class = "PET"
		else
			new_class = select(2, UnitClass(unitid))
		end
		if isInRaid == nil and GetNumGroupMembers() > 0 then
			isInRaid = true
		end

		-- subgroup and rank
		new_subgroup = 1
		new_rank = 0
		if isInRaid then
			local num = select(3, unitid:find("(%d+)"))
			if num then
				local _
				new_rank, new_subgroup, _, _, _, _, _, _, new_role, new_ML = select(2, GetRaidRosterInfo(num))
			end
		else
			new_rank = UnitIsGroupLeader(new_unitid) and 2 or 0
		end
		-- online/offline status
		new_online = UnitIsConnected(unitid)

		-- compare data
		if not old_name
		or new_name     ~= old_name
		or new_unitid   ~= old_unitid
		or new_class    ~= old_class
		or new_subgroup ~= old_subgroup
		or new_rank     ~= old_rank
		or new_online   ~= old_online
		or new_role     ~= old_role
		or new_ML       ~= old_ML
		then
			unit.name = new_name
			unit.unitid = new_unitid
			unit.class = new_class
			unit.subgroup = new_subgroup
			unit.rank = new_rank
			unit.online = new_online
			unit.role = new_role
			unit.ML = new_ML
			self:SendMessage("AloftRoster_UnitChanged",
				new_unitid, new_name, new_class, new_subgroup, new_rank,
				old_name, old_unitid, old_class, old_subgroup, old_rank,
				new_role, new_ML,
				old_role, old_ML)
			return name, true
		end
		return name
	else
		unknownUnits[unitid] = true
		return false
	end
end


function AloftRoster:RemoveUnit(name)
	local r = roster[name]
	roster[name] = nil
	self:SendMessage("AloftRoster_UnitChanged",
		nil, nil, nil, nil, nil,
		r.name, r.unitid, r.class, r.subgroup, r.rank,
		nil, nil,
		r.role, r.ML)
	r = del(r)
end

------------------------------------------------
-- API
------------------------------------------------

function AloftRoster:GetUnitIDFromName(name)
	if roster[name] then
		return roster[name].unitid
	else
		return nil
	end
end


function AloftRoster:GetUnitIDFromUnit(unit)
	-- TEST: error(("AloftRoster:GetUnitIDFromUnit(): checking %q."):format(unit))
	if not LegitimateUnits[unit] then
		error(("Bad argument #2 to 'GetUnitIDFromUnit'. %q is not a legitimate UnitID."):format(unit))
	end
	local name = UnitName(unit)
	if name and roster[name] then
		return roster[name].unitid
	else
		return nil
	end
end

function AloftRoster:GetUnitObjectFromName(name)
	return roster[name]
end


function AloftRoster:GetUnitObjectFromUnit(unit)
	if not LegitimateUnits[unit] then
		error(("Bad argument #2 to 'GetUnitObjectFromUnit'. %q is not a legitimate UnitID."):format(unit))
	end
	local name = UnitName(unit)
	return roster[name]
end


local function iter(t)
	local key = t.key
	local pets = t.pets
	repeat
		key = next(roster, key)
		if not key then
			t = del(t)
			return nil
		end
	until (pets or roster[key].class ~= "PET")
	t.key = key
	return roster[key]
end

function AloftRoster:IterateRoster(pets)
	local t = new()
	t.pets = pets
	return iter, t
end
