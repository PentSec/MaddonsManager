local Aloft = Aloft
if not Aloft then return end

-----------------------------------------------------------------------------

local AloftCastBar = Aloft:NewModule("CastBar", Aloft, "AceEvent-3.0", "AceTimer-3.0")

local SML = LibStub("LibSharedMedia-3.0")

local AloftCastWarning = nil

-----------------------------------------------------------------------------

AloftCastBar.namespace = "castBar"
AloftCastBar.defaults =
{
	profile =
	{
		offsets =
		{
			left		= 0,
			right		= 0,
			vertical	= -12,
		},
		height			= 10,
		incremental		= true,

		border			= "None",
		borderEdgeSize	= 16,
		borderInset		= 4,
		borderColor		= { 1, 1, 1, 1 },
		backdropColor	= { 0.25, 0.25, 0.25, 0.5 },
		color			= { 1.0, 0.7, 0.0, 1.0 },
		texture			= "Blizzard",

		nointerBorder			= "None",
		nointerBorderEdgeSize	= 16,
		nointerBorderInset		= 4,
		nointerBorderColor		= { 1, 1, 1, 1 },
		nointerBackdropColor	= { 0.25, 0.25, 0.25, 0.5 },
		nointerTexture			= "Blizzard",
		nointerColor			= { 1.0, 0.0, 0.0, 1.0 },
	},
}

-----------------------------------------------------------------------------

local inset
local interval = 0.05

-- backdrop table for initializing visible nameplates
local backdropTable =
{
	-- tile = false,
	-- tileSize = 16,
	bgFile = nil,
	edgeSize = 16,
	edgeFile = nil,
	insets = { left = 0, right = 0, top = 0, bottom = 0 },
}

-- backdrop table for resetting nameplates when they are hidden
local defaultBackdropTable =
{
	-- tile = false,
	-- tileSize = 0,
	bgFile = nil,
	-- edgeSize = 0,
	edgeFile = nil,
	insets = { left = 0, right = 0, top = 0, bottom = 0 },
}

local BORDER_INIT_ATTEMPTS = 2

AloftCastBar.castFramePool = { }

-----------------------------------------------------------------------------

function AloftCastBar:UpdateAll()
	if Aloft:IsConfigModeEnabled() then
		local aloftData = Aloft:GetTargetNameplate()
		if aloftData then
			self:OnCastBarShow("AloftCastBar:UpdateAll", aloftData)
		end
	end
end

-----------------------------------------------------------------------------

function AloftCastBar:OnInitialize()
	if self.db ~= Aloft.AloftDB:GetNamespace(self.namespace, true) then self.db = Aloft.AloftDB:RegisterNamespace(self.namespace, self.defaults) end
end

function AloftCastBar:OnEnable()
	self:UnregisterAllEvents()
	self:UnregisterAllMessages()
	self:CancelAllTimers()

	AloftCastWarning = Aloft:GetModule("CastWarning", true) -- optional

	self:RegisterMessage("Aloft:SetupFrame", "SetupFrame")
	self:RegisterMessage("Aloft:OnNameplateShow", "OnNameplateShow")
	self:RegisterMessage("Aloft:OnNameplateHide", "OnNameplateHide")
	self:RegisterMessage("Aloft:OnCastBarShow", "OnCastBarShow")
	self:RegisterMessage("Aloft:OnCastBarHide", "OnCastBarHide")
	self:RegisterMessage("Aloft:OnCastBarValueChanged", "Update")

	self:RegisterMessage("Aloft:OnIsTargetDataChanged", "OnIsTargetDataChanged")
	self:RegisterMessage("Aloft:OnConfigModeChanged", "OnConfigModeChanged")

	self:RegisterEvent("CVAR_UPDATE", "OnCVarUpdate")

	self:RegisterMessage("SharedMedia_SetGlobal", function(message, mediatype, override)
		if mediatype == "statusbar" then
			self:UpdateAll()
		end
	end)

	self:RegisterMessage("Aloft:SetAll", function(message, type, value)
		if AloftCastBar.db.profile[type] then
			AloftCastBar.db.profile[type] = value

			-- special cases for "noInterrupt" side of things
			if type == "texture" then
				AloftCastBar.db.profile.nointerTexture = value
			elseif type == "border" then
				AloftCastBar.db.profile.nointerBorder = value
			end

			self:UpdateAll()
		end
	end)

	self:UpdateAll()
end

function AloftCastBar:OnDisable()
	self:UnregisterAllEvents()
	self:UnregisterAllMessages()
	self:CancelAllTimers()

	for aloftData in Aloft:IterateNameplates() do
		local nameplateFrame = aloftData.nameplateFrame
		local castBar = aloftData.castBar

		castBar:ClearAllPoints()
		castBar:SetPoint("BOTTOMRIGHT", aloftData.castBarOverlayRegion, "BOTTOMRIGHT", -4.5, 4.5)
		castBar:SetWidth(116.5)
		castBar:SetHeight(10.18)
		castBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
		castBar:SetBackdrop(defaultBackdropTable)
		castBar:SetBackdropColor(0, 0, 0, 0)
		castBar:SetBackdropBorderColor(0, 0, 0, 0)

		castBar:SetFrameLevel(nameplateFrame:GetFrameLevel())

		local castFrame = aloftData.castFrame
		if castFrame then castFrame:Hide() end
		-- castBar:Show()

		-- TODO: hide castFrame
	end
end

function AloftCastBar:IsDisplayEnabled()
	-- ChatFrame7:AddMessage("AloftCastBar:IsDisplayEnabled(): " .. tostring(type(GetCVar("ShowVKeyCastbar"))) .. "/" .. tostring(GetCVar("ShowVKeyCastbar")) .. "/" .. tostring(GetCVar("ShowVKeyCastbar") == "1"))
	return Aloft:GetNameplateCVar("ShowVKeyCastbar") and not (AloftCastWarning and AloftCastWarning:IsEnabled() and AloftCastWarning.db and AloftCastWarning.db.profile and AloftCastWarning.db.profile.enable)
end

function AloftCastBar:OnCVarUpdate(event, name, value)
	ChatFrame7:AddMessage("AloftCastBar:OnCVarUpdate(): " .. tostring(event) .. "/" .. tostring(name) .. "/" .. tostring(type(value)) .. "/" .. tostring(value))
end

-----------------------------------------------------------------------------

function AloftCastBar:AcquireCastFrame(aloftData)
	local layoutFrame = aloftData.layoutFrame
	if not layoutFrame then
		layoutFrame = Aloft:AcquireLayoutFrame(aloftData)
	end
	if not layoutFrame then
		ChatFrame7:AddMessage("AloftCastBar:AcquireCastFrame(): no layoutFrame " .. tostring(aloftData.name))
		ChatFrame7:AddMessage("AloftCastBar:AcquireCastFrame(): " .. debugstack())
	end

	local castFrame = aloftData.castFrame
	if not castFrame then
		castFrame = next(self.castFramePool)
		if castFrame then
			self.castFramePool[castFrame] = nil
		else
			-- ChatFrame7:AddMessage("Aloft:AcquireCastFrame(): " .. tostring(aloftData.name) .. "/" .. tostring(nameplateFrame:GetFrameLevel()))
			castFrame = CreateFrame("Frame", nil, layoutFrame) -- NOTE: needs a parent for frame layering/Frame:SetFrameLevel() to work correctly
		end

		aloftData.castFrame = castFrame
		castFrame.aloftData = aloftData

		castFrame.noInterrupt = nil
		castFrame.width = 0

		local nameplateFrame = aloftData.nameplateFrame
		castFrame:SetParent(layoutFrame) -- NOTE: needs a parent for frame layering/Frame:SetFrameLevel() to work correctly
		castFrame:SetFrameLevel(nameplateFrame:GetFrameLevel() + 1)
	end

	-- castFrame:Hide()
	-- ChatFrame7:AddMessage("Aloft:AcquireCastFrame(): show layout frame " .. tostring(aloftData.name) .. "/" .. tostring(aloftData) .. "/" .. tostring(aloftData.layoutFrame))

	return castFrame
end

function AloftCastBar:NeedsBorder(aloftData, noInterrupt)
	if noInterrupt then
		return self.db.profile.nointerBorder ~= "None"
	else
		return self.db.profile.border ~= "None"
	end
end

function AloftCastBar:GetBorder(aloftData, noInterrupt)
	if noInterrupt then
		return ((self.db.profile.nointerBorder ~= "None") and self.db.profile.nointerBorderInset) or 0, SML:Fetch("border", self.db.profile.nointerBorder)
		-- return 0, SML:Fetch("border", "None")
	else
		return ((self.db.profile.border ~= "None") and self.db.profile.borderInset) or 0, SML:Fetch("border", self.db.profile.border)
		-- return 0, SML:Fetch("border", "None")
	end
end

function AloftCastBar:SetupFrame(message, aloftData)
	self:DoSetupFrame(aloftData)
end

function AloftCastBar:DoSetupFrame(aloftData)
	local castFrame = aloftData.castFrame
	if castFrame then
		local texture, color, backdropColor, borderColor
		if castFrame.noInterrupt then
			texture = SML:Fetch("statusbar", self.db.profile.nointerTexture)
			color = self.db.profile.nointerColor
			backdropColor = self.db.profile.nointerBackdropColor
			borderColor = self.db.profile.nointerBorderColor
			-- ChatFrame7:AddMessage("AloftCastBar:SetupFrame(): noInterrupt " .. tostring(aloftData.name))
		else
			texture = SML:Fetch("statusbar", self.db.profile.texture)
			color = self.db.profile.color
			backdropColor = self.db.profile.backdropColor
			borderColor = self.db.profile.borderColor
			-- ChatFrame7:AddMessage("AloftCastBar:SetupFrame(): interrupt " .. tostring(aloftData.name))
		end
		local inset, edgeFile = self:GetBorder(aloftData, castFrame.noInterrupt)

		local castRegion = castFrame.castRegion
		if not castRegion then
			castRegion = castFrame:CreateTexture(nil, "ARTWORK")
			castRegion:SetBlendMode("DISABLE")

			castFrame.castRegion = castRegion
			castRegion.castFrame = castFrame
		end

		castRegion:SetParent(castFrame) -- TODO: redundant
		castRegion:SetTexture(texture)
		castRegion:SetVertexColor(unpack(color))

		castRegion:ClearAllPoints()
		castRegion:SetPoint("TOPLEFT", castFrame, "TOPLEFT", inset, -inset)
		castRegion:SetPoint("BOTTOMLEFT", castFrame, "BOTTOMLEFT", inset, inset)
		castRegion:Show()
		-- ChatFrame7:AddMessage("AloftCastBar:SetupFrame(): " .. tostring(aloftData.name) .. "/" .. tostring(castRegion:GetTexture()))

		backdropTable.insets.left = inset
		backdropTable.insets.right = inset
		backdropTable.insets.top = inset
		backdropTable.insets.bottom = inset
		backdropTable.edgeFile = edgeFile
		backdropTable.edgeSize = (castFrame.noInterrupt and self.db.profile.nointerBorderEdgeSize) or self.db.profile.borderEdgeSize
		backdropTable.bgFile = texture

		-- ChatFrame7:AddMessage("AloftCastBar:SetupFrame(): backdrop")
		castFrame:SetBackdrop(defaultBackdropTable)
		castFrame:SetBackdropColor(0, 0, 0, 0.1) -- set a bogus color (basically clears the default/residual color), non-transparent (to force a draw)
		castFrame:SetBackdropBorderColor(0, 0, 0, 0.1) -- set a bogus color (basically clears the default/residual color), non-transparent (to force a draw)

		-- frame delay to set the real color and show; 2010/11/05 frame delay verified as required, flipping the color inline does not have any effect
		self:ScheduleTimer(function(aloftData) AloftCastBar:DoSetupCastBarBackdrop(aloftData) end, 0.0, aloftData) -- next frame

		--[[
		local sr, sg, sb, sa = aloftData.castBarShieldRegion:GetVertexColor()
		ChatFrame7:AddMessage("AloftCastBar:DoSetupFrame(): " .. tostring(aloftData.name) .. "|"
			.. "|" .. tostring(sr) .. "-" .. tostring(sg) .. "-" .. tostring(sb) .. "-" .. tostring(sa)
				.. "/" .. floor(256*sr) .. "." .. floor(256*sg) .. "." .. floor(256*sb) .. "." .. floor(256*sa)
				.. "/" .. ("|c%02x%02x%02x%02xshield color|r"):format(floor(256*sa), floor(256*sr), floor(256*sg), floor(256*sb)))
		]]

		-- this manipulates the cast bar background always display above the frame background
		local _, _, _, _, backgroundRegion = castFrame:GetRegions()

		if backgroundRegion and backgroundRegion.SetBlendMode then
			-- NOTE: as the castFrame has regions added to it, for name text/time text, backgroundRegion will eventually appear in the correct region location
			-- TODO: kludgy, do something about this
			backgroundRegion:SetDrawLayer("BACKGROUND") -- TODO: redundant
			backgroundRegion:SetBlendMode("BLEND")
			-- backgroundRegion:SetParent(castFrame) -- TODO: redundant

			backgroundRegion:Show()
			-- ChatFrame7:AddMessage("AloftCastBar:SetupFrame(): background region " .. tostring(aloftData.name) .. "/" .. tostring(backgroundRegion:GetTexture()))
		else
			-- ChatFrame7:AddMessage("AloftCastBar:DoSetupFrame(): no background region " .. tostring(aloftData.name) .. "/" .. tostring(castFrame:GetNumRegions()))
		end

		local layoutFrame = aloftData.layoutFrame
		if not layoutFrame then
			layoutFrame = Aloft:AcquireLayoutFrame(aloftData)
		end
		if not layoutFrame then
			ChatFrame7:AddMessage("AloftCastBar:DoSetupFrame(): no layoutFrame " .. tostring(aloftData.name))
			ChatFrame7:AddMessage("AloftCastBar:DoSetupFrame(): " .. debugstack())
		end

		castFrame:ClearAllPoints()
		castFrame:SetPoint("TOPLEFT", layoutFrame, "TOPLEFT", self.db.profile.offsets.left - inset, self.db.profile.offsets.vertical + inset)
		castFrame:SetPoint("BOTTOMRIGHT", layoutFrame, "TOPRIGHT", self.db.profile.offsets.right + inset, self.db.profile.offsets.vertical - self.db.profile.height - inset)
	end
end

-- configure backdrop/borders after a frame delay
function AloftCastBar:DoSetupCastBarBackdrop(aloftData)
	local castFrame = aloftData.castFrame
	if castFrame then
		local texture, backdropColor, borderColor
		if castFrame.noInterrupt then
			texture = SML:Fetch("statusbar", self.db.profile.nointerTexture)
			backdropColor = self.db.profile.nointerBackdropColor
			borderColor = self.db.profile.nointerBorderColor
			-- ChatFrame7:AddMessage("AloftCastBar:DoSetupCastBarBackdrop(): noInterrupt " .. tostring(aloftData.name))
		else
			texture = SML:Fetch("statusbar", self.db.profile.texture)
			backdropColor = self.db.profile.backdropColor
			borderColor = self.db.profile.borderColor
			-- ChatFrame7:AddMessage("AloftCastBar:DoSetupCastBarBackdrop(): interrupt " .. tostring(aloftData.name))
		end
		local inset, edgeFile = self:GetBorder(aloftData, castFrame.noInterrupt)

		backdropTable.insets.left = inset
		backdropTable.insets.right = inset
		backdropTable.insets.top = inset
		backdropTable.insets.bottom = inset
		backdropTable.edgeFile = edgeFile
		backdropTable.edgeSize = self.db.profile.borderEdgeSize
		backdropTable.bgFile = texture

		castFrame:SetBackdrop(backdropTable)

		-- NOTE: hiding default cast bar via alpha does not seem to effect the alpha of bar/background colors
		local r, g, b, a = unpack(backdropColor)
		local _, _, _, castBarAlpha = aloftData.castBar:GetStatusBarColor()
		a = a * castBarAlpha

		castFrame:SetBackdropColor(r, g, b, a)
		castFrame:SetBackdropBorderColor(unpack(borderColor))

		-- ChatFrame7:AddMessage("AloftCastBar:DoSetupCastBarBackdrop(): " .. tostring(aloftData.name)
		-- 	.. "|" .. tostring(floor(r*256)) .. "/" .. tostring(floor(g*256)) .. "/" .. tostring(floor(b*256)) .. "/" .. tostring(floor(a*256))
		-- 	.. "|" .. ("|c%02x%02x%02x%02xbackdrop color|r"):format(floor(256*a), floor(256*r), floor(256*g), floor(256*b)))
	end
end

function AloftCastBar:ReleaseCastFrame(aloftData)
	-- ChatFrame7:AddMessage("AloftCastBar:ReleaseCastFrame(): release " .. aloftData.name)

	-- self:CancelAllTimers()
	self:CleanupCastFrame(aloftData)
	self:RePoolCastFrame(aloftData)
end

function AloftCastBar:CleanupCastFrame(aloftData)
	local castFrame = aloftData.castFrame
	if castFrame then
		castFrame.noInterrupt = nil
		castFrame.width = 0

		self:ClearBackdrop(castFrame)
		castFrame:Hide()
		-- ChatFrame7:AddMessage("AloftCastBar:CleanupCastFrame(): ----- CLEAR " .. tostring(aloftData.name) .. "/" .. tostring(aloftData) .. "/" .. tostring(castFrame))
	end
end

function Aloft:RePoolCastFrame(aloftData)
	local castFrame = aloftData.castFrame
	if castFrame then
		castFrame:Hide()

		castFrame.aloftData = nil
		aloftData.castFrame = nil
		-- ChatFrame7:AddMessage("Aloft:RePoolCastFrame(): " .. tostring(aloftData) .. "/" .. tostring(aloftData.name))

		castFrame:SetParent(nil) -- probably a NOOP for reference frames
		self.castFramePool[castFrame] = true
	end
end

function AloftCastBar:ClearBackdrop(castFrame)
	if castFrame then
		-- ChatFrame7:AddMessage("AloftCastBar:ClearBackdrop(): clear")
		castFrame:SetBackdropColor(0, 0, 0, 0)
		castFrame:SetBackdropBorderColor(0, 0, 0, 0)

		-- NOTE: doing this on nameplate hide may case #132 crashes
		-- castFrame:SetBackdrop(defaultBackdropTable)
	end
end

-----------------------------------------------------------------------------

function AloftCastBar:OnNameplateShow(message, aloftData)
	-- ChatFrame7:AddMessage("AloftCastBar:OnNameplateShow(): show " .. tostring(aloftData.name))
	local castFrame = aloftData.castFrame
	if castFrame then
		castFrame:Hide() -- hide when the nameplate becomes visible; if spellcast activity is underway, it will be shown again
	end
end

function AloftCastBar:OnNameplateHide(message, aloftData)
	-- ChatFrame7:AddMessage("AloftCastBar:OnNameplateHide(): hide " .. tostring(aloftData.name))
end

-- NOTE: when cast bar is disabled (i.e. via Blizzard "Combat>Cast Bar>On Nameplates"),
--       Blizzard delivers an "OnShow" event, followed immediately by an "OnHide" event, and no "OnValueChanged" events;
--       and apparently, in the process, it shows the default target spell cast icon for a few frames, and leaves it
function AloftCastBar:OnCastBarShow(message, aloftData)
	-- ChatFrame7:AddMessage("AloftCastBar:OnCastBarShow(): enter " .. tostring(aloftData.name))

	local castBar = aloftData.castBar
	if castBar then castBar:SetAlpha(0.0) end -- always hide the Blizzard cast bar, regardless of other outcome

	if self:IsDisplayEnabled() then
		if Aloft:IsConfigModeEnabled() and (aloftData.isTarget or aloftData:IsTarget()) then
			local castFrame = self:AcquireCastFrame(aloftData)
			castFrame.noInterrupt = true

			self:DoSetupFrame(aloftData)
			castFrame:Show() -- NOTE: needs to be made visible here to insure that other modules can detect IsVisible and provide their elements

			-- ChatFrame7:AddMessage("AloftCastBar:OnCastBarShow(): config " .. tostring(aloftData.name) .. "/" .. tostring(castFrame:GetFrameLevel()))
			return
		else
			local castFrame = self:AcquireCastFrame(aloftData)
			castFrame.noInterrupt = (castBar.castBarShieldRegion:IsShown() and true) or nil
			-- ChatFrame7:AddMessage("AloftCastBar:OnCastBarShow(): noInterrupt " .. tostring(aloftData.name) .. "/" .. tostring(castFrame.noInterrupt))

			self:DoSetupFrame(aloftData)
			castFrame:Show()

			return
		end
	else
		-- ChatFrame7:AddMessage("AloftCastBar:OnCastBarShow(): disabled")
	end

	-- ChatFrame7:AddMessage("AloftCastBar:OnCastBarShow(): hide " .. tostring(aloftData.name) .. "/" .. tostring(castFrame and castFrame:GetFrameLevel()))
	-- if Aloft:IsConfigModeEnabled() then ChatFrame7:AddMessage("AloftCastBar:OnCastBarShow(): release " .. tostring(aloftData.name) .. "/" .. tostring(debugstack(1, 100, 100))) end
	self:ReleaseCastFrame(aloftData)
end

function AloftCastBar:OnCastBarHide(message, aloftData)
	-- ChatFrame7:AddMessage("AloftCastBar:OnCastBarHide(): enter " .. tostring(aloftData.name))
	self:ReleaseCastFrame(aloftData)
end

function AloftCastBar:OnIsTargetDataChanged(message, aloftData)
	if Aloft:IsConfigModeEnabled() and (aloftData.isTarget or aloftData:IsTarget()) then
		-- ChatFrame7:AddMessage("AloftCastBar:OnIsTargetDataChanged(): enter " .. tostring(aloftData.name) .. "/" .. tostring(aloftData.isTarget))
		self:ScheduleTimer(function(aloftData) AloftCastBar:OnCastBarShow("AloftCastBar:OnIsTargetDataChanged", aloftData) end, 0.0, aloftData) -- next frame
		-- NOTE: currently, this is really only used by "preview" mode, so the degree of delay here is not a big deal
	else
		-- ChatFrame7:AddMessage("AloftCastBar:OnIsTargetDataChanged(): release " .. tostring(aloftData.name) .. "/" .. tostring(aloftData.isTarget))
		-- self:ReleaseCastFrame(aloftData)
	end
end

function AloftCastBar:OnConfigModeChanged(message)
	local aloftData = Aloft:GetTargetNameplate()
	if aloftData then
		if Aloft:IsConfigModeEnabled() then
			self:OnCastBarShow("AloftBossIcon:OnConfigModeChanged", aloftData)
		else
			-- ChatFrame7:AddMessage("AloftCastBar:OnConfigModeChanged(): release " .. tostring(aloftData.name) .. "/" .. tostring(aloftData.isTarget))
			self:ReleaseCastFrame(aloftData)
		end
	end
end

-----------------------------------------------------------------------------

function AloftCastBar:CalculateFrameWidth(aloftData, castFrame)
	local inset, _ = self:GetBorder(aloftData, castFrame.noInterrupt)

	-- by hook or by crook, value must end up non-nil
	local castBar = aloftData.castBar
	local value = castBar:GetValue() or 0.0
	local minValue, maxValue = castBar:GetMinMaxValues()
	local width = ((maxValue and maxValue > 0) and (value / maxValue) * (castFrame:GetWidth() - (2 * inset))) or 0

	return minValue, value, maxValue, width
end

function AloftCastBar:Update(message, aloftData)
	-- ChatFrame7:AddMessage("AloftCastBar:Update(): enter " .. tostring(aloftData.name))

	local castBar = aloftData.castBar
	if castBar then castBar:SetAlpha(0.0) end -- always hide the Blizzard cast bar, regardless of other outcome

	local castFrame = self:AcquireCastFrame(aloftData)
	if castFrame and self:IsDisplayEnabled() then
		if Aloft:IsConfigModeEnabled() and (aloftData.isTarget or aloftData:IsTarget()) then
			local inset, _ = self:GetBorder(aloftData, true)
			local width = 0.7 * (castFrame:GetWidth() - (2 * inset))
			-- ChatFrame7:AddMessage("AloftCastBar:Update(): config " .. tostring(aloftData.name) .. "/" .. tostring(castFrame:GetWidth()) .. "/" .. tostring(width))

			castFrame.width = width
			self:DoShowCastFrame(aloftData)

			-- ChatFrame7:AddMessage("AloftCastBar:Update(): config " .. tostring(aloftData.name) .. "/" .. tostring(castFrame:GetFrameLevel()))
			return
		elseif aloftData.nameplateFrame:IsVisible() and (not aloftData.alphaOverride or aloftData.alphaOverride > 0) then
			-- ChatFrame7:AddMessage("AloftCastBar:Update(): casting " .. tostring(aloftData.name))
			local minValue, value, maxValue, width = self:CalculateFrameWidth(aloftData, castFrame)
			-- ChatFrame7:AddMessage("AloftCastBar:Update(): " .. tostring(aloftData.name) .. "/" .. tostring(minValue) .. "<" .. tostring(value) .. "<" .. tostring(maxValue) .. "/" .. tostring(width))
			-- ChatFrame7:AddMessage("AloftCastBar:Update(): width " .. tostring(aloftData.name) .. "/" .. tostring(value) .. "/" .. tostring(width))
			if width and width >= 0 then
				-- ChatFrame7:AddMessage("AloftCastBar:Update(): draw " .. tostring(aloftData.name) .. "/" .. tostring(value) .. "/" .. tostring(width))

				--[[
				if AloftCastBar:NeedsBorder(aloftData, noInterrupt) and self.db.profile.incremental and (not castFrame.init or castFrame.init < BORDER_INIT_ATTEMPTS) then
					castRegion:SetWidth(1) -- width is initially bogus, updated after a frame delay below
				end
				]]
				castFrame.width = width

				if AloftCastBar:NeedsBorder(aloftData, castBar.castBarShieldRegion:IsShown()) and self.db.profile.incremental then
					-- frame delay to set the real width; hopefully avoids the "missing/malformed border" issue
					self:ScheduleTimer(function(aloftData) AloftCastBar:DoShowCastFrame(aloftData) end, 0.0, aloftData) -- one frame
				else
					self:DoShowCastFrame(aloftData)
				end

				return
			end
		end
	else
		-- ChatFrame7:AddMessage("AloftCastBar:Update(): disabled or not target")
	end

	-- ChatFrame7:AddMessage("AloftCastBar:Update(): hide " .. tostring(aloftData.name) .. "/" .. tostring(castFrame:GetFrameLevel()))
	-- if Aloft:IsConfigModeEnabled() then ChatFrame7:AddMessage("AloftCastBar:Update(): hide " .. tostring(aloftData.name)) end
	self:ReleaseCastFrame(aloftData)
end

function AloftCastBar:DoShowCastFrame(aloftData)
	local castFrame = aloftData and aloftData.castFrame
	local castRegion = castFrame and castFrame.castRegion

	-- ChatFrame7:AddMessage("AloftCastBar:DoShowCastFrame(): region " .. tostring(castFrame.castRegion))
	if castFrame then
		castFrame.castRegion:SetWidth(castFrame.width)

		-- local r, g, b, a = castFrame:GetBackdropColor()
		-- ChatFrame7:AddMessage("AloftCastBar:DoShowCastFrame(): "
		-- 	.. tostring(floor(r*256)) .. "/" .. tostring(floor(g*256)) .. "/" .. tostring(floor(b*256)) .. "/" .. tostring(floor(a*256))
		-- 	.. "/" .. ("|c%02x%02x%02x%02xbackdrop color|r"):format(floor(256*a), floor(256*r), floor(256*g), floor(256*b)))

		-- flag as having been through the first frame-delay
		-- if not castFrame.init then
		--	castFrame.init = 0
		-- else
		--	castFrame.init = castFrame.init + 1
		-- end

		-- ChatFrame7:AddMessage("AloftCastBar:DoShowCastFrame(): show " .. tostring(aloftData.name) .. "/" .. tostring(castFrame.width))
		castFrame:Show()
	end
end

-----------------------------------------------------------------------------

function AloftCastBar:GetTargetSpellInfo()
	local now = GetTime() * 1000 -- convert to milliseconds

	local _, rank, displayName, _, startTime, endTime, _, castId, noInterrupt = UnitCastingInfo("target")
	if displayName then
		local elapsedTime = now - startTime
		-- ChatFrame7:AddMessage("AloftCastBar:GetTargetSpellInfo(): casting " .. tostring(UnitName("target")) .. "/" .. tostring(displayName) .. "/" .. tostring(castId) .. "/" .. tostring(endTime) .. "/" .. tostring(noInterrupt))
		return displayName, rank, elapsedTime, endTime, noInterrupt
	end
	_, rank, displayName, _, startTime, endTime, _, noInterrupt = UnitChannelInfo("target")
	if displayName then
		local elapsedTime = endTime - startTime - (now - startTime)
		-- ChatFrame7:AddMessage("AloftCastBar:GetTargetSpellInfo(): channel " .. tostring(UnitName("target")) .. "/" .. tostring(displayName) .. "/" .. tostring(castId) .. "/" .. tostring(endTime) .. "/" .. tostring(noInterrupt))
		return displayName, rank, elapsedTime, endTime, noInterrupt
	end
	return nil, nil, nil, nil
end

function AloftCastBar:IsTargetCasting()
	local name, _, _, _, _, _, _, _, _ = UnitCastingInfo("target")
	if not name then
		name, _, _, _, _, _, _, _ = UnitChannelInfo("target")
	end
	return name
end

-----------------------------------------------------------------------------
