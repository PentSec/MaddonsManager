local Aloft = Aloft
if not Aloft then return end
local AloftModules = AloftModules
if not AloftModules then return end

-----------------------------------------------------------------------------

AloftModules:AddInitializer("AloftCastBarSpellNameText", function()

-----------------------------------------------------------------------------

local AloftCastBar = Aloft:GetModule("CastBar") -- always on
if not AloftCastBar then return end

local AloftSpellNameText = Aloft:NewModule("SpellNameText", Aloft, "AceEvent-3.0")
AloftSpellNameText.dynamic = "AloftCastBarSpellNameText"

-----------------------------------------------------------------------------

AloftSpellNameText.namespace = "spellNameText"
AloftSpellNameText.defaults =
{
	profile =
	{
		enable			= true,
		font			= "Arial Narrow",
		fontSize		= 9,
		shadow			= true,
		alignment		= "LEFT",
		outline			= "",
		offsets =
		{
			left		= 16,
			right		= 0,
			vertical	= 0,
		},
		color			= { 1, 1, 1, 1 },
	},
}

-----------------------------------------------------------------------------

function AloftSpellNameText:Update()
	self:RegisterEvents()

	if self.db.profile.enable then
		for aloftData in Aloft:IterateVisibleNameplates() do
			self:SetupFrame("AloftSpellNameText:Update", aloftData)
		end
	end
end

-----------------------------------------------------------------------------

function AloftSpellNameText:RegisterEvents()
	self:UnregisterAllEvents()
	self:UnregisterAllMessages()
	self:CancelAllTimers()

	if self.db.profile.enable then
		self:RegisterMessage("Aloft:SetupFrame", "SetupFrame")
		self:RegisterMessage("Aloft:OnNameplateHide", "OnNameplateHide")
		self:RegisterMessage("Aloft:OnCastBarShow", "OnCastBarShow")
		self:RegisterMessage("Aloft:OnCastBarHide", "OnCastBarHide")
		self:RegisterMessage("Aloft:OnCastBarValueChanged", "UpdateText")
	end
end

-----------------------------------------------------------------------------

function AloftSpellNameText:OnInitialize()
	if self.db ~= Aloft.AloftDB:GetNamespace(self.namespace, true) then self.db = Aloft.AloftDB:RegisterNamespace(self.namespace, self.defaults) end

	self.initialized = true
end

function AloftSpellNameText:OnEnable()
	-- Ace3 now calls OnInitialize only if the addon is available at time of ADDON_LOADED?
	if not self.initialized then self:OnInitialize() end

	self:UnregisterAllEvents()
	self:UnregisterAllMessages()
	self:CancelAllTimers()

	self:RegisterMessage("Aloft:SetAll", function(message, type, value)
		if AloftSpellNameText.db.profile[type] then
			AloftSpellNameText.db.profile[type] = value
			self:Update()
		end
	end)

	self:Update()
end

function AloftSpellNameText:OnDisable()
	self:UnregisterAllEvents()
	self:UnregisterAllMessages()
	self:CancelAllTimers()
end

function AloftSpellNameText:SetupFrame(message, aloftData)
	if not self:IsDisplayEnabled() then return nil end

	local castFrame = aloftData.castFrame
	if castFrame then
		local spellNameText = castFrame.spellNameText
		if not spellNameText then
			spellNameText = castFrame:CreateFontString(nil, "OVERLAY")

			castFrame.spellNameText = spellNameText
			spellNameText.castFrame = castFrame
		end

		self:PrepareText(spellNameText, self.db.profile)

		spellNameText:ClearAllPoints()
		spellNameText:SetPoint("TOPLEFT", castFrame, "TOPLEFT", self.db.profile.offsets.left, self.db.profile.offsets.vertical)
		spellNameText:SetPoint("BOTTOMRIGHT", castFrame, "BOTTOMRIGHT", self.db.profile.offsets.right, self.db.profile.offsets.vertical)
		spellNameText:SetText("")

		spellNameText:Hide() -- TODO: kludgy

		return spellNameText
	end

	return nil
end

function AloftSpellNameText:IsDisplayEnabled()
	-- ChatFrame7:AddMessage("AloftSpellNameText:IsDisplayEnabled(): " .. tostring(type(GetCVar("ShowVKeyCastbarSpellName"))) .. "/" .. tostring(AloftCastBar:IsDisplayEnabled()))
	return Aloft:GetNameplateCVar("ShowVKeyCastbarSpellName") and AloftCastBar:IsDisplayEnabled()
end

function AloftSpellNameText:UpdateText(message, aloftData)
	local text = ""
	local castBar = aloftData.castBar
	if Aloft:IsConfigModeEnabled() and (aloftData.isTarget or aloftData:IsTarget()) then
		text = "Spell Name"
	elseif AloftSpellNameText:IsDisplayEnabled() then
		text = castBar.spellNameText:GetText() or ""
	end

	if self:IsDisplayEnabled() then
		local spellNameText = self:SetupFrame(message, aloftData)
		if text and spellNameText then	
			spellNameText:SetText(text)
			spellNameText:Show()

			-- ChatFrame7:AddMessage("AloftSpellNameText:UpdateText(): " .. tostring(aloftData.name) .. "/" .. tostring(spellNameText:GetText()))
			-- if Aloft:IsConfigModeEnabled() and (aloftData.isTarget or aloftData:IsTarget()) then ChatFrame7:AddMessage("AloftSpellNameText:UpdateText(): config " .. tostring(aloftData.name)) end

			return
		end
	end

	self:OnCastBarHide(message, aloftData)
end

function AloftSpellNameText:OnNameplateHide(message, aloftData)
	self:OnCastBarHide(message, aloftData)
end

function AloftSpellNameText:OnCastBarShow(message, aloftData)
	-- ChatFrame7:AddMessage("AloftSpellNameText:OnCastFrameShow(): enter " .. tostring(aloftData.name))

	if 	self:IsDisplayEnabled() then
		local spellNameText = self:SetupFrame(message, aloftData)
		if spellNameText then
			spellNameText:Show()
			return
		end
	end

	self:OnCastBarHide(message, aloftData)
end

function AloftSpellNameText:OnCastBarHide(message, aloftData)
	-- ChatFrame7:AddMessage("AloftSpellNameText:OnCastFrameHide(): hide")

	local spellNameText = self:SetupFrame(message, aloftData)
	if spellNameText then
		spellNameText:Hide()
	end
end

-----------------------------------------------------------------------------

end)
