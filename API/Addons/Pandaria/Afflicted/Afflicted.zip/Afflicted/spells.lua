AfflictedSpells = {}
AfflictedSpells.version = 13

function AfflictedSpells:GetData()
	if( self.spells ) then
		return self.spells
	end
	
	self.spells = {
		-- Death Knight
		-- Strangulate
		[47476] = "{cooldown=60;cdAnchor='interrupts';class='DEATHKNIGHT';}",
		--Asphyxiate
		[108194] = "{cooldown=30;cdAnchor='interrupts';class='DEATHKNIGHT';}",
		-- Icebound Fortitude
		[48792] = "{type='buff';disabled=true;duration=12;cooldown=180;cdDisabled=true;anchor='defenses';cdAnchor='cooldowns';class='DEATHKNIGHT';}",
		-- Mind Freeze
		[47528] = "{cooldown=15;cdAnchor='interrupts';class='DEATHKNIGHT';}",
		-- Anti-Magic Shell
		[48707] = "{cdDisabled=true;type='buff';disabled=true;duration=5;cooldown=45;anchor='defenses';cdAnchor='cooldowns';class='DEATHKNIGHT';}",
		-- Death Grip
		[49576] = "{cdDisabled=true;cooldown=25;cdAnchor='spells';class='DEATHKNIGHT';}",
		-- Anti-Magic Zone
		[51052] = "{disabled=true;duration=10;anchor='defenses';cooldown=120;cdDisabled=true;cdAnchor='cooldowns';class='DEATHKNIGHT';}",
		-- Dancing Rune Weapon
		[49028] = "{disabled=true;duration=12;anchor='damage';cooldown=90;cdDisabled=true;cdAnchor='cooldowns';class='DEATHKNIGHT';}",
		-- Lichborne
		[49039] = "{type='buff';duration=10;anchor='defenses';cooldown=120;cdDisabled=true;cdAnchor='cooldowns';class='DEATHKNIGHT';}",
		-- Vampiric Blood
		[55233] = "{type='buff';duration=10;anchor='defenses';cooldown=60;cdDisabled=true;cdAnchor='cooldowns';class='DEATHKNIGHT';}",
		-- Leap (Ghoul)
		[47482] = "{cooldown=30;cdDisabled=true;cdAnchor='spells';class='DEATHKNIGHT';}",
		-- Gnaw (Ghoul)
		[47481] = "{cooldown=60;cdDisabled=true;cdAnchor='spells';class='DEATHKNIGHT';}",
		-- Death's Advance
		[96268] =  "{disabled=true;duration=6;anchor='buff';cooldown=30;cdDisabled=true;cdAnchor='cooldowns';class='DEATHKNIGHT';}",
		-- Death Pact
		[48743] =  "{cdDisabled=true;cooldown=120;cdAnchor='spells';class='DEATHKNIGHT';}",
		
		-- Paladin
		--Rebuke
		[96231] = "{cooldown=15;cdAnchor='interrupts';class='PALADIN';}",
		-- Divine Plea
		[54428] = "{type='buff';disabled=true;duration=9;anchor='buffs';cooldown=120;cdDisabled=true;cdAnchor='cooldowns';class='PALADIN';}",
		-- Avenging Wrath
		[31884] = "{type='buff';duration=20;anchor='damage';cooldown=120;cdDisabled=true;cdAnchor='cooldowns';class='PALADIN';}",
		-- Hammer of Justice
		[853] = "{cooldown=60;cdDisabled=true;cdAnchor='cooldowns';class='PALADIN';}",
		-- Hand of Protection
		[1022] = "{type='buff';duration=10;anchor='defenses';cdDisabled=true;cooldown=300;cdAnchor='cooldowns';class='PALADIN';}",
		-- Divine Shield
		[642] = "{type='buff';duration=8;anchor='defenses';cooldown=300;cdDisabled=true;cdAnchor='cooldowns';class='PALADIN';}",
		-- Hand of Freedom
		[1044] = "{type='buff';duration=6;anchor='spells';cdDisabled=true;cooldown=20;cdAnchor='cooldowns';class='PALADIN';}",
		-- Hand of Sacrifice
		[6940] = "{disabled=true;type='buff';duration=12;anchor='defenses';cdDisabled=true;cooldown=120;cdAnchor='cooldowns';class='PALADIN';}",
		-- Devotion Aura
		[31821] = "{type='buff';duration=6;anchor='defenses';cooldown=180;cdAnchor='cooldowns';class='PALADIN';}",
		-- Fist of Justice
		[105593] = "{cooldown=30;cdDisabled=true;cdAnchor='cooldowns';class='PALADIN';}",
		-- Repentance
		[20066] = "{cooldown=15;cdDisabled=true;cdAnchor='cooldowns';class='PALADIN';}",
		-- Hand of Purity
		[114039] = "{disabled=true;type='buff';duration=6;anchor='defenses';cdDisabled=true;cooldown=30;cdAnchor='cooldowns';class='PALADIN';}",
		
		-- Warrior
		-- Shield Reflect
		[23920] = "{type='buff';disabled=true;duration=5;cdDisabled=true;cooldown=20;cdAnchor='cooldowns';class='WARRIOR';}",
	        -- Pummel
		[6552] = "{cooldown=15;cdAnchor='interrupts';class='WARRIOR';}",
		-- Intervene
		[3411] = "{cooldown=30;cdDisabled=true;cdAnchor='defenses';class='WARRIOR';}",
		-- Recklessness
		[1719] = "{type='buff';duration=12;anchor='damage';cooldown=300;cdDisabled=true;cdAnchor='cooldowns';class='WARRIOR';}",
		-- Berserker Rage
		[18499] = "{type='buff';disabled=true;duration=6;anchor='spells';cooldown=30;cdAnchor='cooldowns';class='WARRIOR';}",
		-- Shield Wall
		[871] = "{type='buff';disabled=true;duration=12;anchor='defenses';cooldown=300;cdDisabled=true;cdAnchor='cooldowns';class='WARRIOR';}",
		-- Disarm
		[676] = "{cdDisabled=true;cooldown=60;cdAnchor='spells';class='WARRIOR';}",
		-- Heroic Throw
		[57755] = "{cooldown=30;cdAnchor='interrupts';class='WARRIOR';}",
		-- Heroic Leap
		[6544] = "{cooldown=45;cdDisabled=true;cdAnchor='cooldowns';class='WARRIOR';}",
		-- Disrupting Shout
		[102060] = "{cooldown=40;cdAnchor='interrupts';class='WARRIOR';}",
		-- Dragon Roar
		[118000] = "{cooldown=60;cdAnchor='cooldowns';class='WARRIOR';}",
		-- Safeguard
		[114029] = "{cooldown=30;cdDisabled=true;cdAnchor='defenses';class='WARRIOR';}",
		-- Mass Shield Reflect
		[114028] = "{type='buff';disabled=true;duration=5;cdDisabled=true;cooldown=600;cdAnchor='cooldowns';class='WARRIOR';}",
		-- Shockwave
		[46968] = "{cooldown=60;cdAnchor='cooldowns';class='WARRIOR';}",
		
		-- Druid
		-- Survival Instincts
		[61336] = "{type='buff';duration=12;anchor='defenses';cooldown=180;cdDisabled=true;cdAnchor='cooldowns';class='DRUID';}",
		-- Berserk
		[50334] = "{type='buff';duration=15;anchor='damage';cooldown=180;cdDisabled=true;cdAnchor='cooldowns';class='DRUID';}",
		-- Nature's Grasp
		[16689] = "{type='buff';disabled=true;duration=45;anchor='buffs';cooldown=60;cdDisabled=true;cdAnchor='cooldowns';class='DRUID';}",
		-- Innervate
		[29166] = "{type='buff';disabled=true;duration=10;anchor='buffs';cooldown=180;cdDisabled=true;cdAnchor='cooldowns';class='DRUID';}",
		-- Bash
		[5211] = "{cooldown=50;cdDisabled=true;cdAnchor='interrupts';class='DRUID';}",
		-- Skull Bash BEAR
		[80964] = "{cooldown=15;cdAnchor='interrupts';class='DRUID';}",
		-- Skull Bash CAT
		[80965] = "{cooldown=15;cdAnchor='interrupts';class='DRUID';}",
		-- Skull Bash
		[106839] = "{cooldown=15;cdAnchor='interrupts';class='DRUID';}",
		-- Disorienting Roar
		[99] = "{cooldown=30;cdDisabled=true;cdAnchor='cooldowns';class='DRUID';}",
		-- Typhoon
		[132469] = "{cooldown=20;cdAnchor='cooldowns';class='DRUID';}",
		-- Mass Entanglement
		[102359] = "{cooldown=30;cdDisabled=true;cdAnchor='cooldowns';class='DRUID';}",

		
		-- Priest
		-- Hymn of Hope
		[64901] = "{type='buff';duration=8;anchor='buffs';cooldown=360;cdDisabled=true;cdAnchor='cooldowns';class='PRIEST';}",
		-- Dispersion
		[47585] = "{type='buff';duration=6;anchor='defenses';cooldown=75;cdAnchor='cooldowns';class='PRIEST';}",
		-- Guardian Spirit
		[47788] = "{type='buff';duration=10;anchor='defenses';cooldown=150;cdDisabled=true;cdAnchor='cooldowns';class='PRIEST';}",
		-- Pain Suppression
		[33206] = "{type='buff';duration=8;anchor='defenses';cooldown=180;cdDisabled=true;cdAnchor='cooldowns';class='PRIEST';}",
		-- Silence
		[15487] = "{cooldown=45;cdAnchor='interrupts';class='PRIEST';}",
		-- Psychic Scream
		[8122] = "{cooldown=30;cdAnchor='spells';cdDisabled=true;class='PRIEST';}",
		--Strength of Soul
		[89485] = "{type='buff';duration=5;anchor='defenses';cooldown=45;cdAnchor='cooldowns';class='PRIEST';}",
		--Psychic Horror
		[64044] = "{cooldown=45;cdAnchor='spells';cdDisabled=true;class='PRIEST';}",
		
		-- Warlock
		-- Devour Magic (Felhunter)
		[19505] = "{cooldown=15;cdAnchor='spells';cdDisabled=true;class='WARLOCK';}",
		-- Clone Magic (Observer)
		[115284] = "{cooldown=15;cdAnchor='spells';cdDisabled=true;class='WARLOCK';}",
		-- Spell Lock (Felhunter)
		[19647] = "{cooldown=24;cdAnchor='interrupts';class='WARLOCK';}",
		-- Spell Lock (sacrifice)
		[103135] = "{cooldown=24;cdAnchor='interrupts';class='WARLOCK';}",
		-- Optic Blast
		[115781] = "{cooldown=24;cdAnchor='interrupts';class='WARLOCK';}",
		-- Demonic portal
		[48020] = "{cooldown=20;cdAnchor='spells';class='WARLOCK';}",
		-- Fellash
		[115770] = "{cooldown=25;cdAnchor='spells';class='WARLOCK';}",
		-- Whiplash
		[6360] = "{cooldown=25;cdAnchor='spells';class='WARLOCK';}",
		-- Sacced spell lock
		[103135] = "{cooldown=24;cdAnchor='interrupts';class='WARLOCK';}",		
			
		-- Shaman
		-- Hex
		[51514] = "{cooldown=45;cdDisabled=true;cdAnchor='spells';class='SHAMAN'}",
		-- Wind Shear
		[57994] = "{cooldown=12;cdAnchor='interrupts';class='SHAMAN';}",
		-- Tremor Totem
		[8143] = "{type='totem';disabled=true;duration=5;anchor='buffs';repeating=true;cooldown=60;cdAnchor='cooldowns';class='SHAMAN';}",
		-- Shamanistic Rage
		[30823] = "{type='buff';disabled=true;duration=15;anchor='defenses';cooldown=60;cdDisabled=true;cdAnchor='cooldowns';class='SHAMAN';}",
		-- Mana Tide Totem
		[16190] = "{type='totem';disabled=true;duration=12;anchor='buffs';cooldown=300;cdAnchor='cooldowns';class='SHAMAN';}",
		-- Grounding Totem
		[8177] = "{type='totem';disabled=true;duration=15;anchor='buffs';cooldown=25;cdAnchor='cooldowns';class='SHAMAN';}",
		-- Astral Shift
		[108271] = "{type='buff';disabled=true;duration=6;anchor='defenses';cooldown=120;cdDisabled=true;cdAnchor='cooldowns';class='SHAMAN';}",
		-- Thunderstorm
		[51490] = "{cooldown=45;cdAnchor='spells';class='SHAMAN';}",
		
		-- Hunter
		-- Bestial Wrath
		[19574] = "{type='buff';duration=10;anchor='damage';cdDisabled=true;cooldown=60;cdAnchor='cooldowns';class='HUNTER';}",
		-- Wyvern Sting
		[19386] = "{cooldown=60;cdAnchor='cooldowns';class='HUNTER';}",
		-- Silencing Shot
		[34490] = "{cooldown=24;cdAnchor='interrupts';class='HUNTER';}",
		-- Readiness
		[23989] = "{cooldown=180;cdDisabled=true;cdAnchor='cooldowns';resets={49012,34600,63670,19263,3034,14327,34490};class='HUNTER';}",
		-- Nether Shock (Nether Ray)
		[50479] = "{cooldown=40;cdAnchor='interrupts';class='HUNTER';}",
		-- Pin (Crab)
		[50245] = "{cooldown=40;cdDisabled=true;cdAnchor='spells';class='HUNTER';}",
		-- Freezing Trap
		[1499] = "{type='trap';configName='frost';cooldownName='frost';disabled=true;duration=30;anchor='spells';cooldown=30;cdDisabled=true;cdAnchor='cooldowns';class='HUNTER';}",
		-- Deterrence
		[19263] = "{type='buff';duration=5;anchor='defenses';cooldown=120;cdDisabled=true;cdAnchor='cooldowns';class='HUNTER';}",

		
		-- Mage
		-- Cold Snap
		[11958] = "{cooldown=180;cdDisabled=true;cdAnchor='cooldowns';resets={44572,45438};class='MAGE'}",
		-- Deep Freeze
		[44572] = "{cooldown=30;cdAnchor='spells';class='MAGE';}",
		-- Icy Veins
		[12472] = "{type='buff';duration=20;anchor='damage';cooldown=180;cdDisabled=true;cdAnchor='cooldowns';class='MAGE';}",
		-- Invisibility
		[66] = "{disabled=true;duration=23;anchor='defenses';cooldown=90;cdDisabled=true;cdAnchor='cooldowns';class='MAGE';}",
		-- Ice Block
		[45438] = "{type='buff';duration=10;anchor='defenses';cooldown=240;cdDisabled=true;cdAnchor='cooldowns';class='MAGE';}",
		-- Counterspell
		[2139] = "{cooldown=24;cdAnchor='interrupts';class='MAGE';}",
		-- Blink
		[1953] = "{cooldown=15;cdDisabled=true;cdAnchor='cooldowns';class='MAGE';}",
		--Frostjaw
		[102051] = "{cooldown=20;cdAnchor='spells';class='MAGE';}",
		-- Ring of frost
		[113724] = "{duration=10;cooldown=45;cdAnchor='spells';class='MAGE';}",
		
		
		-- Rogue
		-- Kick
		[1766] = "{cooldown=15;cdAnchor='interrupts';class='ROGUE';}",
		-- Kidney Shot
		[408] = "{cooldown=20;cdAnchor='spells';class='ROGUE';}",
		-- Shadow Step
		[36554] = "{disabled=true;duration=3;anchor='buffs';cooldown=24;cdAnchor='cooldowns';class='ROGUE';}",
		-- Adrenaline Rush
		[13750] = "{duration=15;anchor='damage';cooldown=180;cdDisabled=true;cdAnchor='cooldowns';class='ROGUE';}",
		-- Preparation
		[14185] = "{cooldown=300;cdDisabled=true;cdAnchor='cooldowns';resets={1856,51722,2983,5277};class='ROGUE'}",
		-- Cloak of Shadows
		[31224] = "{type='buff';duration=5;anchor='defenses';cooldown=60;cdDisabled=true;cdAnchor='cooldowns';class='ROGUE';}",
		-- Vanish
		[1856] = "{type='buff';disabled=true;duration=10;anchor='defenses';cooldown=180;cdAnchor='cooldowns';class='ROGUE';}",
		-- Sprint
		[2983] = "{type='buff';duration=15;disabled=true;anchor='buffs';cooldown=60;cdAnchor='cooldowns';class='ROGUE';}",
		-- Evasion
		[5277] = "{type='buff';duration=15;anchor='defenses';cooldown=180;cdDisabled=true;cdAnchor='cooldowns';class='ROGUE';}",
		-- Blind
		[2094] = "{cooldown=180;cdAnchor='cooldowns';class='ROGUE';}",
		-- Dismantle
		[51722] = "{cooldown=60;cdDisabled=true;cdAnchor='cooldowns';class='ROGUE';}",
		-- Combat Readiness
		[74001] = "{type='buff';duration=20;anchor='defenses';cooldown=120;cdDisabled=true;cdAnchor='cooldowns';class='ROGUE';}",
		-- Smoke Bomb
		[76577] = "{cooldown=180;cdDisabled=true;cdAnchor='cooldowns';class='ROGUE';}",
		
		-- Monk
		--Transcendence: Transfer
		[119996] = "{cooldown=180;cdDisabled=true;cdAnchor='cooldowns';class='MONK';}",
		--Zen Meditation
		[115176] = "{type='buff';disabled=true;duration=8;anchor='defenses';cooldown=180;cdAnchor='cooldowns';class='MONK';}",
		--Diffuse Magic
		[122783] = "{type='buff';disabled=true;duration=6;anchor='defenses';cooldown=150;cdAnchor='cooldowns';class='MONK';}",
		--Grapple Weapon
		[117368] = "{cooldown=60;cdDisabled=true;cdAnchor='cooldowns';class='MONK';}",
		--Leg Sweep
		[119381] = "{cooldown=45;cdDisabled=true;cdAnchor='cooldowns';class='MONK';}",
		--Ring of Peace
		[116844] = "{duration=8;anchor='spells';cooldown=45;cdAnchor='cooldowns';class='MONK';}",
		--Life Cocoon
		[116849] = "{type='buff';duration=12;anchor='defenses';disabled=true;cooldown=120;cdDisabled=true;cdAnchor='cooldowns';class='MONK';}",
		--Spear Hand Strike
		[116705] = "{cooldown=15;cdAnchor='interrupts';class='MONK';}",
		--Fortifying Brew
		[115203] = "{type='buff';disabled=true;duration=20;anchor='defenses';cooldown=180;cdAnchor='cooldowns';class='MONK';}",
		--Touch of Karma
		[122470] = "{type='buff';duration=10;anchor='spells';cooldown=150;cdAnchor='cooldowns';class='MONK';}",
		--Nimble Brew
		[137562] = "{type='buff';disabled=true;duration=6;anchor='defenses';cooldown=120;cdAnchor='cooldowns';class='MONK';}",
		
		-- Misc
		-- PvP Trinket
		[42292] = "{cooldown=120;cdAnchor='defenses'}",
		-- Escape Artist
		[20589] = "{cooldown=105;cdAnchor='defenses'}",
	}
	
	return self.spells
end

function AfflictedSpells:Verify()
	AfflictedSpells:GetData()
	
	print("Verifying Afflicted database.")
	
	local found
	for id, data in pairs(self.spells) do
		if( not GetSpellInfo(id) ) then
			print(string.format("Spell does not exist %s.", id))
			found = true
		elseif( type(data) == "number" ) then
			if( type(self.spells[data]) ~= "string" ) then
				print(string.format("[%s] is linking to a spell that links to another spell.", id))
				found = true
			end
		elseif( type(data) == "string" ) then
			local tbl, error = loadstring("return " .. data)
			if( type(tbl) ~= "function" ) then
				print(string.format("[%s] = %s", id, error))
				found = true
			end
			
			tbl = tbl()
			
			if( not tbl.class ) then
				print(string.format("No class tag found on %s.", id))
				found = true
			end
		end
	end

	if( not found ) then
		print("All good, no spellIDs missing.")
	end
end

function AfflictedSpells:GetTotemClass(spellName)
	if( not self.totems ) then
		self.totems = {
			[GetSpellInfo(3599)] = "fire",
			[GetSpellInfo(2894)] = "fire",
			[GetSpellInfo(8190)] = "fire",
			[GetSpellInfo(5394)] = "water",
			[GetSpellInfo(16190)] = "water",
			[GetSpellInfo(8143)] = "earth",
			[GetSpellInfo(2062)] = "earth",
			[GetSpellInfo(2484)] = "earth",
			[GetSpellInfo(8177)] = "air",
			[GetSpellInfo(98008)] = "air",
		}
	end
	
	return self.totems[spellName]
end
