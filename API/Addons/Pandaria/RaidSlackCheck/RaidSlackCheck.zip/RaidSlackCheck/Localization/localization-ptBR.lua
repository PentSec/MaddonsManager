﻿if GetLocale() == "ptBR" then

function rsclocalel()

	psfpotchecklocal = "Verificação de poções" -- Needs review
	psfpotchecklocalt2 = "Verificação de flask" -- Needs review
	psfpotchecklocalt3 = "Reviver - Rebuffar" -- Needs review
	psfpotchecklocalt322 = "Check de buffs depois de reviver em combate." -- Needs review
	rscchatlist1 = "Raid" -- Needs review
	rscchatlist2 = "Aviso de Raid" -- Needs review
	rscchatlist4 = "Grupo" -- Needs review
	rscchatlist5 = "Guilda" -- Needs review
	rscchatlist6 = "Dizer" -- Needs review
	rscchatlist7 = "Gritar" -- Needs review
	rscchatlist8 = "Apenas para si mesmo" -- Needs review
	rscloccolor = "Cor dos nomes" -- Needs review
	rsclocfight1 = "Última luta" -- Needs review
	rsclocfight2 = "Luta anterior" -- Needs review
	rsclocfight3 = "Luta" -- Needs review
	rscloclastf = "Luta anterior" -- Needs review
	rsclocnotinc = "Fora de combate (pré-pots)" -- Needs review
	rsclocpot10 = "Quem usou poção" -- Needs review
	rsclocpot11 = "Quem não usou" -- Needs review
	rsclocpot12 = "Poções antes do combate anterior:" -- Needs review
	rsclocpot13 = "Usou poções antes do combate anterior" -- Needs review
	rsclocpot14 = "Antes do combate anterior, ninguém usou poções." -- Needs review
	rsclocpot17 = "Ninguém usou poções" -- Needs review
	rsclocpot18 = "Usou poções" -- Needs review
	rsclocpot2 = "0 poções selecionadas" -- Needs review
	rsclocpot3 = "0 poções" -- Needs review
	rsclocpot4 = "Todos usaram poções" -- Needs review
	rsclocpot5 = "Informações sobre" -- Needs review
	rsclocpot6 = "0 poções:" -- Needs review
	rsclocpot8 = "Outras poções usadas:" -- Needs review
	rsclocpot9 = "nenhuma outra poção foi usada." -- Needs review
	rsclocrep1 = "Reportar no chat:" -- Needs review

end


end