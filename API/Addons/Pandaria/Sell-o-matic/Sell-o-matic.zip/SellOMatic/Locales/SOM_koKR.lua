local L = LibStub("AceLocale-3.0"):NewLocale("SellOMatic", "koKR")
if not L then return end

L["item(s) sold"] = "개 판매"
-- L["Selling"] = ""
-- L["You've earned"] = ""

