local L = LibStub("AceLocale-3.0"):NewLocale("SellOMatic", "frFR")
if not L then return end

L["item(s) sold"] = "objet(s) vendu(s)"
L["Selling"] = "Vente" -- Needs review
L["You've earned"] = "Vous l'avez gagné" -- Needs review

