local L = LibStub("AceLocale-3.0"):NewLocale("SellOMatic", "itIT")
if not L then return end

L["item(s) sold"] = "Oggetto(i) venduto(i)"
L["Selling"] = "Stai vendendo"
L["You've earned"] = "Hai guadagnato"

