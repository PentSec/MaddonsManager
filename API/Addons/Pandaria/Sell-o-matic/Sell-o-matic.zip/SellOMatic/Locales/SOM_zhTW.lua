local L = LibStub("AceLocale-3.0"):NewLocale("SellOMatic", "zhTW")
if not L then return end

L["item(s) sold"] = "個物品被賣掉了"
L["Selling"] = "出售" -- Needs review
L["You've earned"] = "你得到了" -- Needs review

