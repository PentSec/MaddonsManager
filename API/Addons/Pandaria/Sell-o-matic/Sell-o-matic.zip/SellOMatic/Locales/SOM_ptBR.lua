local L = LibStub("AceLocale-3.0"):NewLocale("SellOMatic", "ptBR")
if not L then return end

-- L["item(s) sold"] = ""
-- L["Selling"] = ""
-- L["You've earned"] = ""

