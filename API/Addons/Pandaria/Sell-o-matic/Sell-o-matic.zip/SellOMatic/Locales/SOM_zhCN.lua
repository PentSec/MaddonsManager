local L = LibStub("AceLocale-3.0"):NewLocale("SellOMatic", "zhCN")
if not L then return end

L["item(s) sold"] = "个物品被卖掉了"
-- L["Selling"] = ""
-- L["You've earned"] = ""

