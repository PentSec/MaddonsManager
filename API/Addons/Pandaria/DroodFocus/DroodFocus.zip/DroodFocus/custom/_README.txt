You can put in this directory your custom textures.
NB: The files must be present before the launch of WoW, otherwise they will not be loaded by the game (even after a reload of the interface).