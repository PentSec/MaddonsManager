﻿----------------------------------------------------------------------------------------------------
-- DroodFocus 4.0.0 - Grid
-- Meranannon - Discordia - Vol'jin (EU)
-- rev 1
----------------------------------------------------------------------------------------------------

local DF = DF_namespace
local _

function DF:alignToGridX(value)
	return value
end
function DF:alignToGridY(value)
	return value
end