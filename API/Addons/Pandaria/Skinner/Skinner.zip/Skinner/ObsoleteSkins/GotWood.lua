
function Skinner:GotWood()

	self:applySkin(GotWoodFrame)

end
