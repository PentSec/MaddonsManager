﻿--[[ Credit for these translations goes to:
--]]
local L = LibStub("AceLocale-3.0"):NewLocale("TellMeWhen", "itIT", false)
if not L then return end


L["CREATURETYPE_1"] = "Bestia"
L["CREATURETYPE_10"] = "Non Specificato"
L["CREATURETYPE_11"] = "Totem"
L["CREATURETYPE_12"] = "Mascotte"
L["CREATURETYPE_13"] = "Nuvola di Gas"
L["CREATURETYPE_14"] = "Mascotte Selvatica"
L["CREATURETYPE_2"] = "Dragoide"
L["CREATURETYPE_3"] = "Demone"
L["CREATURETYPE_4"] = "Elementale"
L["CREATURETYPE_5"] = "Gigante"
L["CREATURETYPE_6"] = "Non Morto"
L["CREATURETYPE_7"] = "Umanoide"
L["CREATURETYPE_8"] = "Animale"
L["CREATURETYPE_9"] = "Unità Meccanica"
