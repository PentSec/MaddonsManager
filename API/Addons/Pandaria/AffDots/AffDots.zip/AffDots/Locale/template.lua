--[[
	Use this file as template if you want to translate addon to your locale.

	L["text to translate"] = ""  =>  L["text to translate"] = "translated text"
	L["shortened name"] = "long description"  =>  L["shortened name"] = "translated long description"
	\n is line break, leave it as is
]]--

L["AffDots (drag here to move options frame)"] = ""
L["Lock frames"] = ""

--Tabs
L["General"] = ""
L["Affliction"] = ""
L["Demonology"] = ""
L["Destruction"] = ""
L["Colors"] = ""
L["Layout"] = ""
L["TidyPlates"] = ""
L["Burst"] = ""

--General
L["Hide when not in combat"] = ""
L["Hide icons"] = ""
L["Hide text"] = ""
L["Show focus frame"] = ""
L["Show CoE"] = ""
L["Show HP%"] = ""
L["Show Soul Leech value"] = ""
L["Target frame size"] = ""
L["Focus frame size"] = ""
L["Text size"] = ""
L["CoE/Hp text size"] = ""
L["Font"] = ""
L["Layout"] = ""
L["Horizontal"] = ""
L["Vertical"] = ""
L["Bars"] = ""
L["Change color of text"] = ""
L["Relative values"] = ""
L["Hide UI"] = ""
L["Color"] = ""

--Affliction
L["Show Haunt"] = ""
L["Order:"] = ""
L["Agony"] = ""
L["Corruption"] = ""
L["UA"] = ""
L["Haunt"] = ""
L["Enable"] = ""

--Demonology
L["Show Hand of Guldan"] = ""
L["Show Demonic Fury"] = ""
L["Doom"] = ""
L["Hand of Guldan"] = ""
L["Demonic Fury <="] = ""

--Destruction
L["Show Conflagrate"] = ""
L["Show Rain of Fire"] = ""
L["Show Burning Embers"] = ""
L["Show Havoc"] = true
L["Show Backdraft"] = true
L["Immolate"] = ""
L["Conflagrate"] = ""
L["Rain of Fire"] = ""
L["Burning Embers"] = ""
L["Havoc"] = true
L["Backdraft"] = true
L["Burning Embers <="] = ""
L["Colors for Burning Embers:"] = ""


--Colors
L["Current stats are better, full Pandemic benefit"] = ""
L["Current stats are same, full Pandemic benefit"] = ""
L["Current stats are worse, full Pandemic benefit"] = ""
L["Current stats are better, partial Pandemic benefit"] = ""
L["Current stats are same, partial Pandemic benefit"] = ""
L["Current stats are worse, partial Pandemic benefit"] = ""
L["No dot on target"] = ""
L["CoE/Hp/Haunt color"] = ""
L["Text color"] = ""
L["Color switch"] = ""
L["When refresh will not recieve full Pandemic benefit,\nswitch color only if current stats are at least x% better"] = ""
L["Transparency"] = ""

--TidyPlates
L["Integrate dot colors in TidyPlates"] = ""
L["Width"] = ""
L["Height"] = ""
L["tidydesc"] = "If you want dots to show in certain order in TidyPlates, go to 'Tidy Plates Hub: Tank' and 'Tidy Plates Hub: Damage', find 'Buffs & Debuffs' section, set 'Filter Mode' to 'Specific Auras' and write this in Aura List:\nMy 980\nMy 172\nMy 87389\nMy 30108\nAll 1490\nFirst line is Agony, second and third Corruption, fourth UA, fifth CoE. Reorder them as needed. Put other auras in list if you need them"

--Burst
L["burstdesc"] = "Compares your current damage to your baseline damage, changes color if increase is at least x% higher.\nIntended to show when you have enough damage increase effects and it is a good time to spend your resources. Set it as high as you possibly can for maximum effect.\nTo save your baseline damage, click 'Set current as baseline' button, make sure you are fully buffed (Dark Intent when solo, party buffed when in 5-man, fully buffed with food and flask in raid) and without active procs or potions. You need to click it once for each spec, when you change gear or some buffs become available or unavailable.\n\nAffliction is special and needs active dots present on target to switch colors, demonology and destruction does not have this requirement."
L["Set current as baseline"] = ""
L["Damage increase needed to change color (percent)"] = ""
L["Show text"] = ""
L["\nTo quickly set baseline values, press the following key combination on Burst frame:"] = ""
L["Key"] = ""
L["Left SHIFT"] = ""
L["Right SHIFT"] = ""
L["Left CTRL"] = ""
L["Right CTRL"] = ""
L["Left ALT"] = ""
L["Right ALT"] = ""
L["Mouse button"] = ""
L["Right mouse button"] = ""
L["Burst frame for other classes: www.curse.com/addons/wow/mesmash"] = ""

--Horizontal/Vertical layout
L["Icon size"] = ""
L["Icon position"] = ""
L["Text position"] = ""

--Bars layout
L["Spacing"] = ""
L["Background"] = ""
L["Background color"] = ""
L["Enable proportional bars"] = ""
L["All bars will move at the same speed"] = ""
L["Proportional bars time limit"] = ""
L["Maximum numbers of seconds to display in proportional bar"] = ""