﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Mails", "koKR" )

if not L then return end

L["EXPIRY_ALL_ACCOUNTS_TITLE"] = "모든 계정 검사"
L["EXPIRY_ALL_REALMS_TITLE"] = "모든 진영 검사"
L["EXPIRY_CHECK_TITLE"] = "우편 만료 검사"
L["Mail Expiry Warning"] = "우편 만료 경고"
L["Scan mail body (marks it as read)"] = "우편 내용을 검사 (읽은 것으로 표시)"
L["SCAN_MAIL_BODY_TITLE"] = "우편 내용 검사"
L["Warn when mail expires in less days than this value"] = "우편이 이 날짜 안에 만료되면 경고"

