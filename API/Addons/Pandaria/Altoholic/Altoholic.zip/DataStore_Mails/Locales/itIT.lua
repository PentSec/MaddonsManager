﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Mails", "itIT" )

if not L then return end


