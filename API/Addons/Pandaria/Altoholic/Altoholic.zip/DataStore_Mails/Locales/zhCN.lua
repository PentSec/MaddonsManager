﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Mails", "zhCN" )

if not L then return end

L["Mail Expiry Warning"] = "邮件过期警告"
L["Scan mail body (marks it as read)"] = "扫描邮件内容(标记为已读)"
L["Warn when mail expires in less days than this value"] = "在邮件过期前多少天进行警告"

