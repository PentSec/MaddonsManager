﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Inventory", "ptBR" )

if not L then return end


