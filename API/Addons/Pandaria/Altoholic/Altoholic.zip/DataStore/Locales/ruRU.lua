local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore", "ruRU" )

if not L then return end

L["Disabled"] = "Отключено" -- Needs review
L["Enabled"] = "Включено" -- Needs review
L["Memory used for %d |4character:characters;:"] = "Памяти использовано для %d |4персонажа:персонажей;:" -- Needs review

