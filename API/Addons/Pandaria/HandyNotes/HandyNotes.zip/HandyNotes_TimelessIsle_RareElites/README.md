This is fork of the same name addon [HandyNotes_TimelessIsle_RareElites][1]

[1]: http://www.curse.com/addons/wow/handynotes_timelessisle_rareelit