Custom Raid Target Icons
by Kielbasa

Extract these eight tga files into /Interface/Icons and you should be good to go :D