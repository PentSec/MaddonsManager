local L = Scrap_Locals
if GetLocale() ~= 'zhTW' then return end

L["Add"] = "添加到垃圾清單"
L["Added"] = "已添加到垃圾清單: %s"
L["AutoSell"] = "自動出售"
L["AutoSellTip"] = "開啟此功能，Scrap會在你訪問商人時自動出售所有垃圾。"
L["Junk"] = "垃圾"
L["Loading"] = "載入中..."
L["NotJunk"] = "非垃圾"
L["Remove"] = "從垃圾清單移除"
L["Removed"] = "已從垃圾清單移除: %s"
L["SellJunk"] = "出售垃圾"
L["ShowTutorials"] = "顯示教學"
L["SoldJunk"] = "你出售垃圾共獲得 %s"