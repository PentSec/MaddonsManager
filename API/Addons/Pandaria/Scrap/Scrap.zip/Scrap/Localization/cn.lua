local L = Scrap_Locals
if GetLocale() ~= 'zhCN' then return end
	
L["Add"] = "添加到垃圾列表"
L["Added"] = "已添加到垃圾列表: %s"
L["AutoSell"] = "自动出售"
L["AutoSellTip"] = "开启此功能，Scrap会在你访问商人时自动出售所有垃圾。"
L["Remove"] = "从垃圾列表删除"
L["Removed"] = "已从垃圾列表删除: %s"
L["SellJunk"] = "出售垃圾"
L["ShowTutorials"] = "显示教学"
L["SoldJunk"] = "你出售垃圾共获得 %s"