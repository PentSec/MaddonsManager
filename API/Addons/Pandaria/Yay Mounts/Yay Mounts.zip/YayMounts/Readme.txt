ADDING NEW MOUNTS

1)in game type "/ym new"
2)open the file YayMountsData.lua
3)scroll down to the very bottom and find the subsection:
-------------NEW MOUNTS-------------------
4)add the lines from in game to the subsection
5)change "ground/fly/scaling" to the appropriate value for that mount

	-it should look like:

-------------NEW MOUNTS-------------------
[123456] = "fly" --EXAMPLE 1
[123457] = "ground" -- EXAMPLE 2


6)please leave a comment on the addon website if you have any issues