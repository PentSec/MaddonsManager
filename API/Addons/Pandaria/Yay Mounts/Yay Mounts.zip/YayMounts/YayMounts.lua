YayMounts = LibStub("AceAddon-3.0"):NewAddon("YayMounts","AceConsole-3.0", "AceEvent-3.0")
AceGUI = LibStub("AceGUI-3.0")

local function size(t)
	local i = 0
	for k,v in pairs(t) do
		i = i + 1
	end
	return i
end

local function pairsByKeys (t, f)
	local a = {}
		for n in pairs(t) do 
			table.insert(a, n) 
		end
		table.sort(a, f)
		local i = 0      -- iterator variable
		local iter = function ()   -- iterator function
			i = i + 1
			if a[i] == nil then 
				return nil
			else 
				return a[i], t[a[i]]
			end
		end
	return iter
end

local options = {
	name="YayMounts",
	handler = YayMounts,
	type = "group",
	args = {
		enable = {
			type = "execute",
			name = YayMountsLocale.Misc.optionsGUIButton,
			func = "Frames",
		},
	}
}

local version = "1.6.6"
local t, p, tProfiles, tProfiles2, newMounts, aspectTable = {}, {}, {}, {}, {}, {13165, 5118, 13159}
local filters = {Types = {}, Sources = {}, Flags ={}}
local stealth, total = false, 0
local usePassengerMount = false
local onGroundMount, mountUsed, currentTab, currentSubTab, durability
local localClass, class = UnitClass("player")
local f = CreateFrame("frame")
local f2 = CreateFrame("frame")
local delaySPEXS = 600


local defaults = { 
	global = { 
		["CV"] = 1.0, --Current version
	},
	profile = {
		settings = {
			["ER"] = true, --emptyrandom: use random mount if none selected
			["FFP"] = false, --Druid: Use flight form with priority
			["TTT"] = false, --Travel to Travel, no human form. Mostly for pvp.
			["MTFF"] = false, --Druid: When flying mounted shift directly to flight form
			["FBP"] = false, --Prioritize flying broom, even over Flight form
			["HM"] = false, -- Has Mount
			["NDWF"] = false, -- No Dismount while Flying. Safe!
			["FFM"] = true, --Force Flying Mount (in ground areas)
			["MR"] = true, --Monk: Roll
			["RS"] = true, --Rogue: Sprint
			["PMLS"] = true, --Priest/Mage: Levitate/Slowfall
			["SMIFO"] = false, --Only use scaling mounts in flyable areas
			["ASD"] = false, --Always Stealth Dismiss mini-pets
			["ASP"] = true, -- Auto summon pets
			["SPAD"] = true, -- Summon pets after death
			["SPEXS"] = true, --summon pets every x seconds
			["URM"] = true, --use a repair mount if one exists
		},
		misc = {			
			["RACE"] = "Human",
			["DBSize"] = 0, -- Database size
			["NumPets"] = 0,
			["Delay"] = 300, --Delay between summoning a new pet
			["MinDurability"] = 0.2, --summon repair mount if under X durability
			
			RepairMounts = {},
			NumMounts = {
				["Total"] = 0,
				["Ground"] = 0,
				["Flying"] = 0,
				["Scaling"] = 0,
				["Special"] = 0,
				},
		},		
		mounts = {
			['*'] = {
			},
		},
		pets = {
			['*'] = {
			},
		},
	}
}

function YayMounts:OnInitialize() 
	self.db = LibStub("AceDB-3.0"):New("YayMountsDB", defaults, "Default")
	local ymOptions = LibStub("AceConfigRegistry-3.0")
	ymOptions:RegisterOptionsTable("YayMounts",options)
	self.ymOpFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("YayMounts","YayMounts")
	self:RegisterChatCommand("ym", "ChatCommand")
	self:RegisterChatCommand("yaymounts", "ChatCommand")
end

function YayMounts:ChatCommand(input) --Chat command function
	if input == "reload" or input == "rl" then
		YayMounts:ReSort()
		self:Print(YayMountsLocale.Misc.mountsReloaded)
	
	elseif input == "new" then
		YayMounts:ReSort()
		YayMounts:NewMounts()
		
	else
		YayMounts:Frames("tab1")
	end
end

function YayMounts:OnEnable()-- addon enabled
	delaySPEXS = self.db.profile.misc["Delay"]
	YayMounts:Delay(f2, self.db.profile.misc["Delay"], true)
	if not self.db.profile.settings["SPEXS"] then
		f2:Hide()
	end

	YayMounts:AlphaSortProfileDB()
	
	local _, race = UnitRace("player")
	local i = 0
	for k,v in pairs(YayMountsType["Mounts"]) do
		i = i+1
	end
		
	if self.db.global["CV"] ~= version or self.db.profile.misc["RACE"] ~= race or i ~= self.db.profile.misc["DBSize"] then
		self.db.profile.misc["RACE"] = race
		self.db.global["CV"] = version
		self.db.profile.misc["DBSize"] = i
		YayMounts:StartUpReSort()
	end

	YayMounts:MapOverrides()
 	
	self:RegisterEvent("UPDATE_BINDINGS", "MapOverrides")
	self:RegisterEvent("COMPANION_LEARNED", "EventHandler")
	
	
	if GetNumCompanions("CRITTER") > 0 then
		if self.db.profile.settings["ASP"] then
			self:RegisterEvent("PLAYER_ENTERING_WORLD", "EventHandler")
			self:RegisterEvent("PLAYER_UNGHOST", "EventHandler")
			self:RegisterEvent("PLAYER_ALIVE", "EventHandler")
		end
		
		if self.db.profile.settings["ASD"] then
			self:RegisterEvent("UPDATE_STEALTH", "EventHandler")
		end
	end
	
	self:RegisterEvent("PLAYER_REGEN_DISABLED", "EventHandler")
	self:RegisterEvent("PLAYER_REGEN_ENABLED", "EventHandler")
	
	if race == "Worgen" and UnitLevel("player") < 21 then
		self:RegisterEvent("PLAYER_LEVEL_UP", "EventHandler")
	end
	
end
--------------------------------------------------------------
--database handling and creation functions
--------------------------------------------------------------
local function IsUsableS(spellID)
	local bool, _ = IsUsableSpell(YayMounts:SpellToName(spellID))
	return bool
end

local function IsUsableM(MountSID)
	for q=1, GetNumCompanions("MOUNT"), 1 do
		local _,_,S,_,_ = GetCompanionInfo("Mount", q)
		if S == MountSID then
			return true
		end
	end
	return false
end

function YayMounts:AlphaSortProfileDB()
	table.wipe(tProfiles)
	table.wipe(tProfiles2)
	
	self.db:GetProfiles(tProfiles)

	for k, v in pairs(tProfiles) do
		tProfiles2[v] = k			--put names as key, order #'s as value
	end
	
	table.wipe(tProfiles)
	
	for k, v in pairsByKeys(tProfiles2) do
		tinsert(tProfiles, k)		--sort alphabetically, name as value
	end
	
end

function YayMounts:ReSort()
	local tempTable = {}
	
	for k,v in pairs(self.db.profile.pets) do
		tempTable[k] = v[1]
	end
	
	table.wipe(self.db.profile.pets)
	YayMounts:SortPets(tempTable)
	table.wipe(tempTable)
	
	for k,v in pairs(self.db.profile.mounts) do
		tempTable[k] = self.db.profile.mounts[k][4]
	end
	table.wipe(self.db.profile.mounts)
	
	YayMounts:SortMounts(tempTable)
end

function YayMounts:StartUpReSort()
	local tempTable = {}
	
	for k,v in pairs(self.db.profile.mounts) do
		tempTable[k] = self.db.profile.mounts[k][4]
	end
	table.wipe(self.db.profile.mounts)
	
	YayMounts:SortMounts(tempTable)
end

function YayMounts:ProfessionCheck(ID)
	if YayMountsType["Professions"][ID] then
		prof1, prof2, _,_,_,_ = GetProfessions()
		
		if prof1 then
			prof1, _, SL1 = GetProfessionInfo(prof1)
			
			if YayMountsType["Professions"][ID][1] == prof1 then
				if YayMountsType["Professions"][ID][2] <= SL1 then
					return true
				end
			end
		end
		
		if prof2 then
			prof2, _, SL2 = GetProfessionInfo(prof2)
			
			if YayMountsType["Professions"][ID][1] == prof2 then
				if YayMountsType["Professions"][ID][2] <= SL2 then 
					return true
				end
			end
		end
		
		return false
	end
	
	return true
end

function YayMounts:ReputationCheck(ID)
	if YayMountsType["Reputation"][ID] then
		if YayMountsType["Reputation"][ID] == "Cloud Serpent" then
			if IsUsableS(130487) then -- Cloud Serpent Riding
				return true
			end
		end
		
		return false -- Reputation or skill does not meet requirements
	end
	
	return true
end

function YayMounts:SpellToName(spell) --converts spell ID to Name
	local name = GetSpellInfo(spell)
	return name
end

function YayMounts:ItemToName(item)
	local name = GetItemInfo(item)
	return name
end

function YayMounts:GetMounts(info, key)
	if info == "mounts" then
		return self.db.profile.mounts[key][4]
		
	elseif info == "pets" then
		return self.db.profile.pets[key][1]
		
	elseif info == "settings" then
		return self.db.profile.settings[key]
		
	elseif info == "misc" then
		return self.db.profile.misc[key]
		
	elseif info == "delay" then
		return ( self.db.profile.misc["Delay"] / 60 )
	end
end

function YayMounts:SetMounts(info, key, state)
	if info == "mounts" then
		self.db.profile.mounts[key][4] = state
		
	elseif info == "pets" then
		self.db.profile.pets[key][1] = state
		
	elseif info == "misc" then
		self.db.profile.misc[key] = state
		
	elseif info == "settings" then
		if key == "ASP" then
			if state then
				self:RegisterEvent("UPDATE_STEALTH", "EventHandler")
			else
				self:UnregisterEvent("UPDATE_STEALTH", "EventHandler")
			end
			self.db.profile.settings[key] = state
			
		elseif key == "SPEXS" then
			if state then
				f2:Show()
			else
				f2:Hide()
			end
			self.db.profile.settings[key] = state			
		else
			self.db.profile.settings[key] = state
		end
	end
end

function YayMounts:SetDelay(d)
	delaySPEXS = d
	self.db.profile.misc["Delay"] = d	
	end

function YayMounts:ClearMounts(mountType)-- clear all mounts
	if mountType == "pets" then
		for k,v in pairs(self.db.profile.pets) do
			v[1] = false
			p[v[2]]:SetValue(false)
		end	
	
	else	
		for k,v in pairs(self.db.profile.mounts) do
			if self.db.profile.mounts[k][3] == mountType then
				if YayMounts:ProfessionCheck(k) then
					self.db.profile.mounts[k][4] = false
					t[k]:SetValue(false)
				end
			end
		end
	end
end

function YayMounts:SelectAllMounts(mountType)-- select all mounts
	if mountType == "pets" then
		for k,v in pairs(self.db.profile.pets) do
			p[v[2]]:SetValue(true)
			v[1] = true
		end
		
	else
		for k,v in pairs(self.db.profile.mounts) do
			if self.db.profile.mounts[k][3] == mountType then
				if YayMounts:ProfessionCheck(k) then
					self.db.profile.mounts[k][4] = true
					t[k]:SetValue(true)
				end
			end
		end
	end
end

function YayMounts:BuildList(mountType)--Builds and draws the checkboxes for the opened tab
	if mountType == "pets" then
		p = {}
		YayMounts:ResetPetFilters()
		
		for k,v in pairsByKeys(self.db.profile.pets) do
			local _, S,_,_,_,_,_,_, I = C_PetJournal.GetPetInfoByIndex(v[2])
			if not (S == 282 or S == 280 or S == 283 or S == 281) then
				p[v[2]] = AceGUI:Create("CheckBox")
				p[v[2]]:SetImage(I)
				p[v[2]]:SetLabel(k)
				p[v[2]]:SetValue(YayMounts:GetMounts("pets", k))
				p[v[2]]:SetCallback("OnValueChanged",  function() YayMounts:SetMounts("pets", k, p[v[2]]:GetValue()) end)
				YayMountsContent:AddChild(p[v[2]])
			end
		end
		
		YayMounts:RestorePetFilters()
		
	else	
		t = {}
		for q=1, GetNumCompanions("MOUNT"), 1 do
		local _,_,S,_,_ = GetCompanionInfo("Mount", q)
			if self.db.profile.mounts[S][3] == mountType then
				t[S] = AceGUI:Create("CheckBox")
				t[S]:SetImage(self.db.profile.mounts[S][2])
				t[S]:SetLabel(self.db.profile.mounts[S][1])
				t[S]:SetValue(YayMounts:GetMounts("mounts", S))
				t[S]:SetCallback("OnValueChanged",  function() YayMounts:SetMounts("mounts", S, t[S]:GetValue()) end)
				YayMountsContent:AddChild(t[S])
				
				if not YayMounts:ProfessionCheck(S) or not YayMounts:ReputationCheck(S) then
					self.db.profile.mounts[S][4] = false
					t[S]:SetDisabled(true)
				end
			end
		end
		
		if mountType == "ground" and IsUsableS(87840) then
			t[87840] = AceGUI:Create("CheckBox")
			t[87840]:SetImage("Interface\\Icons\\ability_mount_blackdirewolf")
			t[87840]:SetLabel(YayMounts:SpellToName(87840))
			t[87840]:SetValue(YayMounts:GetMounts("mounts", 87840))
			t[87840]:SetCallback("OnValueChanged",  function() YayMounts:SetMounts("mounts", 87840, t[87840]:GetValue()) end)
			YayMountsContent:AddChild(t[87840])
		end
	end
end

function YayMounts:SortMounts(tempTable)--Rebuilds the database. Activates on load
self.db.profile.misc.NumMounts["Ground"] = 0
self.db.profile.misc.NumMounts["Flying"] = 0
self.db.profile.misc.NumMounts["Special"] = 0
self.db.profile.misc.NumMounts["Scaling"] = 0
self.db.profile.misc.NumMounts["Total"] = 0

	for q=1, GetNumCompanions("MOUNT"), 1 do
		local _,_,S,I,O = GetCompanionInfo("MOUNT", q)
		local N = YayMounts:SpellToName(S)
		local mountType = nil
		
		--this is realy inefficient, it's a hashtable so just look it up, FIX THIS
		for k,v in pairs(YayMountsType["Mounts"]) do
			if S == k then
				mountType = v
			end
		end
		
		if S == 61425 or S == 61447 or S == 122708 then
			self.db.profile.misc.RepairMounts[S] = true
		end
		
		if mountType == nil and S ~= 75207 then
			self.db.profile.misc.NumMounts["Total"] = self.db.profile.misc.NumMounts["Total"] - 1
			newMounts[S] = N
		else
			if tempTable[S] == nil then
				self.db.profile.mounts[S] = {N, I, mountType, true}
			elseif tempTable[S] == true then
				self.db.profile.mounts[S] = {N, I, mountType, true}
			else
				self.db.profile.mounts[S] = {N, I, mountType, false}
			end
			
			self.db.profile.settings["HM"] = true
		end
		
		--Increment the counters
		if mountType == "ground" then
			self.db.profile.misc.NumMounts["Ground"] = self.db.profile.misc.NumMounts["Ground"] + 1
		elseif mountType == "fly" then
			self.db.profile.misc.NumMounts["Flying"] = self.db.profile.misc.NumMounts["Flying"] + 1
		elseif mountType == "special" then
			self.db.profile.misc.NumMounts["Special"] = self.db.profile.misc.NumMounts["Special"] + 1
		elseif mountType == "scaling" then
			self.db.profile.misc.NumMounts["Scaling"] = self.db.profile.misc.NumMounts["Scaling"] + 1
		end
		
		self.db.profile.misc.NumMounts["Total"] = self.db.profile.misc.NumMounts["Total"] + 1
	end
	
	if self.db.profile.misc["RACE"] == "Worgen" and UnitLevel("player") >= 20 then
		if self.db.profile.mounts[87840] then
			if tempTable[87840] == nil then
				self.db.profile.mounts[87840] = {YayMounts:SpellToName(87840), "Interface\\Icons\\ability_mount_blackdirewolf", "ground", true}
			elseif tempTable[87840] == true then
				self.db.profile.mounts[87840] = {YayMounts:SpellToName(87840), "Interface\\Icons\\ability_mount_blackdirewolf", "ground", true}
			else
				self.db.profile.mounts[87840] = {YayMounts:SpellToName(87840), "Interface\\Icons\\ability_mount_blackdirewolf", "ground", false}
			end
		else
			self.db.profile.mounts[87840] = {YayMounts:SpellToName(87840), "Interface\\Icons\\ability_mount_blackdirewolf", "ground", true}
		end
		
		self.db.profile.misc.NumMounts["Ground"] = self.db.profile.misc.NumMounts["Ground"] + 1
		self.db.profile.misc.NumMounts["Total"] = self.db.profile.misc.NumMounts["Total"] + 1
		self.db.profile.settings["HM"] = true
	end
	
	if (size(newMounts) > 0) then
		self:Print("New mounts have been found! Please leave a comment at the addon website or read the Readme file in the addon folder if you would like to add mounts yourself.")
		local str = "New mounts: "
		for k,v in pairs(newMounts) do
			str = string.format("%s %s,", str, v)
		end
		self:Print(str)
	end
end

function YayMounts:SortPets(tempTable)--Rebuilds the pet database. Activates on load
	YayMounts:ResetPetFilters()
	_, self.db.profile.misc["NumPets"] = C_PetJournal.GetNumPets(true)
	
	for q=1, self.db.profile.misc["NumPets"] do
		local _, S, _, CustomName, Lvl, _, _, DefaultName = C_PetJournal.GetPetInfoByIndex(q)
		
		if not (S == 282 or S == 280 or S == 283 or S == 281) then
			if CustomName == nil then
				CustomName = DefaultName
			end
			
			if self.db.profile.pets[CustomName][2] ~= q and self.db.profile.pets[CustomName][2] ~= nil then
				local _, _, _, _, Lvl2 = C_PetJournal.GetPetInfoByIndex(self.db.profile.pets[CustomName][2])
				if Lvl < Lvl2 then
					if tempTable[CustomName] == true or tempTable[CustomName] == nil  then
						self.db.profile.pets[CustomName] = {true, q} -- Name = {IsEnabled, Index}
					else
						self.db.profile.pets[CustomName] = {false, q}
					end
				end
			else
				if tempTable[CustomName] == nil then
					self.db.profile.pets[CustomName] = {true, q}
				elseif tempTable[CustomName] == true then
					self.db.profile.pets[CustomName] = {true, q}
				else
					self.db.profile.pets[CustomName] = {false, q}
				end
			end
		end
	end
	
	YayMounts:RestorePetFilters()
end

function YayMounts:NewMounts()
	
	for k,v in pairs(newMounts) do
		self:Print("["..k..'] = "ground/fly/scaling", --'..v)
	end
end
--------------------------------------------------------------
--GUI functions for drawing frames
--------------------------------------------------------------
local function PetOptionsHandler(flag)
	if flag and GetNumCompanions("CRITTER") > 0 then
		YayMounts:RegisterEvent("PLAYER_ENTERING_WORLD", "EventHandler")
	else
		YayMounts:UnregisterEvent("PLAYER_ENTERING_WORLD", "EventHandler")
	end
end

function YayMounts:SetSliderButtonLabel(info, value)
	str = "value"
	if info == "SPEXS" then
		str, _ = string.gsub(strSPEXS, " X ", " "..value.." ")
	
	elseif info == "RepairMount" then
		str, _ = string.gsub(strRepairMount, " X ", " "..value.." ")
	end	
	
	return str
end

local function DrawGroup1a(container) --Ground Mounts, Tab1
	container:SetLayout("Flow")
		
	local selectallbutton = AceGUI:Create("Button")
	selectallbutton:SetText("Select All")
	selectallbutton:SetCallback("OnClick", function() YayMounts:SelectAllMounts("ground") end)
	container:AddChild(selectallbutton)
		
	local clearallbutton = AceGUI:Create("Button")
	clearallbutton:SetText("Clear All")
	clearallbutton:SetCallback("OnClick", function() YayMounts:ClearMounts("ground") end)
	container:AddChild(clearallbutton)
	
	local scrollcontainerframe = AceGUI:Create("SimpleGroup")
	scrollcontainerframe:SetLayout("Fill")
	scrollcontainerframe:SetFullWidth(true)
	scrollcontainerframe:SetFullHeight(true)
	container:AddChild(scrollcontainerframe)

	local scrollframe = AceGUI:Create("ScrollFrame")
	scrollcontainerframe:AddChild(scrollframe)
	
	
	YayMountsContent = AceGUI:Create("InlineGroup")
	YayMountsContent:SetFullWidth(true)
 	YayMountsContent:SetLayout("Flow")
	
	YayMounts:BuildList("ground")
	scrollframe:AddChild(YayMountsContent)
end

local function DrawGroup2a(container) --Flying Mounts, Tab2
	container:SetLayout("Flow")
	
	local selectallbutton = AceGUI:Create("Button")
	selectallbutton:SetText("Select All")
	selectallbutton:SetCallback("OnClick", function() YayMounts:SelectAllMounts("fly") end)
	container:AddChild(selectallbutton)
		
	local clearallbutton = AceGUI:Create("Button")
	clearallbutton:SetText("Clear All")
	clearallbutton:SetCallback("OnClick", function() YayMounts:ClearMounts("fly") end)
	container:AddChild(clearallbutton)
	
	local scrollcontainerframe = AceGUI:Create("SimpleGroup")
	scrollcontainerframe:SetLayout("Fill")
	scrollcontainerframe:SetFullWidth(true)
	scrollcontainerframe:SetFullHeight(true)
	container:AddChild(scrollcontainerframe)

	local scrollframe = AceGUI:Create("ScrollFrame")
	scrollcontainerframe:AddChild(scrollframe)
	
	YayMountsContent = AceGUI:Create("InlineGroup")
	YayMountsContent:SetFullWidth(true)
 	YayMountsContent:SetLayout("Flow")
	
	YayMounts:BuildList("fly")
	scrollframe:AddChild(YayMountsContent)
end

local function DrawGroup3a(container) --Scaling Mounts, Tab3
	container:SetLayout("Flow")
	
	local selectallbutton = AceGUI:Create("Button")
	selectallbutton:SetText("Select All")
	selectallbutton:SetCallback("OnClick", function() YayMounts:SelectAllMounts("scaling") end)
	container:AddChild(selectallbutton)
		
	local clearallbutton = AceGUI:Create("Button")
	clearallbutton:SetText("Clear All")
	clearallbutton:SetCallback("OnClick", function() YayMounts:ClearMounts("scaling") end)
	container:AddChild(clearallbutton)
		
	local scrollcontainerframe = AceGUI:Create("SimpleGroup")
	scrollcontainerframe:SetLayout("Fill")
	scrollcontainerframe:SetFullWidth(true)
	scrollcontainerframe:SetFullHeight(true)
	container:AddChild(scrollcontainerframe)
		
	local scrollframe = AceGUI:Create("ScrollFrame")
	scrollcontainerframe:AddChild(scrollframe)
		
	YayMountsContent = AceGUI:Create("InlineGroup")
	YayMountsContent:SetFullWidth(true)
 	YayMountsContent:SetLayout("Flow")
		
	
	YayMounts:BuildList("scaling")
	scrollframe:AddChild(YayMountsContent)
end

local function DrawGroup4a(container) --Special Mounts, Tab4
	container:SetLayout("Flow")
	
	local selectallbutton = AceGUI:Create("Button")
	selectallbutton:SetText("Select All")
	selectallbutton:SetCallback("OnClick", function() YayMounts:SelectAllMounts("special") end)
	container:AddChild(selectallbutton)
		
	local clearallbutton = AceGUI:Create("Button")
	clearallbutton:SetText("Clear All")
	clearallbutton:SetCallback("OnClick", function() YayMounts:ClearMounts("special") end)
	container:AddChild(clearallbutton)
		
	local scrollcontainerframe = AceGUI:Create("SimpleGroup")
	scrollcontainerframe:SetLayout("Fill")
	scrollcontainerframe:SetFullWidth(true)
	scrollcontainerframe:SetFullHeight(true)
	container:AddChild(scrollcontainerframe)
		
	local scrollframe = AceGUI:Create("ScrollFrame")
	scrollcontainerframe:AddChild(scrollframe)
		
	YayMountsContent = AceGUI:Create("InlineGroup")
	YayMountsContent:SetFullWidth(true)
 	YayMountsContent:SetLayout("Flow")
		
	
	YayMounts:BuildList("special")
	scrollframe:AddChild(YayMountsContent)
end

local function SelectGroupMounts(container, event, group)
	container:ReleaseChildren()
	if group == "tab1" then
		DrawGroup1a(container)
	elseif group == "tab2" then
		DrawGroup2a(container)
	elseif group == "tab3" then
		DrawGroup3a(container)
	elseif group == "tab4" then
		DrawGroup4a(container)
	end
	currentSubTab = group
end

local function DrawGroup1(container)--MOUNTS
	container:SetLayout("Fill")

	local tab  = AceGUI:Create("TabGroup")
	tab:SetLayout("Flow")
	tab:SetTabs({{text="Ground ("..YayMounts.db.profile.misc.NumMounts["Ground"]..")", value="tab1"}, {text="Flying ("..YayMounts.db.profile.misc.NumMounts["Flying"]..")", value="tab2"}, {text="Scaling ("..YayMounts.db.profile.misc.NumMounts["Scaling"]..")", value="tab3"}, {text="Special ("..YayMounts.db.profile.misc.NumMounts["Special"]..")", value="tab4"}})
	tab:SetCallback("OnGroupSelected", SelectGroupMounts)
	
	if currentSubTab ~= nil then
		tab:SelectTab(currentSubTab)
	else
		tab:SelectTab("tab1")
	end
	container:AddChild(tab)
end

local function DrawGroup2(container)--PETS
	container:SetLayout("Flow")
		
	local selectallbutton = AceGUI:Create("Button")
	selectallbutton:SetText("Select All")
	selectallbutton:SetCallback("OnClick", function() YayMounts:SelectAllMounts("pets") end)
	container:AddChild(selectallbutton)
		
	local clearallbutton = AceGUI:Create("Button")
	clearallbutton:SetText("Clear All")
	clearallbutton:SetCallback("OnClick", function() YayMounts:ClearMounts("pets") end)
	container:AddChild(clearallbutton)
		
	local scrollcontainerframe = AceGUI:Create("SimpleGroup")
	scrollcontainerframe:SetLayout("Fill")
	scrollcontainerframe:SetFullWidth(true)
	scrollcontainerframe:SetFullHeight(true)
	container:AddChild(scrollcontainerframe)
	
	local scrollframe = AceGUI:Create("ScrollFrame")		
	scrollcontainerframe:AddChild(scrollframe)
	
	YayMountsContent = AceGUI:Create("InlineGroup")
	YayMountsContent:SetFullWidth(true)		
	YayMountsContent:SetLayout("Flow")
	
	
	YayMounts:BuildList("pets")
	scrollframe:AddChild(YayMountsContent)
end

local function DrawGroup3(container)--MOUNT OPTIONS
	container:SetLayout("Flow")
	
	yayMountsBindingButton = AceGUI:Create("Keybinding")
	yayMountsBindingButton:SetLabel(BINDING_NAME_YAYMOUNTBINDING)
	yayMountsBindingButton:SetKey(GetBindingKey("YAYMOUNTBINDING"))
	yayMountsBindingButton:SetCallback("OnKeyChanged", function() YayMounts:Keybinding(yayMountsBindingButton:GetKey(), 1) end)
	container:AddChild(yayMountsBindingButton)
	
	yayMountsBindingButton2 = AceGUI:Create("Keybinding")
	yayMountsBindingButton2:SetLabel(BINDING_NAME_YAYMOUNTBINDING2)
	yayMountsBindingButton2:SetKey(GetBindingKey("YAYMOUNTBINDING2"))
	yayMountsBindingButton2:SetCallback("OnKeyChanged", function() YayMounts:Keybinding(yayMountsBindingButton2:GetKey(), 2); end)
	container:AddChild(yayMountsBindingButton2)
	
	yayMountsBindingButton4 = AceGUI:Create("Keybinding")
	yayMountsBindingButton4:SetLabel(BINDING_NAME_YAYMOUNTBINDING4)
	yayMountsBindingButton4:SetKey(GetBindingKey("YAYMOUNTBINDING4"))
	yayMountsBindingButton4:SetCallback("OnKeyChanged", function() YayMounts:Keybinding(yayMountsBindingButton4:GetKey(), 4); end)
	container:AddChild(yayMountsBindingButton4)

	local nDWF = AceGUI:Create("CheckBox")
	nDWF:SetLabel(YayMountsLocale.String.NDWF)
	nDWF:SetValue(YayMounts:GetMounts("settings", "NDWF"))
	nDWF:SetCallback("OnValueChanged",  function() YayMounts:SetMounts("settings", "NDWF", nDWF:GetValue()) end)
	nDWF:SetFullWidth(true)
	container:AddChild(nDWF)
	
	local emptyRandom = AceGUI:Create("CheckBox")
	emptyRandom:SetLabel(YayMountsLocale.String.ER)
	emptyRandom:SetValue(YayMounts:GetMounts("settings", "ER"))
	emptyRandom:SetCallback("OnValueChanged",  function() YayMounts:SetMounts("settings", "ER", emptyRandom:GetValue()) end)
	emptyRandom:SetFullWidth(true)
	container:AddChild(emptyRandom)
	
	local forceFlyingMount = AceGUI:Create("CheckBox")
	forceFlyingMount:SetLabel(YayMountsLocale.String.FFM)
	forceFlyingMount:SetValue(YayMounts:GetMounts("settings", "FFM"))
	forceFlyingMount:SetCallback("OnValueChanged", function() YayMounts:SetMounts("settings", "FFM", forceFlyingMount:GetValue()) end)
	forceFlyingMount:SetFullWidth(true)
	container:AddChild(forceFlyingMount)
	
	local scalingMountLimiter = AceGUI:Create("CheckBox")
	scalingMountLimiter:SetLabel(YayMountsLocale.String.SMIFO)
	scalingMountLimiter:SetValue(YayMounts:GetMounts("settings", "SMIFO"))
	scalingMountLimiter:SetCallback("OnValueChanged", function() YayMounts:SetMounts("settings", "SMIFO", scalingMountLimiter:GetValue()) end)
	scalingMountLimiter:SetFullWidth(true)
	container:AddChild(scalingMountLimiter)
	
	local sliderRepairMount = AceGUI:Create("Slider") --repair mount slider in decimal %
	sliderRepairMount:SetLabel("Low Durability %")
	sliderRepairMount:SetValue(YayMounts:GetMounts("misc", "MinDurability")*100)
	sliderRepairMount:SetCallback("OnMouseUp", function() YayMounts:SetMounts("misc", "MinDurability", (sliderRepairMount:GetValue()/100)) end)
	sliderRepairMount:SetSliderValues(0, 100, 5)
	sliderRepairMount:SetDisabled( not YayMounts:GetMounts("settings", "URM"))
	
	local repairMount = AceGUI:Create("CheckBox")
	repairMount:SetLabel(YayMountsLocale.String.URM)
	repairMount:SetValue(YayMounts:GetMounts("settings", "URM"))
	repairMount:SetCallback("OnValueChanged", function() YayMounts:SetMounts("settings", "URM", repairMount:GetValue()) sliderRepairMount:SetDisabled(not repairMount:GetValue()) end)
	repairMount:SetFullWidth(true)
	
	container:AddChild(repairMount)
	container:AddChild(sliderRepairMount)
	
	if GetItemCount(37011, false) > 0 then
		local flyingBroomPriority = AceGUI:Create("CheckBox")
		flyingBroomPriority:SetLabel(YayMountsLocale.String.FBP)
		flyingBroomPriority:SetValue(YayMounts:GetMounts("settings", "FBP"))
		flyingBroomPriority:SetCallback("OnValueChanged", function() YayMounts:SetMounts("settings", "FBP", flyingBroomPriority:GetValue()) end)
		flyingBroomPriority:SetFullWidth(true)
		container:AddChild(flyingBroomPriority)
	end
end

local function DrawGroup4(container) --PET OPTIONS
	container:SetLayout("Flow")
	
	yayMountsBindingButton3 = AceGUI:Create("Keybinding")
	yayMountsBindingButton3:SetLabel(BINDING_NAME_YAYMOUNTBINDING3)
	yayMountsBindingButton3:SetKey(GetBindingKey("YAYMOUNTBINDING3"))
	yayMountsBindingButton3:SetCallback("OnKeyChanged", function() YayMounts:Keybinding(yayMountsBindingButton3:GetKey(), 3) end)
	container:AddChild(yayMountsBindingButton3)

	local aSP = AceGUI:Create("CheckBox") --auto summon pets
	aSP:SetLabel(YayMountsLocale.String.ASP)
	aSP:SetValue(YayMounts:GetMounts("settings", "ASP"))
	aSP:SetCallback("OnValueChanged",  function() YayMounts:SetMounts("settings", "ASP", aSP:GetValue()) PetOptionsHandler(aSP:GetValue()) end)
	aSP:SetFullWidth(true)
	container:AddChild(aSP)
	
	local aSD = AceGUI:Create("CheckBox") --dismiss pet when stealthing
	aSD:SetLabel(YayMountsLocale.String.ASD)
	aSD:SetValue(YayMounts:GetMounts("settings", "ASD"))
	aSD:SetCallback("OnValueChanged",  function() YayMounts:SetMounts("settings", "ASD", aSD:GetValue()) end)
	aSD:SetFullWidth(true)
	container:AddChild(aSD)
	
	local sPAD = AceGUI:Create("CheckBox") -- summon pet after death
	sPAD:SetLabel(YayMountsLocale.String.SPAD)
	sPAD:SetValue(YayMounts:GetMounts("settings", "SPAD"))
	sPAD:SetCallback("OnValueChanged",  function() YayMounts:SetMounts("settings", "SPAD", sPAD:GetValue()) end)
	sPAD:SetFullWidth(true)
	container:AddChild(sPAD)
	
	local sliderSPEXS = AceGUI:Create("Slider") --SPEXS slider in minutes
	sliderSPEXS:SetLabel("Delay")
	sliderSPEXS:SetValue(YayMounts:GetMounts("delay"))
	sliderSPEXS:SetCallback("OnMouseUp", function() YayMounts:SetDelay(sliderSPEXS:GetValue()*60) end)
	sliderSPEXS:SetSliderValues(1, 20, 1)
	sliderSPEXS:SetDisabled( not YayMounts:GetMounts("settings", "SPEXS"))
	
	local sPEXS = AceGUI:Create("CheckBox") -- summon pet every X minutes
	sPEXS:SetLabel(YayMountsLocale.String.SPEXS)
	sPEXS:SetValue(YayMounts:GetMounts("settings", "SPEXS"))
	sPEXS:SetCallback("OnValueChanged",  function() 
			YayMounts:SetMounts("settings", "SPEXS", sPEXS:GetValue()) 
			sliderSPEXS:SetDisabled(not sPEXS:GetValue())

		end)
	sPEXS:SetFullWidth(true)
	
	container:AddChild(sPEXS)
	container:AddChild(sliderSPEXS)
end

local function DrawGroup5(container) --CLASS OPTIONS
	container:SetLayout("Flow")
	
	if class == "MONK" then
		local monkRoll = AceGUI:Create("CheckBox")
		monkRoll:SetLabel(YayMountsLocale.String.MR)
		monkRoll:SetValue(YayMounts:GetMounts("settings", "MR"))
		monkRoll:SetCallback("OnValueChanged",  function() YayMounts:SetMounts("settings", "MR", monkRoll:GetValue()) end)
		monkRoll:SetFullWidth(true)
		container:AddChild(monkRoll)
	end
	
	if class == "ROGUE" then
		local rogueSprint = AceGUI:Create("CheckBox")
		rogueSprint:SetLabel(YayMountsLocale.String.RS)
		rogueSprint:SetValue(YayMounts:GetMounts("settings", "RS"))
		rogueSprint:SetCallback("OnValueChanged",  function() YayMounts:SetMounts("settings", "RS", rogueSprint:GetValue()) end)
		rogueSprint:SetFullWidth(true)
		container:AddChild(rogueSprint)
	end
	
	if class == "DRUID" then
		local flightFormPriority = AceGUI:Create("CheckBox")
		flightFormPriority:SetLabel(YayMountsLocale.String.FFP)
		flightFormPriority:SetValue(YayMounts:GetMounts("settings", "FFP"))
		flightFormPriority:SetCallback("OnValueChanged",  function() YayMounts:SetMounts("settings", "FFP", flightFormPriority:GetValue()) end)
		flightFormPriority:SetFullWidth(true)
		container:AddChild(flightFormPriority)
		
		local travelToTravel = AceGUI:Create("CheckBox")
		travelToTravel:SetLabel(YayMountsLocale.String.TTT)
		travelToTravel:SetValue(YayMounts:GetMounts("settings", "TTT"))
		travelToTravel:SetCallback("OnValueChanged", function() YayMounts:SetMounts("settings", "TTT", travelToTravel:GetValue()) end)
		travelToTravel:SetFullWidth(true)
		container:AddChild(travelToTravel)
		
		local mountToFlightForm = AceGUI:Create("CheckBox")
		mountToFlightForm:SetLabel(YayMountsLocale.String.MTFF)
		mountToFlightForm:SetValue(YayMounts:GetMounts("settings", "MTFF"))
		mountToFlightForm:SetCallback("OnValueChanged", function() YayMounts:SetMounts("settings", "MTFF", mountToFlightForm:GetValue()) end)
		mountToFlightForm:SetFullWidth(true)
		container:AddChild(mountToFlightForm)
	end
	
	if class == "MAGE" then
		local pMLS = AceGUI:Create("CheckBox")
		pMLS:SetLabel(YayMountsLocale.String.MS)
		pMLS:SetValue(YayMounts:GetMounts("settings", "PMLS"))
		pMLS:SetCallback("OnValueChanged",  function() YayMounts:SetMounts("settings", "PMLS", pMLS:GetValue()) end)
		pMLS:SetFullWidth(true)
		container:AddChild(pMLS)
	end
	
	if class == "PRIEST" then
		local pMLS = AceGUI:Create("CheckBox")
		pMLS:SetLabel(YayMountsLocale.String.PL)
		pMLS:SetValue(YayMounts:GetMounts("settings", "PMLS"))
		pMLS:SetCallback("OnValueChanged",  function() YayMounts:SetMounts("settings", "PMLS", pMLS:GetValue()) end)
		pMLS:SetFullWidth(true)
		container:AddChild(pMLS)
	end
end

local function DrawGroup6(container) --ADDON OPTIONS
	container:SetLayout("List")
	local cPV, tempStr = 1, YayMounts.db:GetCurrentProfile()
	
	for k,v in pairs(tProfiles) do
		if v == tempStr then
			cPV = k
		end
	end
	
	local createProfile = AceGUI:Create("EditBox")
	createProfile:SetLabel("Create new Profile")
	createProfile:SetMaxLetters(15)
	
	

	
	local currentProfile = AceGUI:Create("Dropdown")
	currentProfile:SetList(tProfiles)
	currentProfile:SetLabel("Current Profile:")
	currentProfile:SetValue(cPV)
	
	local copyFrom = AceGUI:Create("Dropdown")
	copyFrom:SetList(tProfiles)
	copyFrom:SetItemDisabled(cPV, true)
	copyFrom:SetLabel("Copy settings from:")

	
	local copyButton = AceGUI:Create("Button")
	copyButton:SetWidth(75)
	copyButton:SetText("Copy")
	copyButton:SetDisabled(true)
	
	local deleteSelect = AceGUI:Create("Dropdown")
	deleteSelect:SetList(tProfiles)
	deleteSelect:SetItemDisabled(cPV, true)
	deleteSelect:SetItemDisabled(1, true)
	deleteSelect:SetLabel("Delete profile:")
	
	local deleteButton = AceGUI:Create("Button")
	deleteButton:SetWidth(100)
	deleteButton:SetText("Delete")
	deleteButton:SetDisabled(true)
	
	--Callbacks
	createProfile:SetCallback("OnEnterPressed", function()
		tempKey,tempStr = cPV, createProfile:GetText()
		if tempStr ~= "" then
			YayMounts.db:SetProfile(tempStr) 
			YayMounts:AlphaSortProfileDB()
			currentProfile:SetList(tProfiles)
			copyFrom:SetList(tProfiles)
			deleteSelect:SetList(tProfiles)
			if currentProfile:GetValue() ~= tempStr then
				for k,v in pairs(tProfiles) do
					if v == tempStr then
						tempKey = k
					end
				end
				currentProfile:SetValue(tempKey)
				copyFrom:SetItemDisabled(tempKey, true)
				copyFrom:SetItemDisabled(cPV, false)
				deleteSelect:SetItemDisabled(tempKey, true)
				deleteSelect:SetItemDisabled(cPV, false)
				deleteSelect:SetItemDisabled(1, true)			
				cPV = currentProfile:GetValue()
				createProfile:SetText("")
			end
		end
	end)
	
	currentProfile:SetCallback("OnValueChanged", function() 
		if currentProfile:GetValue() ~= cPV then 
			YayMounts.db:SetProfile(tProfiles[currentProfile:GetValue()])
			copyFrom:SetItemDisabled(currentProfile:GetValue(), true)
			copyFrom:SetItemDisabled(cPV, false)
			deleteSelect:SetItemDisabled(currentProfile:GetValue(), true)
			deleteSelect:SetItemDisabled(cPV, false)
			cPV = currentProfile:GetValue() 
		end 
	end)
	
	copyFrom:SetCallback("OnValueChanged", function() copyButton:SetDisabled(false) end)
	
	copyButton:SetCallback("OnClick", function() 
		YayMounts.db:CopyProfile(tProfiles[copyFrom:GetValue()], true) 
		copyFrom:SetValue(nil) 
		copyButton:SetDisabled(true)
		YayMounts:ReSort()
	end)
	
	deleteSelect:SetCallback("OnValueChanged", function()
		if deleteSelect:GetValue() ~= nil then
			deleteButton:SetDisabled(false) 
		else
			deleteButton:SetDisabled(true)
		end
	end)
	
	deleteButton:SetCallback("OnClick", function()
		YayMounts.db:DeleteProfile(tProfiles[deleteSelect:GetValue()], true)
		deleteSelect:SetValue(nil) 
		deleteButton:SetDisabled(true)
		YayMounts:AlphaSortProfileDB()
		currentProfile:SetList(tProfiles)
		copyFrom:SetList(tProfiles)
		deleteSelect:SetList(tProfiles)
		deleteSelect:SetItemDisabled(1, true)
		deleteSelect:SetItemDisabled(cPV, true)
	end)
	
	container:AddChild(createProfile)
	container:AddChild(currentProfile)
	container:AddChild(copyFrom)
	container:AddChild(copyButton)
	container:AddChild(deleteSelect)
	container:AddChild(deleteButton)
end

local function SelectGroup(container, event, group)-- Callback function for OnGroupSelected
	container:ReleaseChildren()
	if group == "tab1" then
		DrawGroup1(container)
 	elseif group == "tab2" then
 		DrawGroup2(container)
	elseif group == "tab3" then
 		DrawGroup3(container)
	elseif group == "tab4" then
 		DrawGroup4(container)
	elseif group == "tab5" then
		DrawGroup5(container)
	elseif group == "tab6" then
		DrawGroup6(container)
	end
	currentTab = group
end

function YayMounts:Frames(selectedTab)-- Basic frame
	if not yayFrame then
		if self.db.profile.misc["NumPets"] == 0 then
			YayMounts:ResetPetFilters()
			_, self.db.profile.misc["NumPets"] = C_PetJournal.GetNumPets(true)
			YayMounts:RestorePetFilters()
		end
		
	
		yayFrame = AceGUI:Create("Frame")
		yayFrame:SetCallback("OnClose", function(widget) AceGUI:Release(widget); yayFrame = nil end)
		yayFrame:SetTitle("Yay Mounts")
		yayFrame:SetStatusText("Version "..version..", by Cyrae - Windrunner US")
		yayFrame:SetLayout("Fill")
		yayFrame:SetWidth(720)
		yayFrame:SetHeight(490)
		
		local tTabs = {
			{text="Mounts ("..self.db.profile.misc.NumMounts["Total"]..")", value="tab1"}, 
			{text="Pets ("..self.db.profile.misc["NumPets"]..")", value="tab2"}, 
			{text="Mount Options", value="tab3"}, 
			{text="Pet Options", value="tab4"},
			{text="Profile Options", value="tab6"},
		}
	
		if class == "MAGE" or class == "PRIEST" or class == "DRUID" or class == "MONK" or class == "ROGUE" then
			tinsert(tTabs, 5, {text=""..localClass.." Options", value = "tab5"})
		end
	
		local tab = AceGUI:Create("TabGroup")
		tab:SetLayout("Flow")
		tab:SetTabs(tTabs)
		tab:SetCallback("OnGroupSelected", SelectGroup)
		tab:SelectTab(selectedTab)
		yayFrame:AddChild(tab)
		
	else
		AceGUI:Release(yayFrame)
		yayFrame, currentTab, currentSubTab = nil
	end
end

--------------------------------------------------------------
--Mounting and button click functions
--------------------------------------------------------------
function YayMounts:Mounting(flyable, zone)
	if self.db.profile.settings["HM"] then --fix this for running wild
		local e = {}
		local i, useRepairMount = 1, false
		local mountType		
		
		--Repair mount code
		if size(self.db.profile.misc.RepairMounts) >0 and self.db.profile.settings["URM"] then
			for i = 0, 17 do
				current, maximum = GetInventoryItemDurability(i)
				if current ~= nil and maximum ~= nil then
					if (current / maximum) <= self.db.profile.misc["MinDurability"] then
						useRepairMount = true
					end
				end
			end
			
			for i = 0, 4 do
				for j = 0, GetContainerNumSlots(i) do
					current, maximum = GetContainerItemDurability(i, j);
					if current ~= nil and maximum ~= nil then
						if (current / maximum) <= self.db.profile.misc["MinDurability"] then
							useRepairMount = true
						end
					end
				end
			end
		end
		
		if useRepairMount then
			for k in pairs(self.db.profile.misc.RepairMounts) do
				if self.db.profile.mounts[k][4] then
					e[i] = k
					i = i + 1
				end
			end
							
			if #e == 0 then 
				for k in pairs(self.db.profile.misc.RepairMounts) do
					e[i] = k
					i = i + 1
				end
			end
							
			if #e == 0 then 
				self:Print("Error with Repair Mount table e")
				return
			end
			
			return YayMounts:SpellToName(e[math.random(#e)])
		end
		--end repair mount code
		
		if flyable then
			mountType = "fly"
		else
			mountType = "ground"
		end
		
		--write code to prefer scaling mounts over ground mounts when underwater, unless in vashjir?
		if usePassengerMount then
			for k,v in pairs(YayMountsType["Passenger"]) do
				if mountType == "fly" then
					if IsUsableSpell(k) and v == "fly" then
						e[i] = k
						i = i + 1
					end
				else
					if IsUsableSpell(k) then
						e[i] = k
						i = i + 1
					end
				end
			end
			
			if mountType == "fly" and #e == 0 then
				for k,v in pairs(YayMountsType["Passenger"]) do
					if IsUsableSpell(k) then
						e[i] = k
						i = i + 1
					end
				end
			end
		else
			for k,v in pairs(self.db.profile.mounts) do
				if IsUsableSpell(k) then
					if self.db.profile.settings["SMIFO"] then
						if mountType == "fly" then
							if (v[3] == mountType or v[3] == "scaling") and v[4] then
								e[i] = k
								i = i + 1
							end
							
						else
							if v[3] == mountType and v[4] then
								e[i] = k
								i = i + 1
							end
						end
					
					else
						if (v[3] == mountType or v[3] == "scaling") and v[4] then
							e[i] = k
							i = i + 1
						end
					end
				end
			end		
			
			if self.db.profile.settings["FFM"] and mountType == "ground" and (IsUsableSpell(61229) or IsUsableSpell(32295)) then
				for k,v in pairs(self.db.profile.mounts) do
					if (v[3] == "fly") and v[4] then
						if IsUsableSpell(k) then
							e[i] = k
							i = i + 1
						end
					end
				end
			end
		end
		
		e = YayMounts:Filter(e, zone)
		
		if #e == 0 and self.db.profile.settings["ER"] then
			i = 1
			for k,v in pairs(self.db.profile.mounts) do
				if IsUsableSpell(k) and (v[3] == mountType or v[3] == "scaling")  then				
					e[i] = k
					i = i + 1
				end
			end
			
			if i == 1 then
				for k,v in pairs(self.db.profile.mounts) do
					if IsUsableSpell(k) then				
						e[i] = k
						i = i + 1
					end
				end
			end
			
			e = YayMounts:Filter(e, zone)
		
		elseif #e == 0 then
			self:Print(YayMountsLocale.String.NoMounts)
			return nil
		end
		
		mountUsed = YayMounts:SpellToName(e[math.random(#e)])
		return mountUsed
	end
end

function YayMounts:PreClick()
local _,_,_,_, feralSwiftness = GetTalentInfo(2, 1)
local _,_,WGActive,_,_,_ = GetWorldPVPAreaInfo(1)
local zone = GetRealZoneText()
local flyable
local broom = false
local loanedMount = nil

	if zone == YayMountsLocale.Zone.Wintergrasp and WGActive then --Check if in wintergrasp and no battle
		flyable = true
	end
	
	--if IsUsableSpell(25528) == 1 or IsUsableSpell(32295) then
	if IsUsableSpell(59976) then
		flyable = true
	else
		flyable = false
	end
	
	loanedMount = YayMounts:CheckMountTraining(zone, loanedMount) --check if we have cold weather flying, a loaned mount, and/or flight master's license

	if IsUsableS(2645) then --check if we have instant ghost wolf
		ghostWolf = true
	end
	
	 
	if GetItemCount(37011, false) > 0 and not playerCombat and self.db.profile.settings["FBP"] == true then -- check if we can use flying broom
		broom = true
	end
		
	------------Smart mounting stuff-------------

	if IsMounted() and IsFlying() then
		if class == "DRUID" and self.db.profile.settings["MTFF"] and IsFlying() and GetUnitSpeed("player") ~= 0 then -- Druid: Flying mount to flight form
			YayMounts:Druids(flyable, zone)
			
		elseif self.db.profile.settings["NDWF"] then
			YayMounts:SetMacroButton()
		else
			Dismount()
			YayMounts:SetMacroButton()
		end
	
	elseif IsMounted() then
		if IsSwimming() and class == "DRUID" and IsUsableS(1066) and GetUnitSpeed("player") ~= 0  then
			YayMounts:SetMacroButton(YayMounts:SpellToName(1066)) -- Aquatic Form
			
		else
			Dismount()
			YayMounts:SetMacroButton()
		end
		
	elseif CanExitVehicle() then
		YayMounts:SetMacroButton()
		VehicleExit()
		
	elseif YayMounts:PriestOrMage() then
		return
		
	elseif flyable and IsOutdoors() then
		if broom then --flying broom
			YayMounts:SetMacroButton(YayMounts:ItemToName(37011))
			
		elseif class == "SHAMAN" and ghostWolf and (playerCombat or GetUnitSpeed("player") ~= 0) then
			YayMounts:SetMacroButton(YayMounts:SpellToName(2645)) --Ghost wolf
			
		elseif class == "MONK" and self.db.profile.settings["MR"] and IsUsableS(109132) and (playerCombat or GetUnitSpeed("player") ~= 0) then
			YayMounts:SetMacroButton(YayMounts:SpellToName(109132)) --Roll
			
		elseif class == "ROGUE" and self.db.profile.settings["RS"] and IsUsableS(2983) and (playerCombat or GetUnitSpeed("player") ~= 0) then
			YayMounts:SetMacroButton(YayMounts:SpellToName(2983)) --Sprint		
			
		elseif IsSwimming() then
			YayMounts:Swimming(flyable, zone, broom)
			
		elseif class == "DRUID" then
			YayMounts:Druids(flyable, zone)
			
		else
			YayMounts:SetMacroButton(YayMounts:Mounting(flyable, zone))
		end
		
	elseif not flyable and IsOutdoors() and zone ~= YayMountsLocale.Zone.VortexPinnacle then
		if zone == YayMountsLocale.Zone.Oculus and YayMounts:Filter(nil, zone) then
			return
			
		elseif broom then --flying broom
			YayMounts:SetMacroButton(YayMounts:ItemToName(37011))			
			
		elseif class == "SHAMAN" and ghostWolf and (playerCombat or GetUnitSpeed("player") ~= 0) then
			YayMounts:SetMacroButton(YayMounts:SpellToName(2645)) --Ghost wolf
			
		elseif class == "SHAMAN" and not self.db.profile.settings["HM"] and GetUnitSpeed("player") == 0 then
			YayMounts:SetMacroButton(YayMounts:SpellToName(2645))
			
		elseif class == "MONK" and self.db.profile.settings["MR"] and IsUsableS(109132) and (playerCombat or GetUnitSpeed("player") ~= 0) then
			YayMounts:SetMacroButton(YayMounts:SpellToName(109132)) --Roll
			
		elseif class == "ROGUE" and self.db.profile.settings["RS"] and IsUsableS(2983) and (playerCombat or GetUnitSpeed("player") ~= 0) then
			YayMounts:SetMacroButton(YayMounts:SpellToName(2983)) --Sprint
			
		elseif IsSwimming() then
			YayMounts:Swimming(flyable, zone, broom)
			
		elseif loanedMount ~= nil and not playerCombat and GetUnitSpeed("player") == 0 then
			YayMounts:SetMacroButton(YayMounts:ItemToName(loanedMount))
			
		elseif class == "DRUID" then
			YayMounts:Druids(flyable, zone)
			
		else
			YayMounts:SetMacroButton(YayMounts:Mounting(flyable, zone))
		end
		
	elseif not IsOutdoors() or zone == YayMountsLocale.Zone.VortexPinnacle then
		if IsSwimming() then
			YayMounts:Swimming(flyable, zone, broom)
			
		elseif class == "DRUID" and IsUsableS(768) then
			YayMounts:SetMacroButton(YayMounts:SpellToName(768))
			
		elseif class == "SHAMAN" and IsUsableS(2645) then
			YayMounts:SetMacroButton(YayMounts:SpellToName(2645)) --Ghost wolf
			
		elseif class == "MONK" and self.db.profile.settings["MR"] and IsUsableS(109132) then
			YayMounts:SetMacroButton(YayMounts:SpellToName(109132)) --Roll
			
		elseif class == "ROGUE" and self.db.profile.settings["RS"] and IsUsableS(2983) and (playerCombat or GetUnitSpeed("player") ~= 0) then
			YayMounts:SetMacroButton(YayMounts:SpellToName(2983)) --Sprint
		end
		
	else
		YayMounts:SetMacroButton(YayMounts:Mounting(flyable, zone))
	end
end

function YayMounts:ForcePassengerMount()
	usePassengerMount = true
	YayMounts:PreClick()
	usePassengerMount = false
end

function YayMounts:PriestOrMage()
	if not playerCombat then
		if (IsFalling() or GetUnitSpeed("player") ~= 0) and class == "PRIEST" and IsUsableS(1706) and self.db.profile.settings["PMLS"] then --IsUsableSpell checks for reagents/glyphs
			YayMounts:SetMacroButton("[@player] "..YayMounts:SpellToName(1706).."\n/cancelaura "..YayMounts:SpellToName(1706)) --Levitate
			return true
			
		elseif (IsFalling() or GetUnitSpeed("player") ~= 0) and class == "MAGE" and IsUsableS(130) and self.db.profile.settings["PMLS"] then
			YayMounts:SetMacroButton("[@player] "..YayMounts:SpellToName(130).."\n/cancelaura "..YayMounts:SpellToName(130)) --Slow fall
			return true
			
		else
			return false
		end
	end
end

function YayMounts:Druids(flyable, zone)
	local flightForm = 5
	if GetSpecialization() == 1 then
		flightForm = 6
	end
	
	if (flyable and not playerCombat) then
		if IsSwimming() then
			YayMounts:SetMacroButton(YayMounts:Mounting(flyable, zone), 1)
		elseif (GetUnitSpeed("player") == 0 and self.db.profile.settings["FFP"]) or IsFalling() or IsFlying() or GetUnitSpeed("player") ~= 0 or GetShapeshiftForm() == flightForm then
			if IsUsableS(40120) then --Swift Flight Form
				YayMounts:SetMacroButton(YayMounts:SpellToName(40120))
			elseif IsUsableS(33943) then --Flight Form
				YayMounts:SetMacroButton(YayMounts:SpellToName(33943))
			end
		else
			YayMounts:SetMacroButton(YayMounts:Mounting(flyable, zone), 1)
		end
		
	elseif IsUsableS(783) and (playerCombat or GetUnitSpeed("player") ~= 0) then --Travel Form
		YayMounts:SetMacroButton(YayMounts:SpellToName(783))
		
	elseif not playerCombat then
		YayMounts:SetMacroButton(YayMounts:Mounting(false, zone), 1)	
	end
end

function YayMounts:Swimming(flyable, zone, broom)
	local timer, _,_,scale,_,_ = GetMirrorTimerInfo(2)
	local name, _, _, _, _, _, _, _, _, _, _ = UnitBuff("player", YayMountsLocale.Misc.WaterBreathing)
	if timer == "UNKNOWN" or scale >= 0 then
		scale = 1
	end
	
	if flyable and not playerCombat then
		if class == "DRUID" and IsUsableS(1066) and GetUnitSpeed("player") ~= 0 then
			YayMounts:SetMacroButton(YayMounts:SpellToName(1066)) --Aquatic Form
		elseif class == "DRUID" then
			YayMounts:Druids(flyable, zone)
		--elseif broom then
			--YayMounts:SetMacroButton(YayMounts:ItemToName(33176)) --Flying Broom
		else
			YayMounts:SetMacroButton(YayMounts:Mounting(true, zone))
		end
		
	elseif IsOutdoors() and not playerCombat then
		if class == "DRUID" and IsUsableS(1066) and GetUnitSpeed("player") ~= 0 then
			YayMounts:SetMacroButton(YayMounts:SpellToName(1066)) --Aquatic Form
		else 
			if zone == YayMountsLocale.Zone.Vashjir1 or zone == YayMountsLocale.Zone.Vashjir2 or zone == YayMountsLocale.Zone.Vashjir3 or zone == YayMountsLocale.Zone.Vashjir4 or zone == YayMountsLocale.Zone.Vashjir5 and self.db.profile.mounts[75207][4] == true then --Abyssal Seahorse
				YayMounts:SetMacroButton(YayMounts:SpellToName(75207)) --Abyssal Seahorse
			elseif IsUsableSpell(98718) and self.db.profile.mounts[98718][4] == true then
				YayMounts:SetMacroButton(YayMounts:SpellToName(98718)) --Subdued Seahorse
			elseif IsUsableM(64731) and self.db.profile.mounts[64731][4] then
				YayMounts:SetMacroButton(YayMounts:SpellToName(64731)) --Sea Turtle
			else
				YayMounts:SetMacroButton(YayMounts:Mounting(false, zone))
			end
		end
		
	elseif not playerCombat then
		if class == "DRUID" and IsUsableS(1066) then
			YayMounts:SetMacroButton(YayMounts:SpellToName(1066)) -- Aquatic Form
		elseif class == "SHAMAN" and IsUsableS(2645) then
			YayMounts:SetMacroButton(YayMounts:SpellToName(2645)) --Ghost wolf
		end
	end
end

function YayMounts:CheckMountTraining(zone, loanedMount)
	if zone == YayMountsLocale.Zone.StormPeaks or zone == YayMountsLocale.Zone.Icecrown then
		if GetItemCount(44221, false) > 0 then
			return 44221
		elseif GetItemCount(44229, false) > 0 then
			return 44229
		else
			return nil
		end
	end
	return loanedMount, flyable
end

function YayMounts:SetMacroButton(mount, button)
	if not playerCombat then
		if mount and button == 2 then
			YayMountsButton2:SetAttribute("macrotext", "/use "..YayMounts:Mounting(false, GetRealZoneText()))
		elseif mount and button == 3 then
			YayMountsButton3:SetAttribute("macrotext", "/script C_PetJournal.SummonPetByGUID("..mount..")") --for mini-pet summoning
		elseif mount and usePassengerMount then
			YayMountsButton4:SetAttribute("macrotext", "/use "..mount)
		elseif mount then
			YayMountsButton:SetAttribute("macrotext", "/use "..mount)		
		else
			YayMountsButton:SetAttribute("macrotext", nil)
		end
	end
end

function YayMounts:SetMacroButtonCombat(mount, button)
	if mount and button == 2 then
		YayMountsButton2:SetAttribute("macrotext", "/use "..YayMounts:Mounting(false, GetRealZoneText()))

		elseif mount and button == 3 then
			YayMountsButton3:SetAttribute("macrotext", "/use "..mount)
		elseif mount then
			YayMountsButton:SetAttribute("macrotext", "/use "..mount)
		else
			YayMountsButton:SetAttribute("macrotext", nil)
		end
end

function YayMounts:Filter(e, zone)
	if zone ~= YayMountsLocale.Zone.AQ40 and e ~= nil then
		for k,v in pairs(e) do
			if v == YayMountsType["Ahn'Qiraj"][v] then
				tremove(e, k)
			end
		end
		return e
		
	elseif zone == YayMountsLocale.Zone.AQ40 and e ~= nil then
		local aq40 = false
		local aq40Table = {}
		local i = 1
		
		for k,v in pairs(e) do
			if v == YayMountsType["Ahn'Qiraj"][v] then
				aq40 = true
				
				break
			end
		end
		
		if aq40 then
			for k,v in pairs(e) do
				if v == YayMountsType["Ahn'Qiraj"][v] then
					aq40Table[i] = v
					i = i + 1
				end
			end
			return aq40Table
		
		else
			return e
		end
		
	
	elseif zone == YayMountsLocale.Zone.Oculus and e == nil then
		if GetItemCount(37859) == 1 then
			YayMounts:SetMacroButton(YayMounts:ItemToName(37859))
			return true
		elseif GetItemCount(37860) == 1 then
			YayMounts:SetMacroButton(YayMounts:ItemToName(37860))
			return true
		elseif GetItemCount(37815) == 1 then
			YayMounts:SetMacroButton(YayMounts:ItemToName(37815))
			return true
		end
		return false
		
	else
		return e
	end
end

function YayMounts:EventHandler(arg1, arg2)
	if  arg1 == "PLAYER_REGEN_DISABLED" then
		playerCombat = true
		if class == "SHAMAN" then
			YayMounts:SetMacroButtonCombat(YayMounts:SpellToName(2645))
		elseif class == "DRUID" then
			if not self.db.profile.settings["TTT"] then
				YayMounts:SetMacroButtonCombat("[swimming] "..YayMounts:SpellToName(1066).."; [outdoors] "..YayMounts:SpellToName(783).."; "..YayMounts:SpellToName(768))
			else
				YayMounts:SetMacroButtonCombat("[swimming] !"..YayMounts:SpellToName(1066).."; [outdoors] !"..YayMounts:SpellToName(783).."; !"..YayMounts:SpellToName(768))
			end
			
		elseif class == "PRIEST" then
			if IsUsableS(1706) and self.db.profile.settings["PMLS"] then --IsUsableSpell checks for reagents/glyphs
				YayMounts:SetMacroButtonCombat("[@player] "..YayMounts:SpellToName(1706).."\n/cancelaura "..YayMounts:SpellToName(1706)) --Levitate
			end
			
		elseif class == "MAGE" then
			if IsUsableS(130) and self.db.profile.settings["PMLS"] then
				YayMounts:SetMacroButtonCombat("[@player] "..YayMounts:SpellToName(130).."\n/cancelaura "..YayMounts:SpellToName(130)) --Slow fall
			end
		
		elseif class == "MONK" and self.db.profile.settings["MR"] then
			if IsUsableS(109132) then
				YayMounts:SetMacroButtonCombat(YayMounts:SpellToName(109132)) --Roll
			end
		end
		
	elseif arg1 == "PLAYER_REGEN_ENABLED" then
		playerCombat = false
		YayMounts:SetMacroButton()
		
	elseif arg1 == "PLAYER_LEVEL_UP" then
		if arg2 == 20 then
			YayMounts:ReSort()
			self:UnregisterEvent("PLAYER_LEVEL_UP")
		end
		
	elseif arg1 == "COMPANION_LEARNED" then
		YayMounts:ReSort()
		if yayFrame then
			local ct, cst = currentTab, currentSubTab
			YayMounts:Frames()
			currentSubTab = cst
			YayMounts:Frames(ct)
		end
		
	elseif arg1 == "PLAYER_ENTERING_WORLD" then
		YayMounts:Delay(f, 3.5, false)
	
	elseif (arg1 == "PLAYER_UNGHOST" or arg1 == "PLAYER_ALIVE") and UnitIsDeadOrGhost("player") == nil and self.db.profile.settings["SPAD"] then
		YayMounts:Delay(f, 3.5, false)
		
	elseif arg1 == "UPDATE_STEALTH" then
		if IsStealthed() and ( UnitIsPVP("player") or self.db.profile.settings["ASD"] ) then
			YayMounts:CallPet("stealth")
		end		
	end
end

--------------------------------------------------------------
--Pet stuff
--------------------------------------------------------------
function YayMounts:CallPet(event)
	if playerCombat or IsFalling() or CanExitVehicle() or (UnitChannelInfo("player") ~= nil) or UnitBuff("player", "Food") or UnitBuff("player", "Drink") then
		return
	end
	

	YayMounts:ResetPetFilters()
	
	if self.db.profile.misc["NumPets"] == 0 then
		_, self.db.profile.misc["NumPets"] = C_PetJournal.GetNumPets(true)
	end
	
	if event == "stealth" then
		if C_PetJournal.GetSummonedPetGUID() then
			C_PetJournal.SummonPetByGUID(C_PetJournal.GetSummonedPetGUID())
		end
		
	elseif not IsStealthed() then
		if self.db.profile.misc["NumPets"] > 0 then
			local e = {}
			local i, S = 1, 0
			
			for k,v in pairs(self.db.profile.pets) do
				if v[1] then
					e[i] = v[2]
					i = i + 1
				end
			end
			
			if #e == 0 then
				for k,v in pairs(self.db.profile.pets) do
					e[i] = v[2]
					i = i + 1
				end
			end
			
			if #e == 0 then
				return
			end
				
			S = e[math.random(#e)]
			id = C_PetJournal.GetPetInfoByIndex(S)			
			
		if id == nil then
			YayMounts:RestorePetFilters()
			return
		end
			
			C_PetJournal.SummonPetByGUID(id)
			YayMounts:RestorePetFilters()
		end
	end
end

function YayMounts:ResetPetFilters()
	for i=1, C_PetJournal.GetNumPetTypes() do
		filters.Types[i] = not C_PetJournal.IsPetTypeFiltered(i)
	end
	
	for i=1, C_PetJournal.GetNumPetSources() do
		filters.Sources[i] =  not C_PetJournal.IsPetSourceFiltered(i)
	end
	
	filters.Flags[1] = not C_PetJournal.IsFlagFiltered(LE_PET_JOURNAL_FLAG_COLLECTED)
	filters.Flags[2] = not C_PetJournal.IsFlagFiltered(LE_PET_JOURNAL_FLAG_NOT_COLLECTED)
	filters.Flags[3] = not C_PetJournal.IsFlagFiltered(LE_PET_JOURNAL_FLAG_FAVORITES)

	C_PetJournal.AddAllPetTypesFilter()
	C_PetJournal.AddAllPetSourcesFilter()
	C_PetJournal.ClearSearchFilter()
	C_PetJournal.SetFlagFilter(LE_PET_JOURNAL_FLAG_COLLECTED, true)
	C_PetJournal.SetFlagFilter(LE_PET_JOURNAL_FLAG_NOT_COLLECTED, false)
	C_PetJournal.SetFlagFilter(LE_PET_JOURNAL_FLAG_FAVORITES, false)
end

function YayMounts:RestorePetFilters()
	for i=1, C_PetJournal.GetNumPetTypes() do
		C_PetJournal.SetPetTypeFilter(i, filters.Types[i])
	end
	
	for i=1, C_PetJournal.GetNumPetSources() do
		C_PetJournal.SetPetSourceFilter(i, filters.Sources[i])
	end
	
	C_PetJournal.SetFlagFilter(LE_PET_JOURNAL_FLAG_COLLECTED, filters.Flags[1])
	C_PetJournal.SetFlagFilter(LE_PET_JOURNAL_FLAG_NOT_COLLECTED, filters.Flags[2])
	C_PetJournal.SetFlagFilter(LE_PET_JOURNAL_FLAG_FAVORITES, filters.Flags[3])
	
	wipe(filters.Types)
	wipe(filters.Sources)
	wipe(filters.Flags)
end
--------------------------------------------------------------
--Keybinding stuff
--------------------------------------------------------------
function YayMounts:MapOverrides()
	if not InCombatLockdown() then
		ClearOverrideBindings(YayMountsButton)
		local key1 = GetBindingKey("YAYMOUNTBINDING")
		if key1 then
			SetOverrideBindingClick(YayMountsButton, true, key1, YayMountsButton:GetName())
		end

		ClearOverrideBindings(YayMountsButton2)
		key1 = GetBindingKey("YAYMOUNTBINDING2")
		if key1 then
			SetOverrideBindingClick(YayMountsButton2, true, key1, YayMountsButton2:GetName())
		end
		
		ClearOverrideBindings(YayMountsButton3)
		key1 = GetBindingKey("YAYMOUNTBINDING3")
		if key1 then
			SetOverrideBindingClick(YayMountsButton3, true, key1, YayMountsButton3:GetName())
		end
		
		ClearOverrideBindings(YayMountsButton4)
		key1 = GetBindingKey("YAYMOUNTBINDING4")
		if key1 then
			SetOverrideBindingClick(YayMountsButton4, true, key1, YayMountsButton4:GetName())
		end
	end
end

function YayMounts:Keybinding(key, buttonID)
	if not key then
		key = ""
	end

	if not InCombatLockdown() then
		if buttonID == 1 then
			local key1 = GetBindingKey("YAYMOUNTBINDING")
			if key1 then
				SetBinding(key1)
			end
			SetBinding(key, "YAYMOUNTBINDING")
			
		elseif buttonID == 2 then
			local key1 = GetBindingKey("YAYMOUNTBINDING2")
			if key1 then
				SetBinding(key1)
			end
			SetBinding(key, "YAYMOUNTBINDING2")
					
		elseif buttonID == 3 then
			local key1 = GetBindingKey("YAYMOUNTBINDING3")
			if key1 then
				SetBinding(key1)
			end
			SetBinding(key, "YAYMOUNTBINDING3")
		
		elseif buttonID == 4 then
			local key1 = GetBindingKey("YAYMOUNTBINDING4")
			if key1 then
				SetBinding(key1)
			end
			SetBinding(key, "YAYMOUNTBINDING4")
		end
	end	
	
	SaveBindings(GetCurrentBindingSet())
end

function YayMounts:Delay(f, d, re)
	local delay = d
	
	f:Show()
	if not re then
		f:SetScript("OnUpdate", function(this, expired)
			delay = delay - expired
			if delay < 0 then
				YayMounts:CallPet(true)
				this:Hide()
			end
		end)
	else
		f:SetScript("OnUpdate", function(this, expired)
			delaySPEXS = delaySPEXS - expired
			if delaySPEXS < 0 then
				YayMounts:CallPet(true)
				delaySPEXS = self.db.profile.misc["Delay"]
			end
        end)
	end
end