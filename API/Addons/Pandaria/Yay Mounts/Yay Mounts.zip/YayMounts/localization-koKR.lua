﻿if GetLocale() == "koKR" then
BINDING_HEADER_YAYMOUNTSHEADER = "YayMounts"
BINDING_NAME_YAYMOUNTBINDING = "Mount/Dismount"
BINDING_NAME_YAYMOUNTBINDING2 = "Force Ground Mounting"

YayMountsLocale = {
	String = {
		NoYMP = "Yay Mounts can help handle your Mini-pets. To do so, please click the button below!",
		NDWF = "Don't dismount while flying. You'll have to land or (if enabled in Blizzard options) cast a spell",
		ER = "Choose random usable mount if no usable mounts selected",
		FFP = "Druid: Prioritize using Flight Form over a regular mount even when not moving",
		FBP = "Prioritize using Flying Broom over a regular mount when not moving, even over Flight Form",
		FBPD = "Prioritize using Flying Broom over a regular mount when not moving",
		NoMounts = "No mounts Selected",
		FFM = "Use Flying type mounts even in areas where you cannot fly",
		NewMountFound = "New mount found: ",
		TTT = "Druid: When in combat, shift from Travel or Aquatic form directly back to that form",
		MTFF = "Druid: When on a flying mount and flying + moving, shift into Flight Form",
		AL = "Pressing the mount keybind while moving (or in combat if enabled) will swap between the Aspects selected below",
		AL2 = "Aspects for [Force Ground Mounting]",
		AIC = "Hunter: YayMounts aspect swapping while in combat (WARNING: This can be buggy)",
		UA = "Hunter: [Mount/Dismount] will swap between the Aspects selected below",
		UA2= "Hunter: [Force Ground Mounting] will swap between the Aspects selected below",
		PL = "Priest: Mount/Dismount keybind will use levitate on yourself when you are falling or in combat",
		MS = "Mage: Mount/Dismount keybind will use slowfall on yourself when you are falling or in combat",
		SMIFO = "Only use scaling type mounts in flyable areas",
		ASP = "Automatically use a random pet when changing instances or logging in",
		ASD = "Always dismiss mini-pets when stealthing",
		SPAD = "Summon a mini-pet after ressurecting. Delayed slightly to avoid causing a GCD after ressurecting",
		SPEXS = "Attempt to summon a new pet every X minutes",
		URM = "Use a Repair mount if player owns one and if under X durability",
		MS = "Mage: Mount/Dismount keybind will use Slowfall on yourself when you are falling or in combat",
		MR = "Monk: Mount/Dismount keybind will use Roll when unable to mount",
	},
	
	Zone = {
		AQ40 = "안퀴라즈",
		Deadmines = "죽음의 폐광",
		Icecrown = "얼음왕관",
		Oculus = "마력의 눈",
		StormPeaks = "폭풍우 봉우리",
		Wintergrasp = "겨울손아귀 호수",
		Vashjir1 = "켈프타르 숲",
		Vashjir2 = "흐린빛 벌판",
		Vashjir3 = "심연의 나락",
		Vashjir4 = "바쉬르",
		Vashjir5 = "안개빛 방",
		VashjirNespirah = "Nespirah",
		VashjirLGhorek = "L'Ghorek",
		VortexPinnacle = "소용돌이 누각",
	},
	
	Misc = {
		WaterBreathing = "Water Breathing",
		optionsGUIButton = "Open GUI",
		mountsReloaded = "Databases reloaded",
	},
}
end