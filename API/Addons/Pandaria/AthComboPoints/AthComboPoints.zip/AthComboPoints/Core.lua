local class = strlower(select(2, UnitClass("Player")));
local classes = {
	["rogue"] = 5, -- anticipation below
	["druid"] = 5, 
	["monk"] = 5, -- 4 + 1 (talent)
	["paladin"] = 5 -- 3 + 2
};

if classes[class] == nil then
	return;
end

local class_resource_func = {
	["rogue"] = GetComboPoints,
	["druid"] = GetComboPoints,
	["monk"] = function() return UnitPower("player", SPELL_POWER_CHI) end,
	["paladin"] = function() return UnitPower("player", SPELL_POWER_HOLY_POWER) end,
};




local frame = CreateFrame("frame", nil, UIParent);
frame:SetFrameStrata("BACKGROUND");
frame:SetHeight(90);
frame:SetWidth(35);
frame:SetPoint("CENTER", UIParent, "CENTER", 100, -50);


frame.CP = CreateFrame("frame");

for i = 1, classes[class] do
	tinsert(frame.CP, CreateFrame("frame", nil, frame));
	local CP = frame.CP[i];

	CP:SetHeight(15);
	CP:SetWidth(15);

	CP.Texture = CP:CreateTexture();
	CP.Texture:SetAllPoints(CP);
	CP.Texture:SetTexture("Interface\\ComboFrame\\ComboPoint");
	CP.Texture:SetTexCoord(0,0.375,0,0.8);
	CP.Texture:SetVertexColor(0.8, 0.2, 0.2);

	CP:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, -(18)*(i-1));
end

local function updateCP()
	for i = 1, classes[class] do
		if i > class_resource_func[class]("player") then
			frame.CP[i]:Hide();
		else
			frame.CP[i]:Show();
		end
	end
end


if class == "rogue" or class == "druid" then
	frame.CP:RegisterEvent("UNIT_COMBO_POINTS");
	frame.CP:RegisterEvent("PLAYER_TARGET_CHANGED");

	frame.CP:SetScript("OnEvent", updateCP);
else
	frame.CP:RegisterEvent("UNIT_POWER");

	local resourceType = {
		["paladin"] = "HOLY_POWER",
		["monk"] = "CHI",
	}

	frame.CP:SetScript("OnEvent", function(self, event, ...)
		local arg1, arg2 = ...;
		if arg1 == "player" and arg2 == resourceType[class] then
			updateCP();
		end
	end);
end

updateCP();


if class ~= "rogue" then -- the code below does anyone else
	return;
end

local UnitAura = UnitAura;
local select = select;

frame.Anticipation = CreateFrame("frame");
frame.Anticipation:RegisterEvent("UNIT_AURA");

for i = 1,5 do
	tinsert(frame.Anticipation, CreateFrame("frame", nil, frame));
	local CP = frame.Anticipation[i];

	CP:SetHeight(15);
	CP:SetWidth(15);

	CP.Texture = CP:CreateTexture();
	CP.Texture:SetAllPoints(CP);
	CP.Texture:SetTexture("Interface\\ComboFrame\\ComboPoint");
	CP.Texture:SetTexCoord(0,0.375,0,0.8);
	CP.Texture:SetVertexColor(0.6, 0.2, 1);

	CP:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, -(18)*(i-1));
end

local function updateAnticipation(self, event, arg1)
	if arg1 ~= "player" then
		return
	end
	
	local count = select(4, UnitAura("player", "Anticipation"))

	for i = 1,5 do
		if (not count) or (i > count) then
			frame.Anticipation[i]:Hide();
		else
			frame.Anticipation[i]:Show();
		end
	end
end

frame.Anticipation:SetScript("OnEvent", updateAnticipation);
updateAnticipation(frame.Anticipation, "UNIT_AURA", "player");




