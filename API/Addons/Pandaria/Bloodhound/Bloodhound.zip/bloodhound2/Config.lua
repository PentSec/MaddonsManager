-------- YOU'RE ON YOUR OWN HERE, THIS IS A FRIKKIN MESS - Osmium
-------- Challenge Accepted - Whyzerman

local element;
local frame;

Settings = {};
Settings.MultiZoneMode = 0;
Settings.HerbFilter = {};
Settings.OreFilter = {};
Settings.MiscFilter = {};
Settings.ZoneFilter = {{}, {}, {}, {}, {}};
Settings.InspectionRadius = 60;

local function Title(text)
	local str = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
	str:SetPoint("TOPLEFT", element, "TOPLEFT", 16, -16);
	str:SetJustifyH("LEFT");
	str:SetJustifyV("TOP");
	str:SetText(text);
	element = str;
end

local function Column2(offset)
	local str = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
	str:SetPoint("TOPLEFT", element, "TOPRIGHT", -offset, -16);
	str:SetText(" ");
	element = str;
end

local function Heading(text)
	local str = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight");
	str:SetPoint("TOPLEFT", element, "BOTTOMLEFT", 0, -8);
	str:SetText(text);
	element = str;
end

local ddCount = 0;

local function DropDown(settings, key, width, init)
	ddCount = ddCount + 1;
	local dd = CreateFrame("Frame", "dropDown"..ddCount, frame, "UIDropDownMenuTemplate");
	dd:EnableMouse(true);
	dd:SetPoint("TOPLEFT", element, "BOTTOMLEFT", 0, -8);
	dd.State = {};
	UIDropDownMenu_Initialize(dd, init);
	UIDropDownMenu_SetWidth(dd, width);
	UIDropDownMenu_JustifyText(dd, "LEFT");
	UIDropDownMenu_SetSelectedValue(dd, settings[key]);
	element = dd;
end

function AddButton(settings, key, menu, label, value)
	local info = UIDropDownMenu_CreateInfo();
	info.text = label;
	info.value = value;
	info.owner = menu;
	info.func = function()
		UIDropDownMenu_SetSelectedValue(menu, value);
		settings[key] = value;
		Bloodhound2.UpdateMinimap();
	end;
	UIDropDownMenu_AddButton(info);
end

local cbCount = 0;

function CheckBox(label, value, relative, anchor, dx, dy, state)
	cbCount = cbCount + 1;
	local cb = CreateFrame("CheckButton", "checkBox"..cbCount, frame, "UICheckButtonTemplate");
	cb:SetWidth(16);
	cb:SetHeight(16);
	cb:SetPoint("TOPLEFT", relative, anchor, dx, dy);
	local text = getglobal(cb:GetName() .. "Text");
	text:SetText(label);
	cb:SetChecked(not state[value]);
	cb:SetScript("OnClick", function(self)
		if (self:GetChecked()) then
			state[value] = nil;
		else
			state[value] = 1;
		end
		Bloodhound2.UpdateMinimap();
	end);
	element = cb;
	return text:GetWidth();
end

function ContinentName()
	return select(GetCurrentMapContinent(), GetMapContinents());
end

function CheckBoxes(table, state)
	local relative;
	local bottom;
	local height = 1;
	local maxWidth = 0;
	local i = 0;
	local checkboxes = {};

	for k, v in pairs(table) do
		height = height + 1;
	end

	height = floor(height / 2);
	if height > 19 then height = 19; end;

	for k, v in pairs(table) do
		i = i + 1;
		if (i > 1) and (mod(i, height) == 1) then
			width = CheckBox(v, k, relative, "TOPRIGHT", maxWidth + 6, 0, state);	
			relative = element;
			maxWidth = width;
		else
			width = CheckBox(v, k, element, "BOTTOMLEFT", 0, 0, state);
			if (i == 1) then relative = element; end;
			maxWidth = max(width, maxWidth);
		end
		if (i == height) then bottom = element; end;
		checkboxes[k] = element;
	end

	local button = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate");
	button:SetText(L["All"]);
	local allWidth = button:GetTextWidth() + 30;
	button:SetWidth(allWidth);
	button:SetHeight(22);
	button:SetPoint("TOPLEFT", bottom, "TOPLEFT", 0, -20);
	button:SetScript("OnClick", 
		function(self, button, down)
			for k, v in pairs(table) do
				checkboxes[k]:SetChecked(true);
				state[k] = nil;
			end
		end
	);

	element = button;

	local button = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate");
	button:SetText(L["None"]);
	button:SetWidth(button:GetTextWidth() + 30);
	button:SetHeight(22);
	button:SetPoint("TOPLEFT", bottom, "TOPLEFT", allWidth + 20, -20);
	button:SetScript("OnClick", 
		function(self, button, down)
			for k, v in pairs(table) do
				checkboxes[k]:SetChecked(false);
				state[k] = 1;
			end
		end
	);
end

function AddZones(...)
	local table = {};

	for i=1,select("#", ...),1 do
		table[i] = select(i, ...);
	end

	if not Settings.ZoneFilter then
		Settings.ZoneFilter = {{},{},{},{},{}};
	end
	
	local c = GetCurrentMapContinent()
	
	if not Settings.ZoneFilter[c] then
		Settings.ZoneFilter[c] = {}
	end

	CheckBoxes(table, Settings.ZoneFilter[c]);
end

function AddHerbs()
	local table = {};

	for h, v in pairs(Bloodhound2.ContinentHerbs) do
		local name = L[h];
		if not name then name="Herb "..h; end;
		table[h] = name;
	end

	if not Settings.HerbFilter then
		Settings.HerbFilter = {};
	end

	CheckBoxes(table, Settings.HerbFilter);
end

function AddOre()
	local table = {};

	for h, v in pairs(Bloodhound2.ContinentOre) do
		local name = L[h];
		if not name then name="Ore "..h; end;
		table[h] = name;
	end

	if not Settings.OreFilter then
		Settings.OreFilter = {};
	end

	CheckBoxes(table, Settings.OreFilter);
end

function AddMisc()
	local table = {};

	for h, v in pairs(Bloodhound2.ContinentNode) do
		local name = L[h];
		if not name then name="Misc "..h; end;
		table[h] = name;
	end

	if not Settings.MiscFilter then
		Settings.MiscFilter = {};
	end

	CheckBoxes(table, Settings.MiscFilter);
end

local function CopyTable(table)
	local copy = {};
	for k,v in pairs(table) do
		if (type(v) == "table") then
			copy[k] = CopyTable(v);
		else
			copy[k] = v;
		end
	end
	return copy;
end

local configFrame;
local BackupSettings;

local function RefreshConfigFrame()
	if (configFrame) then
		configFrame:Hide();
	end

	BackupSettings = CopyTable(Settings);

	configFrame = CreateFrame("Frame", nil, Bloodhound2.panel);
	configFrame:SetAllPoints(Bloodhound2.panel);
	frame = configFrame;
	element = frame;
	Title(L["Bloodhound2 Options"]);
	Heading(L["Multi-Zone"]);
	DropDown(Settings, "MultiZoneMode", 120, function(menu)
		AddButton(Settings, "MultiZoneMode", menu, L["While flying"], 0);
		AddButton(Settings, "MultiZoneMode", menu, L["Always"], 1);
		AddButton(Settings, "MultiZoneMode", menu, L["Never"], 2);
	end);
	Heading(L["Zones"].." ("..ContinentName()..")");
	AddZones(GetMapZones(GetCurrentMapContinent()));
	element = frame;
	Column2(150);
	Heading(L["Inspection radius"]);
	DropDown(Settings, "InspectionRadius", 70, function(menu)
		AddButton(Settings, "InspectionRadius", menu, 30, 30);
		AddButton(Settings, "InspectionRadius", menu, 35, 35);
		AddButton(Settings, "InspectionRadius", menu, 40, 40);
		AddButton(Settings, "InspectionRadius", menu, 45, 45);
		AddButton(Settings, "InspectionRadius", menu, 50, 50);
		AddButton(Settings, "InspectionRadius", menu, 60, 60);
		AddButton(Settings, "InspectionRadius", menu, 70, 70);
		AddButton(Settings, "InspectionRadius", menu, 80, 80);
		AddButton(Settings, "InspectionRadius", menu, 90, 90);
		AddButton(Settings, "InspectionRadius", menu, 100, 100);
		AddButton(Settings, "InspectionRadius", menu, 120, 120);
	end);
end

local herbFrame;

local function RefreshHerbs()
	if (herbFrame) then herbFrame:Hide(); end;
	herbFrame = CreateFrame("Frame", nil, Bloodhound2.herbPanel);
	herbFrame:SetAllPoints(Bloodhound2.herbPanel);
	frame = herbFrame;
	element = frame;
	Title(L["Bloodhound2 Options"]);
	Heading(L["Herbs"].." ("..ContinentName()..")");
	AddHerbs();
end

local oreFrame;

local function RefreshOre()
	if (oreFrame) then oreFrame:Hide(); end;
	oreFrame= CreateFrame("Frame", nil, Bloodhound2.orePanel);
	oreFrame:SetAllPoints(Bloodhound2.orePanel);
	frame = oreFrame;
	element = frame;
	Title(L["Bloodhound2 Options"]);
	Heading(L["Minerals"].." ("..ContinentName()..")");
	AddOre();
end

local miscFrame;

local function RefreshMisc()
	if (miscFrame) then miscFrame:Hide(); end;
	miscFrame= CreateFrame("Frame", nil, Bloodhound2.miscPanel);
	miscFrame:SetAllPoints(Bloodhound2.miscPanel);
	frame = miscFrame;
	element = frame;
	Title(L["Bloodhound2 Options"]);
	Heading(L["Misc"].." ("..ContinentName()..")");
	AddMisc();
end

local function RestoreHerbDefaults()
	Settings.HerbFilter = {};
end

local function RestoreOreDefaults()
	Settings.OreFilter = {};
end

local function RestoreMiscDefaults()
	Settings.MiscFilter = {};
end

local function RestoreZoneDefaults()
	Settings.MultiZoneMode = 0;
	Settings.InspectionRadius = 60;
	Settings.ZoneFilter[GetCurrentMapContinent()] = {};
end

Bloodhound2.panel = CreateFrame("FRAME", "Bloodhound2", Bloodhound2.Frame);
Bloodhound2.panel.name = L["Bloodhound2"];
Bloodhound2.panel.default = RestoreZoneDefaults;
Bloodhound2.panel.okay = function() end;
Bloodhound2.panel.cancel = function() Settings = BackupSettings; Bloodhound2.UpdateMinimap(); end;
Bloodhound2.panel.refresh = RefreshConfigFrame;
InterfaceOptions_AddCategory(Bloodhound2.panel);

Bloodhound2.herbPanel = CreateFrame("FRAME", "Bloodhound2_Herbs", Bloodhound2.Frame);
Bloodhound2.herbPanel.name = L["Herbs"];
Bloodhound2.herbPanel.parent = "Bloodhound2";
Bloodhound2.herbPanel.default = RestoreHerbDefaults;
Bloodhound2.herbPanel.okay = function() end;
Bloodhound2.herbPanel.cancel = function() end;
Bloodhound2.herbPanel.refresh = RefreshHerbs;
InterfaceOptions_AddCategory(Bloodhound2.herbPanel);

Bloodhound2.orePanel = CreateFrame("FRAME", "Bloodhound2_Ore", Bloodhound2.Frame);
Bloodhound2.orePanel.name = L["Minerals"];
Bloodhound2.orePanel.parent = "Bloodhound2";
Bloodhound2.orePanel.default = RestoreOreDefaults;
Bloodhound2.orePanel.okay = function() end;
Bloodhound2.orePanel.cancel = function() end;
Bloodhound2.orePanel.refresh = RefreshOre;
InterfaceOptions_AddCategory(Bloodhound2.orePanel);

Bloodhound2.miscPanel = CreateFrame("FRAME", "Bloodhound2_Misc", Bloodhound2.Frame);
Bloodhound2.miscPanel.name = L["Misc"];
Bloodhound2.miscPanel.parent = "Bloodhound2";
Bloodhound2.miscPanel.default = RestoreMiscDefaults;
Bloodhound2.miscPanel.okay = function() end;
Bloodhound2.miscPanel.cancel = function() end;
Bloodhound2.miscPanel.refresh = RefreshMisc;
InterfaceOptions_AddCategory(Bloodhound2.miscPanel);