--[[

To localize this add-on, include another LUA file that follows this one in the TOC and
overrides the default values. Example:

if GetLocale()=="deDE" then
    L["Bloodhound2"] = "Schwei�hund2"
    -- etc.
end

Limit each LUA file to a single locale.

]]
L = {};

L["Bloodhound2"] = "Bloodhound2";
L["Bloodhound2 Options"] = "Bloodhound2 Options";
L["Multi-Zone"] = "Multi-Zone";
L["While flying"] = "While flying";
L["Always"] = "Always";
L["Never"] = "Never";
L["Inspection radius"] = "Inspection radius";
L["Zones"] = "Zones";
L["All"] = "All";
L["None"] = "None";

L["Herbs"] = "Herbs";
L["Find Herbs"] = "Find Herbs";
L[181166] = "Bloodthistle";
L[1618] = "PeaceBloom";
L[1617] = "Silverleaf";
L[1619] = "Earthroot";
L[1620] = "Mageroyal";
L[1621] = "Briarthorn";
L[2045] = "Stranglekelp";
L[1622] = "Bruiseweed";
L[1623] = "Wild Steelbloom";
L[1628] = "Grave Moss";
L[1624] = "Kingsblood";
L[2041] = "Liferoot";
L[2042] = "Fadeleaf";
L[2046] = "Goldthorn";
L[2043] = "Khadgar's Whisker";
L[2044] = "Dragon's Teeth";
L[2866] = "Firebloom";
L[142140] = "Purple Lotus";
L[142141] = "Arthas' Tears";
L[142142] = "Sungrass";
L[142143] = "Blindweed";
L[142144] = "Ghost Mushroom";
L[142145] = "Gromsblood";
L[176583] = "Golden Sansam";
L[176584] = "Dreamfoil";
L[176586] = "Mountain Silversage";
L[176587] = "Sorrowmoss";
L[176588] = "Icecap";
L[176589] = "Black Lotus";
L[181270] = "Felweed";
L[190174] = "Frozen Herb (300)";
L[181271] = "Dreaming Glory";
L[181275] = "Ragveil";
L[181277] = "Terocone";
L[181276] = "Flame Cap";
L[181278] = "Ancient Lichen";
L[189973] = "Goldclover";
L[181279] = "Netherbloom";
L[185881] = "Netherdust Bush";
L[191303] = "Firethorn";
L[181280] = "Nightmare Vine";
L[181281] = "Mana Thistle";
L[190169] = "Tiger Lily";
L[190170] = "Talandra's Rose";
L[191019] = "Adder's Tongue";
L[190173] = "Frozen Herb (400)";
L[190175] = "Frozen Herb (415)";
L[190171] = "Lichbloom";
L[190172] = "Icethorn";
L[190176] = "Frost Lotus";
L[202747] = "Cinderbloom";
L[202748] = "Stormvine";
L[202749] = "Azshara's Veil";
L[202750] = "Heartblossom";
L[202751] = "Twilight Jasmine";
L[202752] = "Whiptail";
L[209351] = "Snow Lily";
L[215412] = "Sha-Touched Herb";
L[209353] = "Rain Poppy";
L[209354] = "Golden Lotus";
L[209355] = "Fool's Cap";
L[209349] = "Green Tea Leaf";
L[209350] = "Silkweed";
L[214510] = "Sha-Touched Herb";
L[215410] = "Fool's Cap";

L["Minerals"] = "Minerals";
L["Find Minerals"] = "Find Minerals";
L[188432] = "Black Blood of Yogg-Saron";
L[1731] = "Copper Vein";
L[191844] = "Enchanted Earth";
L[188699] = "Strange Ore";
L[1610] = "Incendicite Mineral Vein";
L[1732] = "Tin Vein";
L[2653] = "Lesser Bloodstone Deposit";
L[73940] = "Ooze Covered Silver Vein";
L[1733] = "Silver Vein";
L[1735] = "Iron Deposit";
L[19903] = "Indurium Mineral Vein";
L[1734] = "Gold Vein";
L[73941] = "Ooze Covered Gold Vein";
L[2040] = "Mithril Deposit";
L[123310] = "Ooze Covered Mithril Deposit";
L[165658] = "Dark Iron Deposit";
L[123309] = "Ooze Covered Truesilver Deposit";
L[2047] = "Truesilver Deposit";
L[123848] = "Ooze Covered Thorium Vein";
L[324] = "Small Thorium Vein";
L[180215] = "Hakkari Thorium Vein";
L[177388] = "Ooze Covered Rich Thorium Vein";
L[175404] = "Rich Thorium Vein";
L[181555] = "Fel Iron Deposit";
L[185877] = "Nethercite Deposit";
L[181069] = "Large Obsidian Chunk";
L[181068] = "Small Obsidian Chunk";
L[181556] = "Adamantite Deposit";
L[189978] = "Cobalt Deposit";
L[181569] = "Rich Adamantite Deposit";
L[185557] = "Ancient Gem Vein";
L[181557] = "Khorium Vein";
L[189979] = "Rich Cobalt Deposit";
L[189980] = "Saronite Deposit";
L[189981] = "Rich Saronite Deposit";
L[195036] = "Pure Saronite Deposit";
L[191133] = "Titanium Vein";
L[202736] = "Obsidium Deposit";
L[202737] = "Pyrite Deposit";
L[202738] = "Elementium Vein";
L[202739] = "Rich Obsidium Deposit";
L[202740] = "Rich Pyrite Deposit";
L[202741] = "Rich Elementium Vein";
L[209330] = "Rich Trillium Vein";
L[209311] = "Ghost Iron Deposit";
L[209312] = "Kyparite Deposit";
L[209313] = "Trillium Vein";
L[209328] = "Rich Ghost Iron Deposit";
L[209329] = "Rich Kyparite Deposit";
L[215413] = "Ghost Iron Deposit";

L["Misc"] = "Miscellaneous";
L["Find Misc"] = "Track Miscellaneous Nodes";
L[218593] = "Trove of the Thunder King";
L[210565] = "Dark Soil";
