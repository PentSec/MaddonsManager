﻿-- Carbonite Localization File

BINDING_HEADER_Nx						= "Carbonite"

NXTITLE				= "CARBONITE"
NXTITLELOW			= "Carbonite"

--EOF










