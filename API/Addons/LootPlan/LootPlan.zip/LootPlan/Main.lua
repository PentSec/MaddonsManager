-- Addon Declaration
-- =================
local ADDONNAME = "LootPlan"
LootPlan = LibStub("AceAddon-3.0"):NewAddon(ADDONNAME, "AceConsole-3.0", "AceHook-3.0")
local addon = LootPlan
addon.ADDONNAME = ADDONNAME
addon.VERSION = "0.4.0"
local registry = LibStub("AceConfigRegistry-3.0")
local dialog = LibStub("AceConfigDialog-3.0")
local ldb = LibStub:GetLibrary("LibDataBroker-1.1")

-- Addon constants
local ADDONTITLE = "LootPlan"
addon.ADDONTITLE = ADDONTITLE

-- Locale
local L = LibStub("AceLocale-3.0"):GetLocale(ADDONNAME, true)

-- Binding Variables
BINDING_HEADER_LOOTPLAN = L["BINDING_HEADER"]
BINDING_NAME_LOOTPLAN_SELECTITEM = L["BINDING_NAME_SELECTITEM"]
BINDING_NAME_LOOTPLAN_QUICKADD = L["BINDING_NAME_QUICKADD"]

-- Addon OnInitialize, OnEnable, OnDisable
-- =======================================
function addon:OnInitialize()
    -- Code that you want to run when the addon is first loaded goes here.

    -- AceDB
    self.db = LibStub("AceDB-3.0"):New("LootPlanDB", addon.dbDefaults)
    addon.options.args.profile = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db)

    -- AceConfig/AceConsole
    LibStub("AceConfig-3.0"):RegisterOptionsTable(ADDONNAME, addon.options, {"lootplan", "lp"})
    
    -- AceConfig GUI
    registry:RegisterOptionsTable(ADDONNAME, addon.options)
    dialog:AddToBlizOptions(ADDONNAME, ADDONNAME)
    
    -- DataBroker
    ldb:NewDataObject(ADDONNAME, {
        type = "launcher",
        label = "LootPlan",
        icon = "Interface\\Icons\\INV_Axe_17",
        OnClick = function(clickedframe, button)
            dialog:Open(ADDONNAME)
        end,
    })
    
    -- Build options
    addon:BuildOptions()

    addon:PrDebug(L["oninit"])
end

function addon:OnEnable()
    -- Called when the addon is enabled

	-- Hook tooltips if needed
    addon:HookTooltips()

    addon:PrDebug(L["onenable"])
end

function addon:OnDisable()
    -- Called when the addon is disabled
    addon:PrDebug(L["ondisable"])
end

addon.lastSelectedItemId = 0
function addon:SelectItem()
    local itemId = 0
    if (GameTooltip:IsShown()) and (select(2,GameTooltip:GetItem())) then
        itemId = addon:GetItemIdFromItemLink( select(2,GameTooltip:GetItem()) )
    elseif (AtlasLootTooltip) and (AtlasLootTooltip:IsShown()) and (select(2,AtlasLootTooltip:GetItem())) then
        itemId = addon:GetItemIdFromItemLink( select(2,AtlasLootTooltip:GetItem()) )
    elseif (ItemRefTooltip:IsShown()) and (select(2,ItemRefTooltip:GetItem())) then
        itemId = addon:GetItemIdFromItemLink( select(2,ItemRefTooltip:GetItem()) )
    end
    
    if (itemId) and (itemId > 0) then
        itemName, itemLink, _, itemLevel, _, itemType, itemSubType, _, itemEquipLoc, itemTexture = GetItemInfo(itemId)
        
        if addon:IsTierItem(itemId) then
            itemEquipLoc = addon.TIER
        end
        
        if itemEquipLoc ~= "" then
        
            addon.lastSelectedItemId = itemId
            addon:RefreshGUI()
        end
    end
end

function addon:RefreshGUI()
    addon:PrDebug("RefreshGUI")
 
    addon:BuildOptions()

    LibStub("AceConfigRegistry-3.0"):NotifyChange(addon.ADDONNAME)    
end

function addon:QuickAdd()
    local itemId = 0
    if (GameTooltip:IsShown()) and (select(2,GameTooltip:GetItem())) then
        itemId = addon:GetItemIdFromItemLink( select(2,GameTooltip:GetItem()) )
    elseif (AtlasLootTooltip) and (AtlasLootTooltip:IsShown()) and (select(2,AtlasLootTooltip:GetItem())) then
        itemId = addon:GetItemIdFromItemLink( select(2,AtlasLootTooltip:GetItem()) )
    elseif (ItemRefTooltip:IsShown()) and (select(2,ItemRefTooltip:GetItem())) then
        itemId = addon:GetItemIdFromItemLink( select(2,ItemRefTooltip:GetItem()) )
    end
    
    if (itemId) and (itemId > 0) then
        _, itemLink, _, itemLevel, _, itemType, itemSubType, _, itemEquipLoc, itemTexture = GetItemInfo(itemId)
        
        if addon:IsTierItem(itemId) then
            itemEquipLoc = addon.TIER
        end
        
        if itemEquipLoc ~= "" then
        
            addon:AddItem(addon.CATOTHER, itemId, "")
            addon:Print( format( L["quickadd_string"], itemLink) )
            addon:RefreshGUI()
        end
    end
end
