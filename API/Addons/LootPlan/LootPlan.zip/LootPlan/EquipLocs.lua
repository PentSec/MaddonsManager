local addon = LootPlan

function addon:MapEquipLoc(itemEquipLoc)

    if addon.EQUIPLOCMAP[itemEquipLoc] then
        return addon.EQUIPLOCMAP[itemEquipLoc]
    else
        return itemEquipLoc
    end

end

addon.TIER = "TIER"

addon.EQUIPLOCMAP = {
    ["INVTYPE_AMMO"]           = "",
    ["INVTYPE_BODY"]           = "",
    ["INVTYPE_ROBE"]           = "INVTYPE_CHEST",
    ["INVTYPE_SHIELD"]         = "INVTYPE_HOLDABLE",
    ["INVTYPE_WEAPONMAINHAND"] = "INVTYPE_WEAPON",
    ["INVTYPE_WEAPONOFFHAND"]  = "INVTYPE_WEAPON",
    ["INVTYPE_THROWN"]         = "INVTYPE_RANGED",
    ["INVTYPE_RANGEDRIGHT"]    = "INVTYPE_RANGED",
    ["INVTYPE_RELIC"]          = "INVTYPE_RANGED",
    ["INVTYPE_TABARD"]         = "",
    ["INVTYPE_BAG"]            = "",
    ["INVTYPE_QUIVER"]         = "",
  }

addon.EQUIPLOCS = {
    "INVTYPE_HEAD",
    "INVTYPE_NECK",
    "INVTYPE_SHOULDER",
    "INVTYPE_CLOAK",
    "INVTYPE_CHEST",
    "INVTYPE_WRIST",
    "INVTYPE_HAND",
    "INVTYPE_WAIST",
    "INVTYPE_LEGS",
    "INVTYPE_FEET",
    "INVTYPE_FINGER",
    "INVTYPE_TRINKET",  
    "INVTYPE_2HWEAPON",  
    "INVTYPE_WEAPON",  
    "INVTYPE_HOLDABLE",  
    "INVTYPE_RANGED",  
    "TIER",
  }
  
  
--[[

"INVTYPE_AMMO"  Ammo  0  
"INVTYPE_HEAD"  Head  1  
"INVTYPE_NECK"  Neck  2  
"INVTYPE_SHOULDER"  Shoulder  3  
"INVTYPE_BODY"  Shirt  4  
"INVTYPE_CHEST"  Chest  5  
"INVTYPE_ROBE"  Chest  5  
"INVTYPE_WAIST"  Waist  6  
"INVTYPE_LEGS"  Legs  7  
"INVTYPE_FEET"  Feet  8  
"INVTYPE_WRIST"  Wrist  9  
"INVTYPE_HAND"  Hands  10  
"INVTYPE_FINGER"  Fingers  11,12  
"INVTYPE_TRINKET"  Trinkets  13,14  
"INVTYPE_CLOAK"  Cloaks  15  
"INVTYPE_WEAPON"  One-Hand  16,17  
"INVTYPE_SHIELD"  Shield  17  
"INVTYPE_2HWEAPON"  Two-Handed  16  
"INVTYPE_WEAPONMAINHAND"  Main-Hand Weapon  16  
"INVTYPE_WEAPONOFFHAND"  Off-Hand Weapon  17  
"INVTYPE_HOLDABLE"  Held In Off-Hand  17  
"INVTYPE_RANGED"  Bows  18  
"INVTYPE_THROWN"  Ranged  18  
"INVTYPE_RANGEDRIGHT"  Wands, Guns, and Crossbows (changed in 2.4.3)  18  
"INVTYPE_RELIC"  Relics  18  
"INVTYPE_TABARD"  Tabard  19  
"INVTYPE_BAG"  Containers  20,21,22,23  
"INVTYPE_QUIVER"  Quivers  20,21,22,23 (defined in GlobalStrings.lua, but does not appear to be used)  

--]]
