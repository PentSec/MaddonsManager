local addon = LootPlan
local L = LibStub("AceLocale-3.0"):GetLocale(addon.ADDONNAME, true)

function addon:BuildOptions_Import()
    addon.importCatId = 5
    addon.importText = ""
    
    addon.options.plugins["IMPORT"] = {
        ["IMPORT"] = {
            type = 'group',
            name = L["menu_import_name"],
            desc = L["menu_import_desc"],
            order = 10,
            args = {
                explaincat = {
                    order = 1,
                    type = 'description',
                    name = L["menu_import_explaincat"],
                },
                cat1 = {
                    order = 11,
                    type = 'toggle',
                    name = L["CAT1"],
                    desc = "",
                    width = 'half',
                    hidden = not addon:IsCategoryForClass(1, select(2, UnitClass("player"))),
                    get = function(info) return (addon.importCatId == 1) end,
                    set = function(info, v) addon.importCatId = 1 end,
                },
                cat2 = {
                    order = 12,
                    type = 'toggle',
                    name = L["CAT2"],
                    desc = "",
                    width = 'half',
                    hidden = not addon:IsCategoryForClass(2, select(2, UnitClass("player"))),
                    get = function(info) return (addon.importCatId == 2) end,
                    set = function(info, v) addon.importCatId = 2 end,
                },
                cat3 = {
                    order = 13,
                    type = 'toggle',
                    name = L["CAT3"],
                    desc = "",
                    width = 'half',
                    hidden = not addon:IsCategoryForClass(3, select(2, UnitClass("player"))),
                    get = function(info) return (addon.importCatId == 3) end,
                    set = function(info, v) addon.importCatId = 3 end,
                },
                cat4 = {
                    order = 14,
                    type = 'toggle',
                    name = L["CAT4"],
                    desc = "",
                    width = 'half',
                    hidden = not addon:IsCategoryForClass(4, select(2, UnitClass("player"))),
                    get = function(info) return (addon.importCatId == 4) end,
                    set = function(info, v) addon.importCatId = 4 end,
                },
                cat5 = {
                    order = 15,
                    type = 'toggle',
                    name = L["CAT5"],
                    desc = "",
                    width = 'half',
                    hidden = not addon:IsCategoryForClass(5, select(2, UnitClass("player"))),
                    get = function(info) return (addon.importCatId == 5) end,
                    set = function(info, v) addon.importCatId = 5 end,
                },
                spe3 = {
                    order = 20,
                    type = 'description',
                    name = " ",
                },
                input = {
                    order = 21,
                    type = 'input',
                    multiline = true,
                    width = 'double',
                    name = L["menu_import_input_name"],
                    desc = L["menu_import_input_desc"],
                    get = function(info) return addon.importText end,
                    set = function(info, v) addon.importText = v end,
                },
                sep5 = {
                    order = 30,
                    type = 'description',
                    name = " ",
                },
                button = {
                    order = 31,
                    type = 'execute',
                    name = L["menu_import_button_name"],
                    desc = L["menu_import_button_desc"],
                    func = function(info)
                            addon:Import()
                            addon:RefreshGUI()
                        end,
                },
                sep4 = {
                    order = 40,
                    type = 'description',
                    name = " ",
                },
                log = {
                    order = 41,
                    type = 'description',
                    name = "",
                },
            },
        },
    }
end


function addon:Import()
    

    for _,row in pairs({strsplit(";", addon.importText)}) do
    
        if row ~= "" then
    
        local itemIdStr, itemNote = strsplit(":", row)
        itemId = tonumber(itemIdStr)
        if not itemNote then itemNote = "" end
        
        if itemId and (itemId > 0) then
        
            local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(itemId) 

            if itemName then
                if addon:IsTierItem(itemId) then
                    itemEquipLoc = addon.TIER
                end
            
                if itemEquipLoc ~= "" then
            
                    if not addon:tcontains(addon.db.char.lootpercat[addon.importCatId], itemId) then
                        
                        addon:AddItem(addon.importCatId, itemId, itemNote)
                        addon:Print( itemId.. " (".. itemName.. "): " ..L["import_log_succes"] )
                        
                    else
                        addon:Print( itemId.. " (".. itemName.. "): " ..L["import_log_alreadyincat"] )
                    end
                else
                    addon:Print( itemId.. " (".. itemName.. "): " ..L["import_log_notlootitem"] )
                end
            else
                addon:Print( "'"..row.."': " ..L["import_log_itemdoesnotexist"])
            end
        else
            addon:Print( "'"..row.."': " ..L["import_log_invalidformat"])
        end
        
        
        end
    end
    
end
