local addon = LootPlan

addon.CATMIN = 1
addon.CATMAX = 5

addon.CATTANK = 1
addon.CATMELEE = 2
addon.CATRANGED = 3
addon.CATHEAL = 4
addon.CATOTHER = 5

addon.CLASS_CAT = {
    -- CLASS            tank   melee  range  heal   other
    ["DEATHKNIGHT"] = { true,  true,  false, false, true },
    ["DRUID"]       = { true,  true,  true,  true,  true },
    ["HUNTER"]      = { false, false, true,  false, true },
    ["MAGE"]        = { false, false, true,  false, true },
    ["PALADIN"]     = { true,  true,  false, true,  true },
    ["PRIEST"]      = { false, false, true,  true,  true },
    ["ROGUE"]       = { false, true,  false, false, true },
    ["SHAMAN"]      = { false, true,  true,  true,  true },
    ["WARLOCK"]     = { false, false, true,  false, true },
    ["WARRIOR"]     = { true,  true,  false, false, true },
  }

function addon:IsCategoryForClass(categoryId, engClass)

    return addon.CLASS_CAT[engClass][categoryId]

end

