local addon = LootPlan
local L = LibStub("AceLocale-3.0"):GetLocale(addon.ADDONNAME, true)
local dialog = LibStub("AceConfigDialog-3.0")

addon.DEFAULTCOORDS = {0, 1, 0, 1}

addon.newItemId = 0
addon.newItemNote = ""
addon.newItemCatId = 1

-- Addon options table
-- ===================
addon.options = {
    name = addon.ADDONTITLE,
    handler = addon,
    type = 'group',
    plugins = { },
    args = {
        gui = {
            order = 999,
            type = 'execute',
            name = L["menu_gui_name"],
            desc = L["menu_gui_desc"],
            func = function(info) dialog:Open(addon.ADDONNAME) end,
            guiHidden = true,
            dialogHidden = true,
        },
        test = {
            order = 999,
            type = 'execute',
            name = "test",
            desc = "test",
            func = function(info) addon:Test() end,
            hidden = true,
        },
        loot = {
            order = 1,
            type = 'group',
            name = L["menu_loot_name"],
            desc = L["menu_loot_desc"],
            cmdHidden = true,
            plugins = { },
            args = { },
        },
        settings = {
            order = 10,
            type = 'group',
            name = L["menu_settings_name"],
            desc = L["menu_settings_desc"],
            cmdHidden = true,
            args = {
                version = {
                    type = 'description',
                    name = format( L["menu_settings_version_name"], addon.VERSION, addon.ADDONTITLE) ,
                    order = 1,
                },
                sep1 = {
                    type = 'description',
                    name = " ",
                    order = 2,
                },
                debug = {
                    type = 'toggle',
                    name = L["menu_settings_debug_name"],
                    desc = L["menu_settings_debug_desc"],
                    get = function(info) return addon.db.profile.debug end,
                    set = function(info, v) addon.db.profile.debug = v end,
                    order = 3,
                },
                sep2 = {
                    type = 'description',
                    name = " ",
                    order = 4,
                },
                keybind = {
                    order = 5,
                    type = 'keybinding',
                    name = L["menu_settings_keybind_name"],
                    desc = L["menu_settings_keybind_desc"],
                    get = function(info) return GetBindingKey("LOOTPLAN_SELECTITEM") end,
                    set = function(info, v)
--                        addon:Print(v)

                        while GetBindingKey("LOOTPLAN_SELECTITEM") do
                            SetBinding( GetBindingKey("LOOTPLAN_SELECTITEM") )
                        end
                        
                        if v then
                            SetBinding(v, "LOOTPLAN_SELECTITEM")
                        end
                        
                        SaveBindings(1)
                    end,
                },
                quickbind = {
                    order = 6,
                    type = 'keybinding',
                    name = L["menu_settings_quickbind_name"],
                    desc = L["menu_settings_quickbind_desc"],
                    get = function(info) return GetBindingKey("LOOTPLAN_QUICKADD") end,
                    set = function(info, v)
--                        addon:Print(v)

                        while GetBindingKey("LOOTPLAN_QUICKADD") do
                            SetBinding( GetBindingKey("LOOTPLAN_QUICKADD") )
                        end
                        
                        if v then
                            SetBinding(v, "LOOTPLAN_QUICKADD")
                        end
                        
                        SaveBindings(1)
                    end,
                },
                sep3 = {
                    type = 'description',
                    name = " ",
                    order = 7,
                },
                noteintooltip = {
                    type = 'toggle',
                    name = L["menu_settings_noteintooltip_name"],
                    desc = L["menu_settings_noteintooltip_desc"],
                    get = function(info) return addon.db.profile.noteintooltip end,
                    set = function(info, v) addon.db.profile.noteintooltip = v end,
                    width = 'double',
                    order = 8,
                },
            },
        },
    },
}

addon.dbDefaults = {
    profile = {
        debug = false,
        noteintooltip = false,
    },
    char = {
        lootpercat = { {}, {}, {}, {}, {}, },
        itemnotes = { },
    },
}

function addon:Test()


end

function addon:BuildOptions()

    addon:BuildOptions_AddItem()

    addon:BuildOptions_Loot()
    
    addon:BuildOptions_Import()
    
end

