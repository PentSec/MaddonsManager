local addon = LootPlan
local L = LibStub("AceLocale-3.0"):GetLocale(addon.ADDONNAME, true)

local EquipLocInCat = { }

function addon:BuildOptions_Loot()

    local EquipLocInCat = wipe(EquipLocInCat)
    
    for catId = addon.CATMIN, addon.CATMAX do
    
        if addon:IsCategoryForClass(catId, select(2, UnitClass("player")) ) then
        
            EquipLocInCat[catId] = { }
    
            addon.options.args.loot.plugins["CAT"..catId] = {
                ["CAT"..catId] = {
                    order = catId,
                    type = 'group',
                    name = L["CAT"..catId],
                    desc = "",
                    plugins = { },
                    args = { },
                },
            }

            -- EQUIPLOCS
            for locIndex, equipLoc in ipairs(addon.EQUIPLOCS) do
                local equipLocName
                if equipLoc == addon.TIER then
                    equipLocName = L[addon.TIER]
                else
                    equipLocName = _G[equipLoc]
                end
                addon.options.args.loot.plugins["CAT"..catId]["CAT"..catId].plugins[equipLoc] = {
                    [equipLoc] = {
                        type = 'group',
                        name = equipLocName,
                        desc = "",
                        order = locIndex,
                        plugins = { },
                        args = { },
                    },
                    ["OVERVIEW"..equipLoc] = {
                        type = 'description',
                        name = " ",
                        desc = "",
                        order = locIndex,
                    },
                }
            end
            
            
            -- ITEMS
            if addon.db.char.lootpercat[catId] then
            for itemIndex,itemId in ipairs(addon.db.char.lootpercat[catId]) do
            
                local itemDisplay, itemLevel, itemEquipLoc, itemTexture = addon:BuildItemDisplay(itemId)
                
                if itemDisplay and itemLevel and itemEquipLoc and itemTexture then

                    local itemNote = addon.db.char.itemnotes[catId..":"..itemId]
                    if not itemNote then itemNote = "" end
                    
                    if not EquipLocInCat[catId][itemEquipLoc] then
                        EquipLocInCat[catId][itemEquipLoc] = 1
                    else
                        EquipLocInCat[catId][itemEquipLoc] = EquipLocInCat[catId][itemEquipLoc] + 1
                    end
                    
                    addon.options.args.loot.plugins["CAT"..catId]["CAT"..catId].plugins[itemEquipLoc][itemEquipLoc].plugins["ITEM"..itemId] = {
                        ["ITEM"..itemId] = {
                            order = itemOrder,
                            type = 'group',
                            name = " ",
                            desc = "",
                            inline = true,
                            args = {
                                display = {
                                    order = 1,
                                    type = 'description',
                                    name = itemDisplay,
                                    desc = "",
                                    image = itemTexture,
                                    imageCoords = addon.DEFAULTCOORDS,
                                    imageWidth = 24,
                                    imageHeight = 24,
                                },
                                note = {
                                    order = 2,
                                    type = 'input',
                                    name = "",
                                    desc = "",
                                    width = 'double',
                                    arg = catId..":"..itemId,
                                    get = function(info) return addon.db.char.itemnotes[info.arg] end,
                                    set = function(info,v) addon.db.char.itemnotes[info.arg] = v end,
                                },
                                sep1 = {
                                    order = 3,
                                    type = 'description',
                                    name = "",
                                },
                                view = {
                                    order = 4,
                                    type = 'execute',
                                    name = L["menu_loot_item_view_name"],
                                    desc = L["menu_loot_item_view_desc"],
                                    width = 'half',
                                    arg = itemId,
                                    func = function(info)
                                            addon:ViewLink(info.arg)
                                        end,
                                },
                                print = {
                                    order = 5,
                                    type = 'execute',
                                    name = L["menu_loot_item_print_name"],
                                    desc = L["menu_loot_item_print_desc"],
                                    width = 'half',
                                    arg = itemId,
                                    func = function(info)
                                            addon:PrintLink(info.arg)
                                        end,
                                },
                                remove = {
                                    order = 6,
                                    type = 'execute',
                                    name = L["menu_loot_item_remove_name"],
                                    desc = L["menu_loot_item_remove_desc"],
                                    width = 'half',
                                    arg = catId..":"..itemId,
                                    confirm = function(info)
                                            return L["menu_confirm_removeitem"]
                                        end,
                                    func = function(info)
                                            addon:RemoveItem(info.arg)
                                            addon:RefreshGUI()
                                        end,
                                },
                            },
                        },
                    }
                    
                end -- if check for nils
            
            end -- for each item in a category
            end
            
            -- Filter empty EquipLocs
            for locIndex, equipLoc in ipairs(addon.EQUIPLOCS) do
                addon.options.args.loot.plugins["CAT"..catId]["CAT"..catId].plugins[equipLoc][equipLoc].hidden = not EquipLocInCat[catId][equipLoc]
                local equipLocName
                if equipLoc == addon.TIER then
                    equipLocName = L[addon.TIER]
                else
                    equipLocName = _G[equipLoc]
                end
                addon.options.args.loot.plugins["CAT"..catId]["CAT"..catId].plugins[equipLoc]["OVERVIEW"..equipLoc].name = equipLocName .. "\n" .. strrep(" ",30) .. (EquipLocInCat[catId][equipLoc] or "|cff808080".."0".."|r")
            end
            
        end -- check category/class
    
    end -- for each category
end

function addon:RemoveItem(categoryId_itemId)
    local categoryId, itemId = strsplit(":", categoryId_itemId)
    categoryId = tonumber(categoryId)
    itemId = tonumber(itemId)

    if (categoryId >= addon.CATMIN) and (categoryId <= addon.CATMAX) then
        addon:tremovebyval(addon.db.char.lootpercat[categoryId], itemId )
        addon.db.char.itemnotes[categoryId..":"..itemId] = nil
    end
    
--    addon.options.args.items.plugins[""..itemId] = nil
    -- TODO

end

