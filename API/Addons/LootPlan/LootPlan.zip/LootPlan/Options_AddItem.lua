local addon = LootPlan
local L = LibStub("AceLocale-3.0"):GetLocale(addon.ADDONNAME, true)

function addon:BuildOptions_AddItem()
    addon.newItemId = addon.lastSelectedItemId
    addon.newItemNote = ""
    addon.newItemCatId = 5

    local itemDisplay, _, _, itemTexture = addon:BuildItemDisplay(addon.newItemId)
        
    addon.options.args.loot.plugins["ADDITEM"] = {
        ["ADDITEM"] = {
            type = 'group',
            name = L["menu_loot_additem_name"],
            desc = L["menu_loot_additem_desc"],
            order = 1,
            inline = true,
            args = {
                itemlink = {
                    order = 1,
                    type = 'description',
                    name = itemDisplay,
                    desc = "",
                    image = itemTexture,
                    imageCoords = addon.DEFAULTCOORDS,
                    imageWidth = 24,
                    imageHeight = 24,
                },
                view = {
                    order = 2,
                    type = 'execute',
                    name = L["menu_loot_additem_view_name"],
                    desc = L["menu_loot_additem_view_desc"],
                    width = 'half',
                    disabled = (addon.newItemId == 0),
                    func = function(info)
                            addon:ViewLink(addon.newItemId)
                        end,
                },
                print = {
                    order = 3,
                    type = 'execute',
                    name = L["menu_loot_additem_print_name"],
                    desc = L["menu_loot_additem_print_desc"],
                    width = 'half',
                    disabled = (addon.newItemId == 0),
                    func = function(info)
                            addon:PrintLink(addon.newItemId)
                        end,
                },
                sep1 = {
                    order = 4,
                    type = 'description',
                    name = "",
                },
                cat1 = {
                    order = 11,
                    type = 'toggle',
                    name = L["CAT1"],
                    desc = "",
                    width = 'half',
                    disabled = (addon.newItemId == 0),
                    hidden = not addon:IsCategoryForClass(1, select(2, UnitClass("player"))),
                    get = function(info) return (addon.newItemCatId == 1) end,
                    set = function(info, v) addon.newItemCatId = 1 end,
                },
                cat2 = {
                    order = 12,
                    type = 'toggle',
                    name = L["CAT2"],
                    desc = "",
                    width = 'half',
                    disabled = (addon.newItemId == 0),
                    hidden = not addon:IsCategoryForClass(2, select(2, UnitClass("player"))),
                    get = function(info) return (addon.newItemCatId == 2) end,
                    set = function(info, v) addon.newItemCatId = 2 end,
                },
                cat3 = {
                    order = 13,
                    type = 'toggle',
                    name = L["CAT3"],
                    desc = "",
                    width = 'half',
                    disabled = (addon.newItemId == 0),
                    hidden = not addon:IsCategoryForClass(3, select(2, UnitClass("player"))),
                    get = function(info) return (addon.newItemCatId == 3) end,
                    set = function(info, v) addon.newItemCatId = 3 end,
                },
                cat4 = {
                    order = 14,
                    type = 'toggle',
                    name = L["CAT4"],
                    desc = "",
                    width = 'half',
                    disabled = (addon.newItemId == 0),
                    hidden = not addon:IsCategoryForClass(4, select(2, UnitClass("player"))),
                    get = function(info) return (addon.newItemCatId == 4) end,
                    set = function(info, v) addon.newItemCatId = 4 end,
                },
                cat5 = {
                    order = 15,
                    type = 'toggle',
                    name = L["CAT5"],
                    desc = "",
                    width = 'half',
                    disabled = (addon.newItemId == 0),
                    hidden = not addon:IsCategoryForClass(5, select(2, UnitClass("player"))),
                    get = function(info) return (addon.newItemCatId == 5) end,
                    set = function(info, v) addon.newItemCatId = 5 end,
                },
                note = {
                    order = 16,
                    type = 'input',
                    name = L["menu_loot_additem_note_name"],
                    desc = L["menu_loot_additem_note_desc"],
                    width = 'double',
                    disabled = (addon.newItemId == 0),
                    get = function(info) return addon.newItemNote end,
                    set = function(info,v) addon.newItemNote = v end,
                },
                sep2 = {
                    order = 30,
                    type = 'description',
                    name = " ",
                },
                button = {
                    order = 31,
                    type = 'execute',
                    name = L["menu_loot_additem_button_name"],
                    desc = L["menu_loot_additem_button_desc"],
                    disabled = (addon.newItemId == 0),
                    confirm = function(info)
                            if addon.newItemId == 0 then
                                return L["menu_error_noitemtooltip"]
                            elseif addon:tcontains(addon.db.char.lootpercat[addon.newItemCatId], addon.newItemId) then
                                return L["menu_error_itemalreadyexists"]
                            end
                            return false
                        end,
                    func = function(info)
                            if addon.newItemId == 0 then
                                return
                            elseif addon:tcontains(addon.db.char.lootpercat[addon.newItemCatId], addon.newItemId) then
                                return
                            end
                            addon:AddItem(addon.newItemCatId, addon.newItemId, addon.newItemNote)
                            addon:RefreshGUI()
                        end,
                },
            },
        },
    }
end


function addon:AddItem(categoryId, itemId, itemNote)
    if addon:tcontains(addon.db.char.lootpercat[categoryId], itemId) then
        return
    end
    
    if (categoryId >= addon.CATMIN) and (categoryId <= addon.CATMAX) then
        tinsert(addon.db.char.lootpercat[categoryId], itemId)
        addon.db.char.itemnotes[categoryId..":"..itemId] = itemNote
    end
    
    addon.lastSelectedItemId = 0

end
