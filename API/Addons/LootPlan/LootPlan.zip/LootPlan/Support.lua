local addon = LootPlan
local L = LibStub("AceLocale-3.0"):GetLocale(addon.ADDONNAME, true)

-- Colors
local RED = "|cffff0000"
local YELLOW = "|cffffff00"
local GREEN = "|cff00ff00"
local ORANGE = "|cffff8000"
local COLORRESET = "|r"

function addon:OutputChat(destination, message)
    SendChatMessage(message, destination)
end

function addon:PrDebug(message)
    if addon.db.profile.debug then
        addon:Print(YELLOW..message)
    end
end

function addon:PrError(message)
    addon:Print(RED..message)
end


function addon:tcontains(tab, val)
    for i,v in ipairs(tab) do
        if v == val then
            return true
        end
    end
    return false
end

function addon:tremovebyval(tab, val)
    for i,v in ipairs(tab) do
        if v == val then
            table.remove(tab, i)
            return true
        end
    end
    return false
end

function addon:GetItemIdFromItemLink(itemLink)
    local found, _, itemString = string.find(itemLink, "^|c%x+|H(.+)|h%[.*%]")
    
    return addon:GetItemIdFromItemString(itemString)
end

function addon:GetItemIdFromItemString(itemString)
    local _, itemId, enchantId, jewelId1, jewelId2, jewelId3, jewelId4, suffixId, uniqueId, linkLevel = strsplit(":", itemString)
    
    return tonumber(itemId)
end

function addon:BuildItemString(itemId)
    local enchantId, jewelId1, jewelId2, jewelId3, jewelId4, suffixId, uniqueId, linkLevel =
          0,         0,        0,        0,        0,        0,        0,        UnitLevel("player")
          
    return "item:".. itemId ..":"..
                     enchantId ..":"..
                     jewelId1 ..":"..
                     jewelId2 ..":"..
                     jewelId3 ..":"..
                     jewelId4 ..":"..
                     suffixId ..":"..
                     uniqueId ..":"..
                     linkLevel
end

local INDENT = "\n      "
function addon:BuildItemDisplay(itemId)

    local itemLink = ""
    local itemRarity = 0
    local itemLevel = 0
    local itemEquipLoc = ""
    local itemTexture = "Interface\\Icons\\INV_Misc_QuestionMark"
    local itemOrder = -1
    local itemDrop = nil
    local itemDropStr = ""
    
    local resultStr = L["menu_warning_noitemtooltip"]

    if itemId > 0 then
        _, itemLink, itemRarity, itemLevel, _, itemType, itemSubType, _, itemEquipLoc, itemTexture = GetItemInfo(itemId)
        
        if itemLink and itemRarity and itemLevel then
            itemOrder = 10000 - ((itemRarity+1) * itemLevel)
            
            itemDrop = addon:GetDropLocs(itemId)
            if itemDrop then
                for k, v in ipairs(itemDrop) do
                    itemDropStr = itemDropStr..","..INDENT.."PT: "..v
                end
                itemDropStr = strsub(itemDropStr, 2 )
            else
                itemDropStr = ""
            end
            
            itemEquipLoc = addon:MapEquipLoc(itemEquipLoc)
            if itemEquipLoc == "" then
                itemEquipLoc = L["notequippable"]
            end
            
            local itemEquipLocName
            if addon:IsTierItem(itemId) then
                itemSubType = L[addon.TIER]
                itemEquipLoc = addon.TIER
                itemEquipLocName = L[addon.TIER]
            else
                itemEquipLocName = _G[itemEquipLoc]
            end
            
            resultStr = format( " %s |cff808080%s, %s,"..INDENT.."%s, %s%s|r",
                    itemLink,
                    L["ilevel "]..itemLevel,
                    L["id "]..itemId,
                    L["category "]..itemType.."|"..itemSubType,
                    L["slot "].."'"..itemEquipLoc.."'",
                    itemDropStr)

        end
    end

    return resultStr, itemLevel, itemEquipLoc, itemTexture, itemOrder
    
end

function addon:GetDropLocs(itemId)
    if not LibStub("LibPeriodicTable-3.1", true) then return nil end
    
	return LibStub("LibPeriodicTable-3.1"):ItemSearch(itemId)
end

function addon:ViewLink(itemId)
    ShowUIPanel(ItemRefTooltip)
    if ( not ItemRefTooltip:IsShown() ) then
        ItemRefTooltip:SetOwner(UIParent, "ANCHOR_PRESERVE")
    end
    ItemRefTooltip:SetHyperlink( addon:BuildItemString(itemId) )
end

function addon:PrintLink(itemId)

    local _, itemLink, _, itemLevel, _, itemType, itemSubType, _, itemEquipLoc, itemTexture = GetItemInfo(itemId)
    local itemDrop = addon:GetDropLocs(itemId)
    local itemDropStr = ""
    if itemDrop then
        for k, v in ipairs(itemDrop) do
            itemDropStr = itemDropStr..", PT: "..v
        end
        itemDropStr = strsub(itemDropStr, 3)
    else
        itemDropStr = ""
    end
    
    itemEquipLoc = addon:MapEquipLoc(itemEquipLoc)
    if itemEquipLoc == "" then
        itemEquipLoc = L["notequippable"]
    end

    if addon:IsTierItem(itemId) then
        itemEquipLoc = L[addon.TIER]
        itemSubType = L[addon.TIER]
    else
        itemEquipLoc = _G[itemEquipLoc]
    end

    addon:Print( format( " %s |cff808080%s, %s, %s, %s%s|r",
            itemLink,
            L["ilevel "]..itemLevel,
            L["id "]..itemId,
            L["category "]..itemType.."|"..itemSubType,
            L["slot "].."'"..itemEquipLoc.."'",
            itemDropStr)
        )
end


function addon:IsTierItem(itemId)
    local tier7 = (itemId >= 40610) and (itemId <= 40639)
    local tier8 = (itemId >= 45632) and (itemId <= 45661)
    
    return tier7 or tier8
end
