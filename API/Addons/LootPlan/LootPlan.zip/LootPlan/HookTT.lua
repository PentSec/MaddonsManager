local addon = LootPlan
local L = LibStub("AceLocale-3.0"):GetLocale(addon.ADDONNAME, true)


--[[ Hook Tooltips ]]--
function addon:HookTooltips()
	addon:HookScript(GameTooltip, "OnTooltipSetItem")
	addon:HookScript(ItemRefTooltip, "OnTooltipSetItem")
	if AtlasLootTooltip then
		addon:HookScript(AtlasLootTooltip, "OnTooltipSetItem")
	end
end

--[[ Unhook Tooltips ]]--
function addon:UnhookTooltips()
	addon:Unhook(GameTooltip, "OnTooltipSetItem")
	addon:Unhook(ItemRefTooltip, "OnTooltipSetItem")
	if AtlasLootTooltip then
		addon:Unhook(AtlasLootTooltip, "OnTooltipSetItem")
	end
end


function addon:OnTooltipSetItem(tooltip, ...)
	local ttName = tooltip:GetName()
	
	local itemLink = select(2, tooltip:GetItem())
	if not itemLink then return end

    local itemId = addon:GetItemIdFromItemLink(itemLink)
    
    if not ((itemId) and (itemId > 0)) then return end

    local itemCat = addon:GetItemInCategory(itemId)
    if itemCat then
		tooltip:AddLine(itemCat)

        -- Add the notes of this item to the tooltip
        if addon.db.profile.noteintooltip then
            for catId = addon.CATMIN, addon.CATMAX do
                if addon:tcontains( addon.db.char.lootpercat[catId], itemId ) then

                    local itemNote = addon.db.char.itemnotes[catId..":"..itemId]
                    if itemNote and (itemNote ~= "") then
                        addon:AddToTooltip(tooltip, format(L["tooltip_note"], L["CAT"..catId], itemNote) )
                    end
                end
            end
            
        end

    end
		
end

function addon:GetItemInCategory(itemId)
    local resultStr = ""
    local resultCount = 0
    for catId = addon.CATMIN, addon.CATMAX do
        if addon:tcontains( addon.db.char.lootpercat[catId], itemId ) then
            resultStr = resultStr .. ", " .. L["CAT"..catId]
            resultCount = resultCount + 1
        end
    end
    
    if resultCount > 0 then
        return format( L["tooltip_category"], strsub(resultStr, 3) )
    else
        return nil
    end
end


function addon:AddToTooltip(tooltip, message)
    if not tooltip then return end
    if not message then return end
    
    local str = ""
    for _,s in pairs({strsplit(" ", message)}) do
        if #str + #s >= 50 then

            tooltip:AddLine("|cff0080ff"..str.."|r")
            
            str = "      "
        end
        str = str .. s .. " "
    end

    tooltip:AddLine("|cff0080ff"..str.."|r")

end
