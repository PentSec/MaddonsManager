local start, dur = 0,0 --Reincarnate variables
local onCooldown = false --Reincarnate on CD
local msActive = true --Self shield is up
local esActive = false --ES on someone
local tank --ES target
local freq = 0 --Update counter

------------------------------------------------
--Register used events
------------------------------------------------
function ShammyShields_OnLoad()
    this:RegisterEvent("PLAYER_ENTERING_WORLD")
    this:RegisterEvent("PLAYER_ALIVE")
    this:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
    this:RegisterEvent("BAG_UPDATE")
    this:RegisterEvent("SPELL_UPDATE_COOLDOWN")
	this:RegisterEvent("PLAYER_TALENT_UPDATE")
end

------------------------------------------------
--Update timers every second if currently running
------------------------------------------------
function ShammyShields_OnUpdate(self, elapsed)
    freq = freq + elapsed
    if freq > 1 then
        freq = 0
        if onCooldown then
            Reincarnate_Timer()
        end
        if esActive then
            EShield_Update()
        end
		if msActive then
			MShield_Update()
		end
    end
end

------------------------------------------------
--Event Handler
------------------------------------------------
function ShammyShields_OnEvent(self, event, ...)
    if event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_ALIVE" then
        Ankh_Counter()
        Check_Spec()
    elseif event == "BAG_UPDATE" or event == "SPELL_UPDATE_COOLDOWN" then
        Ankh_Counter()
	elseif event == "PLAYER_TALENT_UPDATE" then
		Check_Spec()
    elseif event == "COMBAT_LOG_EVENT_UNFILTERED" then
        local type, _, sourceName, _, _, destName, _, _, spellName = select(2, ...)
        --Shield applied
        if type == "SPELL_CAST_SUCCESS" and sourceName == UnitName("player") then
			if spellName == "Water Shield" then
                ShammyShields_MSTime:SetTextColor(1,1,1)
                ShammyShields_MSIcon:SetTexture("Interface\\Icons\\Ability_Shaman_WaterShield")
                ShammyShields_MSIcon:SetAlpha(1)
				msActive = true
			elseif spellName == "Lightning Shield" then
                ShammyShields_MSTime:SetTextColor(1,1,1)
                ShammyShields_MSIcon:SetTexture("Interface\\Icons\\Spell_Nature_LightningShield")
                ShammyShields_MSIcon:SetAlpha(1)
				msActive = true
            elseif spellName == "Earth Shield" then
                tank = destName
                esActive = true
                ShammyShields_ESName:SetText(destName)
                ShammyShields_ESName:SetAlpha(1)
                ShammyShields_ESIcon:SetAlpha(1)
            end
        end
    end
end

------------------------------------------------
--Gets the number of Ankh's in users inventory
------------------------------------------------
function Ankh_Counter()
	local num = GetItemCount(17030)
    ShammyShields_Count:SetText("Ankhs: "..num)
    ShammyShields_Count:SetTextColor(1,1,0)
    if GetSpellInfo("Reincarnation") then
        start, dur, _ = GetSpellCooldown("Reincarnation")
        Reincarnate_Timer()
    end
end

------------------------------------------------
--Determines if Reincarnate is on cooldown
--Updates timer if it is, othewise display "Ready"
------------------------------------------------
function Reincarnate_Timer()
    if start >0 and dur>0 then
        onCooldown = true
        local seconds = math.ceil(dur - (GetTime() - start))
        if seconds <=60 then
            ShammyShields_Cooldown:SetText(seconds.. " Sec")
            ShammyShields_Cooldown:SetTextColor(0,1,0)
            if seconds == 1 then
                start = 0
                dur = 0
            end
        else
            local minutes = math.ceil(seconds/60)
            ShammyShields_Cooldown:SetText(minutes.. " Min")
            ShammyShields_Cooldown:SetTextColor(1,0,0)
        end
    else
        onCooldown = false
        ShammyShields_Cooldown:SetText("Ready")
        ShammyShields_Cooldown:SetTextColor(0,0,1)
    end
end

------------------------------------------------
--Checks if the user is specced into Earth Shield
--Adjusts frame accordingly
------------------------------------------------
function Check_Spec()
	local name, _, _, _, rank = GetTalentInfo(3,23)
	if rank == 0 then
        esActive = false
		ShammyShields_BG:SetHeight(75)
		ShammyShields_ESName:SetAlpha(0)
		ShammyShields_ESIcon:SetAlpha(0)
		ShammyShields_ESTime:SetAlpha(0)
		ShammyShields_ESCharges:SetAlpha(0)
	elseif rank == 1 then
		ShammyShields_BG:SetHeight(120)
		ShammyShields_ESTime:SetAlpha(1)
		ShammyShields_ESCharges:SetAlpha(1)
        EShield_Remove()
	end
end

------------------------------------------------
--Checks the status of users Water or Lightning
--Shield and updates timer
------------------------------------------------
function MShield_Update()
    local name, _, _, charges, _, _, x = UnitBuff("player", "Water Shield", nil, "PLAYER")
    if not name then
        name, _, _, charges, _, _, x = UnitBuff("player", "Lightning Shield", nil, "PLAYER")
    end
    if name then
        ShammyShields_MSCharges:SetText(charges)
        ShammyShields_MSTime:SetText(calcTime(-1*(GetTime()-x)))
        return
    end
    MShield_Remove()
end

------------------------------------------------
--Updates frame to show that user has no active shield
------------------------------------------------
function MShield_Remove()
    msActive = false
    ShammyShields_MSCharges:SetText("")
    ShammyShields_MSTime:SetText("No Shield")
    ShammyShields_MSTime:SetTextColor(1,0,0)
    ShammyShields_MSIcon:SetAlpha(.5)
end

------------------------------------------------
--Checks users Earth Shield target
--Updates Timer
------------------------------------------------
function EShield_Update()
    local name, _, _, charges, _, _, x = UnitBuff(tank, "Earth Shield", nil, "PLAYER")
    if name then
        ShammyShields_ESCharges:SetText(charges)
        ShammyShields_ESTime:SetText(calcTime(-1*(GetTime()-x)))
        return
    end
    EShield_Remove()
end

------------------------------------------------
--Updates frame to show that Earth Shield is not
--active any longer
------------------------------------------------
function EShield_Remove()
    esActive = false
    tank = "No Shield"
    ShammyShields_ESName:SetText(tank)
    ShammyShields_ESCharges:SetText("")
    ShammyShields_ESTime:SetText("")
    ShammyShields_ESName:SetAlpha(.5)
    ShammyShields_ESIcon:SetAlpha(.5)
end

------------------------------------------------
--Formats time from seconds into a MM:SS string
------------------------------------------------
function calcTime(time)
    local minutes = math.floor(time/60)
    local seconds = math.floor(time-(minutes*60))
    if seconds < 10 then
        return (minutes..":0"..seconds)
    else
        return (minutes..":"..seconds)
    end
end

------------------------------------------------
--Resets frame to center of the screen
------------------------------------------------
function Reset_Location()
    ShammyShields:ClearAllPoints()
    ShammyShields:SetPoint("CENTER", "WorldFrame", "CENTER", 0, 0)
end

------------------------------------------------
--Command for reseting frame location
------------------------------------------------
SlashCmdList["RESET"] = Reset_Location
SLASH_RESET1 = "/ssreset"
