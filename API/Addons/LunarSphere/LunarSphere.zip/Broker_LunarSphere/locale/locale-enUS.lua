local L = LibStub("AceLocale-3.0"):NewLocale("Broker_LunarSphere","enUS",true)
L["Click|r to toggle LunarSphere"] = true
