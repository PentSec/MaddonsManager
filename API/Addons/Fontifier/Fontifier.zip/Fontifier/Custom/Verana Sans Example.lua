ADDFONT("Verana Sans.ttf",      "Verana Sans")
ADDFONT("Verana Sans Bold.ttf", "Verana Sans Bold")