--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

local folder, core = ...

local IsTradeSkillLinked = IsTradeSkillLinked
local GetTradeSkillItemNameFilter = GetTradeSkillItemNameFilter
local GetTradeSkillLine = GetTradeSkillLine
local GetFirstTradeSkill = GetFirstTradeSkill
local GetNumTradeSkills = GetNumTradeSkills
local GetTradeSkillInfo = GetTradeSkillInfo
local Debug = core.Debug
local GetTradeSkillItemLink = GetTradeSkillItemLink
local ItemLinkToId = core.ItemLinkToId
local GetItemInfo = GetItemInfo
local _
local iID = core.iID
local UnitName = UnitName
local pairs = pairs
local ipairs = ipairs
local table_insert = table.insert
local setmetatable = setmetatable
local getmetatable = getmetatable
local TradeSkillFrameAvailableFilterCheckButton = TradeSkillFrameAvailableFilterCheckButton
local select = select
local GetTradeSkillInvSlots = GetTradeSkillInvSlots
local GetTradeSkillInvSlotFilter = GetTradeSkillInvSlotFilter
local GetTradeSkillSubClasses = GetTradeSkillSubClasses
local GetTradeSkillSubClassFilter = GetTradeSkillSubClassFilter
local TradeSkillOnlyShowMakeable = TradeSkillOnlyShowMakeable
local SetTradeSkillSubClassFilter = SetTradeSkillSubClassFilter
local SetTradeSkillInvSlotFilter = SetTradeSkillInvSlotFilter
local GetNumFactions = GetNumFactions
local CollapseTradeSkillSubClass = CollapseTradeSkillSubClass
local ExpandTradeSkillSubClass = ExpandTradeSkillSubClass
local iLink = core.iLink
local L = core.L
local type = type
local SetTradeSkillItemNameFilter = SetTradeSkillItemNameFilter


local Jewelcrafting = GetSpellInfo(25229) --Jewelcrafting

function core:TRADE_SKILL_SHOW(event,...)
	if not IsTradeSkillLinked() and self.db.profile.saveTradeskills == true then--only gather if it's our tradeskill.
		self:GetTradeskills()
	end
end



--[[
function printSubClasses(...)
	local class
	for i = 1, select("#", ...) do
	--~     print(select(class, ...).. ":", strjoin(", ", GetAuctionItemSubClasses(class)))
		class = select(i, ...)
		print(i, class)
	
	end
end

function CCCabc()--		/run CCCabc()
--~ 	local classes = {GetAuctionItemClasses()}
--~ 	for a, b in pairs(classes) do 
--~ 		Debug("CCCabc", a,b)
--~ 	end
	
	printSubClasses(GetAuctionItemClasses())
end]]

function core:IsGem(itemID)
--~ 	local itemLink = type(itemID) == "string" and itemID:find("|Hitem:") and itemID or iLink[itemID]
	local _, _, _, _, _, itemType = GetItemInfo(itemID)
	return itemType == L.gem --"Gem"
end

function core:GetTradeskills()
--~ 	Debug("GetTradeskills 1")
	if GetTradeSkillItemNameFilter() then
		--There's text in the filter box. 
		return
	end

	if GetTradeSkillLine() == Jewelcrafting then
		
		--Reset all filters/search/headers.
		local collapsedHeaders, showMakeable, subClass, invSlot, search = self:ResetTradeskillFrame()
		
		--Do our stuff.
		local cuts = {}
		local itemLink, itemID
		for i = GetFirstTradeSkill(), GetNumTradeSkills()  do --count
			itemLink = GetTradeSkillItemLink(i)
			if itemLink  and core:IsGem(itemLink) then
				itemID = iID[itemLink]
				table_insert(cuts, #cuts+1, itemID)
			end
		end

		if #cuts > 0 then
			if self.display then
				Debug("GetTradeskills", "ResetCanCutTable")
				self.display:ResetCanCutTable()
			end
			
			local me = UnitName("player")
			self.db.factionrealm.knownCuts[me] = cuts
			Debug("GetTradeskills", "Saved "..me.."'s "..#cuts.." known gems.")
		end

		--Restore filters/search/headers.
		self:RestoreTradeskillFrame(collapsedHeaders, showMakeable, subClass, invSlot, search)

	end
	
end






--~ local prev_OnEnable = core.OnEnable
--~ function core:OnEnable()
--~ 	if prev_OnEnable then
--~ 		prev_OnEnable(self)
--~ 	end
--~ end

function core:ResetTradeskillFrame()
	local search = GetTradeSkillItemNameFilter()
	SetTradeSkillItemNameFilter("")

	-- Clear all filters
	local showMakeable = TradeSkillFrameAvailableFilterCheckButton:GetChecked();
	TradeSkillOnlyShowMakeable(false);
	local invSlot = 0;
	for i = 0, select("#", GetTradeSkillInvSlots()) - 1 do
		if GetTradeSkillInvSlotFilter(i) then
			invSlot = i;
			break;
		end
	end
	local subClass = 0;
	for i = 0, select("#", GetTradeSkillSubClasses()) - 1 do
		if GetTradeSkillSubClassFilter(i) then
			subClass = i;
			break;
		end
	end
	TradeSkillOnlyShowMakeable(false);
	SetTradeSkillSubClassFilter(0, 1, 1);
	SetTradeSkillInvSlotFilter(0, 1, 1);

	local collapsedHeaders = {}
	local skillName, skillType, numAvailable, isExpanded
	local itemLink
	
	--Expand all headers.
--~ 	for i = GetFirstTradeSkill(), GetNumTradeSkills()  do --count
	for i = GetNumTradeSkills(),1, -1   do --count
		skillName, skillType, numAvailable, isExpanded = GetTradeSkillInfo(i);
		if ( skillType == "header" ) then
			if isExpanded ~= 1 then
				collapsedHeaders[skillName] = 1;
				ExpandTradeSkillSubClass(i);
--~ 				Debug("Expanding", skillName)
			end
		end
	end
	
	return collapsedHeaders, showMakeable, subClass, invSlot, search
end

function core:RestoreTradeskillFrame(collapsedHeaders, showMakeable, subClass, invSlot, search)
	-- Restore headers
	local i = 1;
	while i <= GetNumFactions() do
		local name, category, _, isExpanded = GetTradeSkillInfo(i);
		if name and category == "header" and collapsedHeaders[name] then
			CollapseTradeSkillSubClass(i);
--~ 			Debug("Collapsing", name)
		end
		i = i + 1;
	end
	
	-- Restore filters
	TradeSkillOnlyShowMakeable(showMakeable);
	SetTradeSkillSubClassFilter(subClass, 1, 1);
	SetTradeSkillInvSlotFilter(invSlot, 1, 1);
	
	SetTradeSkillItemNameFilter(search or "")
end


