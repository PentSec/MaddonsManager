--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

local folder, core = ...

local UnitExists = UnitExists
local UnitGUID = UnitGUID
local GetInventoryItemLink = GetInventoryItemLink
local GetItemGem = GetItemGem
local _
local GetTime = GetTime
local UnitName = UnitName
local table_insert = table.insert
local iID = core.iID
local ipairs = ipairs
local Debug = core.Debug
local echo = core.echo
local ClearInspectPlayer = ClearInspectPlayer
local L = core.L
local pairs = pairs
local tostring = tostring


local gearSlotsStart	= 1
local gearSlotsEnd		= 18 --http://www.wowwiki.com/API_TYPE_InventorySlotID

--[[
	It takes a few milliseconds after the inspect event fires before gem info becomes available. Our frame here will constantly check for info then fire our CollectGemData function.
]]
local waitFrame = CreateFrame("Frame")
waitFrame:Hide()
waitFrame:SetScript("OnUpdate", function(this, elapsed) 
	this.alive = this.alive - elapsed
	if this.alive < 0 or not UnitExists(this.unitID) or waitFrame.guid ~= UnitGUID(this.unitID) then
		this:Hide()
		return
	end

	local itemLink
	local gemLink
	for s=gearSlotsStart, gearSlotsEnd do
		itemLink = GetInventoryItemLink(this.unitID, s)
		if itemLink then
			for g = 1, 3 do
				_, gemLink = GetItemGem(itemLink,g)
				if gemLink then --Gem info is now available, call our collect info function.
					core:CollectGemData(this.unitID)
					return this:Hide()
				end
			end
		end
	end
end)
waitFrame:SetScript("OnHide", function(this) 
	core.inspectWait:Hide()
end)


--~ local delay = 0
local maxWait = 3 --Only wait 5 seconds for gem info. Else give up.

function core:OnInspect(unitID)
--~ 	delay = GetTime()

	waitFrame.alive = maxWait
	waitFrame.unitID = unitID
	waitFrame.guid = UnitGUID(unitID)
	waitFrame:Show()
end

local function GetGemInfo(itemLink)
	local gems = {}
	local gemLink
	 for g = 1, 3 do
		_, gemLink = GetItemGem(itemLink,g)
		if gemLink then
			table_insert(gems, iID[gemLink])
		end
	end
	return gems
end

function core:CollectGemData(unitID)
--~ 	Debug(self.name, "CollectData", unitID, GetTime() - delay)	
	local name = self:UnitName(unitID)

	local itemLink
	local iGems
	local tGems = {} --total gems
	local gemsFound = false
	for s=gearSlotsStart, gearSlotsEnd do
		itemLink = GetInventoryItemLink(unitID, s)
		
		if itemLink then
			iGems = GetGemInfo(itemLink)
			for i, gemID in ipairs(iGems) do 
--~ 				Debug(self.name,"OnInspect", name, s, itemLink, i, iLink[gemID])
				tGems[gemID] = (tGems[gemID] or 0) + 1
				gemsFound = true
			end
		end
		
	end
	if gemsFound then
--~ 		local now = GetDate()
		
	--~ 	self.db.global.inspected[name] = GetDate()
		local gemCount = 0
		for gID, count in pairs(tGems) do 
			gemCount = gemCount + count
		end
		
		
		Debug("CollectGemData", "who:"..tostring(name), "gems:"..tostring(gemCount))
		
		local serial = self:Serialize(tGems)
		self.db.global.playerGems[name] = serial
		core:SavePlayerInfo(unitID)
	end
end
