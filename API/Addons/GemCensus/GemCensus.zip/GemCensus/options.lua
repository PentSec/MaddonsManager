--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

local folder, core = ...

local LibStub = LibStub
local Debug = core.Debug
local table_insert = table.insert
local table_sort = table.sort
local print = print
local HideUIPanel = HideUIPanel
local InterfaceOptionsFrame = InterfaceOptionsFrame
local GameMenuFrame = GameMenuFrame
local CreateFrame = CreateFrame
local table_wipe = table.wipe
local echo = core.echo
local ENABLE = ENABLE
local pairs = pairs
local StaticPopup_Show = StaticPopup_Show
local L = core.L
local GENERAL = GENERAL
local DISPLAY = DISPLAY
local UnitName = UnitName
local GetAddOnMetadata = GetAddOnMetadata
local tostring = tostring
local INVENTORY_TOOLTIP = INVENTORY_TOOLTIP
local AUCTIONS = AUCTIONS
local TRADESKILLS = TRADESKILLS

local Options = core:NewModule("MainOptions","AceConsole-3.0")

core.defaultSettings.profile = {
	inspectOnTarget = true,
	printWhenInspecting = true,
	inspectThrottle = 24,
	saveInventory = true,
	saveInventoryBank = true,
	saveAuctions = true,
	saveTradeskills = true,
	debugMessages = false,
}



function Options:OnInitialize()
	self:AddBlizzardOptions()
	self:CreateOptionsDisplay()
	
	self:RegisterChatCommand("gc", "ChatCommand")
end

local name = function(info) 
	local key = info[#info]
--~ 	return key
	return L[key.."Name"] and L[key.."Name"]:format(core.db.profile[key]) or key
end
local desc = function(info) 
	local key = info[#info]
--~ 	return key
	return L[key.."Desc"] and L[key.."Desc"]:format(core.db.profile[key]) or key
end

_G.StaticPopupDialogs["GemCensus_DeleteData"] = {
	text = folder.."\n"..L.deleteAllData,
	button1 = OKAY,
	button2 = CANCEL,
	OnAccept = function (self)
		core.db.global.playerGems = {}
		core.db.global.playerInfo = {}
		
		echo(L.deletedAllData)
	end,
	OnHide = function (self)
		core:OpenOptionsFrame()
	end,
	hideOnEscape = 1,
	timeout = 0,
};

function Options:CreateOptionsDisplay()
	local db = core.db
	local options = {
		type = "group",
		name = core.title,
--~ 		get = function( k ) return db[k.arg] end,
--~ 		set = function( k, v ) db[k.arg] = v; end,
		
		get = function(info)
			local key = info[#info]
			return db.profile[key]
		end,
		set = function(info, v)
			local key = info[#info] 
			db.profile[key] = v
		end,
		
		
		args = {},
		plugins = {},
	}
	
	options.plugins["profiles"] = { profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(db) }

	options.args.general = {
		type = "group",
		name = GENERAL,
		order = 1,
		disabled = function(info) 
			if info.type ~= "group" then
				return not core:IsEnabled()
			end
			return false
		end,
		args = {
		
			enable = {
				type = "toggle",	order	= 1,
				name	= ENABLE,
				desc	= desc, --L.enableDesc,
				set = function(info,val) 
					if val == true then
						core:Enable()
					else
						core:Disable()
					end
				
				end,
				get = function(info) return core:IsEnabled() end,
				disabled = false,
			},
			
			inspectOnTarget = {
				type = "toggle",	order	= 5,
				name	= name, --L.inspectOnTargetName,
				desc	= desc, --L.inspectOnTargetDesc,
			},
			
			printWhenInspecting = {
				type = "toggle",	order	= 6,
				name	= name, --L.printWhenInspectingName,
				desc	= desc, --L.printWhenInspectingDesc,
			},

			inspectThrottle = {
				type = "range",	order	= 7,
				name	= name, --L.inspectThrottleName,
				desc	= desc, --"Wait atleast * hours before inspecting someone again.",
				min 	= 1,
				max 	= 24*7,
				step	= 1,
			},
	

			
			deleteInspectData = {
				type = "execute",	order	= 20,
				name	= name, --L.deleteInspectDataName,
				desc	= desc, --L.deleteInspectDataDesc,
				func = function(info, v)
					StaticPopup_Show("GemCensus_DeleteData");
					LibStub("AceConfigDialog-3.0"):Close(core.title)

				end,
			},
		
			debugMessages = {
				type = "toggle",	order	= 30,
				name	= name, --L.inspectOnTargetName,
				desc	= desc, --L.inspectOnTargetDesc,
			},
		},
	}
	
	--Display options are provided by the Display module. If it's not loaded a button is shown to load the module.
	options.args.display = {
		type = "group",
		name = DISPLAY,
		order = 2,
		disabled = function() return not core:IsEnabled() end,
		args = {
		
			Desc = {
				type = "description",
				name = L.displayOptionsMissing,
				order = 1,
			},
			loadDisplay = {
				type = "execute",	order	= 2,
				name	= name, --L.loadDisplayName,
				desc	= desc, --L.loadDisplayDesc,
				func = function(info, v)
					echo(L.loadingDisplayModule)
					core:LoadAddon("GemCensus_Display")
				end,
			},
		}
	}
	
	--[[
	options.args.modules = {
		type = "group",
		name = "Modules",
		order = 3,
		args = {
			test = {
				type = "execute",	order	= 11,
				name	= name, --"Open options frame",
				desc	= desc, --"Sorry Mario, but the options are in another frame.",
				func = function(info, v)
					print("Hi")
					
				end,
			},
		}
	}
	
	local modules = {}
	for name, module in core:IterateModules() do
		if module.GetOptions then
			Debug("CreateOptionsDisplay", name)
			
			table_insert(modules, #modules+1, {name=module.name, mod=module})
		end
	end
	table_sort(modules, function(a,b) 
		if(a and b) then 
			return a.name < b.name;
		end 
	end)
	for i=1, #modules do 
		options.args.modules.args[modules[i].name] = modules[i].mod:GetOptions()
		options.args.modules.args[modules[i].name].order = i
	end
	]]
	
	
	
	
	
	local config = LibStub("AceConfig-3.0")
--~ 	local dialog = LibStub("AceConfigDialog-3.0")
	config:RegisterOptionsTable(core.title, options ) --
--~ 	coreOpts = dialog:AddToBlizOptions(core.title, core.titleFull)
	
	LibStub("AceConfigDialog-3.0"):SetDefaultSize(core.title, 600, 400) --680
	
	self.options = options
	
	self:BuildAboutMenu()
--~ 	self:BuildInvOptions()
end


function Options:ChangeOptionsDisabled(status)
-- When addon is disabled, disable all options except the enable option.
	for subMenu, options in pairs(self.options.args) do 
		for option in pairs(options.args) do 
			if option ~= "enable" then
				options.args[option].disabled = not status
			end
		end
	end
end

function core:OpenOptionsFrame()
	Options:BuildInvOptions()
	Options:BuildAucOptions()
	Options:BuildTradeskillOptions()
	LibStub("AceConfigDialog-3.0"):Open(self.title)
end

local coreOpts
function Options:AddBlizzardOptions()
-- I'm going to use AceConfigDialog's window to show my options. 
-- But I still want my addon listed in Blizzard's options frame. 
-- The only thing shown in the Blizzard options frame will be a button 
-- to open AceConfigDialog's window.

	local blizOptions = {
		name = core.name,
		type = "group",
		args = {
		
			Desc = {
				type = "description",
				name = L.blizOptionsName:format(UnitName("player")),
				order = 1,
			},
			openOptionsFrame = {
				type = "execute",	order	= 2,
				name	= name, --L.openOptionsFrameName,
				desc	= desc, --L.openOptionsFrameDesc,
				func = function(info, v)
					HideUIPanel(InterfaceOptionsFrame)
					HideUIPanel(GameMenuFrame)
					
					--If I open the AceConfigDialog window now it will close once HideUIPanel fires. 
					-- So I'm making a frame to open it on the next frame refresh.
					local f = CreateFrame("Frame")
					f:SetScript("OnUpdate", function(this, elapsed) 
						core:OpenOptionsFrame()
						this:Hide()
						table_wipe(this)
					end)
				end,
			},
		}
	}

	local config = LibStub("AceConfig-3.0")
	local dialog = LibStub("AceConfigDialog-3.0")
	local blizName = core.title.."bliz"
	
	config:RegisterOptionsTable(blizName, blizOptions )
	coreOpts = dialog:AddToBlizOptions(blizName, core.titleFull)
end

----------------------------------------------
function Options:ChatCommand(input)	--
----------------------------------------------
--~ 	InterfaceOptionsFrame_OpenToCategory(submenuOpts) --expand the submenus.
--~ 	InterfaceOptionsFrame_OpenToCategory(coreOpts)

	if not input or input:trim() == "" then
		core:ShowDisplay()
	elseif input == "config" then
		core:OpenOptionsFrame()
	end
end

function Options:BuildAboutMenu()
	local options = self.options
	
	options.args.about = {
		type = "group",
		name = L.about,
		order = 99,
		args = {
		}
	}
	
	local fields = {"Author", "X-Category", "X-License", "X-Email", "Email", "eMail", "X-Website", "X-Credits", "X-Localizations", "X-Donate"}
	local haseditbox = {["X-Website"] = true, ["X-Email"] = true, ["X-Donate"] = true, ["Email"] = true, ["eMail"] = true}

	local fNames = {
		["Author"] = L.author,
		["X-License"] = L.license,
		["X-Website"] = L.website,
		["X-Donate"] = L.donate,
		["X-Email"] = L.email,
	}
	local yellow = "|cffffd100%s|r"
	
	
	
	options.args.about.args.title = {
		type = "description",
		name = yellow:format(L.title..": ")..core.title,
		order = 1,
	}
	options.args.about.args.version = {
		type = "description",
		name = yellow:format(L.version..": ")..core.version,
		order = 2,
	}
	options.args.about.args.notes = {
		type = "description",
		name = yellow:format(L.notes..": ")..tostring(GetAddOnMetadata(folder, "Notes")),
		order = 3,
	}

	for i,field in pairs(fields) do
		local val = GetAddOnMetadata(folder, field)
		if val then
			
			if haseditbox[field] then
				options.args.about.args[field] = {
					type = "input",
					name = fNames[field] or field,
					order = i+10,
					desc = L.clickCopy,
					width = "full",
					get = function(info)
						local key = info[#info]
						return GetAddOnMetadata(folder, key)
					end,	
				}
			else
				options.args.about.args[field] = {
					type = "description",
					name = yellow:format((fNames[field] or field)..": ")..val,
					width = "full",
					order = i+10,
				}
			end
	
		end
	end

	LibStub("AceConfig-3.0"):RegisterOptionsTable(core.title, options ) --
end

--~ local prev_OnEnable = Options.OnEnable
--~ function Options:OnEnable(...)
--~ 	if prev_OnEnable then prev_OnEnable(self, ...) end
--~ end

local Options = core:GetModule("MainOptions")
_G.StaticPopupDialogs["GemCensus_DeleteInvData"] = {
	text = folder.."\n"..L.deleteInvDataDesc..".",
	button1 = OKAY,
	button2 = CANCEL,
	OnAccept = function (self, ...)
		local who = ...
		if who then
			core.db.factionrealm.myInventory[who] = nil
		end
	end,
	OnHide = function (self)
		Options:BuildInvOptions()
		core:OpenOptionsFrame()
	end,
	hideOnEscape = 1,
	timeout = 0,
};
_G.StaticPopupDialogs["GemCensus_DeleteAucData"] = {
	text = folder.."\n"..L.deleteAucDataDesc..".",
	button1 = OKAY,
	button2 = CANCEL,
	OnAccept = function (self, ...)
		local who = ...
		Debug("GemCensus_DeleteAucData","OnAccept", who)
		if who then
			
			core.db.factionrealm.myAuctions[who] = nil
		end
	end,
	OnHide = function (self)
		Options:BuildAucOptions()
		core:OpenOptionsFrame()
	end,
	hideOnEscape = 1,
	timeout = 0,
};

_G.StaticPopupDialogs["GemCensus_DeleteTradeskillData"] = {
	text = folder.."\n"..L.deleteTradeskillDataDesc..".",
	button1 = OKAY,
	button2 = CANCEL,
	OnAccept = function (self, ...)
		local who = ...
		Debug("GemCensus_DeleteTradeskillData","OnAccept", who)
		if who then
			
			core.db.factionrealm.knownCuts[who] = nil
		end
	end,
	OnHide = function (self)
		Options:BuildAucOptions()
		core:OpenOptionsFrame()
	end,
	hideOnEscape = 1,
	timeout = 0,
};

function Options:BuildInvOptions()
	local options = self.options
	
	options.args.inventory = {
		type = "group",
		name = INVENTORY_TOOLTIP,
		order = 3,
		args = {
		
			saveInventory = {
				type = "toggle",	order	= 2,
				name	= name, --L.saveInventoryName,
				desc	= desc, --L.saveInventoryDesc,
			},	
			saveInventoryBank = {
				type = "toggle",	order	= 3,
				name	= name, --L.saveInventoryBankName,
				desc	= desc, --L.saveInventoryBankDesc,
				disabled =  function() return not core.db.profile.saveInventory end,
			},
--~ 			saveAuctions = {
--~ 				type = "toggle",	order	= 4,
--~ 				name	= name, 
--~ 				desc	= desc, 
--~ 			},
			
		}
	}

	local i=10
	for name, inv in pairs(core.db.factionrealm.myInventory) do 
		options.args.inventory.args[name] = {
			type = "execute",	order	= i,
			name	= name,
			desc	= function(info)
				local key = info[#info]
				return L.deleteInvDataDesc:format(key).."."
			end,
			func = function(info, v)
				local key = info[#info]
				StaticPopup_Show("GemCensus_DeleteInvData", key, nil, key);
				LibStub("AceConfigDialog-3.0"):Close(core.title)
			end,
		}
		
		i = i + 1
	end
	
	LibStub("AceConfig-3.0"):RegisterOptionsTable(core.title, options ) --
end


function Options:BuildAucOptions()
	local options = self.options
	
	options.args.auctions = {
		type = "group",
		name = AUCTIONS,
		order = 4,
		args = {
		
			saveAuctions = {
				type = "toggle",	order	= 1,
				name	= name, 
				desc	= desc, 
--~ 				disabled =  function() return not core.db.profile.saveInventory end,
			},
			
		}
	}
	
	local i=10
	for name, inv in pairs(core.db.factionrealm.myAuctions) do 
		options.args.auctions.args[name] = {
			type = "execute",	order	= i,
			name	= name,
			desc	= function(info)
				local key = info[#info]
				return L.deleteAucDataDesc:format(key).."."
			end,
			func = function(info, v)
				local key = info[#info]
				StaticPopup_Show("GemCensus_DeleteAucData", key, nil, key);
				LibStub("AceConfigDialog-3.0"):Close(core.title)
			end,
		}
		
		i = i + 1
	end
	
	LibStub("AceConfig-3.0"):RegisterOptionsTable(core.title, options ) --
end

function Options:BuildTradeskillOptions()
	local options = self.options
	options.args.tradeskill = {
		type = "group",
		name = TRADESKILLS,
		order = 5,
		args = {
		
			saveTradeskills = {
				type = "toggle",	order	= 1,
				name	= name, 
				desc	= desc, 
--~ 				disabled =  function() return not core.db.profile.saveInventory end,
			},
			
		}
	}
	
	
	
	local i=10
	for name, inv in pairs(core.db.factionrealm.knownCuts) do 
		options.args.tradeskill.args[name] = {
			type = "execute",	order	= i,
			name	= name,
			desc	= function(info)
				local key = info[#info]
				return L.deleteTradeskillDataDesc:format(key).."."
			end,
			func = function(info, v)
				local key = info[#info]
				StaticPopup_Show("GemCensus_DeleteTradeskillData", key, nil, key);
				LibStub("AceConfigDialog-3.0"):Close(core.title)
			end,
			
--~ 			get = function( k ) return db[k.arg] end,
--~ 			set = function( k, v ) db[k.arg] = v; end,
		}
		
		i = i + 1
	end
	
	LibStub("AceConfig-3.0"):RegisterOptionsTable(core.title, options ) --
	
end