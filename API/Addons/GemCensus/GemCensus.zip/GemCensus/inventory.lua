--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

local folder, core = ...
local Debug = core.Debug

local L = core.L
local UnitName = UnitName
local iLink = core.iLink
local NUM_BAG_FRAMES = NUM_BAG_FRAMES
local GetContainerNumSlots = GetContainerNumSlots
local GetContainerItemID = GetContainerItemID
local GetItemInfo = GetItemInfo
local GetContainerItemInfo = GetContainerItemInfo
local pairs = pairs
local NUM_BAG_SLOTS = NUM_BAG_SLOTS
local BANK_CONTAINER = BANK_CONTAINER
local GetNumBankSlots = GetNumBankSlots
local LibStub = LibStub
local StaticPopup_Show = StaticPopup_Show
local GetNumAuctionItems = GetNumAuctionItems
local GetAuctionItemLink = GetAuctionItemLink
local _
local GetAuctionItemInfo = GetAuctionItemInfo


function core:BANKFRAME_OPENED(event)
	if self.db.profile.saveInventoryBank == true then
--~ 		Debug(event, GetContainerNumSlots(BANK_CONTAINER))
		local numSlots = GetContainerNumSlots(BANK_CONTAINER)
		for s=1, numSlots do 
			self:PLAYERBANKSLOTS_CHANGED("PLAYERBANKSLOTS_CHANGED", s)
		end
		
	--~ 	/run print(GetNumBankSlots())
		local bankContainers = GetNumBankSlots()
		
		for bagID=NUM_BAG_SLOTS+1, bankContainers do 
			self:BAG_UPDATE("BAG_UPDATE", bagID)
		end
	end
end


function core:PLAYERBANKSLOTS_CHANGED(event, s)
--~ 	Debug(event, s)
	if self.db.profile.saveInventoryBank == true then
		local bagID = BANK_CONTAINER
		self:SaveSlotInfo(BANK_CONTAINER, s)
	end
end


function core:SaveSlotInfo(bagID, s)
--~ 	Debug("SaveSlotInfo", "bagID:"..bagID, "slot:"..s)
--~ 	local slotsSaved = 0
	if self.db.profile.saveInventory == true then
		local itemID = GetContainerItemID(bagID, s)
		local name = UnitName("player")
		
		if itemID and self:IsGem(itemID) then
--~ 			Debug("SaveSlotInfo", "bagID:"..bagID, "slot:"..s, itemID and iLink[itemID])
	--~ 			self.db.factionrealm.knownCuts[me] = cuts
			self.db.factionrealm.myInventory[name] = self.db.factionrealm.myInventory[name] or {}
			self.db.factionrealm.myInventory[name][bagID] = self.db.factionrealm.myInventory[name][bagID] or {}
			
			local _, count = GetContainerItemInfo(bagID, s)
	
			self.db.factionrealm.myInventory[name][bagID][s] = {id=itemID, count=count}
--~ 			slotsSaved = slotsSaved + 1
			
		else
			if self.db.factionrealm.myInventory[name] and self.db.factionrealm.myInventory[name][bagID] then
				self.db.factionrealm.myInventory[name][bagID][s] = nil
			end
		end
	end
--~ 	return slotsSaved
end

function core:BAG_UPDATE(event, bagID)
	local numSlots = GetContainerNumSlots(bagID)
--~ 	Debug(event, bagID, numSlots)
	local name = UnitName("player")
	if self.db.factionrealm.myInventory[name] then
		self.db.factionrealm.myInventory[name][bagID] = nil
	end

	local itemID
	for s=1, numSlots do 
		self:SaveSlotInfo(bagID, s)
	end
end

function core:SaveInventory()
	Debug("SaveInventory", "Saving inventory at login...")
	local numSlots
	local slotsSaved = 0
	for bagID=0, NUM_BAG_FRAMES do 
		 self:BAG_UPDATE("BAG_UPDATE", bagID)
	end
end

function core:SayMyGems()--		/run _GC:SayMyGems()
	local name = UnitName("player")
	
	if self.db.factionrealm.myInventory[name] then
		for bagID, slots in pairs(self.db.factionrealm.myInventory[name]) do 
			for slot, slotInfo in pairs(slots) do 
				
				Debug("SayMyGems", bagID, slot, iLink[slotInfo.id], slotInfo.count)
			
			end
		end
	end
end

function core:GetMyGems(includeBank)
	local includeBank = includeBank or false
	local myGems = {}
	
	local myName = UnitName("player")
	
	if self.db.factionrealm.myInventory[myName] then
		for bagID, slots in pairs(self.db.factionrealm.myInventory[myName]) do 
			if includeBank == true or bagID > BANK_CONTAINER and bagID <= NUM_BAG_SLOTS then
				for slot, slotInfo in pairs(slots) do 
					myGems = myGems or {}
					myGems[slotInfo.id] = (myGems[slotInfo.id] or 0) + slotInfo.count
				end
			end
		end
	end
	return myGems
end

function core:GetMyInventory(includeBank)--		/run _GC:GetMyInventory()
	local myGems = {}
	local includeBank = includeBank or false
	
--~ 	if self.db.factionrealm.myInventory[name] then
--~ 	local myName = UnitName("player")
	for name, inv in pairs(self.db.factionrealm.myInventory) do 
		
--~ 		if alts == true or myName == name then
		
			for bagID, slots in pairs(inv) do 
				if includeBank == true or bagID > BANK_CONTAINER and bagID <= NUM_BAG_SLOTS then
			
					for slot, slotInfo in pairs(slots) do 
						
		--~ 				Debug("SayMyGems", bagID, slot, iLink[slotInfo.id], slotInfo.count)
						
						myGems[name] = myGems[name] or {}
						
						
						
						myGems[name][slotInfo.id] = (myGems[name][slotInfo.id] or 0) + slotInfo.count
						
					end
				end
				
			end
--~ 		end
	end
--~ 	end
	
--~ 	for name, inv in pairs(myGems) do 
--~ 		for gemID, count in pairs(inv) do 
--~ 			Debug("SayMyGems", name, iLink[gemID], count)
--~ 		end
--~ 	end
	
	return myGems
end

local prevAuctionsSaved = 0
local iID = core.iID
function core:AUCTION_OWNED_LIST_UPDATE(event)
	if self.db.profile.saveAuctions == true then
		local numBatchAuctions, totalAuctions = GetNumAuctionItems("owner")
		local name = UnitName("player")
		self.db.factionrealm.myAuctions[name] = nil
		local auctionsSaved = 0
	--~ 	myAuctions
	--~ 	self.db.factionrealm.myInventory
		local itemLink
		local  owner, sold 
		local numSold = 0
		for i=1, totalAuctions do 
			itemLink = GetAuctionItemLink("owner", i)
			
			
			if itemLink and self:IsGem(itemLink) then
				_, _, _, _, _, _, _, _, _, _, _, owner, sold = GetAuctionItemInfo("owner", i)
				
--~ 				Debug(event, i, itemLink, sold)
				if sold == 1 then
					numSold = numSold + 1
				else
					local itemID = iID[itemLink]
					self.db.factionrealm.myAuctions[name] = self.db.factionrealm.myAuctions[name] or {}
					
					self.db.factionrealm.myAuctions[name][itemID] = (self.db.factionrealm.myAuctions[name][itemID] or 0) + 1
					
					auctionsSaved = auctionsSaved + 1
				end
			end
		end
		
		if prevAuctionsSaved ~= auctionsSaved then
			prevAuctionsSaved = auctionsSaved
			Debug(event, "Saved "..auctionsSaved.." gem auctions.", (numSold > 0 and "(ignoring "..numSold.." sold)" or nil))
		end
	--~ 	Debug(event, numBatchAuctions, totalAuctions, GetOwnerAuctionItems())
	end
end

function core:SayMyAuctions()--		/run _GC:SayMyAuctions()
	for name, auctions in pairs(self.db.factionrealm.myAuctions) do 
		for gemID, count in pairs(auctions) do 
			Debug("SayMyAuctions", name, iLink[gemID], count)
		end
	end
end

function core:GetMyAuctions()
	local myAuctions = {}
	for name, auctions in pairs(self.db.factionrealm.myAuctions) do 
		for gemID, count in pairs(auctions) do 
--~ 			Debug("SayMyAuctions", name, iLink[gemID], count)
			myAuctions[gemID] = (myAuctions[gemID] or 0) + count
			
			
		end
	end
	
	return myAuctions
end

--[[
local myInv = {}
local function eventFire(this, event, ...)
	local numSlots
	local endLine = false
	for bagID=0, NUM_BAG_FRAMES do 
--~ 		if not myInv[bagID] then
--~ 			myInv[bagID] = {}
--~ 		end
		numSlots = GetContainerNumSlots(bagID)
		for s=1, numSlots do 
			local itemID = GetContainerItemID(bagID, s)
			if itemID then
				if not myInv[bagID] then
					print("A", bagID, event, ...)
					myInv[bagID] = {}
				end
				if not myInv[bagID][s] or myInv[bagID][s] ~= itemID then
					print("B", bagID, iLink[itemID], event, ...)
					myInv[bagID][s] = itemID
					
					this.killTime = GetTime() + 1
					this:Show()
					endLine = true
				end
			end
		end
	end
	if endLine then
		print("C", event, ..., "------------")
	end
	
	if this:IsShown() then
		print("D", event, ...)
	end
end

local f = CreateFrame("Frame")
f:Hide()
f:RegisterAllEvents()
f:SetScript("OnEvent", eventFire)
f.killTime = GetTime()+5
f:SetScript("OnUpdate", function(this, elapsed) 
	if GetTime() > this.killTime then
--~ 		this:UnregisterAllEvents()
		this:Hide()
		
		eventFire(this, "END")
	end
end)]]
