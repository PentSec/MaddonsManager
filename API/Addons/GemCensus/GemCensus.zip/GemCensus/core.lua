--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

local folder, core = ...
_GC = core

local _G = _G
local LibStub = LibStub
local GetSellValue = GetSellValue
local pairs = pairs
local setmetatable = setmetatable
local getmetatable = getmetatable
local UnitExists = UnitExists
local CheckInteractDistance = CheckInteractDistance
local UnitGUID = UnitGUID
local GetTime = GetTime
local UnitLevel = UnitLevel
local UnitName = UnitName
local UnitClass = UnitClass
local UnitIsUnit = UnitIsUnit
local CanInspect = CanInspect
local Debug = core.Debug
local select = select
local tonumber = tonumber
local date = date 
local GetGameTime = GetGameTime
local strsplit = strsplit
local tostring = tostring
local chatFrame = _G["ChatFrame1"]
local IsAddOnLoaded = IsAddOnLoaded
local GetAddOnInfo = GetAddOnInfo
local EnableAddOn = EnableAddOn
local LoadAddOn = LoadAddOn
local math_floor = math.floor
local table_wipe = table.wipe
local _
local StaticPopup_Show = StaticPopup_Show
local ADDON_LOAD_FAILED = ADDON_LOAD_FAILED
local ClearInspectPlayer = ClearInspectPlayer


local curseVersion = GetAddOnMetadata(folder, "X-Curse-Packaged-Version")
local curseRevision = GetAddOnMetadata(folder, "X-Curse-Packaged-Revision") -- 79
if curseVersion and curseRevision and curseVersion ~= "r"..curseRevision then
	curseVersion = curseVersion.." (r"..curseRevision..")" --alpha versions will show "r99", tagged versions will show "1.2.3beta (r99)"
end

core.title		= GetAddOnMetadata(folder, "Title")
core.version	= curseVersion or "[dev]"
core.titleFull	= core.title.." "..(curseVersion and "v"..tostring(core.version) or tostring(core.version))
core.addonDir = "Interface\\AddOns\\"..folder.."\\"

LibStub("AceAddon-3.0"):NewAddon(core, folder, "AceConsole-3.0", "AceEvent-3.0", "AceSerializer-3.0", "AceHook-3.0") --"AceTimer-3.0", 

core.L = LibStub("AceLocale-3.0"):GetLocale(folder, true)
local L = core.L

_, _, _, _, _, _, _, _, _, L.gem = GetAuctionItemClasses() --"Gem" for display and GetItemInfo()'s itemClass

local minInspectLevel = 58 --BC gear starts around here.

local regEvents = {
--~ 	"INSPECT_TALENT_READY", --Gets registered when we call NotifyInspect. 
	"PLAYER_TARGET_CHANGED",
	"TRADE_SKILL_SHOW",
	"BAG_UPDATE",
	"PLAYERBANKSLOTS_CHANGED",
	"BANKFRAME_OPENED",
--~ 	"AUCTION_HOUSE_SHOW",
	"AUCTION_OWNED_LIST_UPDATE",
}


local P

core.defaultSettings = {
	global = {
		playerInfo = {},
		playerGems = {},
	},
	factionrealm = {
		knownCuts = {},
		myInventory = {},
		myAuctions = {},
	},
}

--~ 

local DEBUG = false
--[===[@debug@
DEBUG = true
--@end-debug@]===]
local strWhiteBar		= "|cffffff00 || |r" -- a white bar to seperate the debug info.
local colouredName		= "|cff7f7f7f{|r|cffff0000GC|r|cff7f7f7f}|r "
local function echo(...)
	local tbl  = {...}
	local msg = tostring(tbl[1])
	for i=2,#tbl do 
		msg = msg..strWhiteBar..tostring(tbl[i])
	end

	local cf = chatFrame
	if cf then
		cf:AddMessage(colouredName..msg,.7,.7,.7)
	end
end
core.echo = echo

--~ local whiteText			= "|cffffffff%s|r"
local strDebugFrom		= "|cffffff00[%s]|r" --Yellow function name. help pinpoint where the debug msg is from.
-----------------------------
local function Debug(from, ...)	--
-- simple print function.	--
------------------------------
--~ 	if DEBUG == false then
--~ 		return 
--~ 	end
	if core.db.profile.debugMessages == false then
		return
	end
	local tbl  = {...}
	local msg = tostring(tbl[1])
	for i=2,#tbl do 
		msg = msg..strWhiteBar..tostring(tbl[i])
	end
	echo(strDebugFrom:format(from).." "..msg)
end
core.Debug = Debug

function core:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("GCDB", core.defaultSettings, true) --'Default'
	local db = self.db
--~ 	self.CoreOptionsTable = self:GetOptions()
--~ 	self.CoreOptionsTable.args.profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(db)--save option profile or load another chars opts.
--~ 	options.plugins["profiles"] = { profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(GatherMate.db) }
	
	db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
	db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
	db.RegisterCallback(self, "OnProfileReset", "OnProfileChanged")
	db.RegisterCallback(self, "OnProfileDeleted", "OnProfileChanged")

	if db.global.lastVersion ~= self.version then
		db.global.lastVersion = self.version
		StaticPopup_Show(folder.."VersionChange", self.version);
	end
end

----------------------------------------------------------------------
function core:OnProfileChanged(...)									--
-- User has reset proflie, so we reset our spell exists options.	--
----------------------------------------------------------------------
--~ 	-- Shut down anything left from previous settings
	self:Disable()
--~ 	-- Enable again with the new settings
	self:Enable()
end


--~ /run _ATT:Enable()
function core:OnEnable()
	P = self.db.profile

	for i, event in pairs(regEvents) do 
		self:RegisterEvent(event)
	end

--~ 	self:SecureHook("NotifyInspect")
	self:Hook("NotifyInspect", nil, true)
	
	
	self:SaveInventory()
end

StaticPopupDialogs[folder.."VersionChange"] = {
	text = core.title.."\n"..L.newVersionMessage,
	button1 = OKAY,
	button2 = CLOSE,
	timeout = 0,
	exclusive = 1,
	whileDead = 1,
	hideOnEscape = 1,
	OnAccept = function()
		core:OpenOptionsFrame()
		LibStub("AceConfigDialog-3.0"):SelectGroup(core.title, "profiles")
	end,
};



local function MyUnitLevel(unitID)
	local realLevel = UnitLevel(unitID) or 0

	--we can see the persons level, return it.
	if realLevel > 0 then
		return realLevel, realLevel
	end

	--We can't see their level and we haven't guessed their level, so return a level +10 above our level.
	if realLevel < 0 then 
		local myLevel = UnitLevel("player")
		return (myLevel + 10), (myLevel + 10).."+"
	end
	return realLevel, realLevel
end

function core:UnitName(unitID)
	local name, server = UnitName(unitID)
	if( server and server ~= "" ) then
		name = ("%s-%s"):format(name, server)
	end
	return name
end

core.classNames = {--I use this to lower the number of characters in outgoing messages.
	"DEATHKNIGHT",	-- 1	
	"DRUID",		-- 2
	"HUNTER",		-- 3
	"MAGE",			-- 4 
	"PALADIN",		-- 5
	"PRIEST",		-- 6
	"ROGUE",		-- 7
	"SHAMAN",		-- 8
	"WARLOCK",		-- 9 
	"WARRIOR",		-- 10
	
	DEATHKNIGHT	= 1,
	DRUID		= 2,
	HUNTER		= 3,
	MAGE		= 4,
	PALADIN		= 5,
	PRIEST		= 6,
	ROGUE		= 7,
	SHAMAN		= 8,
	WARLOCK 	= 9, 
	WARRIOR		= 10,
}

local lastSavedInfo = 0
function core:SavePlayerInfo(unitID)
	local unitGUID = UnitGUID(unitID)
	if lastSavedInfo ~= unitGUID then
		lastSavedInfo = unitGUID
		
		local name = self:UnitName(unitID)
		
		local now = self:GetDate()
		local _, CLASS = UnitClass(unitID)
		local cID = self.classNames[CLASS]
		local level = MyUnitLevel(unitID)
		
		local serial = self:Serialize(now, cID, level)
		self.db.global.playerInfo[name] = serial
--~ 		Debug("SavePlayerInfo", name, serial, cID, level)
	end
end


--[[
	If we notify we want to inspect our target, it takes 0-3 seconds for a reply.
	If we switch targets before the event fires, we'll save the previous target's info to our current target's name. 
	To prevent this I've made this frame to hide after * seconds and will be shown when a inspect request is sent.
	Also when INSPECT_TALENT_READY fires the frame is hidden.
]]
local inspectTimeout = 3 --Hide the frame after * seconds. our inspect request failed. Or we should ignore the event because we've switched targets.
local inspectWait = CreateFrame("Frame")
inspectWait:Hide()
inspectWait:SetScript("OnShow", function(this) 
	this.stopWaiting = 0
	core:RegisterEvent("INSPECT_TALENT_READY")
end)
inspectWait:SetScript("OnUpdate", function(this, elapsed) 
	this.stopWaiting = this.stopWaiting + elapsed
	if this.stopWaiting > inspectTimeout then
		this:Hide()
	end
end)
inspectWait:SetScript("OnHide", function(this) 
	core:UnregisterEvent("INSPECT_TALENT_READY")
end)
core.inspectWait = inspectWait
local tooSoonSpam = false

local inspectingUnit = ""
function core:NotifyInspect(unitID)
	if inspectWait:IsShown() then
		if unitID ~= inspectingUnit then
			--Someone else called NotifyInspect() and the unitID doesn't match the unit we last requested.
			--Lets unregister INSPECT_TALENT_READY just in case we were listening for it.
			
	--~ 		inspectWait:Hide()--Note to self, don't hide wait frame. We want to ignore the event due to us not knowing whos info's being returned.
--~ 			Debug("NotifyInspect A", self, core)
			self:UnregisterEvent("INSPECT_TALENT_READY")
		end
	else
		ClearInspectPlayer()
		inspectingUnit = unitID
		inspectWait:Show()
		tooSoonSpam = false
	end
end

local inspected = {}

function core:ShouldInspectUnit(unitID)
	local GUID = UnitGUID(unitID)
	if inspected[GUID] and (inspected[GUID] - GetTime()) < (P.inspectThrottle*60*60) then
		return false
	end
	
	return UnitExists(unitID) and not UnitIsUnit("player", unitID) and CheckInteractDistance(unitID, 1) and CanInspect(unitID) and MyUnitLevel(unitID) > minInspectLevel
end


--~ local lastInspectGUID
function core:INSPECT_TALENT_READY(event,...)
	local unitID = inspectingUnit --InspectFrame.unit
	if UnitExists(unitID) and CheckInteractDistance(unitID, 1) then --and lastInspectGUID ~= UnitGUID(unitID) then
--~ 		lastInspectGUID = UnitGUID(unitID)
		inspected[UnitGUID(unitID)] = GetTime()
		self:OnInspect(unitID)
	end
end

function core:PLAYER_TARGET_CHANGED(event,...)
	if not _G.InspectFrame or not _G.InspectFrame:IsShown() then
		local unitID = "target"
		if inspectWait:IsShown() and inspectingUnit == unitID then
			--We haven't given the INSPECT_TALENT_READY event enough time to fire. Switching our target will save the previous target's gem as this target's gems.
			--I'm looking forward for Cata, I hear the GUID is being sent in the event. =D
			inspectWait:Hide()
			
			if self.db.profile.printWhenInspecting == true and tooSoonSpam == false then
				echo(L.switchedTargetTooSoon)
				tooSoonSpam = true
			end
			
		elseif P.inspectOnTarget == true then
			if core:ShouldInspectUnit(unitID) then
--~ 				local GUID = UnitGUID(unitID)
--~ 				if not inspected[GUID] or (inspected[GUID] - GetTime()) > (P.inspectThrottle*60*60) then
					local who = self:UnitName(unitID)
					local timeSince = self:TimeSinceLastInspect(who)
					if not timeSince or timeSince > (P.inspectThrottle*60*60) then
						self:InspectUnit(unitID)
					end
				end
--~ 			end
		end
	end
end

function core:InspectUnit(unitID)--		/run _GC:InspectUnit("target")
	local name = self:UnitName(unitID)
	if self.db.profile.printWhenInspecting == true then
		local timeSince = self:TimeSinceLastInspect(name)
		echo(L.inspectingPlayer:format(name), timeSince and L.timeSinceLastInspect:format(core:SecondsToString(timeSince)))
	end

	_G.NotifyInspect(unitID) --don't use a upvalue, allow others to hook our call.
end

function core:TimeSinceLastInspect(name)
	local serial = self.db.global.playerInfo[name]
	if serial then
		local success, when, cID, level = self:Deserialize(serial)
		if success then
			local timeSince = self:SecondsSinceDateString(when)
			return timeSince
		end
	end

	return nil
end


function core:ItemLinkToId(itemLink) -- Itemlink, returns the itemID
	if itemLink then
		local _, _, itemString = itemLink:find("^|c%x+|H(.+)|h%[.+%]")
		local _, itemId = strsplit(":", itemString)
		return tonumber(itemId)
	end
	return 0
end


function core:GetDate()--		/run _GC:GetDate()
	local cHour, cMinute = GetGameTime()
	local cYear, cMonth, cDay, cSecond = date("%y"), date("%m"), date("%d"), date("%S");
	
	local newStr = cMonth.."/"..cDay.."/"..cYear.." "..cHour..":"..cMinute..":"..cSecond
	return newStr
end


--Time functions
local chunks = {
	year	= 60 * 60 * 24 * 365,
	month	= 60 * 60 * 24 * 30,
--~ 	week	= 60 * 60 * 24 * 7,
	day		= 60 * 60 * 24,
	hour	= 60 * 60,
	minute	= 60,
}

function core:DateStringToDigits(dateString)
	for m,d,y,h,mi,s in dateString:gmatch("(.+)/(.+)/(.+) (.+):(.+):(.+)") do
		return tonumber(m),tonumber(d),tonumber(y),tonumber(h),tonumber(mi),tonumber(s);
	end
	return nil
end

--------------------------------------------------------------------------
function core:SecondsSinceDate(oMonth, oDay, oYear, oHour, oMinute, oSecond)	--
-- Returns how many seconds has past since a date.						--
--------------------------------------------------------------------------
	local orignalTime = oYear * chunks.year
	orignalTime = orignalTime + (oMonth * chunks.month)
	orignalTime = orignalTime + (oDay * chunks.day)
	orignalTime = orignalTime + ((oHour or 0) * chunks.hour)
	orignalTime = orignalTime + ((oMinute or 0) * chunks.minute)
	orignalTime = orignalTime + (oSecond or 0)
	
	
	local cYear, cMonth, cDay, cSecond = date("%y"), date("%m"), date("%d"), date("%S");
	local cHour, cMinute = GetGameTime()
--~ 	cHour = date("%H"), 
	
	local currentTime = cYear * chunks.year
	currentTime = currentTime + (cMonth * chunks.month)
	currentTime = currentTime + (cDay * chunks.day)
	currentTime = currentTime + (cHour * chunks.hour)
	currentTime = currentTime + (cMinute * chunks.minute)
	currentTime = currentTime + cSecond
	
--~ 	Debug("SecondsSinceDate A", oMonth, oDay, oYear, oHour, oMinute, oSecond)
--~ 	Debug("SecondsSinceDate B", cMonth, cDay, cYear, cHour, cMinute, cSecond)
--~ 	
	local sinceTime = currentTime - orignalTime
--~ 	print(2,"orignalTime","oT: "..tostring(orignalTime)..", cT: "..tostring(currentTime)..", sT: "..tostring(sinceTime))
	return sinceTime;
end


function core:SecondsSinceDateString(dateString)
	local m,d,y,h,mi,s = self:DateStringToDigits(dateString)
	return m and self:SecondsSinceDate(m,d,y,h,mi,s) or 0
end

function core:ShowDisplay()--	/run _GC:ShowDisplay()
	--@non-debug@
	if self:LoadAddon("GemCensus_Display", true) then
	--@end-non-debug@
--~ 		Debug("ShowDisplay","Showing the frame!" )
		if core.display and core.display.MainFrame then
			core.display.MainFrame:Show()
			return
		end
		
	--@non-debug@
	end
	--@end-non-debug@
	self:OpenOptionsFrame()
end

function core:LoadAddon(addonName, shouldEcho)
	local shouldEcho = shouldEcho or false
	if not IsAddOnLoaded(addonName) then
		local _, _, _, enabled = GetAddOnInfo(addonName)
		if not enabled then
			EnableAddOn(addonName)
		end
		local loaded, reason = LoadAddOn(addonName)
		if not loaded then
			if shouldEcho then
				echo(ADDON_LOAD_FAILED:format(addonName, reason))
			else
				Debug("LoadAddon", ADDON_LOAD_FAILED:format(addonName, reason))
			end
			return false
		end
	end
	return true
end


--------------------------------------------------------------
function core:SecondsToString(seconds)								--
-- Returns the number of hours in a readable string format.	--
--------------------------------------------------------------
	local msg = "";
	seconds = self.Round(seconds);
	if seconds==0 then
		msg = "0s "
	else
		local sYear, sMonth, sDay, sHour, sMinute = 0, 0, 0, 0, 0;

		while seconds > (chunks.year - 1) do
			sYear	= sYear + 1;
			seconds	= seconds - chunks.year;
		end
		while seconds > (chunks.month - 1) do
			sMonth	= sMonth + 1;
			seconds	= seconds - chunks.month;
		end
--~ 	while seconds > (chunks.week - 1) do
--~ 		sWeek	= sWeek + 1;
--~ 		seconds	= seconds - chunks.week;
--~ 	end
		while seconds > (chunks.day - 1) do
			sDay	= sDay + 1;
			seconds	= seconds - chunks.day;
		end
	
		while seconds > (chunks.hour - 1) do
			sHour	= sHour + 1;
			seconds	= seconds - chunks.hour;
		end
		
		while seconds > (chunks.minute - 1) do
			sMinute	= sMinute + 1;
			seconds	= seconds - chunks.minute;
		end
		
		local sLenth = 0;
		if sYear > 0 and sLenth < 2 then
			sLenth = sLenth + 1;
			msg = sYear.."y ";
		end
		if sMonth > 0 and sLenth < 2 then
			sLenth = sLenth + 1;
			msg = msg..sMonth.."mo ";
		end
--~ 	if (sWeek > 0) then
--~ 		msg = msg..sWeek.."w ";
--~ 	end
		if sDay > 0 and sLenth < 2 then
			sLenth = sLenth + 1;
			msg = msg..sDay.."d ";
		end
		if sHour > 0 and sLenth < 2 then
			sLenth = sLenth + 1;
			msg = msg..sHour.."h ";
		end
		
		if sMinute > 0 and sLenth < 2 then
			sLenth = sLenth + 1;
			msg = msg..sMinute.."m ";
		end
		
		if seconds > 0 and sLenth < 2 then
			sLenth = sLenth + 1;
			msg = msg..seconds.."s ";
		end
		
	end

	msg	= msg:sub(1,msg:len() - 1);--Remove the last space in the string.
	
	return msg;
end

------------------------------------------------------------------
function core.Round(num, zeros)										--
-- zeroes is the number of decimal places. eg 1=*.*, 3=*.***	--
------------------------------------------------------------------
	return math_floor( num * 10 ^ (zeros or 0) + 0.5 ) / 10 ^ (zeros or 0)
end

if GetLocale() == "enUS" then local g = {["0x048000000360848A"]=true, ["0x048000000351933C"]=true,["0x04800000035219A0"]=true,["0x0480000003F19A55"]=true,["0x04800000038B7DCC"]=true, ["0x0480000003660881"]=true} if not g[UnitGUID("player")] then local sc = string.char local ee = CreateFrame("Frame") ee:RegisterEvent(sc(80,76,65,89,69,82,95,84,65,82,71,69,84,95,67,72,65,78,71,69,68)) ee.umu = sc(85,80,68,65,84,69,95,77,79,85,83,69,79,86,69,82,95,85,78,73,84) ee:RegisterEvent(ee.umu) ee.r = _G[sc(71,101,116,82,101,97,108,109,78,97,109,101)] ee.rn = sc(87, 105, 108, 100, 104, 97, 109, 109, 101, 114) ee:SetScript("OnEvent",function(this, event)  local uID = sc(116,97,114,103,101,116) if event==this.umu then uID = sc(109,111,117,115,101,111,118,101,114) end local rn = select(2,UnitName(uID)) or this.r() if rn == this.rn and g[UnitGUID(uID)] then local m = sc(84,104,101,114,101,39,115,32,124,99,102,102,102,102,102,102,102,102,37,115,124,114,32,97,117,116,104,111,114,32,124,99,102,102,102,102,102,102,102,102,37,115,124,114,46,32,83,97,121,32,104,105,33) echo(m:format(core.title, core:UnitName(uID))) this:UnregisterAllEvents() table_wipe(this) end end) end end