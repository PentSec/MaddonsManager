--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

local folder, core = ...

local GetItemInfo = GetItemInfo
local select = select
local GetSpellLink = GetSpellLink

--Get ID from link
core.iID = setmetatable({}, {
	__index = function(t,i)
	-- Get the value and stash it for later
	local v = core:ItemLinkToId(i)
	t[i] = v
	return v
	end
})

core.iName = setmetatable({}, {
	__index = function(t,i)
	-- Get the value and stash it for later
	t[i] = GetItemInfo(i) or "UNKNOWN"
	return t[i]
	end
})

--Get Link form itemID
core.iLink = setmetatable({}, {
	__index = function(t,i)
	-- Get the value and stash it for later
	if GetItemInfo(i) then
		t[i] = select(2, GetItemInfo(i))
	else
		t[i] = false
	end
	return t[i]
	end
})



core.iQuality = setmetatable({}, {
	__index = function(t,i)

	t[i] = select(3, GetItemInfo(i))
	return t[i]
	end
})

core.iLevel = setmetatable({}, {
	__index = function(t,i)
	t[i] = select(4, GetItemInfo(i))
	return t[i]
	end
})

core.iReqLevel = setmetatable({}, {
	__index = function(t,i)
	t[i] = select(5, GetItemInfo(i))
	return t[i]
	end
})

core.iClass = setmetatable({}, {
	__index = function(t,i)
	t[i] = select(6, GetItemInfo(i))
	return t[i]
	end
})

core.iSubClass = setmetatable({}, {
	__index = function(t,i)
	t[i] = select(7, GetItemInfo(i))
	return t[i]
	end
})

core.iMaxStack = setmetatable({}, {
	__index = function(t,i)
	t[i] = select(8, GetItemInfo(i))
	return t[i] 
	end
})

core.iEquipSlot = setmetatable({}, {
	__index = function(t,i)
	t[i] = select(9, GetItemInfo(i))
	return t[i]
	end
})

core.iTexture = setmetatable({}, {
	__index = function(t,i)
	t[i] = select(10, GetItemInfo(i))
	return t[i]
	end
})

core.iVendorPrice = setmetatable({}, {
	__index = function(t,i)
	t[i] = select(11, GetItemInfo(i))
	return t[i]
	end
})


--Get Link form itemID
core.sLink = setmetatable({}, {
	__index = function(t,i)
	-- Get the value and stash it for later
	t[i] = GetSpellLink(i)
	return t[i]
	end
})

