--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

local folder = "GemCensus_Display"
local core = LibStub("AceAddon-3.0"):GetAddon("GemCensus")

local Debug = core.Debug
local LibStub = LibStub
local DISPLAY = DISPLAY
local HIDE = HIDE
local pairs = pairs
local TRADESKILLS = TRADESKILLS 
local tostring = tostring
local echo = core.echo

local display = core.display
local L = display.L

--~ print(folder.." loaded again!", display)

local mainOptions = core:GetModule("MainOptions")
local name = function(info) 
	local key = info[#info]
--~ 	return key
	return L[key.."Name"] and L[key.."Name"]:format(display.db.profile[key]) or key
end
local desc = function(info) 
	local key = info[#info]
--~ 	return key
	return L[key.."Desc"] and L[key.."Desc"]:format(display.db.profile[key]) or key
end
function display:UpdateOptionsTable()
	self.db = core.db:RegisterNamespace(folder, {
		profile = {

--~ 			columnHeight = 12,
			seenCount = 15,
			gemRarity = 3,
			gemLevel = 80,
			knownGems = 1,
			ignoreDragonEyes = true,
			ignoreNightmareTear = true,
			ignoreStormjewels = true,
			displayFrameLevel = 50,
			colourBlindCoins = false,
			
			
			haveRawGems = false,
			includeBankInv = true,
			includeAltRawGems = false,
			matCountdown = 0,
			
			ignoreInventoryGems = 0,
			includeInventoryGemsAlts = true,
			includeAuctionedGems = true,
			
			
			--auctioneer stuff
			filterByProfit = false,
			minProfitGold = 0,
			minProfitPercentage = 0,
			
			--New auction stuff.
			pricingAlgorithm = "",
			
			--ignore gems
--~ 			ignoreGems = {},
		},
	})

	
	
	local options = mainOptions.options
		

		
	options.args.display = {
		type = "group",
		name = DISPLAY,
		order = 3,
		
		get = function(info)
			local key = info[#info]
			return self.db.profile[key]
		end,
		set = function(info, v)
			local key = info[#info] 
			self.db.profile[key] = v
		end,

--~ 		disabled = function() return not core:IsEnabled() end,
	
		args = {
			showDisplay = {
				type = "execute",	order	= 2,
				name	= name, --L.showDisplayName,
				desc	= desc, --L.showDisplayDesc,
				func = function(info, v)
					self.MainFrame:Show()
				end,
			},

			seenCount = {
				type = "range",	order	= 10,
				name	= name, --"Show gems",
				desc	= desc, --L.seenCountDesc,
				min 	= 1,
				max 	= 100,
				step	= 1,
				width = "double",
			},
			
			gemRarity = {
				type = "range",	order	= 11,
				name	= name, --L.gemRarityName,
				desc	= desc, --L.gemRarityDesc,
				min 	= 0,
				max 	= 3,
				step	= 1,
			},
			
			gemLevel = {
				type = "range",	order	= 12,
				name	= name, --L.gemLevelName,
				desc	= desc, --L.gemLevelDesc,
				min 	= 60,
				max 	= 80,
				step	= 5,
			},

			colourBlindCoins = {
				type = "toggle",	order	= 14,
				name	= name, --L.ignoreStormjewelsName,
				desc	= desc, --L.ignoreStormjewelsDesc,
			},
			displayFrameLevel = {
				type = "range",	order	= 15,
				name	= name, --L.minProfitPercentageName,
				desc	= desc, --L.minProfitPercentageDesc,
				min 	= 0,
				max 	= 100,
				step	= 10,
				set = function(info, v)
					local key = info[#info] 
					self.db.profile[key] = v
					self:UpdateFrameLevel()
				end,
--~ 				disabled =  function() return not self.db.profile.filterByProfit end,
			},
			

			rawHeader1 = { --Raw
				type = "header",	order	= 18,
				name	= name,
			},
			
			haveRawGems = {
				type = "toggle",	order	= 19,
				name	= name, --L.haveRawGemsName,
				desc	= desc, --L.haveRawGemsDesc,
			},
			includeAltRawGems = {
				type = "toggle",	order	= 20,
				name	= L.includeAltsInventory, 
				desc	= desc, 
				disabled =  function() return not self.db.profile.haveRawGems end,
			},
			matCountdown = {
				type = "range",	order	= 21,
				name	= name, --L.matCountdownName,
				desc	= function(info) 
					local key = info[#info]
					return L.matCountdownDesc:format( self.db.profile[key] )
				end,
				min 	= 0,
				max 	= 20,
				step	= 1,
				disabled =  function() return not self.db.profile.haveRawGems end,
			},
			
			

			rawHeader2 = { --Cut
				type = "header",	order	= 29,
				name = name,
			},

			ignoreInventoryGems = {
				type = "range",	order	= 31,
				name	= name, --L.matCountdownName,
				desc	= desc,
				min 	= 0,
				max 	= 20,
				step	= 1,
--~ 				disabled =  function() return not self.db.profile.haveRawGems end,
			},

			includeInventoryGemsAlts = {
				type = "toggle",	order	= 32,
				name	= L.includeAltsInventory, 
				desc	= desc, 
				disabled =  function() return self.db.profile.ignoreInventoryGems == 0 end,
			},
			
			includeAuctionedGems = {
				type = "toggle",	order	= 33,
				name	= name, --L.matCountdownName,
				desc	= desc,
				disabled =  function() return self.db.profile.ignoreInventoryGems == 0 end,
			},
			ignoreDragonEyes = {
				type = "toggle",	order	= 34,
				name	= name, --L.ignoreDragonEyesName,
				desc	= desc, --L.ignoreDragonEyesDesc,
			},
			
			ignoreStormjewels = {
				type = "toggle",	order	= 35,
				name	= name, --L.ignoreStormjewelsName,
				desc	= desc, --L.ignoreStormjewelsDesc,
			},
			ignoreNightmareTear = {
				type = "toggle",	order	= 36,
				name	= name, --L.ignoreStormjewelsName,
				desc	= desc, --L.ignoreStormjewelsDesc,
			},
			
			rawHeader3 = {
				type = "header",	order	= 40,
				name	= "",
			},
			
			includeBankInv = {
				type = "toggle",	order	= 41,
				name	= name, --L.includeBankInvName,
				desc	= desc, --L.includeBankInvDesc,
				disabled =  function() return not self.db.profile.haveRawGems and self.db.profile.ignoreInventoryGems == 0 end,
			},

			
		}
	}

	LibStub("AceConfig-3.0"):RegisterOptionsTable(core.title, options ) --
end


function display:BuildPricingOptions()
	local options = mainOptions.options
	
	local algorithms, algorithmsIndex, defaultAlgorithmName = self:GetAlgorithms()
	
	local values = {}
	for name, index in pairs(algorithmsIndex) do 
		values[name] = name
	end
	
	if self.db.profile.pricingAlgorithm == "" then
		self.db.profile.pricingAlgorithm = defaultAlgorithmName
	end

	if not values[self.db.profile.pricingAlgorithm] then
		self.db.profile.prevAlgorithm = self.db.profile.pricingAlgorithm
		self.db.profile.pricingAlgorithm = defaultAlgorithmName
		Debug("BuildPricingOptions", tostring(self.db.profile.pricingAlgorithm).." not found. Changing to "..tostring(defaultAlgorithmName))
		
	elseif self.db.profile.prevAlgorithm and values[self.db.profile.prevAlgorithm] then
		self.db.profile.pricingAlgorithm = self.db.profile.prevAlgorithm
		Debug("BuildPricingOptions", "Price algorithm returning to "..tostring(self.db.profile.prevAlgorithm))
		self.db.profile.prevAlgorithm = nil
		
	elseif self.db.profile.pricingAlgorithm == "VendorValue" and defaultAlgorithmName ~= "VendorValue" then
--~ 		if not self.db.profile.prevAlgorithm then
			echo(L.changingPriceAlgorithm:format("VendorValue", tostring(defaultAlgorithmName)))
			self.db.profile.pricingAlgorithm = defaultAlgorithmName
--~ 		end
	end
	
	
	options.args.display.args.pricing = {
		type = "group",
		name = L.pricing,
		order = 1,
		args = {
--~ 			Desc = {
--~ 				type = "description",
--~ 				name = L.pricingDesc,
--~ 				order = 10,
--~ 			},
			
			pricingAlgorithm = {
				type = "select",	order	= 13,
				name	= name, --L.pricingAlgorithmName,
				desc	= desc, --L.pricingAlgorithmDesc,
				values = values,
				
				set = function(info, v)
					local key = info[#info] 
					self.db.profile[key] = v
					self:FlushPriceData()
				end,
				
			},
			
			filterByProfit = {
				type = "toggle",	order	= 24,
				name	= name,
				desc	= desc,
--~ 				disabled =  function() return self.db.profile.ignoreInventoryGems == 0 end,
			},
			
			minProfitGold = {
				type = "range",	order	= 25,
				name	= name, --L.minProfitGoldName,
				desc	= desc, --L.minProfitGoldDesc,
				min 	= 0,
				max 	= 100,
				step	= 5,
				disabled =  function() return not self.db.profile.filterByProfit end,
			},
			minProfitPercentage = {
				type = "range",	order	= 26,
				name	= name, --L.minProfitPercentageName,
				desc	= desc, --L.minProfitPercentageDesc,
				min 	= 100,
				max 	= 200,
				step	= 5,
				disabled =  function() return not self.db.profile.filterByProfit end,
			},

		},
	}
	
	LibStub("AceConfig-3.0"):RegisterOptionsTable(core.title, options ) --
end

function display:BuildTradeskillOptions()
	local options = mainOptions.options
	
	options.args.display.args.tradeskill = {
		type = "group",
		name = TRADESKILLS,
		order = 2,
		args = {
			knownGems = {
				type = "select",	order	= 2,
				name	= name, --L.knownGemsName,
				desc	= desc, --L.knownGemsDesc,
				
				values = function()
					return {[0]=L.only, [1]=L.include, [2]=HIDE}
				end,
			},

			rawHeader1 = { --Raw
				type = "header",	order	= 4,
				name	= "",
			},
		}
	}

	local i=10
	for name, inv in pairs(core.db.factionrealm.knownCuts) do 
		options.args.display.args.tradeskill.args[name] = {
			type = "toggle",	order	= i,
			name	= name,
--~ 			desc	= L.useCharTradeskills,
			desc	= function(info)
				local key = info[#info]
				return L.useCharTradeskills:format(key)
			end,
			get = function(info)
				local key = info[#info]
				local v = self.db.profile["DTS"..key]
				if v == nil then
					v = true
				end
--~ 				Debug("BuildTradeskillOptions","get", key, v)
				
				return v
			end,
			set = function(info, v)
				local key = info[#info] 
				self.db.profile["DTS"..key] = v
				self:ResetCanCutTable()
			end,
		}
		
		i = i + 1
	end
	
	
	LibStub("AceConfig-3.0"):RegisterOptionsTable(core.title, options ) --
end