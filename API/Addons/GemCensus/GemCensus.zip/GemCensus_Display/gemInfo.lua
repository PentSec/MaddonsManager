--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

local folder = "GemCensus_Display"
local core = LibStub("AceAddon-3.0"):GetAddon("GemCensus")
local display = core.display
local L = display.L

local iLink = core.iLink
local UIParent = UIParent
local TradeSkillFrameAvailableFilterCheckButton = TradeSkillFrameAvailableFilterCheckButton
local select = select
local GetTradeSkillInvSlots = GetTradeSkillInvSlots
local GetTradeSkillInvSlotFilter = GetTradeSkillInvSlotFilter
local GetTradeSkillSubClasses = GetTradeSkillSubClasses
local GetTradeSkillSubClassFilter = GetTradeSkillSubClassFilter
local TradeSkillOnlyShowMakeable = TradeSkillOnlyShowMakeable
local SetTradeSkillSubClassFilter = SetTradeSkillSubClassFilter
local SetTradeSkillInvSlotFilter = SetTradeSkillInvSlotFilter
local GetFirstTradeSkill = GetFirstTradeSkill
local GetNumTradeSkills = GetNumTradeSkills
local GetTradeSkillInfo = GetTradeSkillInfo
local ExpandTradeSkillSubClass = ExpandTradeSkillSubClass
local GetTradeSkillItemLink = GetTradeSkillItemLink
local DoTradeSkill = DoTradeSkill
local GetNumFactions = GetNumFactions
local CollapseTradeSkillSubClass = CollapseTradeSkillSubClass
local ipairs = ipairs
local setmetatable = setmetatable
local getmetatable = getmetatable


local GetTradeSkillLine = GetTradeSkillLine
local echo = core.echo
local iID = core.iID
local Debug = core.Debug


--locale name
local Jewelcrafting = GetSpellInfo(25229) --Jewelcrafting

local LPT = LibStub("LibPeriodicTable-3.1")
if not LPT then
	error(folder .. " requires LibPeriodicTable-3.1") 
	return
end

display.LPT = LPT

local GetItemInfo = GetItemInfo
local pairs = pairs

local noRawGems = {
--~ 	[44087] = true,
--~ 	[33133] = true,
}

local rawGemNames = {}
display.cutToRaw = setmetatable({}, {
	__index = function(t,cutID)
--~ 	if noRawGems[cutID] then
--~ 		t[cutID] = 16893 --soulstone
--~ 		return t[cutID]
--~ 	end
	local cutName = GetItemInfo(cutID)
	if not cutName then
--~ 		Debug("cutToRaw Can't get ItemInfo", cutID, cutName)
		display:RequestInfoFromServer(cutID)
	end	
	if cutName then
		for rawID, rawName in pairs(rawGemNames) do 
			if cutName:find(rawName) then
				t[cutID] = rawID
				return t[cutID]
			end
		end
	end
	t[cutID] = false
	return t[cutID]
	end
})

function display:GetRawGems()--		/run _GCGem:GetRawGems()
	local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount,itemEquipLoc, itemTexture, itemSellPrice
	for item, value, set in LPT:IterateSet("Tradeskill.Mat.ByProfession.Jewelcrafting") do
		itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount,itemEquipLoc, itemTexture, itemSellPrice = GetItemInfo(item)
		if itemType == L.gem then
			rawGemNames[item] = itemName
		end
	end
end

local tooltip = CreateFrame("GameTooltip", folder.."ToolTip", UIParent, "GameTooltipTemplate")
local tooltipStats = _G[tooltip:GetName().."TextLeft2"]
tooltip:SetOwner(UIParent, "ANCHOR_NONE")

--Cache gem stats to a table. eg "+23 Spell Power"
display.gemStats = setmetatable({}, {
	__index = function(t,itemID)
		t[itemID] = "*"
		
		local gemLink = itemID and iLink[itemID]
		if gemLink then
			tooltip:SetOwner(UIParent, "ANCHOR_NONE")
			tooltip:ClearLines()
			tooltip:SetHyperlink(gemLink)
			
			local text = tooltipStats:GetText()
			if text and text:trim() ~= "" then
				t[itemID] = tooltipStats:GetText()
			end
		end
		return t[itemID]
	end
})

do 
	local items = {}

	local f = CreateFrame("Frame")
	f:Hide()
	f.nextUpdate = 0

	local RETRIEVING_ITEM_INFO = RETRIEVING_ITEM_INFO
	local _G = _G
	local table_remove = table.remove
	local tostring = tostring
	local table_insert = table.insert
	local tonumber = tonumber
	
	local tt = CreateFrame("GameTooltip", folder.."ToolTip2", UIParent, "GameTooltipTemplate")
	local ttText1 = _G[tt:GetName().."TextLeft1"]
	
	local itemID
	local name, link
	tt:HookScript("OnTooltipSetItem", function(this) 
		if ttText1:GetText() == RETRIEVING_ITEM_INFO then
			this:Show() --OnTooltipSetItem will only fire a 2nd time if the frame's shown.
--~ 			Debug("OnTooltipSetItem A", this:GetItem())
		else
			name, link = this:GetItem()
			itemID = tonumber(link:match("item:(%d+)"))

			
--~ 			Debug("OnTooltipSetItem B", name, link, itemID)
			
			for i=1, #items do 
				if items[i] == itemID then
					Debug("OnTooltipSetItem C", "Removing info on "..tostring(itemID), link, #items.." left.")
					f.nextUpdate = 0
					table_remove(items, i)
--~ 					f:Hide() --stop the timer
					this:Hide()
				end
			end
		end
	end)


	
	local throttle = 15 --15 second timeout if the server fails to return info.
	f:SetScript("OnUpdate", function(this, elapsed) 
		this.nextUpdate = this.nextUpdate - elapsed
		if this.nextUpdate < 0 then
			this.nextUpdate = throttle
			if #items > 0 then
				Debug("OnUpdate", "Requesting info on "..items[1]..".")
				tt:ClearLines()
				tt:Hide()
--~ 				tt:Show()
				tt:SetOwner(UIParent, "ANCHOR_NONE")
				tt:SetHyperlink(("item:%s:0:0:0:0:0:0:0"):format(items[1]))
				
			else
--~ 				Debug("OnUpdate","Finshed requesting itemLinks from server.")
				echo(L.finshedRequestingInfo)
				this:Hide()
			end
		end
	end)
	
	-------------------------------------------------------
	local p = CreateFrame("Frame")
	p:Hide()
	p:SetScript("OnUpdate", function(this, elapsed)
		this.nextUpdate = this.nextUpdate - elapsed
		if this.nextUpdate < 0 then
			echo(L.requestingInfoFromServer:format(#items))
			f:Show()
			this:Hide()
		end
	end)
	p:SetScript("OnShow",function(this) 
		this.nextUpdate = 0.5
	end)
	
	function display:RequestInfoFromServer(itemID)
		for i=1, #items do 
			if items[i] == itemID then
				return
			end
		end
		table_insert(items, #items+1, itemID)
		Debug("RequestInfoFromServer", itemID)
		p:Show()
	end
	
end

function display:CraftItem(itemID, times)
--~ 	local skillName, skillType, numAvailable, isExpanded, itemLink
	
	if GetTradeSkillLine() ~= Jewelcrafting then
		echo(L.openJCwindow)
		return
	end
	
	local times = times or 1
	
	local collapsedHeaders, showMakeable, subClass, invSlot, search = core:ResetTradeskillFrame()

	local cID, skillName, skillType, numAvailable, isExpanded, itemLink
	for i = GetFirstTradeSkill(), GetNumTradeSkills()  do --count
		skillName, skillType, numAvailable, isExpanded = GetTradeSkillInfo(i);
		if ( skillType ~= "header" ) then
			itemLink = GetTradeSkillItemLink(i)
			if itemLink then
				cID = iID[itemLink]
				if cID == itemID then
--~ 					Debug("CraftItem", "tID:"..i, itemLink.."x"..times)
					
					echo(L.craftingGems:format(itemLink, times))
					DoTradeSkill(i, times)
					break
				end
			end
		end
	end

	core:RestoreTradeskillFrame(collapsedHeaders, showMakeable, subClass, invSlot, search)
end

local prev_OnEnable = display.OnEnable
function display:OnEnable()
	if prev_OnEnable then
		prev_OnEnable(self)
	end

	self:BuildTradeskillOptions()
end

display.canCutGem = setmetatable({}, {
	__index = function(t,i)
	t[i] = display:CanCutGem(i)
--~ 	Debug("canCutGem", iLink[i], t[i])
	return t[i]
	end
})


function display:CanCutGem(itemID)
	for who, gems in pairs(core.db.factionrealm.knownCuts) do 
--~ 		Debug("CanCutGem", iLink[itemID], who, self.db.profile["DTS"..who] ~= false)
		if self.db.profile["DTS"..who] ~= false then --Sometimes this returns nil if we haven't 'set' a value to it. So lets just do a NOT false check.
			for i, gemID in ipairs(gems) do 
				if itemID == gemID then
					return who
				end
			end
		end
	end
	return false
end

function display:ResetCanCutTable()
	self.canCutGem	= setmetatable({}, getmetatable(self.canCutGem))
end