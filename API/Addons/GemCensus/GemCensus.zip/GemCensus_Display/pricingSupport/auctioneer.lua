--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

--[[
	Pricing system stolen from LilSparky's Workshop.
	http://www.wowace.com/addons/lil-sparkys-workshop/
]]

local folder = "GemCensus_Display"
local core = LibStub("AceAddon-3.0"):GetAddon("GemCensus")
local display = core.display

local ipairs = ipairs
local _G = _G
local GetAddOnInfo = GetAddOnInfo
local EnableAddOn = EnableAddOn

-- auctioneer support

do
	local noBuyout = 100 * 100 * 100 --100g
	local function AuctionPriceMinBuyout(link)
		if not link then
			return nil
		end

		local imgSeen, image, matchBid, matchBuy, lowBid, lowBuy, aveBuy, aSeen = _G.AucAdvanced.Modules.Util.SimpleAuction.Private.GetItems(link)

		if imgSeen <= 0 then
			local market = _G.AucAdvanced.API.GetMarketValue(link) or noBuyout
			
			return market * 2, 0
		end

		return lowBuy, imgSeen
	end

	--[[
	local function BestMatch(itemID)
		if not itemID then
			return nil
		end
		return _G.AucAdvanced.API.GetBestMatch(itemID, "market") or 0
	end
	]]

	local function Init()
		display:RegisterAlgorithm("Auctioneer Market", _G.AucAdvanced.API.GetMarketValue)



		local engines = _G.AucAdvanced.GetAllModules(nil, "Stat")

		for pos, engineLib in ipairs(engines) do
			local name = engineLib.GetName()

			display:RegisterAlgorithm("Auctioneer "..name, function(link)
				return _G.AucAdvanced.API.GetAlgorithmValue(name, link)
			end)
		end

		if _G.AucAdvanced.Modules.Util.SimpleAuction then
			display:RegisterAlgorithm("Auctioneer Min Buyout", AuctionPriceMinBuyout)
		end
		
		if _G.AucAdvanced.Modules.Util.Appraiser then
			-- Auc-ScanData gets loaded when GetPrice is called, but not if the checkbox is disabled. Lets just make sure the checkbox is enabled. :)
			local scanData = "Auc-ScanData"
			local _, _, _, enabled = GetAddOnInfo(scanData)
			if not enabled then
				EnableAddOn(scanData)
			end
		
			display:RegisterAlgorithm("Auctioneer Appraiser", _G.AucAdvanced.Modules.Util.Appraiser.GetPrice)
--~ 			display:RegisterAlgorithm("Auctioneer Appraiser", function() return 0 end) --testing
		end
		
		--[[
		if _G.AucAdvanced.API.GetBestMatch then
			display:RegisterAlgorithm("Auctioneer BestMatch", BestMatch)
		end
		]]
		
		local lib,parent,private = _G.AucAdvanced.NewModule("Util", "GCPriceRescan")
		function lib.Processor(callbackType)
			if (callbackType == "scanstats") then
				display:FlushPriceData()
			end
		end
	end


	local function Test(index)
		if _G.AucAdvanced and _G.AucAdvanced.Version then
			return true
		end

		return false
	end

	display:RegisterPricingSupport("Auctioneer", Test, Init)
	
end
