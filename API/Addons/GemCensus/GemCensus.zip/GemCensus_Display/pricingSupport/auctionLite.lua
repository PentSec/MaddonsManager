--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

--[[
	Pricing system stolen from LilSparky's Workshop.
	http://www.wowace.com/addons/lil-sparkys-workshop/
]]

local folder = "GemCensus_Display"
local core = LibStub("AceAddon-3.0"):GetAddon("GemCensus")
local display = core.display

local _G = _G
local math_floor = math.floor

-- AuctionLite support

do

	local function AuctionPrice(itemID) -- AuctionLite version
		if not itemID then
			return nil
		end

		local hist = _G.AuctionLite:GetHistoricalPriceById(itemID, 0)

		local price, count

		if hist then
			price, count = math_floor(hist.price), math_floor(hist.items)
		end

		return price, count
--		return AuctionLite:GetAuctionValue(itemID)
	end

	local function OnScanComplete()
		display:FlushPriceData()
	end

	local function Init()
		display:RegisterAlgorithm("AuctionLite", AuctionPrice)
--		TODO: figure out when to flush the auction data
	end


	local function Test(index)
		if _G.AuctionLite then
			return true
		end

		return false
	end

	display:RegisterPricingSupport("AuctionLite", Test, Init)
end

