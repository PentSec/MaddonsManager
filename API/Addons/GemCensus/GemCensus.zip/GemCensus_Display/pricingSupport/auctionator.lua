--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

--[[
	Pricing system stolen from LilSparky's Workshop.
	http://www.wowace.com/addons/lil-sparkys-workshop/
]]

local folder = "GemCensus_Display"
local core = LibStub("AceAddon-3.0"):GetAddon("GemCensus")
local display = core.display

local ipairs = ipairs
local _G = _G

do

	local function AuctionPrice(itemID)
		return _G.Atr_GetAuctionBuyout(itemID)
	end


	local function Init()
		display:RegisterAlgorithm("Auctionator", AuctionPrice)
	end


	local function Test(index)
		if _G.Atr_GetAuctionBuyout then
			return true
		end

		return false
	end

	display:RegisterPricingSupport("Auctionator", Test, Init)
end
