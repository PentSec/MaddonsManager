--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

--[[
	Pricing system stolen from LilSparky's Workshop.
	http://www.wowace.com/addons/lil-sparkys-workshop/
]]

local folder = "GemCensus_Display"
local core = LibStub("AceAddon-3.0"):GetAddon("GemCensus")
local display = core.display

local GetItemInfo = GetItemInfo

do

	local function VendorValue(itemID)
		local _, _, _, _, _, _, _, _, _, _, vendorPrice = GetItemInfo(itemID)
		return vendorPrice
	end
	display.vendorValue = VendorValue

	local function Init()
		display:RegisterAlgorithm("VendorValue", VendorValue)
	end


	local function Test()
		if GetItemInfo then
			return true
		end

		return false
	end

	display:RegisterPricingSupport("VendorPrice", Test, Init)
end