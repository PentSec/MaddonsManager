--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

--[[
	Pricing system stolen from LilSparky's Workshop.
	http://www.wowace.com/addons/lil-sparkys-workshop/
]]

local folder = "GemCensus_Display"
local core = LibStub("AceAddon-3.0"):GetAddon("GemCensus")
local display = core.display
local L = display.L

local pairs = pairs
local GetItemInfo = GetItemInfo


do
	local cacheName = L.prevPriceAlgorithm --"Previous login price"
	local vendorName = "VendorValue"
	
	local function tableCount(tbl)
		local count = 0
		for a, b in pairs(tbl) do 
			count = count + 1
		end
		return count
	end	
	
	local function VendorValue(itemID)
		local _, _, _, _, _, _, _, _, _, _, vendorPrice = GetItemInfo(itemID)
		return vendorPrice
	end
	
	local f = CreateFrame("Frame")
	f:SetScript("OnEvent", function(this, event, ...)
		if event == "PLAYER_LOGOUT" then
			if core.db.profile.pricingAlgorithm ~= cacheName then
				if tableCount(display.auctionPrice) > 0 then
					core.db.factionrealm.cachedPrices = nil

					for itemID, price in pairs(display.auctionPrice) do 
						if price ~= VendorValue(itemID) then
							core.db.factionrealm.cachedPrices = core.db.factionrealm.cachedPrices or {}
							core.db.factionrealm.cachedPrices[itemID] = price
						end
					end
				end
			end
		end
	end)
	f:RegisterEvent("PLAYER_LOGOUT")
	
	local function getCachedPrice(itemID)
		if not itemID then
			return nil
		end
	
		return core.db.factionrealm.cachedPrices and core.db.factionrealm.cachedPrices[itemID] or nil
	end
	
	local function Init()
		display:RegisterAlgorithm(cacheName, getCachedPrice)
	end

	
	local function Test(index)
		if core.db.factionrealm.cachedPrices then
			return true
		end

		return false
	end
	
	display:RegisterPricingSupport("Cached Price", Test, Init)
end