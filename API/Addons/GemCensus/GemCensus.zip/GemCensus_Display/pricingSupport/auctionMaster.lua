--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

--[[
	Pricing system stolen from LilSparky's Workshop.
	http://www.wowace.com/addons/lil-sparkys-workshop/
]]

local folder = "GemCensus_Display"
local core = LibStub("AceAddon-3.0"):GetAddon("GemCensus")
local display = core.display

local _G = _G
local GetItemInfo = GetItemInfo
local IsAddOnLoaded = IsAddOnLoaded

do
	local auctionMasterSupport = {}

	auctionMasterSupport.isNeutral = false

	local function scanUpdated()
		display:FlushPriceData()
	end

	local function GetItemLink(itemID)
		if itemID then
			local _,link = GetItemInfo(itemID)
			return link
		end

		return nil
	end


	local function AuctionPrice(itemID)
		local link = GetItemLink(itemID)

		if not link then
			return nil
		end

--		local _, sellPrice = AuctionMaster.Statistic:GetAuctionInfo(link, auctionMasterSupport.isNeutral)

		local avgBid, avgBuy, numBid, numBuy = _G.AucMasGetAuctionInfo(link, auctionMasterSupport.isNeutral)

		return avgBuy or 0, numBuy or 0
	end



	local function AuctionPriceCurrent(itemID)
		local link = GetItemLink(itemID)

		if not link then
			return nil
		end

		local avgBid, avgBuy, minBid, minBuy, maxBid, maxBuy, numBid, numBuy = _G.AucMasGetCurrentAuctionInfo(link, auctionMasterSupport.isNeutral, auctionMasterSupport.adjustPrices)

		return avgBuy or 0, numBuy or 0
	end


	local function AuctionPriceMinBuyout(itemID)
		local link = GetItemLink(itemID)

		if not link then
			return nil
		end

		local avgBid, avgBuy, minBid, minBuy, maxBid, maxBuy, numBid, numBuy = _G.AucMasGetCurrentAuctionInfo(link, auctionMasterSupport.isNeutral, auctionMasterSupport.adjustPrices)

		return minBuy or 0, numBuy or 0
	end

	local function Init()
		_G.AucMasRegisterStatisticCallback(scanUpdated)

		display:RegisterAlgorithm("AuctionMaster Historical", AuctionPrice)
		display:RegisterAlgorithm("AuctionMaster Current", AuctionPriceCurrent)
		display:RegisterAlgorithm("AuctionMaster Min Buyout", AuctionPriceMinBuyout)
	end


	local function Test(index)
		if IsAddOnLoaded("AuctionMaster") and (_G.AucMasStatisticVersion and _G.AucMasStatisticVersion.major==1) then
			return true
		end

		return false
	end

	display:RegisterPricingSupport("AuctionMaster", Test, Init)
end

