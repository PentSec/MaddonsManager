--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

--[[
	Pricing system stolen from LilSparky's Workshop.
	http://www.wowace.com/addons/lil-sparkys-workshop/
]]

local folder = "GemCensus_Display"
local core = LibStub("AceAddon-3.0"):GetAddon("GemCensus")
local display = core.display

local _G = _G

local iLink = core.iLink
local getmetatable = getmetatable
local setmetatable = setmetatable
local Debug = core.Debug
local Round = core.Round
local tonumber = tonumber
local math_floor = math.floor
local COPPER_AMOUNT_SYMBOL = COPPER_AMOUNT_SYMBOL
local GOLD_AMOUNT_SYMBOL = GOLD_AMOUNT_SYMBOL
local SILVER_AMOUNT_SYMBOL = SILVER_AMOUNT_SYMBOL
local pairs = pairs


local table_insert = table.insert
local pricingSupportList = {}
local algorithms = {}
local algorithmsIndex = {}
local defaultAlgorithm
local defaultAlgorithmName

local prev_OnEnable = display.OnEnable
function display:OnEnable()
	if prev_OnEnable then
		prev_OnEnable(self)
	end

	self:FlushPriceData()
	self:BuildPricingOptions()
end

local prev_OnInitialize = display.OnInitialize
function display:OnInitialize()
	if prev_OnInitialize then
		prev_OnInitialize(self)
	end
	

	for _, value in pairs(pricingSupportList) do 
		if value.Test() then
			value.Init()
		end
	end
end



function display:GetAlgorithms()
	return algorithms, algorithmsIndex, defaultAlgorithmName
end

function display:RegisterAlgorithm(name, func)
--~ 	Debug("RegisterAlgorithm", name, func)
	
	
	if name and func then

		local a = {}
		a.name = name
		a.func = func

		local i = algorithmsIndex[name]

		if i then
			algorithms[i] = a
		else
			table_insert(algorithms, a)

			algorithmsIndex[name] = #algorithms
		end

		if not defaultAlgorithm then
			defaultAlgorithm = a
			defaultAlgorithmName = name
		end

		return a
	end
end

function display:FlushPriceData()
	self.auctionPrice 			= setmetatable({}, getmetatable(self.auctionPrice))
end

function display:RegisterPricingSupport(addonName, test, init)
--~ 	Debug("RegisterPricingSupport", addonName, test, init)
	
	local t = {}

	t.name = addonName
	t.Test = test
	t.Init = init

	table_insert(pricingSupportList, t)

--~ 	if test() then
--~ 		init()
--~ 	end
end

function display:GetAlgorithmFunction(name)
	if name then
		local index = algorithmsIndex[name]
		if index then
			return algorithms[index].func, algorithms[index].name
		end
	end

	if defaultAlgorithm then
		return defaultAlgorithm.func, defaultAlgorithm.name
	else
		return function () return 0 end, "no auction support"
	end
end

--[[
function display:CanGetPrices()
	return _G.AucAdvanced and true or false
end]]

function display:CanGetPrices()
	return defaultAlgorithm and true or false
end


--~ --40126 thick king's amber
--~ function dTest(itemID)--	/run dTest(40126)
--~ 	local auctionCost, costName = display:GetAlgorithmFunction(display.db.profile.pricingAlgorithm)
--~ 	
--~ 	Debug("dTest", iLink[itemID], core.db.profile.pricingAlgorithm, costName, auctionCost and auctionCost(itemID))
--~ end

--Cache prices in a metatable to reduce CPU usage. It'll get reset when addon's reset or when a auction tells us to flush our data.
display.auctionPrice = setmetatable({}, {
	__index = function(t,itemID)
--~ 		t[itemID] = display:GetAuctionValue(itemID, true)
		local auctionFunc, costName = display:GetAlgorithmFunction(display.db.profile.pricingAlgorithm)
		local value = auctionFunc(itemID) or 0
		if value == 0 then
			value = display.vendorValue(itemID)
		end
		t[itemID] = Round(value)

--~ 		Debug("auctionPrice", itemID and iLink[itemID], t[itemID])
		
		return t[itemID]
	end
})

function display.vendorValue() return 0 end

local iconpath = "Interface\\MoneyFrame\\UI-"
function display:CopperToCoins(copper)
--~ 	Debug("CopperToCoins A", copper, g, s, c)
	copper = tonumber(copper or 0)
	local g = math_floor(copper / 10000)
	local s = math_floor(copper % 10000 / 100)
	local c = copper % 100

--~ 	Debug("CopperToCoins B", copper, g, s, c)
	
	local text = "";
	if self.db.profile.colourBlindCoins == true then
		if g ==0 and s ==0 then
			text = text.."|cFFFF6600" .. c .. COPPER_AMOUNT_SYMBOL.. "|r"
		else
			if g > 0 then
				text = text.."|cFFFFFF00" .. g .. GOLD_AMOUNT_SYMBOL .. "|r"
			end
			if s > 0 then
				text = text.."|cFFCCCCCC" .. s .. SILVER_AMOUNT_SYMBOL .."|r"
			end
			if c > 0 then
				text = text.."|cFFFF6600" .. c .. COPPER_AMOUNT_SYMBOL .. "|r"
			end
		end
		
	else
		if g ==0 and s ==0 then
			text = text.."|cFFFF6600" .. c .. "|r|T"..iconpath.."CopperIcon:0|t"
		else
			if g > 0 then
				text = text.."|cFFFFFF00" .. g .. "|r|T"..iconpath.."GoldIcon:0|t"
			end
			if s > 0 then
				text = text.."|cFFCCCCCC" .. s .. "|r|T"..iconpath.."SilverIcon:0|t"
			end
			if c > 0 then
				text = text.."|cFFFF6600" .. c .. "|r|T"..iconpath.."CopperIcon:0|t"
			end
		end
	end
	return text;
end
--~ 