--[[
	GemCensus: A gem popularity addon.
	Copyright (c) 2010 Cyprias <Cyprias@gmail.com>
	All Rights Reserved.
	Only Curse.com, WoWInterface.com & WoWace.com have permission to redistribute this software. 
	GemCensus shall not be included in a UI pack / compilation without permission. 
]]

--~ local folder, display = ...
local folder = "GemCensus_Display"
local core = LibStub("AceAddon-3.0"):GetAddon("GemCensus")

local _G = _G
local UIParent = UIParent
local CreateFrame = CreateFrame
local Debug = core.Debug
local LibStub = LibStub
local pairs = pairs
local table_insert = table.insert
local table_sort = table.sort
local iName = core.iName
local pcall = pcall
local print = print
local GetItemInfo = GetItemInfo
local unpack = unpack
local GetItemQualityColor = GetItemQualityColor
local Round = core.Round
local _
local math_floor = math.floor
local tonumber = tonumber
local iLink = core.iLink
local GameTooltip = GameTooltip
local IsShiftKeyDown = IsShiftKeyDown
local echo = core.echo
local IsAddOnLoaded = IsAddOnLoaded
local setmetatable = setmetatable
local getmetatable = getmetatable
local TUTORIAL_TITLE19 = TUTORIAL_TITLE19 --"Players"
local REFRESH = REFRESH
local GAMEOPTIONS_MENU = GAMEOPTIONS_MENU
local KEY_NUMLOCK_MAC = KEY_NUMLOCK_MAC
local SEARCH = SEARCH 
local UnitName = UnitName
local SPELL_FAILED_REAGENTS = SPELL_FAILED_REAGENTS
local UIDropDownMenu_AddButton = UIDropDownMenu_AddButton
local wipe = wipe
local CLOSE = CLOSE
local CloseDropDownMenus = CloseDropDownMenus
local ToggleDropDownMenu = ToggleDropDownMenu
local CREATE = CREATE
local tostring = tostring

--~ 
local display = core:NewModule(folder, "AceEvent-3.0")
display.core = core
core.display = display
--~ local L = core.L
display.L = LibStub("AceLocale-3.0"):GetLocale(folder, true)
local L = display.L

_, _, _, _, _, _, _, _, _, L.gem = GetAuctionItemClasses() --"Gem" for display and GetItemInfo()'s itemClass

--~ print(folder.." loaded!", display)

local LST = LibStub("ScrollingTable")
display.LST = LST

local columnHeight = 14

local selectedRows = {}
local highlightOff = { ["r"] = 0.0, ["g"] = 0.0, ["b"] = 0.0, ["a"] = 0.0 }
local highlightSelected = { ["r"] = 0.5, ["g"] = 0.5, ["b"] = 0.5, ["a"] = 0.5 }
local highlightSelectedMouseOver = { ["r"] = 1, ["g"] = 1, ["b"] = 0.5, ["a"] = 0.5 }

local nightmareTear = 49110
local dragonsEye = GetItemInfo(42225)
local stormJewels = {
	[45862] = true, --Bold Stormjewel
	[45882] = true,-- Brilliant Stormjewel
	[45879] = true,-- Delicate Stormjewel
	[45987] = true,-- Rigid Stormjewel
	[45883] = true,-- Runed Stormjewel
	[45880] = true,-- Solid Stormjewel
	[45881] = true,-- Sparkling Stormjewel
--~ 	[] = true,--

}

function display:OnInitialize()
	self:UpdateOptionsTable()
	self:CreateDisplayFrame()
	
	self:GetRawGems()
	
--~ 	Debug("OnInitialize","A")
end

local prev_OnEnable = display.OnEnable
function display:OnEnable()
	if prev_OnEnable then
		prev_OnEnable(self)
	end
	
	self:ResetCanCutTable()
end


local CompareSortSeen = function (self, rowa, rowb, sortbycol)
	local cella, cellb = self.data[rowa].cols[sortbycol], self.data[rowb].cols[sortbycol];
	local column = self.cols[sortbycol];
	local aGem, aCount = unpack(cella.args)
	local bGem, bCount = unpack(cellb.args)
	
	aGem = iName[aGem]
	bGem = iName[bGem]
	
	if column.sort == "dsc" then
		if aCount == bCount then
			return aGem < bGem
		else
			return aCount > bCount
		end
	else
		if aCount == bCount then
			return aGem < bGem
		else
			return aCount < bCount
		end
	end
end

local CompareSortMoney = function (self, rowa, rowb, sortbycol)
	local cella, cellb = self.data[rowa].cols[sortbycol], self.data[rowb].cols[sortbycol];
	local column = self.cols[sortbycol];
	local aMoney, aGem = unpack(cella.args)
	local bMoney, bGem = unpack(cellb.args)
	
	aGem = aGem and iName[aGem] or "x"
	bGem = bGem and iName[bGem] or "x"
	
	if column.sort == "dsc" then
		if aMoney == bMoney then
			return aGem < bGem
		else
			return aMoney > bMoney
		end
	else
		if aMoney == bMoney then
			return aGem < bGem
		else
			return aMoney < bMoney
		end
	end
end

local bgcolor = {r=1,g=1,b=1, a=0.02} --
display.columnHeaders = {
	{ name= L.gem, width = 160, defaultsort = "dsc", bgcolor = bgcolor},
	{ name= L.seen, width = 70, defaultsort = "dsc", comparesort = CompareSortSeen},
	{ name= TUTORIAL_TITLE19, width = 60, defaultsort = "dsc", comparesort = CompareSortSeen, bgcolor = bgcolor,},
	{ name= L.rawPrice, width = 80, defaultsort = "dsc", comparesort = CompareSortMoney},
	{ name= L.cutPrice, width = 80, defaultsort = "dsc", comparesort = CompareSortMoney, bgcolor = bgcolor,},
	{ name= L.profit, width = 80, defaultsort = "dsc", comparesort = CompareSortMoney },
	{ name= "%", width = 50, defaultsort = "dsc", comparesort = CompareSortMoney, bgcolor = bgcolor,},
};

--~ local displayWidth = 665
local displayWidth = 15

for i, value in ipairs(display.columnHeaders) do 
	displayWidth = displayWidth + value.width
end

-- Adds resizing to a window. Resizing is both width and height from the
-- lower right corner only
function display:EnableResize(frame, min_width, min_height, refresh_method)--Stolen from Skillet. shhhhh
    -- lets play the resize me game!
--~ 	frame.refresh_method = refresh_method

    local sizer_se = CreateFrame("Frame", nil, frame) --frame:GetName() .. "_SizerSoutheast"
    sizer_se:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",0,0)
    sizer_se:SetWidth(25)
    sizer_se:SetHeight(25)
    sizer_se:EnableMouse()
    sizer_se:SetScript("OnMouseDown", function(this)
        this:GetParent():StartSizing("BOTTOMRIGHT")
    end)
    sizer_se:SetScript("OnMouseUp", function(this)
        this:GetParent():StopMovingOrSizing()
        -- 'Skillet' is passed for the hidden 'self' variable
        pcall(refresh_method, display)
    end)
    frame:SetScript("OnSizeChanged", function()
        -- 'Skillet' is passed for the hidden 'self' variable
        pcall(refresh_method, display)
    end)

    -- Stole this from LibRockConfig (ya ckkinght!). Draws 3 diagonal lines in the
    -- lower right corner of the window
    local line1 = sizer_se:CreateTexture("_Line1", "BACKGROUND")--sizer_se:GetName() .. 
    line1:SetWidth(14)
    line1:SetHeight(14)
    line1:SetPoint("BOTTOMRIGHT", -4, 4)
    line1:SetTexture("Interface\\Tooltips\\UI-Tooltip-Border")
    local x = 0.1 * 14/17
    line1:SetTexCoord(1/32 - x, 0.5, 1/32, 0.5 + x, 1/32, 0.5 - x, 1/32 + x, 0.5)

    local line2 = sizer_se:CreateTexture("_Line2", "BACKGROUND")
    line2:SetWidth(11)
    line2:SetHeight(11)
    line2:SetPoint("BOTTOMRIGHT", -4, 4)
    line2:SetTexture("Interface\\Tooltips\\UI-Tooltip-Border")
    local x = 0.1 * 11/17
    line2:SetTexCoord(1/32 - x, 0.5, 1/32, 0.5 + x, 1/32, 0.5 - x, 1/32 + x, 0.5)

    local line3 = sizer_se:CreateTexture("_Line3", "BACKGROUND")
    line3:SetWidth(8)
    line3:SetHeight(8)
    line3:SetPoint("BOTTOMRIGHT", -4, 4)
    line3:SetTexture("Interface\\Tooltips\\UI-Tooltip-Border")
    local x = 0.1 * 8/17
    line3:SetTexCoord(1/32 - x, 0.5, 1/32, 0.5 + x, 1/32, 0.5 - x, 1/32 + x, 0.5)
end

function display:UpdateFrameLevel(this)
	local frame = this or self.MainFrame
	frame:SetFrameLevel( self.db.profile.displayFrameLevel )
end

function display:CreateDisplayFrame()
	self.MainFrame = CreateFrame("Frame",nil, UIParent)
	self.MainFrame:Hide()

	self.MainFrame:SetScript("OnShow", function(this) 
		self:RegisterEvent("BAG_UPDATE")
	end)
	self.MainFrame:SetScript("OnHide", function(this) 
		self:UnregisterEvent("BAG_UPDATE")
	end)
	
	local frame = self.MainFrame
	frame:SetPoint("CENTER", UIParent)
	
	frame:EnableMouse(true)
	frame:SetMovable(true) 
	frame:SetResizable(true)
	
	--~ frame:SetToplevel(true)
	--~ frame:RegisterForDrag("LeftButton")
	
	frame:SetScript("OnMouseDown", frame.StartMoving)
	frame:SetScript("OnMouseUp", frame.StopMovingOrSizing)
	
	
	frame:SetWidth(displayWidth)
	frame:SetHeight(311)
	
	local FrameBackdrop = {
		bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
		edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
		tile = true, tileSize = 16, edgeSize = 16,
		insets = { left = 3, right = 3, top = 30, bottom = 3 }
	}
	
	frame:SetBackdrop(FrameBackdrop);
	frame:SetBackdropColor(0.1, 0.1, 0.1)
	
	-- A title bar stolen from the Ace2 Waterfall window.
	local r,g,b = 0, .8, .8; 
--~ 	local r,g,b = math.random(0, 100) / 100, math.random(0, 100) / 100, math.random(0, 100) / 100; 

	frame.titlebar = frame:CreateTexture(nil,"BACKGROUND")
	frame.titlebar2 = frame:CreateTexture(nil,"BACKGROUND")
	
	frame.titlebar:SetPoint("TOPLEFT",frame,"TOPLEFT",3,-4)
	frame.titlebar:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-3,-4)
	frame.titlebar:SetHeight(13)
	
	frame.titlebar2:SetPoint("TOPLEFT",frame.titlebar,"BOTTOMLEFT",0,0)
	frame.titlebar2:SetPoint("TOPRIGHT",frame.titlebar,"BOTTOMRIGHT",0,0)
	frame.titlebar2:SetHeight(13)
	
	frame.titlebar:SetGradientAlpha("VERTICAL",r*0.6,g*0.6,b*0.6,1,r,g,b,1)
	frame.titlebar:SetTexture(r,g,b,1)
	frame.titlebar2:SetGradientAlpha("VERTICAL",r*0.9,g*0.9,b*0.9,1,r*0.6,g*0.6,b*0.6,1)
	frame.titlebar2:SetTexture(r,g,b,1)
		
	local title = CreateFrame("Frame",nil,frame)
	title:SetPoint("TOPLEFT",frame.titlebar,"TOPLEFT",0,0)
	title:SetPoint("BOTTOMRIGHT",frame.titlebar2,"BOTTOMRIGHT",0,0)
	
	local titletext = title:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	titletext:SetPoint("TOPLEFT",title,"TOPLEFT",0,0)
	titletext:SetPoint("TOPRIGHT",title,"TOPRIGHT",0,0)
	titletext:SetHeight(26)
	titletext:SetShadowColor(0,0,0)
	titletext:SetShadowOffset(1,-1)
	titletext:SetTextColor(1,1,1)
	titletext:SetText(core.title); --core.titleFull
	
	frame.closeBtn = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
	local closeBtn = frame.closeBtn
	closeBtn:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -3, -3)
	closeBtn:SetScript("OnClick", function(this, ...)
		this:GetParent():Hide()
	end)
	
	frame:SetMinResize(displayWidth,171)
	frame:SetMaxResize(displayWidth,521)--40=661
	self:EnableResize(frame, displayWidth, 260, self.UpdateDisplaySize)
	
	frame.btnRefresh = CreateFrame("Button", nil, frame, "GameMenuButtonTemplate")
	local btnRefresh = frame.btnRefresh
	btnRefresh:SetText(REFRESH)
	btnRefresh:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 5, 5)
	btnRefresh:SetScript("OnClick", function(this, ...)
--~ 		print("btnRefresh","OnClick")
		self:UpdateGemTable()
	end)
	
	frame.btnConfig = CreateFrame("Button", nil, frame, "GameMenuButtonTemplate")
	local btnConfig = frame.btnConfig
	btnConfig:SetText(GAMEOPTIONS_MENU)
	btnConfig:SetPoint("LEFT", btnRefresh, "RIGHT")
	btnConfig:SetScript("OnClick", function(this, ...)
		core:OpenOptionsFrame()
--~ 		LibStub("AceConfigDialog-3.0"):SelectGroup(core.title, "display") --There's a bug where the text on options doesn't get updated when using this.
	end)
	
	frame.btnClear = CreateFrame("Button", nil, frame, "GameMenuButtonTemplate")
	local btnClear = frame.btnClear
	btnClear:SetText(KEY_NUMLOCK_MAC)
	btnClear:SetPoint("LEFT", btnConfig, "RIGHT")
	btnClear:SetScript("OnClick", function(this, ...)
		frame.stGems:SetData({})
	end)
	
	frame.txtSearch = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
	local txtSearch = frame.txtSearch
	txtSearch:SetText(SEARCH)
	txtSearch:SetTextColor(1, 0, 0, 0.5)
	txtSearch:SetWidth(140)
	txtSearch:SetHeight(20)
	txtSearch:SetPoint("LEFT", frame.btnClear, "RIGHT")
	txtSearch:SetAutoFocus(false)
	txtSearch.hadFocus = false
	txtSearch:SetScript("OnEnter", function(this, ...)
		GameTooltip:SetOwner(this, "ANCHOR_RIGHT");
		GameTooltip:SetText(L.txtSearchDesc, 1.0, 1.0, 1.0);
	end)
	txtSearch:SetScript("OnLeave", function(this, ...)
		GameTooltip:Hide();
	end)
	txtSearch:SetScript("OnEnterPressed", function(this, ...)
		this:ClearFocus();
		self:UpdateGemTable()
	end)
	txtSearch:SetScript("OnEditFocusGained", function(this, ...)
		if this.hadFocus == false then
			this:SetText("")
			this:SetTextColor(1, 1, 1, 1)
			this.hadFocus = true
		end
	end)

	--Add list frame.
	frame.stGems = LST:CreateST(self.columnHeaders, 1, columnHeight, nil, frame) --self.db.profile.columnHeight
	frame.stGems.frame:SetPoint("BOTTOMLEFT",frame, 3,30)
	frame.stGems.frame:SetPoint("TOP", frame, 0, -50)
	frame.stGems.frame:SetPoint("RIGHT", frame, -3,0)
	frame.stGems:Show()
	
	self:UpdateNumColumns()
	self:SetMouseFunctions()

	self.MainFrame:SetScript("OnEnter", function(this) 
		self:UpdateFrameLevel(this)
	end)
	
end

function display:UpdateNumColumns()
	local stGems = self.MainFrame.stGems
	local frame = stGems.frame
	local left, bottom, width, height = frame:GetRect()
	
	height = height - (columnHeight * 1.25)
	
	local columns = height / columnHeight
	stGems:SetDisplayRows(core.Round(columns), columnHeight)
--~ 	Debug("UpdateNumColumns", core.Round(columns), self.db.profile.columnHeight, self.MainFrame:GetHeight())
end






-- http://forums.wowace.com/showthread.php?t=15763
display.dropDownMenu = CreateFrame("Frame", folder.."DropDownMenu")
display.dropDownMenu.displayMode = "MENU"
local info = {}
display.dropDownMenu.initialize = function(self, level, ...)
    if not level then return end
    wipe(info)
	local gemID = self.gemID

    if level == 1 then
        -- Create the title of the menu
        info.isTitle = 1
		info.text = iLink[gemID]
        info.notCheckable = 1
        UIDropDownMenu_AddButton(info, level)
		
        info.disabled     = nil
        info.isTitle      = nil
        info.notCheckable = nil

        info.text = CREATE
        info.value = "Create"
		info.hasArrow = 1
        UIDropDownMenu_AddButton(info, level)

        -- Close menu item
        info.text         = CLOSE
        info.func         = function() CloseDropDownMenus() end
        info.checked      = nil
        info.notCheckable = 1
		info.hasArrow = nil
        UIDropDownMenu_AddButton(info, level)
		
	 elseif level == 2 then
        if _G.UIDROPDOWNMENU_MENU_VALUE == "Create" then --not upvalue
			local gemID = self.gemID
	
			local rawID = display.cutToRaw[gemID]
			if rawID then
				local myInv = core:GetMyGems() --only mats on char, not bank/alts.
				local count = rawID and myInv[rawID] or 0
				
				if count == 0 then
					info.text = SPELL_FAILED_REAGENTS:format(rawID and iLink[rawID])
					info.func = function(this, gemID, count)
						CloseDropDownMenus()
					end
					UIDropDownMenu_AddButton(info, level)
					
				else
				
					count = count > 10 and 10 or count
					
					for i=1, count do 
						info.text = i
						info.arg1 = gemID
						info.arg2 = i
						info.func = function(this, gemID, count)
			--~ 				Debug("Click A", ...)
							display:CraftItem(gemID, count)
							CloseDropDownMenus()
						end
						UIDropDownMenu_AddButton(info, level)
					end
				end
			end
			
		end
    end
end




function display:SetMouseFunctions()

	local st = self.MainFrame.stGems
	
	st.LibraryRefresh = st.Refresh
	st.Refresh = function(st)
		st:LibraryRefresh()
		for i=1,st.displayRows do
			local row = i+(st.offset or 0)

			local filteredRow = st.filtered[row]

			if filteredRow and st.data[filteredRow] then
				if selectedRows[st.data[filteredRow].auxData] then
					if i ~= st.mouseOverRow then
						st:SetHighLightColor(st.rows[i],highlightSelected)
					else
						st:SetHighLightColor(st.rows[i],highlightSelectedMouseOver)
					end
				else
					if i ~= st.mouseOverRow then
						st:SetHighLightColor(st.rows[i],highlightOff)
					else
						st:SetHighLightColor(st.rows[i],st:GetDefaultHighlight())
					end
				end
			end
		end
	end
	
	
	st:RegisterEvents({
		["OnEnter"] = function (rowFrame, cellFrame, data, cols, row, realrow, column, st, ...)
--~ 			Debug("OnEnter", rowFrame, cellFrame, data, cols, row, realrow, column, st, ...)
			
			GameTooltip:SetOwner(cellFrame, "ANCHOR_TOPLEFT")
			GameTooltip:ClearLines()
			
			if row then

				if realrow and selectedRows[data[realrow].auxData or 0] then
					st:SetHighLightColor(rowFrame,highlightSelectedMouseOver)
				else
					st:SetHighLightColor(rowFrame,st:GetDefaultHighlight())
				end

				st.mouseOverRow = row
				
				local celldata = data[realrow].cols[column];
				
				local columnName = self.columnHeaders[column].name
				
--~ 				if column == 3 then --Seen
				if columnName == L.gem then --Seen
					local gemID = unpack(celldata.args) --Seen
					local gemLink = gemID and iLink[gemID]
					GameTooltip:AddLine(gemLink,1,1,1,true)
					
					local rawID = self.cutToRaw[gemID]
					if rawID then
						local rawLink = iLink[rawID]
						if self.myRawGems[rawID] and self.myRawGems[rawID] > 0 then
							GameTooltip:AddLine("You have "..self.myRawGems[rawID].." raw gems.",1,1,1,true)
						end
					end
					if self.myCutGems[gemID] and self.myCutGems[gemID] > 0 then
						GameTooltip:AddLine("You have "..self.myCutGems[gemID].." cut gems.",1,1,1,true)
					end
					
					GameTooltip:Show()
					return
					
				
				elseif columnName == L.seen then --Seen
					local gemID, count, totalCount, highestSeen = unpack(celldata.args) --Seen
					
					local percent = Round(count / totalCount * 100, 2)
--~ 					local msg = "was seen "..count.." times and accounts for "..percent.."% of all gems."
					local msg = L.mouseoverSeen:format(count, percent)
					
					
					GameTooltip:AddLine(iLink[gemID],1,1,1,true)
					GameTooltip:AddLine(msg,1,1,1,true)
					GameTooltip:Show()
					return
					
				
				elseif columnName == TUTORIAL_TITLE19 then --Players
				
					
					local gemID, gemPopPercent, gemsPerPlayer, highestPlayerPop = unpack(celldata.args)
					
					
					local gemPlayerCount = self.gemPlayerCount[gemID]

--~ 					local msg = gemPlayerCount.." ("..Round(gemPopPercent,2).."%) players have "..Round(gemsPerPlayer,2).." gems socketed."
					local msg = L.mouseoverPlayers:format(gemPlayerCount, Round(gemPopPercent,2), Round(gemsPerPlayer,2))
					
					
					
					GameTooltip:AddLine(iLink[gemID],1,1,1,true)
					GameTooltip:AddLine(msg,1,1,1,true)
					GameTooltip:Show()
					return

--~ 				elseif column == 4 or column == 5 then --raw & cut prices
				elseif columnName == L.rawPrice or columnName == L.cutPrice  then
					local _, gemID = unpack(celldata.args)
				

					local gemLink = gemID and iLink[gemID]
					if gemLink then
						GameTooltip:SetHyperlink(gemLink)
						GameTooltip:Show()
						return
					end
					
				elseif columnName == "%" then
				
					local profitPercent, gemID = unpack(celldata.args)
					GameTooltip:AddLine(iLink[gemID],1,1,1,true)
--~ 					local msg = "Profit percentage: "..Round(profitPercent, 2).."%"
					local msg = L.mouseoverProfitPercentage:format(Round(profitPercent, 2))
					
					GameTooltip:AddLine(msg,1,1,1,true)
					GameTooltip:Show()
					return
					
					
					
--~ 				else
--~ 				
--~ 					GameTooltip:AddLine(self.columnHeaders[column].name,1,1,1,true)
--~ 					local value = cellFrame.text:GetText()

--~ 					local r,g,b = cellFrame.text:GetTextColor()
--~ 					GameTooltip:AddLine(value,r,g,b,true)
--~ 					GameTooltip:AddLine(cellData.tooltipText,.7,.7,.7)
				end

				GameTooltip:AddLine(self.columnHeaders[column].name,1,1,1,true)
				local value = cellFrame.text:GetText()
				local r,g,b = cellFrame.text:GetTextColor()
				GameTooltip:AddLine(value,r,g,b,true)
--~ 				GameTooltip:AddLine(cellData.tooltipText,.7,.7,.7)
				GameTooltip:Show()

			else
				local columnName = self.columnHeaders[column].name
				local r,g,b = 1,1,1

				GameTooltip:AddLine(columnName,r,g,b,true)
				
				
				if columnName == TUTORIAL_TITLE19 then
					GameTooltip:AddLine(L.mouseoverPlayersHeader,.7,.7,.7)
				end
				
				GameTooltip:Show()
			
			end

			
		end,
		
		["OnLeave"] = function (rowFrame, cellFrame, data, cols, row, realrow, column, st, ...)
--DEFAULT_CHAT_FRAME:AddMessage("onLeave start")
--				frame.keyCapture:EnableKeyboard(false)
			cellFrame:UnregisterEvent("MODIFIER_STATE_CHANGED")

			if row  then
				if realrow and selectedRows[data[realrow].auxData or 0] then
					st:SetHighLightColor(rowFrame,highlightSelected)
				else
					st:SetHighLightColor(rowFrame,highlightOff)
				end

				if st.mouseOverRow == row then
					st.mouseOverRow = nil
				end

				GameTooltip:Hide()

				st:Refresh()
			else
				GameTooltip:Hide()
			end

			return true
--DEFAULT_CHAT_FRAME:AddMessage("onLeave end")
		end,
		
		["OnClick"] = function (rowFrame, cellFrame, data, cols, row, realrow, column, st, button, ...)
			if row then
				if button == "LeftButton" then
					if not IsShiftKeyDown() then
						for i=1,#data do
							selectedRows[data[i].auxData] = false
						end
					end

					selectedRows[data[realrow].auxData] = true

					st:Refresh()
				elseif button == "RightButton" then
					local columnName = self.columnHeaders[column].name
--~ 					local celldata = data[realrow].cols[column];
					local gemID = data[realrow].auxData
--~ 					Debug(button, columnName, gemID)
					
					display.dropDownMenu.gemID = gemID
					ToggleDropDownMenu(1, nil, display.dropDownMenu, cellFrame, 0, 0)

				end
			else
				if button == "RightButton" then
					if self.columnHeaders[column].rightclick then
						self.columnHeaders[column].rightclick()
					end
				end
			end
		end,
	})

end

function display:UpdateDisplaySize(...)
	self:UpdateNumColumns()
end




local function GetNameColour(data, cols, realrow, column, table)
--~ 	local itemID = data[realrow].cols[column].value
	local itemID = unpack(data[realrow].cols[column].args)
--~ 	Debug("GetNameColour", realrow, column, itemID)
	local _, _, iRarity = GetItemInfo(itemID);
	local r, g, b, hex = GetItemQualityColor(iRarity)
--~ 	Debug("GetNameColour", realrow, column, itemID,iRarity, r, g, b)
	
	return {r=r,g=g,b=b}
end

function display:RedToGreen(current, max, min)
	if not current or current == "??" then
		return .5,.5,.5;
	end
	local min = min or 0
	current = current - min
	max = max - min
	
	local percentage = (current/max)*100;
	local red,green = 0,0;
	if percentage >= 50 then
		--green to yellow
		red		= ((100 - percentage) / 100) * 2;
		green	= 1;
	else
		--yellow to red
		green	= ((100 - (100 - percentage)) / 100) * 2;
		red		= 1;
	end
	return red, green, 0
end

local function GetSeenColour(data, cols, realrow, column, table)
--~ 	local itemID = data[realrow].cols[column].value
	local itemID, count, _, max = unpack(data[realrow].cols[column].args)
	local r,g,b = display:RedToGreen(count, max)
	return {r=r,g=g,b=b}
end

local function GetPopColour(data, cols, realrow, column, table)
	local itemID, gemPopPercent, _, highestPlayerPop = unpack(data[realrow].cols[column].args)
	local r,g,b = display:RedToGreen(gemPopPercent, highestPlayerPop)
	return {r=r,g=g,b=b}
end

local function GetPPColour(data, cols, realrow, column, table)--Profit Percentage
	local profitPercent, gemID, highestPP, lowestPP = unpack(data[realrow].cols[column].args)
	local r,g,b = display:RedToGreen(profitPercent, highestPP, lowestPP)
	return {r=r,g=g,b=b}
end




--

--~ display.columnNames = {}
--~ for i, value in ipairs(display.columnHeaders) do 
--~ 	display.columnNames[value.name] = i
--~ end

function display:CachePrices(gemID)
	local cutPrice = self.auctionPrice[gemID]
	
	local rawID = self.cutToRaw[gemID]
	if rawID then
		local rawPrice = self.auctionPrice[rawID]
	end
end

function display:GetGemProfit(gemID)
	local rawID = self.cutToRaw[gemID]
	
	local cutPrice = self.auctionPrice[gemID]
	if rawID then
		local rawPrice = self.auctionPrice[rawID]

		local profit = cutPrice - rawPrice
		if rawPrice and rawPrice > 0 then
			local profitPercent = (cutPrice / rawPrice * 100)
			
			return profit, profitPercent
		end
		return profit, 0
	end
	
	return 0, 0
end


function display:UpdateGemTable()
	local data = {}
	
--~ 	if self.db.profile.canUnderCut == true then
--~ 		local undercutMod = "Auc-Stat-Simple"
--~ 		if IsAddOnLoaded("Auc-Advanced") and not IsAddOnLoaded(undercutMod) then
--~ 			echo( L.loadingAuctionerModule:format(undercutMod) )
--~ 			core:LoadAddon(undercutMod)
--~ 		end
--~ 	end
	
	local totalCount, sortedGems = self:GetFilteredGems()
	
	local highestSeen = sortedGems[1] and sortedGems[1].count
	Debug("UpdateGemTable", "gemIDs:"..tostring(#sortedGems))
	
	--For popularity colour, I need to find out what the highest pop percentage is.
	local gemPopPercent, gemsPerPlayer
	local highestPlayerPop = 0
	local gemID, rawID
	
	for gID, percent in pairs(self.gemPopPercent) do 
		if percent > highestPlayerPop then
			highestPlayerPop = percent
		end
	end

--~ 	local cutPrice, rawPrice, profit, profitPercent
	local cutPrice, rawPrice, profit, profitPercent = {}, {}, {}, {}

	local highestPP = 0
	local lowestPP = 999
	for i=1, #sortedGems do 
		gemID = sortedGems[i].gemID
		
		profitPercent[gemID] = 0
		cutPrice[gemID] = 0
		rawPrice[gemID] = 0

		rawID = self.cutToRaw[gemID]
		if rawID then
			rawPrice[gemID] = self.auctionPrice[rawID]
		end
		cutPrice[gemID] = self.auctionPrice[gemID]

		profit[gemID] = cutPrice[gemID] - rawPrice[gemID]

		if rawPrice[gemID] and rawPrice[gemID] > 0 then
			profitPercent[gemID] = (cutPrice[gemID] / rawPrice[gemID] * 100)
		end
		
		if profitPercent[gemID] > highestPP then
			highestPP = profitPercent[gemID]
		end
		if profitPercent[gemID] < lowestPP then
			lowestPP = profitPercent[gemID]
		end
	end
	
	
	for i=1, #sortedGems do 
		gemID = sortedGems[i].gemID
		rawID = self.cutToRaw[gemID]
		
		gemPopPercent = self.gemPopPercent[gemID]
		gemsPerPlayer = self.gemsPerPlayer[gemID]
		
		table_insert(data, {
			auxData = gemID,
		
			cols = {
				
				{
					value = function (gemID)
						return iName[gemID]
					end,
					args = {sortedGems[i].gemID},
					color = GetNameColour,
				},
				
				
				{--seen column
					args = {sortedGems[i].gemID, sortedGems[i].count, totalCount, highestSeen},
					value = function (_, count, max)
						return count.." ("..Round(count/max*100).."%)"
					end,
					color = GetSeenColour,
				},
				
				{--Players
					args = {sortedGems[i].gemID, gemPopPercent, gemsPerPlayer, highestPlayerPop},
					value = function (_, gemPopPercent, gemsPerPlayer)
						return Round(gemPopPercent).."% (*"..Round(gemsPerPlayer)..")"
					end,
					color = GetPopColour,
				},
				
				{--rawPrice column
					args = {rawPrice[gemID], rawID},
					value = function (rawPrice, rawID)
						return self:CopperToCoins(rawPrice)
						
					end,
				},
				
				{--cutPrice column
					args = {cutPrice[gemID], sortedGems[i].gemID},
					value = function (cutPrice, gemID)
						return self:CopperToCoins(cutPrice)
					end,
				},
				
				{--profit column
					args = {profit[gemID] > 0 and profit[gemID] or 0, sortedGems[i].gemID},
					value = function (profit)
						return self:CopperToCoins(profit)
					end,
				},
				
				{--profitPercent
					args = {profitPercent[gemID], sortedGems[i].gemID, highestPP, lowestPP},
					value = function (profitPercent, gemID)
						if profitPercent > 0 then
							return Round(profitPercent).."%"
						else
							return "??"
						end
					end,
					color = GetPPColour,
				},
				
				
				
			},
		})
	end

--~ 	Debug("UpdateGemTable", "data:"..tostring(#data))
	
	self.MainFrame.stGems:SetData(data)
	
	
--~ 	self.MainFrame.stGems:SetHighLightColor(1, {r=1,g=1,b=1})
end

display.myCutGems = {}
display.myRawGems = {}

function display:ResetMyGems()
	self.myRawGems = {} --pretty much the same table twice except with alt inventory option.
	self.myCutGems = {}
	
	if self.db.profile.haveRawGems == true or self.db.profile.ignoreInventoryGems > 0 then
		local myFullInv = core:GetMyInventory(self.db.profile.includeBankInv)

		
		local me = UnitName("player")
		for name, inv in pairs(myFullInv) do 
			if self.db.profile.includeAltRawGems == true or name == me then
				for gemID, count in pairs(inv) do 
					self.myRawGems[gemID] = (self.myRawGems[gemID] or 0) + count
				end
			end
			
			if self.db.profile.includeInventoryGemsAlts == true or name == me then
				for gemID, count in pairs(inv) do 
					
					self.myCutGems[gemID] = (self.myCutGems[gemID] or 0) + count
				end
			end
		end
	end

--~ 	Debug("ResetMyGems", "Reset")
--~ 	for gemID, count in pairs(self.myCutGems) do 
--~ 		Debug("SayMyGems", iLink[gemID], count, myAuctions[gemID])
--~ 	end
end

local t = CreateFrame("Frame")
t:Hide()
t:SetScript("OnUpdate", function(this, elapsed) 
	this.stop = this.stop - elapsed
	if this.stop < 0 then
		this:Hide()
	end
end)
t:SetScript("OnHide", function(this, elapsed) 
--~ 	Debug("OnHide", "Reset")
	display:ResetMyGems()
end)
function display:BAG_UPDATE(event, ...) 
--~ 	Debug(event, ...)
	t.stop = 0.1 --BAG_UPDATE fires twice when something's moved. We only want to call our reset function once.
	t:Show()
end

function display:GetFilteredGems()
	local totalCount, sortedGems = self:GetSortedGems()
	
	Debug("GetFilteredGems", "gemIDs:"..tostring(#sortedGems), "totalGems:"..totalCount)
	
	local filteredGems = {}
	
	local gemID, count
	local itemRarity, itemLevel
	local percent
	local rawID
	
--~ 	this.hadFocus
	
	local txtSearch = ""
	if self.MainFrame.txtSearch.hadFocus == true then
		txtSearch = self.MainFrame.txtSearch:GetText():lower()
	end


	self:ResetMyGems()
	


	--Add auction items to our inv list.
	if self.db.profile.includeAuctionedGems == true then
		local myAuctions = core:GetMyAuctions()
		for gemID, count in pairs(myAuctions) do 
			self.myCutGems[gemID] = (self.myCutGems[gemID] or 0) + count
--~ 			self.myRawGems[gemID] = (self.myRawGems[gemID] or 0) + count
		end
	end
	
	
	local tmpRawGems = {} --So we can subtract gem count.
	for a, b in pairs(self.myRawGems) do 
		tmpRawGems[a] = b
	end
	
	local profit, profitPercent
	for i=1, #sortedGems do 
		if #filteredGems >= self.db.profile.seenCount then
			break
		end
		gemID = sortedGems[i].gemID
--~ 		if not gemID then
--~ 			Debug("GetFilteredGems A", gemID)
--~ 		end
		
		
		
		if txtSearch:trim() == "" or (iName[gemID]:lower():find(txtSearch) or self.gemStats[gemID]:lower():find(txtSearch)) then

			if self.db.profile.ignoreDragonEyes == false or not iName[gemID]:find(dragonsEye) then
				if self.db.profile.ignoreNightmareTear == false or gemID ~= nightmareTear then
					if self.db.profile.ignoreStormjewels == false or not stormJewels[gemID] then
--~ 						if iLink[gemID] then
							_, _, itemRarity, itemLevel = GetItemInfo(gemID) 
--~ 							Debug("GetFilteredGems A", gemID, iLink[gemID], itemRarity, itemLevel)
							if self.db.profile.gemRarity == 0 or itemRarity and itemRarity >= (self.db.profile.gemRarity + 1) then -- 
								if itemLevel and itemLevel >= self.db.profile.gemLevel then
--~ 									Debug("GetFilteredGems B", gemID)
									
									--self.db.profile.ignoreInventoryGems == 0 or 
									if self.db.profile.ignoreInventoryGems == 0 or not self.myCutGems[gemID] or self.myCutGems[gemID] < self.db.profile.ignoreInventoryGems  then --Only add gems if you have below ignoreInventoryGems.
--~ 										Debug("GetFilteredGems C", gemID)
										
										rawID = self.cutToRaw[gemID]
--~ 										Debug("GetFilteredGems CC", gemID, rawID)
										if self.db.profile.haveRawGems == false or (rawID and tmpRawGems[rawID] and tmpRawGems[rawID] >= 1) then
											
--~ 											Debug("GetFilteredGems D", gemID)
													
											if self.db.profile.knownGems == 0 and self.canCutGem[gemID] --Only show gems you can cut.
											or self.db.profile.knownGems == 1 --show all gems.
											or self.db.profile.knownGems == 2 and (not self.canCutGem[gemID]) then --Only show gems you can't cut.
													
												profit, profitPercent = self:GetGemProfit(gemID)
--~ 													Debug("GetFilteredGems E", gemID)
												--not self:CanGetPrices() or 
												if self.db.profile.filterByProfit == false or (profit/100/100) > self.db.profile.minProfitGold then
--~ 													Debug("GetFilteredGems F", gemID)
													if self.db.profile.filterByProfit == false or profitPercent > self.db.profile.minProfitPercentage then
--~ 														Debug("GetFilteredGems G", gemID)
														table_insert(filteredGems, #filteredGems+1, sortedGems[i])
														
														tmpRawGems[rawID] = rawID and tmpRawGems[rawID] and (tmpRawGems[rawID] - self.db.profile.matCountdown)
													end
												end
											end
										end
									end
								end
							end
--~ 						end
					end
				end
			end
		end
	end
	
	return totalCount, filteredGems
end


display.gemPopPercent = {}--What percentage of players have that gem.
display.gemPlayerCount = {}
display.gemsPerPlayer = {}-- How many of that gem do players (that use it) equip.

function display:GetSortedGems()
	local playerGems = core.db.global.playerGems
	
	local tGems = {}
	local totalCount = 0
	
	local success, when, pGems
	local gemSeenOnPlayer = {}
	local totalPlayers = 0
	
	local gemSeen = {}
	for who, serial in pairs(playerGems) do 
		success, pGems = core:Deserialize(serial)
		if success then
			totalPlayers = totalPlayers + 1
			
			for gemID, count in pairs(pGems) do 
				tGems[gemID] = (tGems[gemID] or 0) + count
				totalCount = totalCount + count
				
				--new
				gemSeenOnPlayer[gemID] = gemSeenOnPlayer[gemID] or {}
				gemSeenOnPlayer[gemID][who] = true --(gemSeenOnPlayer[who] or 0) + 1
				gemSeen[gemID] = (gemSeen[gemID] or 0) + count
			end
			
		end
	end
--~ self:CachePrices(gemID) --I'm doing this now so their price gets cached for next login.

	if self.db.profile.pricingAlgorithm ~= L.prevPriceAlgorithm then	
		Debug("GetSortedGems","Caching gem prices...")
		for gemID, count in pairs(gemSeen) do 
			self:CachePrices(gemID) --I'm doing this now so their price gets cached for next login.
		end
	end
	
	local sGems = {}
	for gemID, count in pairs(tGems) do 
		table_insert(sGems, #sGems+1, {gemID=gemID, count=tGems[gemID]})
	end
	
	table_sort(sGems, function(a,b) 
		if(a and b) then 
			if a.count == b.count then
				return a.gemID < b.gemID
			else
				return a.count > b.count
			end
		end 
	end)
	
	--Do gem popularity stuff.
	local playerCount = 0
--~ 	for name in pairs(gemSeenOnPlayer) do 
--~ 		playerCount = playerCount + 1
--~ 	end
--~ 	local gemPopPercent = Round(playerCount/totalPlayers*100,2)
--~ 	local gemsPerPlayer = Round(gemSeen / playerCount)
	
	local gemPopPercent, gemsPerPlayer
	for gemID, players in pairs(gemSeenOnPlayer) do 
		playerCount = 0
		for name in pairs(players) do 
			playerCount = playerCount + 1
		end
		local gemPopPercent = playerCount/totalPlayers*100 --Round(playerCount/totalPlayers*100,2)
		local gemsPerPlayer = gemSeen[gemID] / playerCount --Round(gemSeen[gemID] / playerCount)
		
		self.gemPopPercent[gemID] = gemPopPercent
		self.gemsPerPlayer[gemID] = gemsPerPlayer
		
		self.gemPlayerCount[gemID] = playerCount
--~ 		if gemID and iName[gemID]:find("Solid") then
--~ 			Debug("GetGemPopularity", gemID and iLink[gemID], playerCount, gemPopPercent)
--~ 		end
	end
	
	
	return totalCount, sGems
end
