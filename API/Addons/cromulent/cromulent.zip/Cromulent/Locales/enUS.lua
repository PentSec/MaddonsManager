local L = LibStub("AceLocale-3.0"):NewLocale("Cromulent", "enUS", true)
if not L then return end
--
L["%d-man"] = true
L["Instances"] = true
