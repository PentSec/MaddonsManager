local L = LibStub("AceLocale-3.0"):NewLocale("Cromulent", "koKR")
if not L then return end
--
L["%d-man"] = "%d명"
L["Instances"] = "인스턴스"
