﻿-- Please note the Code contained in this file has been modified and adapted as needed - May 2009.
-- The original credit for the unmodified addon belongs to the auctionlite addon author MerialKilrogg
-- The auctionlite code was available under GPLv2 license and as such this code is available under GPLv2

-- FlaskCalc Addons --
-- Create the addons in memory
FlaskCalc = LibStub("AceAddon-3.0"):NewAddon("SlyProfits",
                                            "AceConsole-3.0",
                                            "AceEvent-3.0",
                                            "AceHook-3.0");

local SLYPROFITS_VERSION = "1.0.5";
local DBName = "SlyProfitsDB";
local hooked = false;
-- Currently no slash commands...
local Options = {
  type = "group",
  get = function(item) return FlaskCalc.db.profile[item[#item]] end,
  set = function(item, value) FlaskCalc.db.profile[item[#item]] = value end,
  args = {
    configLaunch = {
      type = "execute",
      func = function()
        FlaskCalc:ConfigRecipes();
      end,
      desc = "Configure Recipes",
      name = "Configure Recipes",
      order = 8,
    },
  },
};

local SlashOptions = {
  type = "group",
  handler = SlyProfits,
  args = {
    recipes = {
      type = "execute",
      desc = "Opens the recipes configuration dialog",
      name = "Recipes",
      func = function()
        FlaskCalc:ConfigRecipes();
      end,
    },
  },
};

local SlashCmds = {
  "slyprofits",
};

local Defaults = {
  profile = {
    filterProfs= true,
    showAlchemy = true,
    showBlacksmithing = true,
    showCooking = true,
    showEnchanting = true,
    showEngineering = true,
    showInscription = true,
    showJewelcrafting = true,
    showLeatherworking = true,
    showTailoring = true,
    showMining = true,
    showFirstAid = true,
    showMisc = true,
    disabledIDs = {},
    hiddenIDs = {},
    nextFreeID = 3000,
    advanced = true,
    inventory = false,
    customRecipes = {},
    notFoundData = {},

    --TODO
    vendorPrice = {
				["Arcane Powder"] = 800,
				["Simple Grinder"] = 20000,
				["Snowplum Brandy"] = 120,
				["Yellow Dye"] = 400,
				["Walnut Stock"] = 40000,
				["Crystal Vial"] = 400,
				["Corpse Dust"] = 400,
				["Leaded Vial"] = 32,
				["Glass of Aged Dalaran Red"] = 8000,
				["Strong Flux"] = 1600,
				["Weak Flux"] = 80,
				["Crusty Flatbread"] = 1360,
				["Purple Dye"] = 2000,
				["Infernal Stone"] = 4000,
				["Antiseptic-Soaked Dressing"] = 200000,
				["Rough Blasting Powder"] = 13,
				["Stranglethorn Seed"] = 320,
				["Pattern: Polar Cord"] = 0,
				["Black Dye"] = 800,
				["Salt"] = 40,
				["Blue Dye"] = 40,
				["Scribe's Satchel"] = 4000,
				["Mining Pick"] = 65,
				["Virtuoso Inking Set"] = 600,
				["Glass of Dalaran White"] = 1200,
				["Bright Baubles"] = 200,
				["Star Wood"] = 3600,
				["Resilient Parchment"] = 4000,
				["Simple Wood"] = 30,
				["Lesser Magic Essence"] = 640,
				["Heavy Parchment"] = 1000,
				["Silken Thread"] = 400,
				["Coal"] = 400,
				["Starleaf Seed"] = 5600,
				["Jeweler's Kit"] = 640,
				["Tome of Dalaran Brilliance"] = 4000000,
				["Strange Dust"] = 640,
				["Imbued Vial"] = 3200,
				["Blacksmith Hammer"] = 14,
				["Gray Dye"] = 280,
				["Wild Spineleaf"] = 4000,
				["Tome of Polymorph: Black Cat"] = 20000000,
				["Hair Trigger"] = 7200,
				["Wild Quillvine"] = 1200,
				["Heavy Stock"] = 1600,
				["Bleach"] = 20,
				["Wild Thornroot"] = 800,
				["Elemental Flux"] = 120000,
				["Sacred Candle"] = 800,
				["Holy Candle"] = 560,
				["Coarse Blasting Powder"] = 38,
				["Coarse Thread"] = 8,
				["Devout Candle"] = 1600,
				["Symbol of Kings"] = 120,
				["Symbol of Divinity"] = 1600,
				["Ankh"] = 1600,
				["Nightcrawlers"] = 80,
				["Flintweed Seed"] = 4000,
				["Hornbeam Seed"] = 1120,
				["Ashwood Seed"] = 640,
				["Engineer's Ink"] = 1600,
				["Maple Seed"] = 160,
				["Copper Rod"] = 99,
				["Rune of Portals"] = 1600,
				["Green Dye"] = 80,
				["Fishing Pole"] = 18,
				["Impact Shot"] = 6.4,
				["Red Wine Glass"] = 80000,
				["Intravenous Healing Potion"] = 21600,
				["Savory Snowplum"] = 2560,
				["Tundra Berries"] = 1360,
				["Caraway Burnwine"] = 1200,
				["Orange Dye"] = 800,
				["Honey Mead"] = 40,
				["Glass of Dalaran Red"] = 1600,
				["Tome of Dalaran Intellect"] = 3800000,
				["Briny Hardcheese"] = 2560,
				["Wooden Stock"] = 160,
				["Enchanted Vial"] = 8000,
				["Empty Vial"] = 3.2,
				["Red Dye"] = 40,
				["Ironwood Seed"] = 1600,
				["Fine Thread"] = 80,
				["Poached Emperor Salmon"] = 2560,
				["Pink Dye"] = 2000,
				["Common Parchment"] = 100,
				["Wound Dressing"] = 160000,
				["Sweet Potato Bread"] = 2560,
				["Dragon's Eye"] = 0,
				["Light Parchment"] = 12,
				["Sour Goat Cheese"] = 1360,
				["Wild Berries"] = 560,
				["Heavy Silken Thread"] = 1600,
				["Skinning Knife"] = 66,
				["Copper Modulator"] = 160,
				["Eternium Thread"] = 24000,
				["Demonic Figurine"] = 8000,
				["Rune Thread"] = 4000,
				["Rune of Teleportation"] = 800,
    },
  },
};
-------------------------------------------------------------------------------
-- Hooks and boostrap code
-------------------------------------------------------------------------------

-- Hook some AH/GB functions and UI widgets when the AH/GB gets loaded.
function FlaskCalc:ADDON_LOADED(_, name)

  if IsAddOnLoaded("Blizzard_AuctionUI") and hooked == false then
    hooked = true;
    self:SecureHook("QueryAuctionItems",
                    "QueryAuctionItems_Hook");
    self:SecureHook("AuctionFrameTab_OnClick",
                    "AuctionFrameTab_OnClick_Hook");
    self:HookAuctionFrameUpdate();
    self:AddAuctionFrameTab();
  end
  
  FlaskCalc:InitializeRecipeList();
end

-- If we see an Ace2 database, convert it to Ace3.
function FlaskCalc:ConvertDB()
  local db = _G[DBName];

  -- It's Ace2 if it uses "realms" instead of "factionrealm".
  if db ~= nil and db.realms ~= nil and db.factionrealm == nil then
    -- Change "Realm - Faction" keys to "Faction - Realm" keys.
    db.factionrealm = {}
    for k, v in pairs(db.realms) do
      db.factionrealm[k:gsub("(.*) %- (.*)", "%2 - %1")] = v;
    end

    -- Now unlink the old DB.
    db.realms = nil;
  end
end

-- If any of the options are outdated, convert them.
function FlaskCalc:ConvertOptions()

    --@non-debug@ 
	    -- remove old debugging information
	    self.db.profile.notFoundData = nil;
    --@end-non-debug@

    if self.db.profile.disabledIDs["0027"] == nil then
        self.db.profile.disabledIDs["0027"] = true;
    end
    if self.db.profile.disabledIDs["0028"] == nil then
        self.db.profile.disabledIDs["0028"] = true;
    end
    if self.db.profile.disabledIDs["0029"] == nil then
        self.db.profile.disabledIDs["0029"] = true;
    end
    if self.db.profile.disabledIDs["0030"] == nil then
        self.db.profile.disabledIDs["0030"] = true;
    end
    if self.db.profile.disabledIDs["0031"] == nil then
        self.db.profile.disabledIDs["0031"] = true;
    end
    if self.db.profile.disabledIDs["0032"] == nil then
        self.db.profile.disabledIDs["0032"] = true;
    end
    if self.db.profile.disabledIDs["0033"] == nil then
        self.db.profile.disabledIDs["0033"] = true;
    end
    if self.db.profile.disabledIDs["0034"] == nil then
        self.db.profile.disabledIDs["0034"] = true;
    end
    if self.db.profile.disabledIDs["0035"] == nil then
        self.db.profile.disabledIDs["0035"] = true;
    end
    if self.db.profile.disabledIDs["0036"] == nil then
        self.db.profile.disabledIDs["0036"] = true;
    end
end

function FlaskCalc:RemoveBadEntries()
    local CustomRecipes = self.db.profile.customRecipes;
    if CustomRecipes ~= nil then
        for i = 1, getn(CustomRecipes) do
            local bad = false;
            local R = CustomRecipes[i];
            if R == nil then
                bad = true;
            elseif R.Name == nil then
                bad = true;
            elseif R.Profession == nil then
                bad = true;
            elseif R.ID == nil then
                bad = true;
            elseif R.DesiredAmount == nil then
                bad = true;
            elseif R.Quantity == nil then
                bad = true;
            elseif R.Mats == nil then
                bad = true;
            else
                for j = 1,getn(R.Mats) do
                    if R.Mats[j] == nil then
                        bad = true;
                    elseif R.Mats[j][1] == nil then
                        bad = true;
                    elseif R.Mats[j][2] == nil then
                        bad = true;
                    end
                end

            end
            if bad == true then
                table.remove(self.db.profile.customRecipes,i);
            else
                R.StaticCostPerItem = 0;
            end
        end
    end
end


-- We're alive!
function FlaskCalc:OnInitialize()

  -- Load our database.
  self:ConvertDB();
  self.db = LibStub("AceDB-3.0"):New(DBName, Defaults, "Default");

  -- Update any options that have changed.
  self:ConvertOptions();

  -- Set up our config options.
  local profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db);
  local config = LibStub("AceConfig-3.0");
  config:RegisterOptionsTable("SlyProfits", SlashOptions, SlashCmds);

  local registry = LibStub("AceConfigRegistry-3.0");
  registry:RegisterOptionsTable("SlyProfits Options", Options);

  local dialog = LibStub("AceConfigDialog-3.0");
  self.optionFrames = {
    main     = dialog:AddToBlizOptions("SlyProfits Options", "SlyProfits"),
  };
  -- Register for events.
  self:RegisterEvent("ADDON_LOADED");
  self:RegisterEvent("AUCTION_ITEM_LIST_UPDATE");
  self:RegisterEvent("AUCTION_HOUSE_CLOSED");
  self:RegisterEvent("TRADE_SKILL_SHOW");
  self:RegisterEvent("MERCHANT_SHOW");

  -- Another addon may have forced the Blizzard addons to load early.
  -- If so, just run the init code now.
  if IsAddOnLoaded("Blizzard_AuctionUI") then
    self:ADDON_LOADED("Blizzard_AuctionUI");
  end

  self:Print("SlyProfits v1.1.2 is loaded!");

end
