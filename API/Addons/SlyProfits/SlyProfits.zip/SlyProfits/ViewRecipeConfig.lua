﻿-------------------------------------------------------------------------------
-- RecipeConfig.lua
--
-- Configuration Window to control recipes
-------------------------------------------------------------------------------

local AceGUI = LibStub("AceGUI-3.0");
local theFrame = nil;
local selectedid = nil;
local RecipeFrame = nil;
local Mats = {};
local isOpen = false;
local mode = "New";
local editing = nil;
local TheMats = {nil,nil,nil};

-- Localization
local L = LibStub("AceLocale-3.0"):GetLocale("SlyProfits")

function FlaskCalc:ViewRecipes(RecipeConfigFrame)
    RecipeFrame = RecipeConfigFrame;
    self:CreateViewWindow();

    theFrame:Show();
    isOpen = true;
    theFrame:SetFrameLevel(4000);
    self:ViewRecipeFrame_Update();
end

function FlaskCalc:HideViewRecipes()
    if theFrame ~=  nil then
        theFrame:Hide();
        isOpen = false;
        self:ConfigRecipeFrame_Update();
    end
end

function FlaskCalc:EditMode(Recipe)
    mode = "Edit";
    editing = Recipe;
    Mats = {};
    local TheMats = {nil,nil,nil};
    selectedid = nil;
    for i = 1, getn(editing.Mats) do
        table.insert(Mats, {editing.Mats[i][1],editing.Mats[i][2]});
    end
    theFrame.NameText:SetText("");
    theFrame.NameData:SetText(editing.Name);
    UIDropDownMenu_SetSelectedValue(theFrame.ProfessionData, editing.Profession);
    theFrame.DesiredAmountData:SetText(editing.DesiredAmount);
    theFrame.DesiredAmountData:SetCursorPosition(0);
    theFrame.MakesData:SetText(editing.Quantity);
    theFrame.MakesData:SetCursorPosition(0);
    theFrame.Cooldown:SetChecked(editing.HasCooldown);
    self:ViewRecipeFrame_Update();
end

function FlaskCalc:NewMode()
    mode = "New";
    editing = nil;
    Mats = {};
    local TheMats = {nil,nil,nil};
    selectedid = nil;
    theFrame.Cooldown:SetChecked(false);
    theFrame.NameText:SetText("");
    theFrame.NameData:SetText("");
    theFrame.DesiredAmountData:SetText("");
    UIDropDownMenu_ClearAll(theFrame.ProfessionData);
    theFrame.MakesData:SetText("");
    self:ViewRecipeFrame_Update();
end

function FlaskCalc:CreateViewWindow()
    if theFrame == nil then
        theFrame=CreateFrame("Frame",nil,UIParent);

        theFrame:ClearAllPoints();
        theFrame:SetPoint("TOPLEFT",RecipeFrame,"BOTTOMLEFT",10,0);
        theFrame:SetPoint("TOPRIGHT",RecipeFrame,"BOTTOMRIGHT",-25,0);
        theFrame:SetWidth(330);
        theFrame:SetHeight(240);

        theFrame:SetBackdrop( {
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32,
            insets = { left = 11, right = 12, top = 12, bottom = 11 }
        });
        theFrame.TopLeftBorder=theFrame:CreateTexture(nil,"OVERLAY",nil);
        theFrame.TopLeftBorder:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Corner");
        theFrame.TopLeftBorder:SetHeight(32);
        theFrame.TopLeftBorder:SetWidth(32);
        theFrame.TopLeftBorder:SetPoint("TOPRIGHT",theFrame,"TOPRIGHT",-6,-7);

        theFrame.Title=theFrame:CreateFontString(nil,"OVERLAY","GameFontHighlight");
        theFrame.Title:SetPoint("TOP",theFrame,"TOP",0,-17);
        theFrame.Title:SetHeight(14);
        theFrame.Title:SetWidth(200);
        theFrame.Title:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.Title:SetText(L["Create a New Recipe"]);

        theFrame.NameLabel=theFrame:CreateFontString(nil,"OVERLAY","SlyprofitsLabelFont");
        theFrame.NameLabel:SetPoint("TOPLEFT",theFrame,"TOPLEFT",20,-37);
        theFrame.NameLabel:SetHeight(21);
        theFrame.NameLabel:SetWidth(50);
        theFrame.NameLabel:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.NameLabel:SetText(L["Name"]..": ");

        theFrame.NameText=theFrame:CreateFontString(nil,"OVERLAY","SlyprofitsLabelFont");
        theFrame.NameText:SetPoint("LEFT",theFrame.NameLabel,"RIGHT",0,0);
        theFrame.NameText:SetWidth(270);
        theFrame.NameText:SetHeight(21);
        theFrame.NameText:SetText("");

        theFrame.NameData=CreateFrame("EditBox",nil,theFrame,"SlyprofitsEditBox1");
        theFrame.NameData:SetPoint("LEFT",theFrame.NameLabel,"RIGHT",0,0);
        theFrame.NameData:SetWidth(270);
        theFrame.NameData:SetHeight(21);
        theFrame.NameData:SetText("");

        theFrame.ProfessionLabel=theFrame:CreateFontString(nil,"OVERLAY","SlyprofitsLabelFont");
        theFrame.ProfessionLabel:SetPoint("TOPLEFT",theFrame.NameLabel,"BOTTOMLEFT",0,0);
        theFrame.ProfessionLabel:SetHeight(21);
        theFrame.ProfessionLabel:SetWidth(120);
        theFrame.ProfessionLabel:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.ProfessionLabel:SetText(L["Profession"]..": ");

        theFrame.ProfessionData = CreateFrame("Frame", "ProfessionDropDown", theFrame, "UIDropDownMenuTemplate");
        theFrame.ProfessionData:SetPoint("LEFT",theFrame.ProfessionLabel,"RIGHT",0,0);
        UIDropDownMenu_SetWidth(theFrame.ProfessionData,120);
        UIDropDownMenu_SetButtonWidth(theFrame.ProfessionData, 20);
        UIDropDownMenu_Initialize(theFrame.ProfessionData, ProfessionData_Initialise);

        theFrame.DesiredAmountLabel=theFrame:CreateFontString(nil,"OVERLAY","SlyprofitsLabelFont");
        theFrame.DesiredAmountLabel:SetPoint("TOPLEFT",theFrame.ProfessionLabel,"BOTTOMLEFT",0,0);
        theFrame.DesiredAmountLabel:SetHeight(21);
        theFrame.DesiredAmountLabel:SetWidth(170);
        theFrame.DesiredAmountLabel:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.DesiredAmountLabel:SetText(L["Desired Stack Size"]..": ");

        theFrame.DesiredAmountData=CreateFrame("EditBox",nil,theFrame,"SlyprofitsEditBox2");
        theFrame.DesiredAmountData:SetPoint("LEFT",theFrame.DesiredAmountLabel,"RIGHT",0,0);
        theFrame.DesiredAmountData:SetWidth(50);
        theFrame.DesiredAmountData:SetHeight(21);
        theFrame.DesiredAmountData:SetText("");

        theFrame.Cooldown=CreateFrame("CheckButton","RecipeHasCooldown",theFrame,"OptionsSmallCheckButtonTemplate");
        theFrame.Cooldown:SetPoint("LEFT",theFrame.DesiredAmountData,"RIGHT",0,0);
        theFrame.Cooldown:SetChecked(false);
        theFrame.CooldownText = _G["RecipeHasCooldownText"];
        theFrame.CooldownText:SetText(L["has Cooldown?"]);

        theFrame.MakesLabel=theFrame:CreateFontString(nil,"OVERLAY","SlyprofitsLabelFont");
        theFrame.MakesLabel:SetPoint("TOPLEFT",theFrame.DesiredAmountLabel,"BOTTOMLEFT",0,0);
        theFrame.MakesLabel:SetHeight(21);
        theFrame.MakesLabel:SetWidth(170);
        theFrame.MakesLabel:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.MakesLabel:SetText(L["Makes Per Craft"]..": ");

        theFrame.MakesData=CreateFrame("EditBox",nil,theFrame,"SlyprofitsEditBox3");
        theFrame.MakesData:SetPoint("LEFT",theFrame.MakesLabel,"RIGHT",0,0);
        theFrame.MakesData:SetWidth(50);
        theFrame.MakesData:SetHeight(21);
        theFrame.MakesData:SetText("");

        theFrame.MatsLabel=theFrame:CreateFontString(nil,"OVERLAY","SlyprofitsLabelFont");
        theFrame.MatsLabel:SetPoint("TOPLEFT",theFrame.MakesLabel,"BOTTOMLEFT",0,0);
        theFrame.MatsLabel:SetHeight(14);
        theFrame.MatsLabel:SetWidth(40);
        theFrame.MatsLabel:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.MatsLabel:SetText(L["Mats"]..": ");

        theFrame.ScrollFrameBackground=CreateFrame("Frame",nil,theFrame);
        theFrame.ScrollFrameBackground:SetWidth(290);
        theFrame.ScrollFrameBackground:SetHeight(90);
        theFrame.ScrollFrameBackground:SetPoint("TOPLEFT",theFrame.MatsLabel,"TOPRIGHT",-8,0);
        theFrame.ScrollFrameBackground:SetBackdrop( {
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32,
            insets = { left = 5, right = 5, top = 5, bottom = 5 }
        });

        theFrame.ScrollFrame=CreateFrame("ScrollFrame","ViewMatsScroller",theFrame,"ViewMatsScrollFrame");
        theFrame.ScrollFrame:SetPoint("LEFT",theFrame.ScrollFrameBackground,"LEFT",10,0);
        theFrame.ScrollFrame:SetPoint("RIGHT",theFrame.ScrollFrameBackground,"RIGHT",-30,0);
        theFrame.ScrollFrame:SetPoint("BOTTOM",theFrame.ScrollFrameBackground,"BOTTOM",0,10);
        theFrame.ScrollFrame:SetPoint("TOP",theFrame.ScrollFrameBackground,"TOP",0,-10);

        theFrame.Mats = {};
        local previous = nil;
        for i = 1,3 do
            local MatEntry = CreateFrame("Button","ViewMatButton"..i,theFrame,"ViewMatItemTemplate");
            table.insert(theFrame.Mats,MatEntry);
            if i == 1 then
                MatEntry:SetPoint("TOPLEFT",theFrame.ScrollFrame,"TOPLEFT",0,0);
            else
                MatEntry:SetPoint("TOPLEFT",previous,"BOTTOMLEFT",0,0);
            end
            MatEntry:SetID(i);
            previous = MatEntry;
        end

        theFrame.CloseCross=CreateFrame("Button",nil,theFrame,"UIPanelCloseButton");
        theFrame.CloseCross:SetPoint("TOPRIGHT",theFrame,"TOPRIGHT",-2,-3);
        theFrame.CloseCross:SetScript("OnClick",function() FlaskCalc:HideViewRecipes() end);


        theFrame.SaveButton=CreateFrame("Button",nil,theFrame,"UIPanelButtonTemplate");
        theFrame.SaveButton:SetWidth(82)
        theFrame.SaveButton:SetHeight(25)
        theFrame.SaveButton:SetPoint("BOTTOMRIGHT",theFrame,"BOTTOMRIGHT",-10,10);
        theFrame.SaveButton:SetScript("OnClick",function() FlaskCalc:ViewSaveButton_OnClick(); end);
        theFrame.SaveButton:SetText("Save")

        theFrame.AddMatButton=CreateFrame("Button",nil,theFrame,"UIPanelButtonTemplate");
        theFrame.AddMatButton:SetWidth(82)
        theFrame.AddMatButton:SetHeight(25)
        theFrame.AddMatButton:SetPoint("TOPRIGHT",theFrame.SaveButton,"TOPLEFT",0,0);
        theFrame.AddMatButton:SetScript("OnClick",function() FlaskCalc:AddMatButton_OnClick(); end);
        theFrame.AddMatButton:SetText("Add Mat")

        theFrame.DeleteMatButton=CreateFrame("Button",nil,theFrame,"UIPanelButtonTemplate");
        theFrame.DeleteMatButton:SetWidth(82)
        theFrame.DeleteMatButton:SetHeight(25)
        theFrame.DeleteMatButton:SetPoint("TOPRIGHT",theFrame.AddMatButton,"TOPLEFT",0,0);
        theFrame.DeleteMatButton:SetScript("OnClick",function() FlaskCalc:DeleteMatButton_OnClick(); end);
        theFrame.DeleteMatButton:SetText("Delete Mat")

        theFrame:EnableMouse(true);
        theFrame:SetMovable(false);
    else

    end
	theFrame:Hide()
end

function ProfessionData_Initialise()
 level = level or 1;

 local info = UIDropDownMenu_CreateInfo();


 -- Alchemy
 info.text = GetSpellInfo(2259); --the text of the menu item
 info.value = GetSpellInfo(2259); -- the value of the menu item. This can be a string also.
 info.func = function() ProfessionData_OnClick() end; --sets the function to execute when this item is clicked
 info.owner = this:GetParent(); --binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menues.
 info.checked = nil; --initially set the menu item to being unchecked with a yellow tick
 info.icon = nil; --we can use this to set an icon for the drop down menu item to accompany the text
 UIDropDownMenu_AddButton(info, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu

 --Blacksmithing
 info.text = GetSpellInfo(3100); --the text of the menu item
 info.func = function() ProfessionData_OnClick() end;
 info.value = GetSpellInfo(3100); -- the value of the menu item. This can be a string also.
 --info.func = function() ProfessionData_OnClick() end; --sets the function to execute when this item is clicked
 info.owner = this:GetParent(); --binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menues.
 info.checked = nil; --initially set the menu item to being unchecked with a yellow tick
 info.icon = nil; --we can use this to set an icon for the drop down menu item to accompany the text
 UIDropDownMenu_AddButton(info, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu

 --Cooking
 info.text = GetSpellInfo(2550); --the text of the menu item
 info.func = function() ProfessionData_OnClick() end;
 info.value = GetSpellInfo(2550); -- the value of the menu item. This can be a string also.
 --info.func = function() ProfessionData_OnClick() end; --sets the function to execute when this item is clicked
 info.owner = this:GetParent(); --binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menues.
 info.checked = nil; --initially set the menu item to being unchecked with a yellow tick
 info.icon = nil; --we can use this to set an icon for the drop down menu item to accompany the text
 UIDropDownMenu_AddButton(info, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu

 --Enchanting
 info.text = GetSpellInfo(7411); --the text of the menu item
 info.func = function() ProfessionData_OnClick() end;
 info.value = GetSpellInfo(7411); -- the value of the menu item. This can be a string also.
 --info.func = function() ProfessionData_OnClick() end; --sets the function to execute when this item is clicked
 info.owner = this:GetParent(); --binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menues.
 info.checked = nil; --initially set the menu item to being unchecked with a yellow tick
 info.icon = nil; --we can use this to set an icon for the drop down menu item to accompany the text
 UIDropDownMenu_AddButton(info, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu

 --Engineering
 info.text = GetSpellInfo(4036); --the text of the menu item
 info.func = function() ProfessionData_OnClick() end;
 info.value = GetSpellInfo(4036); -- the value of the menu item. This can be a string also.
 --info.func = function() ProfessionData_OnClick() end; --sets the function to execute when this item is clicked
 info.owner = this:GetParent(); --binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menues.
 info.checked = nil; --initially set the menu item to being unchecked with a yellow tick
 info.icon = nil; --we can use this to set an icon for the drop down menu item to accompany the text
 UIDropDownMenu_AddButton(info, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu

 --Inscription
 info.text = GetSpellInfo(45357); --the text of the menu item
 info.func = function() ProfessionData_OnClick() end;
 info.value = GetSpellInfo(45357); -- the value of the menu item. This can be a string also.
 --info.func = function() ProfessionData_OnClick() end; --sets the function to execute when this item is clicked
 info.owner = this:GetParent(); --binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menues.
 info.checked = nil; --initially set the menu item to being unchecked with a yellow tick
 info.icon = nil; --we can use this to set an icon for the drop down menu item to accompany the text
 UIDropDownMenu_AddButton(info, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu

 --Jewelcrafting
 info.text = GetSpellInfo(25229); --the text of the menu item
 info.func = function() ProfessionData_OnClick() end;
 info.value = GetSpellInfo(25229); -- the value of the menu item. This can be a string also.
 --info.func = function() ProfessionData_OnClick() end; --sets the function to execute when this item is clicked
 info.owner = this:GetParent(); --binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menues.
 info.checked = nil; --initially set the menu item to being unchecked with a yellow tick
 info.icon = nil; --we can use this to set an icon for the drop down menu item to accompany the text
 UIDropDownMenu_AddButton(info, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu

 --Leatherworking
 info.text = GetSpellInfo(2108); --the text of the menu item
 info.func = function() ProfessionData_OnClick() end;
 info.value = GetSpellInfo(2108); -- the value of the menu item. This can be a string also.
 --info.func = function() ProfessionData_OnClick() end; --sets the function to execute when this item is clicked
 info.owner = this:GetParent(); --binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menues.
 info.checked = nil; --initially set the menu item to being unchecked with a yellow tick
 info.icon = nil; --we can use this to set an icon for the drop down menu item to accompany the text
 UIDropDownMenu_AddButton(info, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu

 --Tailoring
 info.text = GetSpellInfo(3908); --the text of the menu item
 info.func = function() ProfessionData_OnClick() end;
 info.value = GetSpellInfo(3908); -- the value of the menu item. This can be a string also.
 --info.func = function() ProfessionData_OnClick() end; --sets the function to execute when this item is clicked
 info.owner = this:GetParent(); --binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menues.
 info.checked = nil; --initially set the menu item to being unchecked with a yellow tick
 info.icon = nil; --we can use this to set an icon for the drop down menu item to accompany the text
 UIDropDownMenu_AddButton(info, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu

 --Mining
 info.text = GetSpellInfo(3564); --the text of the menu item
 info.func = function() ProfessionData_OnClick() end;
 info.value = GetSpellInfo(3564); -- the value of the menu item. This can be a string also.
 --info.func = function() ProfessionData_OnClick() end; --sets the function to execute when this item is clicked
 info.owner = this:GetParent(); --binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menues.
 info.checked = nil; --initially set the menu item to being unchecked with a yellow tick
 info.icon = nil; --we can use this to set an icon for the drop down menu item to accompany the text
 UIDropDownMenu_AddButton(info, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu

  --FirstAid
 info.text = GetSpellInfo(45542); --the text of the menu item
 info.func = function() ProfessionData_OnClick() end;
 info.value = GetSpellInfo(45542); -- the value of the menu item. This can be a string also.
 --info.func = function() ProfessionData_OnClick() end; --sets the function to execute when this item is clicked
 info.owner = this:GetParent(); --binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menues.
 info.checked = nil; --initially set the menu item to being unchecked with a yellow tick
 info.icon = nil; --we can use this to set an icon for the drop down menu item to accompany the text
 UIDropDownMenu_AddButton(info, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu

 --Misc
 info.text = "Misc"; --the text of the menu item
 info.func = function() ProfessionData_OnClick() end;
 info.value = "Misc"; -- the value of the menu item. This can be a string also.
 --info.func = function() ProfessionData_OnClick() end; --sets the function to execute when this item is clicked
 info.owner = this:GetParent(); --binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menues.
 info.checked = nil; --initially set the menu item to being unchecked with a yellow tick
 info.icon = nil; --we can use this to set an icon for the drop down menu item to accompany the text
 UIDropDownMenu_AddButton(info, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu
end

function ProfessionData_OnClick()
  UIDropDownMenu_SetSelectedValue(this.owner, this.value);
end

function FlaskCalc:ViewSaveButton_OnClick()
    for i = 1,3 do
        local MatNameData = _G["ViewMatButton".. i .. "NameData"];
        local MatQuantityData = _G["ViewMatButton".. i .. "QuantityData"];
        if TheMats[i] ~= nil then
            TheMats[i][1] = MatNameData:GetText();
            TheMats[i][2] = MatQuantityData:GetText();
        end
    end
    local valid = true;
    local newRecipe = {};
    local ErrorString = "";

    if theFrame.NameData:GetText() == "" then
        valid = false;
        message("Recipe name must not be empty, Please Correct");
    end
    newRecipe = {};
    newRecipe.Name = theFrame.NameData:GetText();
    newRecipe.Quantity = theFrame.MakesData:GetText();
    newRecipe.DesiredAmount = theFrame.DesiredAmountData:GetText();
    newRecipe.Profession = UIDropDownMenu_GetSelectedValue(theFrame.ProfessionData);
    newRecipe.Mats = {};
    for i=1,getn(Mats) do
        table.insert(newRecipe.Mats,{Mats[i][1],Mats[i][2]});
    end
    if mode == "New" then

        newRecipe.ID = self.db.profile.nextFreeID;
        self.db.profile.nextFreeID = self.db.profile.nextFreeID+1;
        if valid then
            valid = FlaskCalc:IsUnique(newRecipe);
            if valid == false then
                message("Recipe must be unique it cannot have the same name and mats as another recipe, Please Correct");
            end
        end
    else
        if valid and FlaskCalc:CloneCount(newRecipe) ~= 0 then
            if  FlaskCalc:CloneCount(newRecipe) ~= 1 and editing.DesiredAmount == newRecipe.DesiredAmount then
                self:Print(FlaskCalc:CloneCount(newRecipe));
                valid = false;
            end
        end
    end

    if valid then
        if UIDropDownMenu_GetSelectedValue(theFrame.ProfessionData) == nil then
            valid = false;
            message(L["Recipe profession must be selected, Please Correct"]);
        end
    end

    if valid then
        valid = FlaskCalc:IsNumber(theFrame.DesiredAmountData:GetText());
        if valid == false then
            message(L["Desired Stack Size must be a valid number, Please Correct"]);
        end
    end

    if valid then
        valid = FlaskCalc:IsNumber(theFrame.MakesData:GetText());
        if valid == false then
            message(L["Makes Per Craft must be a valid number, Please Correct"]);
        end
    end

    if valid then
        local division = tonumber(theFrame.DesiredAmountData:GetText())/tonumber(theFrame.MakesData:GetText())
        if division ~= math.floor(division) then
            valid = false;
            message(L["Desired Stack Size must be a multiple of Makes Per Craft, Please Correct"]);
        end
    end

    if valid then

        if getn(Mats) == 0 then
            valid = false;
            message(L["At least one mat must be specified, Please Correct"]);
        end
    end

    if valid then
        for i=1,getn(Mats) do
            if Mats[i][1] == "" or FlaskCalc:IsNumber(Mats[i][2]) == false then
                valid = false;
            end
        end
        if valid == false then
            message("Incorrect Mat Data Found, Please Correct");
        end
    end

    if valid then
        FlaskCalc:DoSave(newRecipe);
    else
        self:Print("Invalid");
    end
end

function FlaskCalc:IsNumber(Input)
    local match = string.match(Input,"^%d+$");
    if match == nil then
        return false;
    else
        if tonumber(Input) > 0 then
            return true;
        else
            return false;
        end
    end
end

function FlaskCalc:DoSave(NewRecipe)
    if mode == "New" then
        self.db.profile.nextFreeID = self.db.profile.nextFreeID+1;
        NewRecipe.HasCooldown = theFrame.Cooldown:GetChecked();
        table.insert(self.db.profile.customRecipes,NewRecipe);
    else
        if tonumber(editing.ID) > 1000 or FlaskCalc:IsOveridden(editing.ID) == true then
            editing.Name = theFrame.NameData:GetText();
            editing.Profession = UIDropDownMenu_GetSelectedValue(theFrame.ProfessionData);
            editing.Quantity = theFrame.MakesData:GetText();
            editing.DesiredAmount = theFrame.DesiredAmountData:GetText();
            editing.HasCooldown = theFrame.Cooldown:GetChecked();
            editing.Mats = {};
            for i=1,getn(Mats) do
                table.insert(editing.Mats,{Mats[i][1],Mats[i][2]});
            end
        else
            local overide = {};
            overide.ID = editing.ID;
            self:Print("overiding "..editing.ID);
            overide.Profession = UIDropDownMenu_GetSelectedValue(theFrame.ProfessionData);
            overide.Name = theFrame.NameData:GetText();
            overide.Quantity = theFrame.MakesData:GetText();
            overide.DesiredAmount = theFrame.DesiredAmountData:GetText();
            overide.Mats = {};
            for i=1,getn(Mats) do
                table.insert(overide.Mats,{Mats[i][1],Mats[i][2]});
            end
            overide.HasCooldown = theFrame.Cooldown:GetChecked();
            table.insert(self.db.profile.customRecipes,overide);
        end
    end
    
    -- Sort all items in the list
    table.sort(self.db.profile.customRecipes,function(a,b)
        return string.lower(a.Profession..": "..a.Name) < string.lower(b.Profession..": "..b.Name);
    end);

    FlaskCalc:HideViewRecipes();
end

function FlaskCalc:DeleteMatButton_OnClick()
    table.remove(Mats,selectedid);
    selectedid = nil;
    self:ViewRecipeFrame_Update();
end

function FlaskCalc:ViewMatSelect(ButtonId)
    local offset = FauxScrollFrame_GetOffset(theFrame.ScrollFrame);
    local newselectedid = offset+ButtonId;
    selectedid = newselectedid;
    self:ViewRecipeFrame_Update();
end

function FlaskCalc:AddMatButton_OnClick()
    table.insert(Mats,{"",0});
    self:ViewRecipeFrame_Update();
end


function FlaskCalc:ViewRecipeFrame_Update()
    if mode == "New" then
        theFrame.Title:SetText(L["Create a New Recipe"]);
        theFrame.SaveButton:SetText(L["Create"]);
        theFrame.NameData:Show();
        theFrame.NameText:Hide();
    else
        theFrame.Title:SetText(L["Editing Recipe"]);
        theFrame.SaveButton:SetText(L["Save"]);
        theFrame.NameData:Show();
        theFrame.NameText:Hide();
    end

    local offset = FauxScrollFrame_GetOffset(theFrame.ScrollFrame);
    theFrame.DeleteMatButton:Disable();

    for i = 1,3 do
        local MatEntry = theFrame.Mats[i];
        local index = offset + i;
        if index <= getn(Mats) then
            local currentMat = Mats[index];
            local MatNameData = _G["ViewMatButton".. i .. "NameData"];
            local MatQuantityData = _G["ViewMatButton".. i .. "QuantityData"];
            MatEntry:Show();
            if index == selectedid then
                MatEntry:LockHighlight();
                theFrame.DeleteMatButton:Enable();
            else
                MatEntry:UnlockHighlight();
            end
            if TheMats[i] ~= nil then
                TheMats[i][1] = MatNameData:GetText();
                TheMats[i][2] = MatQuantityData:GetText();
            end
            MatNameData:SetText(currentMat[1]);
            MatNameData:SetCursorPosition(0);
            MatNameData:ClearFocus();
            MatQuantityData:SetText(currentMat[2]);
            MatQuantityData:SetCursorPosition(0);
            MatQuantityData:ClearFocus();
            TheMats[i] = currentMat;

        else
            TheMats[i] = nil;
            MatEntry:Hide();
        end
    end
    FauxScrollFrame_Update(theFrame.ScrollFrame, table.getn(Mats),3, 21);

end

function FlaskCalc:IsNewOpen()
    return isOpen and mode == "New";
end

function FlaskCalc:IsEditOpen(Recipe)
    return isOpen and mode == "Edit" and editing == Recipe;
end
