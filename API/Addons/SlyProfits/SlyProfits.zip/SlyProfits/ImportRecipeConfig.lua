﻿-------------------------------------------------------------------------------
-- RecipeConfig.lua
--
-- Configuration Window to control recipes
-------------------------------------------------------------------------------

local AceGUI = LibStub("AceGUI-3.0");
local theFrame = nil;
local SelectedItems = {};
local LastClick = nil;
local RecipeFrame = nil;
local AllImports = {};
local isOpen = false;

-- Localization
local L = LibStub("AceLocale-3.0"):GetLocale("SlyProfits")


function FlaskCalc:ImportRecipes(RecipeConfigFrame)
    RecipeFrame = RecipeConfigFrame;
    self:CreateImportWindow();

    theFrame:Show();
    isOpen = true;
    theFrame:SetFrameLevel(4000);
    self:ImportRecipeFrame_Update();
end

function FlaskCalc:HideImportRecipes()
    if theFrame ~=  nil then
        theFrame:Hide();
        isOpen = false;
        self:ConfigRecipeFrame_Update();
    end
end

function FlaskCalc:CreateImportWindow()
    if theFrame == nil then
        theFrame=CreateFrame("Frame",nil,UIParent);

        theFrame:ClearAllPoints();
        theFrame:SetPoint("TOPLEFT",RecipeFrame,"BOTTOMLEFT",10,0);
        theFrame:SetPoint("TOPRIGHT",RecipeFrame,"BOTTOMRIGHT",-25,0);
        theFrame:SetWidth(330);
        theFrame:SetHeight(240);

        theFrame:SetBackdrop( {
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32,
            insets = { left = 11, right = 12, top = 12, bottom = 11 }
        });
        theFrame.TopLeftBorder=theFrame:CreateTexture(nil,"OVERLAY",nil);
        theFrame.TopLeftBorder:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Corner");
        theFrame.TopLeftBorder:SetHeight(32);
        theFrame.TopLeftBorder:SetWidth(32);
        theFrame.TopLeftBorder:SetPoint("TOPRIGHT",theFrame,"TOPRIGHT",-6,-7);

        theFrame.Title=theFrame:CreateFontString(nil,"OVERLAY","GameFontHighlight");
        theFrame.Title:SetPoint("TOP",theFrame,"TOP",0,-17);
        theFrame.Title:SetHeight(14);
        theFrame.Title:SetWidth(200);
        theFrame.Title:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.Title:SetText(L["Import Tradeskills into SlyProfits"]);

        theFrame.DataLabel=theFrame:CreateFontString(nil,"OVERLAY","GameFontHighlight");
        theFrame.DataLabel:SetPoint("TOPLEFT",theFrame,"TOPLEFT",20,-37);
        theFrame.DataLabel:SetHeight(14);
        theFrame.DataLabel:SetWidth(100);
        theFrame.DataLabel:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b);
        theFrame.DataLabel:SetText(L["Profession Data"]..":");

        theFrame.NoDataMessage=theFrame:CreateFontString(nil,"OVERLAY","GameFontHighlight");
        theFrame.NoDataMessage:SetPoint("LEFT",theFrame.DataLabel,"RIGHT",0,0);
        theFrame.NoDataMessage:SetHeight(14);
        theFrame.NoDataMessage:SetWidth(200);
        theFrame.NoDataMessage:SetText(L["No Data Found"]);
        theFrame.NoDataMessage:Hide();

        theFrame.ScrollFrameBackground=CreateFrame("Frame",nil,theFrame);
        theFrame.ScrollFrameBackground:SetWidth(330);
        theFrame.ScrollFrameBackground:SetHeight(149);
        theFrame.ScrollFrameBackground:SetPoint("TOPLEFT",theFrame.DataLabel,"BOTTOMLEFT",-11,5);
        theFrame.ScrollFrameBackground:SetBackdrop( {
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32,
            insets = { left = 11, right = 12, top = 12, bottom = 11 }
        });

        theFrame.ScrollFrame=CreateFrame("ScrollFrame","ImportRecipeScroller",theFrame,"ImportRecipeScrollFrame");
        theFrame.ScrollFrame:SetPoint("TOPLEFT",theFrame.DataLabel,"BOTTOMLEFT",0,-7);


        theFrame.Recipes = {};
        local previous = theFrame.DataLabel;
        for i = 1,6 do
            local RecipeEntry = CreateFrame("Button","ImportRecipeButton"..i,theFrame,"ImportRecipeItemTemplate");

            table.insert(theFrame.Recipes,RecipeEntry);
            if i == 1 then
                RecipeEntry:SetPoint("TOPLEFT",theFrame.DataLabel,"BOTTOMLEFT",0,-7);
            else
                RecipeEntry:SetPoint("TOPLEFT",previous,"BOTTOMLEFT",0,0);
            end
            RecipeEntry:SetID(i);
            previous = RecipeEntry;
        end

        theFrame.Instructions=theFrame:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");
        theFrame.Instructions:SetPoint("BOTTOM",theFrame,"BOTTOM",0,17);
        theFrame.Instructions:SetHeight(14);
        theFrame.Instructions:SetWidth(300);
        theFrame.Instructions:SetTextColor(0.5,0.5,0.5);
        theFrame.Instructions:SetText(L["Please open the profession you wish to import"]);

        theFrame.CloseCross=CreateFrame("Button",nil,theFrame,"UIPanelCloseButton");
        theFrame.CloseCross:SetPoint("TOPRIGHT",theFrame,"TOPRIGHT",-2,-3);
        theFrame.CloseCross:SetScript("OnClick",function() FlaskCalc:HideImportRecipes() end);

--[[
        theFrame.ShowAllImports=CreateFrame("CheckButton","ShowAllImports",theFrame,"OptionsSmallCheckButtonTemplate");
        theFrame.ShowAllImports:SetPoint("TOPLEFT",theFrame.ScrollFrame,"BOTTOMLEFT",0,0);
        theFrame.ShowAllImports:SetScript("OnClick",function() FlaskCalc:ShowAllImportsCheckboxClicked() end);
        theFrame.ShowAllImports:SetChecked(self.db.profile.showAllImports);
        theFrame.ShowAllImportsText = _G["ShowAllImportsText"];
        theFrame.ShowAllImportsText:SetText("Show All");
]]--

        theFrame.ImportButton=CreateFrame("Button",nil,theFrame,"UIPanelButtonTemplate");
        theFrame.ImportButton:SetWidth(82)
        theFrame.ImportButton:SetHeight(25)
        theFrame.ImportButton:SetPoint("TOPRIGHT",theFrame.ScrollFrame,"BOTTOMRIGHT",0,0);
        theFrame.ImportButton:SetScript("OnClick",function() FlaskCalc:ImportRecipeButton_OnClick(); end);
        theFrame.ImportButton:SetText("Import")

        theFrame.ImportAllButton=CreateFrame("Button",nil,theFrame,"UIPanelButtonTemplate");
        theFrame.ImportAllButton:SetWidth(92)
        theFrame.ImportAllButton:SetHeight(25)
        theFrame.ImportAllButton:SetPoint("TOPRIGHT",theFrame.ImportButton,"TOPLEFT",-10,0);
        theFrame.ImportAllButton:SetScript("OnClick",function() FlaskCalc:ImportAllRecipeButton_OnClick(); end);
        theFrame.ImportAllButton:SetText("Import All")

        theFrame:EnableMouse(true);
        theFrame:SetMovable(false);
    else

    end
	theFrame:Hide()
end

--[[
function FlaskCalc:ShowAllImportsCheckboxClicked()
    self.db.profile.showAllImports = (theFrame.ShowAllImports:GetChecked() ~= nil);
    self:ImportRecipeFrame_Update();
end
]]--


-- Import selected recipe(s)
function FlaskCalc:ImportRecipeButton_OnClick()
    for i = 1,getn(AllImports) do
        if SelectedItems[AllImports[i]] == true then
            local selected = AllImports[i];
            selected.ID = self.db.profile.nextFreeID;
            self.db.profile.nextFreeID = self.db.profile.nextFreeID+1;
            
            -- Sort mats
            table.sort(selected.Mats,function(a,b)
                return string.lower(a[1]) < string.lower(b[1]);
            end);  

            table.insert(self.db.profile.customRecipes,selected);
        end
    end
    
    -- Update import frame
    theFrame.ImportButton:Disable();
    self:ImportRecipeFrame_Update();
    
    -- Sort all items in the list
    table.sort(self.db.profile.customRecipes,function(a,b)
        return string.lower(a.Profession..": "..a.Name) < string.lower(b.Profession..": "..b.Name);
    end);
    
    -- update recipe frame
    FlaskCalc:ConfigRecipeFrame_Update();
    SelectedItems = {};
    LastClick = nil;
end

-- Select all and then do the same as if all items had been selected manually
function FlaskCalc:ImportAllRecipeButton_OnClick()
    for i = 1,getn(AllImports) do
        if FlaskCalc:IsUnique(AllImports[i]) == true then
            SelectedItems[AllImports[i]] = true;
        end
    end
    
    FlaskCalc:ImportRecipeButton_OnClick();
end

function FlaskCalc:FlaskTradeSkillRecord()

    local profession, _, _ = GetTradeSkillLine();
    if profession == GetSpellInfo(2259) or      -- Alchemy
        profession == GetSpellInfo(3100) or     -- Blacksmithing
        profession == GetSpellInfo(2550) or     -- Cooking
        profession == GetSpellInfo(7411) or     -- Enchanting
        profession == GetSpellInfo(4036) or     -- Engineering
        profession == GetSpellInfo(45357) or    -- Inscription
        profession == GetSpellInfo(25229) or    -- Jewelcrafting
        profession == GetSpellInfo(2108) or     -- Leatherworking
        profession == GetSpellInfo(3908) or     -- Tailoring
        profession == GetSpellInfo(3564) or     -- Mining
        profession == GetSpellInfo(45542) then	-- FirstAid
        AllImports = {};

        local serverRequest = false;

        for i=1,GetNumTradeSkills() do

            local name, type, _, _, _ = GetTradeSkillInfo(i);
            local makesLink = nil
            local isLinked = IsTradeSkillLinked();

            if (name and type ~= "header") then
                local bad = false;
                
                -- item / enchant link
                local link = GetTradeSkillItemLink(i);
                if link then
                
                    --Get item name from link to see if
                    -- 1) item is available in cache
                    -- 2) it really is an item link
                    local itemName, itemLink = GetItemInfo(link);
                    if itemName ~= nil then
                        
                        -- link is an item link of an item already in cache
                        name = itemName;
                        
                        --[===[@debug@
                        -- Item data was found, remove itemLink and spellLink from "notFoundData" table
                        local found, _, spellId = string.find(link, "^|%x+|Henchant:(.+)|h%[.+%]")
                        if found ~= nil then
                            self.db.profile.notFoundData[spellId] = nil
                        end
                        
                        local found, _, itemId  = string.find(itemLink, "^|%x+|Hitem:(.+)|h%[.+%]")
                        if found ~= nil then
                            self.db.profile.notFoundData[itemId] = nil
                        end
                        --@end-debug@]===]
                        
                    else
                    	-- get info from server for the next time
						GameTooltip:SetHyperlink(link);

                    	-- Check if it is an enchanting link, get ID from link and
                    	-- check if the ID is available in the internal list
                    	local found, _, spellId = string.find(link, "^|%x+|Henchant:(.+)|h%[.+%]")

                        if found ~= nil then
                            -- It's an enchant link, check if it is found in the internal db
                        	local itemId = FlaskCalc:FindResult(spellId);

	                        if itemId ~= nil then
								
								--[===[@debug@
		                        -- Enchant ID was found in internal DB, remove it
		                        self.db.profile.notFoundData[spellId] = nil
		                        --@end-debug@]===]
								
								itemName, itemLink = GetItemInfo(itemId);

								if itemName ~= nil then
                        			name = itemName;
                        			
			                        --[===[@debug@
                        			-- item from internal db was found, remove it from "notFoundData" if it was present
			                        self.db.profile.notFoundData[itemId] = nil
			                        --@end-debug@]===]
                        		else
                                    bad = true;

                                    -- get info from server for the next time
									GameTooltip:SetHyperlink("|Hitem:"..itemId.."|hbla|h");
									serverRequest = true;

                                    --[===[@debug@
                                    -- item determided from internal db was not found, add to "notFoundData"
                                    self.db.profile.notFoundData[itemId] = 2
                                    --@end-debug@]===]
                        		end
							else
	                            bad = true;

								-- No data was found in the internal db
		                        --[===[@debug@
		                        self.db.profile.notFoundData[spellId] = 1
		                        --@end-debug@]===]
							end
						else
							-- No enchant link, but item was still not found
                            bad = true;

							--serverRequest = true;
						end
                    end
                    makesLink = itemLink;
                else
                    bad = true;
                    self:Print("No Link:"..name);
                end

				if bad == false then
	                local Recipe = {};
	                Recipe.Name = name;
	                --TODO: Check if link is actually required or could be removed
	                Recipe.ItemLink = makesLink;
	                Recipe.Profession = profession;
	                Recipe.Quantity = GetTradeSkillNumMade(i);
	                Recipe.DesiredAmount = Recipe.Quantity;
	                Recipe.IsLinked = isLinked;
	                Recipe.StaticCostPerItem = 0;
	                Recipe.Mats = {};

	                local numMats = GetTradeSkillNumReagents(i);
	                for j=1, numMats, 1 do
	                    local MatName, _, MatCount, _ = GetTradeSkillReagentInfo(i, j);
	                    if MatName == nil then
	                        bad = true;
	                    end
	                    Recipe.Mats[j] = {MatName,MatCount};
	                end

	                if bad == false then
	                    table.insert(AllImports,Recipe);
	                end
	            end
            end
        end

		if serverRequest == true then
			self:Print("Some item data was requested from the server and should be available the next time you perform this action.");
		end

        table.sort(AllImports,function(a,b)
            return string.lower(a.Profession..": "..a.Name) < string.lower(b.Profession..": "..b.Name);
        end);
        if theFrame ~= nil then
            self:ImportRecipeFrame_Update();
        end
    end
end



function FlaskCalc:ImportRecipeSelect(id)
    -- Unless we're holding control, this is a new selection.
    local offset = FauxScrollFrame_GetOffset(theFrame.ScrollFrame);

    if LastClick ~= nil and IsShiftKeyDown() then
      -- Shift is down and we have a previous click.
      -- Add all items in this range to the selection.
        local lower = offset + id;
        local upper = offset + id;
        if not IsControlKeyDown() then
            SelectedItems = {};
        end
        if LastClick < offset + id then
            lower = LastClick;
        else
            upper = LastClick;
        end

        local i;
        for i = lower, upper do
            if FlaskCalc:IsUnique(AllImports[i]) == true then
                SelectedItems[AllImports[i]] = true;
            end
        end
    else
        -- No shift, or first click; add only the current item to the selection.
        -- If control is down, toggle the item.
        if FlaskCalc:IsUnique(AllImports[offset+id]) == true then
            LastClick = offset + id;
            if not IsControlKeyDown() then
                SelectedItems = {};
            end
            local listing = AllImports[offset + id];
            if IsControlKeyDown() and SelectedItems[listing] then
                SelectedItems[listing] = nil;
            else
                SelectedItems[listing] = true;
            end
        else
        end
    end
    self:ImportRecipeFrame_Update();
end

function FlaskCalc:ImportRecipeButton_OnEnter(Button)
    local ButtonId = Button:GetID();
    local offset = FauxScrollFrame_GetOffset(theFrame.ScrollFrame);
    local hover = AllImports[offset+ButtonId];
    GameTooltip:SetOwner(Button, "ANCHOR_RIGHT")

    GameTooltip:SetText(hover.Profession..": "..hover.Name, 1, 1, 1);
    GameTooltip:AddLine(L["Makes"]..": "..hover.Quantity, nil, nil, nil, 1);
    GameTooltip:AddLine(L["Desired Stack Size"]..": "..hover.DesiredAmount, nil, nil, nil, 1);
    GameTooltip:AddLine(L["Mats"]..": ", nil, nil, nil, 1);
    for i = 1,getn(hover.Mats) do
        GameTooltip:AddLine("     "..hover.Mats[i][2].."x "..hover.Mats[i][1], nil, nil, nil, 1);
    end
    GameTooltip:Show();
end

function FlaskCalc:ImportRecipeFrame_Update()
    local offset = FauxScrollFrame_GetOffset(theFrame.ScrollFrame);
    theFrame.ImportButton:Disable();
    for i = 1,6 do
        local RecipeEntry = theFrame.Recipes[i];
        local index = offset + i;
        if index <= getn(AllImports) then
            local tradeskill = AllImports[index];
            local RecipeButtonDetail = _G["ImportRecipeButton".. i .. "Detail"];
            local RecipeButtonDetailName = _G["ImportRecipeButton".. i .. "DetailName"];
            RecipeButtonDetail:Show();
            RecipeEntry:Show();
            if FlaskCalc:IsUnique(tradeskill) == false then
                RecipeButtonDetailName:SetText("|c88888888" .. tradeskill.Profession .. ": "..tradeskill.Name .. "|r");
                RecipeEntry:UnlockHighlight();
            else
                if SelectedItems[tradeskill] == true then
                    RecipeEntry:LockHighlight();
                    theFrame.ImportButton:Enable();
                else
                    RecipeEntry:UnlockHighlight();
                end

                RecipeButtonDetailName:SetText("|cffffffff" .. tradeskill.Profession .. ": "..tradeskill.Name .. "|r");
            end

        else
            RecipeEntry:Hide();
        end
    end
    if getn(AllImports) == 0 then
        theFrame.NoDataMessage:Show();
    else
        theFrame.NoDataMessage:Hide();
    end
    FauxScrollFrame_Update(theFrame.ScrollFrame, table.getn(AllImports),6, 21);
end

function FlaskCalc:IsImportOpen()
    return isOpen;
end
