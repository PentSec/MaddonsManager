--[[
    SlyProfits Localization file: German
--]]

local L = LibStub("AceLocale-3.0"):NewLocale("SlyProfits", "deDE")
if not L then return end

L["Advanced Mode"] = "Advanced Mode"
L["At least one mat must be specified, Please Correct"] = "Mindestens eine Zutat muss definiert sein, bitte korrigieren."
L["Buyout Per Item"] = "Kaufpreis pro Item"
L["Buyout Total"] = "Gesamter Kaufpreis"
L["Calculates the resale of excess mats, nested recipes and elixir master procs"] = "Berücksichtigt den Wiederverkauf von überzähligen Zutaten, verschachtelte Rezepte und Elixiermeister-Procs"
L["Cost Total"] = "Gesamte Kosten"
L["Create"] = "Erstellen"
L["Create a New Recipe"] = "Neues Rezept erstellen"
L["Desired Stack Size"] = "Gewünschte Stapelgröße"
L["Desired Stack Size must be a multiple of Makes Per Craft, Please Correct"] = "Gewünschte Stapelgröße muss ein Vielfaches von \"Ergibt pro Herstellung\" sein, bitte korrigieren."
L["Desired Stack Size must be a valid number, Please Correct"] = "Gewünschte Stapelgröße muss eine gültige Zahl sein, bitte korrigieren."
L["Editing Recipe"] = "Rezept bearbeiten"
L["Filter Recipes By Current Profession"] = "Rezepte nach eigenen Berufen filtern"
L["Import Tradeskills into SlyProfits"] = "Rezepte in SlyProfits importieren"
L["Item"] = "Item"
L["Makes"] = "Ergibt"
L["Makes Per Craft"] = "Ergibt pro Herstellung"
L["Makes Per Craft must be a valid number, Please Correct"] = "\"Ergibt pro Herstellung\" muss eine gültige Zahl sein, bitte korrigieren."
L["Mats"] = "Zutaten"
L["Name"] = "Name"
L["No Data Found"] = "Keine Daten gefunden"
L["Please open the profession you wish to import"] = "Bitte Beruf zum Importieren öffnen"
L["Profession"] = "Beruf"
L["Profession Data"] = "Berufsdaten"
L["Profit Total"] = "Gesamter Profit"
L["Recipe profession must be selected, Please Correct"] = "Beruf muss ausgewählt sein, bitte korrigieren."
L["Save"] = "Speichern"
L["Searching"] = "Suche:"
L["Time Elapsed"] = "Verstrichene Zeit"
L["Time Remaining"] = "Verbleibende Zeit:"
L["Use Inventory"] = "Inventar berücksichtigen"
L["has Cooldown?"] = "hat Cooldown?"

