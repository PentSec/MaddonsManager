--[[
    SlyProfits Localization file: French
--]]

local L = LibStub("AceLocale-3.0"):NewLocale("SlyProfits", "frFR")
if not L then return end

L["Advanced Mode"] = "Mode avancé"
-- L["At least one mat must be specified, Please Correct"] = ""
L["Buyout Per Item"] = "Achat immédiat par élément"
L["Buyout Total"] = "Achat immédiat en lot"
-- L["Calculates the resale of excess mats, nested recipes and elixir master procs"] = ""
L["Cost Total"] = "Coût total"
L["Create"] = "Créer"
L["Create a New Recipe"] = "Créer une nouvelle recette"
L["Desired Stack Size"] = "Taille de la pile désirée"
-- L["Desired Stack Size must be a multiple of Makes Per Craft, Please Correct"] = ""
-- L["Desired Stack Size must be a valid number, Please Correct"] = ""
L["Editing Recipe"] = "Editer une recette"
-- L["Filter Recipes By Current Profession"] = ""
-- L["Import Tradeskills into SlyProfits"] = ""
-- L["Item"] = ""
-- L["Makes"] = ""
-- L["Makes Per Craft"] = ""
-- L["Makes Per Craft must be a valid number, Please Correct"] = ""
-- L["Mats"] = ""
L["Name"] = "Nom"
L["No Data Found"] = "Aucune information trouvée"
L["Please open the profession you wish to import"] = "SVP, ouvrez le métier que vous voulez importer"
L["Profession"] = "Métier"
L["Profession Data"] = "Données de métier"
L["Profit Total"] = "Bénéfices"
-- L["Recipe profession must be selected, Please Correct"] = ""
L["Save"] = "Sauvegarder"
L["Searching"] = "Chercher"
L["Time Elapsed"] = "Temps écoulé"
L["Time Remaining"] = "Temps restant"
L["Use Inventory"] = "Utiliser l'inventaire"
-- L["has Cooldown?"] = ""
