--[[
    SlyProfits Localization file: Chinese
--]]

local L = LibStub("AceLocale-3.0"):NewLocale("SlyProfits", "zhCN")
if not L then return end

L["Advanced Mode"] = "高级模式"
L["At least one mat must be specified, Please Correct"] = "必须指定一个，请更正"
L["Buyout Per Item"] = "一口价每件物品"
L["Buyout Total"] = "一口价合计"
-- L["Calculates the resale of excess mats, nested recipes and elixir master procs"] = ""
L["Cost Total"] = "金额合计"
L["Create"] = "制作"
L["Create a New Recipe"] = "制作一个新配方"
L["Desired Stack Size"] = "所需堆叠大小"
L["Desired Stack Size must be a multiple of Makes Per Craft, Please Correct"] = "每个商品所需的堆叠大小必须是有效的，请更正"
L["Desired Stack Size must be a valid number, Please Correct"] = "所需的堆叠大小必须是有效的，请更正"
L["Editing Recipe"] = "编辑配方"
L["Filter Recipes By Current Profession"] = "过滤当前专业的配方"
L["Import Tradeskills into SlyProfits"] = "导入 Tradeskills 到 SlyProfits"
L["Item"] = "物品"
L["Makes"] = "制作"
L["Makes Per Craft"] = "制作商品"
L["Makes Per Craft must be a valid number, Please Correct"] = "商品数量必须是有效的，请更正"
L["Mats"] = "粗糙"
L["Name"] = "名称"
L["No Data Found"] = "未找到数据"
L["Please open the profession you wish to import"] = "请打开专业框体导入你的信息"
L["Profession"] = "专业"
L["Profession Data"] = "专业数据"
L["Profit Total"] = "收益合计"
L["Recipe profession must be selected, Please Correct"] = "必须选择专业配方，请更正"
L["Save"] = "保存"
L["Searching"] = "搜索中"
L["Time Elapsed"] = "已用时间 "
L["Time Remaining"] = "剩余时间"
L["Use Inventory"] = "使用背包"
L["has Cooldown?"] = "在冷却？"
