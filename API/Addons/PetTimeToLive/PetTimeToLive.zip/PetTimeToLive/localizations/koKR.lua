-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/pet-time-to-live/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("PetTimeToLive", "koKR")
if not L then return end

L["|cffeda55fControl + Left Click|r to lock the frame"] = "|cffeda55fControl + 왼쪽 클릭|r 프레임 잠금"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55f드래그|r 창 이동"
L["|cffeda55fLeft Click|r to lock/unlock frame"] = "|cffeda55f왼쪽 클릭|r 프레임 잠금/이동"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55f우 클릭|r 설정 창 열기"

