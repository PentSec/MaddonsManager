-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/pet-time-to-live/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("PetTimeToLive", "zhCN")
if not L then return end

L["|cffeda55fControl + Left Click|r to lock the frame"] = "|cffeda55fCtrl + 左键点击|r 锁定框体"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55f拖拽|r 移动位置"
L["|cffeda55fLeft Click|r to lock/unlock frame"] = "|cffeda55f左键点击|r 锁定/解锁框体"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55f右击|r打开设置窗口"

