-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/pet-time-to-live/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("PetTimeToLive", "ruRU")
if not L then return end

L["|cffeda55fControl + Left Click|r to lock the frame"] = "|cffeda55fControl + Левый клик|r - закрепить область"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55f[Двигайте]|r для перемещения окна"
L["|cffeda55fLeft Click|r to lock/unlock frame"] = "|cffeda55fЛевый клик|r - закрепить/освободить область"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55f[Правый клик]|r открывает окно настроек"

