-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/pet-time-to-live/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("PetTimeToLive", "deDE")
if not L then return end


