-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/pet-time-to-live/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("PetTimeToLive", "zhTW")
if not L then return end

L["|cffeda55fControl + Left Click|r to lock the frame"] = "|cffeda55fCtrl + 左鍵點擊|r 鎖定框體"
L["|cffeda55fDrag|r to move the frame"] = "|cffeda55f拖拽|r 移動位置"
L["|cffeda55fLeft Click|r to lock/unlock frame"] = "|cffeda55f左鍵點擊|r 鎖定/解鎖框體"
L["|cffeda55fRight Click|r to open the configuration window"] = "|cffeda55f右擊|r打開設置視窗"

