--[[
Name: PetTimeToLive
Revision: $Revision: 57 $
Author(s): mitch0
Website: http://www.wowace.com/projects/pet-time-to-live
SVN: svn://svn.wowace.com/wow/pet-time-to-live/maguiInline/trunk
License: Public Domain
]]

local AppName = "PetTimeToLive"
local OptionsAppName = AppName .. "_Options"
local VERSION = AppName .. "-r" .. ("$Revision: 57 $"):match("%d+")

local LSM = LibStub:GetLibrary("LibSharedMedia-3.0", true)
local LDB = LibStub:GetLibrary("LibDataBroker-1.1")
local LibDualSpec = LibStub("LibDualSpec-1.0", true)
local L = LibStub("AceLocale-3.0"):GetLocale(AppName)

-- cached stuff

local GetPetTimeRemaining = GetPetTimeRemaining
local GetTotemInfo = GetTotemInfo
local GetTime = GetTime
local PlaySoundFile = PlaySoundFile

-- hard-coded config stuff

local DefaultBGTexture = "Blizzard Dialog Background"
local DefaultBGFile = [[Interface\DialogFrame\UI-DialogBox-Background]]
local DefaultEdgeTexture = "Blizzard Tooltip"
local DefaultEdgeFile = [[Interface\Tooltips\UI-Tooltip-Border]]
local DefaultBarTexture = "Blizzard"
local DefaultBarFile = [[Interface\TargetingFrame\UI-StatusBar]]
local DefaultFontName = "Friz Quadrata TT"
local DefaultFontPath = GameFontNormal:GetFont()
local DefaultFrameWidth = 48
local DefaultFrameHeight = 24
local DefaultSoundName = "Blizzard: Alarm Clock 1"
local DefaultSoundFile = [[Sound\Interface\AlarmClockWarning1.waw]]
local Icon = "Interface\\Icons\\INV_Battery_02"

local PtrScale = 1000
local MaxPtr = 10 * 60 * PtrScale
local NormalUpdateDelay = 1.0/10 -- update frequency == 1/NormalUpdateDelay
local WarningUpdateDelay = 1.0/25 -- update frequency while warning == 1/WarningUpdateDelay, must be <= NormalUpdateDelay
local BarModeUpdateDelay = 1.0/50 -- update frequency in bar-mode
local ElementalSpellIds = { [1] = 2894, [2] = 2062 }

-- internal vars

local _ -- throwaway
local db
local lastUpdate = 0 -- time since last real update
local updateDelay = NormalUpdateDelay
local maxValue = 0
local getPTR

local playerClass
local elementalNames = {}

---------------------------------

PetTimeToLive = LibStub("AceAddon-3.0"):NewAddon(AppName, "AceEvent-3.0")
local PetTimeToLive = PetTimeToLive

PetTimeToLive:SetDefaultModuleState(false)

PetTimeToLive.version = VERSION
PetTimeToLive.AppName = AppName
PetTimeToLive.OptionsAppName = OptionsAppName

-- Default DB stuff

local function makeColor(r, g, b, a)
    a = a or 1.0
    return { ["r"] = r, ["g"] = g, ["b"] = b, ["a"] = a }
end

local defaults = {
    profile = {
        locked = false,
        minimap = {},

        point = "CENTER",
        relPoint = "CENTER",
        x = 0,
        y = 50,

        color = makeColor(1.0, 0.82, 0),
        warnColor = makeColor(0.9, 0.065, 0.075),
        warnThreshold = 5.0,
        warnSound = true,
        warnSoundName = DefaultSoundName,

        font = DefaultFontName,
        fontSize = 16,
        fontOutline = "",
        strata = "HIGH",

        frameWidth = DefaultFrameWidth,
        frameHeight = DefaultFrameHeight,

        bgEnabled = true,
        bgTexture = DefaultBGTexture,
        bgBorderTexture = DefaultEdgeTexture,
        bgTile = false,
        bgTileSize = 32,
        bgEdgeSize = 16,
        bgColor = makeColor(0.2, 0.2, 0.2, 0.8),
        bgBorderColor = makeColor(0.8, 0.6, 0.0),
        barMode = false,
        barTexture = DefaultBarTexture,
        barColor = makeColor(0.11, 0.77, 0.88, 0.8),
    },
}

local function getInset()
    return math.floor(db.bgEdgeSize / 4)
end

local function getPTR_Default()
    local ptr = GetPetTimeRemaining()
    if not ptr or ptr >= MaxPtr or ptr <= 0 then
        -- ptr gets HUGE just before despawning the pet, probably a bug
        -- might need to change this logic if we want to support pets with longer than 10 min lifetime
        return nil
    end
    return ptr / PtrScale
end

local function getPTR_DK()
    local ptr = getPTR_Default()
    if not ptr then
        local _, _, start, duration = GetTotemInfo(1)
        if duration and duration > 0 then
            ptr = start + duration - GetTime()
            if ptr <= 0 then 
                ptr = nil
            end
        end
    end
    return ptr
end

local function getPTR_Shaman()
    local ptr = getPTR_Default()
    if not ptr then
        for i = 1, 2 do
            local _, name, start, duration = GetTotemInfo(1)
            if name == elementalNames[i] then
                ptr = start + duration - GetTime()
                if ptr <= 0 then 
                    ptr = nil
                end
            end
        end
    end
    return ptr
end

local function getPTR_Shaman_First()
    for i, spellId in ipairs(ElementalSpellIds) do
        elementalNames[i] = GetSpellInfo(spellId)
    end
    getPTR = getPTR_Shaman
    return getPTR()
end

function PetTimeToLive:setTextColor(color)
    self.text:SetTextColor(color.r, color.g, color.b, color.a)
end

function PetTimeToLive:start()
    self.mainFrame:Show()
    self:setTextColor(db.color)
    self:update()
end

function PetTimeToLive:stop()
    self.warned = nil
    self.text:SetText(nil)
    maxValue = 0
    if not db.barMode then
        updateDelay = NormalUpdateDelay
    end
    if db.locked then
        self.mainFrame:Hide()
    end
end

function PetTimeToLive:update()
    local ptr = getPTR()
    if not ptr then
        self:stop()
        return
    end
    if db.barMode then
        if ptr > maxValue then
            maxValue = ptr
            self.barFrame:SetMinMaxValues(0, maxValue)
        end
        self.barFrame:SetValue(ptr)
    end
    if ptr > 90 then
        self.text:SetFormattedText("%d:%02d", ptr / 60, ptr % 60)
    elseif ptr < db.warnThreshold then
        if db.disableDecimals then
            self.text:SetFormattedText("%d", ptr)
        else
            self.text:SetFormattedText("%.1f", ptr)
        end
        if not self.warned then
            self.warned = true
            if not db.barMode then
                updateDelay = WarningUpdateDelay
            end
            self:setTextColor(db.warnColor)
            if db.warnSound then
                local soundFile = LSM and LSM:Fetch("sound", db.warnSoundName) or DefaultSoundFile
                PlaySoundFile(soundFile)
            end
        end
    else
        self.text:SetFormattedText("%d", ptr)
    end
end

function PetTimeToLive:UNIT_PET(event, unitId)
    if unitId ~= "player" then return end
    if getPTR() then
        self:start()
    else
        self:stop()
    end
end

function PetTimeToLive:PLAYER_TOTEM_UPDATE()
    if getPTR() then
        self:start()
    else
        self:stop()
    end
end

function PetTimeToLive:mediaUpdate(event, mediaType, key)
    if mediaType == 'font' then
        if key == db.font then
            self:applyFontSettings()
        end
    elseif mediaType == 'background' then
        if key == db.bgTexture then
            self:applyBGSettings()
        end
    elseif mediaType == 'border' then
        if key == db.bgBorderTexture then
            self:applyBGSettings()
        end
    elseif mediaType == 'statusbar' then
        if key == db.barTexture then
            self:applyBarSettings()
        end
    end
end

function PetTimeToLive:applyBarSettings()
    if not db.barMode then
        self:hideBar()
        return
    end
    local barFile
    if LSM then
        barFile = LSM:Fetch("statusbar", db.barTexture, true)
        if not barFile then
            barFile = DefaultBarFile
            LSM.RegisterCallback(self, "LibSharedMedia_Registered", "mediaUpdate")
        end
    else
        barFile = DefaultBarFile
    end
    self.barFrame:SetStatusBarTexture(barFile)
    self.barFrame:SetStatusBarColor(db.barColor.r, db.barColor.g, db.barColor.b, db.barColor.a)
    updateDelay = BarModeUpdateDelay
    self:showBar()
end

function PetTimeToLive:applyBGSettings()
    if not db.bgEnabled then
        self.mainFrame:SetBackdrop(nil)
        self.barFrame:ClearAllPoints()
        self.barFrame:SetPoint("TOPLEFT", self.mainFrame, "TOPLEFT", 0, 0)
        self.barFrame:SetPoint("BOTTOMRIGHT", self.mainFrame, "BOTTOMRIGHT", 0, 0)
        return
    end
    self.bg = self.bg or { insets = {} }
    local bg = self.bg
    if LSM then
        bg.bgFile = LSM:Fetch("background", db.bgTexture, true)
        if not bg.bgFile then
            bg.bgFile = DefaultBGFile
            LSM.RegisterCallback(self, "LibSharedMedia_Registered", "mediaUpdate")
        end
        bg.edgeFile = LSM:Fetch("border", db.bgBorderTexture, true)
        if not bg.edgeFile then
            bg.edgeFile = DefaultEdgeFile
            LSM.RegisterCallback(self, "LibSharedMedia_Registered", "mediaUpdate")
        end
    else
        bg.bgFile = DefaultBGFile
        bg.edgeFile = DefaultEdgeFile
    end
    bg.tile = db.bgTile
    bg.tileSize = db.bgTileSize
    bg.edgeSize = db.bgEdgeSize
    local inset = getInset()
    bg.insets.left = inset
    bg.insets.right = inset
    bg.insets.top = inset
    bg.insets.bottom = inset
    self.mainFrame:SetBackdrop(bg)
    self.mainFrame:SetBackdropColor(db.bgColor.r, db.bgColor.g, db.bgColor.b, db.bgColor.a)
    self.mainFrame:SetBackdropBorderColor(db.bgBorderColor.r, db.bgBorderColor.g, db.bgBorderColor.b, db.bgBorderColor.a)

    self.barFrame:ClearAllPoints()
    self.barFrame:SetPoint("TOPLEFT", self.mainFrame, "TOPLEFT", inset, -inset)
    self.barFrame:SetPoint("BOTTOMRIGHT", self.mainFrame, "BOTTOMRIGHT", -inset, inset)
end

function PetTimeToLive:applyFontSettings()
    local dbFontPath
    if LSM then
        dbFontPath = LSM:Fetch("font", db.font, true)
        if not dbFontPath then
            dbFontPath = DefaultFontPath
            LSM.RegisterCallback(self, "LibSharedMedia_Registered", "mediaUpdate")
        end
    else
        dbFontPath = DefaultFontPath
    end
    local fontPath, fontSize, fontOutline = self.text:GetFont()
    fontOutline = fontOutline or ""
    if dbFontPath ~= fontPath or db.fontSize ~= fontSize or db.fontOutline ~= fontOutline then
        self.text:SetFont(dbFontPath, db.fontSize, db.fontOutline)
    end
end

function PetTimeToLive:applySettings()
    if not self:IsEnabled() then return end
    self.mainFrame:ClearAllPoints()
    self.mainFrame:SetPoint(db.point, UIParent, db.relPoint, db.x, db.y)
    self.mainFrame:SetWidth(db.frameWidth)
    self.mainFrame:SetHeight(db.frameHeight)
    self.mainFrame:SetFrameStrata(db.strata)
    self:applyFontSettings()
    self:applyBGSettings()
    self:applyBarSettings()
    self:toggleLocked(db.locked == true)
end

function PetTimeToLive:hideBar()
    self.barFrame:SetValue(0)
end

function PetTimeToLive:showBar()
end

function PetTimeToLive:createOverlay()
    self.overlay = self.barFrame:CreateTexture("PetTimeToLiveOverlay", "OVERLAY")
    self.overlay:SetTexture(0, 0.42, 0, 0.42)
    self.overlay:SetAllPoints()

    self.overlayText = self.barFrame:CreateFontString("PetTimeToLiveOverlayText", "OVERLAY", "GameFontNormal")
    self.overlayText:SetFont(DefaultFontPath, 10, "")
    self.overlayText:SetJustifyH("CENTER")
    self.overlayText:SetPoint("BOTTOM", self.mainFrame, "BOTTOM", 0, 0)
    self.overlayText:SetText("PTTL")
end

function PetTimeToLive:createFrame()
    self.isMoving = false
    self.mainFrame = CreateFrame("Frame", "PetTimeToLiveMainFrame", UIParent)
    self.mainFrame:SetFrameStrata(db.strata)
    self.mainFrame:EnableMouse(false)
    self.mainFrame:SetClampedToScreen()
    self.mainFrame:SetMovable(true)
    self.mainFrame:SetWidth(db.frameWidth)
    self.mainFrame:SetHeight(db.frameHeight)
    self.mainFrame:SetPoint(db.point, UIParent, db.relPoint, db.x, db.y)

    self.barFrame = CreateFrame("StatusBar", "PetTimeToLiveBarFrame", self.mainFrame)
    local inset = getInset()
    self.barFrame:SetPoint("TOPLEFT", self.mainFrame, "TOPLEFT", inset, -inset)
    self.barFrame:SetPoint("BOTTOMRIGHT", self.mainFrame, "BOTTOMRIGHT", -inset, inset)
    self.barFrame:SetValue(0)

    self.text = self.barFrame:CreateFontString("PetTimeToLiveFrameText", "ARTWORK", "GameFontNormal")
    self.text:SetFont(DefaultFontPath, db.fontSize, db.fontOutline)
    self.text:SetJustifyH("CENTER")
    self.text:SetPoint("CENTER", self.mainFrame, "CENTER", 0, 0)

    self.mainFrame:SetScript("OnMouseDown", function(frame, button)
        if button == "LeftButton" then
            if IsControlKeyDown() then
                self:lock()
                return
            end
            self.mainFrame:StartMoving()
            self.isMoving = true
            GameTooltip:Hide()
        elseif button == "RightButton" then
            self:openConfigDialog()
        end
    end)
    self.mainFrame:SetScript("OnMouseUp", function(frame, button)
        if self.isMoving and button == "LeftButton" then
            self.mainFrame:StopMovingOrSizing()
            self.isMoving = false
            db.point, _, db.relPoint, db.x, db.y = self.mainFrame:GetPoint()
        end
    end)
    self.mainFrame:SetScript("OnEnter", function(frame)
        GameTooltip:SetOwner(frame)
        GameTooltip:AddLine(AppName)
        GameTooltip:AddLine(L["|cffeda55fDrag|r to move the frame"])
        GameTooltip:AddLine(L["|cffeda55fControl + Left Click|r to lock the frame"])
        GameTooltip:AddLine(L["|cffeda55fRight Click|r to open the configuration window"])
        GameTooltip:Show()
    end)
    self.mainFrame:SetScript("OnLeave", function(frame)
        GameTooltip:Hide()
    end)
    self.mainFrame:SetScript("OnUpdate", function(frame, elapsed)
            lastUpdate = lastUpdate + elapsed
            if lastUpdate < updateDelay then return end
            lastUpdate = 0
            self:update()
        end)
end

function PetTimeToLive:lock()
    db.locked = true
    self.mainFrame:EnableMouse(false)
    if self.overlay then
        self.overlay:Hide()
        self.overlayText:Hide()
    end
end

function PetTimeToLive:unlock()
    db.locked = false
    if not self.overlay then
        self:createOverlay()
    end
    self.mainFrame:EnableMouse(true)
    self.overlay:Show()
    self.overlayText:Show()
    self.mainFrame:Show()
end

function PetTimeToLive:OnInitialize()
    _, playerClass = UnitClass("player")
    if playerClass == "DEATHKNIGHT" then
        getPTR = getPTR_DK
    elseif playerClass == "SHAMAN" then
        getPTR = getPTR_Shaman_First
    else
        getPTR = getPTR_Default
    end
    if LSM then
        LSM:Register("font", "Vera Sans Mono Bold",
            [[Interface\AddOns\]] .. AppName .. [[\fonts\VeraMoBd.ttf]])
        LSM:Register("font", "Vera Sans Mono Bold Oblique",
            [[Interface\AddOns\]] .. AppName .. [[\fonts\VeraMoBI.ttf]])
        LSM:Register("font", "Vera Sans Mono Oblique",
            [[Interface\AddOns\]] .. AppName .. [[\fonts\VeraMoIt.ttf]])
        LSM:Register("font", "Vera Sans Mono",
            [[Interface\AddOns\]] .. AppName .. [[\fonts\VeraMono.ttf]])
    end
    self.db = LibStub("AceDB-3.0"):New("PetTimeToLiveDB", defaults, true)
    db = self.db.profile
    if LibDualSpec then
        LibDualSpec:EnhanceDatabase(self.db, AppName)
    end
    self.db.RegisterCallback(self, "OnProfileChanged", "profileChanged")
    self.db.RegisterCallback(self, "OnProfileCopied", "profileChanged")
    self.db.RegisterCallback(self, "OnProfileReset", "profileChanged")
    if not self.mainFrame then
        self:createFrame()
    end
    self:profileChanged()
    self:setupDummyOptions()
    if self.setupDBOptions then -- trickery to make it work with a straight checkout
        self:setupDBOptions()
    end
    self:setupLDB()
    if not self.db.profile.locked then
        self:RegisterEvent("PLAYER_REGEN_DISABLED", function()
            if not self.db.profile.locked then
                self:toggleLocked(true)
            end
        end)
    end
end

function PetTimeToLive:OnEnable(first)
    self:RegisterEvent("UNIT_PET")
    if playerClass == "DEATHKNIGHT" or playerClass == "SHAMAN" then
        self:RegisterEvent("PLAYER_TOTEM_UPDATE")
    end
end

function PetTimeToLive:OnDisable()
    if self.mainFrame then
        self.mainFrame:Hide()
    end
    self:UnregisterAllEvents()
end

function PetTimeToLive:profileChanged()
    db = self.db.profile
    self:applySettings()
end

function PetTimeToLive:toggleLocked(flag)
    if flag == nil then
         flag = not db.locked
    end
    if flag ~= db.locked then
        db.locked = flag
        self:updateMainOptions()
    end
    if flag then
        self:lock()
    else
        self:unlock()
    end
end

function PetTimeToLive:setupLDB()
    local ldb = {
        type = "launcher",
        icon = Icon,
        OnClick = function(frame, button)
            if button == "LeftButton" then
                self:toggleLocked()
            elseif button == "RightButton" then
                self:openConfigDialog()
            end
        end,
        OnTooltipShow = function(tt)
            tt:AddLine(self.AppName)
            tt:AddLine(L["|cffeda55fLeft Click|r to lock/unlock frame"])
            tt:AddLine(L["|cffeda55fRight Click|r to open the configuration window"])
        end,
    }
    LDB:NewDataObject(self.AppName, ldb)
end

-- Stubs for PetTimeToLive_Options

function PetTimeToLive:updateMainOptions()
end

-- BEGIN LoD Options muckery

function PetTimeToLive:setupDummyOptions()
    if self.optionsLoaded then
        return
    end
    self.dummyOpts = CreateFrame("Frame", AppName .. "DummyOptions", UIParent)
    self.dummyOpts.name = AppName
    self.dummyOpts:SetScript("OnShow", function(frame)
        if not self.optionsLoaded then
            if not InterfaceOptionsFrame:IsVisible() then
                return -- wtf... Happens if you open the game map and close it with ESC
            end
            self:openConfigDialog()
        else
            frame:Hide()
        end
    end)
    InterfaceOptions_AddCategory(self.dummyOpts)
end

function PetTimeToLive:loadOptions()
    if not self.optionsLoaded then
        self.optionsLoaded = true
        local loaded, reason = LoadAddOn(OptionsAppName)
        if not loaded then
            print("Failed to load " .. tostring(OptionsAppName) .. ": " .. tostring(reason))
        end
    end
end

function PetTimeToLive:openConfigDialog(opts)
    -- this function will be overwritten by the Options module when loaded
    if not self.optionsLoaded then
        self:loadOptions()
        return self:openConfigDialog(opts)
    end
    InterfaceOptionsFrame_OpenToCategory(self.dummyOpts)
end

-- END LoD Options muckery

-- register slash command

SLASH_PETTIMETOLIVE1 = "/pettimetolive"
SLASH_PETTIMETOLIVE2 = "/pttl"
SlashCmdList["PETTIMETOLIVE"] = function(msg)
    msg = strtrim(msg or "")
    if msg == "locked" then
        PetTimeToLive:toggleLocked()
    else
        PetTimeToLive:openConfigDialog()
    end
end

-- CONFIGMODE

CONFIGMODE_CALLBACKS = CONFIGMODE_CALLBACKS or {}
CONFIGMODE_CALLBACKS[AppName] = function(action)
    if action == "ON" then
        PetTimeToLive:toggleLocked(false)
    elseif action == "OFF" then
        PetTimeToLive:toggleLocked(true)
    end
end
