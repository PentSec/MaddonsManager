local PetTimeToLive = PetTimeToLive
local ACR = LibStub("AceConfigRegistry-3.0")
local AceDBOptions = LibStub("AceDBOptions-3.0")
local ACD = LibStub("AceConfigDialog-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale(PetTimeToLive.OptionsAppName)
local LibDualSpec = LibStub("LibDualSpec-1.0", true)

local MinFontSize = 5
local MaxFontSize = 30
local MinFrameWidth = 20
local MaxFrameWidth = 256
local MinFrameHeight = 16
local MaxFrameHeight = 64

local _

local FontOutlines = {
    [""] = L["None"],
    ["OUTLINE"] = L["Normal"],
    ["THICKOUTLINE"] = L["Thick"],
}

local FrameStratas = {
    ["HIGH"] = L["High"],
    ["MEDIUM"] = L["Medium"],
    ["LOW"] = L["Low"],
}

function PetTimeToLive:getOption(info)
    return self.db.profile[info[#info]]
end

function PetTimeToLive:setOption(info, value)
    self.db.profile[info[#info]] = value
    self:applySettings()
end

local function getColor(dbcolor)
    return dbcolor.r, dbcolor.g, dbcolor.b, dbcolor.a
end

local function setColor(dbcolor, r, g, b, a)
    dbcolor.r, dbcolor.g, dbcolor.b, dbcolor.a = r, g, b, a
end

function PetTimeToLive:getColor(info)
    local dbcolor = self.db.profile[info[#info]]
    return getColor(dbcolor)
end

function PetTimeToLive:setColor(info, r, g, b, a)
    local db = self.db.profile
    local dbcolor = db[info[#info]]
    setColor(dbcolor, r, g, b, a)
    if db.bgEnabled then
        self.mainFrame:SetBackdropColor(db.bgColor.r, db.bgColor.g, db.bgColor.b, db.bgColor.a)
        self.mainFrame:SetBackdropBorderColor(db.bgBorderColor.r, db.bgBorderColor.g, db.bgBorderColor.b, db.bgBorderColor.a)
    end
    if db.barMode then
        self.barFrame:SetStatusBarColor(db.barColor.r, db.barColor.g, db.barColor.b, db.barColor.a)
    end
end


function PetTimeToLive:openConfigDialog()
    InterfaceOptionsFrame_OpenToCategory(self.profiles) -- to expand our tree
    InterfaceOptionsFrame_OpenToCategory(self.opts)
end

function PetTimeToLive:updateMainOptions()
    ACR:NotifyChange(self.AppName)
end

do
    local self = PetTimeToLive

    local mainOptions = {
        type = 'group',
        childGroups = 'tab',
        inline = true,
        name = PetTimeToLive.AppName,
        handler = PetTimeToLive,
        get = "getOption",
        set = "setOption",
        order = 10,
        args = {
            locked = {
                type = 'toggle',
                name = L["Locked"],
                desc = L["Lock/Unlock display frame"],
                width = 'full',
                order = 110,
            },
            config = {
                type = 'execute',
                name = L["Configure"],
                desc = L["Bring up GUI configure dialog"],
                guiHidden = true,
                order = 300,
                func = function() PetTimeToLive:openConfigDialog() end,
            },

            color = {
                type = 'color',
                hasAlpha = true,
                name = L["Color"],
                set = "setColor",
                get = "getColor",
                order = 120,
            },
            warnColor = {
                type = 'color',
                hasAlpha = true,
                name = L["Warning Color"],
                set = "setColor",
                get = "getColor",
                order = 121,
            },

            warnThreshold = {
                type = 'range',
                name = L["Warning Threshold"],
                min = 0,
                max = 10,
                step = 0.1,
                order = 125,
            },
            warnSound = {
                type = 'toggle',
                -- width = 'full',
                name = L["Warning Sound"],
                desc = L["Play a sound if remaining time gets under Warning Threshold"],
                order = 126,
            },
            warnSoundName = {
                type = "select", dialogControl = 'LSM30_Sound',
                disabled = function() return not PetTimeToLive.db.profile.warnSound end,
                -- width = 'full',
                name = L["Warning Sound Name"],
                values = AceGUIWidgetLSMlists.sound,
                order = 127,
            },

            font = {
                type = "select", dialogControl = 'LSM30_Font',
                name = L["Font"],
                --desc = L["Font"],
                values = AceGUIWidgetLSMlists.font,
                order = 135,
            },
            fontSize = {
                type = 'range',
                name = L["Font size"],
                --desc = L["Font size"],
                min = MinFontSize,
                max = MaxFontSize,
                step = 1,
                order = 140,
            },
            fontOutline = {
                type = 'select',
                name = L["Font outline"],
                --desc = L["Font outline"],
                values = FontOutlines,
                order = 150,
            },
            strata = {
                type = 'select',
                name = L["Strata"],
                desc = L["Frame strata"],
                values = FrameStratas,
                order = 151,
            },
            disableDecimals = {
                type = 'toggle',
                name = L["Disable Decimals"],
                desc = L["Do not show sub-second precision time"],
                order = 152,
            },
            frameWidth = {
                type = 'range',
                disabled = false,
                name = L["Width"],
                min = MinFrameWidth,
                max = MaxFrameWidth,
                step = 1,
                order = 153,
            },
            frameHeight = {
                type = 'range',
                disabled = false,
                name = L["Height"],
                min = MinFrameHeight,
                max = MaxFrameHeight,
                step = 1,
                order = 154,
            },
            bar = {
                type = "group",
                name = L["Bar Mode Options"],
                disabled = function() return not PetTimeToLive.db.profile.barMode end,
                inline = true,
                order = 157,
                args = {
                    barMode = {
                        type = 'toggle',
                        order = 1,
                        name = L["Enabled"],
                        disabled = false,
                    },
                    barColor = {
                        type = 'color',
                        hasAlpha = true,
                        name = L["Bar Color"],
                        set = "setColor",
                        get = "getColor",
                        order = 10,
                    },
                    barTexture = {
                        type = "select", dialogControl = 'LSM30_Statusbar',
                        order = 20,
                        name = L["Bar Texture"],
                        values = AceGUIWidgetLSMlists.statusbar,
                    },
                },
            },
            bg = {
                type = "group",
                name = L["Background Options"],
                disabled = function() return not PetTimeToLive.db.profile.bgEnabled end,
                guiInline = true,
                order = 158,
                args = {
                    bgEnabled = {
                        type = 'toggle',
                        order = 1,
                        name = L["Enabled"],
                        disabled = false,
                    },
                    bgTexture = {
                        type = "select", dialogControl = 'LSM30_Background',
                        order = 11,
                        name = L["Background Texture"],
                        desc = L["Texture to use for the frame's background"],
                        values = AceGUIWidgetLSMlists.background,
                    },
                    bgBorderTexture = {
                        type = "select", dialogControl = 'LSM30_Border',
                        order = 12,
                        name = L["Border Texture"],
                        desc = L["Texture to use for the frame's border"],
                        values = AceGUIWidgetLSMlists.border,
                    },
                    bgColor = {
                        type = "color",
                        order = 13,
                        name = L["Background Color"],
                        desc = L["Frame's background color"],
                        hasAlpha = true,
                        set = "setColor",
                        get = "getColor",
                    },
                    bgBorderColor = {
                        type = "color",
                        order = 14,
                        name = L["Border Color"],
                        desc = L["Frame's border color"],
                        hasAlpha = true,
                        set = "setColor",
                        get = "getColor",
                    },
                    bgTile = {
                        type = "toggle",
                        order = 2,
                        name = L["Tile Background"],
                        desc = L["Tile the background texture"],
                    },
                    bgTileSize = {
                        type = "range",
                        order = 16,
                        name = L["Background Tile Size"],
                        desc = L["The size used to tile the background texture"],
                        min = 16, max = 256, step = 1,
                        disabled = function() return not PetTimeToLive.db.profile.bgEnabled or not PetTimeToLive.db.profile.bgTile end,
                    },
                    bgEdgeSize = {
                        type = "range",
                        order = 17,
                        name = L["Border Thickness"],
                        desc = L["The thickness of the border"],
                        min = 1, max = 16, step = 1,
                    },
                },
            },
        },
    }

    local function registerSubOptions(name, opts)
        local appName = self.AppName .. "." .. name
        ACR:RegisterOptionsTable(appName, opts)
        return ACD:AddToBlizOptions(appName, opts.name or name, self.AppName)
    end

    self.optionsLoaded = true

    -- remove dummy options frame, ugly hack
    if self.dummyOpts then
        for k, f in ipairs(INTERFACEOPTIONS_ADDONCATEGORIES) do
            if f == self.dummyOpts then
                tremove(INTERFACEOPTIONS_ADDONCATEGORIES, k)
                f:SetParent(UIParent)
                break
            end
        end
        self.dummyOpts = nil
    end


    ACR:RegisterOptionsTable(self.AppName, mainOptions)
    self.opts = ACD:AddToBlizOptions(self.AppName, self.AppName)
    self.setupDBOptions = function(self)
        local profiles =  AceDBOptions:GetOptionsTable(self.db)
        if LibDualSpec then
            LibDualSpec:EnhanceOptions(profiles, self.db)
        end
        self.profiles = registerSubOptions('profiles', profiles)
    end
    if self.db then -- trickery to make it work with a straight checkout
        self:setupDBOptions()
        self.setupDBOptions = nil
    end
end
