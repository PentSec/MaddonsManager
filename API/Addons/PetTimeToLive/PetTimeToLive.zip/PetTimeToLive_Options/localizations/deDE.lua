-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/pet-time-to-live/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("PetTimeToLive_Options", "deDE")
if not L then return end

L["Color"] = "Farbe"
L["Font"] = "Schriftart"
L["Font outline"] = "Schriftstil"
L["Font size"] = "Schriftgröße"
L["High"] = "Hoch"
L["Locked"] = "Gesperrt"
L["Lock/Unlock display frame"] = "Anzeige sperren/entsperren"
L["Low"] = "Niedrig"
L["Medium"] = "Mittel"
L["None"] = "Keine"
L["Normal"] = "Normal"
L["Thick"] = "Fett"

