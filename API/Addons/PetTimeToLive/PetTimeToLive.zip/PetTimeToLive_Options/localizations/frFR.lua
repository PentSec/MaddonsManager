-- This file is automagically generated.
-- Please visit http://www.wowace.com/projects/pet-time-to-live/localization/
-- if you wish to help with the translation.

local L = LibStub("AceLocale-3.0"):NewLocale("PetTimeToLive_Options", "frFR")
if not L then return end

L["Color"] = "Couleur"
L["Font"] = "Police"
L["Font outline"] = "Epaisseur de police"
L["Font size"] = "Taille de police"
L["Frame strata"] = "Profondeur de la fenêtre"
L["High"] = "Au dessus"
L["Locked"] = "Vérouillé"
L["Lock/Unlock display frame"] = "(Dé)Vérouille la fenêtre"
L["Low"] = "En dessous"
L["Medium"] = "Normal"
L["None"] = "Aucun"
L["Normal"] = "Normal"
L["Strata"] = "Profondeur"
L["Thick"] = "Epais"

