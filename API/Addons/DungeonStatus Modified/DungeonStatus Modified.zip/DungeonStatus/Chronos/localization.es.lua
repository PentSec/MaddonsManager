--------------------------------------------------
-- localization.es.lua (Spanish)
-- $LastChangedBy: Gryphon $
-- $Date: 2007-02-02 22:41:28Z $
-- Translation: NeKRoMaNT

if ( GetLocale() == "esES" ) then

	-- Chat Configuration
	SCHEDULE_COMM		= {"/in","/pause","/delay"};
	SCHEDULE_DESC		= "/in <segundos> <comando> [<args> ...] |cFFCC9966[Nota: /in NO puede realizar hechizos para evitar la creaci�n de bots]|r";
	SCHEDULE_USAGE1		= "Uso: /in <segundos> <comando> [<args> ...]";
	SCHEDULE_USAGE2		= "Ejecuta <comando> con argumentos <args> tras <segundos> segundos.";

end
