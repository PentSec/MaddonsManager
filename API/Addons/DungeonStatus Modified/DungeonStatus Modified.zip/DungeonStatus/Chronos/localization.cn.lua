﻿--------------------------------------------------
-- localization.cn.lua (Chinese)
-- $LastChangedBy: Gryphon $
-- $Date: 2007-02-02 22:41:28Z $
-- Translation:

if ( GetLocale() == "zhCN" ) then

	-- Please submit your translation to everyone@cosmosui.org

end
