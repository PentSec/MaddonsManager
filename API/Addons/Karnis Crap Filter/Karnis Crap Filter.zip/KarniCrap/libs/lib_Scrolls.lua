-- [item id] = required level, --name
Scrolllevel_List = { "I", "II", "III", "IV", "V", "VI", "VII" }

ScrollList_Agility = {
	["3012"] = 10, 	--Agility
	["1477"] = 25, 	--Agility II
	["4425"] = 40, 	--Agility III
	["10309"] = 55, --Agility IV
	["27498"] = 60,	--Agility V
	["33457"] = 70,	--Agility VI
	["43463"] = 80	--Agility VII
	--["43464"] = 90 --Agility VIII
}
ScrollList_Intellect = {	
	["955"] = 5,	--Intellect
	["2290"] = 20, 	--Intellect II
	["4419"] = 35, 	--Intellect III
	["10308"] = 50, --Intellect IV
	["27499"] = 60,	--Intellect V
	["33458"] = 70,	--Intellect VI
	["37091"] = 80	--Intellect VII
	--["37092"] = 90 --Intellect VIII
}
ScrollList_Protection = {
	["3013"] = 1, 	--Protection
	["1478"] = 15, 	--Protection II
	["4421"] = 30, 	--Protection III
	["10305"] = 45, --Protection IV
	["27500"] = 60,	--Protection V
	["33459"] = 70,	--Protection VI
	["43467"] = 80	--Protection VII
	--[""] = 90	--Protection VIII	
}
ScrollList_Spirit = {
	["1181"] = 1, 	--Spirit
	["1712"] = 15, 	--Spirit II
	["4424"] = 30, 	--Spirit III
	["10306"] = 45, --Spirit IV
	["27501"] = 60,	--Spirit V
	["33460"] = 70,	--Spirit VI	
	["37097"] = 80	--Spirit VII
	--["37098"] = 90	--Spirit VIII
}
ScrollList_Stamina = {
	["1180"] = 5,	--Stamina
	["1711"] = 20,	--Stamina II
	["4422"] = 35,	--Stamina III
	["10307"] = 50,	--Stamina IV
	["27502"] = 60,	--Stamina V
	["33461"] = 70,	--Stamina VI
	["37093"] = 80	--Stamina VII
	--["37094"] = 90	--Stamina VIII
}
ScrollList_Strength = {	
	["954"] = 10,	--Strength
	["2289"] = 25,	--Strength II
	["4426"] = 40,	--Strength III
	["10310"] = 55,	--Strength IV
	["27503"] = 60,	--Strength V
	["33462"] = 70,	--Strength VI
	["43465"] = 80 --Strength VII
	--["43466"] = 90 --Strength VIII	
}