mobsEngineerableList = {
	["25793"] = true, --55-D Collect-a-tron
	["25758"] = true, --Defendo-tank 66D
	["25814"] = true, --Fizzcrank Mechagnome
	["25752"] = true, --Scavenge-bot 004-A8
	["25792"] = true, --Scavenge-bot 005-B6	
	["25753"] = true --Sentry-bot 57-K
}