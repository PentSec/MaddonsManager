cookingList = {

	["23676"] = 1, 	--Moongraze Stag Tenderloin
	
	["27669"] = 5, 	--Bat Flesh
	["769"] = 5, 	--Chunk of Boar Meat
	["2886"] = 5, 	--Crag Boar Rib
	["27668"] = 5,	--Lynx Meat
	["12223"] = 5, 	--Meaty Bat Wing
	["159"] = 5,	--Refreshing Spring Water
	["4536"] = 5, 	--Shiny Red Apple
	["6889"] = 5, 	--Small Egg
	["5465"] = 5, 	--Small Spider Leg
	["2672"] = 5, 	--Stringy Wolf Meat
	["5466"] = 5, 	--Scorpid Stinger
	
	["3172"] = 10, 	--Boar Intestines
	["2673"] = 10, 	--Coyote Meat
	["5467"] = 10,  --Kodo Meat
	["785"] = 10, 	--Mageroyal
	["3174"] = 10, 	--Spider Ichor
	["5469"] = 10, 	--Strider Meat
	["729"] = 10, 	--Stringy Vulture Meat

	["3173"] = 11, 	--Bear Meat
	["730"] = 11, 	--Murloc Eye
	["723"] = 12, 	--Goretusk Liver
	["731"] = 12, 	--Goretusk Snout
	["2675"] = 13, 	--Crawler Claw
	["2674"] = 13, 	--Crawler Meat
	["2677"] = 14, --Boar Ribs
	["5503"] = 14, --Clam Meat
	["2924"] = 14, --Crocolisk Meat
	
	["1081"] = 15, 	--Crisp Spider Meat
	["22644"] = 15, --Crunchy Spider Leg
	["2593"] = 15, 	--Flask of Port
	["1179"] = 15, 	--Ice Cold Milk
	["2596"] = 15, 	--Skin of Dwarven Stout
	["5468"] = 15, 	--Soft Frenzy Flesh
	["2452"] = 15, 	--Swiftthistle
	["1080"] = 15,	--Tough Condor Meat
	["1468"] = 16,	--Murloc Fin
	["1015"] = 19,	--Lean Wolf Flank

	["3730"] = 21,	--Big Bear Meat
	["3685"] = 22,	--Raptor Egg
	["5470"] = 22,	--Thunder Lizard Tail
	["3731"] = 23,	--Lion Meat
	["5471"] = 23, 	--Stag Meat
	["3667"] = 23, 	--Tender Crocolisk Meat
	["2594"] = 25, 	--Flagon of Mead
	["2251"] = 25, 	--Gooey Spider Leg
	["4402"] = 25,	--Small Flame Sac
	
	["12037"] = 30, --Mystery Meat
	["12184"] = 30, --Raptor Flesh
	["12203"] = 30, --Red Wolf Meat
	["12202"] = 30, --Tiger Meat
	["3712"] = 30, 	--Turtle Meat
	["3821"] = 34, 	--Goldthorn
	
	["3404"] = 35, --Buzzard Wing
	["4539"] = 35, --Goldenbark Apple
	["12204"] = 35, --Heavy Kodo Meat
	
	["8150"] = 40, --"Deeprock Salt
	["12206"] = 40, --Tender Crab Meat
	["12208"] = 40, --Tender Wolf Meat
	["12205"] = 40,	--White Spider Meat

	["9061"] = 42, 	--Goblin Rocket Fuel
	["12207"] = 45,	--Giant Egg
	["7974"] = 45,	--Zesty Clam Meat
	
	["35562"] = 50,	--Bear Flank
	
	["12808"] = 55, --Essence of Undeath
	["18255"] = 55,	--Runn Tum Tuber
	["20424"] = 55,	--Sandworm Meat
	
	-- Burning Crusade
	["27671"] = 60,	--Buzzard Meat
	["21024"] = 60,	--Chimaerok Tenderloin
	["27677"] = 60,	--Chunk o' Basilisk
	["27678"] = 60,	--Clefthoof Meat
	["31670"] = 60,	--Raptor Ribs
	["27674"] = 60,	--Ravager Flesh
	["31671"] = 60,	--Serpent Flesh
	["27676"] = 60,	--Strange Spores
	["27682"] = 60,	--Talbuk Venison
	["27681"] = 60,	--Warped Flesh
	
	["24477"] = 65,	--Jaggal Clam Meat
	["22577"] = 65,	--Mote of Shadow
	
	-- Wrath of the Lich King
	["43013"] = 70, --Chilled Meat
	["34736"] = 70, --Chunk o' Mammoth
	["43501"] = 70, --Northern Egg
	["43012"] = 70, --Rhino Meat
	["43009"] = 70,	--Shoveltusk Flank
	["43011"] = 70,	--Worg Haunch
	["43010"] = 70	--Wyrm Meat
}
