-- table has the ID and the min required level to use

waterList = {
	["159"]	= 0, 		--Refreshing Spring Water
	["1179"] = 5, 		--Ice Cold Milk
	["9451"] = 15, 		--Bubbling Water
	["1205"] = 15, 		--Melon Juice
	["4791"] = 25, 		--Enchanted Water
	["1708"] = 25, 		--Sweet Nectar
	["1645"] = 35, 		--Moonberry Juice
	["8766"] = 45, 		--Morning Glory Dew
	["18300"] = 55, 	--Hyjal Nectar
	["28399"] = 60,	 	--Filtered Draenic Water 5100mana/30sec
	["27860"] = 65, 	--Purified Draenic Water 7200mana/30sec
	["30457"] = 65, 	--Gilneas Sparkling Water 7200mana/30sec
	["33444"] = 70, 	--Pungent Seal Whey 9180mana/30sec
	["33445"] = 75 		--Honeymint Tea 12690mana/30sec
}