Rogue Power Bars V 2.00 - Displays statusbars with time left on rogue abilities

Author: Anthony Marion - 10-20-2008 (Domia/Horde on Maiev)

For configuration:

/rpb config


------------------------------- Old Readme.txt -----------------------------------
Rogue Power Bars V 1.13 - Displays statusbars with time left on rogue abilities

Author: Fredrik Norm�n - 2006-12-27 (Mangrol/Alliance on Mazrigos)

For configuration of the addon:


/rpb config


Note: You can move the addon when it's in unlock mode, but in this version it will only be displayed when a aura is active.