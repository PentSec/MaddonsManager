﻿
-- Variables needed throughout.
fName = { {}, {} };    --Fixed names to use, need to be a global
kSpellInfo = {{},{}};  --Array of spell info and columns
showWarn = {} --Show warning messages
iMax = nil; --Max number of icons in a row, defined in addonload
SpellSet = nil;  --which set of spells to use
ClearOOC = nil;  --Whether or not to clear warning message on Out of Combat

local kalVersion = " ";
local Debug = nil; -- Change to nil to disable
local iWidth = 32;
local kWarnSize = 18;
local iHeight = iWidth + 28 + kWarnSize + 10; -- Twice font size plus offset
local iSpace = 4;   --Horizontal space between icons
local inCombat = 0;
local kPlayer;  --Who am I
local kClass;   --What class am I
local KALOpt = {}; -- for options to pass to Blizzard option handler
local KALAOpt = {};  --for advanced options
local kFrames = { {}, {} };  --The display icons and text
local kTimer = { {}, {} };   --The timers for each icon
local kName = { {}, {} };    --Temporary name to display with icon
local kWarn = {};            --Warning message frames
local rName = {};           --Real names for the lines
local kSecret = nil;         --Don't show extra boxes unless you know the code
local items = {};    --Used for setting up dropdown menus
local menuTypes= {"SELF", "PARTY", "RAID_PLAYER", "PLAYER"};
local WarnMsg = "You are next!";
local WarnFlag = {};  --Activate warning message after time delay
local WarnDelay = 3;  --number of timesteps to delay

local TimeSinceLastUpdate = 0;
local AnchorShow = 0;
local iMaxMax = 6; --Upper limit on iMax
local jMax = 2; --Max number of rows


-- When the AddOn loads...
function KickAlert_OnLoad(self)
	-- Say hi.
	if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Hello World!") end;
	
	kPlayer = UnitName("player");
    _, kClass = UnitClass("player");
	if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("I am "..kPlayer.." a "..kClass) end;


	-- Setup slash commands

	SlashCmdList["KICKALERT"] = KickAlert_SlashHandler;
    	SLASH_KICKALERT1 = "/kickalert";
    	SLASH_KICKALERT2 = "/kal";

	-- Setup frames names and timer labels

	for j = 1, jMax do
	  for i = 1, iMaxMax do

	    kTimer[j][i] = 0;
	    kFrames[j][i] = KAL_CreateIcon(j, i);
		
	  end

	  kWarn[j] = KAL_CreateWarning(j, kFrames[j][1]);
      WarnFlag[j] = 0; --Initialize

	end

-- Setup options
	if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Start options") end;
	KALOpt = getglobal("KAL_Options");
    KALOpt:Hide();
	KALOpt.name = "KickAlert";
    KALOpt.cancel = function (self) KAL_SetEntry(); end;
    KALOpt.okay = function (self) KAL_GetEntry(); end;
    KALOpt.default = function (self) KAL_AdvOptDefault(); end;
	InterfaceOptions_AddCategory(KALOpt); 
    
    KickAlert_AdvOpt.name = "KAL Advanced Options";
    if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("adv opt name = "..KickAlert_AdvOpt.name) end;
    KickAlert_AdvOpt.parent = "KickAlert";
    KickAlert_AdvOpt.okay = function (self) KAL_AdvOptDone(); end;
    KickAlert_AdvOpt.cancel = function (self) KAL_AdvOptCancel(); end;
    KickAlert_AdvOpt.default = function (self) KAL_AdvOptDefault(); end;
    InterfaceOptions_AddCategory(KickAlert_AdvOpt);
    
    KickAlertFrame:Show(); --start processing
		
	self:RegisterEvent("PLAYER_REGEN_DISABLED");
	self:RegisterEvent("PLAYER_REGEN_ENABLED");
    self:RegisterEvent("PLAYER_ALIVE");
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	self:RegisterEvent("ADDON_LOADED");
	
end

function KickAlert_OnEvent(self, event, ...)
	-- Based upon our registered events, we want different things to happen when each event occurs.

	if (event == "ADDON_LOADED" and arg1 == "KickAlert") then
		if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Addon Loaded"..arg1) end;
		-- In all cases, if the parameter has been saved previously use it,
        --    otherwise, set up a default
        kalVersion = kalVersion..GetAddOnMetadata("KickAlert", "VERSION");
        
        --Icons to display in a row
        if (iMax == nil) then 
            iMax = 4;            
        end
  
        --If there are no stored names fill with *
        for j = 1, jMax do
            for i = 1, iMaxMax do
                if(fName[j][i] == nil) then
                    fName[j][i] = "*";
                    if (showWarn[j] == nil) then showWarn[j] = 1 end;  --small hack here
                end
                kName[j][i] = fName[j][i];
                               
                if (kName[j][i] ~= "*") then --Update names on icons
                  getglobal("KAL_R"..j.."C"..i.."Icon").Name:SetText(string.sub(kName[j][i],1,4));
                end
            end
            
        end
        
        --Get spell info
	    if(SpellSet == nil) then 
        
            SpellSet = 0; --Default      
            if (kClass == "PRIEST") then SpellSet = 1 end;
      
        end
        
        if(ClearOOC == nil) then
            ClearOOC = "Yes"; --Default to yes
            if (kClass == "ROGUE") then ClearOOC = "Yes" end;  --even for rogues
        end
        
        if (KSpellInfo == nil) then KAL_LoadSpellInfo(SpellSet) end;

        if (Debug) then DEFAULT_CHAT_FRAME:AddMessage(kSpellInfo[1]["name"] .. " name loaded") end;  
        if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("array dism cooldown "..kSpellInfo[2]["cDown"]) end;
	
        for k, v in pairs(kSpellInfo) do
            if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("k "..k.." v "..v.name.." row "..v.row) end;
        end

        --Adjust scaling and displays
        
        if (iScale == nil) then iScale = 1 end;
        
        KAL_Options_ScaleSliderLow:SetText(0.75);  --Need to fix slider label
        KAL_Options_ScaleSliderHigh:SetText(2.0);
            
        KAL_Sizing(iScale);
	   
	    KickAlertRef:Hide();
        inCombat = 0; 
        KAL_SetEntry();
        
        KAL_AdvOptSetup();
        
        --Inserting into target frame for right click
        UnitPopupButtons["KAL_FOLLOW_LINE1"] = {
		    text = "Follow this person with "..rName[1],
		    dist = 0,
		    func = KAL_NameLine1
	        }
            
        UnitPopupButtons["KAL_FOLLOW_LINE2"] = {
		    text = "Follow this person with "..rName[2],
		    dist = 0,
		    func = KAL_NameLine2
	        }
            
        if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Popup menu types "..#menuTypes) end;
	
	    for i = 1, #menuTypes do
		    tinsert(UnitPopupMenus[menuTypes[i]], #UnitPopupMenus[menuTypes[i]]-1, "KAL_FOLLOW_LINE1");
            tinsert(UnitPopupMenus[menuTypes[i]], #UnitPopupMenus[menuTypes[i]]-1, "KAL_FOLLOW_LINE2");
	    end

	    hooksecurefunc("UnitPopup_ShowMenu", KAL_ShowMenu);

        
        
	end
		
     
	if (event == "PLAYER_REGEN_DISABLED") then
		if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Disabled!") end;
		inCombat = 1;

		for j = 1, jMax do
		  for i = 1, iMax do
			if (kTimer[j][i] > 0) then kFrames[j][i]:Show() end;
		  end
		end

        if(Debug) then
		    kFrames[1][1]:Show();
		    kFrames[2][1]:Show();
            --kWarn[1]:Show();
            WarnFlag[1] = WarnDelay;
        end

		if (AnchorShow == 1) then
		  KickAlertRef:Hide();
		end
	end

	if (event == "PLAYER_REGEN_ENABLED" or event == "PLAYER_ALIVE" ) then
		if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Enabled!") end;
        if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("ClearOOC in regen "..ClearOOC) end;
		inCombat = 0;

		for j = 1, jMax do
		  for i = 1, iMax do
			kFrames[j][i]:Hide();
		  end
          if (ClearOOC == "Yes") then kWarn[j]:Hide() end;
		end
		
		if (AnchorShow == 1) then
		  KickAlertRef:Show();
		end
		
	end

	if (event == "COMBAT_LOG_EVENT_UNFILTERED") then
    
        for j = 1, jMax do
            if (arg2 == "UNIT_DIED" and arg7 == fName[j][1] and showWarn[j]) then
                kWarn[j].Warning:SetText(string.sub(fName[j][1], 1, 4).." is Dead!");
                kWarn[j]:Show();
            end
        end
            

        for k, v in pairs(kSpellInfo) do
        
		  if (arg9 == v.val) then
		    if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Event!k and args 2 4 9: " ..k.. arg2..arg4..arg9) end;
		    if (arg2 == "SPELL_CAST_SUCCESS") then                
              if (v.row > 0) then
                if (arg4 == kPlayer) then 
                    kWarn[v.row]:Hide();
                    kWarn[v.row].Warning:SetText(WarnMsg);
                else
			        KAL_Setup_Timer (v.row, v.cDown, arg4, v.icon);
			    end
              end
            end
		 
		  end
        end
	end

end

function KickAlert_OnUpdate(self, elapsed)

	local timeStep = .2;
    local ttext = "TBD";
	
	TimeSinceLastUpdate = TimeSinceLastUpdate + elapsed;
	while (TimeSinceLastUpdate > timeStep) do

	  for j = 1, jMax do
      
      if (WarnFlag[j] == 1) then 
          kWarn[j]:Show(); --Show alert after delay
          WarnFlag[j] = 0;
      end
      if (WarnFlag[j] > 1) then WarnFlag[j] = WarnFlag[j] - 1 end;
      
	    for i = 1, iMax do
        
        if ( kTimer[j][i] > 0) then
		  kTimer[j][i] = kTimer[j][i] - timeStep;
		  kFrames[j][i].Timer:SetText(string.format( "%.0f",kTimer[j][i]));
		  if (kTimer[j][i] <= 0) then
			kFrames[j][i]:Hide();
            if (fName[j][i] == "*") then
                ttext = "TBD";
            else
                ttext = fName[j][i];
            end
            kFrames[j][i].Name:SetText(string.sub(ttext, 1, 4));
			kName[j][i] = fName[j][i];
            kTimer[j][i] = 0; --Get rid of annoying minus signs
          end
		end   
		
	    end
	  end

	  TimeSinceLastUpdate = TimeSinceLastUpdate - timeStep;
	  
	end

end

function KAL_CreateIcon(jRow, iCol)


 	local ioff = (iCol-1)*40;
	
	local kalf = CreateFrame("FRAME","KAL_R"..jRow.."C"..iCol.."Icon", UIParent);
	kalf:SetFrameStrata("DIALOG");
	kalf:SetBackdrop({bgFile = "Interface/Icons/INV_Misc_QuestionMark"});

	kalf.Timer = kalf:CreateFontString("KAL_R"..jRow.."C"..iCol.."Icon_Timer","OVERLAY");
	kalf.Timer:SetFontObject(ChatFontNormal);
	kalf.Timer:SetPoint("TOP", 0, 15);

	kalf.Timer:SetText(kTimer[jRow][iCol]);

	kalf.Name = kalf:CreateFontString("KAL_R"..jRow.."C"..iCol.."Icon_Name","OVERLAY");
	kalf.Name:SetFontObject(ChatFontNormal);
	kalf.Name:SetPoint("BOTTOM", 0, -15);
      local tTemp = kName[jRow][iCol];
      if (tTemp == nil) then tTemp = "TBD" end;
	kalf.Name:SetText(string.sub(tTemp, 1, 4));
	kalf:Hide();

	return kalf;
end

function KAL_CreateWarning(jRow, rFrame)

	local kalf = CreateFrame("FRAME","KAL_R"..jRow.."Warning", UIParent);
	kalf:SetFrameStrata("DIALOG");
	kalf.Warning = kalf:CreateFontString("KAL_R"..jRow.."Warning_Text","OVERLAY");
	
	kalf.Warning:SetFont("Fonts\\\FRIZQT__.TTF", kWarnSize);

	kalf.Warning:SetText(WarnMsg);
	if (Debug) then
        kalf:Show();
    else
        kalf:Hide();
    end
	return(kalf);

end

function KickAlert_SlashHandler(msg)

    msg = string.lower(msg);

	if (msg == "anchor" or msg == "anc") then

	  if (AnchorShow == 0) then
		KAL_ShowAll();
		AnchorShow = 1;
	  else
		KAL_HideAll();
		AnchorShow = 0;
	  end

	elseif (msg == "options" or msg == "opt") then

	  InterfaceOptionsFrame_OpenToCategory(KALOpt);

	elseif (msg == "version" or msg == "ver") then
        DEFAULT_CHAT_FRAME:AddMessage("KickAlert version: "..kalVersion);

	elseif (msg == "name") then
	  fName[1][1] = "Aethowynd";
      fName[2][1] = "Aethowynd";
	  if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("KickAlert changed name "..fName[1][1].." "..fName[2][1]) end;
      
    elseif (msg == "debug") then
      if (Debug) then
        Debug = nil;
      else
        Debug = 1;
      end
      
    elseif (msg == "thorim") then
        showWarn[1] = nil;
        showWarn[2] = 1;
        
    elseif (msg == "general") then
        showWarn[1] = 1;
        showWarn[2] = nil;
        
    elseif (msg == "nowarn") then
        showWarn[1] = nil;
        showWarn[2] = nil;
        
    elseif (msg == "warn") then
        showWarn[1] = 1;
        showWarn[2] = 1;
        
    elseif (msg == "disable") then
        KickAlertFrame:Hide(); --Stop processing
        KickAlertFrame:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
        KAL_HideAll();
        AnchorShow = 0;
        -- Remove unit frame right-click menu option
	    for j = 1, #menuTypes do
		    local t = menuTypes[j];
		    for i = 1, #UnitPopupMenus[t] do
			    if (UnitPopupMenus[t][i] == "KAL_FOLLOW_LINE1") then
				    tremove(UnitPopupMenus[t], i);
				    break;
			    end
		    end
            for i = 1, #UnitPopupMenus[t] do
			    if (UnitPopupMenus[t][i] == "KAL_FOLLOW_LINE2") then
				    tremove(UnitPopupMenus[t], i);
				    break;
			    end
		    end
	    end

        
    elseif (msg == "enable") then
        KickAlertFrame:Show(); --Start processing
 	    KickAlertFrame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
        --Reinsert the menu options if they are not there
        local isThere = nil;
        for j = 1, #menuTypes do
            local t = menuTypes[j];
            if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("t is "..t) end;
            for i = 1, #UnitPopupMenus[t] do
	            if (UnitPopupMenus[t][i] == "KAL_FOLLOW_LINE1") then
				    isThere=1;
				    break;
                end
			end
		end
        if (isThere == nil) then
            for i = 1, #menuTypes do
		        tinsert(UnitPopupMenus[menuTypes[i]], #UnitPopupMenus[menuTypes[i]]-1, "KAL_FOLLOW_LINE1");
                tinsert(UnitPopupMenus[menuTypes[i]], #UnitPopupMenus[menuTypes[i]]-1, "KAL_FOLLOW_LINE2");
	        end
        end
        
    elseif (msg == "advanced" or msg == "adv") then 
        --KAL_AdvOptSetup();
        InterfaceOptionsFrame_OpenToCategory(KickAlert_AdvOpt);
        
    elseif (msg == "onerow" or msg == "one") then
        jMax = 1; --Only show kick line
        
    elseif (msg == "both" or msg == "two" or msg == "tworow") then
        jMax = 2;  --Show both kick and dismantle lines
        
    elseif (msg == "names" or msg == "blanknames") then
        for j = 1, jMax do
            for i = 1, iMax do
                fName[j][i] = "*";
            end
        end
        KAL_SetEntry(); -- Update options panel

    elseif ( msg == "clear") then
	    KAL_HideAll();
        
        
    
    elseif (msg == "clearooc") then
        if (ClearOOC == "Yes") then  --Toggles warning clear on going out of combat
            ClearOOC = "No";
        else
            ClearOOC = "Yes";
        end
        
    elseif (msg == "t1" or msg == "this1") then
        ttext = UnitName("target");
        if (ttext == nil) then ttext = "*" end;
        fName[1][1] = ttext;
        kName[1][1] = ttext;
        kFrames[1][1].Name:SetText(string.sub(ttext, 1, 4));
        KAL_SetEntry();
        KAL_GetEntry();
        DEFAULT_CHAT_FRAME:AddMessage("I will follow "..ttext.." for my "..rName[1]);
        
    elseif (msg == "t2" or msg == "this2") then
        ttext = UnitName("target");
        if (ttext == nil) then ttext = "*" end;
        fName[2][1] = ttext;
        kName[2][1] = ttext;
        kFrames[2][1].Name:SetText(string.sub(ttext, 1, 4));
        KAL_SetEntry();
        KAL_Getentry();
        DEFAULT_CHAT_FRAME:AddMessage("I will follow "..ttext.." for my "..rName[2]);
        
    elseif (msg == "secret" or msg == "sekrit") then
        kSecret =1;  --Turns on extra boxes in option screen
        KAL_SetEntry();
    
    else
        DEFAULT_CHAT_FRAME:AddMessage("KickAlert commands (/kickalert or /kal):");
        DEFAULT_CHAT_FRAME:AddMessage("/kal clear - Clear warning messages");
        DEFAULT_CHAT_FRAME:AddMessage("/kal version (/kal ver) - Shows the current version of KickAlert.");
        DEFAULT_CHAT_FRAME:AddMessage("/kal nowarn/warn - Turns off/on warning message");
        DEFAULT_CHAT_FRAME:AddMessage("/kal general or thorim - Turns on warning for kick or dismantle appropriately");
        DEFAULT_CHAT_FRAME:AddMessage("/kal disable/enable -- Turns addon off/on");
        DEFAULT_CHAT_FRAME:AddMessage("/kal options (/kal opt) - Brings up the option panel");
        DEFAULT_CHAT_FRAME:AddMessage("/kal onerow or one - Disable second line and show only the Kick row");
        DEFAULT_CHAT_FRAME:AddMessage("/kal both/two/tworow -- Show both Kick and Dismantle rows");
        DEFAULT_CHAT_FRAME:AddMessage("/kal names/blanknames -- Set all names to *");
        DEFAULT_CHAT_FRAME:AddMessage("/kal ClearOOc/clearooc -- Toggle whether or not exiting combat clears warning messages");
        DEFAULT_CHAT_FRAME:AddMessage("/kal advanced (/kal adv) -- Brings up the advanced option panel, use caution");
        DEFAULT_CHAT_FRAME:AddMessage("/kal this1 or this2 (t1/t2)  --  Makes your target the person you are assigned to follow");
        DEFAULT_CHAT_FRAME:AddMessage("/kal anchor (/kal anc) - Toggle the anchor to move icons");


    end

end

function KAL_Setup_Timer (jRow, kTime, cName, Icon)

--Check to see if name matches one of our fixed names.
--  if not, check that there is an open name

	local iCol;
	local Assigned = 0;
	for iCol = 1, iMax do
	  
	  if (Assigned == 1) then
      
      --do nothing, space reserved for future functions

	  elseif (cName == kName[jRow][iCol] or kName[jRow][iCol] == "*" ) then
		kName[jRow][iCol] = cName; -- In case it was the * that matched
		kFrames[jRow][iCol].Name:SetText(string.sub(cName, 1, 4));
		kFrames[jRow][iCol].Timer:SetText(kTime);
		kTimer[jRow][iCol] = kTime;
		kFrames[jRow][iCol]:SetBackdrop({bgFile = Icon});
		kFrames[jRow][iCol]:Show();
		Assigned=1;
        if (cName == fName[jRow][1] and showWarn[jRow]) then 
            --kWarn[jRow]:Show();  --Put in time delay
            WarnFlag[jRow] = WarnDelay;
            kWarn[jRow].Warning:SetText(WarnMsg);
        end

	  end
	end
end

function KAL_GetEntry(self)

    if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Entered GetEntry") end;
    local jRow, iCol;
    local iMost = min(4, iMax);
    
    for jRow = 1, jMax do
        
        for iCol = 1, iMost do
            local kalf = getglobal("KAL_Options_FixedNameR"..jRow.."C"..iCol);            
            fName[jRow][iCol] = kalf:GetText();
            if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("GetEntryR"..jRow.."C"..iCol.." is "..fName[jRow][iCol]) end;
            if (fName[jRow][iCol] == "") then 
                fName[jRow][iCol] = "*" ;  --Protect input
                kalf:SetText("*");
            end; 
            
            kName[jRow][iCol] = fName[jRow][iCol];
            
        end
        
        showWarn[jRow] = getglobal("KAL_Options_ShowWarn"..jRow):GetChecked();
        local ttest = showWarn[jRow];
        if (ttest == nil) then ttest = "nil" end;
        if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Checkbox "..jRow.." is "..ttest) end;
        
        iScale = KAL_Options_ScaleSlider:GetValue();
        if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Slider Scale is "..iScale) end;
        KAL_Sizing(iScale);  -- resize
        
    end
    
        
end

function KAL_SetEntry(self)
    --Setup default options, also used on cancel
    if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Entered SetEntry with fName "..fName[1][1])end ;
    
    local jRow, iCol;
    local iMost = min(4, iMax); --Don't allow more than 4 names
    local kalf;
    for jRow = 1, jMax do
        for iCol = 1, iMost do
        if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Iterated SetEntry with fName"..jRow..iCol..fName[jRow][iCol])end ;
            kalf = getglobal("KAL_Options_FixedNameR"..jRow.."C"..iCol);
            kalf:SetText(fName[jRow][iCol]);
        end
        getglobal("KAL_Options_ShowWarn"..jRow):SetChecked(showWarn[jRow]);
    end
    
    if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Try to set scale with "..iScale)end ;
    KAL_Options_ScaleSlider:SetValue(iScale);
    
    if (kSecret) then
        for jRow = 1, jMax do
            for iCol = 2, iMost do
              getglobal("KAL_Options_FixedNameR"..jRow.."C"..iCol):Show();
            end
        end
        getglobal("KAL_OptionsLabel1"):Show();
        
    end
    
        
end

function KAL_Sizing(iSize)

    -- Adjust sizes of all frames
    local Wide = iSize * iWidth;
    local sWarn = iSize * kWarnSize;
    local High = Wide + 28*iSize + sWarn + 10*iSize;
    local Space = iSize * iSpace;
    local kalf, kalfW; -- local frame ref
    local i, j; --loop indices


    -- Dimension anchor frame defined in XML
    KickAlertRef:SetWidth(iMax * (Wide + Space) );
    KickAlertRef:SetHeight(Wide + sWarn + (jMax-1) * (High + sWarn) );
    
    -- Dimension icons and warnings
    for j = 1, jMax do
    
        kalfW = getglobal("KAL_R"..j.."Warning");
        kalfW:SetWidth(Wide);
        kalfW:SetHeight(sWarn);
        kalfW.Warning:SetFont("Fonts\\\FRIZQT__.TTF", sWarn);
        kalfW.Warning:SetPoint("LEFT", 0, 0);
    
        for i = 1, iMax do
            kalf = getglobal("KAL_R"..j.."C"..i.."Icon");
            kalf:SetWidth(Wide);
            kalf:SetHeight(Wide);
            kalf:SetPoint("BOTTOMLEFT", "KickAlertRef", "BOTTOMLEFT", (i-1)*(Wide + Space) + Space, (j-1)*High);
            
            if (i == 1) then kalfW:SetPoint("BOTTOMLEFT", kalf, "TOPLEFT", 0, 15) end;
        
        end
        
    end
    
end

function KAL_ShowAll()

    local i, j;
    
    for j = 1, jMax do
    
        getglobal("KAL_R"..j.."Warning"):Show();
        for i = 1, iMax do
            getglobal("KAL_R"..j.."C"..i.."Icon"):Show();
        end
    end
    KickAlertRef:Show();
    
end
    
function KAL_HideAll()

    local i, j;
    
    for j = 1, jMax do
        kWarn[j].Warning:SetText(WarnMsg);
        kWarn[j]:Hide();
        --getglobal("KAL_R"..j.."Warning"):Hide();
        for i = 1, iMax do
            getglobal("KAL_R"..j.."C"..i.."Icon"):Hide();
        end
    end
    KickAlertRef:Hide();
    
end        
        
function KAL_AdvOptDone()
    
    local tval = KickAlert_AdvOpt_Slider1:GetValue();
    if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Return from adv opt "..tval)end ;
    local tval2 = KickAlert_AdvOpt_Slider2:GetValue();
    if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Return of default slider "..tval2)end ;
    
    for k,v in pairs(kSpellInfo) do
        v.row = getglobal("KickAlert_AdvOpt_Slider"..k):GetValue();
        if (Debug) then DEFAULT_CHAT_FRAME:AddMessage(v.name.." in row "..v.row)end ;
    end
    
    iMax = UIDropDownMenu_GetSelectedID(numIcons);
    KAL_Sizing(iScale); --resize anchor
    local tset = UIDropDownMenu_GetSelectedID(ClearQ);
    if (tset == 1) then
        ClearOOC = "No";
    else
        ClearOOC = "Yes";
    end
    if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Return of ClearOOC "..tset.." or "..ClearOOC)end ;
    
    KickAlert_AdvOpt:Hide();
    
end

function KAL_Drop(dFrame, dItems)
    
    local function Drop_OnClick(self)
        UIDropDownMenu_SetSelectedID(this.owner, this:GetID())
    end

    local function Drop_Initialize(self, level)
        level = level or 1;
        local info = UIDropDownMenu_CreateInfo();
        for k,v in pairs(dItems) do
            info = UIDropDownMenu_CreateInfo();
            info.text = v;
            info.value = v;
            info.owner = this:GetParent();
            info.func = Drop_OnClick;
            UIDropDownMenu_AddButton(info, level)
        end
    end


    UIDropDownMenu_Initialize(dFrame, Drop_Initialize)
    
end

function KAL_AdvOptSetup()
    --Initial setup of dropdown menus on advanced option frame
    --Should only be called once
    
    CreateFrame("Frame", "numIcons", KickAlert_AdvOpt, "UIDropDownMenuTemplate");
    numIcons:ClearAllPoints();
    numIcons:SetPoint("TOPLEFT", 94, -44);
    numIcons:Show();
    items = {
        "1",
        "2",
        "3",
        "4",
        "5",
        "6"
    }
    KAL_Drop(numIcons, items);  --Dropdown menu added in lua
    UIDropDownMenu_SetWidth(numIcons, 50);
    UIDropDownMenu_SetButtonWidth(numIcons, 50);
    UIDropDownMenu_JustifyText(numIcons, "RIGHT");
    
    CreateFrame("Frame", "ClearQ", KickAlert_AdvOpt, "UIDropDownMenuTemplate");
    ClearQ:ClearAllPoints();
    ClearQ:SetPoint("TOPLEFT", 200, -380);
    ClearQ:Show();
    items = {"No",
            "Yes"
            }
    KAL_Drop(ClearQ, items);
    UIDropDownMenu_SetWidth(ClearQ, 50);
    UIDropDownMenu_SetButtonWidth(ClearQ, 50);
    UIDropDownMenu_JustifyText(ClearQ, "CENTER");
    
    KAL_AdvOptSetVal();
    
end

function KAL_AdvOptSetVal()
    --Set starting values for Advanced Options Screen
    --Can be called as often as is necessary
    
    UIDropDownMenu_SetSelectedID(numIcons, iMax);
    UIDropDownMenu_SetText(numIcons, iMax);
    local tset = 1;
    if (ClearOOC == "No") then
        tset = 1;
    else
        tset = 2;
    end
    UIDropDownMenu_SetSelectedID(ClearQ, tset);
    UIDropDownMenu_SetText(ClearQ, ClearOOC);
    
    for k,v in pairs(kSpellInfo) do
        getglobal("KickAlert_AdvOpt_Name"..k.."Label"):SetText(v.name);
        getglobal("KickAlert_AdvOpt_Slider"..k):SetValue(v.row);
        
    end
end


function KAL_AdvOptCancel()
    
    --Restore default values
    KAL_AdvOptSetVal();
    
        
    --Close window
    KickAlert_AdvOpt:Hide();
    
end

function KAL_AdvOptDefault()

    --Replaces default settings.  Duplicates some code from above
    iMax = 4;
    jMax = 2;
    showWarn[1] = 1;
    showWarn[2] = 1;
    KAL_SetEntry();
    
    SpellSet = 0; --Default      
    if (kClass == "PRIEST") then SpellSet = 1 end;
    
    KAL_LoadSpellInfo(SpellSet);
                
    KAL_AdvOptSetVal();
    
end

function KAL_LoadSpellInfo(kSpellSet)

	--If there is already data loaded, clear it out
	if (kSpellInfo ~= nil) then

		for k,v in pairs(kSpellInfo) do
			kSpellInfo[k] = {val = nil, name = nil, cDown = nil, row = nil, icon = nil};
		end
	end

	--Load up spell data base, first with temp icon.
	tIcon = "Interface/Icons/INV_Misc_QuestionMark";

	if (kSpellSet == 1) then
	  --Healer spells
	  --Need to adjust label variables too
      rName[1] = "Big Cdowns";
      rName[2] = "Little Cdowns";
      
	  
      kSpellInfo = { {val = 871, name = "Shield Wall", cDown = 300, row = 1, icon = tIcon},
             { val = 12975, name = "Last Stand", cDown = 180, row = 1, icon = tIcon},
			 { val = 33206, name = "Pain Suppression", cDown = 180, row = 1, icon = tIcon},
			 { val = 47788, name = "Guardian Spirit", cDown = 180, row = 1, icon = tIcon},
			 { val = 6346, name = "Fear Ward", cDown = 180, row = 2, icon = tIcon},
			 { val = 498, name = "Divine Protection", cDown = 180, row = 1, icon = tIcon},
             { val = 22812, name = "Barkskin", cDown = 60, row =1, icon = tIcon},
			 { val = 48792, name = "Icebound Fortitude", cDown = 60, row =1, icon = tIcon},
		    };

	else
	  --Interrupt spells, default values
      rName[1] = "Kick Line";
      rName[2] = "Dismantle";
            
      if(kClass == "WARRIOR") then 
        rName[1] = "Interrupt";
        rName[2] = "Disarm";
        
      end

	  kSpellInfo = { {val = 1766, name = "Kick", cDown = 10, row = 1, icon = tIcon}, 
                   {val = 51722, name = "Dismantle", cDown = 60, row = 2, icon = tIcon},
                   {val = 72, name = "Shield Bash", cDown = 12, row = 1, icon = tIcon},
                   {val = 676, name = "Disarm", cDown = 60, row = 2, icon = tIcon},
                   {val = 6552, name = "Pummel", cDown = 10, row = 0, icon = tIcon},
                   {val = 57994, name = "Wind Shear", cDown = 6, row = 1, icon = tIcon},
                   {val = 47476, name = "Strangulate", cDown = 120, row = 0, icon = tIcon},
                   {val = 47528, name = "Mind Freeze", cDown = 10, row = 0, icon = tIcon},
                   {val = 2136, name = "Test1", cDown = 8, row = 1, icon = tIcon},
                   {val = 2136, name = "Test2", cDown = 15, row = 2, icon = tIcon},
                };

	end

	--Now put correct icons in

	for k,v in pairs(kSpellInfo) do
		_, _, newIcon = GetSpellInfo(kSpellInfo[k].val);
		kSpellInfo[k].icon = newIcon;
	end
    
    --Update labels
    KAL_Options_Label1Label:SetText(rName[1]);
    KAL_Options_Label2Label:SetText(rName[2]);
    
    UnitPopupButtons["KAL_FOLLOW_LINE1"] = {
		    text = "Follow this person with "..rName[1],
		    dist = 0,
		    func = KAL_NameLine1
	        }
            
    UnitPopupButtons["KAL_FOLLOW_LINE2"] = {
		    text = "Follow this person with "..rName[2],
		    dist = 0,
		    func = KAL_NameLine2
	        }

end

function KAL_ChangeSpellSet()

    --Only two sets to change between atm
    
    if (SpellSet == 0) then
        SpellSet = 1;
    else
        SpellSet = 0;
    end
    
    KAL_LoadSpellInfo(SpellSet);
    
    KAL_SetEntry();  --Rewrite the options screen
    
end

function KAL_ShowMenu(dropdownMenu, which, unit, name, userData, ...)

	local button
	for i=1, UIDROPDOWNMENU_MAXBUTTONS do
		button = _G["DropDownList"..UIDROPDOWNMENU_MENU_LEVEL.."Button"..i];
		if button.value == "KAL_FOLLOW_LINE1" then
		    button.func = UnitPopupButtons["KAL_FOLLOW_LINE1"].func
		end
        if button.value == "KAL_FOLLOW_LINE2" then
		    button.func = UnitPopupButtons["KAL_FOLLOW_LINE2"].func
		end
	end
end

function KAL_NameLine1()
    local unit = UIDROPDOWNMENU_INIT_MENU.name or "*";

    if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Entered KAL_NameLine1 unit = "..unit)end ;
    fName[1][1] = unit;
    kName[1][1] = unit;
    kFrames[1][1].Name:SetText(string.sub(unit, 1, 4));
    DEFAULT_CHAT_FRAME:AddMessage("I will follow "..unit.." for my "..rName[1]);
    KAL_SetEntry();
    KAL_GetEntry();
    
end

function KAL_NameLine2()
    local unit = UIDROPDOWNMENU_INIT_MENU.name or "*";

    if (Debug) then DEFAULT_CHAT_FRAME:AddMessage("Entered KAL_NameLine2 unit = "..unit)end ;
    fName[2][1] = unit;
    kName[2][1] = unit;
    kFrames[2][1].Name:SetText(string.sub(unit, 1, 4));
    DEFAULT_CHAT_FRAME:AddMessage("I will follow "..unit.." for my "..rName[2]);
    KAL_SetEntry();
    KAL_GetEntry();
    
end

