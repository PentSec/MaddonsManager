--DropDownHandlers

--
-- Set up and handle the Drop downs in the help menu
--

function WC.Frame_OnLoad( theConfigFrame ) --the inital position of the config frame is to the right of the WhammyFrame opening downward
	--W.ShowMessage("WC.Frame_OnLoad")
	
	WC.Create_UI(); --create the UI of the config frame

	--W.ShowMessage("WC.Frame_OnLoad Complete")
end

function WC.Frame_MouseDown( theConfigFrame, whichButton)
	if ( whichButton == "LeftButton" ) then -- drag the frame
		theConfigFrame:StartMoving();
	end
end


function WC.Create_UI()
	--W.ShowMessage("WC.Creating_UI")

	-- position and size the configframe
	local f = WhammyConfigFrame;
	local x,y;
	f:SetWidth(600);
	f:SetHeight(400);
	f:SetPoint("CENTER", "UIParent", "CENTER")
	
	local tt = CreateFrame("GameTooltip", "MyScanningTooltip", nil, "GameTooltipTemplate")

	tt:SetOwner( f, "ANCHOR_TOPRIGHT" );
	--tt:AddFontStrings( MyScanningTooltip:CreateFontString( "$parentTextLeft1", nil, "GameTooltipText" ), MyScanningTooltip:CreateFontString( "$parentTextRight1", nil, "GameTooltipText" ) );

	-- Create the window title
	x = 0
	y = -8
	f.title = f:CreateFontString("WC_Title", "OVERLAY", "GameFontNormal");
	f.title:SetText(WC_kConfigWindowTitle);
	f.title:SetPoint("TOP", f, "TOP", x, y); --centered at the top
	
	
	
	-- Create the Mouse Button Clicks Title
	x = 130;
	y = -35
	f.mouseClicksTitle = f:CreateFontString("WC_Title_MouseClicks", "OVERLAY", "GameFontNormal");
	f.mouseClicksTitle:SetText(WC_kMouseClicksText);
	f.mouseClicksTitle:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	
	-- Create the Other Options Title
	x = 430;
	f.otherOptionsTitle = f:CreateFontString("WC_Title_OtherOptions", "OVERLAY", "GameFontNormal");
	f.otherOptionsTitle:SetText(WC_kOtherOptionsText);
	f.otherOptionsTitle:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	
	-- Create the Left, Middle, Right labels down the left hand side
	x = 30;
	y = -95;
	f.left = f:CreateFontString("WC_Label_Left", "OVERLAY", "GameFontNormalSmall");
	f.left:SetText(WC_kLeftText);
	f.left:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	
	y=y-45;
	f.middle = f:CreateFontString("WC_Label_Center", "OVERLAY", "GameFontNormalSmall");
	f.middle:SetText(WC_kMiddleText);
	f.middle:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	
	y=y-45;
	f.right = f:CreateFontString("WC_Label_Right", "OVERLAY", "GameFontNormalSmall");
	f.right:SetText(WC_kRightText);
	f.right:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	
	y=y-45;
	f.button4 = f:CreateFontString("WC_Label_Button4", "OVERLAY", "GameFontNormalSmall");
	f.button4:SetText(WC_kButton4Text);
	f.button4:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	
	y=y-45;
	f.button5 = f:CreateFontString("WC_Label_Button5", "OVERLAY", "GameFontNormalSmall");
	f.button5:SetText(WC_kButton5Text);
	f.button5:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	
	-- Create the No modifier, Shift, Ctrl and Alt labels across the top
	x = 96;
	y = -65;
	f.shift = f:CreateFontString("WC_Label_NoMod", "OVERLAY", "GameFontNormalSmall");
	f.shift:SetText(WC_kNoMod);
	f.shift:SetPoint("TOPLEFT", f, "TOPLEFT", x, y)

	x=170
	f.shift = f:CreateFontString("WC_Label_Shift", "OVERLAY", "GameFontNormalSmall");
	f.shift:SetText(WC_kShift);
	f.shift:SetPoint("TOPLEFT", f, "TOPLEFT", x, y)

	x=230
	f.ctrl = f:CreateFontString("WC_Label_Ctrl", "OVERLAY", "GameFontNormalSmall");
	f.ctrl:SetText(WC_kCtrl);
	f.ctrl:SetPoint("TOPLEFT", f, "TOPLEFT", x, y)

	x=290
	f.alt = f:CreateFontString("WC_Label_Alt", "OVERLAY", "GameFontNormalSmall");
	f.alt:SetText(WC_kAlt);
	f.alt:SetPoint("TOPLEFT", f, "TOPLEFT", x, y)

	-- Now we need the drop slots (1-12) for mapping spells to mouse clicks 1,2,3 are left middle right etc
	WC.DropSlot_CreateSlots(f);
	
	WC.Create_Controls( f ); --create the controls for the config frame
	
	--W.ShowMessage("WC.Creating_UI Complete")
end


-- init the options array and set it too defaults. Called from AddonLoaded event when it first starts, and also if the user clicks the Defaults button
function WC.Init_Controls()
	--W.ShowMessage("WC.Init_Controls");
	
	local f = WhammyConfigFrame;
	
	f.muteAilmentSoundCheckButton:SetChecked( W_Options.Mute );	
	f.summaryCheckButton:SetChecked( W_Options.ShowSummary );
	f.buttonSizeCheckButton:SetChecked( W_Options.ButtonSize );
	f.rangeCheckButton:SetChecked( W_Options.RangeCheck );
	f.threatNotifyButton:SetChecked( W_Options.ThreatNotify );
	f.isFrameMovableButton:SetChecked( W_Options.Movable );
	
	UIDropDownMenu_SetSelectedValue(WC_Health_DropDown, W_Options.Health1);
	UIDropDownMenu_SetSelectedValue(WC_Health2_DropDown, W_Options.Health2);
	if ( W_Options.Health1 ~= "Off" ) then --if health1 is not off, activate health 2
		UIDropDownMenu_EnableDropDown( WC_Health2_DropDown );
		WC_Health2_Text:SetFontObject( "GameFontNormalSmall");
	end

	WC.Click_CheckButton_Summary( W_Options.ShowSummary );	-- show the summary frame or not
	WC.Click_CheckButton_RangeCheck( W_Options.RangeCheck ) --init the range checking to on or off
	f.miniMapSlider:SetValue(W_Options.Angle); --set the slider on the config window
	--W.ShowMessage("WC.Init_Controls Complete");
end


function WC.DropSlot_CreateSlots( f )
	--W.ShowMessage("DropSlot_CreateSlots")
	local x,y
	
	for i = 1,20 do
		f.dropslot = CreateFrame("CheckButton", "WC_DropSlot"..i, f, "ItemButtonTemplate");
		f.dropslot:SetWidth(36);
		f.dropslot:SetHeight(36);
		f.dropslot:RegisterForDrag("LeftButton")
		f.dropslot:SetScript("OnReceiveDrag", function(self) WC.DropSlot_Dropped(self); end );
		f.dropslot:SetScript("OnClick", function(self) WC.DropSlot_OnClick(self); end );
		f.dropslot:SetScript("OnEnter", function(self) WC.DropSlot_OnEnter(self); end);
		f.dropslot:SetScript("OnLeave", function(self) WC.DropSlot_OnLeave(self); end);
		f.dropslot:SetScript("OnDragStart", function(self) WC.DropSlot_OnDragStart(self); end);
		f.dropslot.slotNumber = i;
		if (i==6 or i==7 or i==8 or i==9 or i==10) then
			f.dropslot.keyPress = "shift";
		elseif (i==11 or i==12 or i==13 or i==14 or i==15) then
			f.dropslot.keyPress = "ctrl";
		elseif (i==16 or i==17 or i==18 or i==19 or i==20) then
			f.dropslot.keyPress = "alt"
		else
			f.dropslot.keyPress = ""; --covers 1,2,3
		end
		
		-- note that left button = 1,  right = 2 and middle = 3. The 'grid' of buttons goes 1-5 downthe first column, then 6-10 etc
		if ( i==1 or i==6 or i==11 or i==16) then --left click
			f.dropslot.mouseButton = "1";
		elseif (i==2 or i==7 or i==12 or i==17) then --center click
			f.dropslot.mouseButton = "3";
		elseif (i==3 or i==8 or i==13 or i==18) then --right click
			f.dropslot.mouseButton = "2";
		elseif (i==4 or i==9 or i==14 or i==19) then --button 4
			f.dropslot.mouseButton = "4";
		elseif (i==5 or i==10 or i==15 or i==20) then --button 5
			f.dropslot.mouseButton = "5";
		end
	end
	
	--no modifier key slots
	x=102
	y=-82
	WC_DropSlot1:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot2:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot3:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot4:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot5:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	
	--shift modifier key slots
	x=164
	y=-82
	WC_DropSlot6:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot7:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot8:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot9:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot10:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	
	--ctrl modifier key slots
	x=223
	y=-82
	WC_DropSlot11:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot12:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot13:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot14:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot15:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);

	--alt modifier key slots
	x=282
	y=-82
	WC_DropSlot16:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot17:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot18:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot19:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
	y=y-46
	WC_DropSlot20:SetPoint("TOPLEFT", f, "TOPLEFT", x, y);
end

function WC.Create_Controls( f )
	local x = 10;
	local y = -20;
	
	--Create a divider to separate one half from the other. It's also a point of reference for the checkboxes
	f.divider = f:CreateTexture();
	f.divider:SetWidth(2);
	local h = f:GetHeight()-60; --height of the frame - 40, 20 space on top and bottom
	f.divider:SetHeight(h);
	f.divider:SetPoint("TOPLEFT", f, "TOPLEFT", h, -30);
	f.divider:SetTexture(.5, .5, .5, .4);

	
	--Create and Setup Defaults Text and Button
	f.defaultText = f:CreateFontString("WC_Defaults_Text", "OVERLAY", "GameFontNormal");
	f.defaultText:SetJustifyH("LEFT")
	f.defaultText:SetText(WC_kDefaultText);
	f.defaultText:SetWidth(340);
	f.defaultText:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 10, 50);
	
	f.defaultButton = CreateFrame("Button", "WC_DefaultButton", f, "UIPanelButtonTemplate");
	f.defaultButton:SetWidth(80);
	f.defaultButton:SetHeight(22);
	f.defaultButton:SetPoint("TOPLEFT", f.defaultText, "TOPLEFT", 240, -35);
	f.defaultButton:SetScript("OnClick", function(self) WC.DefaultButton_OnClick(self); end );
	f.defaultButton:SetText("Defaults");

	--Create and setup Summary CheckButton (the little summary window that shows group mana and health)
	f.summaryCheckButton = CreateFrame("CheckButton", "WC_CheckButton_ShowSummary", f, "UICheckButtonTemplate");
	f.summaryCheckButton:SetWidth(30);
	f.summaryCheckButton:SetHeight(30);
	f.summaryCheckButton:SetPoint("TOPLEFT", f.divider, "TOPRIGHT", x, y);
	f.summaryCheckButton:SetScript("OnClick", function(self) WC.Click_CheckButton_Summary( self:GetChecked() ); end );
	getglobal(f.summaryCheckButton:GetName().."Text"):SetText(WC_kShowSummaryCheckButtonText);
	
	--Create and setup the Button Size CheckButton
	f.buttonSizeCheckButton = CreateFrame("CheckButton", "WC_CheckButton_ButtonSize", f, "UICheckButtonTemplate");
	f.buttonSizeCheckButton:SetWidth(30);
	f.buttonSizeCheckButton:SetHeight(30);
	f.buttonSizeCheckButton:SetPoint("TOPLEFT", f.divider, "TOPRIGHT", x, y-25);
	f.buttonSizeCheckButton:SetScript("OnClick", function(self) WC.Click_CheckButton_ButtonSize( self:GetChecked() ); end );
	getglobal(f.buttonSizeCheckButton:GetName().."Text"):SetText(WC_kButtonSizeCheckButtonText);

	--Create and setup the Mute Ailment Sound CheckButton
	f.muteAilmentSoundCheckButton = CreateFrame("CheckButton", "WC_CheckButton_MuteAilmentSound", f, "UICheckButtonTemplate");
	f.muteAilmentSoundCheckButton:SetWidth(30);
	f.muteAilmentSoundCheckButton:SetHeight(30);
	f.muteAilmentSoundCheckButton:SetPoint("TOPLEFT", f.divider, "TOPRIGHT", x, y-50);
	f.muteAilmentSoundCheckButton:SetScript("OnClick", function(self) WC.Click_CheckButton_MuteAilmentSound( self:GetChecked() ); end );
	getglobal(f.muteAilmentSoundCheckButton:GetName().."Text"):SetText(WC_kMuteAilmentSoundText);

	--Create and setup the Range Check CheckButton
	f.rangeCheckButton = CreateFrame("CheckButton", "WC_CheckButton_RangeCheck", f, "UICheckButtonTemplate");
	f.rangeCheckButton:SetWidth(30)
	f.rangeCheckButton:SetHeight(30)
	f.rangeCheckButton:SetPoint("TOPLEFT", f.divider, "TOPRIGHT", x, y-75)
	f.rangeCheckButton:SetScript("OnClick", function(self) WC.Click_CheckButton_RangeCheck( self:GetChecked() ); end );
	getglobal(f.rangeCheckButton:GetName().."Text"):SetText(WC_kRangeCheckText);
	
	--Create and setup the Threat notification CheckButton
	f.threatNotifyButton = CreateFrame("CheckButton", "WC_CheckButton_ThreatNotify", f, "UICheckButtonTemplate");
	f.threatNotifyButton:SetWidth(30)
	f.threatNotifyButton:SetHeight(30)
	f.threatNotifyButton:SetPoint("TOPLEFT", f.divider, "TOPRIGHT", x, y-100)
	f.threatNotifyButton:SetScript("OnClick", function(self) WC.Click_CheckButton_ThreatNotify( self:GetChecked() ); end );
	getglobal(f.threatNotifyButton:GetName().."Text"):SetText(WC_kThreatNotifyText);
	
	--Create and setup the Lock Frame CheckButton
	f.isFrameMovableButton = CreateFrame("CheckButton", "WC_CheckButton_IsFrameMovable", f, "UICheckButtonTemplate");
	f.isFrameMovableButton:SetWidth(30)
	f.isFrameMovableButton:SetHeight(30)
	f.isFrameMovableButton:SetPoint("TOPLEFT", f.divider, "TOPRIGHT", x, y-125)
	f.isFrameMovableButton:SetScript("OnClick", function(self) WC.Click_CheckButton_IsFrameMovable( self:GetChecked() ); end );
	getglobal(f.isFrameMovableButton:GetName().."Text"):SetText(WC_kIsFrameMovableText);
	
	
	-- The labels and dropdowns for the two health alert dropdowns
	f.healthText = f:CreateFontString("WC_Health_Text", "OVERLAY", "GameFontNormalSmall");
	f.healthText:SetText(WC_kConfigHealthAlertText);
	f.healthText:SetPoint("TOPLEFT", f.divider, "TOPRIGHT", x+5, y-170);
	-- create the drop down menu for health alert #1
	f.healthDropDown = CreateFrame("Frame", "WC_Health_DropDown", f, "UIDropDownMenuTemplate")
	f.healthDropDown:SetPoint("LEFT", f.healthText, "RIGHT", 0, 0)
	UIDropDownMenu_SetWidth(f.healthDropDown, 50);
	UIDropDownMenu_Initialize(f.healthDropDown, WC.Health_DropDownMenu_Initialize);	
	UIDropDownMenu_SetSelectedValue( f.healthDropDown, "Off" )
	
	f.health2Text = f:CreateFontString("WC_Health2_Text", "OVERLAY", "GameFontDisableSmall");
	f.health2Text:SetText(WC_kConfigHealthAlertText2);
	f.health2Text:SetPoint("TOPLEFT", f.divider, "TOPRIGHT", x+35, y-200);
	-- create the drop down menu for health alert #2
	f.health2DropDown = CreateFrame("Frame", "WC_Health2_DropDown", f, "UIDropDownMenuTemplate")
	f.health2DropDown:SetPoint("LEFT", f.health2Text, "RIGHT", 0, 0)
	UIDropDownMenu_SetWidth(f.health2DropDown, 50);
	UIDropDownMenu_Initialize(f.health2DropDown, WC.Health2_DropDownMenu_Initialize);
	UIDropDownMenu_DisableDropDown(f.health2DropDown)
	UIDropDownMenu_SetSelectedValue( f.health2DropDown, "Off" )
	
	--Create and position the minimap icon text and slider in the config window
	f.sliderText = f:CreateFontString("WC_Slider_Text", "OVERLAY", "GameFontNormalSmall");
	f.sliderText:SetJustifyH("LEFT");
	f.sliderText:SetText( WC_kIcon_Pos_Text );
	f.sliderText:SetWidth(100);
	f.sliderText:SetPoint("TOPLEFT", f.divider, "TOPRIGHT", x+5, y-230);
	
	f.miniMapSlider = CreateFrame("Slider", "WC_MiniMapIconPosSlider", f, "OptionsSliderTemplate")
	f.miniMapSlider:SetWidth( 100 );
	f.miniMapSlider:SetHeight( 24 );
	f.miniMapSlider:SetPoint("TOPLEFT", f.sliderText, "TOPRIGHT", 15, 5)
	f.miniMapSlider:SetMinMaxValues(0,359);
	f.miniMapSlider:SetValueStep(1);
	f.miniMapSlider:SetScript("OnValueChanged", function(self) WC.MiniMapIconPosSlider_ValueChanged(self); end );
	
	WC_MiniMapIconPosSliderText:SetFont("FRIZQT__.TTF",11,"OUTLINE, MONOCHROME");
	WC_MiniMapIconPosSliderText:SetText();
	WC_MiniMapIconPosSliderText:SetTextColor(0,1,1);
	WC_MiniMapIconPosSliderHigh:SetText();
	WC_MiniMapIconPosSliderLow:SetText();
	
end

--
-- Called when we first load up the mod to put the saved spells into their respective slots. Can only be called AFTER Player_login since we need to read from the spell book.
--
function WC.DropSlot_Init()
	--W.ShowMessage("DropSlot_Init")

	local specTable = WC.GetSpecTable(); --returns either the primary or secondary talent
	
	if ( specTable ) then
		for slotNum = 1,20 do
			local action = specTable[slotNum];
			local dropSlot = getglobal("WC_DropSlot"..slotNum);
			if (action) then --if there is an action, put it in the corresponding slot
				local infoType = action[1]; -- item, spell or macro
				local info1 = action[2]; -- itemID, spellName, macroID
				local info2 = action[3]; --if item then its link, if spell then spell or pet
				-- W.ShowMessage("dropSlot: "..dropSlot:GetName() );
				-- W.ShowMessage("InfoType: "..infoType)
				-- W.ShowMessage("Info1: "..info1)
				-- W.ShowMessage("Info2: "..info2)
				WC.DropSlot_SetSlot(dropSlot, infoType, info1, info2);
			else --no action so clear the slot
				WC.DropSlot_Clear(dropSlot);
			end
		end
	end

	--the below was original code that worked when there was only one spec
	-- if (W_Options.Actions) then
	-- 	for slotNum = 1,20 do
	-- 		local action = W_Options.Actions[slotNum];
	-- 		if (action) then --if there is an action, set the slot to it
	-- 			local infoType = action[1]; -- item, spell or macro
	-- 			local info1 = action[2]; -- itemID, spellName, macroID
	-- 			local info2 = action[3]; --if item then its link, if spell then spell or pet
	-- 		
	-- 			local dropSlot = getglobal("WC_DropSlot"..slotNum);
	-- 			WC.DropSlot_SetSlot(dropSlot, infoType, info1, info2)
	-- 		end
	-- 	end
	-- end
	--W.ShowMessage("DropSlot_Init complete")
end

--
-- return the table of which talents to use, primary or secondary
--
function WC.GetSpecTable()
	local isInspect, isPet = false;
	local activeSpec = GetActiveTalentGroup(isInspect, isPet); --1 for primary spec, 2 for secondary
	local specTable = {};
	
	if ( activeSpec == 1 ) then --primary spec
		specTable = W_Options.Actions;
		--W.ShowMessage("Primary spec")
	else --secondary spec
		specTable = W_Options.Actions2;
		--W.ShowMessage("Secondary spec")
	end
	
	return specTable --this will either be the primary table or the secondary
end

-- We are trying to drag the item, spell or macro out of the slot, copy it into the cursor
function WC.DropSlot_OnDragStart( theDropSlot )
	--W.ShowMessage("DropSlot_OnDragStart: "..theDropSlot:GetName() );
	if (theDropSlot.hasItem) then
		WC.DropSlot_PickUpItem( theDropSlot.infoType, theDropSlot.info1, theDropSlot.info2)
		WC.DropSlot_Clear(theDropSlot); --clear the dropslot
	end
end

function WC.DropSlot_PickUpItem( infoType, info1, info2)
	--W.ShowMessage("Pickup Item")
	if (infoType == "item") then
		local itemID = info1;
		PickupItem(itemID);
	elseif (infoType == "spell") then
		local spellName = info1;  --slot can change when new spells are learned, so we need to find it
		local bookType = info2;  --spell or pet
		local spellbookIndex = WC.GetSpellbookIndex( spellName, bookType );
		PickupSpell(spellbookIndex, bookType);
		
	elseif (infoType == "macro") then
		local macroID = info1
		PickupMacro( macroID );
	end
end



-- Clear the drop slot when whatever was in it is dragged out
function WC.DropSlot_Clear( theDropSlot )
	--W.ShowMessage("DropSlot_Clear: "..theDropSlot:GetName() )
	theDropSlot.hasItem = nil;
	theDropSlot.infoType = nil; --stops the unit buttons from doing anything
	theDropSlot.info1 = nil;
	theDropSlot.info2 = nil;
	theDropSlot.toolTip = nil;
	theDropSlot.actionWhenPressed = nil;
	SetItemButtonTexture( theDropSlot, nil);
	local specTable = WC.GetSpecTable(); --either the primary or secondary talents
	if ( specTable[theDropSlot.slotNumber] ) then --if there was an action, clear it
		specTable[theDropSlot.slotNumber] = nil; --clear the item from the array as well
	end
	-- if ( W_Options.Actions[theDropSlot.slotNumber] ) then --if there was an action, clear it
	-- 	W_Options.Actions[theDropSlot.slotNumber] = nil; --clear the item from the array as well
	-- end
	
	WC.UpdateUnitButtons(theDropSlot);
end

-- when the cursor enters a dropslot, set the tooltip to display what's in the slot
function WC.DropSlot_OnEnter( theDropSlot )
	GameTooltip:SetOwner(theDropSlot, "ANCHOR_RIGHT");
	
	if (theDropSlot.hasItem) then --it has something in the slot
		if ( theDropSlot.infoType == "item" ) then
			local itemID = theDropSlot.info1;
			local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(itemID);
			GameTooltip:ClearLines();
			GameTooltip:SetText(itemName);
		elseif ( theDropSlot.infoType == "spell" ) then
			local spellName = theDropSlot.info1;
			local bookType = theDropSlot.info2;
			local spellbookIndex = WC.GetSpellbookIndex( spellName, bookType)
			GameTooltip:ClearLines();			
			GameTooltip:SetSpell( spellbookIndex, bookType )
		elseif ( theDropSlot.infoType == "macro" ) then
			local macroID = theDropSlot.info1;
			local macroName, macroTexture, macroBody, localVar = GetMacroInfo( macroID );
			GameTooltip:ClearLines();			
			GameTooltip:SetText(macroName);
		end

	end
end

-- we leave the dropslot, so clear the tooltip
function WC.DropSlot_OnLeave( theDropSlot )
	GameTooltip:Hide();
end

-- called from init to load up the slots from saved data, or when we drop something on a slot
function WC.DropSlot_SetSlot(theDropSlot, infoType, info1, info2 )
	--W.ShowMessage("DropSlot_SetSlot: "..theDropSlot:GetName() )
	--infoType is item, spell or macro
	--info1 is itemID, spellName or MacroID
	--info2 is spell or pet if it's a spell
	local theAction;
	
	theDropSlot.hasItem = true;
	
	if (infoType == "item") then
		local itemID = info1;
		local link = info2;
		local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(itemID);
		if ( itemTexture ) then
			SetItemButtonTexture( theDropSlot, itemTexture )
			theAction = itemName; --used in update unit buttons to tell the button what to do when pressed
		end
	elseif (infoType == "spell") then
		local spellName = info1;
		local bookType = info2;
		local spellbookIndex = WC.GetSpellbookIndex(spellName, bookType); --get the current spellbook index for this spell
		local spellTexture = GetSpellTexture( spellbookIndex, bookType )
		if (spellTexture) then
			SetItemButtonTexture( theDropSlot, spellTexture ); --set the drop slot texture to match the spell texture
			theAction = spellName;
		end
		
	elseif (infoType == "macro") then
		local macroID = info1; --if we are dropping a macro, it will be the ID, if we a loading from the table, it will be the name
		local macroName, macroTexture, macroBody, localVar = GetMacroInfo( macroID );
		if (macroTexture) then
			SetItemButtonTexture( theDropSlot, macroTexture );
			theAction = macroName;
		end
	end
	
	--now keep track of the info in the slot
	theDropSlot.infoType = infoType; --type:  "item", "spell", "macro"
	theDropSlot.info1 = info1; --itemID, spellName, macroID
	theDropSlot.info2 = info2; --itemLink for item, "spell" or "pet" for spells and nil for macro's'
	theDropSlot.actionWhenPressed = theAction;
	
	--update the unit buttons to reflect the item, spell or macro
	WC.UpdateUnitButtons( theDropSlot );

	--Store the thing in the globally saved array
	local slotNumber = theDropSlot.slotNumber;
	local specTable = WC.GetSpecTable();
	specTable[slotNumber] = {infoType, info1, info2}; --store the settings in the va
	--W_Options.Actions[slotNumber] = {infoType, info1, info2}; --store the settings in the var
end

-- dropped an item, spell or macro on a slot
function WC.DropSlot_Dropped( theDropSlot )
	--W.ShowMessage("DropSlot_Dropped: "..theDropSlot:GetName() )
	--see what the cursor is holding  "item"  "spell"  "macro"  "money"  "merchant"
	local i1, i2;
	local oldInfoType, oldInfo1, oldInfo2;
	local hasOldOne;
	local okToDrop = true;
	local combatLockDown = InCombatLockdown();
	local infoType, info1, info2 = GetCursorInfo(); --get what the cursor now holds. infoType = item, spell or macro.  info1 = spellID (index in spell book) or macroID
	
	if ( not combatLockDown ) then
		if ( infoType) then
			if ( theDropSlot.hasItem ) then --we have dropped something onto a slot with something in it, so accept the drop and stick the existing item back into the cursor
				oldInfoType = theDropSlot.infoType;
				oldInfo1 = theDropSlot.info1;
				oldInfo2 = theDropSlot.info2;
				hasOldOne = true;
			end

			if ( infoType == "item" ) then
				i1 = info1;
				i2 = info2;
			elseif (infoType == "spell" ) then
				local spellbookIndex = info1; --the index of where this spell sits in the spellbook. This can change.
				local bookType = info2;
				local spellName = GetSpellName(spellbookIndex, bookType); --get the name of the spell that was dropped
				local name, spellRank, icon, cost, isFunnel, powerType, castTime, minRange, maxRange = GetSpellInfo(spellName); --get the name of the dropped spell
		
				if ( IsPassiveSpell( spellbookIndex, bookType) ) then
					UIErrorsFrame:AddMessage(WC_DropPassiveSpellError, 1.0, 0.0, 0.0, 53, 5);
					okToDrop = false;
				elseif ( spellName == nil or spellRank == nil) then
					UIErrorsFrame:AddMessage(WC_DropError, 1.0, 0.0, 0.0, 53, 5);
					okToDrop = false;
				else
					i1 = spellName; --we store spellName in the database as the id (i.e. slot number) may change in the future
					i2 = bookType;
				end
			elseif (infoType == "macro" ) then
				i1 = info1;
				i2 = info2;
			end
	
			if ( okToDrop ) then
				WC.DropSlot_SetSlot( theDropSlot, infoType, i1, i2); --set the slot (and array) to hold this data

				ClearCursor(); --clear the cursor
	
				if (hasOldOne) then --the slot had something in it previously, so put the old item into the cursor
					WC.DropSlot_PickUpItem( oldInfoType, oldInfo1, oldInfo2)
				end
			end
		end
	else
		UIErrorsFrame:AddMessage(WC_NoChangesInCombat, 1.0, 0.0, 0.0, 53, 5);
	end
end

function WC.GetBookType( spellOrPet )
	local whichBook
	if ( spellOrPet == "spell" ) then
		whichBook = BOOKTYPE_SPELL
	else
		whichBook = BOOKTYPE_PET
	end
	return whichBook
end

-- look through the spell book for a spell by this name, and return it's ID
function WC.GetSpellbookIndex(spellName, bookType)
	local found = false;
	
	for tabIndex = 1, MAX_SKILLLINE_TABS do
		local tabName, tabTexture, tabSpellOffset, tabNumSpells = GetSpellTabInfo(tabIndex);
		
		if not tabName then
			break;
		end
		
		for spellIndex = tabSpellOffset + 1, tabSpellOffset + tabNumSpells do
			local spell, rank = GetSpellName(spellIndex, bookType);
			if (spell == spellName) then
				found = true;
				return spellIndex;
			end
		end
	end
	
	return nil;
end

function WC.GetItemID(itemName)
	local _, link = GetItemInfo(itemName)
	local itemID = link and tonumber(link:match("item:(%d+)"))
	
	return itemID
end

function WC.DropSlot_OnClick( theDropSlot )
	--W.ShowMessage(theDropSlot:GetName().." onclick");

	local infoType, info1, info2 = GetCursorInfo(); --if we clicked something, then clicked the dropslot, treat it like a drag and drop
	if ( infoType ) then
		--W.ShowMessage("passing slot info to DropSlot Dropped");
		WC.DropSlot_Dropped( theDropSlot );
	end
end

--call to update all of the unit buttons when we have assigned a slot a new item, spell or macro
function WC.UpdateUnitButtons( theDropSlot )
	--W.ShowMessage("UpdateUnitButtons: "..theDropSlot:GetName() )
	local buttonNum;
	local infoType, actionWhenPressed;
	local keyPress = theDropSlot.keyPress; --will be emptystring, shift, ctrl or alt
	local mouseButton = theDropSlot.mouseButton; --will be a string of 1, 2, 3 etc
	local f = WhammyFrame;
	
	if ( theDropSlot.hasItem ) then
		infoType = theDropSlot.infoType; --will be item spell or macro, or stop if we have reset or cleared the slot
		actionWhenPressed = theDropSlot.actionWhenPressed; --will be the name of the item, spell or Macro
	else --slot was nil so clear the button out that is associated with the slot.
		infoType = "stop"
		actionWhenPressed = nil;
	end
	
	if ( keyPress == "ctrl" or keyPress == "shift" or keyPress == "alt") then --if there is a keypress modifier then we need to add 
		keyPress = ( keyPress.."-" ); --                                       the dash so the attribute will be properly formatted
	end
	
	local x = (keyPress.."type"..mouseButton);
	local y = (keyPress..infoType..mouseButton);

	for buttonNum = 1,W_kMaxUnitButtons do
		local b = f.buttonArray[buttonNum];
	
		b:SetAttribute( x, infoType); --this will set the keypress and type like   ctrl-type2,  spell
		b:SetAttribute( y, actionWhenPressed); --this will set the spell like   ctrl-spell2, fireball
	
		-- myPetButton:SetAttribute( x, infoType);
		-- myPetButton:SetAttribute( y, actionWhenPressed);
	end
end

--
-- Set up and Handle the Health Level drop down
--
function WC.Health_DropDownMenu_Initialize(frame, level, menuList) --populate the dropdownlist
	local t = {"Off","10","20","30","40","50","60","70","80","90"}; --table for the percentage health
	local func = function(self) WC.Health_DropDownMenu_OnClick(self) end; --the function to be called when a dropdown item is selected

	WC.DropDownMenu_Initialize( WC_Health_DropDown, t, func);
end
function WC.Health_DropDownMenu_OnClick( dd )
	--UIDropDownMenu_SetSelectedValue(this.owner, this.value)
	UIDropDownMenu_SetSelectedValue(dd.owner, dd.value)
	W_Options.Health1 = dd.value
	
	if ( dd.value == "Off" ) then --if we select off in the first drop down, turn off the second one as well
		W_Options.Health2 = dd.value
		UIDropDownMenu_SetSelectedValue(WC_Health2_DropDown, dd.value); --set the frame text of health2 dd to be off as well
		UIDropDownMenu_DisableDropDown( WC_Health2_DropDown );
		WC_Health2_Text:SetFontObject( "GameFontDisableSmall");
	else
		UIDropDownMenu_EnableDropDown( WC_Health2_DropDown );
		WC_Health2_Text:SetFontObject( "GameFontNormalSmall");
	end
end

-- Health2 Drop Down
function WC.Health2_DropDownMenu_Initialize(frame, level, menuList)
	local t = {"Off","10","20","30","40","50","60","70","80","90"}; --table for the percentage health
	local func = function(self) WC.Health2_DropDownMenu_OnClick(self) end; --the function to be called when a dropdown item is selected

	WC.DropDownMenu_Initialize( WC_Health2_DropDown, t, func);
end
function WC.Health2_DropDownMenu_OnClick( dd )
	UIDropDownMenu_SetSelectedValue(dd.owner, dd.value)
	W_Options.Health2 = dd.value;
end

-- a generic ddmenu init function
function WC.DropDownMenu_Initialize( theDropDownMenu, menuList, theOnClickFunction )
	--W.ShowMessage("DropDownMenu Initializing "..theDropDownMenu:GetName() )
	local index, menuItem;

	for index, menuItem in pairs( menuList ) do --iterate over the key, values pairs from the table
		info = UIDropDownMenu_CreateInfo();
		info.text =  menuItem; --the text to show in the menu
		info.value = menuItem; --this can be anything, but we use to to set and keep track of which item is selected
		info.owner = theDropDownMenu;
		info.func = theOnClickFunction; --the function to call when the item is selected
		info.checked = nil;
		UIDropDownMenu_AddButton( info, 1 ); --1 is the menu level
	end
end



--
-- Handle Clicks In Checkboxes
--
function WC.Click_CheckButton_Summary( isChecked )
	local frame = WhammySummaryFrame
	if ( frame ) then
		if ( isChecked ) then
			frame:Show();
			W_Options.ShowSummary = true;
		else
			frame:Hide();
			W_Options.ShowSummary = false;
		end
	end
end

function WC.Click_CheckButton_RangeCheck( isChecked )
	local f = WhammyFrame;
	local onUpdate = function(WhammyFrame, elapsed)
		W.Event_FrameOnUpdate( WhammyFrame, elapsed )
		end
	
	if ( isChecked ) then --turn on range checking
		W_Options.RangeCheck = true;
		f:SetScript( "OnUpdate", onUpdate )
	else -- turn off range checking
		W_Options.RangeCheck = false;
		f:SetScript( "OnUpdate", nil)
		for buttonNum=1,W_kMaxUnitButtons do --set the range to off
			local b = f.buttonArray[buttonNum];
			b.rangeText:SetText("");
		end
	end
end

function WC.SetRangeCheckEnable( isEnabled ) --turn the range checking feature on or off depending on class
	local f = WhammyConfigFrame;
	local b = f.rangeCheckButton;
	local t = getglobal(b:GetName().."Text")
	
	if ( isEnabled ) then
		b:Enable();
		t:SetFontObject( "GameFontNormalSmall");
	else
		WC.Click_CheckButton_RangeCheck( false )
		b:Disable();
		t:SetFontObject( "GameFontDisableSmall");
	end
end


function WC.Click_CheckButton_ButtonSize( isChecked )
	if ( isChecked ) then
		W_Options.ButtonSize = W_kButtonSizeSmall;
	else
		W_Options.ButtonSize = W_kButtonSizeStandard;
	end
	
	W.FrameDrawUnitButtons( WhammyFrame )
end


function WC.Click_CheckButton_MuteAilmentSound( isChecked )
	if ( isChecked ) then
		W_Options.Mute = true;
	else
		W_Options.Mute = false;
	end
end

function WC.Click_CheckButton_ThreatNotify( isChecked )
	if ( isChecked ) then
		W_Options.ThreatNotify = true;
	else
		W_Options.ThreatNotify = false;
	end
end

function WC.Click_CheckButton_IsFrameMovable( isChecked )
	local f = WhammyFrame;

	if ( isChecked ) then
		W_Options.Movable = true;
	else
		W_Options.Movable = false;
	end
	
end



--
-- Default Button Stuff
--
function WC.DefaultButton_OnClick() --clicking asks user if they are sure they want to reset back to defaults
	--W.ShowMessage("Button click");
	if ( StaticPopupDialogs["WHAMMY_DIALOG"] == nil ) then -- if we have not created this popup before, add it to the global popup table
		StaticPopupDialogs["WHAMMY_DIALOG"] = {
			text = "Are you sure you want to set popups to their defaults?",
			button1 = "Yes",
			button2 = "No",
			OnAccept = function()
				WC.Reset_Whammy();
			end,
			timeout = 0,
			whileDead = 1,
			hideOnEscape = 1
		};
	end

	StaticPopup_Show("WHAMMY_DIALOG");
end

function WC.Reset_Whammy()
	W_Options = {};

	W.Init_Variables(); --set the vars to default values
	WC.Init_Controls(); --set the controls to match the defaul values
	for slotNum = 1,20 do --clear out the drop slots
		local dropSlot = getglobal("WC_DropSlot"..slotNum);
		WC.DropSlot_Clear( dropSlot );
	end
	--W.Set_Whammy_Frame_Size() --set the frame size
	WhammyFrame:Show(); --make sure the frame is visible
	
	if ( GetNumRaidMembers() == 0 ) then --not a raid
		W.Event_PartyMembersChanged(); --set the frame to the appropriate size for either player or party
	else -- its a raid, set up the frame
		W.Event_RaidRosterUpdate();
	end
end


--
-- Called when we move the slider in the config window to move the miniMap icon around
-- 
function WC.MiniMapIconPosSlider_ValueChanged( theSlider )
	W_Options.Angle = theSlider:GetValue();
	WB.IconMove();
end


--
-- toggle the config frame shown and hidden
--
function WC.Config_Frame_Toggle()
	local f = WhammyConfigFrame;

	if ( f ) then
		if ( f:IsVisible() ) then --hide the frame if it's visible
			f:Hide();
		else --show the frame if it's hidden
			f:Show();
		end
	end
end