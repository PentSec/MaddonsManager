W_kMaxUnitButtons = "40"; --the total number of unit (player) buttons. Stored in array as a string, so keep it a string.

W_kButtonWidth = 90;
W_kButtonHeight = 16;
W_kFrameGutterTop = 10; --the top gutter of the whammy frame about the buttons. Used for dragging
W_kFrameGutterRight = 10;
W_kGutter = 2;

W_kButtonWidthSmall = 45;

W_kButtonSizeStandard = 0;
W_kButtonSizeSmall = 1;
	
W_kCurseHeight = 6;

W_kUpdateInterval = 1.0; --used for range checking

W_kFontNamePlayer = "GameFontGreenSmall";
W_kFontNameOthers = "GameFontNormalSmall";
W_kFontNameHighlight = "GameFontHighlightSmall";
W_kFontNameDisable = "GameFontDisableSmall";