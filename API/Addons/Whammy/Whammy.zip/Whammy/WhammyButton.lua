function WB.Frame_OnLoad( theFrame )
	theFrame:RegisterForClicks("LeftButtonUp", "RightButtonUp");
	--W.ShowMessage("WB.Frame_OnLoad")
end

function WB.Icon_OnClick( theMiniMapIconFrame, whichButtonWasClicked)
	if ( InCombatLockdown() ) then --if we we are incombat, don't allow hiding/showing of frames or other changes.
		UIErrorsFrame:AddMessage(WC_InCombatError, 1.0, 0.0, 0.0, 53, 5);
	else
		if ( whichButtonWasClicked == "LeftButton" and not IsShiftKeyDown() ) then --just a left click, show/hide the whammy frame
			W.Slash_Command_Handler(); --clcking the button is the same as typing /whammy, so use the same handler
		elseif ( whichButtonWasClicked == "LeftButton" and IsShiftKeyDown() ) then --a shift left click show the config frame
			WC.Config_Frame_Toggle();
		elseif ( whichButtonWasClicked == "RightButton" and IsShiftKeyDown() ) then --shift right click, show the info/help frame
			W.Info_Button_Click();
		end
	end
end

function WB.Icon_OnEnter( theMinimapButton )
	GameTooltip:SetOwner(theMinimapButton, "ANCHOR_LEFT");
	GameTooltip:SetText("      Whammy: v"..WhammyVers.."|n"..W_kMiniMapButton_Text);
	GameTooltip:Show();
end

function WB.IconMove()
	--W.ShowMessage("Icon Move");
	local x = (82 * cos(W_Options.Angle))
	local y = (82 * sin(W_Options.Angle))
	W_MiniMap_ButtonFrame:SetPoint("CENTER","Minimap","CENTER", x,y);
end


function WB.IconBeingDragged()
	--figure out what the angle is from the center of the map
	
	local xpos,ypos = GetCursorPosition() 
    local xmin,ymin = Minimap:GetLeft(), Minimap:GetBottom() 

    xpos = xmin-xpos/UIParent:GetScale()+82 
    ypos = ypos/UIParent:GetScale()-ymin-82
	
	local radians = -math.atan2(ypos,xpos); --get the angle (in degrees) of the x,y coords (rise, run format)
	local degrees = math.deg( radians ) - 180; --convert to degrees
	local degrees = math.floor(degrees)
	if ( degrees < 0 ) then
		degrees = 360 - math.abs(degrees)
	end
	
	W_Options.Angle = degrees
	local f = WhammyConfigFrame
	f.miniMapSlider:SetValue(W_Options.Angle);
	WB.IconMove();
end