W_kSummaryHealthBarWidth = 100;
W_kSummaryHealthBarHeight = 3;
W_kSummaryManaBarWidth = 100;
W_kSummaryManaBarHeight = 3;

--function W_Summary_Button_Click()
--	W.ShowMessage("summary button clicked");
--end


function WS.Frame_OnLoad(self)
	--W.ShowMessage("WS.Frame_OnLoad")
	WhammySummaryFrame_HealthBar:SetWidth( W_kSummaryHealthBarWidth );
	WhammySummaryFrame_HealthBar:SetHeight( W_kSummaryHealthBarHeight );
	
	WhammySummaryFrame_ManaBar:SetWidth( W_kSummaryManaBarWidth );
	WhammySummaryFrame_ManaBar:SetHeight( W_kSummaryManaBarHeight );
end

function WS.Frame_MouseDown(self)
	--W.ShowMessage("Summary_Frame_MouseDown");
	
	if arg1 == "LeftButton" then -- drag the frame
		self:StartMoving();
	end
end

-- called when there is a health changed event to update the party/raid total health bar
function WS.Update_Total_Health()
	local bar = WhammySummaryFrame_HealthBar
	local numRaidMembers = GetNumRaidMembers();
	local numPartyMembers = GetNumPartyMembers();
	local currentUnitHealth, maxUnitHealth, healthFraction = 0,0,0; --need to init these to 0
	
	if ( (W.IsRaid() == false and W.IsParty()) == false ) then -- player is alone
		currentUnitHealth = UnitHealth( "player" ); --get the current player unit health
		maxUnitHealth = UnitHealthMax( "player" ); --get the units max health
	else --player is either in a party or a raid
		if ( W.IsRaid() == false ) then --not in a raid, just in a party, we need to get the player health, then add in the rest of the party
			currentUnitHealth = UnitHealth( "player" ); --get the current player unit health
			maxUnitHealth = UnitHealthMax( "player" ); --get the units max health
				
			for id = 1,numPartyMembers do --walk through the other party members and gather their max and current health
				currentUnitHealth = currentUnitHealth + UnitHealth( "party"..id ); --get the current unit health
				maxUnitHealth = maxUnitHealth + UnitHealthMax( "party"..id ); --get the units max health
			end
		else --in a raid
			for id = 1,numRaidMembers do
				currentUnitHealth = currentUnitHealth + UnitHealth( "raid"..id ); --get the current unit health
				maxUnitHealth = maxUnitHealth + UnitHealthMax( "raid"..id ); --get the units max health
			end
		end
	end
	
	healthFraction = currentUnitHealth / maxUnitHealth; -- what % health are all the units at added together
	healthBarAmount = W_kSummaryHealthBarWidth * healthFraction;
	bar:SetWidth( healthBarAmount ); -- set the raid health bar to the raid health amount
end

function WS.Event_UnitMana()
	local bar = WhammySummaryFrame_ManaBar
	local numRaidMembers = GetNumRaidMembers();
	local numPartyMembers = GetNumPartyMembers();
	local currentUnitMana, maxUnitMana, manaFraction = 0,0,0;
	local unitCount = 0; --need to set this to 0 so it is not nil
	local kMana = 0; -- power type, mana=0, rage=1, focus=2(hunterpets), energy=3, happiness=4
	
	if ( (W.IsRaid() == false and W.IsParty() == false) ) then -- player is alone
		if ( UnitPowerType("player") == kMana ) then --if this player uses mana then we will be counting it toward the total
			currentUnitMana = UnitMana( "player" ); --get the current player unit mana
			maxUnitMana = UnitManaMax( "player" ); --get the units max mana
			unitCount = 1;
		end
	else --player is either in a party or a raid
		if ( W.IsRaid() == false ) then --not in a raid, just in a party, we need to get the player mana, then add in the rest of the party
			if ( UnitPowerType( "player" ) == kMana ) then --we only care about units that use mana
				currentUnitMana = UnitMana( "player" ); --get the current player unit mana
				maxUnitMana = UnitManaMax( "player" ); --get the units max mana
				unitCount = 1;
			end
					
			for id = 1,numPartyMembers do --walk through and see if any of the other party members use mana
				entity = "party"..id
				if ( UnitPowerType( entity ) == kMana ) then --we only care about units that use mana
					currentUnitMana = currentUnitMana + UnitMana( entity ); --get the current unit mana
					maxUnitMana = maxUnitMana + UnitManaMax( entity ); --get the units max mana
					unitCount = unitCount + 1;
				end
			end
		else -- is a party
			for id = 1,numRaidMembers do
				entity =  "raid"..id
				if ( UnitPowerType( entity ) == kMana ) then --we only care about units that use mana
					currentUnitMana = currentUnitMana + UnitMana( entity ); --get the current unit mana
					maxUnitMana = maxUnitMana + UnitManaMax( entity ); --get the units max mana
					unitCount = unitCount + 1;
				end
			end
		end
	end
	
	if ( unitCount > 0 ) then -- if unit count = 0 then this player is alone and does not use mana, so the mana bar will just reset to full width
		manaFraction = currentUnitMana / maxUnitMana; -- what % mana of everyone that uses mana
		manaBarAmount = W_kSummaryManaBarWidth * manaFraction;
		bar:SetWidth( manaBarAmount ); -- set the raid mana bar to the raid mana amount
	else
		bar:SetWidth( W_kSummaryManaBarWidth ); -- set the raid mana bar to the raid mana amount
	end
end
