if ( GetLocale() == "enUS" ) then
	W_kButton_Text = "Whammy"
	W_kIcon_Pos_Text = "Icon Position"
	W_kEnabled_Text = "Enable"
	W_kInfoFrameHelpText = "Whammy enables you to quickly heal, decurse, and perform other functions to yourself, party or raid members through a simple point and click interface. There is also a group summary window that shows overall group health/mana|n|n/whammy              - shows/hides the Whammy window|n|nTo drag Whammy - Click and Drag top grey bar|n|nResize Whammy   - Click and Drag lower right corner|n|nUse Health Alerts to set the percentage health to indicate when a unit needs healing. The Unit Button will turn Yellow for first warning indicator, Red when for the second.|n|nEach Unit Button is also a health level indicator, which is the width of the button.|n|nButtons also have an ailment area at the top (yellow when cursed) and will audibly notify you when a unit has a ailment (the sound can be disabled as well)|n       - Has a M, C, D, P for Magic, Curse, Disease or Poison|n|nYour characters text always appears in green to easily distinguish it from other players.|n|nThere is also basic threat indicator on each button, a small black square on the left side when the unit has threat, which can be toggled off|n|nWhammy Summary  - Show/Hide the via the Options menu|n                                       - Left click to drag|n|nTo set Whammy up, open the Options Frame and drag spells, macros etc from your spell book to the slots. When a Whammy button is clicked, that function will occur. Whammy cannot be used for offensive spells.";

	--Text that appears in the Whammy options window
	W_kOptionsFrameHeading = "Whammy Options";
	W_kOptionsFrameDefaultButtonText = "Defaults";
	
	--Text for the individual unit buttons
	W_kMagicText = "m";
	W_kCurseText = "c";
	W_kDiseaseText = "d";
	W_kPoisonText = "p";
	W_kOutOfRangeText = "Rng";
	
	W_kUnitButtonMenuTrade = "Trade";
	W_kUnitButtonMenuWhisper = "Whisper";
	W_kUnitButtonMenuInspect = "Inspect";
	W_kUnitButtonMenuFollow = "Follow";
	W_kUnitButtonMenuCancel = "Cancel";
	
	W_kUnitButtonTradeError = "They are too far away to trade with";
	W_kUnitButtonInspectError = "They are too far away to inspect";
	
	--stuff in the config frame button assignments and checkboxes
	WC_kDefaultText = "Click Defaults to reset Whammy to it's defaults.|nIt will also remove all spells and reset settings.";
	WC_kShowSummaryCheckButtonText = "Show Summary";
	WC_kButtonSizeCheckButtonText = "Use Small Buttons";
	WC_kMuteAilmentSoundText = "Mute Ailment Sound";
	WC_kRangeCheckText = "Range Checking";
	WC_kThreatNotifyText = "Threat Notification";
	WC_kIsFrameMovableText = "Movable Frame";
	WC_kConfigHealthAlertText = "Health Alert 1:";
	WC_kConfigHealthAlertText2 = "Health Alert 2:";
	WC_kLeftText = "Left:";
	WC_kMiddleText = "Middle:";
	WC_kRightText = "Right:";
	WC_kButton4Text = "Button 4";
	WC_kButton5Text = "Button 5";
	WC_kNoMod = "No Mod";
	WC_kShift = "Shift";
	WC_kCtrl = "Ctrl";
	WC_kAlt = "Alt";
	
	WC_kConfigWindowTitle = "Whammy Configuration";
	WC_kMouseClicksText = "Mouse Button Clicks";
	WC_kOtherOptionsText = "Other Options";
	WC_kIcon_Pos_Text = "Icon Position"
	
	WC_DropPassiveSpellError = "You cannot drop passive spells onto the Whammy slots";
	WC_DropError = "You cannot drop that onto the Whammy slots";
	WC_NoChangesInCombat = "Changes cannot be made while in combat";
	
	W_kMiniMapButton_Text = "Left Click:            Show/Hide Whammy|nRight Click:          Drag Mini Map Icon|nShift-Left Click:   Configuration|nShift-Right Click: About Whammy"
	
	WC_InCombatError = "You cannot make changes to Whammy while in combat."
end

if ( GetLocale() == "deDE" ) then

end

if ( GetLocale() == "frFR" ) then

end 