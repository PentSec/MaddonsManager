------------------------------------------------------------------------------------------
-- Whammy
-- Created By:  Jaycyn of Hyjal
--
-- What is it: Heal, Decurse and more with a point and click
-- License   : Distribute as you wish, please give credit to the author, please send
--           :   bugs and suggestions instead of modifying code yourself.
------------------------------------------------------------------------------------------

W = {}; --this is the namespace for the methods in the Whammy sections of the addon
WC = {}; --this is the namespace for the methods in the WhammyConfig sections of the addon
WP = {}; -- this is the namespace for the methods in the WhammyPet sections of the addon
WS = {}; -- this is the namespace for the methods in the WhammySummary sections of the addon
WB = {}; --namespace for the methods in WhammyButton

W_Options={
	["Mute"]=nil, --ailment muting
	["Temp3"]=nil,
	["Temp4"]=nil,
	["Temp5"]=nil,
	["ThreatNotify"]=nil,
	["Movable"]=nil,
	["ShowSummary"]=nil,
	["ShowWhammy"]=nil, --is whammy visible
	["ButtonSize"]=nil,
	["Temp2"]=nil,
	["RangeCheck"]=nil,
	["Health1"]=nil,
	["Health2"]=nil,
	["Angle"]=nil,
	["Actions"]={},
	["Actions2"]={}
}

local gInParty, gInRaid --in a raid or in a party
local gRaidList = {} --a list of raid1, raid2, raid3, used instead of concatenating raid..1  raid..2 etc for speed
local gPartyList = {} --
for i = 1,4 do
	gPartyList = format("party%d", i)
end
for i = 1,40 do
	gRaidList = format("raid%d", i)
end

function W.FrameOnLoad( theFrame )
	-- Register the game events neccesary for our functionality
	theFrame:RegisterEvent("ADDON_LOADED");
	theFrame:RegisterEvent("VARIABLES_LOADED");
	theFrame:RegisterEvent("RAID_ROSTER_UPDATE");
	theFrame:RegisterEvent("PARTY_MEMBERS_CHANGED");
	theFrame:RegisterEvent("UNIT_AURA");
	theFrame:RegisterEvent("UNIT_HEALTH");
	theFrame:RegisterEvent("UNIT_MANA");
	theFrame:RegisterEvent("PLAYER_LOGIN");
	theFrame:RegisterEvent("PLAYER_REGEN_DISABLED"); --use this to know if we enter or leave
	--theFrame:RegisterEvent("PLAYER_REGEN_ENABLED");
	theFrame:RegisterEvent("SPELLS_CHANGED"); --needed for range checking in case we don't have a spell we can check range with
	theFrame:RegisterEvent("PLAYER_ENTERING_WORLD");
	theFrame:RegisterEvent("PLAYER_ALIVE");
	-- note that the Talent change event is registered after the player login event
	
	--theFrame:RegisterEvent("RAID_TARGET_UPDATE");
	--theFrame:RegisterEvent("UNIT_THREAT_LIST_UPDATE"); --called when a targeted mobs threat list changes
	--theFrame:RegisterEvent("UNIT_THREAT_SITUATION_UPDATE"); --called when a unit (party/raid) moves past another unit
	
	-- set up the slash commands
	SlashCmdList["WHAMMY"] = W.Slash_Command_Handler;
	SLASH_WHAMMY1 = "/whammy";
	SLASH_WHAMMY2 = "/wham";

	WhammyVers = GetAddOnMetadata("Whammy", "Version");  --will be 0.0.7 xx/xx/xx

	theFrame.TimeSinceLastUpdate = 0; --used for range checking
	W.FrameInitWhammyFrame( theFrame ); --create the main frame
	W.FrameCreateUnitButtons( theFrame ); --create the buttons

	W.FrameCreateTestButtons( theFrame ); --the buttons for testing
	
	--W_Test_Button:Show();
	--W_Test_Button2:Show();
end
-- 
-- --------
-- --------  EVENT HANDLERS --------
-- --------

function W.Event_AddOnLoaded()
	--W.ShowMessage("W.Event_AddOnLoaded")

	--W.ShowMessage("W.Event_AddOnLoaded Complete")
end

function W.Event_VariablesLoaded()
	--W.ShowMessage("W.Event_VariablesLoaded")
	local f = WhammyFrame;
	
	W.Init_Variables(); --if any vars are nil, set to default valuess
	
	if ( W_Options.ShowWhammy ) then --if the last time the player played, Whammy was visible, keep it visible'
		if ( f ) then	
			f:Show();
		end
	end
	
	--f:SetMovable( W_Options.Movable ); --either lock the frame in place or make it movable
	
	WB.IconMove(); --move the Whammy Minimap icon into position
	WC.Init_Controls(); --now load the values into the config window.
end

-- This function is called from the main Whammy frame every W_UpdateInterval to check for range on the buttons. On Update is set in WhammyConfig
function W.Event_FrameOnUpdate(theFrame, elapsed)
	theFrame.TimeSinceLastUpdate = theFrame.TimeSinceLastUpdate + elapsed;
	
	if ( theFrame.TimeSinceLastUpdate > W_kUpdateInterval ) then
		W.UnitButtonRangeCheck( theFrame );
		theFrame.TimeSinceLastUpdate = 0;
	end
	
	-- this is tighter code execution and may be used in future updates if necessary
	-- while (self.TimeSinceLastUpdate > W_kUpdateInterval) do
	-- 	W.ShowMessage("Whammy Update message"..elapsed)
	--     self.TimeSinceLastUpdate = self.TimeSinceLastUpdate - W_kUpdateInterval;
	-- end
end

function W.Event_PartyMembersChanged()
	--W.ShowMessage("Event_PartyMembersChanged")
	local f = WhammyFrame;

	f.unitIDArray = {} --reset this as it's about to be re-loaded
	
	W.UnitButtonSetName(1, "player"); --set button1 to player
	--local numPartyMembers = GetNumberPartyMembers()
	
	for i = 1,4 do --player is in pos #1, 1-4 are the other 4 members
		local unitID = "party"..i;
		local buttonNum = i+1; --button 1 is player, button2 is party1, button3 is party2 etc
		if ( UnitExists(unitID) ) then
			W.UnitButtonSetName( buttonNum, unitID ); --party1 goes to button2, party2 goes to button3 etc. Also sets up the health amount for the unit
		else
			W.UnitButtonReset(buttonNum);
		end
	end
end

function W.Event_PlayerLogin()
	--W.ShowMessage("Event_PlayerLogin")
	local f = WhammyFrame;

	W.FrameDrawUnitButtons( f ); --draw the buttons in their proper positions
	WC.DropSlot_Init(); --set up the drop slots, which will in turn setup the unit buttons. Needs to be called here since we poll the spellbook for spell info.
	
	W.UnitButtonSetupRangeChecking();

	W.Event_PartyMembersChanged(); --set up the whammy.unitIDarray to have at least player in it
	
	--at this point, talent information is available so register that event
	f:RegisterEvent("PLAYER_TALENT_UPDATE");
end

function W.Event_PlayerTargetChanged( someArg )
	--W.ShowMessage("Event_PlayerTargetChanged")
	W.UnitButtonClearThreat();
end

function W.Event_RaidRosterUpdate()
	--W.ShowMessage("Event_RaidRosterUpdate")
	local f = WhammyFrame;
	
	f.unitIDArray = {} --reset this as it's about to be re-loaded
	W.UnitButtonResetAll(); --clear all the unit buttons as the raid setup changed and we are re-loading them
	
	local unitCount, buttonNum, id, unitID;
	local name, rank, subgroup, level, class, fileName, zone, online, isDead;
	local subGroupUnitCount = {0,0,0,0,0,0,0,0}; --keep track of how many raid members are in each raid group. Starts at 0 (5 per group)
	
	local numRaidMembers = GetNumRaidMembers();
	
	for id = 1,MAX_RAID_MEMBERS do --this will run from 1 to 40
		if ( id <= numRaidMembers ) then --this will only examine raid members 1...n, where n=number of actual raid members
			unitID = "raid"..id
			name, rank, subgroup, level, class, fileName, zone, online, isDead = GetRaidRosterInfo(id);	--get their name and subgroup
			subGroupUnitCount[ subgroup ] = subGroupUnitCount[ subgroup ] + 1; --keep track of how many units are in each subgroup
			unitCount = subGroupUnitCount[ subgroup ]; --get the next unit position based on the unit count of the subgroup
			buttonNum = ( ( (subgroup-1) * 5) + unitCount ) -- first subgroup, first position will be 1, 8th subgroup, first position will be 36
			W.UnitButtonSetName( buttonNum, unitID ); --sets the name and background color
		end
	end
	
end

function W.Event_PlayerTalentUpdate()
	--W.ShowMessage("player talent update occured");
	WC.DropSlot_Init(); --set up the new talents
end

function W.Event_UnitAura( unitID )
	--W.ShowMessage("Event_UnitAura")
	local f = WhammyFrame;
	local isRemovable = 1;
	local name, rank, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable, shouldConsolidate, spellId;
	
	W.UnitButtonSetAura( unitID, nil ); --clear the aura for this unitID
	for debuffNum = 1,40 do
		--name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitAura(unitID, debuffNum, "HARMFUL")
		name, rank, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable, shouldConsolidate, spellId = UnitDebuff(unitID, debuffNum, isRemovable)
		if ( debuffType ) then -- Magic Disease Poison Curse
			W.UnitButtonSetAura( unitID, debuffType );
			if ( W_Options.Mute == false ) then -- if we are not muted, play a sound
				if ( not W.bPlayedSound ) then
					W.bPlayedSound = true;
					PlaySoundFile("interface\\addons\\Whammy\\AilmentSound.mp3");
				end
			end
		else
			W.bPlayedSound = false;
		end
	end
	
	
	-- --W.ShowMessage("Event_UnitAura")
	-- local f = WhammyFrame;
	-- local isRemovable = 1;
	-- local name, rank, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable, shouldConsolidate, spellId;
	-- 
	-- W.UnitButtonSetAura( unitID, nil ); --clear the aura for this unitID
	-- for debuffNum = 1,40 do
	-- 	--name, rank, icon, count, debuffType, duration, expirationTime, isMine, isStealable = UnitAura(unitID, debuffNum, "HARMFUL")
	-- 	name, rank, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable, shouldConsolidate, spellId = UnitDebuff(unitID, debuffNum, isRemovable)
	-- 	if ( debuffType ) then -- Magic Disease Poison Curse
	-- 		W.UnitButtonSetAura( unitID, debuffType );
	-- 		if ( W_Options.Mute == false ) then -- if we are not muted, play a sound
	-- 				PlaySoundFile("interface\\addons\\Whammy\\AilmentSound.mp3");
	-- 		end
	-- 	end
	-- end

end

function W.Event_UnitHealth( unitID )
	--W.ShowMessage("Event_UnitHealth "..unitID)
	local healthFraction;
	local maxHealth = UnitHealthMax( unitID )
	local currentHealth = UnitHealth( unitID )
	
	if ( UnitIsConnected( unitID ) ) then
	
		if ( UnitIsDeadOrGhost( unitID ) or currentHealth < 1 ) then --unit dead
			healthFraction = 0;
		else
			healthFraction = currentHealth / maxHealth; --the % of how much health they have
			
			if (healthFraction < 0) then healthFraction = 0; end;
			if (healthFraction > 1) then healthFraction = 1; end;
		
			local healthAmount = healthFraction * 100;
			if ( W_Options.Health2 ~= "Off" and healthAmount < tonumber(W_Options.Health2) ) then
				W.UnitButtonHealthAlertSet( unitID, 2, true)
			elseif ( W_Options.Health1 ~= "Off" and healthAmount < tonumber(W_Options.Health1) ) then
				W.UnitButtonHealthAlertSet( unitID, 1, true)
			else
				W.UnitButtonHealthAlertSet( unitID, nil, nil)
			end
		end
	
		W.UnitButtonSetHealth( unitID, healthFraction ); --will adjust the texture of the button to indicate the amount of health
	else
		W.UnitButtonSetDisconnected( unitID )
	end
end

function W.Event_UnitThreatListUpdate( mobID ) --the Mob is the mob whose threat list changed or we just went into combat
	--W.ShowMessage("Event_UnitThreatListUpdate "..mobID)
	--one way to check the mobID is to see who it's target it
	-- if ( UnitExists(mobID) ) then
	-- 
	-- 	if ( not UnitIsPlayer(mobID) and UnitCanAttack( "player", mobID) and UnitHealth( mobID) > 0 and not UnitPlayerControlled(mobID) ) then
	-- 		local mobTarget = mobID.."target"; --this is who has aggro on the mob
	-- 		local mobTargetGUID = UnitGUID(mobTarget); --the get tanks GUID
	-- 		if ( mobTargetGUID ) then
	-- 			--guidNameLookup[mobTargetGUID] = UnitName(mobTarget); --store it
	-- 			local tankName = UnitName( mobTarget );
	-- 			W.ShowMessage("Threat List Update *** "..tankName.." *** HAS AGGRO");
	-- 		end
	-- 	
	-- 	end
	-- end

	--another way is to to check the raid to see who is firmly tanking the mob
	-- local aList;
	-- 
	-- if ( inParty or inRaid ) then
	-- 	if ( inRaid ) then
	-- 		aList = gRaidList; --array of raid1, raid2 etc
	-- 		currentPartySize = GetNumRaidMembers();
	-- 	else
	-- 		aList = gPartyList; --array of party1, party2 etc
	-- 		currentPartySize = GetNumPartyMembers();
	-- 	end
	-- 	
	-- 	for i = 1, currentPartySize do
	-- 		local unitID = aList[i];
	-- 		status = UnitThreatSituation( unitID, mobID)
	-- 		if ( status == 3 ) then --this unit has 100% threat
	-- 			local unitName = UnitName( unitID )
	-- 			W.ShowMessage("*** "..unitName.." *** HAS AGGRO")
	-- 		end
	-- 	end
	-- 
	-- end
end

function W.Event_UnitThreatSituationUpdate( unitID ) --the unit is the unit in the party or raid who changed threat position
	--unitID could be player, party1, raid1 etc... need to get the name
	local mobID = "playertarget"; --who is my target
	if ( unitID ) then
		if ( not UnitIsPlayer(mobID) and UnitCanAttack( "player", mobID) and UnitHealth( mobID) > 0 and not UnitPlayerControlled(mobID) ) then
		
			local mobName = UnitName( mobID );
			local uName = UnitName( unitID );
			if mobName and uName then --if we have a valid mob targeted and a valid unitID was passed in then check threat
				local status = UnitThreatSituation( unitID, mobID ); --if status = 3, the unitID has aggro
				--W.ShowMessage("Event_UnitThreatSituationUpdate *** "..unitID.." *** has aggro on "..mobName);
				local msg = "*** "..uName.." *** has aggro on "..mobName
				UIErrorsFrame:AddMessage( msg, 1.0, 0.0, 0.0, 53, 5);
				local b = W.GetButtonFromUnitID( unitID );
				if (b) then --if there is a button for this unit (i.e. they are in our raid or party)
					W.UnitButtonSetThreat( b ); --set the threat indicator active, and turn it off on others
				end
			end
		 end
		
	end	
	-- local playerGUID = UnitGUID( unitID ); --the global unit number of this unit
	-- if playerGUID then
	-- 	W_gGUIDNameTable[playerGUID] = UnitName( unitID ); --store the unitname in a global dictionary according to their GUID
	-- 	_, w_gGUIDClassTable[playerGUID] = UnitClass( unitID );
	-- end
end

-- called when we enter or leave combat. Enable or disable the drop downs depending on combat status
function W.Event_InCombat( f, isInCombat ) --isInCombat = true when entering combat, and false when leaving
	--when in combat, lock down the DropBoxes so we don't try to change them
	for dropSlotNum = 1,20 do
		local ds = getglobal( "WC_DropSlot"..dropSlotNum );
		if ( isInCombat ) then
			ds.texture = ds:CreateTexture(ds:GetName().."_Texture", "ARTWORK")
			ds.texture:SetTexture(.5, .5, .5, .5)
			ds.texture:SetAllPoints(ds)
			ds:Disable()
		else
			if (ds.texture) then
				ds.texture:SetTexture(nil)
			end
			ds:Enable()
		end
	end
	
	if ( isInCombat ) then --when in combat disable the growbox so we don't taint the frame and get an error
		f.sizer:SetScript("OnMouseDown", nil)
		f.sizer:SetScript("OnMouseUp",   nil)
	else
		f.sizer:SetScript("OnMouseDown", function( self ) W.FrameGrowBoxOnMouseDown( self ); end)
		f.sizer:SetScript("OnMouseUp",   function( self ) W.FrameGrowBoxOnMouseUp( self ); end)
		W.UnitButtonClearThreat();
		W.FrameDrawUnitButtons( f );
	end
	
end
-- --
-- --------  END EVENT HANDLERS --------
-- --
-- 
-- called once the variables are loaded - if they are nil, set to defaults
function W.Init_Variables()
	--W.ShowMessage("W.Init_Variables")
	if ( W_Options == nil ) then W_Options = {}; end
	if ( W_Options.Mute == nil ) then W_Options.Mute = false; end
	if ( W_Options.Temp3 == nil ) then W_Options.Temp3 = false; end
	if ( W_Options.Temp4 == nil ) then W_Options.Temp4 = false; end
	if ( W_Options.Temp5 == nil ) then W_Options.Temp5 = false; end
	if ( W_Options.ThreatNotify == nil ) then W_Options.ThreatNotify = true; end
	if ( W_Options.Movable == nil ) then W_Options.Movable = true; end
	if ( W_Options.ShowSummary == nil ) then W_Options.ShowSummary = true; end
	if ( W_Options.ShowWhammy == nil ) then W_Options.ShowWhammy = true; end
	if ( W_Options.ButtonSize == nil ) then W_Options.ButtonSize = W_kButtonSizeStandard; end
	if ( W_Options.Temp2 == nil ) then W_Options.Temp2 = false; end
	if ( W_Options.RangeCheck == nil ) then W_Options.RangeCheck = true; end
	if ( W_Options.Health1 == nil ) then W_Options.Health1 = "Off"; end
	if ( W_Options.Health2 == nil ) then W_Options.Health2 = "Off"; end
	if ( W_Options.Angle == nil ) then W_Options.Angle = 0; end
	if ( W_Options.Actions == nil ) then W_Options.Actions = {}; end --each row is a table with (item,spell or macro), ID, and either itemLink or spell/pet
	if ( W_Options.Actions2 == nil ) then W_Options.Actions2 = {}; end --the actions for secondary spec
end

function W.UnitButtonHealthAlertSet( unitID, whichAlert, isSet)
	local b = W.GetButtonFromUnitID( unitID )
	local red, green, blue, alpha;
	if b then
		if ( isSet ) then
			if ( whichAlert == 1) then --yellow
				red=1; green=1; blue=0; alpha=1
			elseif ( whichAlert == 2 ) then --red
				red=1; green=0; blue=0; alpha=1
			end
			b.healthAlertLeftTexture:SetTexture( red, green, blue, alpha);
			b.healthAlertTopTexture:SetTexture( red, green, blue, alpha);
			b.healthAlertRightTexture:SetTexture( red, green, blue, alpha);
			b.healthAlertBottomTexture:SetTexture( red, green, blue, alpha);
		else
			b.healthAlertLeftTexture:SetTexture( nil );
			b.healthAlertTopTexture:SetTexture( nil );
			b.healthAlertRightTexture:SetTexture( nil );
			b.healthAlertBottomTexture:SetTexture( nil );
		end
	end
end

function W.Test_Button_Click()
	W.ShowMessage("Test Button #1 click")
	
end

function W.Test_Button2_Click()
	W.ShowMessage("Test Button #2 click")
	
end

function W.FrameInitWhammyFrame( f )
	--W.ShowMessage("W.FrameInitWhammyFrame")
	f:SetWidth(400)
	f:SetHeight(200)
	f:SetPoint("CENTER", 0, 0)
	f:SetResizable(true)
	f:SetMaxResize( UIParent:GetWidth(), UIParent:GetHeight() - 50)
	f:EnableMouse(true)
	f:SetMovable(true)
	--f:SetScript("OnMouseDown", function( self ) W.FrameOnMouseDown( self ); end)
	f:SetScript("OnMouseDown", function( self ) W.FrameOnMouseDown( self, arg1 ); end)
	f:SetScript("OnMouseUp", function( self ) W.FrameOnMouseUp( self ); end)

	f.texture = f:CreateTexture("myframe_texture", "BACKGROUND")
	f.texture:SetTexture(.1,.1,.1,.4)
	f.texture:SetAllPoints(f)

	f.sizer = CreateFrame("Frame", "WhammyFrame_Sizer", f)
	f.sizer:SetWidth(16)
	f.sizer:SetHeight(16)
	f.sizer:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0)
	f.sizer.texture = f.sizer:CreateTexture("myframe_sizer_texture", "ARTWORK")
	f.sizer.texture:SetAllPoints( f.sizer )
	f.sizer.texture:SetTexture("Interface\\AddOns\\Whammy\\Images\\FrameResizeIcon.tga")
	f.sizer:EnableMouse();
	f.sizer:SetScript("OnMouseDown", function( self ) W.FrameGrowBoxOnMouseDown( self ); end)
	f.sizer:SetScript("OnMouseUp",   function( self ) W.FrameGrowBoxOnMouseUp( self ); end)
	
	f.buttonArray = {}; --keeps track of all the buttons in the frame
	f.unitIDArray = {}; --cross reference from the unit name stored in each button to the button the unit is stored in
	f.spellToCheckRangeWith = "" --used for range checking, set in Player_login event
	--W.ShowMessage("W.FrameInitWhammyFrame complete")
end

function W.FrameOnEvent( theFrame, event, ... )
	--W.ShowMessage("FrameOnEvent "..event)
	if ( event == "ADDON_LOADED" and arg1 == "Whammy") then -- the event occurs after the saved vars are loaded
		W.ShowMessage("Version "..WhammyVers.."   /Whammy to show/hide Whammy"); --" V0.21a 1/6/2007 Loaded");
		theFrame:UnregisterEvent("ADDON_LOADED");
		W.Event_AddOnLoaded(); --set up button frames, etc
	elseif ( event == "VARIABLES_LOADED" ) then --this event occurs after we load in any saved variables.
		W.Event_VariablesLoaded();
	elseif ( event =="PLAYER_LOGIN") then
		W.Event_PlayerLogin()
		if ( W.IsRaid() ) then
			W.Event_RaidRosterUpdate()
		end
	elseif ( event == "PLAYER_REGEN_DISABLED" ) then --we have entered combat
		theFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
		theFrame:RegisterEvent("UNIT_THREAT_LIST_UPDATE")
		theFrame:RegisterEvent("UNIT_THREAT_SITUATION_UPDATE")
		theFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
		W.Event_InCombat( theFrame, true )
		
	elseif ( event == "PLAYER_REGEN_ENABLED" ) then --we have left combat, so do whatever updates we couldn't do during combat
		--W.ShowMessage("Event: Regen enabled")
		theFrame:UnregisterEvent("PLAYER_REGEN_ENABLED") --already got the event so forget about it
		theFrame:UnregisterEvent("UNIT_THREAT_LIST_UPDATE")
		theFrame:UnregisterEvent("UNIT_THREAT_SITUATION_UPDATE")
		theFrame:UnregisterEvent("PLAYER_TARGET_CHANGED")
		
		W.Event_InCombat( theFrame, false )
		if ( W.IsRaid() ) then
			W.Event_RaidRosterUpdate();
		else
			W.Event_PartyMembersChanged();
		end
		
	elseif ( event == "UNIT_THREAT_LIST_UPDATE") then
		W.Event_UnitThreatListUpdate( arg1 ); --pass the mob whose threat list changed
		
	elseif ( event == "UNIT_THREAT_SITUATION_UPDATE" and W_Options.ThreatNotify ) then
		W.Event_UnitThreatSituationUpdate( arg1 ); --pass the unit whose threat has moved on the mobs list

	elseif ( event == "PLAYER_TARGET_CHANGED" ) then
		W.Event_PlayerTargetChanged( arg1 ); --arg1 doesn't matter
		
	elseif ( event == "PARTY_MEMBERS_CHANGED" ) then
		--W.ShowMessage("Party members changed event")
		if ( GetNumRaidMembers() == 0 ) then --we only care about this event if we are in a a party and not in a raid
			if ( InCombatLockdown() ) then --if we are in combat, wait to update the buttons until we leave combat
				theFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
			else --we are not in combat, so update the buttons
				W.Event_PartyMembersChanged();
			end
		end
		
	elseif ( event == "RAID_ROSTER_UPDATE" ) then
		if ( InCombatLockdown() ) then --if we are in combat, wait to update the buttons until we leave combat
			theFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
		else --we are not in combat, so update the buttons
			W.Event_RaidRosterUpdate();
		end
		
	elseif ( event == "UNIT_AURA" ) then --handle curses or raid or party members, ignore pets
		local unitID = arg1;
		if ( W.IsRaid() ) then --this captures events for when we are in a raid, so player and party events will be ignored
			if ( W.IsRaidMember( unitID ) ) then --if we are in a raid and the unit is raid1-40
				W.Event_UnitAura( unitID ); -- and ignore events for player and party1-4 since they are duplicate events
			end
		else
			if ( W.IsPartyMember( unitID ) ) then --make sure its player or party1-4 as this event can fire before raidrosterupdate when logging in
				W.Event_UnitAura( unitID );  --only accept player or party. Need to do this for login as UnitAuro fires before Raid roster update
			end
		end

	elseif ( event == "UNIT_HEALTH" ) then
		if ( W.IsRaid() ) then
			if ( W.IsRaidMember(arg1) ) then --if we are in a raid and the unit is raid1-40
				W.Event_UnitHealth( arg1 ); -- and ignore events for player and party1-4 since they are duplicate events
			end
		else
			if ( W.IsPartyMember( arg1 ) ) then --make sure its player or party1-4 as this event can fire before raidrosterupdate when logging in
				W.Event_UnitHealth( arg1 );  --only accept player or party. Need to do this for login as UnitAuro fires before Raid roster update
			end
		end

	elseif ( event == "UNIT_MANA" and W.IsUnitIDPlayerPartyRaid( arg1 ) ) then
		WS.Event_UnitMana(); --arg1 is player, party1-4 or raid 1-40 mana for player, party or raid, this function is in WhammySummary.lua

	--elseif ( event == OnUpdate ) blah blah  - this handles range checking. set via checkboxes in WhammyConfig
	
	elseif ( event == "SPELLS_CHANGED") then --if we are learning new spells, check to see if we can now range check
		W.UnitButtonSetupRangeChecking();
		
	elseif ( event == "PLAYER_TALENT_UPDATE" ) then
		W.Event_PlayerTalentUpdate();
	end
end

	--elseif ( event == "UNIT_HEALTH" and arg1 ~= "target" and arg1 ~= "mouseover" and arg1 ~="focus"  and arg1 ~= "npc" and arg1 ~= "NPC" ) then

function W.FrameCreateUnitButtons( theFrame )
	--W.ShowMessage("W.FrameCreateUnitButtons")
	local strata = "ARTWORK"
	
	for i = 1,W_kMaxUnitButtons do
		local bName = "W_Button"..i;
		local b = CreateFrame("Button", bName, theFrame, "WhammyUnitButtonTemplate");		--the button frame
		tinsert(theFrame.buttonArray, b)
		b:RegisterForClicks("LeftButtonUp", "RightButtonUp", "MiddleButtonUp", "Button4Up", "Button5Up"); -- the buttons need to see the mouse clicks
		b:SetWidth(W_kButtonWidth);
		b:SetHeight(W_kButtonHeight);
		-- the texture which adjusts depending on health
		b.texture = b:CreateTexture(bName.."_Texture", "BACKGROUND");
		b.texture:SetAllPoints(b);
		b.texture:SetTexture( 1, 1, 1, .4 );
		b:Disable();
		
		-- the unit name
		b.unitName = b:CreateFontString( bName.."_UnitName", strata, W_kFontNameOthers )
		b.unitName:SetPoint("CENTER", b, "CENTER", 0, 0);

		--the alert indicator for low health warnings 1 and 2
		b.healthAlertLeftTexture = b:CreateTexture( bName.."HealthAlert_Left_Texture", strata);
		b.healthAlertLeftTexture:SetPoint( "TOPLEFT", b, "TOPLEFT", 0, 0 );
		b.healthAlertLeftTexture:SetPoint( "BOTTOMRIGHT", b, "BOTTOMLEFT", 2, 0);
		b.healthAlertTopTexture = b:CreateTexture( bName.."HealthAlert_Top_Texture", strata);
		b.healthAlertTopTexture:SetPoint( "TOPLEFT", b, "TOPLEFT", 0, 0 );
		b.healthAlertTopTexture:SetPoint( "BOTTOMRIGHT", b, "TOPRIGHT", 0, -2);
		b.healthAlertRightTexture = b:CreateTexture( bName.."HealthAlert_Right_Texture", strata);
		b.healthAlertRightTexture:SetPoint( "TOPRIGHT", b, "TOPRIGHT", 0, 0 );
		b.healthAlertRightTexture:SetPoint( "BOTTOMLEFT", b, "BOTTOMRIGHT", -2, 0);
		b.healthAlertBottomTexture = b:CreateTexture( bName.."HealthAlert_Bottom_Texture", strata);
		b.healthAlertBottomTexture:SetPoint( "BOTTOMLEFT", b, "BOTTOMLEFT", 0, 0 );
		b.healthAlertBottomTexture:SetPoint( "TOPRIGHT", b, "BOTTOMRIGHT", 0, 2);
			
		--When the unit gets a curse (or other ailment) the top lights up in yellow. Create those areas
		b.curseTexture = b:CreateTexture(bName.."_CurseTop", strata)
		b.curseTexture:SetPoint( "TOPLEFT", b, "TOPLEFT", 0, 0 );
		b.curseTexture:SetPoint( "BOTTOMRIGHT", b, "TOPRIGHT", 0, -4);
		
		--When in a party or raid, and a unit gets aggro, display something on the button to indicate they have aggro
		b.threatTexture = b:CreateTexture( bName.."_Threat", strata)
		b.threatTexture:SetPoint( "TOPRIGHT", b, "RIGHT", 0, 2 );
		b.threatTexture:SetPoint( "BOTTOMLEFT", b, "RIGHT", -8, -2);
		
		--When the unit gets a curse( or other ailment ), there are letters on the curse bar that indicate what it is: M)agic C)urse D)isease P)oison
		local y = 4;
		b.magicText = b:CreateFontString( (bName.."_Curse_TextM"), "OVERLAY", "GameFontNormalSmall" )
		b.magicText:SetPoint( "TOPRIGHT", b, "TOPRIGHT", -27, y)
		b.magicText:SetTextColor( 1, 0, 0 );
		b.curseText = b:CreateFontString( (bName.."_Curse_TextC"), "OVERLAY", "GameFontNormalSmall" )
		b.curseText:SetPoint( "TOPRIGHT", b, "TOPRIGHT", -17, y)
		b.curseText:SetTextColor( 1, 0, 0 );
		b.diseaseText = b:CreateFontString( (bName.."_Curse_TextD"), "OVERLAY", "GameFontNormalSmall" )
		b.diseaseText:SetPoint( "TOPRIGHT", b, "TOPRIGHT", -9, y)
		b.diseaseText:SetTextColor( 1, 0, 0 );
		b.poisonText = b:CreateFontString( (bName.."_Curse_TextP"), "OVERLAY", "GameFontNormalSmall" )
		b.poisonText:SetPoint( "TOPRIGHT", b, "TOPRIGHT", 1, y)
		b.poisonText:SetTextColor( 1, 0, 0 );
		-- this is the little Rng that appears on each unit button when the unit is out of range
		b.rangeText = b:CreateFontString( bName.."_RangeText", "OVERLAY", "GameFontNormalSmall");
		b.rangeText:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 1, -2);
		b.rangeText:SetText("");
		b.rangeText:SetTextHeight(10);
		b.rangeText:SetTextColor(1, .5, 1)
	end
	--W.ShowMessage("W.FrameCreateUnitButtons complete")
end

function W.FrameGrowBoxOnMouseDown( theGrowBox )
	theGrowBox:GetParent():StartSizing("BOTTOMRIGHT")
end

function W.FrameGrowBoxOnMouseUp( theGrowBox )
	local f = theGrowBox:GetParent();
	f:StopMovingOrSizing()
	W.FrameDrawUnitButtons(f);
end

function W.FrameOnMouseDown( theFrame, theMouseButton )
	--W.ShowMessage("frame mouse down "..theMouseButton)
	if ( theMouseButton == "LeftButton" ) then --if we clicked the left button
		if ( W_Options.Movable ) then --and moving is enabled
			theFrame:StartMoving(); --then move the frame
		end
	elseif ( theMouseButton == "RightButton" ) then --if it was a right click, let the user lock/unlock the frame
		--present a popup list to lock or unlock the frame
		W.FrameMenuIsFrameMovable();
	end
end

function W.FrameMenuIsFrameMovable() --display a popup to allow the Whammy Frame to be set to Movable or not
	local menuFrame = CreateFrame("Frame", "ExampleMenuFrame", UIParent, "UIDropDownMenuTemplate")

	local function onOption1()
		W_Options.Movable = true;
		if (WhammyConfigFrame) then
			WhammyConfigFrame.isFrameMovableButton:SetChecked( W_Options.Movable );
		end
	end
	local function onOption2()
		W_Options.Movable = false;
		if (WhammyConfigFrame) then
			WhammyConfigFrame.isFrameMovableButton:SetChecked( W_Options.Movable );
		end
	end

	local menuList = {
	  { text = "Movable", func = onOption1 },
	  { text = "Locked", func = onOption2 }
	}

	EasyMenu(menuList, menuFrame, "cursor", 0 , 0, "MENU");
end

function W.FrameOnMouseUp( theFrame )
	theFrame:StopMovingOrSizing()
end

function W.FrameDrawUnitButtons( theFrame )
	--W.ShowMessage("W.FrameDrawUnitButtons")
	local bHeight = W_kButtonHeight + W_kGutter
	local bWidth, w;
	local frameWidth = theFrame:GetWidth();
	local frameHeight = theFrame:GetHeight();
	local rightLimit = frameWidth - W_kFrameGutterRight; --we start drawing at 0, not bWidth so we need to compensate for that
	local x = 0;
	local y = -10;
	local col = 0;

	if ( W_Options.ButtonSize == W_kButtonSizeStandard ) then
		w = W_kButtonWidth
		bWidth = w + W_kGutter;
	else
		w = W_kButtonWidthSmall
		bWidth = w + W_kGutter;
	end
	--sets the min size of the whammyframe depending on the size of the buttons.
	theFrame:SetMinResize( w + W_kGutter + W_kFrameGutterRight, W_kButtonHeight+3+W_kFrameGutterTop)

	--draw the buttons
	for buttonNum = 1,W_kMaxUnitButtons do
		local b = theFrame.buttonArray[buttonNum];
		b:SetWidth( w );
		W.UnitButtonSetNameWidth( b );
		
		x = col * bWidth;
		
		if ( x > rightLimit or (x+bWidth) > rightLimit ) then --if this button would go past the right side of the frame, drop it down a line
			x = 0;
			col = 0;
			y = y - bHeight
		end
		
		if ( -y > frameHeight or (-y+bHeight) > frameHeight ) then
			b:Hide()
		else
			b:Show()
		end
		
		b:ClearAllPoints()
		b:SetPoint("TOPLEFT", theFrame, "TOPLEFT", x, y)
		col = col + 1;
	end
end

function W.FrameCreateTestButtons( theFrame )
	local testButton1 = CreateFrame("Button", "W_Test_Button", theFrame, "UIPanelButtonTemplate")
	testButton1:SetWidth(80);
	testButton1:SetHeight(22);
	testButton1:SetPoint("TOPLEFT", theFrame, "BOTTOMLEFT", 5, 5);
	testButton1:SetScript("OnClick", function() W.Test_Button_Click(); end);
	testButton1:SetText("Test1");
	testButton1:Hide()

	local testButton2 = CreateFrame("Button", "W_Test_Button2", theFrame, "UIPanelButtonTemplate")
	testButton2:SetWidth(80);
	testButton2:SetHeight(22);
	testButton2:SetPoint("RIGHT", theFrame, "LEFT", 5, 5)
	testButton2:SetScript("OnClick", function() W.Test_Button2_Click(); end);
	testButton2:SetText("Test2");
	testButton2:Hide()
end



function W.UnitButtonRangeCheck( f ) --f is whammyframe
	local inRange;
	--W.ShowMessage("W.UnitButtonRangeCheck")
	for buttonNum = 1,W_kMaxUnitButtons do
		local b = f.buttonArray[buttonNum];
		local unitID = b:GetAttribute("unit");
		if ( unitID ) then
			if UnitExists( unitID ) and UnitIsFriend( "player", unitID ) then
				local inRange = IsSpellInRange( f.spellToCheckRangeWith, unitID); --inRange will be 0=Out of Range, 1=In Range, nil=not valid
				local isVisible = UnitIsVisible( unitID );
				
				if ( inRange==1 and isVisible == 1 ) then
					b.rangeText:SetText("");
				else
					b.rangeText:SetText(W_kOutOfRangeText);
				end
			else
				b.rangeText:SetText("");
			end
		else --not a valid  unit, set clear rangetext
			b.rangeText:SetText("");
		end
	end
end

function W.TestBoolean( someB )
	if (someB == 1) then
		return "true"
	elseif (someB == 0) then
		return "false"
	else
		return "nil"
	end
end

function W.UnitButtonReset( i )
	local f = WhammyFrame
	local b = f.buttonArray[i];	

	--reset the buttons and cancel watching for clicks.
	b:SetScript("OnMouseDown", nil ); --thebutton and the mousebutton
	b:SetScript("OnMouseUp", nil);

	b.unitName:SetText(nil)

	b.texture:SetTexture( 1, 1, 1, .4 ); --sets the background to default
	b.texture:SetAllPoints( b ); --sets the texture to full size (health)

	b.magicText:SetText(nil); --clear out any aura's
	b.curseText:SetText(nil);
	b.diseaseText:SetText(nil);
	b.poisonText:SetText(nil);

	b.curseTexture:SetTexture( nil ); --clear the curse bar

	b.rangeText:SetText(nil); --clear out the range text

	b.unitName:SetFontObject(W_kFontNameOthers); --reset the font

	b.healthAlertLeftTexture:SetTexture( nil ); --reset the healh alert indicators
	b.healthAlertTopTexture:SetTexture( nil );
	b.healthAlertRightTexture:SetTexture( nil );
	b.healthAlertBottomTexture:SetTexture( nil );

	local unitID = b:GetAttribute("unit"); --get the unitID if there was one
	if (unitID) then --if the array that links unitID's to buttons had an entry for this, then remove it
		f.unitIDArray[unitID] = nil; --removes the unitID entry from the dictionary
	end
	b:SetAttribute("type", "stop"); --set the function of the button to nothing
	b:SetAttribute("unit", nil)

	b:Disable(); --disable the button

end

function W.UnitButtonResetAll()
	for i = 1,W_kMaxUnitButtons do
		W.UnitButtonReset(i)
	end
end

function W.UnitButtonSetAura( unitID, theAura) --when theAuro=nil, then clear the debuff spot
	local b = W.GetButtonFromUnitID( unitID )

	if (b) then --there could be a time when, you are in combat, and added someone to the party/raid that b could be nil
		if ( theAura ) then --there is a debuff, figure out what it is and display the text
			if (theAura == "Magic") then --if it was magic then set the magic text otherwise clear it
				b.magicText:SetText(W_kMagicText);
			elseif (theAura == "Curse") then
				b.curseText:SetText(W_kCurseText);
			elseif (theAura == "Disease") then
				b.diseaseText:SetText(W_kDiseaseText);
			elseif (theAura == "Poison") then
				b.poisonText:SetText(W_kPoisonText);
			end
			
			local result = b.curseTexture:SetTexture( .97, 1, .38, 1)--yellow bar across the top of the button
			--don't need to worry about result at this time
		else
			b.magicText:SetText(nil); --if there are no debuffs, clear them all
			b.curseText:SetText(nil);
			b.diseaseText:SetText(nil);
			b.poisonText:SetText(nil);
			
			b.curseTexture:SetTexture( nil )
		end	
	end
end

function W.UnitButtonSetHealth( unitID, healthAmountInDecimal )
	local buttonWidth;
	
	local b = W.GetButtonFromUnitID( unitID );--get the button to change based on the unitID whose health is changing
	if b then
		if ( healthAmountInDecimal > 0 ) then -- unit is alive so set up their health
			if ( W_Options.ButtonSize == W_kButtonSizeStandard ) then
				buttonWidth = W_kButtonWidth;
			else
				buttonWidth = W_kButtonWidthSmall;
			end
			W.UnitButtonSetClass( b, unitID)
			local delta = buttonWidth - (buttonWidth * healthAmountInDecimal); --if w=100 and health=100%, then this would be 100-(100*1) = 0
			b.texture:SetPoint("TOPLEFT", b ,"TOPLEFT", 0, 0);
			b.texture:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", -delta, 0);
		else --they are dead, dim the texture
			--buttonWidth = b:GetWidth();
			W.UnitButtonSetAura( unitID, nil ) --reset the aura's and curse bar
			local localizedClass, englishClass = UnitClass(unitID)
			local red, green, blue = W.GetClassColors( englishClass )
			b.texture:SetTexture( red, green, blue, .2) --when dead, dim the color
			b.texture:SetAllPoints(b);--make it fill the button
			--W.ShowMessage("dude")
		end
	end
end

function W.UnitButtonSetName(whichButtonNum, unitID)
	--W.ShowMessage("W.UnitButtonSetName:  buttonNum = "..whichButtonNum.."  unitID = "..unitID);
	local f = WhammyFrame;
	local b = f.buttonArray[whichButtonNum];
	
	--since it has a unit, accept clicks and handle them
	b:SetScript("OnMouseDown", function(self, arg1) W.UnitButtonMouseDown(self, arg1); end); --thebutton and the mousebutton
	b:SetScript("OnMouseUp", function(self) W.UnitButtonMouseUp(self); end);
	
	f.unitIDArray[unitID] = b; --associate a unitID table with the button so we can look up buttons via a unitID
	--W.ShowMessage("UnitButtonSetName unitID.."..unitID.." button ="..b:GetName() )
	b.unitName:SetText( UnitName( unitID ) );
	W.UnitButtonSetNameWidth( b );
	b:SetAttribute("unit", unitID); --set the assignment of the button to the passed in unit
	W.UnitButtonSetClass( b, unitID )
	W.Event_UnitHealth(unitID); --set the initial health for the unit
	
	if ( UnitIsUnit( unitID, "player") ) then --if they are online, color the player one way, and the rest of the units another
		b.unitName:SetFontObject(W_kFontNamePlayer)
	else --someone else in the party or raid
		b.unitName:SetFontObject(W_kFontNameOthers)
	end
	
	b:Enable();
end

-- --called when assigning a unit to a button. Determine what kind class of unit (warrior, mage etc) and color the backgroud to match
function W.UnitButtonSetClass(b, unitID)
	--W.ShowMessage("----- Setting Class ------")
	local localizedClass, englishClass = UnitClass(unitID)
	local red, green, blue = W.GetClassColors( englishClass );

	b.texture:SetTexture( red, green, blue, 1 )
end

function W.GetClassColors( englishClass )
	local r, g, b;
	
	if ( englishClass == "DEATHKNIGHT") then
		r = .77; g = .12; b = .23;
	elseif ( englishClass == "DRUID" ) then
		r = 1.0; g = .49; b = .04;
	elseif ( englishClass == "HUNTER" ) then
		r = .67; g = .83; b = .45;
	elseif ( englishClass == "MAGE" ) then
		r = .41; g = .80; b = .94;
	elseif ( englishClass == "PALADIN" ) then
		r = .96; g = .55; b = .73;	
	elseif ( englishClass == "PRIEST" ) then
		r = 1.0; g = 1.0; b = 1.0;
	elseif ( englishClass == "ROGUE" ) then
		r = 1.0; g = .96; b = .41;
	elseif ( englishClass == "SHAMAN" ) then
		r = .14; g = .35; b = 1.0;
	elseif ( englishClass == "WARLOCK" ) then
		r = .58; g = .51; b = .79;
	elseif ( englishClass == "WARRIOR" ) then
		r = .78; g = .61; b = .43;
	end

	return r, g, b;
end


--called when we assign a new unit to a unitbutton, to make their name fit in the width of the button, or when we change button size
function W.UnitButtonSetNameWidth( b )
	
	local buttonWidth = b:GetWidth(); --the width of the button
	local stringWidth = b.unitName:GetStringWidth(); --the width of the unit name

	if ( stringWidth > buttonWidth ) then --if the unit name is wider than the button, then truncate the unit name
		local newStringWidth = buttonWidth * .95 -- the new string width will be 95% of the button width
		b.unitName:SetWidth( newStringWidth );
	else --the unit name fit within the box so reset the string width value
		b.unitName:SetWidth( buttonWidth );
	end
end

function W.UnitButtonSetThreat( b )
	--W.ShowMessage("UnitButtonSetThreat "..b:GetName() )
	
	W.UnitButtonClearThreat();
	
	b.threatTexture:SetTexture( 0, 0, 0, 1)-- indicate this button has threat
	W_gOldThreatButton = b; --keep track of which one this is

end


--
-- Handle Unit Button Mouse
--
function W.UnitButtonMouseDown( b, mouseButton) --MouseDown and up highlight the unit name when clicked. arg1 is the LeftButton, etc. unused
	--W.ShowMessage("UnitButton_MouseDown "..b:GetName().."  "..mouseButton);

	if ( b:IsEnabled() ) then
		local unitName = b.unitName:GetText();
		b.unitName:SetFontObject(W_kFontNameHighlight)
		if ( W.UnitButtonCheckForAction( b, mouseButton ) ~= true ) then
			W.UnitButtonShowMenu( b );
		end
	end
end

function W.UnitButtonShowMenu( b ) --if the button has a unit assigned but nothing in the mouse button action then show a menu
	local menuFrame = CreateFrame("Frame", "W_UnitButtonDropDown", b, "UIDropDownMenuTemplate")
	local text, func, menuList;
	local unitID = b:GetAttribute("unit"); --which unitID is associated with this button
	local isInspectDisabled, isTradeDisabled, isChatDisabled;
	
	if ( not UnitIsUnit("player", unitID)  ) then --only open a drop down menu if we are clicking on a unit that is not  player
		if ( CheckInteractDistance( unitID, 1) ) then isInspectDisabled = 1; end;
		if ( CheckInteractDistance( unitID, 2) ) then isTradeDisabled = 2; end;
		if ( CheckInteractDistance( unitID, 4) ) then isFollowDisabled = 1; end;
		
		local menuList = {
			{
				text = W_kUnitButtonMenuTrade,
				func = function() W.UnitButtonHandleMenu("trade", unitID) end,
				disabled = isTradeDisabled,
			},
			{
				text = W_kUnitButtonMenuWhisper,
				func = function() W.UnitButtonHandleMenu("whisper", unitID) end,
				disabled = nil,
			},
			{
				text = W_kUnitButtonMenuInspect,
				func = function() W.UnitButtonHandleMenu("inspect", unitID) end,
				disabled = isInspectDisabled,
			},
			{
				text = W_kUnitButtonMenuFollow,
				func = function() W.UnitButtonHandleMenu("follow", unitID) end,
				disabled = isFollowDisabled,
			},
			{
				text = W_kUnitButtonMenuCancel,
				func = function() W.UnitButtonHandleMenu("cancel", unitID) end,
				disabled = nil,
			}
		}
	
		EasyMenu( menuList, menuFrame, b, 0, 0, "MENU", 1 )
		
	end
end

function W.UnitButtonHandleMenu( theMenuItem, unitID )
	--W.ShowMessage(theMenuItem)
	if ( theMenuItem == "trade" ) then		
		InitiateTrade( unitID ); --1 = Inspect, 28 yards  2 = Trade, 11.11 yards  3 = Duel, 9.9 yards  4 = Follow, 28 yards
	elseif ( theMenuItem == "whisper" ) then
		local unitName = UnitName( unitID )
		ChatFrame_SendTell( unitName );
	elseif ( theMenuItem == "inspect" ) then
		InspectUnit( unitID )
	elseif ( theMenuItem == "follow" ) then
		FollowUnit( unitID )
	elseif ( theMenuItem == "cancel" )	then
		CloseDropDownMenus();
	end
	
end

--check to see if there is an action corresponding to the mouse click, if not, then show a drop down menu
function W.UnitButtonCheckForAction( b, mouseButton )
	--W.ShowMessage("Checking for action for button "..b:GetName() )
	local keyPress, mouseButtonNum
	
	if ( IsLeftShiftKeyDown() or IsRightShiftKeyDown() ) then
		keyPress = "shift"
	elseif ( IsLeftControlKeyDown() or IsRightControlKeyDown() ) then
		keyPress = "ctrl"
	elseif ( IsLeftAltKeyDown() or IsRightAltKeyDown() ) then
		keyPress = "alt"
	else
		keyPress = ""
	end
	
	if ( keyPress == "ctrl" or keyPress == "shift" or keyPress == "alt") then --if there is a keypress modifier then we need to add 
		keyPress = ( keyPress.."-" ); --                                       the dash so the attribute will be properly formatted
	end
	
	if ( mouseButton == "LeftButton" ) then
		mouseButtonNum = 1
	elseif ( mouseButton == "MiddleButton" ) then
		mouseButtonNum = 3
	elseif ( mouseButton == "RightButton" ) then
		mouseButtonNum = 2
	else
		mouseButtonNum = mouseButton;  --4 and 5 will take care of themselves
	end
	
	local x = (keyPress.."type"..mouseButtonNum);
	local a = b:GetAttribute(x)

	if (a) then
		return true
	else
		return false
	end
end

function W.UnitButtonClearThreat() --called when player targets something new, need to reset the threat indicator
	--W.ShowMessage("UnitButtonClearThreat")
	if ( W_gOldThreatButton ) then --if someone had threat
		--W.ShowMessage("Clearing threat on "..W_gOldThreatButton:GetName() )
		W_gOldThreatButton.threatTexture:SetTexture( nil ); --clear their threat
		W_gOldThreatButton = nil;
	end
end

function W.UnitButtonSetDisconnected( unitID )
	if ( unitID ) then
		local b = W.GetButtonFromUnitID( unitID )
		b.texture:SetTexture( 0,0,0,.2)
	end

end

function W.UnitButtonMouseUp(b) -- unhighlight the name
	if ( b:IsEnabled() ) then
		local unitID = b:GetAttribute("unit"); --get the name of the unit assigned to this button
		if ( unitID ) then
			if ( UnitIsUnit( unitID, "player") ) then --if they are online, color the player one way, and the rest of the units another
				b.unitName:SetFontObject(W_kFontNamePlayer)
			else --someone else in the party or raid
				b.unitName:SetFontObject(W_kFontNameOthers)
			end
		end
	end
end

--called when player logs in to attempt to start range checking. Will also be called if a player learns new spells to activate the range check option
function W.UnitButtonSetupRangeChecking()
	local f = WhammyFrame;
	--set up range checking
	local rangeCheckSpellArray={
		["DEATHKNIGHT"] = "Hysteria",
		["DRUID"] = "Healing Touch",
		["HUNTER"] = "",
		["MAGE"] = "Remove Curse",
		["PALADIN"] ="Holy Light",
		["PRIEST"] = "Heal",
		["ROGUE"] = "",
		["SHAMAN"] = "Healing Wave",
		["WARLOCK"] = "",
		["WARRIOR"] = ""
	}
	local localizedClass, englishClass = UnitClass("player") --need this for range checking
	f.spellToCheckRangeWith = rangeCheckSpellArray[ englishClass ]
	local name, rank, icon, cost, isFunnel, powerType, castTime, minRange, maxRange = GetSpellInfo( f.spellToCheckRangeWith ); --check to see if spell exists
	if (f.spellToCheckRangeWith == "" or name == nil ) then --range checking not needed or not capable, disable option
		WC.SetRangeCheckEnable(false); --turn off range checking and disable the option the config window
	end
end
-- End Handle Unit Button Mouse


--
-- MISC functions from here down
--

function W.IsUnitIDPlayerPartyRaid( unitID ) --veryify the unitID is formated partyx or raid xx. Used to eliminate pets from health checking/curse checking
	if ( string.find(unitID, "party%d", 1) or string.find(unitID, "raid%d", 1) or string.find(unitID, "player") ) then
		return true
	else
		return false
	end
end

function W.IsRaid()
	local numRaidMembers = GetNumRaidMembers();
	
	if ( numRaidMembers == 0 ) then
		return false;
	else
		return true;
	end
end

function W.IsParty()
	local numPartyMembers = GetNumPartyMembers();
	
	if ( W.IsRaid() ==false and numPartyMembers > 0 ) then --if it is not a raid and there are other party members then its just a party
		return true;
	else -- not just a party, could be player or a raid
		return false;
	end
end

function W.IsRaidMember( unitID ) --check to see if unitID has the word   raid   in it, as in raid1 raid2 etc
	-- local isPet = strfind(unitID, "pet" )
	-- local isRaid = strfind( unitID, "raid" )
	
	local isRaid = string.find(unitID, "raid%d", 1)
	
	if ( isRaid ) then
		return true
	else
		return false
	end
end

function W.IsPartyMember( unitID ) --is this player or party1-4
	--local isPet = strfind(unitID, "pet" )
	local isParty = string.find(unitID, "party%d", 1)
	
	if ( isParty or unitID == "player" ) then
		return true
	else
		return false
	end
end


function W.GetButtonFromUnitID( unitID )
	local f = WhammyFrame;
	local b = f.unitIDArray[unitID];
	
	return b
end

-- Display a message in the chat frame
function W.ShowMessage(aMessage)
	local r,g,b,a
	r = 0;
	g = 1;
	b = 0;
	a = .5;
	
	if ( aMessage ~= nil ) then
		DEFAULT_CHAT_FRAME:AddMessage("Whammy: " ..aMessage, r, g, b, a);
	else
		DEFAULT_CHAT_FRAME:AddMessage("Whammy: nil message");
	end
end



-- handle our one and only slash command. msg is what the user typed i.e. /whammy msg
function W.Slash_Command_Handler(msg)
	--W.ShowMessage("slash handler");
	local frame = WhammyFrame;
	if ( frame ) then
		if ( msg ) then
			if ( msg == "reset" ) then --user wants to reset whammy - reset position, buttons etc.
				W.ShowMessage("Whammy Reset");
				WC.Reset_Whammy();
			elseif (msg=="show config" or msg=="config" ) then
				WC.Config_Frame_Toggle();
			end
		else
			if ( frame:IsVisible() ) then
				frame:Hide();
				W_Options.ShowWhammy = false;
				if ( WhammyConfigFrame:IsVisible() ) then
					WhammyConfigFrame:Hide();
				end
			else
				frame:Show();
				W_Options.ShowWhammy = true;
			end
		end
	end
end


function W.Info_Button_Click() -- show/hide the info frame when the user clicks the ? button
	local frame = WhammyInfoFrame;
	if ( frame ) then
		if ( frame:IsVisible() ) then
			frame:Hide();
		else
			frame:Show();
		end
	end
end

--
-- When the info window loads, set the text that should appear
--
function W.Info_OnLoad(self)
	--W.ShowMessage("W.Info_OnLoad");
	local infoText
	local helpFrameWidth = 440;
	
	WhammyInfoFrame:SetWidth( helpFrameWidth ); --adjust the size of the frame
	WhammyInfoFrame_Heading:SetText("Whammy "..WhammyVers);
	
	-- note that the height of the info frame will adjust around the height of the text. Did this for localization purposes in case another language takes
	--    more or less space to say the same thing
	local t = WhammyInfoFrame_Help_Text;
	
	t:SetPoint("TOPLEFT", "WhammyInfoFrame", 10, -35); --set the starting position of the help text
	t:SetWidth( helpFrameWidth - 15); --set the width of the text
	t:SetText( W_kInfoFrameHelpText ); --set the text from the static text
	local textHeight = t:GetHeight(); --get the height of the text so we can adjust the frame height around it
	WhammyInfoFrame:SetHeight( textHeight + 80 ) --set the frame height to the height of the text + space for the heading area
end




