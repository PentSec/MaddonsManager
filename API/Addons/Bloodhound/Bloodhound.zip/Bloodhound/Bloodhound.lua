
-------- SINGLE OBJECT IN GLOBAL NAMESPACE

Bloodhound = {};


-------- CREATE OUR INVISIBLE FRAME TO RECEIVE EVENTS AND UPDATES

local frame = CreateFrame("Frame", nil, UIParent);
Bloodhound.Frame = frame;


-------- DEFINE AND REGISTER EVENT HANDLERS

local events = {};

function events:MINIMAP_UPDATE_TRACKING(...)
    if player and player.Z then
	    Bloodhound.UpdateMinimap();
    end
end

frame:SetScript("OnEvent", 
	function(self, event, ...)
		events[event](self, ...);
	end);

local k, v;

for k, v in pairs(events) do
	frame:RegisterEvent(k);
end


-------- WORK AROUND WOW BUG THAT CAUSES GetPlayerMapPosition TO RETURN 0,0

WorldMapFrame:Show()
WorldMapFrame:Hide()


-------- HOOK INTO PER-FRAME UPDATE HANDLER

local player = {};		-- player position
local totalElapsed = 0.0;	-- time elapsed since last update
local updateFrequency = 0.1;	-- interval for each minimap update
local lastzoom = 0;		-- previous minimap zoom level

frame:SetScript("OnUpdate",
	function(self, elapsed)
		totalElapsed = totalElapsed + elapsed;				-- measure total elapsed time

		if (totalElapsed >= updateFrequency) then				-- if enough time has passed
			totalElapsed = mod(totalElapsed, updateFrequency);

			local cmap = GetCurrentMapContinent();
			local zmap = GetCurrentMapZone();
			SetMapToCurrentZone();
			local c = GetCurrentMapContinent();				-- get current player position
			local z = GetCurrentMapZone();
			local x, y = GetPlayerMapPosition("player");
			local m = Minimap:GetZoom();
			SetMapZoom(cmap, zmap);
            
            if (c ~= player.C) then						-- reload continent data if continent has changed
                Bloodhound.HerbNodes, Bloodhound.ContinentHerbs = Bloodhound.ReloadNodes(Bloodhound.HerbDatabase[c], Bloodhound.ZoneDatum[c]);
                Bloodhound.OreNodes, Bloodhound.ContinentOre = Bloodhound.ReloadNodes(Bloodhound.OreDatabase[c], Bloodhound.ZoneDatum[c]);
            end

            if (c ~= player.C or z ~= player.Z or x ~= player.X or y ~= player.Y or m ~= lastzoom) then
                player.C = c;
                player.Z = z;
                player.X = x;
                player.Y = y;
                lastzoom = m;
                Bloodhound.UpdateMinimap();	-- player has moved or minimap scale has changed
            end
		end
	end);

function Bloodhound.UpdateMinimap()
	local gx, gy = Bloodhound.CalculateForce();
	Bloodhound.DrawArrow(gx, gy);
end


-------- DATABASE LOADING

Bloodhound.HerbNodes = {};
Bloodhound.OreNodes = {};
Bloodhound.ContinentHerbs = {};
Bloodhound.ContinentOre = {};

function Bloodhound.ReloadNodes(database, zoneDatum)

	if (database == nil) then return {}; end

	local nodes = {};
	local db = {};

	local zoneNode, positions;
	for zoneNode, positions in pairs(database) do
		local _, _, zone, node = string.find(zoneNode, "Z(%d+)N(%d+)");
		local z = tonumber(zone);
		local datum = zoneDatum[z];
		local n = tonumber(node);
		db[n] = true;

		for _,pos in ipairs(positions) do
			local x = floor(pos / 1000);
			local y = pos - 1000 * x;
			x, y = Bloodhound.ZoneDatum.LocalToGlobal(x / 1000.0, y / 1000.0, datum);
			tinsert(nodes, {Z = z, N = n, X = x, Y = y, TimeStamp = time() - 3600});
		end
	end

	return nodes, db;
end


-------- UTILITY FUNCTIONS

function Print(message)
	DEFAULT_CHAT_FRAME:AddMessage(message);
end



-------- ARROW LOADING AND DISPLAY

local function GetArrowTexture()

	local tex = Bloodhound.GravityTexture

	if not ( tex ) then
		tex = Minimap:CreateTexture();
		tex:SetTexture("Interface\\AddOns\\Bloodhound\\MinimapArrow");
		Bloodhound.GravityTexture = tex
	end

	return tex
end

function Bloodhound.DrawArrow(gravityX, gravityY)

	local gravityTexture = GetArrowTexture()

	if (gravityX == 0 and gravityY == 0) then 
		gravityTexture:Hide();
		return;
	end

	local gravityScale = sqrt(gravityX * gravityX + gravityY * gravityY)
	gravityX = gravityX / gravityScale
	gravityY = gravityY / gravityScale
			
	-- determine rotated and scaled texture coordinates
	local gy = (gravityX + gravityY) / 2.82843
	local gx = (gravityX - gravityY) / 2.82843

	gravityTexture:SetTexCoord(
		0.5 - gx, 0.5 + gy,
		0.5 + gy, 0.5 + gx,
		0.5 - gy, 0.5 - gx,
		0.5 + gx, 0.5 - gy);
				
	gravityTexture:SetPoint("CENTER", Minimap, "CENTER", 40 * gravityX, -40 * gravityY)
	gravityTexture:Show()
end


-------- "RUBY" MANAGEMENT (REUSE RUBIES AND ONLY CREATE NEW ONES WHEN NEEDED)

local circles = {};
local nextCircle = 1;
local circleScale = 1;

function Bloodhound.ResetCircles()
	nextCircle = 1;
	circleScale = Minimap:GetHeight() * 0.015 / (7 - Minimap:GetZoom());
end

function Bloodhound.SetCircle(dx, dy, alpha)
	local circle;
	if (#circles < nextCircle) then
		circle = Minimap:CreateTexture();
		circles[nextCircle] = circle;
		circle:SetTexture("Interface\\AddOns\\Bloodhound\\Circle");
		circle:SetWidth(12);
		circle:SetHeight(12);
		circle:SetAlpha(1);
	else
		circle = circles[nextCircle];
	end

	nextCircle = nextCircle + 1;
	circle:SetPoint("CENTER", Minimap, "CENTER", dx * circleScale, -dy * circleScale);
	circle:SetAlpha(alpha);
	circle:Show();
end

function Bloodhound.HideExtraCircles()
	for i=nextCircle,#circles,1 do
		circles[i]:Hide();
	end
end



-------- MAIN FUNCTION FOR CALCULATING RECOMMENDED DIRECTION OF TRAVEL

function Bloodhound.CalculateForce()

	local c = player.C;			-- get player position
	local z = player.Z;
	local x = player.X;
	local y = player.Y;

	if c == 0 or z == 0 then return 0,0 end     -- don't draw arrow if using world coordinates
    if not Bloodhound.ZoneDatum then return 0,0 end
    
    local datum = Bloodhound.ZoneDatum[c][z];	-- get scale and offset for current zone map
    if datum == nil then return 0,0 end
    
	local gx, gy = Bloodhound.ZoneDatum.LocalToGlobal(x, y, datum);	-- convert player position to world coordinates
	local now = time();			    -- value to use for time-stamping visited nodes
	local fx = 0;				    -- cumulative force, X-component
	local fy = 0;				    -- cumulative force, Y-component
	local multiZone = true;			-- whether to include more than the current zone
	local inspectionRadius = 60;

	if Settings then
		if Settings.MultiZoneMode==0 then
			multiZone = IsFlying();
		elseif Settings.MultiZoneMode==1 then
			multiZone = true;
		else
			multiZone = false;
		end

		if Settings.InspectionRadius then
			inspectionRadius = Settings.InspectionRadius;
		end
	end

	local settingsFilter;			-- which node types to ignore
	local nodes = {};				-- which nodes to track

	for i=1,GetNumTrackingTypes(),1 do
		local name, _, active, _ = GetTrackingInfo(i);
		if (active == 1) then
			if (name == L["Find Herbs"]) then
				settingsFilter = Settings.HerbFilter;
				nodes = Bloodhound.HerbNodes;
			elseif (name == L["Find Minerals"]) then
				settingsFilter = Settings.OreFilter;
				nodes = Bloodhound.OreNodes;
			end
		end
	end

	local avoidZones = {};			-- which zones to avoid

	if multiZone then
		for k,v in pairs(Settings.ZoneFilter[GetCurrentMapContinent()]) do
			avoidZones[k] = true;
		end
	end

	local avoidNodes = {};			-- which node types to ignore

	if settingsFilter then
		for k,v in pairs(settingsFilter) do
			avoidNodes[k] = true;
		end
	end

	local minimapSize = Minimap:GetWidth();
	Bloodhound.ResetCircles();
	
	for key, node in pairs(nodes) do
		if (avoidNodes[node.N] ~= true) and (avoidZones[node.Z] ~= true) and (multiZone or (node.Z == z)) then
			local dx = node.X - gx;
			local dy = node.Y - gy;
			local rsqrd = dx * dx + dy * dy;	
			local r = sqrt(rsqrd);			    -- distance to node
			local age = now - node.TimeStamp;	-- time since last inspected

			if (r < inspectionRadius) then
				node.TimeStamp = now;
			else
                --[[ 
                The magnitude of the force is proportional to the age and inversely 
                proportional to the square of the distance, and the direction is towards
                the node. The math for this starts out as
                
                local force = age / rsqrd
                local angle = math.atan2(dy, dx)
                fx = fx + force * math.cos(angle)
                fy = fy + force * math.sin(angle)
                
                But cos(angle) is just dx/r and sin(angle) is just dy/r, so we don't 
                actually need atan2, cos, and sin and instead we can write this as
                ]]
				local force = age / (r * rsqrd)
				fx = fx + force * dx
				fy = fy + force * dy
			end

			if (r < minimapSize) and (age > 60) then	-- draw ruby
				local alpha = (r - 60) / (minimapSize - 60);
				alpha = max(0, alpha);
				Bloodhound.SetCircle(dx, dy, alpha);
			end
		end
	end

	Bloodhound.HideExtraCircles();
	return fx, fy;
end
