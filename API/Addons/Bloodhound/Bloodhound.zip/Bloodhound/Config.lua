
-------- YOU'RE ON YOUR OWN HERE, THIS IS A FRIKKIN MESS

local element;
local frame;
local panel;
local herbPanel;
local orePanel;

local function Title(text)
	local str = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
	str:SetPoint("TOPLEFT", element, "TOPLEFT", 16, -16);
	str:SetJustifyH("LEFT");
	str:SetJustifyV("TOP");
	str:SetText(text);
	element = str;
end

local function Column2(offset)
	local str = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
	str:SetPoint("TOPLEFT", element, "TOPRIGHT", -offset, -16);
	str:SetText(" ");
	element = str;
end

local function Heading(text)
	local str = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight");
	str:SetPoint("TOPLEFT", element, "BOTTOMLEFT", 0, -8);
	str:SetText(text);
	element = str;
end

local ddCount = 0;

local function DropDown(settings, key, width, init)
	ddCount = ddCount + 1;
	local dd = CreateFrame("Frame", "dropDown"..ddCount, frame, "UIDropDownMenuTemplate");
	dd:EnableMouse(true);
	dd:SetPoint("TOPLEFT", element, "BOTTOMLEFT", 0, -8);
	dd.State = {};
	UIDropDownMenu_Initialize(dd, init);
	UIDropDownMenu_SetWidth(dd, width);
	UIDropDownMenu_JustifyText(dd, "LEFT");
	UIDropDownMenu_SetSelectedValue(dd, settings[key]);
	element = dd;
end

function AddButton(settings, key, menu, label, value)
	local info = UIDropDownMenu_CreateInfo();
	info.text = label;
	info.value = value;
	info.owner = menu;
	info.func = function()
		UIDropDownMenu_SetSelectedValue(this.owner, this.value);
		settings[key] = this.value;
		Bloodhound.UpdateMinimap();
	end;
	UIDropDownMenu_AddButton(info);
end

local cbCount = 0;

function CheckBox(label, value, relative, anchor, dx, dy, state)
	cbCount = cbCount + 1;
	local cb = CreateFrame("CheckButton", "checkBox"..cbCount, frame, "UICheckButtonTemplate");
	cb:SetWidth(16);
	cb:SetHeight(16);
	cb:SetPoint("TOPLEFT", relative, anchor, dx, dy);
	local text = getglobal(cb:GetName() .. "Text");
	text:SetText(label);
	cb:SetChecked(not state[value]);
	cb:SetScript("OnClick", function(self)
		if (self:GetChecked()) then
			state[value] = nil;
		else
			state[value] = 1;
		end
		Bloodhound.UpdateMinimap();
	end);
	element = cb;
	return text:GetWidth();
end

function ContinentName()
	return select(GetCurrentMapContinent(), GetMapContinents());
end

function CheckBoxes(table, state)
	local relative;
	local bottom;
	local height = 1;
	local maxWidth = 0;
	local i = 0;
	local checkboxes = {};

	for k, v in pairs(table) do
		height = height + 1;
	end

	height = floor(height / 2);

	for k, v in pairs(table) do
		i = i + 1;
		if (i > 1) and (mod(i, height) == 1) then
			width = CheckBox(v, k, relative, "TOPRIGHT", maxWidth + 6, 0, state);	
			relative = element;
			maxWidth = width;
		else
			width = CheckBox(v, k, element, "BOTTOMLEFT", 0, 0, state);
			if (i == 1) then relative = element; end;
			maxWidth = max(width, maxWidth);
		end
		if (i == height) then bottom = element; end;
		checkboxes[k] = element;
	end

	local button = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate");
	button:SetText(L["All"]);
	local allWidth = button:GetTextWidth() + 30;
	button:SetWidth(allWidth);
	button:SetHeight(22);
	button:SetPoint("TOPLEFT", bottom, "TOPLEFT", 0, -20);
	button:SetScript("OnClick", 
		function(self, button, down)
			for k, v in pairs(table) do
				checkboxes[k]:SetChecked(true);
				state[k] = nil;
			end
		end
	);

	element = button;

	local button = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate");
	button:SetText(L["None"]);
	button:SetWidth(button:GetTextWidth() + 30);
	button:SetHeight(22);
	button:SetPoint("TOPLEFT", bottom, "TOPLEFT", allWidth + 20, -20);
	button:SetScript("OnClick", 
		function(self, button, down)
			for k, v in pairs(table) do
				checkboxes[k]:SetChecked(false);
				state[k] = 1;
			end
		end
	);
end

function AddZones(...)
	local table = {};

	for i=1,select("#", ...),1 do
		table[i] = select(i, ...);
	end

	if not Settings.ZoneFilter then
		Settings.ZoneFilter = {{},{},{},{}};
	end

	CheckBoxes(table, Settings.ZoneFilter[GetCurrentMapContinent()]);
end

function AddHerbs()
	local table = {};

	for h, v in pairs(Bloodhound.ContinentHerbs) do
		local name = L[h];
		if not name then name="Herb "..h; end;
		table[h] = name;
	end

	if not Settings.HerbFilter then
		Settings.HerbFilter = {};
	end

	CheckBoxes(table, Settings.HerbFilter);
end

function AddOre()
	local table = {};

	for h, v in pairs(Bloodhound.ContinentOre) do
		local name = L[h];
		if not name then name="Ore "..h; end;
		table[h] = name;
	end

	if not Settings.OreFilter then
		Settings.OreFilter = {};
	end

	CheckBoxes(table, Settings.OreFilter);
end

local function CopyTable(table)
	local copy = {};
	for k,v in pairs(table) do
		if (type(v) == "table") then
			copy[k] = CopyTable(v);
		else
			copy[k] = v;
		end
	end
	return copy;
end

local configFrame;
local BackupSettings;

local function RefreshConfigFrame()
	if (configFrame) then
		configFrame:Hide();
	end

	BackupSettings = CopyTable(Settings);

	configFrame = CreateFrame("Frame", nil, panel);
	configFrame:SetAllPoints(panel);
	frame = configFrame;
	element = frame;
	Title(L["Bloodhound Options"]);
	Heading(L["Multi-Zone"]);
	DropDown(Settings, "MultiZoneMode", 120, function(menu)
		AddButton(Settings, "MultiZoneMode", menu, L["While flying"], 0);
		AddButton(Settings, "MultiZoneMode", menu, L["Always"], 1);
		AddButton(Settings, "MultiZoneMode", menu, L["Never"], 2);
	end);
	Heading(L["Zones"].." ("..ContinentName()..")");
	AddZones(GetMapZones(GetCurrentMapContinent()));
	element = frame;
	Column2(150);
	Heading(L["Inspection radius"]);
	DropDown(Settings, "InspectionRadius", 70, function(menu)
		AddButton(Settings, "InspectionRadius", menu, 30, 30);
		AddButton(Settings, "InspectionRadius", menu, 35, 35);
		AddButton(Settings, "InspectionRadius", menu, 40, 40);
		AddButton(Settings, "InspectionRadius", menu, 45, 45);
		AddButton(Settings, "InspectionRadius", menu, 50, 50);
		AddButton(Settings, "InspectionRadius", menu, 60, 60);
		AddButton(Settings, "InspectionRadius", menu, 70, 70);
		AddButton(Settings, "InspectionRadius", menu, 80, 80);
		AddButton(Settings, "InspectionRadius", menu, 90, 90);
		AddButton(Settings, "InspectionRadius", menu, 100, 100);
		AddButton(Settings, "InspectionRadius", menu, 120, 120);
	end);
end

local herbFrame;

local function RefreshHerbs()
	if (herbFrame) then herbFrame:Hide(); end;
	herbFrame = CreateFrame("Frame", nil, herbPanel);
	herbFrame:SetAllPoints(herbPanel);
	frame = herbFrame;
	element = frame;
	Title(L["Bloodhound Options"]);
	Heading(L["Herbs"].." ("..ContinentName()..")");
	AddHerbs();
end

local oreFrame;

local function RefreshOre()
	if (oreFrame) then oreFrame:Hide(); end;
	oreFrame= CreateFrame("Frame", nil, orePanel);
	oreFrame:SetAllPoints(orePanel);
	frame = oreFrame;
	element = frame;
	Title(L["Bloodhound Options"]);
	Heading(L["Minerals"].." ("..ContinentName()..")");
	AddOre();
end

local function RestoreHerbDefaults()
	Settings.HerbFilter = {};
end

local function RestoreOreDefaults()
	Settings.OreFilter = {};
end

local function RestoreZoneDefaults()
	Settings.MultiZoneMode = 0;
	Settings.InspectionRadius = 60;
	Settings.ZoneFilter[GetCurrentMapContinent()] = {};
end

panel = CreateFrame("FRAME", "Bloodhound_Config", Bloodhound.Frame);
panel.name = L["Bloodhound"];
panel.default = RestoreZoneDefaults;
panel.okay = function() end;
panel.cancel = function() Settings = BackupSettings; Bloodhound.UpdateMinimap(); end;
panel.refresh = RefreshConfigFrame;
InterfaceOptions_AddCategory(panel);

herbPanel = CreateFrame("FRAME", "Bloodhound_Config_Herbs", Bloodhound.Frame);
herbPanel.name = L["Herbs"];
herbPanel.parent = "Bloodhound_Config";
herbPanel.default = RestoreHerbDefaults;
herbPanel.okay = function() end;
herbPanel.cancel = function() end;
herbPanel.refresh = RefreshHerbs;
InterfaceOptions_AddCategory(herbPanel);

orePanel = CreateFrame("FRAME", "Bloodhound_Config_Ore", Bloodhound.Frame);
orePanel.name = L["Minerals"];
orePanel.parent = "Bloodhound_Config";
orePanel.default = RestoreOreDefaults;
orePanel.okay = function() end;
orePanel.cancel = function() end;
orePanel.refresh = RefreshOre;
InterfaceOptions_AddCategory(orePanel);

Settings = {};
Settings.MultiZoneMode = 0;
Settings.HerbFilter = {};
Settings.OreFilter = {};
Settings.ZoneFilter = {{}, {}, {}, {}};
Settings.InspectionRadius = 60;
