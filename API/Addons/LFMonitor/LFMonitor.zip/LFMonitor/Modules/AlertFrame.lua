﻿function LFMonitor:CreateAlertFrame()

	local frame = CreateFrame("ScrollingMessageFrame", "LFMMAIN", UIParent, "LFMonitorTemplate")
	local ddmenu = CreateFrame("Frame", "LFMonitorDDMenu", UIParent, "UIDropDownMenuTemplate")
	local clmenu = CreateFrame("Frame", "LFMonitorCLMenu", UIParent, "UIDropDownMenuTemplate")
	local upbutton = CreateFrame("Button", "ScrollAlertFrameUpBtn", frame)
	local downbutton = CreateFrame("Button","ScrollAlertFrameDownBtn", frame)
	local endbutton = CreateFrame("Button", "ScrollAlertFrameEndBtn", frame)
	local endflash = endbutton:CreateTexture("LFMEndFlash", "OVERLAY")

	frame:Hide()
	frame:SetMovable(true)
	frame:SetResizable(true)
	frame:EnableMouse(true)
	frame:EnableKeyboard(true)
	frame:EnableMouseWheel(true)
	frame:SetClampedToScreen(true)
	frame:SetJustifyV("BOTTOM")
	frame:SetJustifyH("LEFT")
	frame:SetFadeDuration(60)
	frame:SetMaxLines(64)
	frame:SetFrameStrata("BACKGROUND")
	frame:SetHeight(LFMonitorDB.alert.position.height)
	frame:SetWidth(LFMonitorDB.alert.position.width)
	frame:SetMinResize(150, 100)
	frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", LFMonitorDB.alert.position.x, LFMonitorDB.alert.position.y)
	frame:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMLEFT", (LFMonitorDB.alert.position.x + LFMonitorDB.alert.position.width), (LFMonitorDB.alert.position.y - LFMonitorDB.alert.position.height))
	frame:SetBackdrop({bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 16, insets = {left = 4, right = 4, top = 4, bottom = 4}})
	frame.TimeSinceLastUpdate = 0

	local function frameOnShow()

		LFMonitor:SetAlertBackdropColour()		
		LFMonitor:SetAlertBorderColour()
		LFMonitor:SetAlertFont()
		frame.isLocked = LFMonitorDB.options.locked

	end

	frame:SetScript("OnShow", frameOnShow)
	frame:SetScript("OnHyperlinkClick", function(self, link, text, button) LFMonitor:OnHyperlinkShow(self, link, text, button) end)
	frame:SetScript("OnHide", function(frame) if (frame.isMoving) then frame:StopMovingOrSizing(); frame.isMoving = false; end end)

	local function frameOnMouseDown(event, arg1)

		local left, right, top, bottom = nil, nil, nil, nil

		if (arg1 == "RightButton") then

			LFMonitor:ChatCommand(nil)

		elseif (((not frame.isLocked) or (frame.isLocked == 0)) and (arg1 == "LeftButton")) then 

			if (LFMonitor:IsEdge("LEFT")) then

				left = true
		
			end
		
			if (LFMonitor:IsEdge("RIGHT")) then

				right = true

			end

			if (LFMonitor:IsEdge("TOP")) then

				top = true

			end

			if (LFMonitor:IsEdge("BOTTOM")) then

				bottom = true

			end

			if (left) then

				if (bottom) then

					frame:StartSizing("BOTTOMLEFT")

				elseif (top) then

					frame:StartSizing("TOPLEFT")

				else

					frame:StartSizing("LEFT")

				end

			elseif (right) then

				if (bottom) then

					frame:StartSizing("BOTTOMRIGHT")

				elseif (top) then

					frame:StartSizing("TOPRIGHT")

				else

					frame:StartSizing("RIGHT")

				end

			elseif (top) then

				frame:StartSizing("TOP")

			elseif (bottom) then

				frame:StartSizing("BOTTOM")

			end

		end 

		if (left or right or top or botttom) then

			frame.isResizing = true

		elseif ((not frame.isLocked) or (frame.isLocked == 0)) then

			frame:StartMoving()
			frame.isMoving = true

		end

	end

	frame:SetScript("OnMouseDown", frameOnMouseDown)

	local function frameOnMouseUp()

		if (frame.isResizing or frame.isMoving) then 

			frame:StopMovingOrSizing()
			frame.isResizing = false
			frame.isMoving = false
			LFMonitorDB.alert.position.width = frame:GetWidth()
			LFMonitorDB.alert.position.height = frame:GetHeight()
			LFMonitorDB.alert.position.x = frame:GetLeft()
			LFMonitorDB.alert.position.y = frame:GetTop()

		end

	end

	frame:SetScript("OnMouseUp", frameOnMouseUp)

	local function frameOnEnter()

		local r, g, b, a = frame:GetTextColor()

		if (a < 1) then

			UIFrameFadeIn(frame, 0.5, a, 1)

		end

		if (not upbutton:IsVisible()) then

			LFMonitor:AlertShowButtons()

		end

		LFMonitor:SetMouse(true)
		
	end

	local function frameOnLeave()

		if (not LFMonitor:IsInBounds()) then

			LFMonitor:SetMouse(false)
			LFMonitor:AlertHideButtons()
			frame.TimeSinceLastUpdate = 0

		end

	end
	
	frame:SetScript("OnEnter", frameOnEnter)
	frame:SetScript("OnLeave", frameOnLeave)
	frame:SetScript("OnUpdate", function(self, elapsed) LFMonitor:AlertOnUpdate(self, elapsed) end)
	
	local function upOnClick()

		PlaySound("UChatScrollButton")
		frame:ScrollUp()

		if (LFMonitor.frame:GetScript("OnUpdate") == nil) then

			LFMonitor.frame:SetScript("OnUpdate", function(self, elapsed) LFMonitor:lfmframeOnUpdate(self, elapsed) end)

		end

	end

	upbutton:Hide()
	upbutton:SetHeight(27)
	upbutton:SetWidth(27)
	upbutton:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -10, -10)
	upbutton:SetScript("OnClick", upOnClick)
	upbutton:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollUp-Up")
	upbutton:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollUp-Down")
	upbutton:SetDisabledTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollUp-Disabled")
	upbutton:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")

	local function downOnClick()

		PlaySound("UChatScrollButton")
		frame:ScrollDown()

	end

	downbutton:Hide()
	downbutton:SetHeight(27)
	downbutton:SetWidth(27)
	downbutton:SetPoint("TOP", upbutton, "TOP", 0, -27)
	downbutton:SetScript("OnClick", downOnClick)
	downbutton:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up")
	downbutton:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Down")
	downbutton:SetDisabledTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Disabled")
	downbutton:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")

	local function frameOnMouseWheel(self, direction)

		if (direction == 1) then

			upOnClick()

		else

			downOnClick()

		end

	end

	frame:SetScript("OnMouseWheel", frameOnMouseWheel)

	endbutton:Hide()
	endbutton:SetHeight(27)
	endbutton:SetWidth(27)
	endbutton:SetPoint("TOP", downbutton, "TOP", 0, -27)
	endbutton:SetScript("OnClick", function() PlaySound("UChatScrollButton"); frame:ScrollToBottom(); LFMonitor.frame:SetScript("OnUpdate", nil); endflash:Hide(); end)
	endbutton:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollEnd-Up")
	endbutton:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollEnd-Down")
	endbutton:SetDisabledTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollEnd-Disabled")
	endbutton:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")

	endflash:Hide()
	endflash:SetHeight(27)
	endflash:SetWidth(27)
	endflash:SetPoint("TOP", downbutton, "TOP", 0, -27)
	endflash:SetTexture("Interface\\ChatFrame\\UI-ChatIcon-BlinkHilight")

	return frame

end