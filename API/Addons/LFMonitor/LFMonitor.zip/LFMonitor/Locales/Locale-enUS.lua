﻿if ((GetLocale() == "enUS") or (LFMonitor.TEXT == nil)) then 

-- Chat commands
	LFMonitor.CHAT_COMMANDS = {"lfmonitor", "lfmon"}

-- Whisper command
	LFMonitor.WHISPER_COMMAND = "/w"

--fonts
	LFMonitor.FONT_FRIZ = "Friz Quadrata TT"
	LFMonitor.FONT_ARIALN = "Arial Narrow"
	LFMonitor.FONT_SKURRI = "Skurri"
	LFMonitor.FONT_MORPHEUS = "Morpheus"

--timestamps
	LFMonitor.TS_12HR1 = "12h h:m"
	LFMonitor.TS_12HR2 = "12h h:m:s"
	LFMonitor.TS_12HR3 = "12h h:m am/pm"
	LFMonitor.TS_12HR4 = "12h h:m:s am/pm"
	LFMonitor.TS_24HR1 = "24h h:m"
	LFMonitor.TS_24HR2 = "24h h:m:s"

--appearance options
	LFMonitor.APPEARANCE_OPTIONS = "Appearance options"
	LFMonitor.TIMESTAMP = "Timestamp"
	LFMonitor.MESSAGE_TEXT = "Message text"
	LFMonitor.TEXT = "Text"
	LFMonitor.WINDOW = "Window"
	LFMonitor.FONT = "Font"
	LFMonitor.TIMESTAMP_FORMAT = "Timestamp format"

	if (GetCVar("locale") == "enGB") then

		LFMonitor.CLASS_COLOUR_TEXT = "Use class colours"

	else

		LFMonitor.CLASS_COLOUR_TEXT = "Use class colors"

	end

--profession options
	LFMonitor.SET_LOOKING_FOR = "Set the 'Looking For' professions to monitor"
	LFMonitor.PROF = "Looking for"

--responses options
	LFMonitor.RESPONSES = "Responses"
	LFMonitor.RESPONSES_TO_REQUESTS = "Responses to 'Looking For' requests"
	LFMonitor.SET_RESPONSES = "Set the responses to provide to requests"
	LFMonitor.WHISPER_ME = "Whisper me for prices"
	LFMonitor.LFG_RESPONSE = "Invite"

--general options
	LFMonitor.GENERAL_OPTIONS = "General options"
	LFMonitor.SEND_CRAFTING_LIST = "Send crafting list"
	LFMonitor.HIDE_IN_INSTANCES = "Hide in instances"
	LFMonitor.HIDE_IN_COMBAT = "Hide in combat"
	LFMonitor.SHOW_IN_CITIES = "Only show in major cities and inns"
	LFMonitor.TRADE_CHANNEL = "Only show when in Trade channel"
	LFMonitor.CRAFTING_LIST = "The crafting list will only be shown if the relevant crafting panel has been opened at least once since LFMonitor was installed. It will update each time the panel is opened"
	LFMonitor.SOUND_ON = "Sound on"
	LFMonitor.LOCK = "Lock position and size"
	LFMonitor.CHANNELS = "Monitored channels"

--custom search
	LFMonitor.CUSTOM_OPTIONS = "Custom monitoring"
	LFMonitor.CUSTOM_INST = "Enter a word or phrase you would like monitored"
	LFMonitor.CUSTOM_BASIC = "Basic search"
	LFMonitor.CUSTOM_ADV = "Advanced search"
	LFMonitor.CUSTOM_WARNING = "The box below will accept any lua pattern matching expression. This is for advanced users only. More information on lua patterns can be found at |cff00ff00http://www.wowwiki.com/Pattern_matching"
	LFMonitor.CUSTOM_CHANNELS = "Monitor Custom Channels"

--sounds
	LFMonitor.COINS = "Coins"
	LFMonitor.WINDOW_TAB = "Window tab"
	LFMonitor.MENU_OPENING = "Menu opening"
	LFMonitor.MINIMAP_OPENING = "Minimap opening"
	LFMonitor.SPELLBOOK_OPENING = "Spellbook opening"
	LFMonitor.SPELLBOOK_CLOSING = "Spellbook closing"
	LFMonitor.TALENTS_OPENING = "Talents opening"
	LFMonitor.QUEST_LOG_OPENING = "Quest log opening"
	LFMonitor.FISHING = "Fishing"
	LFMonitor.DISCOVERY = "Discovery"
	LFMonitor.APPLAUSE = "Applause"
	LFMonitor.BEEP = "Beep"
	LFMonitor.CLICK = "Click"
	LFMonitor.DOG_BARKING = "Dog barking"
	LFMonitor.MOUSE_CLICK = "Mouse click"
	LFMonitor.STAPLER = "Stapler"

--jewelcrafting
	LFMonitor.JEWELCRAFTING = "Jewelcrafting"
	LFMonitor.jctxt = {"jc", "jcer", "jewelcrafter", "jc'er", "cutter","jw", "jewel"}

--enchanting
	LFMonitor.ENCHANTING = "Enchanting"
	LFMonitor.enctxt = {"enchant", "enchanter", "chanter", "enc"}

--leatherworking
	LFMonitor.LEATHERWORKING = "Leatherworking"
	LFMonitor.lwtxt = {"lw", "lwer", "leatherworker"}

--inscription
	LFMonitor.INSCRIPTION = "Inscription"
	LFMonitor.instxt = {"inscription", "inscriptions", "inscriptioner", "inscriber", "inscripter", "inscriptor"}

--tailoring
	LFMonitor.TAILORING = "Tailoring"
	LFMonitor.tlrtxt = {"tailor", "tailer", "tailoring"}

--blacksmithing
	LFMonitor.BLACKSMITHING = "Blacksmithing"
	LFMonitor.bstxt = {"bs", "blacksmith", "blacksmither"}

--alchemy
	LFMonitor.ALCHEMY = "Alchemy"
	LFMonitor.alctxt = {"alchemist", "alc"}

--engineering
	LFMonitor.ENGINEERING = "Engineering"
	LFMonitor.engtxt = {"engineer", "eng", "engi"}

--want to buy
	LFMonitor.ALL_WTB_REQUESTS = "All 'Want to buy' requests"
	LFMonitor.wtbtxt = {"wtb", "want to buy"}

--want to sell
	LFMonitor.ALL_WTS_REQUESTS = "All 'Want to sell' requests"
	LFMonitor.wtstxt = {"wts", "want to sell", "selling"}

--looking for
	LFMonitor.ALL_LFG_REQUESTS = "All 'Looking for group' requests"
	LFMonitor.ALL_LF_CRAFTER_REQUESTS = "All 'Looking for crafter' requests"
	LFMonitor.GENERAL_LF_REQUESTS = "General 'Looking for' requests"
	LFMonitor.lftxt = {"lf", "looking for", "any"}
	LFMonitor.misctxt = {"crafter", "craft"}

--looking for work
	LFMonitor.ALL_LFW_REQUESTS = "All 'Looking for work' requests"
	LFMonitor.lfwtxt = {"lfw", "looking for work", "crafting", "cutting", "lf work"}

--looking for more
	LFMonitor.ALL_LFM_REQUESTS = "All 'Looking for more' requests"
	LFMonitor.LFM_OPTIONS = "'Looking For More' options"
	LFMonitor.LFM_LIMIT = "Limit LFM requests to the following classes"
	LFMonitor.lfmtxt = {"lf%d*m*"} -- lf(optional digit)m - matches lfm, lf1m, lf2m etc.
	LFMonitor.lfgtxt = {"lfg", "lfg/m", "looking for group"}
	LFMonitor.IGNORE_RAID = "Ignore raid settings"
	
--menu
-- in all the following section %s will be replaced with the player's name
	LFMonitor.AUTOREPLY = "Autoreply"
	LFMonitor.SEND_AUTO = "Send your autoresponse to %s"
	LFMonitor.IGNORE_LIST = "Add %s to your ignore list"
	LFMonitor.CLOSE_MENU = "Close this menu"
	LFMonitor.WHISPER = "Whisper %s"

--dialogues
	LFMonitor.CANNOT_SEND = "Cannot send an autoreponse - nothing to reply with!"
	LFMonitor.RESET_CONFIRM = "The will reset ALL LFMonitor's settings. Are you sure?"

--classes
	LFMonitor.DK_TXT = {"death knight", "deathknight", "dk"}
	LFMonitor.DR_TXT = {"druid", "drood"}
	LFMonitor.HU_TXT = {"hunter", "huntard"}
	LFMonitor.MA_TXT = {"mage"}
	LFMonitor.PA_TXT = {"paladin", "pally", "pala"}
	LFMonitor.PR_TXT = {"priest"}
	LFMonitor.RO_TXT = {"rogue", "rouge"}
	LFMonitor.SH_TXT = {"shaman", "shammy", "shamy"}
	LFMonitor.WA_TXT = {"warlock", "lock"}
	LFMonitor.WR_TXT = {"warrior", "war", "warr"}
	LFMonitor.TANK_TXT = {"tank", "mt", "ot", "tanks"}
	LFMonitor.HEALER_TXT = {"healer", "healers"}
	LFMonitor.DPS_TXT = {"dps", "dpser"}
	LFMonitor.CC_TXT = {"crowd control", "cc"}

--raids
	LFMonitor.EOE_NAME = "Eye of Eternity"
	LFMonitor.EOE = {"eoe%d*", "maly%d*", "malygos"}
	LFMonitor.ICC_NAME = "Icecrown Citadel"
	LFMonitor.ICC = {"icc%d*", "marrowgar", "deathwhisper", "gunship", "saurfang", "rotface", "festergut", "putricide", "princes", "queen", "dreamwalker", "sindragosa", "lich", "lk"}
	LFMonitor.NAXX_NAME = "Naxxramas"
	LFMonitor.NAXX = {"naxxramas", "naxx%d*", "anub'rekhan", "faerlina", "maexxna", "razuvious", "gothik", "horsemen", "patchwerk", "grobbulus", "gluth", "thaddius", "noth", "heigan", "loatheb", "sapphiron", "kel'thuzad"}
	LFMonitor.ONY_NAME = "Onyxia's Lair"
	LFMonitor.ONY = {"onyxia%d*", "ony%d*"}
	LFMonitor.OS_NAME = "Obsidium Sanctum"
	LFMonitor.OS = {"os", "os3d", "sarth", "sartharion"}
	LFMonitor.TOC_NAME = "Trial of the (Grand) Crusader"
	LFMonitor.TOC = {"toc%d*", "togc%d*", "tgc%d*", "beasts", "champs", "jaraxxus", "twins", "anub"}
	LFMonitor.RS_NAME = "Ruby Sanctum"
	LFMonitor.RS = {"rs%d*", "halion"}
	LFMonitor.ULR_NAME = "Ulduar"
	LFMonitor.ULR = {"ulduar%d*", "leviathan", "ignis", "razorscale", "deconstructor", "assembly", "kologarn", "auriaya", "mimiron", "freya", "thorim", "hodir", "vezax", "yogg", "yogg-saron","algalon"}
	LFMonitor.VOA_NAME = "Vault of Archavon"
	LFMonitor.VOA = {"voa%d*", "archavon", "koralon", "emalon", "toravon"}
	LFMonitor.BMJ_NAME = "Battle for Mount Hyjal"
	LFMonitor.BMJ = {"hyjal", "bmj%d*", "winterchill", "anetheron", "kaz'rogal", "azgalor", "archimonde"}
	LFMonitor.BT_NAME = "Black Temple"
	LFMonitor.BT = {"temple", "bt%d*", "naj'entus", "supremus", "akama", "gorefiend", "bloodboil", "reliquary", "shahraz", "illidari"}
	LFMonitor.GL_NAME = "Gruul's Lair"
	LFMonitor.GL = {"gruul%d*", "gl%d*", "maulgar"}
	LFMonitor.KZ_NAME = "Karazhan"
	LFMonitor.KZ = {"karazhan%d*", "kara%d*", "kz*d%", "attumen", "virtue", "moroes", "opera", "nightbane", "curator", "illhoof", "aran", "netherspite", "chess", "malchezaar"}
	LFMonitor.ML_NAME = "Magtheridon's Lair"
	LFMonitor.ML = {"mag%d*", "magtheridon", "ml%d*"}
	LFMonitor.SSC_NAME = "Serpentshire Cavern"
	LFMonitor.SSC = {"serpentshire", "ssc%d*", "hydross", "lurker", "leotheras", "karathress", "tidewalker", "vashj"}
	LFMonitor.SP_NAME = "Sunwell Plateau"
	LFMonitor.SP = {"sunwell%d*", "kalecgos", "sathrovarr", "brutallus", "felmyst", "eredar", "m'uru", "entropius", "kil'jaeden"}
	LFMonitor.TK_NAME = "Tempest Keep"
	LFMonitor.TK = {"tempest", "tk%d*", "al'ar", "reaver", "solarian", "sunstrider"}
	LFMonitor.ZA_NAME = "Zul'Aman"
	LFMonitor.ZA = {"zul'aman", "za%d*", "nalorakk", "akil'zon", "jen'alai", "halazzi", "malacrass", "zul'jin"}
	LFMonitor.BWL_NAME = "Blackwing Lair"
	LFMonitor.BWL = {"blackwing%d*", "bwl%d*", "razorgore", "vaelastrasz", "lashlayer", "firemaw", "ebonroc", "flamegor", "chromaggus", "nefarian"}
	LFMonitor.MC_NAME = "Molten Core"
	LFMonitor.MC = {"molten", "mc%d*", "lucifron", "magmadar", "gehennas", "garr", "geddon", "shazzrah", "sulfuron", "golemagg", "majordomo", "ragnaros"}
	LFMonitor.RQ_NAME = "Ruins of Ahn'Qiraj"
	LFMonitor.RQ = {"ahn'qiraj", "aq", "aq20", "kurinnaxx", "rajaxx", "moam", "buru", "ayamiss", "ossirian"}
	LFMonitor.AQ_NAME = "Temple of Ahn'Qiraj"
	LFMonitor.AQ = {"ahn'qiraj", "aq", "aq40", "skeram", "sartura", "fankriss", "viscidus", "huhuran", "emperors", "sandworm", "c'thun"}
	LFMonitor.UBRS_NAME = "Upper Blackrock Spire"
	LFMonitor.UBRS = {"blackrock", "ubrs%d*", "emberseer", "flamewreath", "goraluk", "jed", "gyth", "blackhand", "valthalak", "drakkisath"}
	LFMonitor.ZG_NAME = "Zul'Gurub"
	LFMonitor.ZG = {"zul'gurub", "zg%d*", "jeklik", "venoxis", "mar'li", "thekal", "arlokk", "soulflayer", "mandokir", "hexxer", "gahz'ranka", "madness"}
	
end
