function CT_RA_CreateDefaultSet()
	-- Create the "Default" set of options.
	CT_RAMenu_Options["Default"] = {
		PlayRSSound = 1,
		MenuLocked = 1,
		ShowMTs = { 1, 1, 1, 1, 1 },
		NotifyDebuffsClass = {},
		NotifyDebuffs = {},
		DefaultColor = { r = 0, g = 0.1, b = 0.9, a = 0.5 },
		MemberHeight = 40,
		PercentColor = { r = 1, g = 1, b = 1 },
		DefaultAlertColor = { r = 1, g = 1, b = 1 },
		BGOpacity = 0.4,
		WindowPositions = { },
		BuffArray = {
			{ ["show"] = 1, ["name"] = CT_RA_POWERWORDFORTITUDE, ["index"] = 1 },
			{ ["show"] = 1, ["name"] = CT_RA_MARKOFTHEWILD, ["index"] = 2 },
			{ ["show"] = 1, ["name"] = CT_RA_ARCANEINTELLECT, ["index"] = 3 },
			{ ["show"] = 1, ["name"] = CT_RA_SHADOWPROTECTION, ["index"] = 5 },
			{ ["show"] = 1, ["name"] = CT_RA_POWERWORDSHIELD, ["index"] = 6 },
			{ ["show"] = 1, ["name"] = CT_RA_SOULSTONERESURRECTION, ["index"] = 7 },
			{ ["show"] = 1, ["name"] = CT_RA_DIVINESPIRIT, ["index"] = 8 },
			{ ["show"] = 1, ["name"] = CT_RA_THORNS, ["index"] = 9 },
			{ ["show"] = 1, ["name"] = CT_RA_FEARWARD, ["index"] = 10 },
			{ ["show"] = 1, ["name"] = CT_RA_BLESSINGOFMIGHT, ["index"] = 11 },
			{ ["show"] = 1, ["name"] = CT_RA_BLESSINGOFWISDOM, ["index"] = 12 },
			{ ["show"] = 1, ["name"] = CT_RA_BLESSINGOFKINGS, ["index"] = 13 },
			{ ["show"] = 1, ["name"] = CT_RA_BLESSINGOFSALVATION, ["index"] = 14 },
			{ ["show"] = 1, ["name"] = CT_RA_BLESSINGOFLIGHT, ["index"] = 15 },
			{ ["show"] = 1, ["name"] = CT_RA_BLESSINGOFSANCTUARY, ["index"] = 16 },
			{ ["show"] = 1, ["name"] = CT_RA_RENEW, ["index"] = 17 },
			{ ["show"] = 1, ["name"] = CT_RA_REJUVENATION, ["index"] = 18 },
			{ ["show"] = 1, ["name"] = CT_RA_REGROWTH, ["index"] = 19 },
			{ ["show"] = 1, ["name"] = CT_RA_AMPLIFYMAGIC, ["index"] = 20 },
			{ ["show"] = 1, ["name"] = CT_RA_DAMPENMAGIC, ["index"] = 21 },
			{ ["show"] = 1, ["name"] = CT_RA_LIFEBLOOM, ["index"] = 22 },
			{ ["show"] = 1, ["name"] = CT_RA_WILDGROWTH, ["index"] = 23 },
		},
		DebuffColors = {
			{ ["type"] = CT_RA_CURSE, ["r"] = 1, ["g"] = 0, ["b"] = 0.75, ["a"] = 0.5, ["id"] = 4, ["index"] = 1 },
			{ ["type"] = CT_RA_MAGIC, ["r"] = 1, ["g"] = 0, ["b"] = 0, ["a"] = 0.5, ["id"] = 6, ["index"] = 2 },
			{ ["type"] = CT_RA_POISON, ["r"] = 0, ["g"] = 0.5, ["b"] = 0, ["a"] = 0.5, ["id"] = 3, ["index"] = 3 },
			{ ["type"] = CT_RA_DISEASE, ["r"] = 1, ["g"] = 1, ["b"] = 0, ["a"] = 0.5, ["id"] = 5, ["index"] = 4 },
			{ ["type"] = CT_RA_WEAKENEDSOUL, ["r"] = 1, ["g"] = 0, ["b"] = 1, ["a"] = 0.5, ["id"] = 2, ["index"] = 5 },
			{ ["type"] = CT_RA_RECENTLYBANDAGED, ["r"] = 0, ["g"] = 0, ["b"] = 0, ["a"] = 0.5, ["id"] = 1, ["index"] = 6 },
		},
		ShowGroups = { },
		SpellCastDelay = 0.5,
		SORTTYPE = "group",
	};
	for i = 1, CT_RA_MaxGroups do
		CT_RAMenu_Options["Default"]["NotifyDebuffsClass"][i] = 1;
	end
	for i = 1, NUM_RAID_GROUPS do
		CT_RAMenu_Options["Default"]["NotifyDebuffs"][i] = 1;
	end
end

function CT_RASets_CopyTable(source)
	if ( type(source) == "table" ) then
		local dest = { };
		for k, v in pairs(source) do
			dest[k] = CT_RASets_CopyTable(v);
		end
		return dest;
	else
		return source;
	end
end

function CT_RA_ResetOptions()
	-- Reset all options
	CT_RAMenu_Options = {};

	-- Create the "Default" option set.
	CT_RA_CreateDefaultSet();

	-- Copy the "Default" set into the "temp" set
	CT_RAMenu_Options["temp"] = CT_RASets_CopyTable(CT_RAMenu_Options["Default"]);
	CT_RAMenu_Options["temp"]["unchanged"] = 1;

	CT_RAMenu_CurrSet = "Default";
	CT_RASets_ButtonPosition = 16;
end


CT_RA_ResetOptions();


function CT_RASets_OnEvent(self, event, ...)
	if (event == "VARIABLES_LOADED") then
		CT_RASets_MoveButton();
	elseif (event == "PLAYER_REGEN_DISABLED") then
		if (UIDROPDOWNMENU_OPEN_MENU == "CT_RASets_DropDown") then
			CloseDropDownMenus();
		end
	end
end

function CT_RASets_MoveButton()
	CT_RASets_Button:SetPoint("TOPLEFT", "Minimap", "TOPLEFT", 52 - (80 * cos(CT_RASets_ButtonPosition)), (80 * sin(CT_RASets_ButtonPosition)) - 52);
end

function CT_RASets_ToggleDropDown()
	CT_RASets_DropDown.point = "TOPRIGHT";
	CT_RASets_DropDown.relativePoint = "BOTTOMLEFT";
	ToggleDropDownMenu(1, nil, CT_RASets_DropDown);
end

function CT_RASets_DropDown_Initialize(self)
	--CT_RASets_OpenedLevel = CT_RA_Level;
	CT_RASets_OpenedLevel = 0;

	local inCombat = InCombatLockdown();

	local info = {};
	info.text = "CT_RaidAssist";
	info.isTitle = 1;
	info.justifyH = "CENTER";
	info.notCheckable = 1;
	UIDropDownMenu_AddButton(info);

	info = { };
	info.text = "Open CTRA options";
	info.value = ".options";
	info.notCheckable = 1;
	info.disabled = inCombat;
	info.func = CT_RASets_DropDown_OnClick;
	UIDropDownMenu_AddButton(info);

	info = { };
	info.text = "Open CTRA raid window";
	info.value = ".ctraid";
	info.notCheckable = 1;
	info.disabled = inCombat;
	info.func = CT_RASets_DropDown_OnClick;
	UIDropDownMenu_AddButton(info);

	if ( ( CT_RASets_OpenedLevel or 0 ) >= 1 ) then
		info = { };
		info.text = "Target management";
		info.value = ".target";
		info.notCheckable = 1;
		info.disabled = inCombat;
		info.func = CT_RASets_DropDown_OnClick;
		UIDropDownMenu_AddButton(info);
	end
	
	info = { };
	if ( CT_RAMenu_Options["temp"]["LockGroups"] ) then
		info.text = "Unlock raid frames";
	else
		info.text = "Lock raid frames";
	end
	info.value = ".locktoggle";
	info.notCheckable = 1;
	info.disabled = inCombat;
	info.func = CT_RASets_DropDown_OnClick;
	UIDropDownMenu_AddButton(info);
	
	info = { };
	info.text = "Edit option sets";
	info.value = ".editsets";
	info.notCheckable = 1;
	info.disabled = inCombat;
	info.func = CT_RASets_DropDown_OnClick;
	UIDropDownMenu_AddButton(info);

	local numSets = 0;
	local sets = {};
	for k, v in pairs(CT_RAMenu_Options) do
		if ( k ~= "temp" ) then
			numSets = numSets + 1;
			if ( numSets == 8 ) then
				break;
			end
			tinsert(sets, k);
		end
	end
	if ( numSets > 0 ) then
		sort(sets, function (a, b)
				if (string.lower(a) < string.lower(b)) then
					return true;
				else
					return false;
				end
		end);

		info.text = "--- Option Sets ---";
		info.isTitle = 1;
		info.justifyH = "CENTER";
		info.notCheckable = 1;
		UIDropDownMenu_AddButton(info);

		for i, k in ipairs(sets) do
			info = { };
			info.text = k;
			info.value = "*" .. k;
			info.isTitle = nil;
			if ( CT_RAMenu_CurrSet == k ) then
				info.checked = 1;
			end
			info.disabled = inCombat;
			info.tooltipTitle = "Change Set";
			info.tooltipText = "Changes the current option set to this one, updating all of your settings to match the ones specified in the option set.";
			info.func = CT_RASets_DropDown_OnClick;
			UIDropDownMenu_AddButton(info);
		end
	end
end

function CT_RASets_DropDown_OnClick(self)
	if (self.value == ".options") then
		if (not InCombatLockdown()) then
			ShowUIPanel(CT_RAMenuFrame);
		end

	elseif (self.value == ".target") then
		ShowUIPanel(CT_RATargetFrame);

	elseif (self.value == ".editsets") then
		if (not InCombatLockdown()) then
			ShowUIPanel(CT_RAMenuFrame);
			CT_RAMenuButton_OnClick(self, 5);
		end

	elseif (self.value == ".locktoggle") then
		if (not InCombatLockdown()) then
			CT_RAMenu_Options["temp"]["LockGroups"] = not CT_RAMenu_Options["temp"]["LockGroups"];
			CT_RA_UpdateRaidFrames();
			CT_RAMenu_UpdateMenu();
			CT_RAMenu_UpdateOptionSets();
		end

	elseif (self.value == ".ctraid") then
		if (not InCombatLockdown()) then
			ShowUIPanel(CT_RATabFrame);
		end

	elseif (strsub(self.value, 1, 1) == "*") then
		for k, v in pairs(CT_RAMenu_Options) do
			if ( k ~= "temp" ) then
				if (k == strsub(self.value, 2)) then
					if (not InCombatLockdown()) then
						CT_RAMenu_LoadSet(k);
					end
					return;
				end
			end
		end
	end
end

function CT_RASets_DropDown_OnLoad(self)
	UIDropDownMenu_Initialize(self, CT_RASets_DropDown_Initialize, "MENU");
end

tinsert(UISpecialFrames, "CT_RAMenu_NewSetFrame");
tinsert(UISpecialFrames, "CT_RAMenu_DeleteSetFrame");

-- -----------------------------------------------------------------------

-- These CT_RASetsEdit* and CT_RASet_New functions are not used anywhere.
-- It may have been new code Cide was working on, or old code that he left here.
-- I've commented it out for now.

--[[

CT_RASetsEditFrame_NumButtons = 7;

function CT_RASetsEditFrame_Update()
	local numEntries = 0;
	for k, v in pairs(CT_RAMenu_Options) do
		numEntries = numEntries + 1;
	end
	FauxScrollFrame_Update(CT_RASetsEditFrameScrollFrame, numEntries, CT_RASetsEditFrame_NumButtons , 32);

	for i = 1, CT_RASetsEditFrame_NumButtons, 1 do
		local button = getglobal("CT_RASetsEditFrameBackdropButton" .. i);
		local index = i + FauxScrollFrame_GetOffset(CT_RASetsEditFrameScrollFrame);
		local num, name = 0, nil;
		if ( i <= numEntries ) then
			
			for k, v in pairs(CT_RAMenu_Options) do
				num = num + 1;
				if ( num == index ) then
					name = k;
					break;
				end
			end
			if ( name ) then
				button:Show();
				if ( CT_RASetsEditFrame.selected == name ) then
					getglobal(button:GetName() .. "CheckButton"):SetChecked(1);
				else
					getglobal(button:GetName() .. "CheckButton"):SetChecked(nil);
				end
				getglobal(button:GetName() .. "Name"):SetText(name);
			end
		else
			button:Hide();
		end
	end
end

function CT_RASetsEditCB_Check(id)
	for i = 1, CT_RASetsEditFrame_NumButtons, 1 do
		getglobal("CT_RASetsEditFrameBackdropButton" .. i .. "CheckButton"):SetChecked(nil);
	end
	if ( not id ) then
		return;
	end
	getglobal("CT_RASetsEditFrameBackdropButton" .. id .. "CheckButton"):SetChecked(1);
	local num = 0;
	for k, v in pairs(CT_RAMenu_Options) do
		if ( k ~= "temp" ) then
			num = num + 1;
			if ( num == id+FauxScrollFrame_GetOffset(CT_RASetsEditFrameScrollFrame) ) then
				CT_RASetsEditFrame.selected = k;
				if ( k == "Default" ) then
					CT_RASetsEditFrame_EnableDelete(nil);
				else
					CT_RASetsEditFrame_EnableDelete(1);
				end
				return;
			end
		end
	end
	CT_RASetsEditFrame_EnableDelete(nil);
end

function CT_RASetsEditFrame_EnableDelete(enable)
	if ( enable ) then
		CT_RASetsEditFrameDeleteButton:Enable();
	else
		CT_RASetsEditFrameDeleteButton:Disable();
	end
end

function CT_RASetsEdit_Delete()
	if ( CT_RASetsEditFrame.selected ) then
		CT_RAMenu_Options[CT_RASetsEditFrame.selected] = nil;
		if ( CT_RASetsEditFrame.selected == CT_RAMenu_CurrSet ) then
			CT_RAMenu_CurrSet = "Default";
			CT_RA_UpdateRaidGroup(0);
			CT_RAOptions_Update();
			CT_RA_UpdateMTs(true);
			CT_RA_UpdatePTs(true);
			CT_RA_UpdateVisibility();
			CT_RA_UpdateRaidFrameOptions();
			CT_RAMenu_UpdateMenu();
		end
	end
	CT_RASetsEditFrame.selected = nil;
	CT_RASetsEditFrame_Update();
	CT_RASetsEditFrame_EnableDelete(nil);
end

function CT_RASetsEditNewDropDown_OnLoad(self)
	UIDropDownMenu_Initialize(self, CT_RASetsEditNew_DropDown_Initialize);
	UIDropDownMenu_SetWidth(self, 180);
	UIDropDownMenu_SetSelectedName(CT_RASetsEditNew_DropDown, "Default");
end

function CT_RASetsEditNew_DropDown_Initialize(self)
	local info = {};
	for k, v in pairs(CT_RAMenu_Options) do
		if ( k ~= "temp" ) then
			info = { };
			info.text = k;
			info.func = CT_RASetsEditNew_DropDown_OnClick;
			UIDropDownMenu_AddButton(info);
		end
	end
end

function CT_RASetsEditNew_DropDown_OnClick(self)
	local num = 0;
	for k, v in pairs(CT_RAMenu_Options) do
		if ( k ~= "temp" ) then
			num = num + 1;
			if ( num == self:GetID() ) then
				CT_RASetsEditNewFrame.set = k;
				UIDropDownMenu_SetSelectedName(CT_RASetsEditNew_DropDown, k);
				return;
			end
		end
	end
	CT_RASetsEditNewFrame.set = "Default";
	UIDropDownMenu_SetSelectedName(CT_RASetsEditNew_DropDown, "Default");
end

function CT_RASet_New()
	local name = CT_RASetsEditNewFrameNameEB:GetText();
	if ( strlen(name) > 0 and CT_RASetsEditNewFrame.set and CT_RAMenu_Options[CT_RASetsEditNewFrame.set] and not CT_RAMenu_Options[name] ) then
		CT_RAMenu_Options[name] = { };
		for k, v in pairs(CT_RAMenu_Options[CT_RASetsEditNewFrame.set]) do
			CT_RAMenu_Options[name][k] = v;
		end
	end
	CT_RASetsEditFrame_Update();
end

]]

-- -----------------------------------------------------------------------

CT_RA_BuffTextures = {
	[CT_RA_POWERWORDFORTITUDE[1]] = { "Spell_Holy_WordFortitude", 30*60 },
	[CT_RA_POWERWORDFORTITUDE[2]] = { "Spell_Holy_PrayerOfFortitude", 60*60 },
	[CT_RA_MARKOFTHEWILD[1]] = { "Spell_Nature_Regeneration", 30*60 },
	[CT_RA_MARKOFTHEWILD[2]] = { "Spell_Nature_Regeneration", 60*60 },
	[CT_RA_ARCANEINTELLECT[1]] = { "Spell_Holy_MagicalSentry", 30*60 },
	[CT_RA_ARCANEINTELLECT[2]] = { "Spell_Holy_ArcaneIntellect", 60*60 },
	[CT_RA_ARCANEINTELLECT[3]] = { "Achievement_Dungeon_TheVioletHold", 30*60 },
	[CT_RA_ARCANEINTELLECT[4]] = { "Achievement_Dungeon_TheVioletHold_Heroic", 60*60 },
	[CT_RA_SHADOWPROTECTION[1]] = { "Spell_Shadow_AntiShadow", 10*60 },
	[CT_RA_SHADOWPROTECTION[2]] = { "Spell_Holy_PrayerofShadowProtection", 20*60 },
	[CT_RA_POWERWORDSHIELD] = { "Spell_Holy_PowerWordShield", 30 },
	[CT_RA_SOULSTONERESURRECTION] = { "Spell_Shadow_SoulGem", 30*60 },
	[CT_RA_DIVINESPIRIT[1]] = { "Spell_Holy_DivineSpirit", 30*60 },
	[CT_RA_DIVINESPIRIT[2]] = { "Spell_Holy_PrayerofSpirit", 60*60 },
	[CT_RA_THORNS] = { "Spell_Nature_Thorns", 10*60 },
	[CT_RA_FEARWARD] = { "Spell_Holy_Excorcism", 10*60 },
	[CT_RA_BLESSINGOFMIGHT[1]] = { "Spell_Holy_FistOfJustice" },
	[CT_RA_BLESSINGOFMIGHT[2]] = { "Spell_Holy_GreaterBlessingofKings" },
	[CT_RA_BLESSINGOFWISDOM[1]] = { "Spell_Holy_SealOfWisdom" },
	[CT_RA_BLESSINGOFWISDOM[2]] = { "Spell_Holy_GreaterBlessingofWisdom" },
	[CT_RA_BLESSINGOFKINGS[1]] = { "Spell_Magic_MageArmor" },
	[CT_RA_BLESSINGOFKINGS[2]] = { "Spell_Magic_GreaterBlessingofKings" },
	[CT_RA_BLESSINGOFSALVATION[1]] = { "Spell_Holy_SealOfSalvation" },
	[CT_RA_BLESSINGOFSALVATION[2]] = { "Spell_Holy_GreaterBlessingofSalvation" },
	[CT_RA_BLESSINGOFLIGHT[1]] = { "Spell_Holy_PrayerOfHealing02" },
	[CT_RA_BLESSINGOFLIGHT[2]] = { "Spell_Holy_GreaterBlessingofLight" },
	[CT_RA_BLESSINGOFSANCTUARY[1]] = { "Spell_Nature_LightningShield" },
	[CT_RA_BLESSINGOFSANCTUARY[2]] = { "Spell_Holy_GreaterBlessingofSanctuary" },
	[CT_RA_RENEW] = { "Spell_Holy_Renew", 15 },
	[CT_RA_REJUVENATION] = { "Spell_Nature_Rejuvenation", 12 },
	[CT_RA_REGROWTH] = { "Spell_Nature_ResistNature", 21 },
	[CT_RA_AMPLIFYMAGIC] = { "Spell_Holy_FlashHeal", 10*60 },
	[CT_RA_DAMPENMAGIC] = { "Spell_Nature_AbolishMagic", 10*60 },
	[CT_RA_LIFEBLOOM] = { "INV_Misc_Herb_Felblossom", 7 },
	[CT_RA_WILDGROWTH] = { "Ability_Druid_Flourish", 7 },
};
