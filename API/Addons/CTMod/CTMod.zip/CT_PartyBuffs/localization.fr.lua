-- Version : French ( by Sasmira )
-- Last Update : 03/31/2005


if ( GetLocale() == "frFR" ) then

CT_PARTYBUFFS_TOGGLE = { };
CT_PARTYBUFFS_TOGGLE["1"] = "Les Buffs du Groupe et des Familiers sont maintenant visibles.";
CT_PARTYBUFFS_TOGGLE["2"] = "Seulement les Buffs du Groupe sont maintenant visibles.";
CT_PARTYBUFFS_TOGGLE["3"] = "Seulement les Buffs du Familier sont maintenant visibles.";
CT_PARTYBUFFS_TOGGLE["4"] = "Les Buffs du Groupe et des Familiers sont maintenant cach\195\169s.";

CT_PARTYBUFFS_MODNAME1 = "Buffs de Groupe";
CT_PARTYBUFFS_SUBNAME1 = "Voir les Buffs";
CT_PARTYBUFFS_TOOLTIP1 = "Afficher les buffs de chaque membre du groupe sous leur portrait.\nCliquer pour changer l\'affichage.";

CT_PARTYBUFFS_NUMSHOWN = "%d Buffs de Groupe sont maintenant visibles.";

CT_PARTYBUFFS_MODNAME2 = "Bouton de Buffs";
CT_PARTYBUFFS_SUBNAME2 = "ON/OFF";
CT_PARTYBUFFS_TOOLTIP2 = "Change le nombre de Buffs affichables pour chaque membre du Groupe";

end