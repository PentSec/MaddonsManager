-- UnitFramesOptions
CT_UFO_RADIO = { "None", "Percent", "Deficit", "Values", "Current" };
CT_UFO_SELECTION = { "On Health Bar:", "Right of Health Bar:", "On Mana Bar:", "Right of Mana Bar:" };
CT_UFO_SELECTION2 = { "On Health Bar:", "Left of Health Bar:", "On Mana Bar:", "Left of Mana Bar:", "Enemy Health Bar:" };
CT_UFO_BOX = { "Player Frame", "Party Frames", "Target Frame", "Assist (Target of Target) Frame", "Focus Frame" };
CT_UFO_TARGETCLASS = "Show the class";
CT_UFO_PARTYTEXTSIZE = "Text Size";
CT_UFO_PARTYTEXTSIZE_LARGE = "Large";
CT_UFO_PARTYTEXTSIZE_SMALL = "Small";
CT_UFO_TARGETOFASSIST = "Show the target";
CT_UFO_ASSISTCASTBAR = "Show the casting bar";
CT_UFO_TARGETOFFOCUS = "Show the target";
CT_UFO_FOCUSCASTBAR = "Show the casting bar";
