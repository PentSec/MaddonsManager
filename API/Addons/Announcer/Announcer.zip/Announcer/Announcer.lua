Announcer = LibStub("AceAddon-3.0"):NewAddon("Announcer", "AceConsole-3.0");

local db;
local options;
local GroupedMessages = { };

local defaults = {
	profile = {
		messages = "Default~Announce this!",
	},
};

local GetNumRaidMembers = GetNumRaidMembers;
local GetNumPartyMembers = GetNumPartyMembers;
local IsInInstance = IsInInstance;
local SendChatMessage = SendChatMessage;
local select = select;
local strsplit = strsplit;

local function UpdateMessages()
	for index in pairs(GroupedMessages) do
		GroupedMessages[index] = nil;
	end
	
	local messages = { strsplit("\n", db.profile.messages) };
	local category, message;
	
	for i = 1, #(messages) do
		category, message = strsplit("~", messages[i]);
		category = strlower(category);
		
		if(not GroupedMessages[category]) then
			GroupedMessages[category] = { };
		end
		
		table.insert(GroupedMessages[category], message);
	end
end

local function getOptions()
	if(not options) then
		options = {
			name = "Announcer",
			type = "group",
			childGroups="tab",
			args = {
				messages = {
					name = "Messages",
					type = "group",
					args = {
						messages = {
							type = "input",
							name = "Messages",
							desc = "The messages to announce",
							get = function() return db.profile.messages end,
							set = function(_, messages) 
								db.profile.messages = messages
								UpdateMessages()
							end,
							multiline = 10,
							width = "full",
						},
					},
				},
				profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(Announcer.db)
			},
		};
	end
	
	return options;
end

function Announcer:RefreshOptions()
	UpdateMessages();
end

function Announcer:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("AnnouncerDB", defaults, "Default");
	LibStub("AceConfig-3.0"):RegisterOptionsTable("Announcer", getOptions);
	LibStub("AceConfigDialog-3.0"):AddToBlizOptions("Announcer");
	self:RegisterChatCommand("announcer", "DoAnnounce");
	self.db.RegisterCallback(self, "OnProfileChanged", "RefreshOptions");
	self.db.RegisterCallback(self, "OnProfileCopied", "RefreshOptions");
	self.db.RegisterCallback(self, "OnProfileReset", "RefreshOptions");
	db = self.db;
	
	UpdateMessages();
	
	 math.randomseed(math.random(0, 2147483647) + (GetTime() * 1000));
end

function Announcer:DoAnnounce(input)
	local group, channel;
	
	if(input) then
		group, channel = self:GetArgs(input, 2);
	end
	
	if(group) then 
		group = strlower(group);
	end

	if(not channel) then
		if(not group or group ~= "config") then
			self:Print("Usage:");
			self:Print("  /announcer |cffeda55fconfig|r: Open configuration panel");
			self:Print("  /announcer |cffff0fffmessagegroupname|r |cffeda55fgroup|r : Announce to your current group");
			self:Print("  /announcer |cffff0fffmessagegroupname|r |cffeda55fparty|r : Announce to your party");
			self:Print("  /announcer |cffff0fffmessagegroupname|r |cffeda55fraid|r : Announce to your raid");
			self:Print("  /announcer |cffff0fffmessagegroupname|r |cffeda55fguild|r : Announce to your guild");
			self:Print("  /announcer |cffff0fffmessagegroupname|r |cffeda55fofficer|r : Announce to your officers");
			self:Print("  /announcer |cffff0fffmessagegroupname|r |cffeda55frw|r : Announce as a raid warning");
			self:Print("  /announcer |cffff0fffmessagegroupname|r |cffeda55fbg|r : Announce to your battleground");
			self:Print("  /announcer |cffff0fffmessagegroupname|r |cffeda55fyell|r : Yell your announcement");
			self:Print("  /announcer |cffff0fffmessagegroupname|r |cffeda55fsay|r : Say your announcement");
		else
			InterfaceOptionsFrame_OpenToFrame("Announcer");
		end
	else
		if(not GroupedMessages[group]) then return; end
		
		channel = strlower(channel);
		
		local channelNumber = "";
		
		if(channel == "group") then
			local kind = select(2, IsInInstance());
			
			if(kind == "pvp") then
				channel = "BATTLEGROUND";
			elseif(GetNumRaidMembers() > 0) then
				channel = "RAID";
			elseif(GetNumPartyMembers() > 0) then
				channel = "PARTY";
			else
				channel = "SAY";
			end			
		elseif(channel == "party") then
			channel = "PARTY";
		elseif(channel == "raid") then
			channel = "RAID";
		elseif(channel == "guild") then
			channel = "GUILD";
		elseif(channel == "officer") then
			channel = "OFFICER";
		elseif(channel == "rw") then
			channel = "RAID_WARNING";
		elseif(channel == "bg") then
			channel = "BATTLEGROUND";
		elseif(channel == "yell") then
			channel = "YELL";
		elseif(channel == "say") then
			channel = "SAY";
		else
			channelNumber = channel;
			channel = "CHANNEL";
		end
		
		SendChatMessage(GroupedMessages[group][math.random(1, #(GroupedMessages[group]))], channel, nil, channelNumber);
	end
end
