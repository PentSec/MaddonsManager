local L = LibStub("AceLocale-3.0"):NewLocale("WarriorVigilanceTracker", "deDE", false)

if L then

-- Chat commands
L["wvt"] = "wvt"

-- Options
L["Options"] = "Optionen"
L["General Options for Warrior Vigilance Tracker."] = "Allgemeine Optionen"

L["Hide Title"] = "Verstecke Title"
L["Hides the Titletext"] = "Versteckt den Titletext"

L["Lock the frame."] = "Sperrt das Frame"
L["Frame locked"] = "Frame gesperrt"

L["Scale"] = "Skalierung"
L["scale the Frame"] = "Skaliert das Frame"

L["Only show in defensive stance"] = "Nur in defensive Haltung anzeigen"

--ReportLocations
L["Say"] = "Sagen"
L["Party"] = "Gruppe"
L["Raid"] = "Raid"
L["Guild"] = "Gilde"
L["Officer"] = "Offiziere"
L["Channel"] = "Channel"

L["Announce"] = "Melden"
L["Announces your vigilance to a given chat."] = "Meldet deine Wachsamkeit in einem voreingestellten Chat-Fenster."

L["Announce Channel"] = "Melde Channel"
L["Vigilance set on:"] = "Mein Wachsamkeit ist auf:"

-- Debug
L["Debug"] = "Debug"
L["Debug enabled"] = "Debug angeschaltet"
L["Debug-Mode"] = "Debug-Mode"

L["Vigilance"] = "Wachsamkeit"
L["Warrior Vigilance Tracker"] = "WVT"
L["No Vigilance!"] = "Keine Wachsamkeit!"
L["minutes"] = "min"

end

