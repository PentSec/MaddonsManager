local L = LibStub("AceLocale-3.0"):NewLocale("WarriorVigilanceTracker", "enUS", true)

-- Chat commands
L["wvt"] = true

-- Options
L["Options"] = true
L["General Options for Warrior Vigilance Tracker."] = true

L["Hide Title"] = true
L["Hides the Titletext"] = true

L["Lock the frame."] = true
L["Frame locked"] = true

L["Scale"] = true
L["scale the Frame"] = true

L["Only show in defensive stance"] = true

--ReportLocations
L["Say"] = true
L["Party"] = true
L["Raid"] = true
L["Guild"] = true
L["Officer"] = true
L["Channel"] = true

L["Announce"] = true
L["Announces your vigilance to a given chat."] = true

L["Announce Channel"] = true
L["Vigilance set on:"] = true

-- Debug
L["Debug"] = true
L["Debug enabled"] = true
L["Debug-Mode"] = true

L["Vigilance"] = true
L["Warrior Vigilance Tracker"] = "WVT"
L["No Vigilance!"] = true
L["minutes"] = "min"


