--[[****************************************************************
	Warrior Vigilance Tracker v1.0
	25 Aug 2009

	Author: Aoie @ EU Aman'thul Alliance
	****************************************************************
	Description:
		* Tracks your vigilance cast on the target
		* Shows time left or if vigilance was removed
		* Easy recasting by left-clicking the buttonframe without targeting
		* Right-clicking will cast vigilance on your current target
	****************************************************************]]

WarriorVigilanceTracker = LibStub("AceAddon-3.0"):NewAddon("WarriorVigilanceTracker", "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("WarriorVigilanceTracker")

local options = {
	name	= "Warrior Vigilance Tracker",
	handler	= WarriorVigilanceTracker,
	type	= 'group',
	args	= {
		Locked = {
			name = L["Frame locked"],
			desc = L["Lock the frame."],
			type = "toggle",
			set = "SetOption",
			get = function(info) return WarriorVigilanceTracker.db.profile.Locked end,
			order = 100,
		},
		HideTitle = {
			name = L["Hide Title"],
			desc = L["Hides the Titletext"],
			type = "toggle",
			set = "SetOption",
			get = function(info) return WarriorVigilanceTracker.db.profile.HideTitle end,
			order = 101,
		},
		Scale = {
			name = L["Scale"],
			desc = L["scale the Frame"],
			type = "range",
			min = 0.5,
			max = 2.0,
			step = 0.05,
			get = function(info) return WarriorVigilanceTracker.db.profile.Scale end,
			set = function(info, value)
					WarriorVigilanceTracker.db.profile.Scale = value
					WarriorVigilanceTracker.Frame.Anchor:SetScale(value)
				end,
			order = 102,
		},
		DefStance = {
			name = L["Only show in defensive stance"],
			desc = L["Only show in defensive stance"],
			type = "toggle",
			set  = function(info, value)
					WarriorVigilanceTracker.db.profile.DefStance = value
					WarriorVigilanceTracker:DefStanceChanged(0)
				end,
			get  = function(info) return WarriorVigilanceTracker.db.profile.DefStance end,
			order = 103,
		},
		Debug = {
			name = L["Debug enabled"],
			desc = L["Debug-Mode"],
			type = "toggle",
			set  = "SetOption",
			get = function(info) return WarriorVigilanceTracker.db.profile.Debug end,
			order = 999,
		},
		Announce = {
			type = "select",
			name = L["Announce"],
			desc = L["Announces your vigilance to a given chat."],
			values = {
				["1-SAY"] = L["Say"],
				["2-PARTY"] = L["Party"],
				["3-RAID"] = L["Raid"],
				["4-GUILD"] = L["Guild"],
				["5-OFFICER"] = L["Officer"],
				["9-CHANNEL"] = L["Channel"],
			},
			get = function(info) return WarriorVigilanceTracker.db.profile.Announce or "1-SAY" end,
			set = function(info, value)	WarriorVigilanceTracker.db.profile.Announce = value	end,
			order = 200,
		},
		AnnounceChannel = {
			type = "input",
			name = L["Announce Channel"],
			get = function(info) return WarriorVigilanceTracker.db.profile.AnnounceChannel end,
			set = function(info, value)	WarriorVigilanceTracker.db.profile.AnnounceChannel = value	end,
			order = 201,
		},
	},
}

local db
local timer
local version = "1.0"
local Debug = false
local datenname = ""
local datenspell = ""
local datentimer = 0

local defaults = {
	profile = {
		Debug		= false,
		Locked 		= false,
		HideTitle	= false,
		Announce 	= "1-SAY",
		Scale 		= 1,
		DefStance	= 0,
	},
}

local AnnounceList = {
	["1-SAY"] = "SAY",
	["2-PARTY"] = "PARTY",
	["3-RAID"] = "RAID",
	["4-GUILD"] = "GUILD",
	["5-OFFICER"] = "OFFICER",
	["9-CHANNEL"] = "CHANNEL",
}

local ClassColor = {
	["WARRIOR"] 	= "|cffc78c6e%s|r",
	["PALADIN"] 	= "|cfff58cba%s|r",
	["DEATH KNIGHT"]= "|cffc41f3b%s|r",
	["HUNTER"]		= "|cffabd473%s|r",
	["SHAMAN"]		= "|cff2459ff%s|r",
	["ROGUE"]		= "|cfffff569%s|r",
	["DRUID"]		= "|cffff7d0a%s|r",
	["MAGE"]		= "|cff89ccf0%s|r",
	["WARLOCK"]		= "|cff9482c9%s|r",
	["PRIEST"]		= "|cffffffff%s|r",
}

function WarriorVigilanceTracker:Debug(arg)
	if (Debug == true) then
		self:Print(arg)
	end
	if ((Debug == false) and (self.db.profile.Debug == true)) then
		self:Print(arg)
	end
end

function WarriorVigilanceTracker:SetOption(info, value)
	local name = info[#info]
	self.db.profile[name] = value
	local arg = info.arg
	if arg then self[arg](self) end
	self:Debug(name.." : "..tostring(value))
	if name == "HideTitle" then
		if value == true then
			self.Frame.Title:Hide()
			self.db.profile.Locked = true
		else
			self.Frame.Title:Show()
			self.db.profile.Locked = false
		end
	end
	if name == "Locked" then
		if self.db.profile.HideTitle == true and value == false then
			self.db.profile.HideTitle = false
			self.Frame.Title:Show()
		end
	end
end

function WarriorVigilanceTracker:GetOption(info)
	local name = info[#info]
	return self.db.profile[name]
end

function WarriorVigilanceTracker:SetupFrames()
	if self.db.profile.HideTitle then self.Frame.Title:Hide() end
	if self.db.profile.Scale then WarriorVigilanceTracker.Frame.Anchor:SetScale(self.db.profile.Scale) end
end

function WarriorVigilanceTracker:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("WarriorVigilanceTrackerDB", defaults, "Default")
	db = self.db.profile
	
	LibStub("AceConfig-3.0"):RegisterOptionsTable("WarriorVigilanceTracker", options)
	self.optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("WarriorVigilanceTracker", "WarriorVigilanceTracker")
	self:RegisterChatCommand(L["wvt"], "ChatCommand")
	
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	timer = self:ScheduleRepeatingTimer("Repeat", 2)
	
	self:CreateFrames()
	self:SetupFrames()
end

function WarriorVigilanceTracker:DefStanceChanged(defstance)
	if self.db.profile.DefStance then
		if defstance == 1 then
			self:Debug("DefStance found")
			self.Frame.Anchor:Show()
		else
			self:Debug("DefStance not found")
			self.Frame.Anchor:Hide()
		end
	else
		self:Debug("DB::DefStance = 0")
		self.Frame.Anchor:Show()
	end
end

--7/2 15:12:44.896  SPELL_AURA_APPLIED,0x03000000001D02A8,"Lavie",0x511,0x03000000001D02A8,"Lavie",0x511,71,"Defensive Stance",0x1,BUFF



function WarriorVigilanceTracker:OnEnable()
	self:Debug("OnEnable: Begin")
	_, unitclass = UnitClass("player")
	if (unitclass == "WARRIOR") then
		self:Debug("Class: Warrior")
		self.Frame.Anchor:Show()
	elseif ((Debug == true) or ((Debug == false) and (self.db.profile.Debug == true))) then
		self.Frame.Anchor:Show()
	end
end

function WarriorVigilanceTracker:OnDisable()

end

function WarriorVigilanceTracker:ChatCommand(input)
	if not input or input:trim() == "" then
        InterfaceOptionsFrame_OpenToCategory(self.optionsFrame)
    else
        LibStub("AceConfigCmd-3.0").HandleCommand(WarriorVigilanceTracker, "wvt", input)
    end
end

function WarriorVigilanceTracker_AnnounceToChat()
	local i, n = GetChannelName(WarriorVigilanceTracker.db.profile.AnnounceChannel)
	SendChatMessage(L["Vigilance set on:"].." "..datenname, AnnounceList[WarriorVigilanceTracker.db.profile.Announce], nil, i)
end

function WarriorVigilanceTracker:VigilanceCast(destName, spellName)
	self:Debug("VigilanceCast: Begin")
	datenname = destName
	datenspell = spellName
	datentimer = 0
	self:PreClick()
	self:Debug("VigilanceCast: End")
end

function WarriorVigilanceTracker:VigilanceRemoved(destName)
	self:Debug("VigilanceRemoved: Begin")
	datenname = ""
	datenspell = ""
	datentimer = 0
	self.Frame.Button.Time:SetTextColor(1,0,0,1)
	self.Frame.Button.Time:SetText("removed")
	self:Debug("VigilanceRemoved: End")
end

function WarriorVigilanceTracker:VigilanceRefresh(destName, spellName)
	self:Debug("VigilanceRefresh: Begin")
	if datenname == destName and datenspell == spellName then
		datentimer = 0
		self:PreClick()
	end
	self:Debug("VigilanceRefresh: End")
end

function WarriorVigilanceTracker:Repeat()
	if ((datentimer == 0) and not (datenname == "")) then
		local name, _, _, _, _, _, expirationTime, _, _ = UnitBuff(datenname, datenspell)
		datentimer = expirationTime
	end
	if not (datenname == "") then
		_, englishClass = UnitClass(datenname);
		if ClassColor[englishClass] then
			self.Frame.Button.Text:SetText(string.format(ClassColor[englishClass], datenname))
			self.Frame.Button.Time:SetText(format("%.0f",-1*(GetTime()-datentimer)/60).." "..L["minutes"])
		else
			self.Frame.Button.Text:SetText(datenname)
			self.Frame.Button.Time:SetText(format("%.0f",-1*(GetTime()-datentimer)/60).." "..L["minutes"])
		end
		if not InCombatLockdown() and updateOOC then 
			updateOOC = false
			self.Frame.Button:SetAttribute("unit", datenname)
		end
		
		if (-1*(GetTime()-datentimer)/60) > 9 then
			self.Frame.Button.Time:SetTextColor(0,1,0,1)
		elseif (-1*(GetTime()-datentimer)/60) > 3 then
			self.Frame.Button.Time:SetTextColor(1,1,0,1)
		else
			self.Frame.Button.Time:SetTextColor(1,0,0,1)
		end
		if (-1*(GetTime()-datentimer)/60) <= 0 then
			self.Frame.Button.Time:SetTextColor(1,0,0,1)
			self.Frame.Button.Time:SetText("removed")
		end
	end
end

function WarriorVigilanceTracker:COMBAT_LOG_EVENT_UNFILTERED(event, ...)
	local timestamp, type, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags = select(1, ...)

	if (sourceName == UnitName("player")) then
		if (type == "SPELL_AURA_APPLIED") then
			local spellId, spellName, _ = select(9, ...)
			self:Debug("SPELL_AURA_APPLIED 1")
			if (spellId == 50720) then
				self:Debug("SPELL_AURA_APPLIED 2")
				self:VigilanceCast(destName, spellName)
			elseif (spellName == "Defensive Stance") then
				self:DefStanceChanged(1)
			elseif (spellName == "Berserker Stance" or spellName == "Battle Stance") then
				self:DefStanceChanged(0)
			end
		end
		if (type == "SPELL_AURA_REMOVED") then
			local spellId, _, _ = select(9, ...)
			if (spellId == 50720) then
				self:VigilanceRemoved(destName)
			end
		end
	end
	if (type == "SPELL_AURA_REFRESH") then
		local spellId, spellName, _ = select(9, ...)
		if (spellId == 50720) then
			self:VigilanceRefresh(destName, spellName)
		end
	end
end

--7/2 15:12:44.896  SPELL_AURA_APPLIED,0x03000000001D02A8,"Lavie",0x511,0x03000000001D02A8,"Lavie",0x511,71,"Defensive Stance",0x1,BUFF

function WarriorVigilanceTracker:CreateFrames()
	local defaultTitle = L["Warrior Vigilance Tracker"].."|cffffcc00 "..version.."|r"
	self.Frame = {}
	--Create Anchor
	self.Frame.Anchor = CreateFrame("Frame", "WVT2", UIParent)
	local f = self.Frame.Anchor
	
	f:SetMovable(true)
	f:EnableMouse(true)
	f:SetFrameStrata("LOW")
	f:SetPoint("CENTER", UIParent, "CENTER")
	f:SetWidth(150)
	f:SetHeight(45)
	f:SetScript("OnLoad", function()
			this.isResizing = false
			this.isMoving = false
		end)
	f:SetScript("OnMouseUp", function()
			if this.isMoving then
				this:StopMovingOrSizing()
				this.isMoving = false
			end
		end)
	f:SetScript("OnMouseDown", function()
			if ((not db.Locked) or (db.Locked == 0) and (arg1 == "LeftButton")) then
				this:StartMoving()
				this.isMoving = true
			end
		end)
	f:SetScript("OnHide", function()
			if this.isMoving then
				this:StopMovingOrSizing()
				this.isMoving = false
			end
		end)
	
	--Create Title
	self.Frame.Title = f:CreateFontString("$parent_Title", f, "GameFontNormal")
	local t = self.Frame.Title
	t:SetJustifyH("CENTER")
	t:ClearAllPoints()
	t:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
	t:SetText(defaultTitle)
	t:SetTextColor(1,1,1,1)
	
	--Create the Button
	self.Frame.Button = CreateFrame("Button", "$parent_Button", f, "SecureActionButtonTemplate")
	local b = self.Frame.Button
	
	b:EnableMouse(true)
	b:EnableKeyboard(true)
	b:SetWidth(150)
	b:SetHeight(30)
	b:SetBackdrop({
		bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
		edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
		tile = true,
		tileSize = 4,
		edgeSize = 4,
		insets = { left = 2, right = 2, top = 2, bottom = 2, },
	})
	b:SetBackdropColor(0,0,0,1)
	b:RegisterForClicks("AnyUp")
	b:ClearAllPoints()
	b:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 0)

	b:SetAttribute("type1", "spell")
	b:SetAttribute("spell1", L["Vigilance"])
	
	b:SetAttribute("type2", "spell")
	b:SetAttribute("spell2", L["Vigilance"])
	b:SetAttribute("unit2", "target")

	b:SetAttribute("shift-type2", "macro")
	b:SetAttribute("shift-macrotext2", "/script WarriorVigilanceTracker_AnnounceToChat()")
	
	--Create the Button Text
	self.Frame.Button.Text = b:CreateFontString("$parent_Text", b, "GameFontHighlight")
	local bt = self.Frame.Button.Text
	
	bt:SetJustifyH("LEFT")
	bt:ClearAllPoints()
	bt:SetPoint("LEFT", b, "LEFT", 5, 0)
	bt:SetTextColor(1,1,1,1)
	bt:SetText(L["No Vigilance!"])
	
	--Create the Button Time
	self.Frame.Button.Time = b:CreateFontString("$parent_Time", b, "GameFontHighlight")
	local btt = self.Frame.Button.Time
	
	btt:SetJustifyH("RIGHT")
	btt:ClearAllPoints()
	btt:SetPoint("RIGHT", b, "RIGHT", -5, 0)
	btt:SetTextColor(1,1,1,1)
	btt:SetText("")
	
	f:Hide()
end

function WarriorVigilanceTracker:PreClick()
	if InCombatLockdown() then 
		updateOOC = true
	else
		self.Frame.Button:SetAttribute("unit", datenname)
	end
end








