-------------------------------------------------------------------------------
-- German localization
-------------------------------------------------------------------------------

if (GetLocale() == "deDE") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XAspectBarButtonToggle:LeftButton"] = "Zeige/Verstecke XAspectBar";
end;