-------------------------------------------------------------------------------
-- Spanish localization (Default)
-------------------------------------------------------------------------------

if (GetLocale() == "esES") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XAspectBarButtonToggle:LeftButton"] = "Muestre/Esconde XAspectBar";
end;