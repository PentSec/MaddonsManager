-------------------------------------------------------------------------------
-- English localization (Default)
-------------------------------------------------------------------------------

-- Bindings
BINDING_HEADER_XASPECTBAR_TITLE  = "XBar";
getfenv()["BINDING_NAME_CLICK XAspectBarButtonToggle:LeftButton"] = "Show/hide XAspectBar";

local XBARMOD="XAspectBar";

-- Aspects
XAspectBarSpells = {
	"^13165", --Aspect of the Hawk
	"^13163", -- Aspect of the Monkey
	"^61846", --Aspect of the Dragonhawk
	"^5118",--Aspect of the Cheetah
	"^13159",--Aspect of the Pack
	"^13161",--Aspect of the Beast
	"^20043",--Aspect of the Wild
	"^34074",--Aspect of the Viper
	XBAR_SNOWRAP,
	"^31519",--Trueshot Aura
};

XASPECTBAR_ACTIONBARPAGE = "Page "; --  For the slider options

XBarCore.Localize(XAspectBarSpells);