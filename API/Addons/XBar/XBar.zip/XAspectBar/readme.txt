Aspect Bar Switching
===================

The option to swap action bars in combat has been re-implemented!

To select which action bars to use, click the bottom + in the config window, select which aspect to change.  A slider will appear for it.  To disable the bar switching, select 0, to enable it, select which action bar you would like to swap to (1-6).