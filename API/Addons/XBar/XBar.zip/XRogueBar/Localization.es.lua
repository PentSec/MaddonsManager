-------------------------------------------------------------------------------
-- Spanish localization
-------------------------------------------------------------------------------

if (GetLocale() == "esES") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XRogueBarButtonToggle:LeftButton"] = "Muestre/Esconde XRogueBar";
end;