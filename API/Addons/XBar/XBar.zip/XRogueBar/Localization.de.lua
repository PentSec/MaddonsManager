-------------------------------------------------------------------------------
-- German localization
-- by Aphelandra - Todeskrallen
-------------------------------------------------------------------------------

if (GetLocale() == "deDE") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XRogueBarButtonToggle:LeftButton"] = "Zeige/Verstecke XRogueBar";
end;