﻿-- This is a backup database so that the bars will not completely fail for non enUS clients in case of Babble not loading

function XBar_LoadBackupClasses()
	print("XBarBackupDBClasses loaded");
	XBarBackupDBClasses = {
		["deDE"] = {
			["Warlock"] = "Hexenmeister",
			["Warrior"] = "Krieger",
			["Hunter"] = "J\195\164ger",
			["Mage"] = "Magier",
			["Priest"] = "Priester",
			["Druid"] = "Druide",
			["Paladin"] = "Paladin",
			["Shaman"] = "Schamane",
			["Rogue"] = "Schurke",
			["Deathknight"] = "Todesritter",
		},
		["esES"] = {
			["Warlock"] = "Brujo",
			["Warrior"] = "Guerrero",
			["Hunter"] = "Cazador",
			["Mage"] = "Mago",
			["Priest"] = "Sacerdote",
			["Druid"] = "Druida",
			["Paladin"] = "Palad\195\173n",
			["Shaman"] = "Cham\195\161n",
			["Rogue"] = "P\195\173caro",
		},
		["frFR"] = {
			["Warlock"] = "Démoniste",
			["Warrior"] = "Guerrier",
			["Hunter"] = "Chasseur",
			["Mage"] = "Mage",
			["Priest"] = "Prêtre",
			["Druid"] = "Druide",
			["Paladin"] = "Paladin",
			["Shaman"] = "Chaman",
			["Rogue"] = "Voleur",
			["Deathknight"] = "Chevalier de la mort",
		},
		["twTW"] = {
			["Warlock"] = "術士",
			["Warrior"] = "戰士",
			["Hunter"] = "獵人",
			["Mage"] = "法師",
			["Priest"] = "牧師",
			["Druid"] = "德魯伊",
			["Paladin"] = "聖騎士",
			["Shaman"] = "薩滿",
			["Rogue"] = "盜賊",
			["Deathknight"] = "死亡騎士",
		},
	};
end