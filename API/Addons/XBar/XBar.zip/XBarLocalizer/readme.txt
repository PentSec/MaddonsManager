XBarLocalizer
=============

This addon provides an interface to integrate the Ace Library Babble into the Spell lists of XBar for non-enUS clients.  This will help ensure that non-enUS versions get updated spell names if new spells are added to the bars.

This addon now sports a converted localization database for backup purposes should any of the Ace2 libraries fail.  This database will be unloaded to conserve memory if this is a enUS client or all Ace2 libraries loaded properly on a non-enUS client.

***NOTE***
The backup database from 1.14 is INCOMPLETE, therefore not all buttons will show (it will act like you do not have the spell).
The Ace2 Libraries will find the most up-to-date version you have installed and auto-update themselves, the backup database will not.

If you have a non-enUS client, you may delete the mod entirely to save even more memory.