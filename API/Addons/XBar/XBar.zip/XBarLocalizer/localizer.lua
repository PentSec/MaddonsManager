local ForceUseBackupClass=false;

local locale=GetLocale();
local loadbackupclasses=false;
local lib;

XBarLocalizerCache = {};

-- This code provides a generalized interface in which to retrieve localizations from Babble.
lib=LibStub:GetLibrary("LibBabble-Class-3.0",1);
if not lib then
	if not ForceUseBackupClass then
		DEFAULT_CHAT_FRAME:AddMessage("XBarLocalizer: LibBabble-Class failed to load.");
	end
else
	XBarLocalizerLBC=lib:GetLookupTable();
end

-- Set this so mods can see if we're loaded or not
XBARLOCALIZER = true;

if (locale ~= "enUS" and locale ~= "enGB") and XBarLocalizerLBC==nil then
	-- If not using enUS or enGB, load the backup db
	loadbackupclasses=true;
end

if ForceUseBackupClass then
	XBarLocalizerLBC=nil;
	loadbackupclasses=true;
end

if loadbackupclasses then
	XBar_LoadBackupClasses();
end

function XBarGetBackupClass(classname)
	local r=nil;
	
	if (XBarBackupDBClasses) and (XBarBackupDBClasses[locale]) then
		r=XBarBackupDBClasses[locale][skill];
	end

	return r;
end

function XBar_BabbleClass(text)
	local r=text;

	if XBarLocalizerLBC==nil then
		r=XBarGetBackupClass(text);
	else
		r=XBarLocalizerLBC[text];
	end

	-- if we don't have it, just return the same value given
	if r==nil then
		r=text;
	end
	
	return r;
end