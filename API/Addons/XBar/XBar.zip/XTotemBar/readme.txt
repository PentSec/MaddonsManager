The bar will show your totems in green, and allied totem buffs in blue.

You can wrap the bar using the built-in options interface now.