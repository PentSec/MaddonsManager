-------------------------------------------------------------------------------
-- Spanish Localizations
-------------------------------------------------------------------------------

if (GetLocale() == "esES") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XTotemBarButtonToggle:LeftButton"] = "Muestre/Esconde XTotemBar";
end;