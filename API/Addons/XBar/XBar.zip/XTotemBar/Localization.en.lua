-------------------------------------------------------------------------------
-- English localization (Default)
-------------------------------------------------------------------------------

-- Bindings
getfenv()["BINDING_NAME_CLICK XTotemBarButtonToggle:LeftButton"] = "Show/hide XTotemBar";

-- Totems
XTotemBarSpells = {
	"#Earth",
	"^8071",--Stoneskin Totem
	"^2484",--Earthbind Totem
	"^5730",--Stoneclaw Totem
	"^8075",--Strength of Earth Totem
	"^8143",--Tremor Totem
	"^2062",--Earth Elemental Totem
	XBAR_SWRAP,
	"#Fire",
	"^3599",--Searing Totem
	"^1535",--Fire Nova Totem
	"^8190",--Magma Totem
	"^8227",--Flametongue Totem
	"^8181",--Frost Resistance Totem
	"^30706",--Totem of Wrath
	"^2894",--Fire Elemental Totem
	XBAR_SWRAP,
	"#Water",
	"^8170",--Cleansing Totem
	"^5394",--Healing Stream Totem
	"^5675",--Mana Spring Totem
	"^8184",--Fire Resistance Totem
	"^16190",--Mana Tide Totem
	XBAR_SWRAP,
	"#Air",
	"^8177",--Grounding Totem
	"^10595",--Nature Resistance Totem
	"^8512",--Windfury Totem
	"^6495",--Sentry Totem
	"^3738",--Wrath of Air Totem
};

XBarCore.Localize(XTotemBarSpells);

