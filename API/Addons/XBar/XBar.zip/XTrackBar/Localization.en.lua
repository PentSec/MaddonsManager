-------------------------------------------------------------------------------
-- English localization (Default)
-------------------------------------------------------------------------------

-- Bindings
getfenv()["BINDING_NAME_CLICK XTrackBarButtonToggle:LeftButton"] = "Show/hide XTrackBar";
