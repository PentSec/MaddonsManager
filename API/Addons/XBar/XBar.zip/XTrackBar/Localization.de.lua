-------------------------------------------------------------------------------
-- German localization
-------------------------------------------------------------------------------

if (GetLocale() == "deDE") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XTrackBarButtonToggle:LeftButton"] = "Zeige/Verstecke XTrackBar";
end;