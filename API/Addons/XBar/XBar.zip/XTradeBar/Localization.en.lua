-------------------------------------------------------------------------------
-- English localization (Default)
-- By Dr. Doom
-------------------------------------------------------------------------------

-- Bindings
getfenv()["BINDING_NAME_CLICK XTradeBarButtonToggle:LeftButton"] = "Show/hide XTradeBar";

-- As of XTradeBar 1.05 (XBar 1.10) or higher, the specialties must come right before their respective tradeskills
-- Note that the master weaponsmithing skills take precedence over the general skill "weaponsmith" and must appear before

-- Tradeskills
XTradeBarSpells = {
    --[[01]] "#^2259",
	--[[02]] "^28672",--Transmutation Master
	--[[03]] "^28675",--Potion Master
	--[[04]] "^28677",--Elixir Master
	--[[05]] "^2259",--Alchemy
    --[[06]] "#^2018",
	--[[07]] "^17039",--Master Swordsmith
	--[[08]] "^17041",--Master Axesmith
	--[[09]] "^17040",--Master Hammersmith
	--[[10]] "^9788",--Armorsmith
	--[[11]] "^9787",--Weaponsmith
	--[[12]] "^2018",--Blacksmithing
    --[[13]] "#^2575",
	--[[14]] "^2656",--Smelting
    --[[15]] "#^7411",
	--[[16]] "^7411",--Enchanting
	--[[17]] "^13262",--Disenchant
    --[[18]] "#^4036",
	--[[19]] "^20219",--Gnomish Engineer
	--[[20]] "^20222",--Goblin Engineer
	--[[21]] "^4036",--Engineering
	--[[22]] "#^45357",
	--[[23]] "^45357",--Inscription
	--[[24]] "^51005",--Milling
    --[[25]] "#^2108",
	--[[26]] "^10656",--Dragonscale Leatherworking
	--[[27]] "^10658",--Elemental Leatherworking
	--[[28]] "^10660",--Tribal Leatherworking
	--[[29]] "^2108",--Leatherworking
    --[[30]] "#^3908",
	--[[31]] "^26798",--Mooncloth Tailoring
	--[[32]] "^26797",--Spellfire Tailoring
	--[[33]] "^26801",--Shadoweave Tailoring
	--[[34]] "^3908",--Tailoring
    --[[35]] "#^25229",
	--[[36]] "^25229",--Jewelcrafting
	--[[37]] "^31252",--Prospecting
    --[[38]] "#Secondary",
	--[[39]] "^3273",--First Aid
	--[[40]] "Kochen", -- This is a fix for the deDE locale.  It perceives it as a 'Specialization' and replaces the spell
	--[[41]] "^2550",--Cooking
	--[[42]] "^818",--Basic Campfire
	--[[43]] "^7620",--Fishing
    --[[44]] "#Tracking",
	--[[45]] "^2580",--Find Minerals
	--[[46]] "^2383",--Find Herbs
	--[[47]] "^2481",--Find Treasure
	--[[48]] "^43308",--Find Fish
	--[[49]] "#Special",
	--[[50]] "%^53428",--Runeforging
};

XBarCore.Localize(XTradeBarSpells);