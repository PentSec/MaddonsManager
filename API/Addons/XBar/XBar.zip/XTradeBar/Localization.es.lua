-------------------------------------------------------------------------------
-- Spanish localization
--
-------------------------------------------------------------------------------
if (GetLocale() == "esES") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XTradeBarButtonToggle:LeftButton"] = "Muestre/Esconde XTradeBar";
end;