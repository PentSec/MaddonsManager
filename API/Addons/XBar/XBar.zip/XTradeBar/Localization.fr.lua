-------------------------------------------------------------------------------
-- French localization 
--
-------------------------------------------------------------------------------
if (GetLocale() == "frFR") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XTradeBarButtonToggle:LeftButton"] = "Montrer/cacher XTradeBar";
end;