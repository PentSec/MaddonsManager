-------------------------------------------------------------------------------
-- English localization (Default)
-------------------------------------------------------------------------------

-- Bindings
getfenv()["BINDING_NAME_CLICK XPetStuffBarButtonToggle:LeftButton"] = "Show/hide XPetStuffBar";

-- Pet Skills
XPetStuffBarSpells = {
	"#XP Bar",
	"*XPBar",
	"*XPBarText",
	"*XPBarHorizontal",
	"#PetStuffBar",
	"^62757",--Call Stabled Pet
	"^1515",--Tame Beast
	"^883",--Call Pet
	"^2641",--Dismiss Pet
	"^6991",--Feed Pet
	"^136",--Mend Pet
	"^982",--Revive Pet
	"^1462",--Beast Lore
	"^1002",--Eyes of the Beast
	"^6197",--Eagle Eye
	"^19574",--Bestial Wrath
	"^19577",--Intimidation
	"^34026",--Kill Command
	"^53271",--Master's Call
};

--Eagle eye isn't really a pet ability, but meh, what the hell.

XBarCore.Localize(XPetStuffBarSpells);