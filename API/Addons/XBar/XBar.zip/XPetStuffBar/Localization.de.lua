-------------------------------------------------------------------------------
-- German localization
-- By Aphelandra - Todeskrallen
-------------------------------------------------------------------------------

if (GetLocale() == "deDE") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XPetStuffBarButtonToggle:LeftButton"] = "Zeige/Verstecke XPetStuffBar";
end;