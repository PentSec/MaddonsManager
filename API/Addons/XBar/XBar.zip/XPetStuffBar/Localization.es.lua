-------------------------------------------------------------------------------
-- Spanish localization
-------------------------------------------------------------------------------

if (GetLocale() == "esES") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XPetStuffBarButtonToggle:LeftButton"] = "Muestre/Esconde XPetStuffBar";
end;