Custom Options:

XPBar:           Show a movable pet XP bar
XPBarText:       Always show text on the bar.
XPBarHorizontal: Shows the pet bar Horizontally (uncheck to show vertically)