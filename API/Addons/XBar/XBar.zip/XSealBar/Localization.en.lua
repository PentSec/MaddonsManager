-------------------------------------------------------------------------------
-- English localization (Default)
-------------------------------------------------------------------------------

-- Bindings
getfenv()["BINDING_NAME_CLICK XSealBarButtonToggle:LeftButton"] = "Show/hide XSealBar";

-- Seals
XSealBarSpells = {
	"^853",--Hammer of Justice
	"^24275",--Hammer of Wrath
	"^20271",--Judgement of Light
	"^53408",--Judgement of Wisdom
	"^53407",--Judgement of Justice
	"^21084",--Seal of Righteousness
	"^20164",--Seal of Justice
	"^20165",--Seal of Light
	"^20166",--Seal of Wisdom
	"^20375",--Seal of Command
	"^53736",--Seal of Corruption
	"^31801",--Seal of Vengeance
};

XBarCore.Localize(XSealBarSpells);
