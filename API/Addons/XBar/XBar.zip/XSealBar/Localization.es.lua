-------------------------------------------------------------------------------
-- Spanish localizations
-------------------------------------------------------------------------------

if (GetLocale() == "esES") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XSealBarButtonToggle:LeftButton"] = "Muestre/Esconde XSealBar";
end;