-------------------------------------------------------------------------------
-- French localization 
-------------------------------------------------------------------------------

if (GetLocale() == "frFR") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XBuffBarButtonToggle:LeftButton"] = "Montrer/cacher XBuffBar";
end;