-------------------------------------------------------------------------------
-- Spanish localization (Default)
-------------------------------------------------------------------------------

if (GetLocale() == "esES") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XBuffBarButtonToggle:LeftButton"] = "Muestre/Esconde XBuffBar";
end;