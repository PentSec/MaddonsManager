Options Pane Menu
=================

The available buffs from each class are broken down into sub menus based on which class you log into.  The menu has a nested structure that reflects this.