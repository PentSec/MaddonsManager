-------------------------------------------------------------------------------
-- German localization
-- by Aphelandra - Todeskrallen
-------------------------------------------------------------------------------

if (GetLocale() == "deDE") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XBuffBarButtonToggle:LeftButton"] = "Zeige/Verstecke XBuffBar";
end;