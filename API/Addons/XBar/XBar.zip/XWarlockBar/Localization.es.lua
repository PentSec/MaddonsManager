-------------------------------------------------------------------------------
-- Spanish localization
-------------------------------------------------------------------------------

if (GetLocale() == "esES") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XWarlockBarButtonToggle:LeftButton"] = "Muestre/Esconde XWarlockBar";
end;