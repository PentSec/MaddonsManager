-------------------------------------------------------------------------------
-- German localization
-- by Aphelandra - Todeskrallen
-------------------------------------------------------------------------------

if (GetLocale() == "deDE") then

getfenv()["BINDING_NAME_CLICK XWarlockBarButtonToggle:LeftButton"] = "Zeige/Verstecke XWarlockBar";
end;