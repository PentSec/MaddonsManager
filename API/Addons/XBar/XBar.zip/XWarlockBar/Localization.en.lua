-------------------------------------------------------------------------------
-- English localization (Default)
-------------------------------------------------------------------------------

-- Bindings
getfenv()["BINDING_NAME_CLICK XWarlockBarButtonToggle:LeftButton"] = "Show/hide XWarlockBar";

-- Spells
XWarlockBarSpells = {
	"#Demons",
	"^688",--Summon Imp
	"^697",--Summon Voidwalker
	"^712",--Summon Succubus
	"^691",--Summon Felhunter
	"^30146",--Summon Felguard
	"^1122",--Inferno
	"^18540",--Ritual of Doom
	"^126",--Eye of Kilrogg
	XBAR_SNOWRAP,
    "#Miscellaneous",
	"^1454",--Life Tap
	"^755",--Health Funnel
	"^18220",--Dark Pact
	"^1098",--Enslave Demon
	"^710",--Banish
	"^5500",--Sense Demons
	XBAR_SWRAP,
	"#Conjurables",
	"^48018",--Demonic Circle: Summon
	"^48020",--Demonic Circle: Teleport
	"^698",--Ritual of Summoning
	"^29893",--Ritual of Souls
	"^693",--Create Soulstone
	"^6201",--Create Healthstone
	"^6366",--Create Firestone
	"^2362",--Create Spellstone
	XBAR_SNOWRAP,
	"#Curses",
	"^702",--Curse of Weakness
	"^980",--Curse of Agony
	"^1714",--Curse of Tongues
	"^18223",--Curse of Exhaustion
	"^1490",--Curse of the Elements
	"^603",--Curse of Doom
};

XBarCore.Localize(XWarlockBarSpells);