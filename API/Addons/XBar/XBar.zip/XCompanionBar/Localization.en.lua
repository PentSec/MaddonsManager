--------------------------------------------------------------------------------- English localization (Default)
-------------------------------------------------------------------------------

-- Bindings
getfenv()["BINDING_NAME_CLICK XCompanionBarButtonToggle:LeftButton"] = "Show/hide XCompanionBar";

XCOMPANIONBAR_MSG1="XCompanionBar: New companion learned.  Type '/console reloadui' to show it on the bar.";
XCOMPANIONBAR_MSG2=" companions detected.";
XCOMPANIONBAR_MSG3="XCompanionBar: Companions not reported by WoW Client.  Type /console reloadui to fix.";

-- Since pets/mounts will be localized as retrieved from the game, there is no need to do any further localization.