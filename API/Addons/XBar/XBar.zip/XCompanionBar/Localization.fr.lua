-------------------------------------------------------------------------------
-- French localization 
-------------------------------------------------------------------------------

if (GetLocale() == "frFR") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XCompanionBarButtonToggle:LeftButton"] = "Montrer/cacher XCompanionBar";
end;