Custom Options:

WrapBar - This will make the bar split up into shorter bars where the Spacers are.  If you want to change the wrap points for this, open Localization.en.lua (or your language) and move the spacers around the list to accomodate.

Note that if new pets and mounts are added, you must reload the UI to show them.