--This is the internal name of the mod.
local XBARMOD="XCompanionBar";
local dbver="1";

--Default settings and other info about the mod
XBarCore.ModData[XBARMOD] = {
	["nbuttons"]=0,
	["dbver"]=dbver,
	["dhorizontal"]=true,
	["hidebar"]=false,
	["dorder"]="az",
	["dscale"]=1,
	["dtooltips"]=true,
	["enabled"]=true,
	["nchecks"]=0,
	["wrappable"]=true,
	["sortable"]=false, -- Cannot sort due to the way companions are auto-managed.
	["ftexint"]=XBARMOD.."_Texture",
	["fbuttonid"]="XBar_StdButtonID",
	["foptioncb"]="XBar_StdOptionCB",
};

XCompanionBarSpells = { }; -- Empty to start

local SETUPCOMPLETE=false;

function XCompanionBar_OnLoad()
	--Each bar must catch its own event notifications
	this:RegisterEvent("PLAYER_ENTERING_WORLD");
	this:RegisterEvent("COMPANION_UPDATE");
	this:RegisterEvent("COMPANION_LEARNED");
end

function XCompanionBar_OnEvent(event,arg1)
	local e=event;

	--XCompanionBar has some other things it needs to do besides the standard stuff.
	if (event == "PLAYER_ENTERING_WORLD") then
		XCompanionBar_Setup();
	elseif (event == "COMPANION_LEARNED") then
		print(XCOMPANIONBAR_MSG1);
	end
	XBar_StdEventHandler(XBARMOD,e,arg1);
end

function XCompanionBar_Setup()
	local i,v,n,_,t,m,b,c1,c2,last;
	local typelist={};

	if not SETUPCOMPLETE then
		typelist.mount="MOUNT";
		typelist.pet="CRITTER";

		XCompanionBarSpells = { };
		b=0;
		for m,t in pairs(typelist) do
			n=GetNumCompanions(t);
			b=b+n;
			c1=0;
			c2=1;
			-- If we have any companions of that type, iterate through and find the pet info we need.
			if (n ~= nil) and (n>0) then
				for i=1,n do
					c1=c1+1;
					if c1>15 then
						c1=1;
						c2=c2+1;
					end
					if c1==1 then
						tinsert(XCompanionBarSpells,"#"..m..tostring(c2));
						tinsert(XCompanionBarSpells,XBAR_SWRAP);
					end
					_,v,_,_,_=GetCompanionInfo(t,i);
					if (not v) and (i==1) then
						print(XCOMPANIONBAR_MSG3);
					end
					tinsert(XCompanionBarSpells,"!"..strsub(t,1,1)..tostring(v))

					-- Now to enable it if we have just discovered this pet.
					if (XBarData[XBarCore.XBarOptionSet].mods.XCompanionBar) and (XBarData[XBarCore.XBarOptionSet].mods.XCompanionBar[v]) == nil then
						-- Debug code here to track down a very elusive error.
						if (XBarCore.XBarOptionSet)==nil then 
							print("XCompanionBar: Option set not found, please report this to the author.");
						end
						if (XBarData[XBarCore.XBarOptionSet].mods==nil) then
							print("XCompanionBar: Mods index not found, please report this to the author.");
						end
						if (XBarData[XBarCore.XBarOptionSet].mods.XCompanionBar==nil) then
							print("XCompanionBar: XCompanionBar index not found, please report this to the author.");
						end
						XBarData[XBarCore.XBarOptionSet].mods.XCompanionBar[v]=true;
					end
				end
				if (m~="pet") then
					tinsert(XCompanionBarSpells,XBAR_SWRAP);
				end
			end
		end
		
		if (b==0) then
			-- No mounts/critters, so junk it.
			print("XCompanionBar: No"..XCOMPANIONBAR_MSG2);
			XBarCore.ModData[XBARMOD].enabled=false;
			XBarCore.ModData[XBARMOD].loaded=false;
		else
			print("XCompanionBar: "..tostring(b)..XCOMPANIONBAR_MSG2);
		end
		SETUPCOMPLETE=true;
	end
end

function XCompanionBar_Texture(texture,spellname)
	local t = texture;
	local summoned,_;

	-- Will highlight the Mount/critter the player has out
	_,summoned,_=XBarCore.GetCompanionInfo("MOUNT",spellname);
	if summoned then
		t="Interface\\Icons\\Spell_Nature_WispSplodeGreen";
	else
		_,summoned,_=XBarCore.GetCompanionInfo("CRITTER",spellname);
		if summoned then
			t="Interface\\Icons\\Spell_Nature_WispSplodeGreen";
		end
	end

	return t;
end
