-------------------------------------------------------------------------------
-- German localization
-- by Aphelandra - Todeskrallen
-------------------------------------------------------------------------------

if (GetLocale() == "deDE") then

getfenv()["BINDING_NAME_CLICK XCompanionBarButtonToggle:LeftButton"] = "Zeige/Verstecke XCompanionBar";
end;