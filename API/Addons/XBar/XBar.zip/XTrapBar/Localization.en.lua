-------------------------------------------------------------------------------
-- English localization (Default)
-------------------------------------------------------------------------------

-- Bindings
getfenv()["BINDING_NAME_CLICK XTrapBarButtonToggle:LeftButton"] = "Show/hide XTrapBar";

-- Traps
XTrapBarSpells = {
	"^13795",--Immolation Trap
	"^13813",--Explosive Trap
	"^1499",--Freezing Trap
	"^60192",--Freezing Arrow
	"^13809",--Frost Trap
	"^34600",--Snake Trap
};

XBarCore.Localize(XTrapBarSpells);