-------------------------------------------------------------------------------
-- German localization
-- by Aphelandra - Todeskrallen
-------------------------------------------------------------------------------

if (GetLocale() == "deDE") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XTrapBarButtonToggle:LeftButton"] = "Zeige/Verstecke XTrapBar";
end;