--This is the internal name of the mod.
local XBARMOD="XTrapBar";
local dbver="2";

local ForceTexture;

--Default settings and other info about the mod
XBarCore.ModData[XBARMOD]={
	----REQUIRED VALUES----
	["nbuttons"]=0,
	["dbver"]=dbver,
	["dhorizontal"]=true,
	["dhidebar"]=false,
	["dorder"]="az",
	["dscale"]=1,
	["dtooltips"]=true,
	["enabled"]=false,
	["nchecks"]=0,
	["wrappable"]=false,
	["sortable"]=true,
	["fbuttonid"]="XBar_StdButtonID",
	["foptioncb"]="XBar_StdOptionCB",
};

function XTrapBar_OnLoad()
	--Each bar must catch its own event notifications
	local Class,_;

	-- Nonlocalized class check
	_, Class = UnitClass("player");
	if (Class == "HUNTER") then
		--Each bar must catch its own event notifications
		this:RegisterEvent("SPELLS_CHANGED");
		this:RegisterEvent("SPELL_UPDATE_COOLDOWN");
		this:RegisterEvent("PLAYER_ENTERING_WORLD");
		this:RegisterEvent("UNIT_AURA");
		this:RegisterEvent("ACTIONBAR_UPDATE_USABLE");
		XBarCore.ModData[XBARMOD].enabled=true;
	else
		this:SetScript("OnUpdate",nil);
		-- Reduces lag
	end
end
