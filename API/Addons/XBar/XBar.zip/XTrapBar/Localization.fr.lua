-------------------------------------------------------------------------------
-- French localization 
-------------------------------------------------------------------------------

if (GetLocale() == "frFR") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XTrapBarButtonToggle:LeftButton"] = "Montrer/cacher XTrapBar";
end;