-------------------------------------------------------------------------------
-- French localization 
-------------------------------------------------------------------------------

if (GetLocale() == "frFR") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XPortalsBarButtonToggle:LeftButton"] = "Montrer/cacher XPortalsBar";
end;