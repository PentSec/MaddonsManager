-------------------------------------------------------------------------------
-- English localization (Default)
-------------------------------------------------------------------------------

-- Bindings
getfenv()["BINDING_NAME_CLICK XPortalsBarButtonToggle:LeftButton"] = "Show/hide XPortalsBar";

-- Traps
XPortalsBarSpells = {
	"#Teleports",
	"^3561",--Teleport: Stormwind
	"^3562",--Teleport: Ironforge
	"^32271",--Teleport: Exodar
	"^3565",--Teleport: Darnassus
	"^3567",--Teleport: Orgrimmar
	"^3563",--Teleport: Undercity
	"^3566",--Teleport: Thunder Bluff
	"^32272",--Teleport: Silvermoon
	"^49358",--Teleport: Stonard
	"^49359",--Teleport: Theramore
	"^35715",--Teleport: Shattrath
	"^53140",--Teleport: Dalaran
	XBAR_SWRAP,
	"#Portals",
	"^10059",--Portal: Stormwind
	"^11416",--Portal: Ironforge
	"^32266",--Portal: Exodar
	"^11419",--Portal: Darnassus
	"^11417",--Portal: Orgrimmar
	"^11418",--Portal: Undercity
	"^11420",--Portal: Thunder Bluff
	"^32267",--Portal: Silvermoon
	"^49361",--Portal: Stonard
	"^49360",--Portal: Theramore
	"^35717",--Portal: Shattrath
	"^53142",--Portal: Dalaran
};

XBarCore.Localize(XPortalsBarSpells);
