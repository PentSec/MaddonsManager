--This is the internal name of the mod.
local XBARMOD="XPortalsBar";
local dbver="2";

--Default settings and other info about the mod
XBarCore.ModData[XBARMOD] = {
	["nbuttons"]=0,
	["dbver"]=dbver,
	["dhorizontal"]=true,
	["hidebar"]=false,
	["dorder"]="az",
	["dscale"]=1,
	["dtooltips"]=true,
	["enabled"]=false,
	["nchecks"]=0,
	["wrappable"]=true,
	["sortable"]=true,
	["fbuttonid"]="XBar_StdButtonID",
	["fbuttoncb"]="XBar_StdButtonCB",
	["foptioncb"]="XBar_StdOptionCB",
};

function XPortalsBar_OnLoad()
	--Each bar must catch its own event notifications
	local Class,_;

	-- Nonlocalized class check
	_, Class = UnitClass("player");
	if (Class == "MAGE") then
		this:RegisterEvent("SPELLS_CHANGED");
		this:RegisterEvent("SPELL_UPDATE_COOLDOWN");
		this:RegisterEvent("PLAYER_ENTERING_WORLD");
		this:RegisterEvent("ACTIONBAR_UPDATE_USABLE");
		XBarLoader.NotifyBagUpdates(XBARMOD,"XBar_StdEventHandler");
		XBarCore.ModData[XBARMOD].enabled=true;
	else
		this:SetScript("OnUpdate",nil);
		-- Reduces lag
	end
end
