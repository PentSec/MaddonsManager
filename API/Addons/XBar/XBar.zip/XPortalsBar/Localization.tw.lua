﻿-------------------------------------------------------------------------------
-- Traditional Chinese localization (竹笙姬@暴風祭壇 http://tw.myblog.yahoo.com/norova.tw/)
-------------------------------------------------------------------------------
if (GetLocale() == "zhTW") then

-- Bindings
getfenv()["BINDING_NAME_CLICK XPortalsBarButtonToggle:LeftButton"] = "顯示/隱藏 XPortalsBar";
end;