-------------------------------------------------------------------------------
-- English localization (Default)
-------------------------------------------------------------------------------

-- Bindings
BINDING_HEADER_XBAR_TITLE  = "XBar";
BINDING_NAME_XBAR_CONFIG   = "XBar Config";

-- Help text
XBAR_HELPTEXT1             = "Commands:";
XBAR_HELPTEXT2             = "  /xbar config";
XBAR_HELPTEXT3             = "  /xbar show <bar>";
XBAR_HELPTEXT4             = "  /xbar hide <bar>";
XBAR_HELPTEXT5             = "  /xbar resetpos <bar>";
XBAR_HELPTEXT16            = "  /xbar resetmod <bar>";
XBAR_HELPTEXT13            = "  /xbar toggle <bar>";
XBAR_HELPTEXT14            = "  /xbar stopmoving <bar>";
XBAR_HELPTEXT6             = "  /xbar options";
XBAR_HELPTEXT7             = "To move the bar: Hold down the control key and right click the XBar";

XBAR_HELPTEXT8             = "Options:";
XBAR_HELPTEXT9             = "  /xbar options view";
XBAR_HELPTEXT10            = "  /xbar options new <optionset>";
XBAR_HELPTEXT11            = "  /xbar options set #";
XBAR_HELPTEXT15            = "  /xbar options reset #";
XBAR_HELPTEXT12            = "  /xbar options delete #";

-- Gui Text
XBAR_CLOSEBTN              = "Close";
XBAR_REVERSE               = "Reverse";
XBAR_HORIZONTAL            = "Horizontal";
XBAR_SCALE                 = "Scale";
XBAR_VISIBLE               = "Visible";
XBAR_TOOLTIPS              = "Tooltips";
XBAR_TOGGLE                = "Toggle";
XBAR_WRAP                  = "Wrap";
XBAR_SELMOD                = "<-- Select Bar";
XBAR_SELOPTION             = "<-- Select Option";
XBAR_NOMOD                 = "NO BARS INSTALLED";
XBAR_SORTDISABLE           = "Sorting is not available for this bar.";
XBAR_HEADER                = "HEADER";
XBAR_SPACER                = "SPACER";
XBAR_OPTION                = "OPTION";
XBAR_BINDBTN               = "Bind";
XBAR_BINDWAIT              = "<press a key or click>";
XBAR_BINDERR               = "Binding already used in ";

-- Messages
XBAR_MSG1                  = ": Showing/hiding window.";
XBAR_MSG2                  = ": No version information found, switching to default settings.";
XBAR_MSG3                  = ": Version change detected, switching to default settings.";
XBAR_MSG4                  = "XBar: Initialized with optionset ";
XBAR_MSG5                  = ": Addon failed to register.";
XBAR_MSG6                  = ": Resetting position.";
XBAR_MSG7                  = "XBar: Invalid option set: ";
XBAR_MSG8                  = "XBar: New option set '";
XBAR_MSG9                  = "' stored in slot #";
XBAR_MSG10                 = "XBar: Deleting option set: ";
XBAR_MSG11                 = ": Unsticking window.";

XBAR_PLACEHOLDER           = "Click the button to open the options interface.";