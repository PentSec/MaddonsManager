--[[
    Author: Alternator (Massiner of Nathrezim)
    Copyright 2010
	
	Notes:


]]

BFLocales 	= {};
BFConst 	= {};
BFUtil 		= {};
BFUILib 	= {};
BFButton 	= {};
BFBar 		= {};
BFCustomAction = {};
ButtonForge_API1 = {};