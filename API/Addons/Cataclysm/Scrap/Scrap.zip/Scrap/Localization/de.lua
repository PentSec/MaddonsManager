local L = Scrap_Locals
if GetLocale() ~= 'deDE' then return end
	
L["Add"] = "Zur Müllliste hinzufügen"
L["Added"] = "Zur Müllliste hinzugefügt: %s"
L["AdvancedOptions"] = "Erweiterte Einstellungen"
L["AutoSell"] = "Automatisch verkaufen"
L["AutoSellTip"] = "Wenn aktiviert, wird Scrap deinen Müll automaitsch beim Händler verkaufen."
L["Junk"] = "Müll"
L["Loading"] = "Lade..."
L["NotJunk"] = "Kein Müll"
L["Remove"] = "Von der Müllliste entfernen"
L["Removed"] = "Von der Müllliste entfernt: %s"
L["SafeMode"] = "Sicherheitsmodus"
L["SafeModeTip"] = "Wenn eingeschaltet wird Scrap nicht mehr als 12 Gegenstände verkaufen, damit sie zurückgekauft werden können."
L["SellJunk"] = "Müll verkaufen"
L["ShowTutorials"] = "Zeige Anleitungen"
L["SoldJunk"] = "Du hast deinen Müll für %s verkauft"