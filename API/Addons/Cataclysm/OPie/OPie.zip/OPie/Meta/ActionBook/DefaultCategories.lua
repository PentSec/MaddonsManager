local AB = assert(OneRingLib.ext.ActionBook:compatible(1,2), "Requires a compatible ActionBook library version")

do -- spellbook
	local spells = {}
	local function search()
		local ni, i, st, sid = 1, 1
		repeat
			i, st, sid = i + 1, GetSpellBookItemInfo(i, "spell")
			if st == "SPELL" and not IsPassiveSpell(sid) then
				spells[ni], ni = sid, ni + 1
			end
		until not st
		for i=#spells,ni,-1 do
			spells[i] = nil
		end
		return ni-1
	end
	AB:category("Abilities", search, function(id) return "spell", spells[id] end)
end
do -- Items
	local items = {}
	local function search()
		local i = 1
		for bag=0,4 do
			for slot=1,GetContainerNumSlots(bag) do
				local iid = GetContainerItemID(bag, slot)
				if iid and GetItemSpell(iid) then
					items[i], i = iid, i+1
				end
			end
		end
		for slot=INVSLOT_FIRST_EQUIPPED, INVSLOT_LAST_EQUIPPED do
			if GetItemSpell(GetInventoryItemLink("player", slot)) then
				items[i], i = GetInventoryItemID("player", slot), i + 1
			end
		end
		for j=#items,i,-1 do
			items[j] = nil
		end
		return i-1
	end
	AB:category("Items", search, function(id) return "item",items[id] end)
end
AB:category("Mounts", function() return GetNumCompanions("MOUNT") end, function(id)
	return "spell", (select(3, GetCompanionInfo("MOUNT", id)))
end)
AB:category("Non-combat pets", function() return GetNumCompanions("CRITTER") end, function(id)
	return "spell", (select(3, GetCompanionInfo("CRITTER", id)))
end)
AB:category("Macros", function() local a,b = GetNumMacros() return a+b+1 end, function(id)
	if id == 1 then return "macrotext", "" end
	id = id - 1
	local g, p = GetNumMacros()
	if id > 0 and id <= g then
		return "macro", (GetMacroInfo(id))
	elseif id > g and id <= (g+p) then
		return "macro", (GetMacroInfo(id-g+36))
	end
end)
AB:category("Equipment sets", function() return GetNumEquipmentSets() end, function(id)
	return "equipmentset", (GetEquipmentSetInfo(id))
end)
AB:category("Raid markers", function() return 14 end, function(id) return id <= 8 and "raidmark" or "worldmark", id <= 8 and id or (id - 8) end)