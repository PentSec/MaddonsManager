-- load required libraries, required when running disembedded
LoadAddOn( "Ace3" )
LoadAddOn( "LibPeriodicTable-3.1" )
LoadAddOn( "LibSharedMedia-3.0" )
