function EventAlert_LoadAlerts_Warlock()

-- Custom
	if EA_CustomItems[EA_CLASS_WARLOCK] == nil then EA_CustomItems[EA_CLASS_WARLOCK] = {} end;

-- Normal
	if EA_Items[EA_CLASS_WARLOCK] == nil then EA_Items[EA_CLASS_WARLOCK] = {} end;
		-- Backdraft
			if EA_Items[EA_CLASS_WARLOCK][54274] == nil then EA_Items[EA_CLASS_WARLOCK][54274] = true end;
			if EA_Items[EA_CLASS_WARLOCK][54276] == nil then EA_Items[EA_CLASS_WARLOCK][54276] = true end;
			if EA_Items[EA_CLASS_WARLOCK][54277] == nil then EA_Items[EA_CLASS_WARLOCK][54277] = true end;

		-- Backlash
			if EA_Items[EA_CLASS_WARLOCK][34936] == nil then EA_Items[EA_CLASS_WARLOCK][34936] = true end;

		-- Decimation
			if EA_Items[EA_CLASS_WARLOCK][63165] == nil then EA_Items[EA_CLASS_WARLOCK][63165] = true end;
			if EA_Items[EA_CLASS_WARLOCK][63167] == nil then EA_Items[EA_CLASS_WARLOCK][63167] = true end;

		-- Empowered Imp
			if EA_Items[EA_CLASS_WARLOCK][47283] == nil then EA_Items[EA_CLASS_WARLOCK][47283] = true end;

		-- Eradication
			if EA_Items[EA_CLASS_WARLOCK][64368] == nil then EA_Items[EA_CLASS_WARLOCK][64368] = true end;
			if EA_Items[EA_CLASS_WARLOCK][64370] == nil then EA_Items[EA_CLASS_WARLOCK][64370] = true end;
			if EA_Items[EA_CLASS_WARLOCK][64371] == nil then EA_Items[EA_CLASS_WARLOCK][64371] = true end;

	    -- Molten Core
			if EA_Items[EA_CLASS_WARLOCK][47383] == nil then EA_Items[EA_CLASS_WARLOCK][47383] = true end;
			if EA_Items[EA_CLASS_WARLOCK][71162] == nil then EA_Items[EA_CLASS_WARLOCK][71162] = true end;
			if EA_Items[EA_CLASS_WARLOCK][71165] == nil then EA_Items[EA_CLASS_WARLOCK][71165] = true end;

		-- Nightfall
			if EA_Items[EA_CLASS_WARLOCK][17941] == nil then EA_Items[EA_CLASS_WARLOCK][17941] = true end;


-- Alternate
	if EA_AltItems[EA_CLASS_WARLOCK] == nil then EA_AltItems[EA_CLASS_WARLOCK] = {} end;
		-- Shadowburn
			if EA_AltItems[EA_CLASS_WARLOCK][17877] == nil then EA_AltItems[EA_CLASS_WARLOCK][17877] = true end;


-- Stacking
	if EA_StackingItems[EA_CLASS_WARLOCK] == nil then EA_StackingItems[EA_CLASS_WARLOCK] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_WARLOCK] == nil then EA_StackingItemsCounts[EA_CLASS_WARLOCK] = {} end;

end