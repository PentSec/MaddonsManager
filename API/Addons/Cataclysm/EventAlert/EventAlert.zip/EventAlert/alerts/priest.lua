function EventAlert_LoadAlerts_Priest()

-- Custom
	if EA_CustomItems[EA_CLASS_PRIEST] == nil then EA_CustomItems[EA_CLASS_PRIEST] = {} end;

-- Normal
	if EA_Items[EA_CLASS_PRIEST] == nil then EA_Items[EA_CLASS_PRIEST] = {} end;
		-- Borrowed Time
			if EA_Items[EA_CLASS_PRIEST][59887] == nil then EA_Items[EA_CLASS_PRIEST][59887] = true end;
			if EA_Items[EA_CLASS_PRIEST][59888] == nil then EA_Items[EA_CLASS_PRIEST][59888] = true end;
			if EA_Items[EA_CLASS_PRIEST][59889] == nil then EA_Items[EA_CLASS_PRIEST][59889] = true end;

	    -- Surge of Light
            -- Remove old spell IDs
            if EA_Items[EA_CLASS_PRIEST][33151] == true then EA_Items[EA_CLASS_PRIEST][33151] = nil end;
			if EA_Items[EA_CLASS_PRIEST][33151] == false then EA_Items[EA_CLASS_PRIEST][33151] = nil end;

            -- New Spell ID
            if EA_Items[EA_CLASS_PRIEST][88688] == nil then EA_Items[EA_CLASS_PRIEST][88688] = true end;



-- Alternate
	if EA_AltItems[EA_CLASS_PRIEST] == nil then EA_AltItems[EA_CLASS_PRIEST] = {} end;



-- Stacking
	if EA_StackingItems[EA_CLASS_PRIEST] == nil then EA_StackingItems[EA_CLASS_PRIEST] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_PRIEST] == nil then EA_StackingItemsCounts[EA_CLASS_PRIEST] = {} end;

        -- Evangelism
			if EA_StackingItems[EA_CLASS_PRIEST][81661] == nil then EA_StackingItems[EA_CLASS_PRIEST][81661] = true end;
			if EA_StackingItemsCounts[EA_CLASS_PRIEST][81661] == nil then EA_StackingItemsCounts[EA_CLASS_PRIEST][81661] = 5 end;

        -- Dark Evangelism
			if EA_StackingItems[EA_CLASS_PRIEST][87118] == nil then EA_StackingItems[EA_CLASS_PRIEST][87118] = true end;
			if EA_StackingItemsCounts[EA_CLASS_PRIEST][87118] == nil then EA_StackingItemsCounts[EA_CLASS_PRIEST][87118] = 5 end;

        -- Serendipity
			if EA_StackingItems[EA_CLASS_PRIEST][63731] == nil then EA_StackingItems[EA_CLASS_PRIEST][63731] = true end;
			if EA_StackingItems[EA_CLASS_PRIEST][63735] == nil then EA_StackingItems[EA_CLASS_PRIEST][63735] = true end;

			if EA_StackingItemsCounts[EA_CLASS_PRIEST][63731] == nil then EA_StackingItemsCounts[EA_CLASS_PRIEST][63731] = 2 end;
			if EA_StackingItemsCounts[EA_CLASS_PRIEST][63735] == nil then EA_StackingItemsCounts[EA_CLASS_PRIEST][63735] = 2 end;

        -- Shadow Orb
			if EA_StackingItems[EA_CLASS_PRIEST][77487] == nil then EA_StackingItems[EA_CLASS_PRIEST][77487] = true end;
			if EA_StackingItemsCounts[EA_CLASS_PRIEST][77487] == nil then EA_StackingItemsCounts[EA_CLASS_PRIEST][77487] = 3 end;

end