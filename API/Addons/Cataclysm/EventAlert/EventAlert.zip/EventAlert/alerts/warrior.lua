function EventAlert_LoadAlerts_Warrior()

-- Custom
	if EA_CustomItems[EA_CLASS_WARRIOR] == nil then EA_CustomItems[EA_CLASS_WARRIOR] = {} end;

-- Normal
	if EA_Items[EA_CLASS_WARRIOR] == nil then EA_Items[EA_CLASS_WARRIOR] = {} end;
		-- Battle Trance
			if EA_Items[EA_CLASS_WARRIOR][12964] == nil then EA_Items[EA_CLASS_WARRIOR][12964] = true end;

		-- Bloodsurge
			if EA_Items[EA_CLASS_WARRIOR][46916] == nil then EA_Items[EA_CLASS_WARRIOR][46916] = true end;

		-- Incite
			if EA_Items[EA_CLASS_WARRIOR][86627] == nil then EA_Items[EA_CLASS_WARRIOR][86627] = true end;

		-- Lambs to the Slaughter
			if EA_Items[EA_CLASS_WARRIOR][84584] == nil then EA_Items[EA_CLASS_WARRIOR][84584] = true end;
			if EA_Items[EA_CLASS_WARRIOR][84585] == nil then EA_Items[EA_CLASS_WARRIOR][84585] = true end;
			if EA_Items[EA_CLASS_WARRIOR][84586] == nil then EA_Items[EA_CLASS_WARRIOR][84586] = true end;

		-- Sudden Death
			if EA_Items[EA_CLASS_WARRIOR][52437] == nil then EA_Items[EA_CLASS_WARRIOR][52437] = true end;

		-- Sword and Board
			if EA_Items[EA_CLASS_WARRIOR][50227] == nil then EA_Items[EA_CLASS_WARRIOR][50227] = true end;

		-- Taste for Blood
			if EA_Items[EA_CLASS_WARRIOR][60503] == nil then EA_Items[EA_CLASS_WARRIOR][60503] = true end;


-- Alternate
	if EA_AltItems[EA_CLASS_WARRIOR] == nil then EA_AltItems[EA_CLASS_WARRIOR] = {} end;
		-- Overpower
	    	if EA_AltItems[EA_CLASS_WARRIOR][7384] == nil then EA_AltItems[EA_CLASS_WARRIOR][7384] = true end;

		-- Execute
	    	if EA_AltItems[EA_CLASS_WARRIOR][5308] == nil then EA_AltItems[EA_CLASS_WARRIOR][5308] = true end;

		-- Raging Blow
	    	-- if EA_AltItems[EA_CLASS_WARRIOR][85288] == nil then EA_AltItems[EA_CLASS_WARRIOR][85288] = true end;

		-- Revenge
	    	if EA_AltItems[EA_CLASS_WARRIOR][6572] == nil then EA_AltItems[EA_CLASS_WARRIOR][6572] = true end;

		-- Victory Rush
	        if EA_AltItems[EA_CLASS_WARRIOR][34428] == nil then EA_AltItems[EA_CLASS_WARRIOR][34428] = true end;


--Stacking
	if EA_StackingItems[EA_CLASS_WARRIOR] == nil then EA_StackingItems[EA_CLASS_WARRIOR] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_WARRIOR] == nil then EA_StackingItemsCounts[EA_CLASS_WARRIOR] = {} end;

	   -- Thunderstruck
	       if EA_StackingItems[EA_CLASS_WARRIOR][87095] == nil then EA_StackingItems[EA_CLASS_WARRIOR][87095] = true end;
	       if EA_StackingItems[EA_CLASS_WARRIOR][87096] == nil then EA_StackingItems[EA_CLASS_WARRIOR][87096] = true end;

           if EA_StackingItemsCounts[EA_CLASS_WARRIOR][87095] == nil then EA_StackingItemsCounts[EA_CLASS_WARRIOR][87095] = 3 end;
           if EA_StackingItemsCounts[EA_CLASS_WARRIOR][87096] == nil then EA_StackingItemsCounts[EA_CLASS_WARRIOR][87096] = 3 end;

end