function EventAlert_LoadAlerts_Mage()

-- Custom
	if EA_CustomItems[EA_CLASS_MAGE] == nil then EA_CustomItems[EA_CLASS_MAGE] = {} end;

--Normal
	if EA_Items[EA_CLASS_MAGE] == nil then EA_Items[EA_CLASS_MAGE] = {} end;
	   -- Arcane Concentration
			if EA_Items[EA_CLASS_MAGE][12536] == nil then EA_Items[EA_CLASS_MAGE][12536] = true end;

	   -- Arcane Missiles
			if EA_Items[EA_CLASS_MAGE][79683] == nil then EA_Items[EA_CLASS_MAGE][79683] = true end;

	   -- Blazing Speed
			if EA_Items[EA_CLASS_MAGE][31643] == nil then EA_Items[EA_CLASS_MAGE][31643] = true end;

	   -- Brain Freeze
			if EA_Items[EA_CLASS_MAGE][57761] == nil then EA_Items[EA_CLASS_MAGE][57761] = true end;

	   -- Firestarter
			if EA_Items[EA_CLASS_MAGE][54741] == nil then EA_Items[EA_CLASS_MAGE][54741] = true end;

	   -- Hot Streak
			if EA_Items[EA_CLASS_MAGE][48108] == nil then EA_Items[EA_CLASS_MAGE][48108] = true end;

	   -- Impact
			if EA_Items[EA_CLASS_MAGE][64343] == nil then EA_Items[EA_CLASS_MAGE][64343] = true end;


-- Alternate
	if EA_AltItems[EA_CLASS_MAGE] == nil then EA_AltItems[EA_CLASS_MAGE] = {} end;


-- Stacking
	if EA_StackingItems[EA_CLASS_MAGE] == nil then EA_StackingItems[EA_CLASS_MAGE] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_MAGE] == nil then EA_StackingItemsCounts[EA_CLASS_MAGE] = {} end;

    	-- Arcane Blast
		if EA_StackingItems[EA_CLASS_MAGE][36032] == nil then EA_StackingItems[EA_CLASS_MAGE][36032] = true end;
		if EA_StackingItemsCounts[EA_CLASS_MAGE][36032] == nil then EA_StackingItemsCounts[EA_CLASS_MAGE][36032] = 4 end;

    	-- Fingers of Frost
			if EA_StackingItems[EA_CLASS_MAGE][44544] == nil then EA_StackingItems[EA_CLASS_MAGE][44544] = true end;
			if EA_StackingItems[EA_CLASS_MAGE][44543] == nil then EA_StackingItems[EA_CLASS_MAGE][44543] = true end;
			if EA_StackingItems[EA_CLASS_MAGE][44545] == nil then EA_StackingItems[EA_CLASS_MAGE][44545] = true end;
			if EA_StackingItemsCounts[EA_CLASS_MAGE][44544] == nil then EA_StackingItemsCounts[EA_CLASS_MAGE][44544] = 1 end;
			if EA_StackingItemsCounts[EA_CLASS_MAGE][44543] == nil then EA_StackingItemsCounts[EA_CLASS_MAGE][44543] = 1 end;
			if EA_StackingItemsCounts[EA_CLASS_MAGE][44545] == nil then EA_StackingItemsCounts[EA_CLASS_MAGE][44545] = 1 end;

end