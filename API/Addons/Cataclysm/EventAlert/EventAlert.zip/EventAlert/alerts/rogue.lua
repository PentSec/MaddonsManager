function EventAlert_LoadAlerts_Rogue()

-- Custom
	if EA_CustomItems[EA_CLASS_ROGUE] == nil then EA_CustomItems[EA_CLASS_ROGUE] = {} end;

-- Normal
	if EA_Items[EA_CLASS_ROGUE] == nil then EA_Items[EA_CLASS_ROGUE] = {} end;


-- Alternate
	if EA_AltItems[EA_CLASS_ROGUE] == nil then EA_AltItems[EA_CLASS_ROGUE] = {} end;


-- Stacking
	if EA_StackingItems[EA_CLASS_ROGUE] == nil then EA_StackingItems[EA_CLASS_ROGUE] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_ROGUE] == nil then EA_StackingItemsCounts[EA_CLASS_ROGUE] = {} end;

	-- Combo Points
		if EA_StackingItems[EA_CLASS_ROGUE][64385] == nil then EA_StackingItems[EA_CLASS_ROGUE][64385] = true end;
		if EA_StackingItemsCounts[EA_CLASS_ROGUE][64385] == nil then EA_StackingItemsCounts[EA_CLASS_ROGUE][64385] = 5 end;

end