function EventAlert_LoadAlerts_Paladin()

-- Custom
	if EA_CustomItems[EA_CLASS_PALADIN] == nil then EA_CustomItems[EA_CLASS_PALADIN] = {} end;

-- Normal
	if EA_Items[EA_CLASS_PALADIN] == nil then EA_Items[EA_CLASS_PALADIN] = {} end;

        -- Art of War
			if EA_Items[EA_CLASS_PALADIN][59578] == nil then EA_Items[EA_CLASS_PALADIN][59578] = true end;

  		-- Daybreak
			if EA_Items[EA_CLASS_PALADIN][88819] == nil then EA_Items[EA_CLASS_PALADIN][88819] = true end;

		-- Denounce
			if EA_Items[EA_CLASS_PALADIN][85509] == nil then EA_Items[EA_CLASS_PALADIN][85509] = true end;

  		-- Grand Crusader
			if EA_Items[EA_CLASS_PALADIN][85416] == nil then EA_Items[EA_CLASS_PALADIN][85416] = true end;

  		-- Hand of Light
			if EA_Items[EA_CLASS_PALADIN][90174] == nil then EA_Items[EA_CLASS_PALADIN][90174] = true end;

		-- Infusion of Light
			if EA_Items[EA_CLASS_PALADIN][53672] == nil then EA_Items[EA_CLASS_PALADIN][53672] = true end;
			if EA_Items[EA_CLASS_PALADIN][54149] == nil then EA_Items[EA_CLASS_PALADIN][54149] = true end;

  		-- Sacred Duty
			if EA_Items[EA_CLASS_PALADIN][85433] == nil then EA_Items[EA_CLASS_PALADIN][85433] = true end;

  		-- Surge of Light
			if EA_Items[EA_CLASS_PALADIN][88688] == nil then EA_Items[EA_CLASS_PALADIN][88688] = true end;


-- Alternate
	if EA_AltItems[EA_CLASS_PALADIN] == nil then EA_AltItems[EA_CLASS_PALADIN] = {} end;

        -- Hammer of Wrath
			if EA_AltItems[EA_CLASS_PALADIN][24275] == nil then EA_AltItems[EA_CLASS_PALADIN][24275] = true end;


-- Stacking
	if EA_StackingItems[EA_CLASS_PALADIN] == nil then EA_StackingItems[EA_CLASS_PALADIN] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_PALADIN] == nil then EA_StackingItemsCounts[EA_CLASS_PALADIN] = {} end;

    	-- Holy Power
			if EA_StackingItems[EA_CLASS_PALADIN][85247] == nil then EA_StackingItems[EA_CLASS_PALADIN][85247] = true end;
			if EA_StackingItemsCounts[EA_CLASS_PALADIN][85247] == nil then EA_StackingItemsCounts[EA_CLASS_PALADIN][85247] = 3 end;

end