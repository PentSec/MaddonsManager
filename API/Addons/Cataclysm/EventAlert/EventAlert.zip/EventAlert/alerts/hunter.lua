function EventAlert_LoadAlerts_Hunter()

-- Custom
	if EA_CustomItems[EA_CLASS_HUNTER] == nil then EA_CustomItems[EA_CLASS_HUNTER] = {} end;

-- Normal
	if EA_Items[EA_CLASS_HUNTER] == nil then EA_Items[EA_CLASS_HUNTER] = {} end;
	    -- Rapid Killing
			if EA_Items[EA_CLASS_HUNTER][35098] == nil then EA_Items[EA_CLASS_HUNTER][35098] = true end;
			if EA_Items[EA_CLASS_HUNTER][35099] == nil then EA_Items[EA_CLASS_HUNTER][35099] = true end;


-- Alternate
	if EA_AltItems[EA_CLASS_HUNTER] == nil then EA_AltItems[EA_CLASS_HUNTER] = {} end;
		-- Counterattack
			if EA_AltItems[EA_CLASS_HUNTER][19306] == nil then EA_AltItems[EA_CLASS_HUNTER][19306] = true end;

		-- Kill Shot
			if EA_AltItems[EA_CLASS_HUNTER][53351] == nil then EA_AltItems[EA_CLASS_HUNTER][53351] = true end;


-- Stacking
	if EA_StackingItems[EA_CLASS_HUNTER] == nil then EA_StackingItems[EA_CLASS_HUNTER] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_HUNTER] == nil then EA_StackingItemsCounts[EA_CLASS_HUNTER] = {} end;

    	-- Master Marksman
    		if EA_StackingItems[EA_CLASS_HUNTER][82925] == nil then EA_StackingItems[EA_CLASS_HUNTER][82925] = true end;
			if EA_StackingItemsCounts[EA_CLASS_HUNTER][82925] == nil then EA_StackingItemsCounts[EA_CLASS_HUNTER][82925] = 5 end;

end