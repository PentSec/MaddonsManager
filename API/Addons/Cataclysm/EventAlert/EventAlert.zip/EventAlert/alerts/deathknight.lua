function EventAlert_LoadAlerts_Deathknight()

-- Custom
	if EA_CustomItems[EA_CLASS_DK] == nil then EA_CustomItems[EA_CLASS_DK] = {} end;

-- Normal
	if EA_Items[EA_CLASS_DK] == nil then EA_Items[EA_CLASS_DK] = {} end;
		-- Cinderglacier (Runeforge)
			if EA_Items[EA_CLASS_DK][53386] == nil then EA_Items[EA_CLASS_DK][53386] = true end;

		-- Killing Machine
			if EA_Items[EA_CLASS_DK][51124] == nil then EA_Items[EA_CLASS_DK][51124] = true end;

		-- Rime (Freezing Fog)
			if EA_Items[EA_CLASS_DK][59052] == nil then EA_Items[EA_CLASS_DK][59052] = true end;

		-- Sudden Doom
			if EA_Items[EA_CLASS_DK][81340] == nil then EA_Items[EA_CLASS_DK][81340] = true end;


-- Alternate
	if EA_AltItems[EA_CLASS_DK] == nil then EA_AltItems[EA_CLASS_DK] = {} end;
		-- Dark Transformation
	    	if EA_AltItems[EA_CLASS_DK][63560] == nil then EA_AltItems[EA_CLASS_DK][63560] = true end;

		-- Rune Strike
	    	if EA_AltItems[EA_CLASS_DK][56815] == nil then EA_AltItems[EA_CLASS_DK][56815] = true end;


-- Stacking
	if EA_StackingItems[EA_CLASS_DK] == nil then EA_StackingItems[EA_CLASS_DK] = {} end;
	if EA_StackingItemsCounts[EA_CLASS_DK] == nil then EA_StackingItemsCounts[EA_CLASS_DK] = {} end;

end