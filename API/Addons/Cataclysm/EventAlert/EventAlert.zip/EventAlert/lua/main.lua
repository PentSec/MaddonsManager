function EventAlert_OnLoad(self)
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
    self:RegisterEvent("COMBAT_TEXT_UPDATE");

    self:RegisterEvent("PLAYER_LOGIN");
    self:RegisterEvent("PLAYER_ENTERING_WORLD");
    self:RegisterEvent("PLAYER_DEAD");
    self:RegisterEvent("ADDON_LOADED");

    SlashCmdList["EVENTALERT"] = EventAlert_SlashHandler;
    SLASH_EVENTALERT1 = "/eventalert";
    SLASH_EVENTALERT2 = "/ea";
end


function EventAlert_OnEvent(self, event, ...)

	if (event == "ADDON_LOADED") then
        local arg1 = ...;
        if (arg1 == "EventAlert") then
	        EventAlert_LoadSpellArrays();
        	EventAlert_LoadVariables();
	        EventAlert_CreateOptionsPanels();
		    EventAlert_VersionCheck();

	       -- Create Actual Alert Frames
	   		EventAlert_CreateAnchorIcons();
	        EventAlert_CreateAlertIcons(EA_Items[EA_playerClass]);
	        EventAlert_CreateAlertIcons(EA_AltItems[EA_playerClass]);
			EventAlert_CreateAlertIcons(EA_StackingItems[EA_playerClass]);
	        EventAlert_CreateAlertIcons(EA_CustomItems[EA_playerClass]);
        end
    end

    -- Check for stuck buffs on the screen
    if #EA_TempBuffsTable ~= 0 then
        for i,v in ipairs (EA_TempBuffsTable) do
        	local check_name,_ = GetSpellInfo(v);
            local _, _, _, _, _, _, _, _, _, _, check_spellId = UnitBuff("player", check_name);

            if (check_spellId == nil) then
				if (EA_AltItems[EA_playerClass][v] or EA_StackingItems[EA_playerClass][EA_powerAlert]) then
                 -- Do Nothing
                else
                	local v2 = table.foreach(EA_TempBuffsTable, function(i2, v2) if v2==v then return v2 end end)
						if v2 then
                        	EA_removeBuffValue(v2);
						end
                end
            end
		end
    end
	-- End Check

    -- Monitor Holy Power and Combo Points
	if (EA_playerClass == EA_CLASS_PALADIN or EA_playerClass == EA_CLASS_ROGUE or EA_playerClass == EA_CLASS_DRUID) then

    	if EA_doPower == nil then EA_doPower = 0 end;

        if (EA_playerClass == EA_CLASS_PALADIN) then
	        EA_powerAlert = 85247;
			EA_powerValue = UnitPower("player", 9);
        else
	        EA_powerAlert = 64385;
            EA_powerValue = GetComboPoints("player", "target");
        end


        if (EA_StackingItems[EA_playerClass][EA_powerAlert]) then
        	if (EA_powerValue >= EA_StackingItemsCounts[EA_playerClass][EA_powerAlert]) then
		        if (EA_doPower == 0) then
			        EA_addBuffValue(EA_powerAlert);
		    	    EA_doPower = 1;
		        end
		    end
		end

	    if (EA_powerValue < EA_StackingItemsCounts[EA_playerClass][EA_powerAlert]) then
	    	if (EA_doPower == 1) then
	            EA_removeBuffValue(EA_powerAlert);
	    	    EA_doPower = 0;
	        end
	    end
    end


    if (event == "COMBAT_LOG_EVENT_UNFILTERED") then

		local EA_eventType = select(2, ...);
        local EA_arg7 = select(7, ...);
        local EA_arg9 = select(9, ...);
        local EA_arg10 = select(10, ...);
        local EA_arg13 = select(13, ...);

        if (EA_Config.Debug == true) then
            if (EA_arg7 == UnitName("player")) then
            	if (EA_arg10 ~= nil) then
	        		DEFAULT_CHAT_FRAME:AddMessage(""..EA_eventType.."  Name: "..EA_arg10.."  ID: "..EA_arg9);
	            end
           	end
        end

        if (EA_eventType == "SPELL_AURA_APPLIED" or EA_eventType == "SPELL_AURA_APPLIED_DOSE" or EA_eventType == "SPELL_AURA_REFRESH") then
        	if (EA_arg7 == UnitName("player")) then

				if (EA_Config.ShowSpellInfo) then
	        		DEFAULT_CHAT_FRAME:AddMessage("Spell Name: "..EA_arg10.."  --  Spell ID: "..EA_arg9);
	            end

				if (EA_Items[EA_playerClass][EA_arg9] or EA_CustomItems[EA_playerClass][EA_arg9]) then
		        	if #EA_TempBuffsTable ~= 0 then
                    	local v = table.foreach(EA_TempBuffsTable, function(i2, v2) if v2==EA_arg9 then return v2 end end)
		                if not v then
							EA_addBuffValue(EA_arg9);
						end
	                else
						EA_addBuffValue(EA_arg9);
	                end
                end

				if (EA_StackingItems[EA_playerClass][EA_arg9] and EA_arg9 ~= 64385) then
                	for i,v in pairs(EA_StackingItemsCounts[EA_playerClass]) do

                    	local name, rank = GetSpellInfo(i);

                       	local _,_,_,EA_count,_,_,_,_,_,_,_ = UnitBuff("player", name);

                        if (EA_count == nil) then
                        	-- Do nothing
                        else
                        	if (EA_count >= v) then
                                if #EA_TempBuffsTable ~= 0 then
    	                            local v = table.foreach(EA_TempBuffsTable, function(i2, v2) if v2==EA_arg9 then return v2 end end)
		                		 	if not v then
										EA_addBuffValue(EA_arg9);
									end
	                            else
									EA_addBuffValue(EA_arg9);
	                            end
                            end
                        end
                    end
                end

    	   	end
        end

        if (EA_eventType == "SPELL_AURA_REMOVED" or EA_eventType == "SPELL_AURA_REMOVED_DOSE") then
        	if (EA_arg7 == UnitName("player")) then
	            if (EA_Items[EA_playerClass][EA_arg9] or EA_CustomItems[EA_playerClass][EA_arg9]) then
                	local v = table.foreach(EA_TempBuffsTable, function(i, v) if v==EA_arg9 then return v end end)
						if v then
							EA_removeBuffValue(v);
			            end
	            end
            end
		end
    end

	if (event == "PLAYER_DEAD" or event == "PLAYER_ENTERING_WORLD") then
        local EA_arg9 = select(9, ...);

        local v = table.foreach(EA_TempBuffsTable, function(i, v) if v==EA_arg9 then return v end end)
			if v then
	        	local f = _G["EAFrame_"..v];
	            f:Hide();
				EA_TempBuffsTable = table.wipe(EA_TempBuffsTable);
			end


        -- I'm annoyed that this code has to be here and not above in the ADDON_LOADED event.  >-(
        if (EA_PreLoadComplete == 0) then

            for i,v in pairs(EA_AltItems[EA_playerClass]) do
                local name, rank = GetSpellInfo(i);
                local EA_link = GetSpellLink(i);

                if (EA_link ~= nil) then
                    local _, _, spellString = string.find(EA_link, "^|c%x+|Hspell:(.+)|h%[.*%]")

                    if (EA_PreLoadAlts[name] == nil) then
                        EA_PreLoadAlts[name] = spellString;
                    elseif (EA_PreLoadAlts[name] < spellString) then
                        EA_PreLoadAlts[name] = spellString;
                    elseif (EA_PreLoadAlts[name] >= spellString) then
                        -- Do Nothing
                    end
                end
            end
        EA_PreLoadComplete = 1;
        end
	end

	if (event == "COMBAT_TEXT_UPDATE") then
        local EA_arg1 = select(1, ...);
        local EA_arg2 = select(2, ...);

		if (EA_arg1 == "SPELL_ACTIVE" or EA_arg1 == "SPELL_CAST") then
            local v = table.foreach(EA_PreLoadAlts, function(i, v) if i==EA_arg2 then return v end end)
            if v then
            	v = tonumber(v);

            	if (EA_AltItems[EA_playerClass][v]) then
                	local v2 = table.foreach(EA_TempBuffsTable, function(i2, v2) if v2==v then return v2 end end)
                    if (not v2) then
                    	EA_addBuffValue(v);
                    end
                end
            end
        end
    end

end

function EventAlert_OnUpdate()
    if #EA_TempBuffsTable ~= 0 then

        local timerFontSize = 0;
        for i,v in ipairs (EA_TempBuffsTable) do
            local eaf = _G["EAFrame_"..v];

            local name, rank = GetSpellInfo(v);

            if (EA_Config.ShowStacks) then
            	if (EA_StackingItems[EA_playerClass][v]) then
					if (v == EA_powerAlert) then
						EA_count = EA_powerValue;
					else
						_,_,_,EA_count,_,_,_,_,_,_,_ = UnitBuff("player", name);
					end

					if (EA_count ~= nil) then
						eaf.spellCount:ClearAllPoints();
						eaf.spellCount:SetPoint("BOTTOMRIGHT", 0, 0);

						eaf.spellCount:SetFont("Fonts\\\FRIZQT__.TTF", 22, "OUTLINE");
						eaf.spellCount:SetFormattedText("%s", EA_count);
					end
				end
            else
				eaf.spellCount:ClearAllPoints();
				eaf.spellCount:SetPoint("BOTTOMRIGHT", 0, 0);

				eaf.spellCount:SetFont("Fonts\\\FRIZQT__.TTF", 22, "OUTLINE");
				eaf.spellCount:SetFormattedText("%s", "");
            end

            if (not EA_StackingItems[EA_playerClass][EA_powerAlert]) then
				if (EA_StackingItems[EA_playerClass][v]) then

	                _,_,_,EA_count,_,_,_,_,_,_,_ = UnitBuff("player", name);

	                local tempCount = EA_StackingItemsCounts[EA_playerClass][v];

	                if (EA_count < tempCount) then
						EA_removeBuffValue(v);
				    end
	            end
            end



            if (EA_AltItems[EA_playerClass][v]) then
				-- Lava Surge = 77762
                -- Lava Burst = 51505

				if (v == 77762) then
                	v = 51505;
                    local EA_start, EA_duration, EA_enabled = GetSpellCooldown(v);
		            if (EA_start > 0 and EA_duration > 1.5) then
                        v = 77762;
                        EA_removeBuffValue(v);
	                end

                    EA_affectingCombat = UnitAffectingCombat("player");
                    if (not EA_affectingCombat) then
                        v = 77762;
                        EA_removeBuffValue(v);
                    end
    			else
                	local EA_usable, _ = IsUsableSpell(v);
                    local EA_start, EA_duration, EA_enabled = GetSpellCooldown(v);
		            if (EA_start > 0 and EA_duration > 1.5) then
                        EA_removeBuffValue(v);
	                end

                    if (not EA_usable) then
    	            	EA_removeBuffValue(v);
	                end
                end
            end

            if (EA_Config.ShowTimer == true) then

                local _,_,_,_,_,_,EA_expirationTime,_,_ = UnitAura("player", name, rank);

                if (EA_expirationTime ~= nil) then
                    local EA_time = 0;

                    EA_time = EA_time + EA_expirationTime;
                    EA_currentTime = GetTime();
                    EA_timeLeft = EA_expirationTime - EA_currentTime;

                    if (EA_timeLeft > 0 and EA_timeLeft < 30) then
                        if (EA_Config.ChangeTimer == true) then
                            timerFontSize = 28;
                            eaf.spellTimer:ClearAllPoints();
                            eaf.spellTimer:SetPoint("CENTER", 0, 0);
                        else
                            timerFontSize = 18;
                            eaf.spellTimer:ClearAllPoints();
                            eaf.spellTimer:SetPoint("TOP", 0, 20);
                        end

                        eaf.spellTimer:SetFont("Fonts\\\FRIZQT__.TTF", timerFontSize, "OUTLINE");
                        eaf.spellTimer:SetFormattedText("%d", EA_timeLeft);
                    end
                end
            else
            	eaf.spellTimer:SetText("");
            end
        end
    end
end


function EA_addBuffValue(EASpellID)
    table.insert(EA_TempBuffsTable, EASpellID);
	EventAlert_PositionFrames();
	EventAlert_DoAlert();

end

function EA_removeBuffValue(EASpellID)

	local f = _G["EAFrame_"..EASpellID];
	f:Hide();

    for i,v in ipairs(EA_TempBuffsTable) do
		if (v == EASpellID) then
			table.remove(EA_TempBuffsTable, i);
		end
	end

	EventAlert_PositionFrames();
	f:SetScript("OnUpdate", nil);

end

function EventAlert_DoAlert()

	if (EA_Config.ShowFlash == true) then
	   UIFrameFadeIn(LowHealthFrame, 1, 0, 1);
	   UIFrameFadeOut(LowHealthFrame, 2, 1, 0);
	end

	if (EA_Config.DoAlertSound == true) then
	   PlaySoundFile(EA_Config.AlertSound);
	end
end

function EventAlert_PositionFrames(event)

	if (EA_Config.ShowFrame == true) then

    	EA_Main_Frame:ClearAllPoints();
   		EA_Main_Frame:SetPoint(EA_Position.Anchor, UIParent, EA_Position.relativePoint, EA_Position.xLoc, EA_Position.yLoc);

		local prevFrame = "EA_Main_Frame";


        for k,v in ipairs(EA_TempBuffsTable) do
            local eaf = _G["EAFrame_"..v];

            if (v == 85247) then
            	_, _, gsiIcon, _, _, _, _, _, _ = GetSpellInfo(15237);
				gsiName, _, _, _, _, _, _, _, _ = GetSpellInfo(v);
			elseif (v == 64385) then
            	_, _, gsiIcon, _, _, _, _, _, _ = GetSpellInfo(v);
				gsiName = "Combo Points";
            else
				gsiName, _, gsiIcon, _, _, _, _, _, _ = GetSpellInfo(v);
            end

        	eaf:ClearAllPoints();

            if (prevFrame == "EA_Main_Frame") then
                eaf:SetPoint("CENTER", prevFrame, "CENTER", 0, 0);
		  	elseif (prevFrame == eaf) then
              	prevFrame = "EA_Main_Frame";
	            eaf:SetPoint("CENTER", prevFrame, "CENTER", 0, 0);
            else
				eaf:SetPoint("CENTER", prevFrame, "CENTER", 100+EA_Position.xOffset, 0+EA_Position.yOffset);
            end

            eaf:SetWidth(EA_Position.IconSize);
			eaf:SetHeight(EA_Position.IconSize);

			eaf:SetBackdrop({bgFile = gsiIcon});

            if (EA_Config.ShowName == true) then
	    		eaf.spellName:SetText(gsiName);
		    else
	    		eaf.spellName:SetText("");
			end


            eaf:SetScript("OnUpdate", EventAlert_OnUpdate);
            prevFrame = eaf;
	    	eaf:Show();
        end
	end
end


function EventAlert_SlashHandler(msg)

    msg = string.lower(msg);

	if (msg == "options" or msg == "opt") then
    	InterfaceOptionsFrame_OpenToCategory(EA_GeneralOptions_Panel);
    elseif (msg == "version" or msg == "ver") then
        InterfaceOptionsFrame_OpenToCategory(EA_About_Panel);
    elseif (msg == "print") then
        EventAlert_PrintTable();
    elseif (msg == "printalts") then
        EventAlert_PrintAltsTable();
    elseif (msg == "debug") then
		if (EA_Config.Debug == true) then
			DEFAULT_CHAT_FRAME:AddMessage("Debugging off");
            EA_Config.Debug = false;
        elseif (EA_Config.Debug == false) then
			DEFAULT_CHAT_FRAME:AddMessage("Debugging on");
        	EA_Config.Debug = true;
        end
	elseif (msg == "clear") then
    	EventAlert_ClearTables();
    else
        DEFAULT_CHAT_FRAME:AddMessage("EventAlert commands (/eventalert or /ea):");
        DEFAULT_CHAT_FRAME:AddMessage("/ea options (/ea opt) - Toggle the options window on or off");
        DEFAULT_CHAT_FRAME:AddMessage("/ea version (/ea ver) - Shows the current version of EventAlert.");
    end

end


-- Just used for debugging.
function EventAlert_PrintTable()
	table.foreach(EA_TempBuffsTable, print)
end

-- Just used for debugging.
function EventAlert_PrintAltsTable()
	table.foreach(EA_PreLoadAlts, print)
end

function EventAlert_ClearTables()
    for i, v in ipairs(EA_TempBuffsTable) do
		local f = _G["EAFrame_"..i];
		f:Hide();
	end
	EA_TempBuffsTable = table.wipe(EA_TempBuffsTable);
end


function pairsByKeys (t, f)
	local a = {}
		for n in pairs(t) do table.insert(a, n) end
		table.sort(a, f)
		local i = 0      -- iterator variable
		local iter = function ()   -- iterator function
			i = i + 1
			if a[i] == nil then return nil
			else return a[i], t[a[i]]
			end
		end
	return iter
end


function EventAlert_VersionCheck()

    if (EA_Config.Version < EA_tempVer) then

        if (EA_Config.Version <= 461) then
        	EventAlert_FunctionOfDoom();
            -- InterfaceOptionsFrame_OpenToCategory(EA_About_Panel);
        else
            EA_Config.Version = EA_tempVer;
            InterfaceOptionsFrame_OpenToCategory(EA_About_Panel)
        end

    end

    if (EA_Config.Version == EA_tempVer) then
		-- print("Doing Nothing");
    end

end


function EventAlert_CreateOptionsPanels()
	-- Create Options Panels inside the addons section of the Blizzard UI.
		EventAlert.panel = CreateFrame( "Frame", "EventAlertPanel", UIParent );
		EventAlert.panel.name = "EventAlert";
        EventAlert.panel.okay = EAOptionsPanelOK;
		InterfaceOptions_AddCategory(EventAlert.panel);

		EAOptionsPanel('EA_GeneralOptions_Panel', 'EventAlert', EA_TITLE_MAINOPTIONS, EA_SUBTEXT_MAINOPTIONS)
		EAOptionsPanel('EA_IconOptions_Panel', 'EventAlert', EA_TITLE_ICONOPTIONS, EA_SUBTEXT_ICONOPTIONS)
		EAOptionsPanel('EA_SoundOptions_Panel', 'EventAlert', EA_TITLE_SOUNDOPTIONS, EA_SUBTEXT_SOUNDOPTIONS)
		EAOptionsPanel('EA_AlertOptions_Panel', 'EventAlert', EA_TITLE_ALERTOPTIONS, EA_SUBTEXT_ALERTOPTIONS)
		EAOptionsPanel('EA_CustomAlertOptions_Panel', 'EventAlert', EA_TITLE_CUSTOMALERTOPTIONS, EA_SUBTEXT_CUSTOMALERTOPTIONS)
		EAOptionsPanel('EA_About_Panel', 'EventAlert', EA_TITLE_ABOUT, EA_SUBTEXT_ABOUT)

		EventAlert_CreateGeneralOptionsFrames();
		EventAlert_CreateIconOptionsFrames();
	    EventAlert_CreateSoundOptionsFrames();
        EventAlert_CreateAlertsOptionsFrames();
        EventAlert_CreateCustomAlertsOptionsFrames();
        EventAlert_CreateAboutFrames();
	-- End Options Panels Creation
end

function EventAlert_LoadSpellArrays()
	if EA_CustomItems == nil then EA_CustomItems = {} end;
	if EA_Items == nil then	EA_Items = {} end;
	if EA_AltItems == nil then EA_AltItems = {}	end;
	if EA_StackingItems == nil then EA_StackingItems = {} end;
	if EA_StackingItemsCounts == nil then EA_StackingItemsCounts = {} end;

	EventAlert_LoadAlerts_Deathknight();
	EventAlert_LoadAlerts_Druid();
	EventAlert_LoadAlerts_Hunter();
	EventAlert_LoadAlerts_Mage();
	EventAlert_LoadAlerts_Paladin();
	EventAlert_LoadAlerts_Priest();
	EventAlert_LoadAlerts_Rogue();
	EventAlert_LoadAlerts_Shaman();
	EventAlert_LoadAlerts_Warlock();
	EventAlert_LoadAlerts_Warrior();
end








-- THE CAKE IS A LIE!
function EventAlert_FunctionOfDoom()
	EA_Config = nil;
	EA_Position = nil;
	EA_Items = nil;
	EA_AltItems = nil;
	EA_StackingItems = nil;
	EA_StackingItemsCounts = nil;

    if (EA_Config == nil) then
	    EA_Config = { DoAlertSound, AlertSound, AlertSoundText, ShowFrame, ShowName, ShowFlash, ShowTimer, ChangeTimer, ShowStacks, AllowESC, ShowSpellInfo, DoDoom, Debug, Version, VersionText };
    end
    if (EA_Position == nil) then
    	EA_Position = { Anchor, LockFrame, IconSize, relativePoint, xLoc, yLoc, xOffset, yOffset };
	end

    if EA_Config.DoAlertSound == nil then EA_Config.DoAlertSound = true end;
    if EA_Config.AlertSound == nil then EA_Config.AlertSound = "Sound\\Spells\\ShaysBell.wav" end;
    if EA_Config.AlertSoundText == nil then EA_Config.AlertSoundText = "Shay's Bell" end;
    if EA_Config.ShowFrame == nil then EA_Config.ShowFrame = true end;
    if EA_Config.ShowName == nil then EA_Config.ShowName = true end;
    if EA_Config.ShowFlash == nil then EA_Config.ShowFlash = false end;
    if EA_Config.ShowTimer == nil then EA_Config.ShowTimer = true end;
    if EA_Config.ChangeTimer == nil then EA_Config.ChangeTimer = false end;
	if EA_Config.ShowStacks == nil then EA_Config.ShowStacks = true end;
    if EA_Config.AllowESC == nil then EA_Config.AllowESC = false end;
    if EA_Config.ShowSpellInfo == nil then EA_Config.ShowSpellInfo = false end;
    if EA_Config.DoDoom == nil then EA_Config.DoDoom = true end;
    if EA_Config.Debug == nil then EA_Config.Debug = false end;
    if EA_Config.Version == nil then EA_Config.Version = EA_tempVer end;
	if EA_Config.VersionText == nil then EA_Config.VersionText = EA_tempVerText end;

    if EA_Position.Anchor == nil then EA_Position.Anchor = "CENTER" end;
    if EA_Position.LockFrame == nil then EA_Position.LockFrame = true end;
    if EA_Position.IconSize == nil then EA_Position.IconSize = 60 end;
    if EA_Position.relativePoint == nil then EA_Position.relativePoint = "CENTER" end;
    if EA_Position.xLoc == nil then EA_Position.xLoc = 0 end;
    if EA_Position.yLoc == nil then EA_Position.yLoc = 0 end;
    if EA_Position.xOffset == nil then EA_Position.xOffset = 0 end;
    if EA_Position.yOffset == nil then EA_Position.yOffset = 0 end;

	EventAlert_LoadSpellArrays();

    local EA_Reset_Text = CreateFrame("Frame", "EA_Reset_Text_Frame", UIParent)
	    EA_Reset_Text = EA_Reset_Text_Frame:CreateFontString(nil, 'ARTWORK');
        EA_Reset_Text:SetFont("Fonts\\FRIZQT__.TTF", 30, "OUTLINE, MONOCHROME")
	  	EA_Reset_Text:SetPoint("TOP", UIParent, "CENTER", 0, 50);
        EA_Reset_Text:SetText("EventAlert has reset all settings to default (except custom spell IDs).\nPlease log out of the game and back in to avoid any LUA errors.\nSorry!  :(");

    print("EventAlert has reset all settings to default (except custom spell IDs).  Please log out of the game and back in to avoid any LUA errors.");
end