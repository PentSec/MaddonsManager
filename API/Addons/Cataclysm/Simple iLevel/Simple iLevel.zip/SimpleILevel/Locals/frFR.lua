local L = LibStub("AceLocale-3.0"):NewLocale("SimpleILevel", "frFR");

if not L then return end

L.core = {
	ageDays = "%s jours", -- Needs review
	ageHours = "%s heures", -- Needs review
	ageMinutes = "%s minutes", -- Needs review
	ageSeconds = "%s secondes", -- Needs review
	desc = "Ajout le iLevel moyen (AiL) à l'infobulle des autres joueurs", -- Needs review
	load = "Chargement v%s", -- Needs review
	minimapClick = "SimpleiLevel - cliquer pour les détails", -- Needs review
	minimapClickDrag = "Cliquer/déplacer pour déplacer l’icône", -- Needs review
	name = "Simple iLevel", -- Needs review
	purgeNotification = "Purge %s personnage du cache", -- Needs review
	purgeNotificationFalse = "Vous n'avez pas une purge auto configurée", -- Needs review
	scoreDesc = "Ceci est le iLevel moyen de votre équipement actuel", -- Needs review
	scoreYour = "Votre AiL est %s", -- Needs review
	slashClear = "Effacement des paramètres", -- Needs review
	slashGetScore = "%s avait un AiL de %s et l'information date de %s", -- Needs review
	slashGetScoreFalse = "Désolé, il y a eu une erreur lors de l'obtention du score de %s", -- Needs review
	slashTargetScore = "%s a un AiL de %s", -- Needs review
	slashTargetScoreFalse = "Désolé, il y a eu une erreur lors de la détermination du score de votre cible", -- Needs review
	ttAdvanced = "%s", -- Needs review
	ttLeft = "iLevel moyen (AiL):", -- Needs review
	options = {
		autoscan = "Scan auto", -- Needs review
		autoscanDesc = "Active/désactive le scan automatique lors de changement dans le groupe/raid", -- Needs review
		clear = "Effacer les paramètres", -- Needs review
		clearDesc = "Effacer tous les paramètres et le cache", -- Needs review
		-- color = "Color Score",
		-- colorDesc = "Color the AiL where appropriate. Disable this if you only want to see white and gray scores.",
		get = "Obtenir le score", -- Needs review
		getDesc = "Obtenir l'AiL à partir d'un nom si présent dans le cache", -- Needs review
		ldb = "Options LDB", -- Needs review
		ldbRefresh = "Taux de rafraichissement", -- Needs review
		ldbRefreshDesc = "A quelles occurrences LDB doit être mis à jour en secondes", -- Needs review
		ldbSource = "Etiquette de la source", -- Needs review
		ldbSourceDesc = "Affiche une étiquette de la source de données for le score LDB", -- Needs review
		ldbText = "Active/désactive LDB Text", -- Needs review
		ldbTextDesc = "Active/désactive LDB, cela va économiser quelques ressources", -- Needs review
		maxAge = "Age maximum du cache", -- Needs review
		maxAgeDesc = "Définir le temps de rafraichissement d'une inspection en minutes", -- Needs review
		minimap = "Afficher le bouton sur la minimap", -- Needs review
		minimapDesc = "Active/désactive l'affichage du bouton sur la minimap", -- Needs review
		-- modules = "Load Modules",
		-- modulesDesc = "For these changes to take effect you need to reload your UI with /rl or /console reloadui.",
		name = "Options générales", -- Needs review
		open = "Ouvrir l'interface des options", -- Needs review
		options = "Options de SiL", -- Needs review
		paperdoll = "Afficher sur la feuille de personnage", -- Needs review
		paperdollDesc = "Affiche votre AiL sur la feuille de personnage dans le panneau des stats", -- Needs review
		purge = "Effacer le cache", -- Needs review
		purgeAuto = "Purger automatiquement le cache", -- Needs review
		purgeAutoDesc = "Purge automatiquement les informations se trouvant dans le cache datant de plus de # jours. 0 pour jamais", -- Needs review
		purgeDesc = "Effacer du cache tous les personnages plus vieux de %s jours", -- Needs review
		purgeError = "Veuillez entrer le nombre de jours", -- Needs review
		target = "Obtenir le score de votre cible", -- Needs review
		targetDesc = "Obtenir l'AiL de votre cible", -- Needs review
		ttAdvanced = "Infobulle avancée", -- Needs review
		ttAdvancedDesc = "Active/désactive l'infobulle avancée incluant le temps", -- Needs review
		-- ttCombat = "Tooltip in Combat",
		-- ttCombatDesc = "Show the SiL information on the tooltip while in combat",
	},
}
L.group = {
	-- addonName = "Simple iLevel - Group",
	-- desc = "View the AiL of everyone in your group",
	-- load = "Group Module Loaded",
	-- name = "SiL Group",
	nameShort = "Groupe", -- Needs review
	outputHeader = "Simple iLevel: moyenne du groupe %s", -- Needs review
	outputNoScore = "%s n'est pas disponible", -- Needs review
	outputRough = "* indique un score aproximatif", -- Needs review
	options = {
		group = "Score du groupe", -- Needs review
		groupDesc = "Affiche le score de votre groupe dans <%s>", -- Needs review
	},
}
L.resil = {
	-- addonName = "Simple iLevel - Resilience",
	-- desc = "Shows the amount of PvP gear other players have equipped in the tooltip",
	-- load = "Resilience Module Loaded",
	-- name = "SiL Resilience",
	-- nameShort = "Resilience",
	-- outputHeader = "Simple iLevel: Group Average PvP Gear %s",
	-- outputNoScore = "%s is not available",
	-- outputRough = "* denotes an approximate score",
	-- ttPaperdoll = "You have %s/%s items with a %s resilience rating.",
	-- ttPaperdollFalse = "You currently do not have any PvP items equiped.",
	options = {
		cinfo = "Affiche sur les fiche personnage", -- Needs review
		-- cinfoDesc = "Shows your SimpleiLevel Resilience score on the stats pane.",
		-- group = "Group PvP Score",
		-- groupDesc = "Prints the PvP Score of your group to <%s>.",
		-- name = "SiL Resilience Options",
		-- pvpDesc = "Displayed the PvP gear of everyone in your group.",
		-- ttType = "Tooltip Type",
		-- ttZero = "Zero Tooltip",
		-- ttZeroDesc = "Shows information in the tooltip even if they have no PvP gear.",
	},
}
L.social = {
	-- addonName = "Simple iLevel - Social",
	-- desc = "Added the AiL to chat windows for various channels",
	-- load = "Social Module Loaded",
	-- name = "SiL Social",
	-- nameShort = "Social",
	options = {
		-- chatEvents = "Show Score On:",
		-- color = "Color Score",
		-- colorDesc = "Color the score in the chat windows.",
		enabled = "Activé", -- Needs review
		-- enabledDesc = "Enable all features or SiL Social.",
		-- name = "SiL Social Options",
	},
}


