local L = LibStub("AceLocale-3.0"):NewLocale("SimpleILevel", "zhCN");

if not L then return end

L.core = {
	ageDays = "%s天", -- Needs review
	ageHours = "%s小时", -- Needs review
	ageMinutes = "%s分钟", -- Needs review
	ageSeconds = "%s秒", -- Needs review
	desc = "提示栏显示其它玩家的平均物品等级", -- Needs review
	load = "载入版本%s", -- Needs review
	minimapClick = "简易物品等级 - 点击取得细节", -- Needs review
	minimapClickDrag = "拖动以迁移图标", -- Needs review
	name = "简易物品等级", -- Needs review
	purgeNotification = "清除缓存内的%s人", -- Needs review
	purgeNotificationFalse = "你并未设置自动清除", -- Needs review
	scoreDesc = "这是您所有已装备物品的平均物品等级。", -- Needs review
	scoreYour = "您的数值 %s", -- Needs review
	slashClear = "清除设置", -- Needs review
	slashGetScore = "%s的平均物品等级为%score（%s前）", -- Needs review
	slashGetScoreFalse = "抱歉，获取%target的数值时发生错误", -- Needs review
	slashTargetScore = "%s的平均物品等级为%s", -- Needs review
	slashTargetScoreFalse = "抱歉，建构数值时发生错误", -- Needs review
	ttAdvanced = "%s前", -- Needs review
	ttLeft = "平均物品等级：", -- Needs review
	options = {
		autoscan = "自动扫描", -- Needs review
		autoscanDesc = "切换自动扫描队伍、团队变化", -- Needs review
		clear = "清除设置", -- Needs review
		clearDesc = "清除所有设置与缓存", -- Needs review
		color = "着色分数", -- Needs review
		-- colorDesc = "Color the AiL where appropriate. Disable this if you only want to see white and gray scores.",
		get = "获取数值", -- Needs review
		getDesc = "获取已记录玩家的平均物品等级", -- Needs review
		ldb = "LDB选项", -- Needs review
		ldbRefresh = "刷新频率", -- Needs review
		ldbRefreshDesc = "LDB将几秒刷新一次", -- Needs review
		ldbSource = "来源标签", -- Needs review
		ldbSourceDesc = "显示LDB数值来源的标签", -- Needs review
		ldbText = "切换LDB文字", -- Needs review
		ldbTextDesc = "切换打開LDB，或可节省些资源", -- Needs review
		maxAge = "最长缓存时间", -- Needs review
		maxAgeDesc = "设置检查间隔时间（分钟）", -- Needs review
		minimap = "显示小地图按钮", -- Needs review
		minimapDesc = "切换显示小地图按钮", -- Needs review
		modules = "载入模块", -- Needs review
		-- modulesDesc = "For these changes to take effect you need to reload your UI with /rl or /console reloadui.",
		name = "一般选项", -- Needs review
		open = "打开选项页面", -- Needs review
		options = "选项", -- Needs review
		paperdoll = "显示于人物信息", -- Needs review
		paperdollDesc = "在人物信息窗口的属性栏显示平均物品等级。", -- Needs review
		purge = "清除缓存", -- Needs review
		purgeAuto = "自动清除缓存", -- Needs review
		purgeAutoDesc = "自动清除#天前的缓存，0为从不清除", -- Needs review
		purgeDesc = "清除所有超过%s天的人物缓存", -- Needs review
		purgeError = "请输入天数", -- Needs review
		target = "获取目标数值", -- Needs review
		targetDesc = "获取目标的平均物品等级", -- Needs review
		ttAdvanced = "高级提示栏", -- Needs review
		ttAdvancedDesc = "切换显示检查间隔时间", -- Needs review
		ttCombat = "战斗中提示信息", -- Needs review
		ttCombatDesc = "当在战斗中时显示SiL提示信息", -- Needs review
	},
}
L.group = {
	addonName = "简易物品等级 - 队伍", -- Needs review
	desc = "查看你队伍中所有人的AiL.", -- Needs review
	load = "队伍模块已加载", -- Needs review
	name = "SiL 队伍", -- Needs review
	nameShort = "队伍", -- Needs review
	outputHeader = "团体平均：%s", -- Needs review
	outputNoScore = "%s (未能取得)", -- Needs review
	outputRough = "* 代表一个近似的评分", -- Needs review
	options = {
		group = "团体数值", -- Needs review
		groupDesc = "发布团体数值到<%s>", -- Needs review
	},
}
L.resil = {
	addonName = "简易物品等级 - 韧性", -- Needs review
	desc = "在提示信息中显示其其他玩家装备的PvP装备数量", -- Needs review
	load = "韧性模块已加载", -- Needs review
	name = "SiL 韧性", -- Needs review
	nameShort = "韧性", -- Needs review
	outputHeader = "Simple iLevel: 队伍平均 PvP 装备 %s", -- Needs review
	outputNoScore = "%s 为不可用", -- Needs review
	outputRough = "* 表示为近似的得分", -- Needs review
	ttPaperdoll = "你已有 %s/%s 件物品和 %s 韧性等级。", -- Needs review
	ttPaperdollFalse = "你当前没有装备任何PvP物品。", -- Needs review
	options = {
		cinfo = "在角色信息上显示", -- Needs review
		cinfoDesc = "在属性面板里显示你的 SimpleiLevel 韧性分数.", -- Needs review
		group = "队伍 PvP 分数", -- Needs review
		-- groupDesc = "Prints the PvP Score of your group to <%s>.",
		name = "SiL 韧性选项", -- Needs review
		pvpDesc = "显示你队伍中所有人的PvP装备.", -- Needs review
		ttType = "提示信息类型", -- Needs review
		ttZero = "零提示信息", -- Needs review
		ttZeroDesc = "如果你没有PvP装备也在提示信息里显示信息.", -- Needs review
	},
}
L.social = {
	addonName = "简易物品等级 - 社交", -- Needs review
	desc = "增加AiL到不同频道的聊天窗体", -- Needs review
	load = "社交模块已加载", -- Needs review
	name = "SiL 社交", -- Needs review
	nameShort = "社交", -- Needs review
	options = {
		chatEvents = "显示分数在:", -- Needs review
		color = "着色分数", -- Needs review
		colorDesc = "在聊天窗体中着色分数.", -- Needs review
		enabled = "已启用", -- Needs review
		enabledDesc = "启用 SiL 社交的所有功能", -- Needs review
		name = "SiL 社交选项", -- Needs review
	},
}


