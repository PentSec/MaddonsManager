local L = LibStub("AceLocale-3.0"):NewLocale("SimpleILevel", "ptBR");

if not L then return end

L.core = {
	ageDays = "%s dias", -- Needs review
	ageHours = "%s horas", -- Needs review
	ageMinutes = "%s minutos", -- Needs review
	ageSeconds = "%s segundos", -- Needs review
	desc = "Incluir iLevel Medio (AiL) na informacção flutuante dos players", -- Needs review
	load = "Lendo v%s", -- Needs review
	minimapClick = "iLevelSimples - Clique para detalhes", -- Needs review
	minimapClickDrag = "Clique e mova o ícone", -- Needs review
	name = "iLevel Simples", -- Needs review
	purgeNotification = "Limpa %s pessoas do seu cache de informações", -- Needs review
	purgeNotificationFalse = "Voçê nao pussui configuração de auto limpeza", -- Needs review
	scoreDesc = "Este é o iLevel medio de seus itens equipados", -- Needs review
	scoreYour = "Seu AiL atrual é %s", -- Needs review
	slashClear = "Limpeza de ajustes", -- Needs review
	slashGetScore = "Este %s possui o seguinte %s baseado em informacoes de %s dias atras", -- Needs review
	slashGetScoreFalse = "Desculpe, houve um erro ao tentar pegar o score deste %s", -- Needs review
	slashTargetScore = "Este %s tem de %s", -- Needs review
	slashTargetScoreFalse = "Desculpe, ouve um erro ao tentar capturar o score deste player", -- Needs review
	ttAdvanced = "%s atras", -- Needs review
	ttLeft = "iLevel Medio:", -- Needs review
	options = {
		autoscan = "Autoscan", -- Needs review
		autoscanDesc = "Faz automaticamente alterações de scan em Paty ou raid ", -- Needs review
		clear = "Limpar Configurações", -- Needs review
		clearDesc = "Limpar as configurações do cache", -- Needs review
		-- color = "Color Score",
		-- colorDesc = "Color the AiL where appropriate. Disable this if you only want to see white and gray scores.",
		get = "Pegando Score", -- Needs review
		getDesc = "Pegar o AiL do nome em cache", -- Needs review
		ldb = "Opções LDB", -- Needs review
		ldbRefresh = "Taxa de atualização", -- Needs review
		ldbRefreshDesc = "Atualizar a LDB a cada quantos segundos", -- Needs review
		ldbSource = "Tamanho do Banco", -- Needs review
		ldbSourceDesc = "Ajuda na descrição do LDB", -- Needs review
		ldbText = "Limpa o tesxo da LDB", -- Needs review
		ldbTextDesc = "Limpa LDB e o desliga, o tornara  com recursos minimos", -- Needs review
		maxAge = "Idade maxima de Cache", -- Needs review
		maxAgeDesc = "Define a quantidade de tempo para fazer nova inspeção", -- Needs review
		minimap = "Mostrar o botao no minimap", -- Needs review
		minimapDesc = "Altera o modo de exibição do botão no minimap", -- Needs review
		-- modules = "Load Modules",
		-- modulesDesc = "For these changes to take effect you need to reload your UI with /rl or /console reloadui.",
		name = "Opçoes gerais", -- Needs review
		open = "Abrui as opções da UI", -- Needs review
		options = "SiL Opções", -- Needs review
		paperdoll = "Mostra as Informações de seu char", -- Needs review
		paperdollDesc = "Mostra seu AiL no painel de visualizacao de seu char", -- Needs review
		purge = "Limpar Cache", -- Needs review
		purgeAuto = "Limpa o Cache automaticamente", -- Needs review
		purgeAutoDesc = "Limpau automaticament e o Cache que possui mais de # dias. 0 é nunca", -- Needs review
		purgeDesc = "Limpar todo cache que possui mais de %s dias", -- Needs review
		purgeError = "Por Favor, entre com  o numero de dias", -- Needs review
		target = "Pega o Score do Target", -- Needs review
		targetDesc = "Verificar AiL do target atual", -- Needs review
		ttAdvanced = "Dicas Avançadas", -- Needs review
		ttAdvancedDesc = "Ferramentas de dicas Avançada", -- Needs review
		-- ttCombat = "Tooltip in Combat",
		-- ttCombatDesc = "Show the SiL information on the tooltip while in combat",
	},
}
L.group = {
	-- addonName = "Simple iLevel - Group",
	-- desc = "View the AiL of everyone in your group",
	-- load = "Group Module Loaded",
	-- name = "SiL Group",
	-- nameShort = "Group",
	outputHeader = "iLevel Simples: Media do Grupo - %s", -- Needs review
	outputNoScore = "%s nao esta disponível", -- Needs review
	outputRough = "* as doações estao por volta da seguinte meta.", -- Needs review
	options = {
		group = "Score do Grupo", -- Needs review
		groupDesc = "Envia o score do seu grupo para <%s>.", -- Needs review
	},
}
L.resil = {
	-- addonName = "Simple iLevel - Resilience",
	-- desc = "Shows the amount of PvP gear other players have equipped in the tooltip",
	-- load = "Resilience Module Loaded",
	-- name = "SiL Resilience",
	-- nameShort = "Resilience",
	-- outputHeader = "Simple iLevel: Group Average PvP Gear %s",
	-- outputNoScore = "%s is not available",
	-- outputRough = "* denotes an approximate score",
	-- ttPaperdoll = "You have %s/%s items with a %s resilience rating.",
	-- ttPaperdollFalse = "You currently do not have any PvP items equiped.",
	options = {
		-- cinfo = "Show on Character Info",
		-- cinfoDesc = "Shows your SimpleiLevel Resilience score on the stats pane.",
		-- group = "Group PvP Score",
		-- groupDesc = "Prints the PvP Score of your group to <%s>.",
		-- name = "SiL Resilience Options",
		-- pvpDesc = "Displayed the PvP gear of everyone in your group.",
		-- ttType = "Tooltip Type",
		-- ttZero = "Zero Tooltip",
		-- ttZeroDesc = "Shows information in the tooltip even if they have no PvP gear.",
	},
}
L.social = {
	-- addonName = "Simple iLevel - Social",
	-- desc = "Added the AiL to chat windows for various channels",
	-- load = "Social Module Loaded",
	-- name = "SiL Social",
	-- nameShort = "Social",
	options = {
		-- chatEvents = "Show Score On:",
		-- color = "Color Score",
		-- colorDesc = "Color the score in the chat windows.",
		-- enabled = "Enabled",
		-- enabledDesc = "Enable all features or SiL Social.",
		-- name = "SiL Social Options",
	},
}


