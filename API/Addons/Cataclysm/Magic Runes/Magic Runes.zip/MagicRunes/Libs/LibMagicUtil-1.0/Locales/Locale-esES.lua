local L = LibStub("AceLocale-3.0"):NewLocale("LibMagicUtil-1.0", "esES")
if not L then return end

-- To help localize LibMagicUtil-1.0 please enter phrase translations on the
-- following URL:
-- http://www.wowace.com/projects/libmagicutil-10/localization/
-- This file should not be edited manually!

-- L["Background Color"] = ""
-- L["Background Frame"] = ""
-- L["Background Texture"] = ""
-- L["Bar Height"] = ""
-- L["Bar Scale"] = ""
-- L["Bar Size"] = ""
-- L["Bar Spacing"] = ""
-- L["Bar Width"] = ""
-- L["Border color"] = ""
-- L["Border Texture"] = ""
-- L["Edge size"] = ""
-- L["Maximum number of bars"] = ""
-- L["Number of pixels to insert between the background frame edge and the content."] = ""
-- L["Padding"] = ""
-- L["The background texture used for the background frame."] = ""
-- L["The border texture used for the background frame."] = ""
-- L["The size in pixels of the background tiles."] = ""
-- L["The space in pixels between each bar."] = ""
-- L["Tile Background"] = ""
-- L["Tile Size"] = ""
-- L["Whether or not to tile the background texture."] = ""
-- L["Width of the border."] = ""

