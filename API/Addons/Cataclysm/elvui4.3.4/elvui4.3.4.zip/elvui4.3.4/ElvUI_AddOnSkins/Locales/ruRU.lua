--Файл локализации для ruRU
local L = ElvUI[1].Libs.ACL:NewLocale("ElvUI", "ruRU")
if not L then return end

L["AddOn Skins"] = "Скины аддонов"
L["AuraBar Backdrop"] = true
L["Bar Height"] = true
L["Double"] = "Двойной"
L["Embed Below Top Tab"] = "Не перекрывать панель вкладок"
L["Embed into Right Chat Panel"] = true
L["Embed Left Window Width"] = "Ширина левого встроенного окна"
L["Embed Settings"] = "Настройки Встраивания"
L["Embed Type"] = "Тип встраивания"
L["Gloss Template"] = true
L["Hide Chat Frame"] = "Скрыть фрейм чата"
L["Left Panel"] = "Левое окно"
L["Right Panel"] = "Правое окно"
L["Settings to control Embedded AddOns\n\nAvailable Embeds: Omen | Skada | Recount"] = "Настройки для конктроля встроенных аддонов\n\nДоступны для встраивания: Omen | Skada | Recount"
L["Single"] = "Одинарный"
L["Supported AddOns"] = true
L["Template"] = true
L["Title Backdrop"] = true
L["Title Gloss Template"] = true
L["Title Template"] = true
L["WeakAura Cooldowns"] = true