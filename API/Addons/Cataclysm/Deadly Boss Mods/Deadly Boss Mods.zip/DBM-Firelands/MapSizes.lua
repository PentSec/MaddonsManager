DBM:RegisterMapSize("Firelands", 
	1, 1587.49993896484, 1058.3332824707, 	-- The Firelands
	2, 375.0, 250.0,						-- The Anvil of Conflagration
	3, 1440.0, 960)							-- Sulfuron Keep