DBM:RegisterMapSize("WellofEternity",
	0, 1252.0830078125, 833.3332519532--Not sure if floor is 0 or 1, will need to verify
)