DBM:RegisterMapSize("TheStonecore",
	1, 1317.12899780273, 878.086975097656
)