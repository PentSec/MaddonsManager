DBM:RegisterMapSize("BlackwingDescent", 
	1, 849.69401550293, 566.462341070175,	-- floor 1
	2, 999.692977905273, 666.462005615234)	-- floor 2