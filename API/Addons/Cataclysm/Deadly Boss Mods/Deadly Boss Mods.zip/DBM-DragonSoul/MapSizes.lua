DBM:RegisterMapSize("DragonSoul", 
	1, 3106.70849609375,2063.065185546875,	-- Dragonblight
	2, 397.5,265.0,							-- Maw of Go'rath
	3, 427.5,285.0,							-- Maw of Shu'ma
	4, 185.19921875, 123.466796875,			-- Eye of Eternity
--	5, 1.5, 1,								-- Gunship (It doesn't actually have usuable coords, useless map data)
--	6, 1.5, 1,								-- Spine (Same probelm as above)
	7, 1108.3515625, 738.900390625			-- Maelstrom
)