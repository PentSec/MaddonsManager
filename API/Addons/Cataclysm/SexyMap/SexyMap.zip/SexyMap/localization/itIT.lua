
if GetLocale() ~= "itIT" then return end
local _, sm = ...
local L = sm.L


