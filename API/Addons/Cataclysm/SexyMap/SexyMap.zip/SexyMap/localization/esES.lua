
if GetLocale() ~= "esES" then return end
local _, sm = ...
local L = sm.L


