
if GetLocale() ~= "ptBR" then return end
local _, sm = ...
local L = sm.L


