
if GetLocale() ~= "ruRU" then return end
local _, sm = ...
local L = sm.L


