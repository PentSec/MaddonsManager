
if GetLocale() ~= "zhTW" then return end
local _, sm = ...
local L = sm.L


