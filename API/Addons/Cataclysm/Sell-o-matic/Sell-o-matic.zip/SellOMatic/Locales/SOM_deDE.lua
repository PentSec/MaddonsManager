local L = LibStub("AceLocale-3.0"):NewLocale("SellOMatic", "deDE")
if not L then return end

L["item(s) sold"] = "Gegenstände verkauft"
-- L["Selling"] = ""
-- L["You've earned"] = ""

