local L = LibStub("AceLocale-3.0"):NewLocale("SellOMatic", "esES")
if not L then return end

L["item(s) sold"] = "objeto(s) vendido(s)"
L["Selling"] = "Vendiendo"
L["You've earned"] = "Has ganado"

