local L = LibStub("AceLocale-3.0"):NewLocale("SellOMatic", "zhTW")
if not L then return end

L["item(s) sold"] = "個物品被賣掉了"
-- L["Selling"] = ""
-- L["You've earned"] = ""

