local debug = false;
--[===[@debug@
debug = true;
--@end-debug@]===]

local L = LibStub("AceLocale-3.0"):NewLocale("SellOMatic", "enUS", true, debug);

L["item(s) sold"] = true
L["Selling"] = true
L["You've earned"] = true

