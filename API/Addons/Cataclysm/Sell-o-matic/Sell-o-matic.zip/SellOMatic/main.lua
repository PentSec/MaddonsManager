SellOMatic = LibStub("AceAddon-3.0"):NewAddon("SellOMatic", "AceEvent-3.0", "AceConsole-3.0");
local L = LibStub("AceLocale-3.0"):GetLocale("SellOMatic");

-- Addon variables
local junk_items, SOMNone, profit;
-- Addon junk variables
local bag, slot, name, itemName, itemLink, itemRarity, itemSellPrice, itemStackCount, num;

function SellOMatic:OnInitialize()
	SellOMatic:Create_SOMNone();
end;

function SellOMatic:OnEnable()
	SellOMatic:RegisterEvent("MERCHANT_SHOW");
	SellOMatic:RegisterEvent("MERCHANT_CLOSED");
	SellButton:Hide();
end;

function SellOMatic:OnDisable()
	SellOMatic:UnregisterEvent("MERCHANT_SHOW");
	SellOMatic:UnregisterEvent("MERCHANT_CLOSED");
end;

function SellOMatic:MERCHANT_SHOW()
	SellButton:Show();
	junk_items = SellOMatic:ScanJunk();
	if junk_items == 0 then SOMNone:Show() end;
end;

function SellOMatic:MERCHANT_CLOSED()
	SellButton:Hide();
	SOMNone:Hide();
end;

function SellOMatic:Sell()
	junk_items = SellOMatic:ScanJunk();
	if junk_items ~= 0 then
		SellOMatic:SellJunk();
		SOMNone:Show();
	end;
end;

function SellOMatic:ScanJunk()
	num = 0;
	for bag = 0,NUM_BAG_SLOTS,1 do
		for slot = 1,GetContainerNumSlots(bag),1 do
			name = GetContainerItemLink(bag,slot);
			if name ~= nil then
				_, _, itemRarity, _, _, _, _, _, _, _, _ = GetItemInfo(name);
				if itemRarity == 0 then
					num = num + 1;
				end;
			end;
		end;
	end;
	return num;
end;

function SellOMatic:SellJunk()
	num = 0;
	profit = 0;
	for bag = 0,NUM_BAG_SLOTS,1 do
		for slot = 1,GetContainerNumSlots(bag),1 do
			name = GetContainerItemLink(bag,slot);
			if name ~= nil then
				itemName, itemLink, itemRarity, _, _, _, _, itemStackCount, _, _, itemSellPrice = GetItemInfo(name);
				if itemRarity == 0 then
					if itemStackCount > 1 then itemSellPrice = itemSellPrice * GetItemCount(itemName) end;
					profit = profit + itemSellPrice;
					num = num + 1;
					UseContainerItem(bag,slot);
					SellOMatic:Print(L["Selling"]..": "..itemLink);
				end;
			end;
		end;
	end;
	SellOMatic:Print(num.." "..L["item(s) sold"]);
	SellOMatic:Print(L["You've earned"]..": "..GetCoinText(profit," "));
end;

function SellOMatic:ShowProfit()
	profit = 0;
	for bag = 0,NUM_BAG_SLOTS,1 do
		for slot = 1,GetContainerNumSlots(bag),1 do
			name = GetContainerItemLink(bag,slot);
			if name ~= nil then
				itemName, _, itemRarity, _, _, _, _, itemStackCount, _, _, itemSellPrice = GetItemInfo(name);
				if itemRarity == 0 then
					if itemStackCount > 1 then itemSellPrice = itemSellPrice * GetItemCount(itemName) end;
					profit = profit + itemSellPrice;
				end;
			end;
		end;
	end;
	return profit;
end;

function SellOMatic:Create_SOMNone()
	SOMNone = CreateFrame("Frame","SOMNone",SellButton);
	SOMNone:ClearAllPoints();
	SOMNone:SetPoint("TOPRIGHT",MerchantFrame,"TOPRIGHT",-43,-41);
	SOMNone:SetHeight(30);
	SOMNone:SetWidth(30);
	SOMNone.texture = SOMNone:CreateTexture()
	SOMNone.texture:SetAllPoints(SOMNone);
	SOMNone.texture:SetTexture(0.3,0.3,0.3,0.7);
	SOMNone:Hide();
end;

function SellOMatic:SOMButtonTooltip_Show()
	GameTooltip_SetDefaultAnchor(GameTooltip,MerchantFrame);
	GameTooltip:ClearAllPoints();
	GameTooltip:SetPoint("TOPLEFT",MerchantFrame,"TOPRIGHT",-30,-40);
	GameTooltip:SetText(GetCoinTextureString(SellOMatic:ShowProfit()),1,1,1);
	GameTooltip:Show();
end;

function SellOMatic:SOMButtonTooltip_Hide()
	GameTooltip:Hide();
end;
