local n=MogIt.base.AddNPC
n(58632,"Armsmaster Harlan")
n(9056,"Fineous Darkvire")