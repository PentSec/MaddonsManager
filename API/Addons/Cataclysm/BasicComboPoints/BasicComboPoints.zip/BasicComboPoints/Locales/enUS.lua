local L = LibStub("AceLocale-3.0"):NewLocale("BasicComboPoints","enUS",true)

L["desc"] = "BasicComboPoints is a numerical display of your current combo points, with extras such as a font and color chooser."

L["Lock the points frame in its current location."] = true

L["Font"] = true
L["Apply the font you wish to use for your Combo Points."] = true

L["Apply the color you wish to use for your Combo Points."] = true

L["Apply the %s you wish to use for Combo Point %d."] = true

L["Apply the size you wish to use for your Combo Points."] = true

L["Apply a shadow to your text."] = true

L["Outline"] = true
L["Apply a outline to your text."] = true
L["Thick Outline"] = true
