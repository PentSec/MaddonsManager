﻿if GetLocale() == "esMX" then

function psealocale()

icravalitriayell1			= "He abierto un portal al Sueño. Vuestra salvación está dentro, héroes..."
icravalitriayell2			= "¡ESTOY RENOVADA! Ysera haz que estas asquerosas criaturas descansen"
whrabrann				= "Brann Barbabronce"

end

end