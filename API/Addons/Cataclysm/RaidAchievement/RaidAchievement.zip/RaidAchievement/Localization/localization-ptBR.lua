﻿if GetLocale() == "ptBR" then

function psealocale()



end

end