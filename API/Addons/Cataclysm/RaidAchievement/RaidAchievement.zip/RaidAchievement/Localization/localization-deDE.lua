﻿if GetLocale() == "deDE" then


function psealocale()


	PSFeaserver = "ru-Gordunni"
	charakillintime = "Voraussetzungen erfuellt! Toete den Boss mit 3 Stacks Blitzladung (30 Sekunden uebrig)!"
	charakillintime2 = "Voraussetzung erfuellt! Toetet den Boss wenn er den Buff hat (20 Sek uebrig)!"
	-- chhrbrannyell = ""
	chratitle = "   Cataclysm Heroisch"
	crraraidpartachloc1 = "Statischer Schock!"
	crraraidpartachloc2 = "Giftbombe!"
	crraraidpartachloc3 = "Arkaner Annihilator!"
	crraraidpartachloc4 = "Flammenwerfer!"
	crratitle = "    Cataclysm Raids"
	icravalitriayell1 = "Ich habe ein Portal in den Traum geöffnet. Darin liegt Eure Erlösung, Helden..."
	icravalitriayell2 = "ICH BIN GEHEILT! Ysera, erlaubt mir diese üblen Kreaturen zu beseitigen!"
	nrallbuttonmaint = "Zonenliste"
	nrallbuttontak = "Taktiken"
	-- nxraonyemote = ""
	-- nxraonyxiab = ""
	psbuttonoff = "Stop"
	psbuttonon = "Start"
	pseaaddonmy = "AddOn"
	pseaaddonoff = "AUS"
	pseaaddonok = "Okay"
	pseaaddonon = "Addon aktivieren"
	pseaaddonon2 = "AN"
	pseachangeall = "Umkehren"
	pseachatlist1 = "raid"
	pseachatlist2 = "Raid Warnung"
	pseachatlist3 = "Offizier"
	pseachatlist4 = "Gruppe"
	pseachatlist5 = "Gilde"
	pseachatlist6 = "Sagen"
	pseachatlist7 = "Schreien"
	pseachatlist8 = "An sich selbst"
	pseadisableall = "Alles deaktivieren"
	pseaenableall = "Alles aktivieren"
	psealeftmenu1 = "Addon"
	psealeftmenu11 = "Verfolgung nach Fehlschlag"
	psealeftmenu3 = "Naxxramas"
	psealeftmenu31 = "Naxxramas + andere Minischlachtzuege aus WotLK"
	psealeftmenu4 = "WotLK Instanzen"
	psealeftmenu5 = "Ulduar"
	psealeftmenu6 = "Eiskronenzitadelle"
	psealeftmenucata = "Cata Heroisch"
	psealeftmenucata2 = "Cata Raids"
	pseamanyachtitle = "    Erfolg nach einem Fehlschlag weiterhin beobachten"
	pseamoduleload = "Geladene Module:"
	pseamodulenotload = "Fehler beim Laden der Module:"
	pseapartfailedloc = "Teil ist fehlgeschlagen!"
	pseapsaddonanet = "Fehler! Das Addon 'PhoenixStyle' ist nicht installiert."
	pseapsaddonanet2 = "Sie koennen es auf www.ps-addon.com runterladen."
	pseareports = "- Kanal in welchem die Warnungen ausgegeben werden"
	pseashownames = "Den Grund (Spielername etc.) anzeigen wieso das Achievement nicht geschafft wurde"
	pseashowveren = "Berichten, wenn eine aktuellere Version in Gruppe/Schlachtzug gefunden wurde"
	pseasoundoptions1 = "Spiele Sound wenn Erfolg fehlgeschlagen"
	pseasoundoptions2 = "Spiele Sound wenn Voraussetzungen erfuellt"
	pseasoundoptions3 = "Spiele Sound wenn ich den Erfolg benoetige"
	pseasoundoptions6 = "Master Modus, spiele Sound wenn In-Game Sound deaktiviert ist" -- Needs review
	pseatreb2 = "Anforderungen erfuellt! Vernichtet den Boss jetzt!"
	pseatreb4 = "fehlgeschlagen!"
	pseatrebulda2 = "Toetet das letzte Monster und danach den Boss!"
	pseauierror = "    Fehler!"
	pseauierroraddonoff = "Fehler! Das Addon ist deaktiviert - dieses Modul ist nicht verfuegbar!"
	pseauinomodule1 = "    Fehler! Modul ist nicht installiert!"
	pseauinomodule2 = "Fehler! Ausgewaehltes Modul ist nicht installiert!"
	psmoduletxtoff = "Modul ist deaktiviert"
	psmoduletxton = "Modul ist aktiviert"
	psoldvertxt = "(veraltet)"
	racolor1 = "rot" -- Needs review
	racolor2 = "schwarz" -- Needs review
	racolor3 = "gelb" -- Needs review
	racolor5 = "gruen" -- Needs review
	racolor6 = "lila" -- Needs review
	-- racolorcomb = ""
	-- radeathwingemote1 = ""
	-- radeathwingemote2 = ""
	raiccof = "von"
	raiccused = "betreten"
	ramaintrackingtitle = "Verfolgung"
	ramanyachtitinfo = "Wenn ein Erfolg fehlschlaegt ist seine beobachtung bist zum Kampfende gesperrt. Dieses Modul setzt die Sperre zurueck. Dies erfolgt in"
	ramanyachtitinfo2 = "nach der Benachrichtigung. Lege die Anzahl der Zuruecksetzungen pro Kampf fest und druecke auf 'Start'. Dieses Modul wird nach dem Logout automatisch deaktiviert."
	ramanyachtitinfoq = "Zuruecksetzung erfolgt "
	ramanyachtitinfoq2 = "mal in diesem Kampf. Du kannst das hier aendern:"
	raminibuttset = "Minimap Button anzeigen"
	ramodulnotblock = "die Ueberpruefung wird nicht geblockt"
	ranewversfound = "|cff00ff00Achtung!|r Es wurde eine neuere Version des Addons |cff00ff00'RaidAchievement'|r gefunden. Es wird empfohlen das Addon ueber www.ps-addon.com zu aktualisieren."
	rasec = "sek."
	ravalitnottrack = "keine Verfolgung im heroischen Modus durch das Addon"
	ut_3 = "Hauptoptionen" -- Needs review
	whraaddkilled1 = "Mob wurde getoetet!"
	whraaddkilled2 = "wird nicht erfuellt, wenn der Boss jetzt getoetet wird!"
	whrabrann = "Brann Bronzebart"
	-- whrabrannemo = ""
	-- whrabrannemo2 = ""
	-- whragundemo = ""




end





end