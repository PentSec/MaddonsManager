﻿if GetLocale() == "ptBR" then


function iclllocaleui()



end


end