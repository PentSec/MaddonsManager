﻿if GetLocale() == "koKR" then


function iclllocaleui()



end


end