﻿if GetLocale() == "esMX" then



function iclllocaleui()



end


end