﻿if GetLocale() == "esES" then


function iclllocaleui()



end


end