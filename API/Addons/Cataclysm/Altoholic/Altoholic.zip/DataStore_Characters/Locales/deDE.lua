local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Characters", "deDE" )

if not L then return end


