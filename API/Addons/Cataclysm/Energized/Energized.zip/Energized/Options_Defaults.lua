if not Energized then return end
local E = Energized
local L = LibStub("AceLocale-3.0"):GetLocale("Energized")


function E:PrepareDefaults()

	self.defaults = {
		profile = {
			minimap = { hide = true },

			enableSolo = false,
			enableParty = false,
			enableBattleground = false,
			enableArena = false,
			enableRaid = true,

			lowWarn = true,
			itemWarn = true,
			equippedWarn = true,
			petBuffs = E.isPetClass,
			weaponBuffs = true,
			inCombatScan = true,
			scanThrottle = 3.0,

			iconSet = "Default",
			feedText = 3,
			recentCaster = 3,
			showYourselfAsRecentCaster = true,
			hideTime = 10,
			subtipAnchor = 2,
			showHint = true,
			showZeroIssuesMessage = false,

			enableReporting = true,
			reportPetIssues = false,
			reportUnexpected = false,

			minDurability = .10,
			petMode = "NONE",
			
			hunterPetFed = true,
			
			rogueThrownEnchant = true,

			warriorStance = true,
			warriorVigilance = true,
			
			warlockDarkIntent = true,
			
			doNotEquip = {
				-- Fishing items
				[44050] = true,
				[19970] = true,
				[45991] = true,
				[50287] = true,
				[45992] = true,
				[45858] = true,
				[19972] = true,
				[19022] = true,
				[19969] = true,
				[25978] = true,
				[6365] = true,
				[33820] = true,
				[6397] = true,
				[12225] = true,
				[6366] = true,
				[6256] = true,
				[58119] = true, -- Cata starts here
				[46337] = true,
				-- Chef's Hat
				[46349] = true,
				-- Riding crops
				[25653] = true,
				[32863] = true,
				[11122] = true,
			},
			
			groups = {
			 ["**"] = {
					name = L["Unknown"],
					me = "EXPECTED",
					pet = "EXPECTED",
					when = "ALWAYS",
					report = true,
			  items = {
						["*"] = {
							mode = "EXACT",
							value = "",
							warn = 300,
							partyFormat = "ANY",
							difficulty = "ANY",
							quantity = 1,
							talentTree = 0,
							talentWho = "ANYONE",
							priorityMe = "0",
							priorityPet = "0",
							mountMode = "NONE",
							enableSolo = true,
							fromPet = false,
						},
					},
				},

			},
		},
	} -- self.defaults



-------------------------------------------------------------------------------------------------------------------------------------------------
-- CLASS RULE GROUPS ----------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------
	
-- COMMON ---------------------------------------------------------------------------------------------------------------------------------------

	-- Well Fed
	table.insert(self.defaults.profile.groups, {
		name = GetSpellInfo(57399),
		report = false,
		items = {
			{ id = "fed", type = "CONSUMABLE", value = "\"57399\"", partyFormat = "ANY_RAID", enableSolo = false },
		},
	})

	-- Flask/Elixir
	table.insert(self.defaults.profile.groups, {
		name = L["Flask/Elixir"],
		report = false,
		pet = "NONE",
		items = {--                                                                                                           |Cata starts here
			{ id = "flask", type = "CONSUMABLE", value = "\"53760\",\"54212\",\"53758\",\"53755\",\"67019\",\"62380\",\"53752\",\"79637\",\"92679\",\"94160\",\"79469\",\"79472\",\"79470\",\"79471\"", partyFormat = "ANY_RAID", enableSolo = false },
			--                                                                                                                                                                                                              |Cata starts here
			{ id = "elixir", type = "CONSUMABLE", value = "\"60340\",\"60345\",\"60341\",\"60344\",\"60346\",\"28497\",\"60343\",\"53751\",\"53764\",\"53748\",\"60347\",\"53763\",\"53747\",\"53749\",\"33721\",\"53746\",\"79480\",\"79481\",\"79632\",\"79477\",\"79635\",\"79474\",\"79468\",\"79631\"", partyFormat = "ANY_RAID", enableSolo = false },
		},
	})

	-- + Stats/Resistances
	table.insert(self.defaults.profile.groups, {
		name = L["BoK/MotW"],
		items = {
			{ type = "BUFF", value = "\"1126\"", class = "DRUID" }, -- Mark of the Wild
			{ id = "BoK", type = "BUFF", value = "\"20217\"", class = "PALADIN" }, -- Blessing of Kings
			{ type = "CONSUMABLE", value = "\"69378\"", partyFormat = "ANY_RAID", enableSolo = false }, -- Blessing of Forgotten Kings
			--{ type = "CONSUMABLE", value = "\"69381\"" }, -- Drums of the Wild [appears to be removed in cata]
			{ type = "BUFF", value = "\"90363\"", class = "HUNTER", fromPet = true, mountMode = "NOT_MOUNTED" }, -- Embrace of the Shale Spider (BM/Shale Spider)
		},
	})

	-- Prayer of Fortitude
	table.insert(self.defaults.profile.groups, {
		name = GetSpellInfo(21562),
		items = {
			{ type = "BUFF", value = "\"21562\"", class = "PRIEST" }, -- Power Word: Fortitude
			{ type = "CONSUMABLE", value = "\"69377\"", partyFormat = "ANY_RAID", enableSolo = false }, -- Runescroll of Fortitude
			{ type = "BUFF", value = "\"6307\"", class = "WARLOCK", fromPet = true, mountMode = "NOT_MOUNTED" }, -- Blood Pact (Destruction/Imp)
			{ type = "BUFF", value = "\"90364\"", class = "HUNTER", fromPet = true, mountMode = "NOT_MOUNTED" }, -- Qiraji Fortitude (BM/Silithid)
		},
	})

	-- Arcane Intellect
	table.insert(self.defaults.profile.groups, {
		name = GetSpellInfo(39235),
		pet = "NONE",
		items = {
			{ id = "ai", type = "BUFF", value = "\"39235\",\"1459\",\"61316\"", class = "MAGE" }, -- Arcane Intellect, Arcane Brilliance, Dalaran Brilliance
			{ type = "BUFF", value = "\"54424\"", class = "WARLOCK", fromPet = true, mountMode = "NOT_MOUNTED" }, -- Fel Intelligence (Affliction/Felhunter)
		},
	})

	-- Crusader Aura
	table.insert(self.defaults.profile.groups, {
		name = GetSpellInfo(32223),
		me = "UNEXPECTED",
		pet = "UNEXPECTED",
		items = {
			{ type = "BUFF", value = "\"32223\"", class = "PALADIN", mountMode = "NOT_MOUNTED" }, -- Crusader Aura
		},
	})

	-- Aspect of the Pack
	table.insert(self.defaults.profile.groups, {
		name = GetSpellInfo(13159),
		me = "UNEXPECTED",
		pet = "UNEXPECTED",
		items = {
			{ type = "BUFF", value = "\"13159\"", class = "HUNTER" }, -- Aspect of the Pack
		},
	})
	
	-- + Mana Regen
	table.insert(self.defaults.profile.groups, {
		name = L["BoM (Mana Regen)"],
		items = {
			{ id = "mp5", type = "BUFF", value = "\"19740\"", class = "PALADIN", }, -- Blessing of Might
			{ type = "BUFF", value = "\"54424\"", class = "WARLOCK", fromPet = true, mountMode = "NOT_MOUNTED" }, -- Fel Intelligence (Affliction/Felhunter)
		},
	})

	-- + Attack Power
	table.insert(self.defaults.profile.groups, {
		name = L["+ Attack Power"],
		items = {
			{ id = "tsa", type = "BUFF", value = "\"19506\"", class = "HUNTER", talentTree = 2, talentIndex = 11 }, -- Trueshot Aura
			{ type = "BUFF", value = "\"30802\"", class = "SHAMAN", talentTree = 2, talentIndex = 16 }, -- Unleashed Rage
			{ type = "BUFF", value = "\"53138\"", class = "DEATHKNIGHT", talentTree = 1, talentIndex = 11 }, -- Abomination's Might
			{ type = "BUFF", value = "\"19740\"", class = "PALADIN", }, -- Blessing of Might
			--{ type = "BUFF", value = "\"47436\"", class = "WARRIOR" }, -- Battle Shout
		},
	})
	
	-- Healthstone
	table.insert(self.defaults.profile.groups, {
		name = L["Healthstone"],
		report = false,
		pet = "NONE",
		items = {
			{ id = "hs", type = "ITEM", value = "\"5512\"", partyFormat = "ANY_RAID", class = "WARLOCK", enableSolo = false },
		},
	})

-- HUNTER ---------------------------------------------------------------------------------------------------------------------------------------

	-- Aspect of the Cheetah
	table.insert(self.defaults.profile.groups, {
		name = GetSpellInfo(5118),
		hidden = true,
		me = "UNEXPECTED",
		pet = "NONE",
		report = false,
		items = {
			{ id = "aotc", type = "BUFF", value = "\"5118\"", class = "HUNTER" }, -- Aspect of the Cheetah
		},
	})
	
	-- Aspect
	table.insert(self.defaults.profile.groups, {
		name = L["Aspect"],
		hidden = true,
		pet = "NONE",
		report = false,
		items = {-- Hawk, Fox, Wild
			{ id = "aspect", type = "BUFF", value = "\"13165\",\"82661\",\"20043\"", class = "HUNTER", mountMode = "NOT_MOUNTED" },
		},
	})

-- PALADIN --------------------------------------------------------------------------------------------------------------------------------------

	-- Righteous Fury
	table.insert(self.defaults.profile.groups, {
		name = GetSpellInfo(25780),
		hidden = true,
		report = false,
		when = "WHEN_TANK",
		items = {
			{ id = "rf", type = "BUFF", value = "\"25780\"", class = "PALADIN" },
		},
	})
	
	-- Aura
	table.insert(self.defaults.profile.groups, {
		name = L["Aura"],
		hidden = true,
		report = false,
		items = {-- Devotion, Resistance, Concentration, Retribution
			{ id = "aura", type = "BUFF", value = "\"465\",\"19891\",\"19746\",\"7294\"", class = "PALADIN", mountMode = "NOT_MOUNTED" },
		},
	})
	
	-- Seal
 table.insert(self.defaults.profile.groups, {
  name = L["Seal"],
  hidden = true,
  report = false,
  items = {-- Righteousness, Justice, Insight, Truth
   { id = "seal", type = "BUFF", value = "\"20154\",\"20164\",\"20165\",\"31801\"", class = "PALADIN"},
  },
 })

-- MAGE -----------------------------------------------------------------------------------------------------------------------------------------

	-- Armor
	table.insert(self.defaults.profile.groups, {
		name = L["Mage Armor"],
		hidden = true,
		report = false,
		items = {
			{ id = "magearmor", type = "BUFF", value = "\"6117\",\"30482\",\"7302\"", class = "MAGE" },
		},
	})
	
	-- Mana Gem
	table.insert(self.defaults.profile.groups, {
		name = L["Mana Gem"],
		hidden = true,
		report = false,
		items = {
			{ id = "managem", type = "ITEM", value = "\"36799\",\"33312\",\"5514\",\"5513\",\"8007\",\"8008\",\"22044\"" },
		},
	})

-- PRIEST ---------------------------------------------------------------------------------------------------------------------------------------

	-- Inner Fire
	table.insert(self.defaults.profile.groups, {
		name = GetSpellInfo(588),
		hidden = true,
		report = false,
		items = {
			{ id = "innerfire", type = "BUFF", value = "\"588\"", class = "PRIEST" },
		},
	})

-- SHAMAN ---------------------------------------------------------------------------------------------------------------------------------------

	-- Elemental Shield
	table.insert(self.defaults.profile.groups, {
		name = L["Elemental Shield"],
		hidden = true,
		report = false,
		items = {
			{ id = "elementalshield", type = "BUFF", value = "\"324\",\"52127\",\"974\"", class = "SHAMAN" },
		},
	})

-- WARLOCK --------------------------------------------------------------------------------------------------------------------------------------

	-- Armor
	table.insert(self.defaults.profile.groups, {
		name = L["Warlock Armor"],
		pet = "NONE",
		hidden = true,
		report = false,
		items = {
			{ id = "warlockarmor", type = "BUFF", value = "\"28176\",\"687\"", class = "WARLOCK" },
		},
	})

	-- Soul Link
	table.insert(self.defaults.profile.groups, {
		name = GetSpellInfo(19028),
		pet = "NONE",
		hidden = true,
		report = false,
		items = {
			{ id = "soullink", type = "BUFF", value = "\"19028\"", class = "WARLOCK", mountMode = "NOT_MOUNTED" },
		},
	})

-- WARRIOR --------------------------------------------------------------------------------------------------------------------------------------

-- Gets no lovin'

-- DEATH KNIGHT ---------------------------------------------------------------------------------------------------------------------------------

	-- Presence
	table.insert(self.defaults.profile.groups, {
		name = L["Presence"],
		hidden = true,
		report = false,
		pet = "NONE",
		items = {
			{ id = "presence", type = "BUFF", value = "\"48263\",\"48266\",\"48265\"", class = "DEATHKNIGHT" },
		},
	})

	-- Blood Presence
	table.insert(self.defaults.profile.groups, {
		name = GetSpellInfo(48263),
		hidden = true,
		report = false,
		pet = "NONE",
		when = "WHEN_TANK",
		items = {
			{ id = "bloodpresence", type = "BUFF", value = "\"48263\"", class = "DEATHKNIGHT" },
		},
	})

	-- Bone Shield
	table.insert(self.defaults.profile.groups, {
		name = GetSpellInfo(49222),
		hidden = true,
		report = false,
		pet = "NONE",
		items = {
			{ id = "boneshield", type = "BUFF", value = "\"49222\"", class = "DEATHKNIGHT", talentTree = 1, talentIndex = 9, talentWho = "ME", warn = 30, mountMode = "NOT_MOUNTED" },
		},
	})

-------------------------------------------------------------------------------------------------------------------------------------------------

	self.PrepareDefaults = nil
	classValue = nil

end


function E:FindDefaultItem(itemId)
	for k, v in pairs(self.defaults.profile.groups) do
		for kk, vv in pairs(v.items) do
			if vv.id == itemId then
				return vv, v
			end
		end
	end
	return {}, {}
end


local function turnOff(id)
	select(2, E:FindDefaultItem(id)).me = "NONE"
	select(2, E:FindDefaultItem(id)).pet = "NONE"
end


local function unhide(id)
	select(2, E:FindDefaultItem(id)).hidden = false
end

local function hide(id)
	select(2, E:FindDefaultItem(id)).hidden = true
end


function E:CheckForPetClass()
 -- This function is temporarily hacked in order to turn off
 -- pet buff checks for everyone in 4.0. We'll go through and
 -- actually strip out the buff checks later
	self.isPetClass = false
	local c = self.class
	self.shouldHavePet = ((c == "HUNTER" or c == "WARLOCK") or (c == "DEATHKNIGHT" and select(5, GetTalentTabInfo(3)) >= 31))
end


function E:PrepareClassDefaults()
	-- PALADIN
	if E.class == "PALADIN" then
		if select(5, GetTalentTabInfo(1)) >= 31 then          -- Holy
			turnOff("tsa")
			E:FindDefaultItem("tsa").enableSolo = false
			E:FindDefaultItem("BoK").enableSolo = false
		elseif select(5, GetTalentTabInfo(2)) >= 31 then      -- Protection
			unhide("rf")
			E:FindDefaultItem("mp5").enableSolo = false
			E:FindDefaultItem("tsa").enableSolo = false
		else                                                 -- Retribution
			E:FindDefaultItem("mp5").enableSolo = false
			E:FindDefaultItem("BoK").enableSolo = false
		end
		unhide("aura")
		unhide("seal")
		
	-- MAGE
	elseif E.class == "MAGE" then
		hide("tsa")
		unhide("magearmor")
		unhide("managem")
		
	-- PRIEST
	elseif E.class == "PRIEST" then
		hide("tsa")
		unhide("innerfire")
		
	-- ROGUE
	elseif E.class == "ROGUE" then
		hide("ai")
		hide("mp5")

	-- SHAMAN
	elseif E.class == "SHAMAN" then
		if select(5, GetTalentTabInfo(1)) >= 31 then          -- Elemental
			turnOff("tsa")
		elseif select(5, GetTalentTabInfo(2)) >= 31 then      -- Enhancement
		else                                                  -- Restoration
			turnOff("tsa")
		end
		unhide("elementalshield")
		
	-- WARLOCK
	elseif E.class == "WARLOCK" then
		hide("tsa")
		unhide("warlockarmor")
		unhide("soullink")
		
	-- WARRIOR
	elseif E.class == "WARRIOR" then
		if select(5, GetTalentTabInfo(1)) >= 31 then          -- Protection
		else
		end
		hide("ai")
		hide("mp5")
		
	-- DEATHKNIGHT
	elseif E.class == "DEATHKNIGHT" then
		hide("ai")
		hide("mp5")
		unhide("presence")
		unhide("bloodpresence")
		unhide("boneshield")
		if select(5, GetTalentTabInfo(1)) >= 31 then          -- Blood
			select(2, self:FindDefaultItem("bloodpresence")).me = "EXPECTED"
			select(2, self:FindDefaultItem("bloodpresence")).when = "ALWAYS"
			self:FindDefaultItem("presence").value = "\"48263\",\"48266\",\"48265\""
		else                                                  -- Frost/Unholy
			select(2, self:FindDefaultItem("bloodpresence")).me = "UNEXPECTED"
			select(2, self:FindDefaultItem("bloodpresence")).when = "ALWAYS"
			self:FindDefaultItem("presence").value = "\"48266\",\"48265\""
		end
		
	-- DRUID
	elseif E.class == "DRUID" then
		if select(5, GetTalentTabInfo(1)) >= 31 then          -- Balance
			turnOff("tsa")
		elseif select(5, GetTalentTabInfo(3)) >= 31 then      -- Restoration
			turnOff("tsa")
		else                                                  -- Feral Combat
			turnOff("ai")
			turnOff("mp5")
		end
		
	-- HUNTER
	elseif E.class == "HUNTER" then
		unhide("aotc")
		unhide("aspect")
		hide("ai")
		hide("mp5")
	end
		
end


