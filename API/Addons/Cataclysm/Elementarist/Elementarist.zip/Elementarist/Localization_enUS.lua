-- enUS localization file for Elementarist

-- This is the default locale.

if GetLocale() then
	local L = Elementarist.Locals

	L.BEHAVIOUR_KEEP_FS_UP = "Keep Flame Shock up"
	L.BEHAVIOUR_FS_BEFORE_LVB = "Flame Shock before Lava"
	L.THREAT_WARNING_SUFFIX = "% threat!"
	L.THREAT_WARNING_PREFIX = ""
	L.CONFIG_ENABLED = "Enabled"
	L.CONFIG_ONLY_ON_ELE = "Disable when not on elemental talent"
	L.CONFIG_LOCK_FRAMES = "Lock elementarist frames"
	L.CONFIG_SPELL_ADV_SCALE = "Spell advisor scale"
	L.CONFIG_SPELL_ADV_ALPHA = "Spell advisor alpha"
	L.CONFIG_DISABLE_DEBUFF_TRACKER = "Disable debuff tracker"
	L.CONFIG_DEBUFF_TRACKER_SCALE = "Debuff tracker scale"
	L.CONFIG_DEBUFF_TRACKER_ALPHA = "Debuff tracker alpha"
	L.CONFIG_ENABLE_NOVA = "Enable Fire Nova in rotation"
	L.CONFIG_BEHAVIOUR = "Flame Shock behaviour"
	L.CONFIG_THREAT_WARNING = "Threat warning"
	L.CONFIG_RESET_POSITIONS = "Reset frame positions"
	L.CONFIG_CLSTBEHAVIOUR = "Chain Lightning single target behaviour"
	L.CLSTBEHAVIOUR_CL_AFTER_LVB = "Chain Lightning after Lava"
	L.CLSTBEHAVIOUR_CL_ON_CD = "Chain Lightning on Cooldown"
	L.CLSTBEHAVIOUR_NONE = "None"
-- new for 1.9
	L.CONFIG_SHIELD_TRACKER_SCALE = "Shield tracker scale"
	L.CONFIG_SHIELD_TRACKER_ALPHA = "Shield tracker alpha"
	L.CONFIG_DISABLE_SHIELD_TRACKER = "Disable shield tracker"
	L.CONFIG_ENABLE_UE_SPELL = "Enable Unleash Elements in rotation"
-- new for 2.0
	L.CONFIG_ENABLE_EQ_SPELL = "Enable Earthquake in rotation"
-- new for 2.1.4
	L.CONFIG_DISABLE_MINI = "Disable mini frames"
end