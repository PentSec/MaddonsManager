﻿-- Local stuff

if (GetLocale() == "esES") then
	XPERL_RAID_MONITOR_TITLE		= "Monitor Casteo |c00A04040(BETA)|r"
	XPERL_RAID_MONITOR_TOTALS		= "Alternar visualización de Totales y Estadísticas"

	XPERL_RAID_MONITOR_STATS_RAID_MANA	= "Mana Banda"
	XPERL_RAID_MONITOR_STATS_HIGH_MANA	= "Mana Alto"
	XPERL_RAID_MONITOR_STATS_LOW_MANA	= "Mana Bajo"
	XPERL_RAID_MONITOR_STATS_RAID_HEALTH	= "Salud Banda"

	XPERL_MONITOR_LEFTCLICK			= "|c00FFFFFFClick izquierdo|r para %s"
	XPERL_MONITOR_RIGHTCLICK		= "|c00FFFFFFClick derecho|r para %s"
	XPERL_MONITOR_CLICKCAST			= "cast |c0000FF00%s|r"
	XPERL_MONITOR_CLICKTARGET		= "|c00FFFF80objetivo|r"

	XPERL_MONITOR_INNERVATE			= "Enervar"
	XPERL_MONITOR_MANATIDE			= "Totem de Marea de maná"

	XPERL_LOC_OOR				= "n/a"
end
