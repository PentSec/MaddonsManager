local LibSimpleOptions = LibStub("LibSimpleOptions-1.0")
local runePowerStatusBar;
local runePowerStatusBarDark;
local runePowerStatusBarText;

--Readability == win
local RUNETYPEC_BLOOD = 1;
local RUNETYPEC_UNHOLY = 2;
local RUNETYPEC_FROST = 3;
local RUNETYPEC_CHROMATIC = 4;

local offset = 0;
local start = 0;

local runeY = {
	[1] = start,
	[2] = start-offset,
	[3] = start-offset*2,
	[4] = start-offset*3,
	[5] = start-offset*4,
	[6] = start-offset*5
}

RuneHero_Saved = {
	anchor = "CENTER",
	parent = "UIParent",
	rel = "BOTTOM",
	x = 0;
	y = 155;
	scale = 1;
	runeX = 65;
	scrollWidth = 260;
};

RuneHero_Char = {
	main = "Interface\\AddOns\\RuneHero\\textures\\runeblade2",
	overlay = "Interface\\AddOns\\RuneHero\\textures\\runeblade2-statusbar",
	proc = "Interface\\AddOns\\RuneHero\\textures\\runeblade2-proc",
	l = 150;
	r = 245;
	name = "Frostmourne"
};

function RunePower_Event ()
end
local function RHOptions(self, anchor)
	local title, subText = self:MakeTitleTextAndSubText("Rune Hero", "The ultimate runic experience.")


-- Position Box
  LocPosBox = CreateFrame("Frame",nil,self)
	LocPosBox:SetWidth(155) 
  LocPosBox:SetHeight(135) 
	LocPosBox:SetPoint("TOPLEFT",10,-70)
  LocPosBox:SetBackdrop({
	  bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", 
	  edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", 
	  tile=1, tileSize=10, edgeSize=20, 
	  insets={left=5, right=5, top=5, bottom=5}
	});
	LocPosBox:SetBackdropBorderColor(0.4, 0.4, 0.4);
	local LocPosTitleBox = CreateFrame("Frame",nil,LocPosBox)
	LocPosTitleBox:SetWidth(100) 
  LocPosTitleBox:SetHeight(20) 
	LocPosTitleBox:SetPoint("Top",0,6)
  LocPosTitleBox:SetBackdrop({
	  bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark", 
	  edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", 
	  tile=1, tileSize=5, edgeSize=13, 
	  insets={left=2, right=2, top=2, bottom=2}
	});
	LocPosTitleBox:SetBackdropBorderColor(0.4, 0.4, 0.4);

	local LocPosBoxTitle = LocPosTitleBox:CreateFontString(nil, LocPosTitleBox, "GameFontNormalSmall") 
	LocPosBoxTitle:SetPoint("TOP", LocPosBox, "TOP", 0, 2) 
	LocPosBoxTitle:SetText("Frame Position") 

-- X textbox
	RHSavedX = CreateFrame("EditBox", "RHSavedX", LocPosBox,"InputBoxTemplate")
	RHSavedX:SetPoint("TOPLEFT", 20, -34);
	RHSavedX:SetWidth(50) 
	RHSavedX:SetHeight(13) 
	RHSavedX:SetJustifyH("CENTER")
	RHSavedX:SetText(string.format("%.1f", RuneHero_Saved.x))
	RHSavedX:SetScript("OnTextChanged", function() RuneHero_Saved.x = RHSavedX:GetNumber()  RuneFrameC:ClearAllPoints() RuneFrameC:SetPoint(RuneHero_Saved.anchor, RuneHero_Saved.parent,RuneHero_Saved.rel,RuneHero_Saved.x,RuneHero_Saved.y) end)
	local RHSavedXText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedXText:SetPoint("BOTTOMRIGHT", RHSavedX, "TOPLEFT", 30, 5) 
	RHSavedXText:SetText("X") 
-- Y textbox
	RHSavedY = CreateFrame("EditBox", "RHSavedY", LocPosBox,"InputBoxTemplate")
	RHSavedY:SetPoint("TOPLEFT", 90, -34);
	RHSavedY:SetWidth(50) 
	RHSavedY:SetHeight(13) 
	RHSavedY:SetJustifyH("CENTER")
	RHSavedY:SetText(string.format("%.1f", RuneHero_Saved.y))
	RHSavedY:SetScript("OnTextChanged", function() RuneHero_Saved.y = RHSavedY:GetNumber()  RuneFrameC:ClearAllPoints() RuneFrameC:SetPoint(RuneHero_Saved.anchor, RuneHero_Saved.parent,RuneHero_Saved.rel,RuneHero_Saved.x,RuneHero_Saved.y) end)

	local RHSavedYText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedYText:SetPoint("BOTTOMRIGHT", RHSavedY, "TOPLEFT", 30, 5) 
	RHSavedYText:SetText("Y") 
-- Locked Ticker
	RHLockCheckBox = self:MakeToggle(
	'name', "Frame Locked",
	'description', "Allow the frame to be moved",
	'default', false,
	'getFunc', function() return RuneHero_Saved.Locked; end,
	'setFunc', function(value) RHLock_Adjust(value) end
	)
  RHLockCheckBox:SetPoint("TOPLEFT", LocPosBox, "TOPLEFT", 10, -60)
-- Dock to Player Ticker
	RHPlayerCheckBox = self:MakeToggle(
	'name', "Dock to Player",
	'description', "Dock The Frame To The Playerframe",
	'default', false,
	'getFunc', function() return RHGetDock("PlayerFrame"); end,
	'setFunc', function(value) RHDock_Adjust("player",value) end
	)
  RHPlayerCheckBox:SetPoint("TOPLEFT", LocPosBox, "TOPLEFT", 10, -80)
-- Dock to Castbar Ticker
	RHBottomCheckBox = self:MakeToggle(
	'name', "Dock to Castbar",
	'description', "Dock The Frame To The Castbar",
	'default', false,
	'getFunc', function() return RHGetDock("UIParent"); end,
	'setFunc', function(value) RHDock_Adjust("bottom",value) end
	)
  RHBottomCheckBox:SetPoint("TOPLEFT", LocPosBox, "TOPLEFT", 10, -100)
  
-- Texture Box
  local GFXPosBox = CreateFrame("Frame",nil,self)
	GFXPosBox:SetWidth(300) 
  GFXPosBox:SetHeight(135) 
	GFXPosBox:SetPoint("TOPLEFT",175,-70)
  GFXPosBox:SetBackdrop({
	  bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", 
	  edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", 
	  tile=1, tileSize=10, edgeSize=20, 
	  insets={left=5, right=5, top=5, bottom=5}
	});
	GFXPosBox:SetBackdropBorderColor(0.4, 0.4, 0.4);
	local GFXPosTitleBox = CreateFrame("Frame",nil,GFXPosBox)
	GFXPosTitleBox:SetWidth(100) 
  GFXPosTitleBox:SetHeight(20) 
	GFXPosTitleBox:SetPoint("Top",0,6)
  GFXPosTitleBox:SetBackdrop({
	  bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark", 
	  edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", 
	  tile=1, tileSize=5, edgeSize=13, 
	  insets={left=2, right=2, top=2, bottom=2}
	});
	GFXPosTitleBox:SetBackdropBorderColor(0.4, 0.4, 0.4);

	local GFXPosBoxTitle = GFXPosTitleBox:CreateFontString(nil, GFXPosTitleBox, "GameFontNormalSmall") 
	GFXPosBoxTitle:SetPoint("TOP", GFXPosBox, "TOP", 0, 2) 
	GFXPosBoxTitle:SetText("Frame Graphic") 

-- 	show the main texture
	  RuneHero_MainTexture = GFXPosBox:CreateTexture('RuneHero_MainTexture',"ARTWORK")
	  RuneHero_MainTexture:SetTexture(RuneHero_Char.main);
    RuneHero_MainTexture:SetHeight(128)
		RuneHero_MainTexture:SetWidth(256)
		RuneHero_MainTexture:SetPoint("TOPLEFT", 20, -10);

-- show template dropdown
		local RuneHero_Template = self:MakeDropDown(
       'name', 'Select Template',
	     'description', 'Load A Template',
	     'values', { '1', 'Select Template' },
	     'default', '1',
	     'setFunc', function(value) RuneHero_ChangeTemplate(value) end,
	     'current', '1'
		);
	RuneHero_Template:SetPoint("TOPLEFT", 470, -30);
	RHSwords = {}
	
	for i = 1,RHTotal do
		tinsert(RHSwords, i)
		tinsert(RHSwords, RHsword[i].name)
	end
	RuneHero_Panel_DropDown1.values = RHSwords
	
-- Settings Box
  local GFXSetBox = CreateFrame("Frame",nil,self)
	GFXSetBox:SetWidth(165) 
  GFXSetBox:SetHeight(135) 
	GFXSetBox:SetPoint("TOPLEFT",485,-70)
  GFXSetBox:SetBackdrop({
	  bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", 
	  edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", 
	  tile=1, tileSize=10, edgeSize=20, 
	  insets={left=5, right=5, top=5, bottom=5}
	});
	GFXSetBox:SetBackdropBorderColor(0.4, 0.4, 0.4);
	local GFXSetTitleBox = CreateFrame("Frame",nil,GFXSetBox)
	GFXSetTitleBox:SetWidth(100) 
  GFXSetTitleBox:SetHeight(20) 
	GFXSetTitleBox:SetPoint("Top",0,6)
  GFXSetTitleBox:SetBackdrop({
	  bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark", 
	  edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", 
	  tile=1, tileSize=5, edgeSize=13, 
	  insets={left=2, right=2, top=2, bottom=2}
	});
	GFXSetTitleBox:SetBackdropBorderColor(0.4, 0.4, 0.4);

	local GFXSetBoxTitle = GFXSetTitleBox:CreateFontString(nil, GFXSetTitleBox, "GameFontNormalSmall") 
	GFXSetBoxTitle:SetPoint("TOP", GFXSetBox, "TOP", 0, 2) 
	GFXSetBoxTitle:SetText("Frame Settings") 

-- scale slider
    RHScaleSlide = self:MakeSlider(
	     'name', 'Frame Size',
	     'description', 'Select The Size Of The Frame',
	     'minText', '10%',
	     'maxText', '200%',
	     'minValue', 10,
	     'maxValue', 200,
	     'step', 1,
	     'default', 70,
	     'current', RuneHero_Saved.scale*100,
	     'setFunc', function(value)  end,
	     'currentTextFunc', function(value) RuneHero_SlashCommand("size "..value); return ("%.0f%%"):format(value) end
	 )
	RHScaleSlide:SetPoint("TOP", GFXSetBox, "TOP", 0, -30)
-- Angle slider
    RHAngleSlide = self:MakeSlider(
	     'name', 'Frame Rotation',
	     'description', 'Select The Direction Of The Frame',
	     'minText', '0',
	     'maxText', '270',
	     'minValue', 0,
	     'maxValue', 270,
	     'step', 90,
	     'default', 90,
	     'current', RuneHero_Char.rotation,
	     'setFunc', function(value)  end,
	     'currentTextFunc', function(value) RuneHero_Rotate(value); return ("%.0f"):format(value) end
	 )
	RHAngleSlide:SetPoint("TOP", GFXSetBox, "TOP", 0, -70)
-- FlipX Ticker
	RHflipXCheckBox = self:MakeToggle(
	'name', "Mirror X",
	'description', "Mirror The Frame Horizontally",
	'default', false,
	'getFunc', function() return RuneHero_Char.flipx end,
	'setFunc', function(value) RuneHero_Char.flipx = value end
	)
  RHflipXCheckBox:SetPoint("TOPLEFT", GFXSetBox, "TOPLEFT", 10, -100)
-- FlipX Ticker
	RHflipYCheckBox = self:MakeToggle(
	'name', "Flip Y",
	'description', "Flip The Frame Vertically",
	'default', false,
	'getFunc', function() return RuneHero_Char.flipy end,
	'setFunc', function(value) RuneHero_Char.flipy = value end
	)
  RHflipYCheckBox:SetPoint("TOPLEFT", GFXSetBox, "TOPLEFT", 95, -100)

-- Rune Box
  RuneBox = CreateFrame("Frame",nil,self)
	RuneBox:SetWidth(410) 
  RuneBox:SetHeight(195) 
	RuneBox:SetPoint("TOPLEFT",10,-220)
  RuneBox:SetBackdrop({
	  bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", 
	  edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", 
	  tile=1, tileSize=10, edgeSize=20, 
	  insets={left=5, right=5, top=5, bottom=5}
	});
	RuneBox:SetBackdropBorderColor(0.4, 0.4, 0.4);
	RuneTitleBox = CreateFrame("Frame",nil,RuneBox)
	RuneTitleBox:SetWidth(210) 
  RuneTitleBox:SetHeight(20) 
	RuneTitleBox:SetPoint("Top",0,6)
  RuneTitleBox:SetBackdrop({
	  bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark", 
	  edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", 
	  tile=1, tileSize=5, edgeSize=13, 
	  insets={left=2, right=2, top=2, bottom=2}
	});
	RuneTitleBox:SetBackdropBorderColor(0.4, 0.4, 0.4);

	local RuneBoxTitle = RuneTitleBox:CreateFontString(nil, RuneTitleBox, "GameFontNormalSmall") 
	RuneBoxTitle:SetPoint("TOP", RuneBox, "TOP", 0, 2) 
	RuneBoxTitle:SetText("Rune Position & Direction Settings") 

-- 	show Blood 1 texture
	  RuneHero_Blood1 = RuneBox:CreateTexture('RuneHero_Blood1',"ARTWORK")
	  RuneHero_Blood1:SetTexture(RuneHero_Char.blood1gfx);
    RuneHero_Blood1:SetHeight(29)
		RuneHero_Blood1:SetWidth(29)
		RuneHero_Blood1:SetPoint("TOPLEFT", 10, -10);
-- Blood 1 X textbox
	RHSavedb1X = CreateFrame("EditBox", "RHSavedb1X", RuneBox,"InputBoxTemplate")
	RHSavedb1X:SetPoint("TOPLEFT", 70, -18);
	RHSavedb1X:SetWidth(40) 
	RHSavedb1X:SetHeight(13) 
	RHSavedb1X:SetJustifyH("CENTER")
	RHSavedb1X:SetText(string.format("%.0f", RuneHero_Char.b1x))
	RHSavedb1X:SetScript("OnTextChanged", function() RuneHero_Char.b1x = RHSavedb1X:GetNumber(); end)
	RHSavedb1XText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedb1XText:SetPoint("BOTTOMRIGHT", RHSavedb1X, "TOPLEFT", -8, -10) 
	RHSavedb1XText:SetText("X -") 
-- Blood 1 Y textbox
	RHSavedb1Y = CreateFrame("EditBox", "RHSavedb1Y", RuneBox,"InputBoxTemplate")
	RHSavedb1Y:SetPoint("TOPLEFT", 140, -18);
	RHSavedb1Y:SetWidth(40) 
	RHSavedb1Y:SetHeight(13) 
	RHSavedb1Y:SetJustifyH("CENTER")
	RHSavedb1Y:SetText(string.format("%.0f", RuneHero_Char.b1y))
	RHSavedb1Y:SetScript("OnTextChanged", function() RuneHero_Char.b1y = RHSavedb1Y:GetNumber(); end)
	local RHSavedb1YText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedb1YText:SetPoint("BOTTOMRIGHT", RHSavedb1Y, "TOPLEFT", -8, -10) 
	RHSavedb1YText:SetText("Y -") 
-- Blood 1 Direction dropdown
		RHSavedb1D = self:MakeDropDown(
       'name', '',
	     'description', 'Which Direction Does The Rune Move ?',
	     'values', { '1', 'Right','2', 'Left','3', 'Up','4', 'Down'  },
	     'default', '1',
	     'setFunc', function(value) RuneHero_Char.b1d = string.format("%.0f", value) end,
	     'current', RuneHero_Char.b1d
		);
	RHSavedb1D:SetPoint("TOPLEFT", RuneBox,"TOPLEFT", 170, -12);
-- Blood 1 distance textbox
	RHSavedb1L = CreateFrame("EditBox", "RHSavedb1L", RuneBox,"InputBoxTemplate")
	RHSavedb1L:SetPoint("TOPLEFT", 360, -18);
	RHSavedb1L:SetWidth(40) 
	RHSavedb1L:SetHeight(13) 
	RHSavedb1L:SetJustifyH("CENTER")
	RHSavedb1L:SetText(string.format("%.0f", RuneHero_Char.b1l))
	RHSavedb1L:SetScript("OnTextChanged", function() RuneHero_Char.b1l = RHSavedb1L:GetNumber(); end)
	local RHSavedb1LText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedb1LText:SetPoint("BOTTOMRIGHT", RHSavedb1L, "TOPLEFT", -8, -10) 
	RHSavedb1LText:SetText("Amt ") 

-- 	show Blood 2 texture
	  RuneHero_Blood2 = RuneBox:CreateTexture('RuneHero_Blood2',"ARTWORK")
	  RuneHero_Blood2:SetTexture(RuneHero_Char.blood2gfx);
    RuneHero_Blood2:SetHeight(29)
		RuneHero_Blood2:SetWidth(29)
		RuneHero_Blood2:SetPoint("TOPLEFT", 10, -40);
-- Blood 2 X textbox
	RHSavedb2X = CreateFrame("EditBox", "RHSavedb2X", RuneBox,"InputBoxTemplate")
	RHSavedb2X:SetPoint("TOPLEFT", 70, -48);
	RHSavedb2X:SetWidth(40) 
	RHSavedb2X:SetHeight(13) 
	RHSavedb2X:SetJustifyH("CENTER")
	RHSavedb2X:SetText(string.format("%.0f", RuneHero_Char.b2x))
	RHSavedb2X:SetScript("OnTextChanged", function() RuneHero_Char.b2x = RHSavedb2X:GetNumber(); end)
	RHSavedb2XText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedb2XText:SetPoint("BOTTOMRIGHT", RHSavedb2X, "TOPLEFT", -8, -10) 
	RHSavedb2XText:SetText("X -") 
-- Blood 2 Y textbox
	RHSavedb2Y = CreateFrame("EditBox", "RHSavedb2Y", RuneBox,"InputBoxTemplate")
	RHSavedb2Y:SetPoint("TOPLEFT", 140, -48);
	RHSavedb2Y:SetWidth(40) 
	RHSavedb2Y:SetHeight(13) 
	RHSavedb2Y:SetJustifyH("CENTER")
	RHSavedb2Y:SetText(string.format("%.0f", RuneHero_Char.b2y))
	RHSavedb2Y:SetScript("OnTextChanged", function() RuneHero_Char.b2y = RHSavedb2Y:GetNumber(); end)
	local RHSavedb2YText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedb2YText:SetPoint("BOTTOMRIGHT", RHSavedb2Y, "TOPLEFT", -8, -10) 
	RHSavedb2YText:SetText("Y -") 
-- Blood 2 Direction dropdown
		RHSavedb2D = self:MakeDropDown(
       'name', '',
	     'description', 'Which Direction Does The Rune Move ?',
	     'values', { '1', 'Right','2', 'Left','3', 'Up','4', 'Down'  },
	     'default', '1',
	     'setFunc', function(value) RuneHero_Char.b2d = string.format("%.0f", value) end,
	     'current', RuneHero_Char.b2d
		);
	RHSavedb2D:SetPoint("TOPLEFT", RuneBox,"TOPLEFT", 170, -42);
-- Blood 2 distance textbox
	RHSavedb2L = CreateFrame("EditBox", "RHSavedb2L", RuneBox,"InputBoxTemplate")
	RHSavedb2L:SetPoint("TOPLEFT", 360, -48);
	RHSavedb2L:SetWidth(40) 
	RHSavedb2L:SetHeight(13) 
	RHSavedb2L:SetJustifyH("CENTER")
	RHSavedb2L:SetText(string.format("%.0f", RuneHero_Char.b2l))
	RHSavedb2L:SetScript("OnTextChanged", function() RuneHero_Char.b2l = RHSavedb2L:GetNumber(); end)
	local RHSavedb2LText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedb2LText:SetPoint("BOTTOMRIGHT", RHSavedb2L, "TOPLEFT", -8, -10) 
	RHSavedb2LText:SetText("Amt ") 

-- 	show Frost 1 texture
	  RuneHero_Frost1 = RuneBox:CreateTexture('RuneHero_Frost1',"ARTWORK")
	  RuneHero_Frost1:SetTexture(RuneHero_Char.frost1gfx);
    RuneHero_Frost1:SetHeight(29)
		RuneHero_Frost1:SetWidth(29)
		RuneHero_Frost1:SetPoint("TOPLEFT", 10, -70);
-- Frost 1 X textbox
	RHSavedf1X = CreateFrame("EditBox", "RHSavedf1X", RuneBox,"InputBoxTemplate")
	RHSavedf1X:SetPoint("TOPLEFT", 70, -78);
	RHSavedf1X:SetWidth(40) 
	RHSavedf1X:SetHeight(13) 
	RHSavedf1X:SetJustifyH("CENTER")
	RHSavedf1X:SetText(string.format("%.0f", RuneHero_Char.f1x))
	RHSavedf1X:SetScript("OnTextChanged", function() RuneHero_Char.f1x = RHSavedf1X:GetNumber(); end)
	RHSavedf1XText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedf1XText:SetPoint("BOTTOMRIGHT", RHSavedf1X, "TOPLEFT", -8, -10) 
	RHSavedf1XText:SetText("X -") 
-- Frost 1 Y textbox
	RHSavedf1Y = CreateFrame("EditBox", "RHSavedf1Y", RuneBox,"InputBoxTemplate")
	RHSavedf1Y:SetPoint("TOPLEFT", 140, -78);
	RHSavedf1Y:SetWidth(40) 
	RHSavedf1Y:SetHeight(13) 
	RHSavedf1Y:SetJustifyH("CENTER")
	RHSavedf1Y:SetText(string.format("%.0f", RuneHero_Char.f1y))
	RHSavedf1Y:SetScript("OnTextChanged", function() RuneHero_Char.f1y = RHSavedf1Y:GetNumber(); end)
	local RHSavedf1YText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedf1YText:SetPoint("BOTTOMRIGHT", RHSavedf1Y, "TOPLEFT", -8, -10) 
	RHSavedf1YText:SetText("Y -") 
-- Frost 1 Direction dropdown
		RHSavedf1D = self:MakeDropDown(
       'name', '',
	     'description', 'Which Direction Does The Rune Move ?',
	     'values', { '1', 'Right','2', 'Left','3', 'Up','4', 'Down'  },
	     'default', '1',
	     'setFunc', function(value) RuneHero_Char.f1d = string.format("%.0f", value) end,
	     'current', RuneHero_Char.f1d
		);
	RHSavedf1D:SetPoint("TOPLEFT", RuneBox,"TOPLEFT", 170, -72);
-- Frost 1 distance textbox
	RHSavedf1L = CreateFrame("EditBox", "RHSavedf1L", RuneBox,"InputBoxTemplate")
	RHSavedf1L:SetPoint("TOPLEFT", 360, -78);
	RHSavedf1L:SetWidth(40) 
	RHSavedf1L:SetHeight(13) 
	RHSavedf1L:SetJustifyH("CENTER")
	RHSavedf1L:SetText(string.format("%.0f", RuneHero_Char.f1l))
	RHSavedf1L:SetScript("OnTextChanged", function() RuneHero_Char.f1l = RHSavedf1L:GetNumber(); end)
	local RHSavedf1LText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedf1LText:SetPoint("BOTTOMRIGHT", RHSavedf1L, "TOPLEFT", -8, -10) 
	RHSavedf1LText:SetText("Amt ") 
-- 	show Frost 2 texture
	  RuneHero_Frost2 = RuneBox:CreateTexture('RuneHero_Frost2',"ARTWORK")
	  RuneHero_Frost2:SetTexture(RuneHero_Char.frost2gfx);
    RuneHero_Frost2:SetHeight(29)
		RuneHero_Frost2:SetWidth(29)
		RuneHero_Frost2:SetPoint("TOPLEFT", 10, -100);
-- Frost 2 X textbox
	RHSavedf2X = CreateFrame("EditBox", "RHSavedf2X", RuneBox,"InputBoxTemplate")
	RHSavedf2X:SetPoint("TOPLEFT", 70, -108);
	RHSavedf2X:SetWidth(40) 
	RHSavedf2X:SetHeight(13) 
	RHSavedf2X:SetJustifyH("CENTER")
	RHSavedf2X:SetText(string.format("%.0f", RuneHero_Char.f2x))
	RHSavedf2X:SetScript("OnTextChanged", function() RuneHero_Char.f2x = RHSavedf2X:GetNumber(); end)
	RHSavedf2XText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedf2XText:SetPoint("BOTTOMRIGHT", RHSavedf2X, "TOPLEFT", -8, -10) 
	RHSavedf2XText:SetText("X -") 
-- Frost 2 Y textbox
	RHSavedf2Y = CreateFrame("EditBox", "RHSavedf2Y", RuneBox,"InputBoxTemplate")
	RHSavedf2Y:SetPoint("TOPLEFT", 140, -108);
	RHSavedf2Y:SetWidth(40) 
	RHSavedf2Y:SetHeight(13) 
	RHSavedf2Y:SetJustifyH("CENTER")
	RHSavedf2Y:SetText(string.format("%.0f", RuneHero_Char.f2y))
	RHSavedf2Y:SetScript("OnTextChanged", function() RuneHero_Char.f2y = RHSavedf2Y:GetNumber(); end)
	local RHSavedf2YText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedf2YText:SetPoint("BOTTOMRIGHT", RHSavedf2Y, "TOPLEFT", -8, -10) 
	RHSavedf2YText:SetText("Y -") 
-- Frost 2 Direction dropdown
		RHSavedf2D = self:MakeDropDown(
       'name', '',
	     'description', 'Which Direction Does The Rune Move ?',
	     'values', { '1', 'Right','2', 'Left','3', 'Up','4', 'Down'  },
	     'default', '1',
	     'setFunc', function(value) RuneHero_Char.f2d = string.format("%.0f", value) end,
	     'current', RuneHero_Char.f2d
		);
	RHSavedf2D:SetPoint("TOPLEFT", RuneBox,"TOPLEFT", 170, -102);
-- Frost 2 distance textbox
	RHSavedf2L = CreateFrame("EditBox", "RHSavedf2L", RuneBox,"InputBoxTemplate")
	RHSavedf2L:SetPoint("TOPLEFT", 360, -108);
	RHSavedf2L:SetWidth(40) 
	RHSavedf2L:SetHeight(13) 
	RHSavedf2L:SetJustifyH("CENTER")
	RHSavedf2L:SetText(string.format("%.0f", RuneHero_Char.f2l))
	RHSavedf2L:SetScript("OnTextChanged", function() RuneHero_Char.f2l = RHSavedf2L:GetNumber(); end)
	local RHSavedf2LText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedf2LText:SetPoint("BOTTOMRIGHT", RHSavedf2L, "TOPLEFT", -8, -10) 
	RHSavedf2LText:SetText("Amt ") 
-- 	show Unholy 1 texture
	  RuneHero_Unholy1 = RuneBox:CreateTexture('RuneHero_Unholy1',"ARTWORK")
	  RuneHero_Unholy1:SetTexture(RuneHero_Char.unholy1gfx);
    RuneHero_Unholy1:SetHeight(29)
		RuneHero_Unholy1:SetWidth(29)
		RuneHero_Unholy1:SetPoint("TOPLEFT", 10, -130);
-- Unholy 1 X textbox
	RHSavedu1X = CreateFrame("EditBox", "RHSavedu1X", RuneBox,"InputBoxTemplate")
	RHSavedu1X:SetPoint("TOPLEFT", 70, -138);
	RHSavedu1X:SetWidth(40) 
	RHSavedu1X:SetHeight(13) 
	RHSavedu1X:SetJustifyH("CENTER")
	RHSavedu1X:SetText(string.format("%.0f", RuneHero_Char.u1x))
	RHSavedu1X:SetScript("OnTextChanged", function() RuneHero_Char.u1x = RHSavedu1X:GetNumber(); end)
	RHSavedu1XText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedu1XText:SetPoint("BOTTOMRIGHT", RHSavedu1X, "TOPLEFT", -8, -10) 
	RHSavedu1XText:SetText("X -") 
-- Unholy 1 Y textbox
	RHSavedu1Y = CreateFrame("EditBox", "RHSavedu1Y", RuneBox,"InputBoxTemplate")
	RHSavedu1Y:SetPoint("TOPLEFT", 140, -138);
	RHSavedu1Y:SetWidth(40) 
	RHSavedu1Y:SetHeight(13) 
	RHSavedu1Y:SetJustifyH("CENTER")
	RHSavedu1Y:SetText(string.format("%.0f", RuneHero_Char.u1y))
	RHSavedu1Y:SetScript("OnTextChanged", function() RuneHero_Char.u1y = RHSavedu1Y:GetNumber(); end)
	local RHSavedu1YText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedu1YText:SetPoint("BOTTOMRIGHT", RHSavedu1Y, "TOPLEFT", -8, -10) 
	RHSavedu1YText:SetText("Y -") 
-- Unholy 1 Direction dropdown
		RHSavedu1D = self:MakeDropDown(
       'name', '',
	     'description', 'Which Direction Does The Rune Move ?',
	     'values', { '1', 'Right','2', 'Left','3', 'Up','4', 'Down'  },
	     'default', '1',
	     'setFunc', function(value) RuneHero_Char.u1d = string.format("%.0f", value) end,
	     'current', RuneHero_Char.u1d
		);
	RHSavedu1D:SetPoint("TOPLEFT", RuneBox,"TOPLEFT", 170, -132);
-- Unholy 1 distance textbox
	RHSavedu1L = CreateFrame("EditBox", "RHSavedu1L", RuneBox,"InputBoxTemplate")
	RHSavedu1L:SetPoint("TOPLEFT", 360, -138);
	RHSavedu1L:SetWidth(40) 
	RHSavedu1L:SetHeight(13) 
	RHSavedu1L:SetJustifyH("CENTER")
	RHSavedu1L:SetText(string.format("%.0f", RuneHero_Char.f1l))
	RHSavedu1L:SetScript("OnTextChanged", function() RuneHero_Char.u1l = RHSavedu1L:GetNumber(); end)
	local RHSavedu1LText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedu1LText:SetPoint("BOTTOMRIGHT", RHSavedu1L, "TOPLEFT", -8, -10) 
	RHSavedu1LText:SetText("Amt ") 
-- 	show Unholy 2 texture
	  RuneHero_Unholy2 = RuneBox:CreateTexture('RuneHero_Unholy2',"ARTWORK")
	  RuneHero_Unholy2:SetTexture(RuneHero_Char.unholy2gfx);
    RuneHero_Unholy2:SetHeight(29)
		RuneHero_Unholy2:SetWidth(29)
		RuneHero_Unholy2:SetPoint("TOPLEFT", 10, -160);
-- Unholy 2 X textbox
	RHSavedu2X = CreateFrame("EditBox", "RHSavedu2X", RuneBox,"InputBoxTemplate")
	RHSavedu2X:SetPoint("TOPLEFT", 70, -168);
	RHSavedu2X:SetWidth(40) 
	RHSavedu2X:SetHeight(13) 
	RHSavedu2X:SetJustifyH("CENTER")
	RHSavedu2X:SetText(string.format("%.0f", RuneHero_Char.u2x))
	RHSavedu2X:SetScript("OnTextChanged", function() RuneHero_Char.u2x = RHSavedu2X:GetNumber(); end)
	RHSavedu2XText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedu2XText:SetPoint("BOTTOMRIGHT", RHSavedu2X, "TOPLEFT", -8, -10) 
	RHSavedu2XText:SetText("X -") 
-- Unholy 2 Y textbox
	RHSavedu2Y = CreateFrame("EditBox", "RHSavedu2Y", RuneBox,"InputBoxTemplate")
	RHSavedu2Y:SetPoint("TOPLEFT", 140, -168);
	RHSavedu2Y:SetWidth(40) 
	RHSavedu2Y:SetHeight(13) 
	RHSavedu2Y:SetJustifyH("CENTER")
	RHSavedu2Y:SetText(string.format("%.0f", RuneHero_Char.u2y))
	RHSavedu2Y:SetScript("OnTextChanged", function() RuneHero_Char.u2y = RHSavedu2Y:GetNumber(); end)
	local RHSavedu2YText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedu2YText:SetPoint("BOTTOMRIGHT", RHSavedu2Y, "TOPLEFT", -8, -10) 
	RHSavedu2YText:SetText("Y -") 
-- Unholy 2 Direction dropdown
		RHSavedu2D = self:MakeDropDown(
       'name', '',
	     'description', 'Which Direction Does The Rune Move ?',
	     'values', { '1', 'Right','2', 'Left','3', 'Up','4', 'Down'  },
	     'default', '1',
	     'setFunc', function(value) RuneHero_Char.u2d = string.format("%.0f", value) end,
	     'current', RuneHero_Char.u2d
		);
	RHSavedu2D:SetPoint("TOPLEFT", RuneBox,"TOPLEFT", 170, -162);
-- Unholy 2 distance textbox
	RHSavedu2L = CreateFrame("EditBox", "RHSavedu2L", RuneBox,"InputBoxTemplate")
	RHSavedu2L:SetPoint("TOPLEFT", 360, -168);
	RHSavedu2L:SetWidth(40) 
	RHSavedu2L:SetHeight(13) 
	RHSavedu2L:SetJustifyH("CENTER")
	RHSavedu2L:SetText(string.format("%.0f", RuneHero_Char.u2l))
	RHSavedu2L:SetScript("OnTextChanged", function() RuneHero_Char.u2l = RHSavedu2L:GetNumber(); end)
	local RHSavedu2LText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedu2LText:SetPoint("BOTTOMRIGHT", RHSavedu2L, "TOPLEFT", -8, -10) 
	RHSavedu2LText:SetText("Amt ") 
	
-- Rune graphics Box
  RuneGFXBox = CreateFrame("Frame",nil,self)
	RuneGFXBox:SetWidth(220) 
  RuneGFXBox:SetHeight(120) 
	RuneGFXBox:SetPoint("TOPLEFT",430,-220)
  RuneGFXBox:SetBackdrop({
	  bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", 
	  edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", 
	  tile=1, tileSize=10, edgeSize=20, 
	  insets={left=5, right=5, top=5, bottom=5}
	});
	RuneGFXBox:SetBackdropBorderColor(0.4, 0.4, 0.4);
	RuneGFXTitleBox = CreateFrame("Frame",nil,RuneGFXBox)
	RuneGFXTitleBox:SetWidth(140) 
  RuneGFXTitleBox:SetHeight(20) 
	RuneGFXTitleBox:SetPoint("Top",0,6)
  RuneGFXTitleBox:SetBackdrop({
	  bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark", 
	  edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", 
	  tile=1, tileSize=5, edgeSize=13, 
	  insets={left=2, right=2, top=2, bottom=2}
	});
	RuneGFXTitleBox:SetBackdropBorderColor(0.4, 0.4, 0.4);

	local RuneGFXBoxTitle = RuneGFXTitleBox:CreateFontString(nil, RuneGFXTitleBox, "GameFontNormalSmall") 
	RuneGFXBoxTitle:SetPoint("TOP", RuneGFXBox, "TOP", 0, 2) 
	RuneGFXBoxTitle:SetText("Rune Graphic Settings") 

-- show template dropdown
		RuneHero_RuneTemplate = self:MakeDropDown(
       'name', '',
	     'description', 'Load A Rune Template',
	     'values', { '1', 'Select Runes' },
	     'default', '1',
	     'setFunc', function(value) RuneHero_ChangeRuneTemplate(value) end,
	     'current', '1'
		);
	RuneHero_RuneTemplate:SetPoint("TOPLEFT", 460, -235);
	RHRune = {}
	
	for i = 1,RHTotRunes do
		tinsert(RHRune, i)
		tinsert(RHRune, RHRunes[i].name)
	end
	RuneHero_RuneTemplate.values = RHRune
-- Hide Blizz Runes Ticker
	RHHideCheckBox = self:MakeToggle(
	'name', "Hide Blizz Runes",
	'description', "Hide the Blizzard Default Frame",
	'default', false,
	'getFunc', function() return RuneHero_Char.Hide; end,
	'setFunc', function(value) RuneHero_Char.Hide = value end
	)
  RHHideCheckBox:SetPoint("TOPLEFT", LocPosBox, "TOPLEFT", 310, 50)
-- Ring Ticker
	RHRuneRingCheckBox = self:MakeToggle(
	'name', "Coloured",
	'description', "Overlay the runes with a coloured Border",
	'default', false,
	'getFunc', function() return RuneHero_Char.rings end,
	'setFunc', function(value) RuneHero_Char.rings = value for rune  = 1, 6 do   RuneButtonC_Update(RuneFrameC.runes[rune], rune)	end  end
	)
  RHRuneRingCheckBox:SetPoint("TOPLEFT", RuneGFXBox, "TOPLEFT", 20, -50)
-- fadeout Ticker
	RHFadeCheckBox = self:MakeToggle(
	'name', "Fading",
	'description', "Should the rune fade out based on ready time",
	'default', false,
	'getFunc', function() return RuneHero_Char.runefade end,
	'setFunc', function(value) RuneHero_Char.runefade = value for rune  = 1, 6 do   RuneButtonC_Update(RuneFrameC.runes[rune], rune)	end   end
	)
  RHFadeCheckBox:SetPoint("TOPLEFT", RuneGFXBox, "TOPLEFT", 130, -50)
-- largedeath  Ticker
	RHLargeDeathCheckBox = self:MakeToggle(
	'name', "Larger Death Runes",
	'description', "Should the death runes be bigger",
	'default', false,
	'getFunc', function() return RuneHero_Char.largedeath end,
	'setFunc', function(value) RuneHero_Char.largedeath = value for rune  = 1, 6 do   RuneButtonC_Update(RuneFrameC.runes[rune], rune)	end end
	)
  RHLargeDeathCheckBox:SetPoint("TOPLEFT", RuneGFXBox, "TOPLEFT", 35, -80)

-- Rune Text Box
  RuneTexBox = CreateFrame("Frame",nil,self)
	RuneTexBox:SetWidth(220) 
  RuneTexBox:SetHeight(65) 
	RuneTexBox:SetPoint("TOPLEFT",430,-350)
  RuneTexBox:SetBackdrop({
	  bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", 
	  edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", 
	  tile=1, tileSize=10, edgeSize=20, 
	  insets={left=5, right=5, top=5, bottom=5}
	});
	RuneTexBox:SetBackdropBorderColor(0.4, 0.4, 0.4);
	RuneTexTitleBox = CreateFrame("Frame",nil,RuneTexBox)
	RuneTexTitleBox:SetWidth(160) 
  RuneTexTitleBox:SetHeight(20) 
	RuneTexTitleBox:SetPoint("Top",0,6)
  RuneTexTitleBox:SetBackdrop({
	  bgFile="Interface\\DialogFrame\\UI-DialogBox-Background-Dark", 
	  edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", 
	  tile=1, tileSize=5, edgeSize=13, 
	  insets={left=2, right=2, top=2, bottom=2}
	});
	RuneTexTitleBox:SetBackdropBorderColor(0.4, 0.4, 0.4);

	local RuneTexBoxTitle = RuneTexTitleBox:CreateFontString(nil, RuneTexTitleBox, "GameFontNormalSmall") 
	RuneTexBoxTitle:SetPoint("TOP", RuneTexBox, "TOP", 0, 2) 
	RuneTexBoxTitle:SetText("Rune Power Text Settings") 
-- text X textbox
	RHSavedtX = CreateFrame("EditBox", "RHSavedtX", RuneTexBox,"InputBoxTemplate")
	RHSavedtX:SetPoint("TOPLEFT", 40, -28);
	RHSavedtX:SetWidth(40) 
	RHSavedtX:SetHeight(13) 
	RHSavedtX:SetJustifyH("CENTER")
	RHSavedtX:SetText(string.format("%.0f", RuneHero_Char.tx))
	RHSavedtX:SetScript("OnTextChanged", function() RuneHero_Char.tx = RHSavedtX:GetNumber(); end)
	RHSavedtXText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedtXText:SetPoint("BOTTOMRIGHT", RHSavedtX, "TOPLEFT", -8, -10) 
	RHSavedtXText:SetText("X -") 
-- text 2 Y textbox
	RHSavedtY = CreateFrame("EditBox", "RHSavedtY", RuneTexBox,"InputBoxTemplate")
	RHSavedtY:SetPoint("TOPLEFT", 112, -28);
	RHSavedtY:SetWidth(40) 
	RHSavedtY:SetHeight(13) 
	RHSavedtY:SetJustifyH("CENTER")
	RHSavedtY:SetText(string.format("%.0f", RuneHero_Char.ty))
	RHSavedtY:SetScript("OnTextChanged", function() RuneHero_Char.ty = RHSavedtY:GetNumber(); end)
	local RHSavedtYText = self:CreateFontString(nil, UIParent, "GameFontWhite") 
	RHSavedtYText:SetPoint("BOTTOMRIGHT", RHSavedtY, "TOPLEFT", -8, -10) 
	RHSavedtYText:SetText("Y -") 
-- text color 
	RHSavedtC = self:MakeColorPicker(
	     'name', '',
	     'description', 'Change the text color',
	     'hasAlpha', false,
	     'defaultR', 0,
	     'defaultG', 0,
	     'defaultB', 0,
	     'defaultA', 1,
	     'currentR', RuneHero_Char.txr,
	     'currentG', RuneHero_Char.txg,
	     'currentB', RuneHero_Char.txb,
	     'currentA', RuneHero_Char.txa,
	     'setFunc', function(r, g, b, a) RuneHero_Char.txr, RuneHero_Char.txg, RuneHero_Char.txb, RuneHero_Char.txa = r, g, b, a end
	 )
	RHSavedtC:SetPoint("TOPLEFT", 600, -372);
	RuneHero_Panel_ColorPicker1:SetScript("OnClick", function(self) OpenColorPicker(self.info) ColorPickerFrame:SetFrameStrata("TOOLTIP"); end )
end
function RuneHero_Rotate(value)
	if value == 0 then xvalue = 90 
	elseif value == 90 then xvalue = 0 
	elseif value == 180 then xvalue = 270
	elseif value == 270 then xvalue = 180
	end
	
	RHRotate:SetDegrees(xvalue)
	RHRotate:Play()
	RuneHero_Char.rotation = value
end
function RuneHero_ChangeRuneTemplate(template)
	template = tonumber(template)
	RuneHero_Char.blood1gfx = RHRunes[template].blood1
	RuneHero_Char.blood1gfx = RHRunes[template].blood1
	RuneHero_Char.blood2gfx = RHRunes[template].blood2
	RuneHero_Char.frost1gfx = RHRunes[template].frost1
	RuneHero_Char.frost2gfx = RHRunes[template].frost2
	RuneHero_Char.unholy1gfx = RHRunes[template].unholy1
	RuneHero_Char.unholy2gfx = RHRunes[template].unholy2
	RuneHero_Char.death1gfx = RHRunes[template].death1
	RuneHero_Char.death2gfx = RHRunes[template].death2
	RuneHero_Char.death3gfx = RHRunes[template].death3
	RuneHero_Char.death4gfx = RHRunes[template].death4
	RuneHero_Char.death5gfx = RHRunes[template].death5
	RuneHero_Char.death6gfx = RHRunes[template].death6
	RuneHero_Char.ringgfx = RHRunes[template].ring
	RuneHero_Char.rings = RHRunes[template].rings
  RuneHero_Blood1:SetTexture(RuneHero_Char.blood1gfx);
  RuneHero_Blood2:SetTexture(RuneHero_Char.blood2gfx);
  RuneHero_Unholy1:SetTexture(RuneHero_Char.unholy1gfx);
  RuneHero_Unholy2:SetTexture(RuneHero_Char.unholy2gfx);
  RuneHero_Frost1:SetTexture(RuneHero_Char.frost1gfx);
  RuneHero_Frost2:SetTexture(RuneHero_Char.frost2gfx);

		for rune  = 1, 6 do
			RuneButtonC_Update(RuneFrameC.runes[rune], rune);
		end

end
function RuneHero_ChangeTemplate(template)

	RuneHero_Char.main = RHsword[template].main
	RuneHero_Char.overlay = RHsword[template].overlay
	RuneHero_Char.l = RHsword[template].l
	RuneHero_Char.r = RHsword[template].r
	RuneHero_Char.tx = RHsword[template].x
	RuneHero_Char.ty = RHsword[template].y
	RuneHero_Char.b1x = RHsword[template].b1x
	RuneHero_Char.b2x = RHsword[template].b2x
	RuneHero_Char.f1x = RHsword[template].f1x
	RuneHero_Char.f2x = RHsword[template].f2x
	RuneHero_Char.u1x = RHsword[template].u1x
	RuneHero_Char.u2x = RHsword[template].u2x
	RuneHero_Char.b1y = RHsword[template].b1y
	RuneHero_Char.b2y = RHsword[template].b2y
	RuneHero_Char.f1y = RHsword[template].f1y
	RuneHero_Char.f2y = RHsword[template].f2y
	RuneHero_Char.u1y = RHsword[template].u1y
	RuneHero_Char.u2y = RHsword[template].u2y
	RuneHero_Char.b1d = RHsword[template].b1d
	RuneHero_Char.b1l = RHsword[template].b1l
	RuneHero_Char.b2d = RHsword[template].b2d
	RuneHero_Char.b2l = RHsword[template].b2l
	RuneHero_Char.f1d = RHsword[template].f1d
	RuneHero_Char.f1l = RHsword[template].f1l
	RuneHero_Char.f2d = RHsword[template].f2d
	RuneHero_Char.f2l = RHsword[template].f2l
	RuneHero_Char.u1d = RHsword[template].u1d
	RuneHero_Char.u1l = RHsword[template].u1l
	RuneHero_Char.u2d = RHsword[template].u2d
	RuneHero_Char.u2l = RHsword[template].u2l
	-- RuneHero_Char.scrollWidth = RHsword[template].scrollWidth
	if RuneHero_MainTexture then RuneHero_MainTexture:SetTexture(RuneHero_Char.main); end
	RuneBlade:SetTexture(RuneHero_Char.main);
	RuneBladeStatusBar:SetTexture(RuneHero_Char.overlay);
	RHSavedtX:SetText(string.format("%.0f", RuneHero_Char.tx))
	RHSavedtY:SetText(string.format("%.0f", RuneHero_Char.ty))
	RHSavedb1X:SetText(string.format("%.0f", RuneHero_Char.b1x))
	RHSavedb2X:SetText(string.format("%.0f", RuneHero_Char.b2x))
	RHSavedf1X:SetText(string.format("%.0f", RuneHero_Char.f1x))
	RHSavedf2X:SetText(string.format("%.0f", RuneHero_Char.f2x))
	RHSavedu1X:SetText(string.format("%.0f", RuneHero_Char.u1x))
	RHSavedu2X:SetText(string.format("%.0f", RuneHero_Char.u2x))
	RHSavedb1Y:SetText(string.format("%.0f", RuneHero_Char.b1y))
	RHSavedb2Y:SetText(string.format("%.0f", RuneHero_Char.b2y))
	RHSavedf1Y:SetText(string.format("%.0f", RuneHero_Char.f1y))
	RHSavedf2Y:SetText(string.format("%.0f", RuneHero_Char.f2y))
	RHSavedu1Y:SetText(string.format("%.0f", RuneHero_Char.u1y))
	RHSavedu2Y:SetText(string.format("%.0f", RuneHero_Char.u2y))
	RHSavedb1D:SetValue(( RuneHero_Char.b1d))
	RHSavedb1L:SetText(string.format("%.0f", RuneHero_Char.b1l))
	RHSavedb2D:SetValue(( RuneHero_Char.b2d))
	RHSavedb2L:SetText(string.format("%.0f", RuneHero_Char.b2l))
	RHSavedf1D:SetValue(( RuneHero_Char.f1d))
	RHSavedf1L:SetText(string.format("%.0f", RuneHero_Char.f1l))
	RHSavedf2D:SetValue(( RuneHero_Char.f2d))
	RHSavedf2L:SetText(string.format("%.0f", RuneHero_Char.f2l))
	RHSavedu1D:SetValue(( RuneHero_Char.u1d))
	RHSavedu1L:SetText(string.format("%.0f", RuneHero_Char.u1l))
	RHSavedu2D:SetValue(( RuneHero_Char.u2d))
	RHSavedu2L:SetText(string.format("%.0f", RuneHero_Char.u2l))

end

function RHGetDock(dock)
	local saveddock = RuneHero_Saved.parent
	if saveddock == dock then
		return true
	else
		return false
	end
end

function RHDock_Adjust(cmd,value)
	local setting = "player"
	if cmd == "player" and value == true then setting = "player"
		elseif cmd == "player" and value == false then setting = "bottom"
		elseif cmd == "bottom" and value == true then setting = "bottom"
		elseif cmd == "bottom" and value == false then setting = "player"
	end
		if setting == "player" then 
			RHPlayerCheckBox:SetChecked(true)
			RHBottomCheckBox:SetChecked(false)
		else
			RHPlayerCheckBox:SetChecked(false)
			RHBottomCheckBox:SetChecked(true)
		end
			
	RuneHero_SlashCommand(setting)
end

function RHLock_Adjust(value)
	if (RuneHero_Saved.Locked == false and value == true) then
		RuneButtonIndividual1C:SetMovable(false);
		RuneButtonIndividual1C:RegisterForDrag(nil);
		RuneButtonIndividual1C:SetScript('OnDragStart', nil );
		RuneFrameC:SetClampedToScreen(true);
		DEFAULT_CHAT_FRAME:AddMessage(" RuneHero locked.");
    RuneHero_Saved.Locked = true
	elseif (RuneHero_Saved.Locked == true and value == false) then
		RuneButtonIndividual1C:SetMovable(true);
		RuneButtonIndividual1C:RegisterForDrag('LeftButton');
		RuneButtonIndividual1C:SetScript('OnDragStart', RuneFrameC_OnDragStart );
		RuneButtonIndividual1C:SetScript('OnDragStop', RuneFrameC_OnDragStop );
		RuneFrameC:SetClampedToScreen(true);
		DEFAULT_CHAT_FRAME:AddMessage(" RuneHero unlocked. Click on the top rune icon to drag.");
		RuneHero_Saved.Locked = false
	end
end

function RuneButtonC_OnLoad (self)
	RuneFrameC_AddRune(RuneFrameC, self);
	
	self.rune = getglobal(self:GetName().."Rune");
	self.border = getglobal(self:GetName().."Border");
	self.texture = getglobal(self:GetName().."BorderTexture");
	self.bg = getglobal(self:GetName().."BG");

	self.border = getglobal(self:GetName().."Border");

	RuneButtonC_Update(self);

	self:SetScript("OnUpdate", RuneButtonC_OnUpdate);

	self:SetFrameLevel( self:GetFrameLevel() + 2*self:GetID() );
	self.border:SetFrameLevel( self:GetFrameLevel() + 1 );
end

function RuneButtonC_OnUpdate (self, elapsed)

	local rune = self:GetID()
	local start, duration, r = GetRuneCooldown(rune);
	local remain = (duration - GetTime() + start) / duration;
-- DEFAULT_CHAT_FRAME:AddMessage(r)
	if r == false or runeY[rune] == 0 then 
	local remainx, remainy, dir, dist = 0 , 0, '0' ,0
		if rune == 1 then offsetx = RuneHero_Char.b1x; runeY[rune] = RuneHero_Char.b1y ; dir = RuneHero_Char.b1d; dist = RuneHero_Char.b1l; end 
		if rune == 2 then offsetx = RuneHero_Char.b2x; runeY[rune] = RuneHero_Char.b2y ; dir = RuneHero_Char.b2d; dist = RuneHero_Char.b2l;end 
		if rune == 3 then offsetx = RuneHero_Char.u1x; runeY[rune] = RuneHero_Char.u1y ; dir = RuneHero_Char.u1d; dist = RuneHero_Char.u1l;end 
		if rune == 4 then offsetx = RuneHero_Char.u2x; runeY[rune] = RuneHero_Char.u2y ; dir = RuneHero_Char.u2d; dist = RuneHero_Char.u2l;end 
		if rune == 5 then offsetx = RuneHero_Char.f1x; runeY[rune] = RuneHero_Char.f1y ; dir = RuneHero_Char.f1d; dist = RuneHero_Char.f1l;end 
		if rune == 6 then offsetx = RuneHero_Char.f2x; runeY[rune] = RuneHero_Char.f2y ; dir = RuneHero_Char.f2d; dist = RuneHero_Char.f2l;end 
		local RHangle = string.format("%.0f", RHRotate:GetDegrees())
		if RuneHero_Char.runefade then 
			local runealpha = remain
			self.rune:SetAlpha(1 - runealpha)
			self.border:SetAlpha(1 - runealpha)
			self.texture:SetAlpha(1 - runealpha)
			self.bg:SetAlpha(1 - runealpha)
		else			
			local runealpha = 0
			self.rune:SetAlpha(1 - runealpha)
			self.border:SetAlpha(1 - runealpha)
			self.texture:SetAlpha(1 - runealpha)
			self.bg:SetAlpha(1 - runealpha)
	  end
		if r == true then 
			remainx = 0 
			remainy = 0
		else 
			remain = remain*dist
			if  dir == '1' then remainx = remain end 
			if  dir == '2' then remainx = 0 - remain end 
			if  dir == '3' then remainy = remain end 
			if  dir == '4' then remainy = 0 - remain end 
		end
      -- DEFAULT_CHAT_FRAME:AddMessage(r)
		self:ClearAllPoints();
		if RHangle == "0" then 
			if RuneHero_Char.flipx == true then 
			  if RuneHero_Char.flipy == true then 
				  offsetx = 0 - offsetx
				  runeY[rune] = 0 - runeY[rune]
				  self:SetPoint("BOTTOMRIGHT", "RuneFrameC", "BOTTOMRIGHT", offsetx + remainx, runeY[rune] + remainy); 
			  else 
				  offsetx = 0 - offsetx
				  self:SetPoint("TOPRIGHT", "RuneFrameC", "TOPRIGHT", offsetx + remainx, runeY[rune] + remainy); 
			  end
		  else
		  	if RuneHero_Char.flipy == true then 
				  runeY[rune] = 0 - runeY[rune]
				  self:SetPoint("BOTTOMLEFT", "RuneFrameC", "BOTTOMLEFT", offsetx + remainx, runeY[rune] + remainy); 
				else
				  self:SetPoint("TOPLEFT", "RuneFrameC", "TOPLEFT", offsetx + remainx, runeY[rune] + remainy);
				end
		  end
		elseif RHangle == "90" then 
			if RuneHero_Char.flipx == true then
				if RuneHero_Char.flipy == true then
					local offsettemp = 128 - offsetx  
					offsetx = runeY[rune] - 128
					runeY[rune] = offsettemp
					self:SetPoint("TOPRIGHT", "RuneFrameC", "TOPRIGHT", offsetx + remainx, runeY[rune] + remainy); 
				else
					local offsettemp = 128 - offsetx  
					offsetx = 128 + ( 0 - ( runeY[rune] ) )
					runeY[rune] = offsettemp
					self:SetPoint("TOPLEFT", "RuneFrameC", "TOPLEFT", offsetx + remainx, runeY[rune] + remainy); 
				end
			else
				if RuneHero_Char.flipy == true then
					local offsettemp = offsetx - 128 
					offsetx = runeY[rune] - 128 
					runeY[rune] = offsettemp
					self:SetPoint("BOTTOMRIGHT", "RuneFrameC", "BOTTOMRIGHT", offsetx + remainx, runeY[rune] + remainy); 
				else
					local offsettemp = offsetx - 128 
					offsetx = 128 + ( 0 - ( runeY[rune] ) )
					runeY[rune] = offsettemp
					self:SetPoint("BOTTOMLEFT", "RuneFrameC", "BOTTOMLEFT", offsetx + remainx, runeY[rune] + remainy); 
				end
			end				
		elseif RHangle == "180" then 
			if RuneHero_Char.flipx == true then
				if RuneHero_Char.flipy == true then
					self:SetPoint("TOPLEFT", "RuneFrameC", "TOPLEFT", offsetx + remainx, runeY[rune] + remainy);
				else
					runeY[rune] = 0 - runeY[rune]
					self:SetPoint("BOTTOMLEFT", "RuneFrameC", "BOTTOMLEFT", offsetx + remainx, runeY[rune] + remainy);
				end
		  else
		  	if RuneHero_Char.flipy == true then
					offsetx = 0 - offsetx
				  self:SetPoint("TOPRIGHT", "RuneFrameC", "TOPRIGHT", offsetx + remainx, runeY[rune] + remainy);
				else
					offsetx = 0 - offsetx
					runeY[rune] = 0 - runeY[rune]
					self:SetPoint("BOTTOMRIGHT", "RuneFrameC", "BOTTOMRIGHT", offsetx + remainx, runeY[rune] + remainy);
				end
			end 
		elseif RHangle == "270" then 

			if RuneHero_Char.flipx == true then
				if RuneHero_Char.flipy == true then
					local offsettemp = 0 - (128 - offsetx )
					offsetx =    ( 0 -  ( runeY[rune] ) ) + 128
					runeY[rune] = offsettemp
					self:SetPoint("BOTTOMLEFT", "RuneFrameC", "BOTTOMLEFT", offsetx + remainx, runeY[rune] + remainy); 
				else
					local offsettemp = 0 - (128 - offsetx )
					offsetx =   (  ( runeY[rune] ) ) -128
					runeY[rune] = offsettemp
					self:SetPoint("BOTTOMRIGHT", "RuneFrameC", "BOTTOMRIGHT", offsetx + remainx, runeY[rune] + remainy); 
				end
  		else
				if RuneHero_Char.flipy == true then
					local offsettemp = 128 - offsetx 
					offsetx = 0- (  ( runeY[rune] )- 128 )  
					runeY[rune] = offsettemp
					self:SetPoint("TOPLEFT", "RuneFrameC", "TOPLEFT", offsetx + remainx, runeY[rune] + remainy); 
			  else
					local offsettemp = 128 - offsetx 
					offsetx =  (  ( runeY[rune] ) ) - 128 
					runeY[rune] = offsettemp
					self:SetPoint("TOPRIGHT", "RuneFrameC", "TOPRIGHT", offsetx + remainx, runeY[rune] + remainy); 
			  end
  		end
		end
  end
end

function RuneButtonC_Update (self, rune)

	local runenum = self:GetID();
	local runeType = GetRuneType(runenum);
	if (runeType == RUNETYPEC_BLOOD) then
		if runenum == 1 then self.rune:SetTexture(RuneHero_Char.blood1gfx); end
		if runenum == 2 then self.rune:SetTexture(RuneHero_Char.blood2gfx); end
			self.texture:SetTexture(RuneHero_Char.ringgfx);
		  self.texture:SetDesaturated(false);
			self.texture:SetVertexColor(.65,0,0,1);
			self.bg:SetVertexColor(.2,.2,.2,1);

		self.rune:SetWidth(29);	
		self.rune:SetHeight(29);
		self.border:SetWidth(29);
		self.border:SetHeight(29);

	elseif (runeType == RUNETYPEC_UNHOLY) then
		if runenum == 3 then self.rune:SetTexture(RuneHero_Char.unholy1gfx); end
		if runenum == 4 then self.rune:SetTexture(RuneHero_Char.unholy2gfx); end
		-- self.rune:SetVertexColor(0,1,0);

		self.texture:SetTexture(RuneHero_Char.ringgfx);
		self.texture:SetDesaturated(false);
		self.texture:SetVertexColor(0,.65,0,1);

		self.bg:SetVertexColor(.2,.2,.2,1);

		self.rune:SetWidth(29);
		self.rune:SetHeight(29);

		self.bg:SetWidth(20);	
		self.bg:SetHeight(20);

		self.border:SetWidth(29);
		self.border:SetHeight(29);

	elseif (runeType == RUNETYPEC_FROST) then
		if runenum == 5 then self.rune:SetTexture(RuneHero_Char.frost1gfx); end
		if runenum == 6 then self.rune:SetTexture(RuneHero_Char.frost2gfx); end
		-- self.rune:SetTexture("Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Frost" );

		self.texture:SetTexture(RuneHero_Char.ringgfx);
		self.texture:SetDesaturated(false);
		self.texture:SetVertexColor(0,.3,1,1);

		self.bg:SetVertexColor(.2,.2,.2,1);

		self.rune:SetWidth(29);
		self.rune:SetHeight(29);
		
		self.bg:SetWidth(20);	
		self.bg:SetHeight(20);

		self.border:SetWidth(29);
		self.border:SetHeight(29);

	elseif (runeType == RUNETYPEC_CHROMATIC) then
		if runenum == 1 then self.rune:SetTexture(RuneHero_Char.death1gfx); end
		if runenum == 2 then self.rune:SetTexture(RuneHero_Char.death2gfx); end
		if runenum == 3 then self.rune:SetTexture(RuneHero_Char.death3gfx); end
		if runenum == 4 then self.rune:SetTexture(RuneHero_Char.death4gfx); end
		if runenum == 5 then self.rune:SetTexture(RuneHero_Char.death5gfx); end
		if runenum == 6 then self.rune:SetTexture(RuneHero_Char.death6gfx); end

		-- self.rune:SetTexture("Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Death.tga" );
		-- self.rune:SetVertexColor(1,1,1);

		self.texture:SetTexture(RuneHero_Char.ringgfx);
		self.texture:SetDesaturated(false);
		self.texture:SetVertexColor(.65,.65,.65,1);

		self.rune:SetWidth(29);
		self.rune:SetHeight(29);

		self.bg:SetWidth(20);	
		self.bg:SetHeight(20);
		if RuneHero_Char.largedeath then 
			self.rune:SetWidth(34);
			self.rune:SetHeight(34);
			self.border:SetWidth(34);
			self.border:SetHeight(34);
	  else
			self.rune:SetWidth(29);
			self.rune:SetHeight(29);
			self.border:SetWidth(29);
			self.border:SetHeight(29);
	  end
	end
		if RuneHero_Char.rings then 
			self.texture:Show()
		else
			self.texture:Hide()
	  end

		self.bg:Hide();	

	
end

function RuneFrameC_OnLoad (self)

	-- Disable rune frame if not a death knight.
	local _, class = UnitClass("player");
	
	if ( class ~= "DEATHKNIGHT" ) then
		self:Hide();
		
	end

	if (RuneHero_Saved.scrollWidth < 0) then
		RuneHero_Saved.scrollWidth = 260;
	end

	self:SetFrameLevel(1);
	
	self:RegisterEvent("PLAYER_ENTERING_WORLD");
	self:RegisterEvent("RUNE_TYPE_UPDATE");
	--self:RegisterEvent("RUNE_POWER_UPDATE");
	self:RegisterEvent("RUNE_REGEN_UPDATE");
	self:RegisterEvent("COMBAT_LOG_EVENT");

	self:RegisterEvent("VARIABLES_LOADED");
	DEFAULT_CHAT_FRAME:AddMessage("RuneHero activated! Type '/runehero' to reposition the bar.");

	self:SetScript("OnEvent", RuneFrameC_OnEvent);
	self:SetScript("OnUpdate", RuneFrameC_OnUpdate);
	
	self.runes = {};

	-- runePowerStatusBar = CreateFrame("StatusBar", "RuneBladeStatusBar", RuneFrameC);
	-- runePowerStatusBar:SetStatusBarTexture("Interface\\AddOns\\RuneHero\\textures\\runeblade-statusbar.tga");
	
	-- runePowerStatusBar:SetStatusBarColor(1,1,1,1);
	-- runePowerStatusBar:SetMinMaxValues(-8,113);
	-- runePowerStatusBar:SetAllPoints(RuneBlade);
	-- runePowerStatusBar:SetFrameLevel(2);
	runePowerStatusBarText = CreateFrame("StatusBar", nil, UIParent):CreateFontString("RuneBladeStatusBarText", 'OVERLAY');
	runePowerStatusBarText:ClearAllPoints();
	runePowerStatusBarText:SetFontObject( WorldMapTextFont );
	runePowerStatusBarText:SetTextColor(.6,.9,1);
	runePowerStatusBarText:SetPoint("TOP", RuneBlade, "TOP", RuneHero_Saved.runeX-80, 25 );
	runePowerStatusBarText:SetJustifyH("CENTER");
	runePowerStatusBarText:SetWidth(90);
	runePowerStatusBarText:SetHeight(40);
	
end



function RuneFrameC_OnUpdate(self)

	local power = UnitMana("player");
	local powerType, powerTypeString = UnitPowerType("player");
	-- runePowerStatusBar:SetValue( power );
	if powerType == 6 then 
  			local maxpower = UnitPowerMax("player");
  			local curwidth = (maxpower / power);
  			local RHangle = string.format("%.0f", RHRotate:GetDegrees())
  			local rb1, rb2, rb3, rb4, rb5, rb6, rb7, rb8 = 1,1,1,1,1,1,1,1
  			local rbs1, rbs2, rbs3, rbs4, rbs5, rbs6, rbs7, rbs8 = 1,1,1,1,1,1,1,1
				if RuneHero_Char.flipx == true and RuneHero_Char.flipy == true then 
	    		rb1, rb2, rb3, rb4, rb5, rb6, rb7, rb8 = 1, 1, 1, 0, 0, 1, 0, 0; 
	 				rbs1, rbs2, rbs3, rbs4, rbs5, rbs6, rbs7, rbs8 = (RuneHero_Char.l/512) + ((RuneHero_Char.r/512)/curwidth) , 1, (RuneHero_Char.l/512) + ((RuneHero_Char.r/512)/curwidth) , 0, 0, 1, 0 , 0
				elseif RuneHero_Char.flipx == true and RuneHero_Char.flipy == false then 
	    		rb1, rb2, rb3, rb4, rb5, rb6, rb7, rb8 = 1, 0, 1, 1, 0, 0, 0, 1; 
	 				rbs1, rbs2, rbs3, rbs4, rbs5, rbs6, rbs7, rbs8 = (RuneHero_Char.l/512) + ((RuneHero_Char.r/512)/curwidth) , 0, (RuneHero_Char.l/512) + ((RuneHero_Char.r/512)/curwidth) , 1, 0, 0, 0 , 1
				elseif RuneHero_Char.flipx == false and RuneHero_Char.flipy == true then 
	   			rb1, rb2, rb3, rb4, rb5, rb6, rb7, rb8 = 0, 1, 0, 0, 1, 1, 1, 0;                                             
	 				rbs1, rbs2, rbs3, rbs4, rbs5, rbs6, rbs7, rbs8 = 0, 1, 0, 0, (RuneHero_Char.l/512) + ((RuneHero_Char.r/512)/curwidth), 1, (RuneHero_Char.l/512) + ((RuneHero_Char.r/512)/curwidth), 0
				elseif RuneHero_Char.flipx == false and RuneHero_Char.flipy == false then 
	   			rb1, rb2, rb3, rb4, rb5, rb6, rb7, rb8 = 0, 0, 0, 1, 1, 0, 1, 1;                                             
	 				rbs1, rbs2, rbs3, rbs4, rbs5, rbs6, rbs7, rbs8 = 0, 0, 0, 1, (RuneHero_Char.l/512) + ((RuneHero_Char.r/512)/curwidth), 0, (RuneHero_Char.l/512) + ((RuneHero_Char.r/512)/curwidth), 1
				end
  			local olpoint, olrelativeTo, olrelativePoint, olxOfs, olyOfs = RuneBladeStatusBar:GetPoint(0)
  			    RuneBlade:SetTexCoord(rb1, rb2, rb3, rb4, rb5, rb6, rb7, rb8)
  			    RuneBladeStatusBar:Hide();
-- normal
				if RHangle == "0" then 
					if RuneHero_Char.flipx == false then 
						RuneBladeStatusBar:SetPoint(olpoint, olrelativeTo, olrelativePoint, 0 - ((256 + (RuneHero_Char.l/2)) - (RuneHero_Char.l + (RuneHero_Char.r/curwidth)/2)), 0) 
  			    RuneBladeStatusBar:SetTexCoord(rbs1, rbs2, rbs3, rbs4, rbs5, rbs6, rbs7, rbs8)
  			    RuneBladeStatusBar:SetWidth(RuneHero_Char.l + (RuneHero_Char.r/curwidth))
					else
						RuneBladeStatusBar:SetPoint(olpoint, olrelativeTo, olrelativePoint, 0 + ((256 + (RuneHero_Char.l/2)) - (RuneHero_Char.l + (RuneHero_Char.r/curwidth)/2)), 0) 
  			    RuneBladeStatusBar:SetTexCoord(rbs1, rbs2, rbs3, rbs4, rbs5, rbs6, rbs7, rbs8)
  			    RuneBladeStatusBar:SetWidth(RuneHero_Char.l + (RuneHero_Char.r/curwidth))
				  end
-- pointing up
				elseif RHangle == "90" then 
					if RuneHero_Char.flipx == false then 
						RuneBladeStatusBar:SetPoint(olpoint, olrelativeTo, olrelativePoint, 0,  0 - ((256 + (RuneHero_Char.l/2)) - (RuneHero_Char.l + (RuneHero_Char.r/curwidth)/2))) 
  			    RuneBladeStatusBar:SetTexCoord(rbs1, rbs2, rbs3, rbs4, rbs5, rbs6, rbs7, rbs8)
  			    RuneBladeStatusBar:SetWidth(RuneHero_Char.l + (RuneHero_Char.r/curwidth))
					else
						RuneBladeStatusBar:SetPoint(olpoint, olrelativeTo, olrelativePoint, 0,  0 + ((256 + (RuneHero_Char.l/2)) - (RuneHero_Char.l + (RuneHero_Char.r/curwidth)/2))) 
  			    RuneBladeStatusBar:SetTexCoord(rbs1, rbs2, rbs3, rbs4, rbs5, rbs6, rbs7, rbs8)
  			    RuneBladeStatusBar:SetWidth(RuneHero_Char.l + (RuneHero_Char.r/curwidth))
				  end
-- pointing left
				elseif RHangle == "180" then 
					if RuneHero_Char.flipx == true then 
						RuneBladeStatusBar:SetPoint(olpoint, olrelativeTo, olrelativePoint, 0 - ((256 + (RuneHero_Char.l/2)) - (RuneHero_Char.l + (RuneHero_Char.r/curwidth)/2)), 0) 
  			    RuneBladeStatusBar:SetTexCoord(rbs1, rbs2, rbs3, rbs4, rbs5, rbs6, rbs7, rbs8)
  			    RuneBladeStatusBar:SetWidth(RuneHero_Char.l + (RuneHero_Char.r/curwidth))
					else
						RuneBladeStatusBar:SetPoint(olpoint, olrelativeTo, olrelativePoint, 0 + ((256 + (RuneHero_Char.l/2)) - (RuneHero_Char.l + (RuneHero_Char.r/curwidth)/2)), 0) 
  			    RuneBladeStatusBar:SetTexCoord(rbs1, rbs2, rbs3, rbs4, rbs5, rbs6, rbs7, rbs8)
  			    RuneBladeStatusBar:SetWidth(RuneHero_Char.l + (RuneHero_Char.r/curwidth))
				  end
-- pointing down
				elseif RHangle == "270" then 
					if RuneHero_Char.flipx == true then 
						RuneBladeStatusBar:SetPoint(olpoint, olrelativeTo, olrelativePoint, 0,  0 - ((256 + (RuneHero_Char.l/2)) - (RuneHero_Char.l + (RuneHero_Char.r/curwidth)/2))) 
  			    RuneBladeStatusBar:SetTexCoord(rbs1, rbs2, rbs3, rbs4, rbs5, rbs6, rbs7, rbs8)
  			    RuneBladeStatusBar:SetWidth(RuneHero_Char.l + (RuneHero_Char.r/curwidth))
					else
						RuneBladeStatusBar:SetPoint(olpoint, olrelativeTo, olrelativePoint, 0,  0 + ((256 + (RuneHero_Char.l/2)) - (RuneHero_Char.l + (RuneHero_Char.r/curwidth)/2))) 
  			    RuneBladeStatusBar:SetTexCoord(rbs1, rbs2, rbs3, rbs4, rbs5, rbs6, rbs7, rbs8)
  			    RuneBladeStatusBar:SetWidth(RuneHero_Char.l + (RuneHero_Char.r/curwidth))
				  end
  			end
RuneBladeStatusBar:Show();
	end
	runePowerStatusBarText:SetTextColor(RuneHero_Char.txr,RuneHero_Char.txg,RuneHero_Char.txb);
	runePowerStatusBarText:SetPoint("TOPLEFT", RuneBlade, "TOPLEFT", RuneHero_Char.tx, RuneHero_Char.ty );
	  if RuneHero_Char.Hide == true then RuneFrame:Hide() else RuneFrame:Show() end

	if ( power > 0) then
		runePowerStatusBarText:SetText( power );
		
	else
		runePowerStatusBarText:SetText( nil );
	end

end

function RuneFrameC_OnEvent (self, event, ...)
	if ( event == "COMBAT_LOG_EVENT" ) and arg7 == UnitName("player") then
		for i = 1, RHProcs do
		if (arg10 == RHProc[i].buff )   then
			if ( arg2 == "SPELL_AURA_APPLIED") then
				RuneBlade:SetTexture(RuneHero_Char.proc);
			elseif (arg2=="SPELL_AURA_REMOVED") then
				RuneBlade:SetTexture(RuneHero_Char.main);
			end
		end
	end
	elseif ( event == "PLAYER_ENTERING_WORLD" ) then
		for rune in next, self.runes do
			RuneButtonC_Update(self.runes[rune], rune);
		end
		RunePower_Event();

	elseif ( event == "RUNE_TYPE_UPDATE" ) then
		for rune in next, self.runes do
			RuneButtonC_Update(self.runes[rune], rune);
		end

	elseif ( event == "RUNE_POWER_UPDATE" ) then
		RunePower_Event();

	elseif ( event == "RUNE_REGEN_UPDATE" ) then
		RunePower_Event();

	elseif ( event == "VARIABLES_LOADED" ) then
			-- Disable rune frame if not a death knight.
	local _, class = UnitClass("player");
	
	if ( class ~= "DEATHKNIGHT" ) then
		self:Hide();
		RuneButtonIndividual1C:Hide();
		RuneButtonIndividual2C:Hide();
		RuneButtonIndividual3C:Hide();
		RuneButtonIndividual4C:Hide();
		RuneButtonIndividual5C:Hide();
		RuneButtonIndividual6C:Hide();
	end
	RuneHero_LoadDefaults();
	    LibSimpleOptions.AddOptionsPanel("RuneHero", function(self) RHOptions(self, anchor) end)

		RuneHero_SetLevels();

		if (RuneHero_Saved.scrollWidth == nil or RuneHero_Saved.scrollWidth < 0) then
			RuneHero_Saved.scrollWidth = 260;
		end
    -- RuneHero_ChangeTemplate(RuneHero_Char.template);
		RuneBlade:SetTexture(RuneHero_Char.main);
	  RuneBladeStatusBar:SetTexture(RuneHero_Char.overlay);
    RuneFrameC:ClearAllPoints();
		RuneFrameC:SetPoint(RuneHero_Saved.anchor, RuneHero_Saved.parent,RuneHero_Saved.rel,RuneHero_Saved.x,RuneHero_Saved.y);
		if RuneHero_Saved.scale > 1 then RuneHero_Saved.scale = RuneHero_Saved.scale/10 end
		RuneFrameC:SetScale(RuneHero_Saved.scale);
		local RuneFrameA = RuneFrameC:CreateAnimationGroup()
		RHRotate=RuneFrameA:CreateAnimation("Rotation")
		value = RuneHero_Char.rotation 
		if value == 0 then xvalue = 90 
		elseif value == 90 then xvalue = 0 
		elseif value == 180 then xvalue = 270
		elseif value == 270 then xvalue = 180
		end
		RHRotate:SetDegrees(xvalue)
		RHRotate:SetDuration(0.00001)
		RHRotate:SetEndDelay(800000000)
		RHRotate:Play();
		-- RuneHero_ButtonScale(RuneHero_Saved.scale);
	end
end

function RuneFrameC_AddRune(runeFrameC, rune)
	tinsert(runeFrameC.runes, rune);
end

function RuneFrameC_OnDragStart()
	RuneFrameC:StartMoving();
end

function RuneFrameC_OnDragStop()
	RuneHero_Saved.anchor = "CENTER";
	RuneHero_Saved.parent = "UIParent";
	RuneHero_Saved.rel = "BOTTOMLEFT";
	RuneHero_Saved.x = RuneFrameC:GetLeft() + 256;
	RuneHero_Saved.y = RuneFrameC:GetBottom() + 128;
	RuneFrameC:ClearAllPoints() 
	RuneFrameC:SetPoint(RuneHero_Saved.anchor, RuneHero_Saved.parent,RuneHero_Saved.rel,RuneHero_Saved.x,RuneHero_Saved.y) 
	

	if RHSavedX then 
		RHSavedX:SetText(string.format("%.1f", RuneHero_Saved.x))
		RHSavedY:SetText(string.format("%.1f", RuneHero_Saved.y))
	end
	RuneFrameC:StopMovingOrSizing();

	RuneHero_SetLevels();
end

function RuneHero_ButtonScale(scale)
	RuneButtonIndividual1C:SetScale(scale);
	RuneButtonIndividual2C:SetScale(scale);
	RuneButtonIndividual3C:SetScale(scale);
	RuneButtonIndividual4C:SetScale(scale);
	RuneButtonIndividual5C:SetScale(scale);
	RuneButtonIndividual6C:SetScale(scale);
end

function RuneHero_SetLevels()

	RuneFrameC:SetFrameLevel(1);

	RuneFrameC.runes[1]:SetFrameLevel(20);
	RuneFrameC.runes[1]:SetFrameLevel(21);

	RuneFrameC.runes[2]:SetFrameLevel(30);
	RuneFrameC.runes[2]:SetFrameLevel(31);

	RuneFrameC.runes[3]:SetFrameLevel(40);
	RuneFrameC.runes[3]:SetFrameLevel(41);

	RuneFrameC.runes[4]:SetFrameLevel(50);
	RuneFrameC.runes[4]:SetFrameLevel(51);

	RuneFrameC.runes[5]:SetFrameLevel(60);
	RuneFrameC.runes[5]:SetFrameLevel(61);

	RuneFrameC.runes[6]:SetFrameLevel(70);
	RuneFrameC.runes[6]:SetFrameLevel(71);

end

function RuneHero_LoadDefaults() 
	if (RuneHero_Saved.anchor == nil) then
		RuneHero_Saved.anchor = "CENTER";
	end
	if (RuneHero_Saved.parent == nil) then
		RuneHero_Saved.parent = "UIParent";
	end
	if (RuneHero_Saved.rel == nil) then
		RuneHero_Saved.rel = "BOTTOM";
	end
	if (RuneHero_Saved.x == nil) then
		RuneHero_Saved.x = 0;
	end
	if (RuneHero_Saved.y == nil) then
		RuneHero_Saved.y = 135;
	end
	if (RuneHero_Saved.scale == nil) then
		RuneHero_Saved.scale = .7;
	end
	if (RuneHero_Saved.runeX == nil) then
		RuneHero_Saved.runeX = 65;
	end
	if (RuneHero_Saved.scrollWidth == nil) then
		RuneHero_Saved.scrollWidth = 260;
	end
	if (RuneHero_Saved.Locked == nil) then 
		RuneHero_Saved.Locked = true;
	elseif (RuneHero_Saved.Locked == false) then
			RuneButtonIndividual1C:SetMovable(true);
		RuneButtonIndividual1C:RegisterForDrag('LeftButton');
		RuneButtonIndividual1C:SetScript('OnDragStart', RuneFrameC_OnDragStart );
		RuneButtonIndividual1C:SetScript('OnDragStop', RuneFrameC_OnDragStop );
		RuneFrameC:SetClampedToScreen(true);
		DEFAULT_CHAT_FRAME:AddMessage(" RuneHero unlocked. Click on the top rune icon to drag.");
	end
	if (RuneHero_Char.template == nil) then 
		RuneHero_Char.template = 1
	end
	if (RuneHero_Char.flipx == nil) then 
		RuneHero_Char.flipx = false
	end
	if (RuneHero_Char.flipy == nil) then 
		RuneHero_Char.flipy = false
	end
	if (RuneHero_Char.rotation == nil) then 
		RuneHero_Char.rotation = 90
	end
	
	if (RuneHero_Char.blood1gfx == nil) then 
		RuneHero_Char.blood1gfx = "Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Blood"
	end
	if (RuneHero_Char.blood2gfx == nil) then 
		RuneHero_Char.blood2gfx = "Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Blood"
	end
	if (RuneHero_Char.unholy1gfx == nil) then 
		RuneHero_Char.unholy1gfx = "Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Unholy"
	end
	if (RuneHero_Char.unholy2gfx == nil) then 
		RuneHero_Char.unholy2gfx = "Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Unholy"
	end
	if (RuneHero_Char.frost1gfx == nil) then 
		RuneHero_Char.frost1gfx = "Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Frost"
	end
	if (RuneHero_Char.frost2gfx == nil) then 
		RuneHero_Char.frost2gfx = "Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Frost"
	end
	if (RuneHero_Char.death1gfx == nil) then 
		RuneHero_Char.death1gfx = "Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Death"
	end
	if (RuneHero_Char.death1gfx == nil) then 
		RuneHero_Char.death1gfx = "Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Death"
	end
	if (RuneHero_Char.death2gfx == nil) then 
		RuneHero_Char.death2gfx = "Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Death"
	end
	if (RuneHero_Char.death3gfx == nil) then 
		RuneHero_Char.death3gfx = "Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Death"
	end
	if (RuneHero_Char.death4gfx == nil) then 
		RuneHero_Char.death4gfx = "Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Death"
	end
	if (RuneHero_Char.death5gfx == nil) then 
		RuneHero_Char.death5gfx = "Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Death"
	end
	if (RuneHero_Char.death6gfx == nil) then 
		RuneHero_Char.death6gfx = "Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Death"
	end
	if (RuneHero_Char.b1x == nil) then RuneHero_Char.b1x = 105 end
	if (RuneHero_Char.b1y == nil) then RuneHero_Char.b1y = -70 end
	if (RuneHero_Char.b1d == nil) then RuneHero_Char.b1d = '1' end
	if (RuneHero_Char.b1l == nil) then RuneHero_Char.b1l = 300 end
	if (RuneHero_Char.b2x == nil) then RuneHero_Char.b2x = 105 end
	if (RuneHero_Char.b2y == nil) then RuneHero_Char.b2y = -90 end
	if (RuneHero_Char.b2d == nil) then RuneHero_Char.b2d = '1' end
	if (RuneHero_Char.b2l == nil) then RuneHero_Char.b2l = 300 end
	if (RuneHero_Char.f1x == nil) then RuneHero_Char.f1x = 105 end
	if (RuneHero_Char.f1y == nil) then RuneHero_Char.f1y = -110 end
	if (RuneHero_Char.f1d == nil) then RuneHero_Char.f1d = '1' end
	if (RuneHero_Char.f1l == nil) then RuneHero_Char.f1l = 300 end
	if (RuneHero_Char.f2x == nil) then RuneHero_Char.f2x = 105 end
	if (RuneHero_Char.f2y == nil) then RuneHero_Char.f2y = -130 end	
	if (RuneHero_Char.f2d == nil) then RuneHero_Char.f2d = '1' end
	if (RuneHero_Char.f2l == nil) then RuneHero_Char.f2l = 300 end
	if (RuneHero_Char.u1x == nil) then RuneHero_Char.u1x = 105 end
	if (RuneHero_Char.u1y == nil) then RuneHero_Char.u1y = -150 end
	if (RuneHero_Char.u1d == nil) then RuneHero_Char.u1d = '1' end
	if (RuneHero_Char.u1l == nil) then RuneHero_Char.u1l = 300 end
	if (RuneHero_Char.u2x == nil) then RuneHero_Char.u2x = 105 end
	if (RuneHero_Char.u2y == nil) then RuneHero_Char.u2y = -170 end	
	if (RuneHero_Char.u2d == nil) then RuneHero_Char.u2d = '1' end
	if (RuneHero_Char.u2l == nil) then RuneHero_Char.u2l = 300 end
	if (RuneHero_Char.tx == nil) then 
		RuneHero_Char.tx = 0
	end
	if (RuneHero_Char.ty == nil) then 
		RuneHero_Char.ty = 0
	end
	if (RuneHero_Char.txr == nil) then 
		RuneHero_Char.txr = .6
	end
	if (RuneHero_Char.txg == nil) then 
		RuneHero_Char.txg = .9
	end
	if (RuneHero_Char.txb == nil) then 
		RuneHero_Char.txb = .1
	end
	if (RuneHero_Char.txa == nil) then 
		RuneHero_Char.txa = 1
	end

end


function RuneHero_SlashCommand(cmd)

	if( cmd == 'bottom' ) then
		RuneFrameC:ClearAllPoints();
		RuneFrameC:SetPoint("CENTER", UIParent, "BOTTOM", 0, 155/RuneFrameC:GetScale() );

		RuneHero_Saved.anchor = "CENTER";
		RuneHero_Saved.parent = "UIParent";
		RuneHero_Saved.rel = "BOTTOM";
		RuneHero_Saved.x = 0;
		RuneHero_Saved.y = 155/RuneFrameC:GetScale();
	if RHSavedX then 
		RHSavedX:SetText(string.format("%.1f", RuneHero_Saved.x))
		RHSavedY:SetText(string.format("%.1f", RuneHero_Saved.y))
	end

	elseif ( cmd == 'player' ) then
		RuneFrameC:ClearAllPoints();
		RuneFrameC:SetPoint("CENTER", "PlayerFrame", "BOTTOMLEFT", 0 ,-80);

		RuneHero_Saved.anchor = "CENTER";
		RuneHero_Saved.parent = "PlayerFrame";
		RuneHero_Saved.rel = "BOTTOMLEFT";
		RuneHero_Saved.x = 0;
		RuneHero_Saved.y = -80;
	if RHSavedX then 
		RHSavedX:SetText(string.format("%.1f", RuneHero_Saved.x))
		RHSavedY:SetText(string.format("%.1f", RuneHero_Saved.y))
	end

	elseif (cmd == 'lock' ) then
		RuneButtonIndividual1C:SetMovable(false);
		RuneButtonIndividual1C:RegisterForDrag(nil);
		RuneButtonIndividual1C:SetScript('OnDragStart', nil );
		RuneFrameC:SetClampedToScreen(true);
		DEFAULT_CHAT_FRAME:AddMessage(" RuneHero locked.");
    RuneHero_Saved.Locked = true
	elseif ( cmd == 'unlock' ) then
		RuneButtonIndividual1C:SetMovable(true);
		RuneButtonIndividual1C:RegisterForDrag('LeftButton');
		RuneButtonIndividual1C:SetScript('OnDragStart', RuneFrameC_OnDragStart );
		RuneButtonIndividual1C:SetScript('OnDragStop', RuneFrameC_OnDragStop );
		RuneFrameC:SetClampedToScreen(true);
		DEFAULT_CHAT_FRAME:AddMessage(" RuneHero unlocked. Click on the top rune icon to drag.");
		RuneHero_Saved.Locked = false
		
	elseif (strsub(cmd,1,4) == 'size') then
		local scaleParam = tonumber(strsub(cmd,6));
		if ( scaleParam == nil ) then
			scaleParam = .7;
		else
			scaleParam = scaleParam/100;
		end
			RuneFrameC:SetScale(scaleParam);
			RuneHero_Saved.scale = scaleParam;
	elseif ( strsub(cmd,1,6) == 'offset') then
		local offset = tonumber(strsub(cmd,8));
		if (offset ~= nil) then
			RuneHero_Saved.runeX = offset;
		else 
			DEFAULT_CHAT_FRAME:AddMessage(" RuneHero: Offset must be a number.");
		end
	elseif ( strsub(cmd,1,5) == 'width') then
		local width = tonumber(strsub(cmd,7));
		if (width ~= nil) then
			RuneHero_Saved.scrollWidth = width;
		else 
			DEFAULT_CHAT_FRAME:AddMessage(" RuneHero: Width must be a number.");
		end
	else
		DEFAULT_CHAT_FRAME:AddMessage(" RuneHero Optional Commands: 'bottom', 'player', 'lock', 'unlock', 'size <1-300%>', 'width <#>', 'offset <#>' .");
    InterfaceOptionsFrame_OpenToCategory("RuneHero")
	end	
end



-- Slash Command Support
SLASH_RUNEHERO1 = "/runehero";
SLASH_RUNEHERO2 = "/rh";



SlashCmdList["RUNEHERO"] = RuneHero_SlashCommand;
