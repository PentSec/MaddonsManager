if ( GetLocale() == "frFR" ) then

QA_ADVMSG = "J'ai $NumItems $ItemName. Il m'en faut $NumNeeded... plus que $NumLeft.";
QA_FINMSG = "$ItemName : $NumItems / $NumNeeded. Fini !";

QA_LOADED = " Charg�";

QA_CHAT_MSG_RESET = "Les r�glages de QuestAnnounce ont �t� remis par d�faut";
QA_CHAT_MSG_VERSION = "QuestAnnouce : Aide pour la version ";

QA_CHAT_MSG_CMD = "/qa ou /questannounce suivi de";
QA_CHAT_MSG_CMD_STATUS = " status vous indiquera le r�glage actif";
QA_CHAT_MSG_CMD_ON = " on activera questannounce";
QA_CHAT_MSG_CMD_OFF = " off d�sactivera questannounce";
QA_CHAT_MSG_CMD_CLASSIC = " classic mettra questannounce en mode classique et s'activera si il est d�sactiv�";
QA_CHAT_MSG_CMD_STD = " std activera les valeurs par d�faut";
QA_CHAT_MSG_CMD_EVERYNUM = " every [num] fera une annonce tous les [num] objets r�cup�r�s";
QA_CHAT_MSG_CMD_CONFIG = " config ouvrira une fen�tre de configuration";
QA_CHAT_MSG_CMD_PAUSE = " pause will disable the questannounce until you select resume or reload the ui. Not saved";
QA_CHAT_MSG_CMD_RESUME = " resume will resume the questannounce if paused";


QA_CHAT_MSG_CLASSIC = "QuestAnnounce : Mode classique charg�";
QA_CHAT_MSG_OFF = "QuestAnnounce est inactif";
QA_CHAT_MSG_OFF2 = "QuestAnnounce inactif";
QA_CHAT_MSG_ON = "QuestAnnounce est actif";
QA_CHAT_MSG_ON2 = "QuestAnnounce actif";

end