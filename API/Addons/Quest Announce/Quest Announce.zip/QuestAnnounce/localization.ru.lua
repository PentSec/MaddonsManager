if ( GetLocale() == "ruRU" ) then



QA_ADVMSG = "$NumItems из NumNeeded $ItemName. осталось $NumLeft";
QA_FINMSG = "Завершено $ItemName. $NumItems/$NumNeeded";

QA_LOADED = " Загружен";

QA_CHAT_MSG_RESET = "QuestAnnounce настройки сброшены.";
QA_CHAT_MSG_VERSION = "QuestAnnouce help показать версию";

QA_CHAT_MSG_CMD = "/qa or /questannounce со следующими командами";
QA_CHAT_MSG_CMD_STATUS = " status показать текущее состояние";
QA_CHAT_MSG_CMD_ON = " on запустить работу questannounce";
QA_CHAT_MSG_CMD_OFF = " off will остановить работу questannounce";
QA_CHAT_MSG_CMD_CLASSIC = " classic перевод questannounce в классический режим и замустить его если был остановлен";
QA_CHAT_MSG_CMD_STD = " std сбросить настройки questannounce";
QA_CHAT_MSG_CMD_EVERYNUM = " every [число] сообщать каждые [число] собранных элементов";
QA_CHAT_MSG_CMD_CONFIG = " config открыть окно конфигурации";
QA_CHAT_MSG_CMD_PAUSE = " pause приостановить работу questannounce. Возобновить командой resume или перезагрузить интерфейс. Не сохранияется";
QA_CHAT_MSG_CMD_RESUME = " resume возобновляет приостановленную работу questannounce ";

 

QA_CHAT_MSG_CLASSIC = "QuestAnnounce классические настройки загружены";
QA_CHAT_MSG_OFF = "QuestAnnounce отключен";
QA_CHAT_MSG_OFF2 = "QuestAnnounce не работает";
QA_CHAT_MSG_ON = "QuestAnnounce включен";
QA_CHAT_MSG_ON2 = "QuestAnnounce работает";

end

