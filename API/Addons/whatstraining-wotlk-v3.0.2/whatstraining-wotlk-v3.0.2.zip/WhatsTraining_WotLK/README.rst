======================
What's Training? WotLK
======================
What's Training? is an backported addon for World of Warcraft 3.3.5 (WotLK) that adds a list of all the spells for your class in a new tab in the spell book.

They are seperated by categories like **Available Now**, **Coming Soon** and similar.

..  figure:: https://i.imgur.com/XLL83Ll.png
    :alt: What's Training Example Screenshot
    :target: https://i.imgur.com/XLL83Ll.png
    
    What's Training Example Screenshoot

Known Issues/TODO
_________________
 - TODO: Finish the code documentation
 - BUG: The frame sometimes freeze or duplicate. Currently resolved by doing a /reload
 
