--[[Author:		Cyprias 
	License:	All Rights Reserved
	Contact:	Cyprias on Curse.com or WowAce.com

	Only Curse.com and Wowace.com have permission to host this addon.
	I have not given permission for Dimmed Actions to be used in any addon compilation or UI pack.]]

-- GLOBAL --
DA = select(2, ...) 
-- MODULE --
local _G = getfenv(0)
setmetatable(DA, {__index = _G})
setfenv(1, DA)
-- LOCAL --
title		= "Dimmed Actions"
folder		= "DimmedActions"
version		= GetAddOnMetadata(folder, "X-Curse-Packaged-Version") or ""
titleFull	= title.." "..version

coreFrame = CreateFrame("Frame")
core	= LibStub("AceAddon-3.0"):NewAddon(coreFrame, title, "AceConsole-3.0", "AceEvent-3.0", "AceHook-3.0") -- 
local L = LibStub("AceLocale-3.0"):GetLocale(title, true)

local P --db.profile

--Echo strings
local strDebugFrom		= "|cffffff00[%s]|r" --Yellow function name. help pinpoint where the debug msg is from.
local strWhiteBar		= "|cffffff00 || |r" -- a white bar to seperate the debug info.

-- global API
local ActionHasRange_		= _G.ActionHasRange
local BOOKTYPE_SPELL		= _G.BOOKTYPE_SPELL
local GetActionInfo_		= _G.GetActionInfo
local GetMacroInfo_			= _G.GetMacroInfo
local GetSpellCooldown_		= _G.GetSpellCooldown
local GetSpellLink_			= _G.GetSpellLink
local GetSpellName_			= _G.GetSpellName
local GetTime_				= _G.GetTime
local HasAction_			= _G.HasAction
local InCombatLockdown_		= _G.InCombatLockdown
local IsActionInRange_		= _G.IsActionInRange
local IsAltKeyDown_			= _G.IsAltKeyDown
local IsUsableAction_		= _G.IsUsableAction
local SecureCmdOptionParse_	= _G.SecureCmdOptionParse
local UnitAffectingCombat_	= _G.UnitAffectingCombat
local UnitBuff_				= _G.UnitBuff
local UnitDebuff_			= _G.UnitDebuff
local UnitExists_			= _G.UnitExists
local UnitIsEnemy_			= _G.UnitIsEnemy
local pairs					= _G.pairs
local print					= _G.print
local table_getn			= _G.table.getn
local table_insert			= _G.table.insert
local table_sort			= _G.table.sort
local tostring				= _G.tostring
local tonumber				= _G.tonumber
local GetMacroBody_			= _G.GetMacroBody
local SpellHasRange_ 		= _G.SpellHasRange
local GetMacroSpell_		= _G.GetMacroSpell

--don't touch.
myTooltip = CreateFrame("GameTooltip", "DA_ToolTip", UIParent, "GameTooltipTemplate")
BT4	= false --Is bartender running? this gets set in OnEnable()
Dominos = false
spellNames = {}--spellname to IDs.
hookedButtons = {}
barOpts		= false --needed for bar display options.
coreOpts	= false
existsOpts	= false
stackOpts	= false

local handerFrames = {}

local regEvents = {
	"ACTIONBAR_SLOT_CHANGED",
	"PLAYER_REGEN_DISABLED",
	"PLAYER_REGEN_ENABLED",
}

local targetSpells = {--spells that can be cast on other people.
	[L["the target"]] = true,
	[L["the enemy"]] = true,
	[L["enemy target"]] = true,
	[L["friendly target"]] = true,
	[L["friendly party"]] = true,
}

--Default Settings
db				= {}
defaultSettings	= {profile = {}}
defaultSettings.profile.updateFrequency	= 0.25
--~ defaultSettings.profile.dimAlpha		= 0.2 --20%
defaultSettings.profile.showAlt			= true
defaultSettings.profile.showNoTarget	= true
defaultSettings.profile.dimCombatOnly			= true
defaultSettings.profile.dimNoMana				= false
defaultSettings.profile.dimUnuseableOntarget	= true
defaultSettings.profile.dimOutOfRange			= true
defaultSettings.profile.dimSpellExists			= true
defaultSettings.profile.dimMacros				= true
defaultSettings.profile.dimCooldown				= true
defaultSettings.profile.blockOtherColours		= true


--colours
defaultSettings.profile.colours = {}
defaultSettings.profile.colours.range			= {r=1,g=0,b=0,a=0.25}	--red, 25% alpha
defaultSettings.profile.colours.unusable		= {r=1,g=1,b=1,a=0.25}	--white, 25%
defaultSettings.profile.colours.mana			= {r=0,g=0,b=1,a=0.25}	--mana, 25%
defaultSettings.profile.colours.cooldown		= {r=1,g=1,b=1,a=0.25}	--white, 25%
defaultSettings.profile.colours.exists			= {r=0,g=1,b=0,a=0.25}	--green, 25%

--bars
defaultSettings.profile.barsBar1				= true
defaultSettings.profile.barsBonusBar1			= true
defaultSettings.profile.barsMultiBarBottomLeft	= true--above your main action bar
defaultSettings.profile.barsMultiBarBottomRight	= false--above your packs
defaultSettings.profile.barsMultiBarRight		= false--vertical bar on right side of screen.
defaultSettings.profile.barsMultiBarLeft		= false--left of ^ bar.

--BT4 Optinos
defaultSettings.profile.barsBT4Bar1		= true
defaultSettings.profile.barsBT4Bar2		= true
defaultSettings.profile.barsBT4Bar3		= true
defaultSettings.profile.barsBT4Bar4		= true
defaultSettings.profile.barsBT4Bar5		= true
defaultSettings.profile.barsBT4Bar6		= true
defaultSettings.profile.barsBT4Bar7		= true
defaultSettings.profile.barsBT4Bar8		= true
defaultSettings.profile.barsBT4Bar9		= true
defaultSettings.profile.barsBT4Bar10	= true


--dominos options.
defaultSettings.profile.dominos = {}

-- Ace3 Functions
function core:OnInitialize()
	db = LibStub("AceDB-3.0"):New("DA_DB", defaultSettings, true)
	CoreOptionsTable.args.profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(db)--save option profile or load another chars opts.

	db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
	db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
	db.RegisterCallback(self, "OnProfileReset", "OnProfileChanged")
	db.RegisterCallback(self, "OnProfileDeleted", "OnProfileChanged")

	
	
	core:RegisterChatCommand("da", "MySlashProcessorFunc")
	
	local config = LibStub("AceConfig-3.0")
	local dialog = LibStub("AceConfigDialog-3.0")
	
	config:RegisterOptionsTable(title, CoreOptionsTable)
	coreOpts = dialog:AddToBlizOptions(title, "DA "..version)
	
	config:RegisterOptionsTable(title.."Bars", BarOptionsTable)
	barOpts = dialog:AddToBlizOptions(title.."Bars", L["Bars"], "DA "..version)
	
	config:RegisterOptionsTable(title.."Colours", ColourOptionsTable)
	colourOpts = dialog:AddToBlizOptions(title.."Colours", L["Colours"], "DA "..version)
	
	config:RegisterOptionsTable(title.."SE", SpellExistOptionsTable)
	existsOpts = dialog:AddToBlizOptions(title.."SE", L["Spell Exists"], "DA "..version)
	
	config:RegisterOptionsTable(title.."SC", StackCountOptionsTable)
	
--~ 	hooksecurefunc("SecureHandlerSetFrameRef", core.SecureHandlerSetFrameRef)
	self:Hook("SecureHandlerSetFrameRef", true, nil, true)
	
end

----------------------------------------------------------------------------------------------------------
function core:SecureHandlerSetFrameRef(frame, label, refFrame)											--
-- Macrotexter and another addon I'm working on uses this function.										--
-- I don't know where else to get a frame's header frame so I'm hooking this function and saving it.	--
----------------------------------------------------------------------------------------------------------
--~ 	Debug("SecureHandlerSetFrameRef", "frame:"..tostring(frame and frame:GetName()), "label:"..tostring(label), "refFrame:"..tostring(refFrame and refFrame:GetName()))
	
	handerFrames[frame] = {
		label=label, 
		refFrame = refFrame
	}
end

----------------------------------------------
function core:MySlashProcessorFunc(input)	--
-- /da function brings up the UI options.	--
----------------------------------------------
	InterfaceOptionsFrame_OpenToCategory(barOpts)
	InterfaceOptionsFrame_OpenToCategory(coreOpts)
end

function core:OnEnable()
	P = db.profile
	
	for i, event in pairs(regEvents) do 
		core:RegisterEvent(event)
	end
	
	if _G.Bartender4 then
		BT4 = true
		AddBT4Options()
	elseif _G.Dominos then
		Dominos = true
		AddDominosOptions()
	else
		--Hook when the bonus bars show and hide so we hook bonus actions.
		if BonusActionBarFrame:HasScript("OnShow") and not core:IsHooked(BonusActionBarFrame, "OnShow") then
			core:HookScript(BonusActionBarFrame, "OnShow", function(self) 
				HookBonusActions()
			end)
		end

		if BonusActionBarFrame:HasScript("OnHide") and not core:IsHooked(BonusActionBarFrame, "OnHide") then
			core:HookScript(BonusActionBarFrame, "OnHide", function(self) 
				UnhookBonusActions()
			end)
		end
	end
	
	CollectActionInfo()
	if P.dimCombatOnly == false then
		HookActionButtons()
	end
end

function testHook()--	/script DA.testHook()
	local self = GetMouseFocus()
	HookVertexColour(self)
	local name = self:GetName()
	local icon = _G[name.."Icon"]
	icon:SetVertexColor(0,1,0,nil,true)
end

------------------------------------------------------
function HookVertexColour(button)					--
-- We hook the SetVertexColor function so we can	--
-- block other addons from colouring the actions.	--
-- This is optional.								--
------------------------------------------------------
	local name = button:GetName()
	local icon = _G[name.."Icon"]
	if icon and not core:IsHooked(icon, "SetVertexColor") then
		core:RawHook(icon, "SetVertexColor", nil, true)
	end
end

----------------------------------------------------------------------------------------------------------------------
function core:SetVertexColor(frame, ...)																			--
-- Our SetVertexColor hook. When we call it we add a 5th var to varifiy it's our call. We block all other calls.	--
-- This is done so that Bartender's built in range/mana colouring doesn't fight with us.							--
----------------------------------------------------------------------------------------------------------------------
	local red, green, blue, alpha, ours = ...
	if ours == true then
		core.hooks[frame].SetVertexColor(frame, ...)
	end
end

----------------------------------------------------------------------
function core:OnProfileChanged(...)									--
-- User has reset proflie, so we reset our spell exists options.	--
----------------------------------------------------------------------
--~ 	local whatHappen, info = ...
	
	-- Shut down anything left from previous settings
	self:Disable()
	-- Enable again with the new settings
	self:Enable()
end


function core:OnDisable()
	-- I know when ace addons are disabled their hooks are released, these functions return the actions to 100% alpha.
	UnhookAllBars()
end

function LocalTest()--	/script DA.LocalTest()
	print( L["Test"] )
end



function DominosTest()--	/script DA.DominosTest()
	local self = GetMouseFocus()
	local parent = self:GetParent()
	Debug("DominosTest", self:GetName())
end

------------------------------
function GetMouseoverInfo()	--	/script DA.GetMouseoverInfo()
-- Used to debug.			--
------------------------------
	local self = GetMouseFocus()--	/script print(GetMouseFocus():GetName().." - "..GetMouseFocus():GetParent():GetName())
	
	
--~ 	local ttt = self:GetAttribute("unit1")
--~ 	print("target: ", ttt)
	
	
--~ 	print("unit: ", SecureButton_GetUnit(self))
	
	Debug("GetMouseoverInfo", self:GetName(), GetMouseFocus():GetParent(), self.action)
	if self.action then
		local actionID = self.action
--~ 	name, iconTexture, body, local = GetMacroInfo(MacroID)
--~ 		local targetID = "target"
		Debug("GetMouseoverInfo", ActionHasRange_(actionID), IsActionInRange_(actionID,targetID))

		local actionType, spellID = GetActionInfo_(actionID)
		Debug("GetMouseoverInfo 1", actionType, spellID)
--~ 		local spellName, spellRank = GetSpellName_( spellID, BOOKTYPE_SPELL )
		if actionType == "macro" then
			local body = GetMacroBody_(spellID)
			
			Debug("Body", body)
			
			Debug("SecureCmdOptionParse", SecureCmdOptionParse_(body))

			Debug("GetMacroSpell", GetMacroSpell_(spellID))
			Debug("GetMacroTarget", GetMacroTarget(spellID))
			Debug("GetMacroItem", GetMacroItem(spellID))
			
		end

--~ 		if spellName then
--~ 			local hasRange = SpellHasRange_(spellName)
--~ 			Debug("GetMouseoverInfo 5", "hasRange: "..tostring(hasRange))
--~ 		end
	end
end
--[[ IsActionInRange_()
	returns 1 if in range
	returns 0 if out of range
	returns nil if in range but can't cast on target (healing on hostile)
]]

function GetMacroTarget(macroID)
	local body = GetMacroBody_(spellID)
	if body then
		local _, target = SecureCmdOptionParse_(body)
		return target
	end
	return nil
end

dominosBars = {
	{name = "ActionButton", start = 1},
	{name = "BonusActionButton", start = 1},
	{name = "MultiBarRightButton", start = 1},
	{name = "MultiBarLeftButton", start = 1},
	{name = "MultiBarBottomRightButton", start = 1},
	{name = "MultiBarBottomLeftButton", start = 1},
	{name = "DominosActionButton", start = 1},
	{name = "DominosActionButton", start = 13},
	{name = "DominosActionButton", start = 25},
	{name = "DominosActionButton", start = 37},
}


--------------------------------------
function HookActionButtons()		--
-- Hook action button's OnUpdate.	--
--------------------------------------
	if BT4 == true then --bartender4's running.
		if P.barsBT4Bar1 == true then
			CheckBT4Bar("BT4Bar1")
		end
		
		if P.barsBT4Bar2 == true then
			CheckBT4Bar("BT4Bar2")
		end
		if P.barsBT4Bar3 == true then
			CheckBT4Bar("BT4Bar3")
		end
		if P.barsBT4Bar4 == true then
			CheckBT4Bar("BT4Bar4")
		end
		if P.barsBT4Bar5 == true then
			CheckBT4Bar("BT4Bar5")
		end
		if P.barsBT4Bar6 == true then
			CheckBT4Bar("BT4Bar6")
		end
		if P.barsBT4Bar7 == true then
			CheckBT4Bar("BT4Bar7")
		end
		if P.barsBT4Bar8 == true then
			CheckBT4Bar("BT4Bar8")
		end
		if P.barsBT4Bar9 == true then
			CheckBT4Bar("BT4Bar9")
		end
		if P.barsBT4Bar10 == true then
			CheckBT4Bar("BT4Bar10")
		end
	elseif Dominos == true then --Dominos' running.
		local barStart = 1
		local barEnd = 12
		local buttonName, buttonObj
		for i=1, table.getn(dominosBars) do 
			if P.dominos["bar"..i] == true then
				barStart = dominosBars[i].start
				barEnd = barStart + 11
				for b = barStart, barEnd do 
					buttonName = dominosBars[i].name..b
					buttonObj = _G[buttonName]
					if buttonObj then
						HookActionButton(buttonObj, "dBar"..i, b)
					end
				end
			end
		end

	else --blizzard bars.
		if BonusActionBarFrame:IsShown() then
			HookBonusActions()
		else
			UnhookBonusActions()
		end
		
		if P.barsMultiBarBottomRight == true then
			for i=1, NUM_ACTIONBAR_BUTTONS, 1 do
				HookActionButton(_G["MultiBarBottomRightButton"..i], "MultiBarBottomRight", i)
			end
		end
		
		if P.barsMultiBarBottomLeft == true then
			for i=1, NUM_ACTIONBAR_BUTTONS, 1 do
				HookActionButton(_G["MultiBarBottomLeftButton"..i], "MultiBarBottomLeft", i)
			end
		end
		
		if P.barsMultiBarRight == true then
			for i=1, NUM_ACTIONBAR_BUTTONS, 1 do
				HookActionButton(_G["MultiBarRightButton"..i], "MultiBarRight", i)
			end
		end
		if P.barsMultiBarLeft == true then
			for i=1, NUM_ACTIONBAR_BUTTONS, 1 do
				HookActionButton(_G["MultiBarLeftButton"..i], "MultiBarLeft", i)
			end
		end
	end
end

------------------------------------------------------------------
function HookBonusActions()										--
--	Here we loop threw bonus action buttons to hook them later.	--
------------------------------------------------------------------
	if P.barsBonusBar1 == true then
		for i=1, NUM_ACTIONBAR_BUTTONS, 1 do
			HookActionButton(_G["BonusActionButton"..i], "BonusBar1", i)
		end

		UnhookBar("Bar1")
		
		--I hide BonusActionBarTexture0 & BonusActionBarTexture1 so I need to hide the buttons underneath too.
		for i=1, NUM_ACTIONBAR_BUTTONS, 1 do
			_G["ActionButton"..i]:SetAlpha(0)
		end
	end

end

------------------------------------------------------
function UnhookBonusActions()						--
-- Loop threw bonus action buttons to onhook them.	--
------------------------------------------------------
	if P.barsBar1 == true then
		for i=1, NUM_ACTIONBAR_BUTTONS, 1 do
			HookActionButton(_G["ActionButton"..i], "Bar1", i)
		end
		UnhookBar("BonusBar1")
	end
end

----------------------------------------------------------------------------------
function CheckBT4Bar(barName)													--
-- Used to hook Bartender4 bars, checks children for buttons then hooks them.	--
----------------------------------------------------------------------------------
	local bar = _G[barName]--"BT4Bar1"
	if bar then
		local kids = { bar:GetChildren() }
		for _, child in ipairs(kids) do
			if child:GetName():find("Button") then
				HookActionButton(child, barName, 0)
			end
		end
--~ 	else
--~ 		Debug("CheckBT4Bar",barName,"doesnt exist")
	end
end

--------------------------------------------------
function HookActionButton(buttonFrame, bar, id)	--
-- Hook a action button's OnUpdate script.		--
--------------------------------------------------
--~ 	Debug("HookActionButton 1", buttonFrame, bar, id)
	if buttonFrame then
		hookedButtons[bar] = hookedButtons[bar] or {}
		if id == 0 then
			id = table.getn(hookedButtons[bar]) + 1
		end
		hookedButtons[bar][id] = buttonFrame
--~ 		Debug("HookActionButton 2", buttonFrame, bar, id)
		
		if buttonFrame:HasScript("OnUpdate") and not core:IsHooked(buttonFrame, "OnUpdate") then
			buttonFrame.daLastUpdate = 0
			core:HookScript(buttonFrame, "OnUpdate", ActionButton_OnUpdate)
--~ 			Debug("HookActionButton 3", buttonFrame, bar, id)
		end
		
		if P.blockOtherColours == true then
			HookVertexColour(buttonFrame)
		end
		
	end
end

--[[
--------------------------------------------------------------
function SpamMissingSpells()								--	/script DA.SpamMissingSpells()
-- Tells user which spells need to be added to their bars	--
-- for macros to work.										--
-- function now obsolete.									--
--------------------------------------------------------------
	local actionID
	local foundMissingSpell = false
	for b=0, 9 do
		for s = 1, 12 do
			actionID = s+(b*12)
			if HasAction_(actionID) then
				local actionType, spellID = GetActionInfo_(actionID)
				if actionType == "macro" then
					local spellName = GetMacroSpell_(spellID)
					if spellName then
						if not spellNames[spellName] then
							foundMissingSpell = true
							local name = GetMacroInfo_(spellID)
							print(L.cannotFindMacroSpell:format(spellName, name))
						end
					end
				end
			end
		end
	end
	if foundMissingSpell == false then
		print("None of the spells in your macros are missing from your action bars. :)")
	end
end
]]

------------------------------------------
function UnhookBar(bar)					--
-- Onhook all actions used by a bar.	--
------------------------------------------
	if hookedButtons[bar] then
--~ 		local icon
		for _, buttonFrame in pairs(hookedButtons[bar]) do 
			if core:IsHooked(buttonFrame, "OnUpdate") then
				core:Unhook(buttonFrame, "OnUpdate")
			end
			
			--reset colour
			UnhookVertexColour(buttonFrame)
			buttonFrame:SetAlpha(1)
		end
	end
end

------------------------------------------------------
function UnhookVertexColour(button)					--
-- Release our hook on SetVertexColor()				--
------------------------------------------------------
	local name = button:GetName()
	local icon = _G[name.."Icon"] or button:GetNormalTexture()
	if icon then
		if core:IsHooked(icon, "SetVertexColor") then
			core:Unhook(icon, "SetVertexColor")
		end
		icon:SetVertexColor(1, 1, 1, nil, true)
	end
end

--------------------------------------------------
function ActionButton_OnUpdate(self, elapsed)	--
-- Our OnUpdate hooked function. 				--
--------------------------------------------------
	self.daLastUpdate = self.daLastUpdate + elapsed
	if self.daLastUpdate >= P.updateFrequency then 
		self.daLastUpdate = 0
		UpdateActionButton(self)
	end
end


------------------------------------------------------------------------------
function CollectActionInfo()												--	/script DA.CollectActionInfo()
-- I save actionID and spellID indexed by spellname to help with macros.	--
-- Since macros don't tell us their spellID or a actionID, I check the 		--
-- spellname to our list and use the known spellID and actionID.			--
------------------------------------------------------------------------------
	local actionID
	for b=0, 9 do
		for s = 1, 12 do
			actionID = s+(b*12)
			SaveActionInfo(actionID)
		end
	end
	CollectSpellInfo()
	if P.dimSpellExists == true then
		AddSpellExistOptions()
	end
	
	AddStackOptions()
end

------------------------------------------------------------------------------------------------------
function SaveActionInfo(actionID)																	--
-- Save a actionID's name, spellID, weather it can be cast on a target and if it has a cooldown.	--
------------------------------------------------------------------------------------------------------
	local actionType, spellID, subType, spellRank, spellName
	if HasAction_(actionID) then -- and ActionHasRange_(actionID)
		actionType, spellID, subType  = GetActionInfo_(actionID)
		if actionType == "spell" and subType  == "spell" and spellID and spellID > 0 then
			spellName, spellRank = GetSpellName_( spellID, BOOKTYPE_SPELL )
			if spellName  then --and not spellNames[spellName]
				local targetSpell, canStack = GetSpellDetails(spellName, spellRank)
--~ 				local targetSpell = SpellHasRange_(spellName)
				spellNames[spellName] = {aID=actionID, sID=spellID, targetSpell=targetSpell, canStack = canStack}
			end
		end
	end
end


function FindGCDID()
	local  _, class  = UnitClass('player')
	local gcdID = 0




end

function GetGCDName()
	local  _, class  = UnitClass('player')
	if class == 'DEATHKNIGHT' then
		return "Blood Strike"
	elseif class == 'DRUID' then
		return "Healing Touch"
	elseif class == 'HUNTER' then
		return "Serpent Sting"
	elseif class == 'MAGE' then
		return "Fireball"
	elseif class == 'PALADIN' then
		return "Flash of Light"
	elseif class == 'PRIEST' then
		return "Lesser Heal"
	elseif class == 'ROGUE' then
		return "Sinister Strike"
	elseif class == 'SHAMAN' then
		return "Healing Wave"
	elseif class == 'WARLOCK' then
		return "Immolate"
	elseif class == 'WARRIOR' then
		return 'Sunder Armor'
	end
end
local gcdName = GetGCDName()

--Look into IsAttackSpell for GCD.
------------------------------------------------------------------------------
function CollectSpellInfo()													--	/script DA.CollectSpellInfo()
-- Save spellID's to a table indexed by spellName. This is used for macros.	--
-- So we know the spellID for any spells within a macro.					--
------------------------------------------------------------------------------
	local spellID = 1
	
	while( GetSpellName_(spellID, BOOKTYPE_SPELL) ) do --find the top rank of every spell
		local spellName, spellRank = GetSpellName_( spellID, BOOKTYPE_SPELL )
--~ 		local nextSpell = GetSpellName_( spellID+1, BOOKTYPE_SPELL )
		
		if not IsPassiveSpell(spellID, BOOKTYPE_SPELL) and not spellNames[spellName] then
			local targetSpell, canStack = GetSpellDetails(spellName, spellRank)
			spellNames[spellName] = {sID=spellID, targetSpell=targetSpell, canStack = canStack}
		end
		spellID = spellID + 1
	end
end

--------------------------------------------------------------
function core:ACTIONBAR_SLOT_CHANGED(event, ...)			--
-- A slot has changed, we save the spell's new actionID.	--
--------------------------------------------------------------
	local actionID  = ...-- ***
	if actionID == 0 then--no actionID, save all actionIDs.
		CollectActionInfo()
		return
	end
	
	for spellName, data in pairs(spellNames) do 
		if data.aID == actionID then
			spellNames[spellName].aID = nil
			break
		end
	end
	if HasAction_(actionID) then -- and ActionHasRange_(actionID)
		actionType, spellID, subType  = GetActionInfo_(actionID)
		if actionType == "spell" and subType  == "spell" and spellID and spellID > 0 then
			spellName = GetSpellName_( spellID, BOOKTYPE_SPELL )
			if spellName and spellNames[spellName] then
				spellNames[spellName].aID = actionID
			end
		end
	end
end

----------------------------------------------------------------------
function core:PLAYER_REGEN_DISABLED(event, ...)						--
-- We've entered combat, check if we should hook action buttons.	--
----------------------------------------------------------------------
	if P.dimCombatOnly == true then
		HookActionButtons()
	end
end

--------------------------------------------------
function core:PLAYER_REGEN_ENABLED(event, ...)	--
-- We've exited combat, unhook action buttons.	--
--------------------------------------------------
	if P.dimCombatOnly == true then
		UnhookAllBars()
	end
end

----------------------------------------------------------------------
function UnhookAllBars()											--
-- Unhook all bars, this also returns action buttons to 100% alpha.	--
----------------------------------------------------------------------
	if BT4 == true then
		for i=1, 10 do 
			UnhookBar("BT4Bar"..i)
		end
		
	elseif Dominos == true then
		for i=1, 10 do 
			UnhookBar("dBar"..i)
		end
		
	else
		UnhookBar("Bar1")
		UnhookBar("BonusBar1")
		UnhookBar("MultiBarBottomLeft")
		UnhookBar("MultiBarBottomRight")
		UnhookBar("MultiBarRight")
		UnhookBar("MultiBarLeft")
	end
end

--removing this, gonna hook BonusBarFrame's OnShow and OnHide instead.
--~ function core:COMBAT_LOG_EVENT_UNFILTERED(event, ...)
--~ 	local timestamp, eventType, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags  = ...
--~ 	local _, _, eventPrefix, eventSuffix = eventType:find("(.-)_(.+)")
--~ 	if eventPrefix == "SPELL" then
--~ 		if FlagIsPlayer(srcFlags) then
--~ 			local spellID, spellName, spellSchool, auraType  = select(9, ...)
--~ 			spellName = spellName:lower()
--~ 			if eventSuffix == "AURA_REMOVED" then
--~ 				if spellName:find("form") or spellName:find("stealth") or spellName:find("stance") or spellName:find("prowl") then
--~ 					UnhookBonusActions()
--~ 				end
--~ 			elseif eventSuffix == "AURA_APPLIED" then
--~ 				if spellName:find("form") or spellName:find("stealth") or spellName:find("stance") or spellName:find("prowl") then
--~ 					HookBonusActions()
--~ 				end
--~ 			end
--~ 		end
--~ 	end
--~ end

--[===[@debug@
function bTest()--	/run DA.bTest()
	local self = GetMouseFocus()
	local buttonType = self:GetAttribute("type")
	local actionID = self.action
	local actionType, spellID, subType = GetActionInfo_(actionID)
	
	Debug("bTest A", buttonType, actionType, spellID, subType)
	local macroText = self:GetAttribute("macrotext");
	local spellName, targetID = SecureCmdOptionParse(macroText)
	
	Debug("bTest B", spellName, targetID)
end
--@end-debug@]===]

function GetSpellType(aID, sID)
--~ 	Debug("GetSpellType", aID, sID)
	
--~ 	local spellName = GetSpellInfo(sID)
--~ 	local spellName, spellRank = GetSpellName( sID, BOOKTYPE_SPELL )
--~ 	Debug("GetSpellType", sID, spellName, IsHelpfulSpell(sID, BOOKTYPE_SPELL))
	
--~ 	local spellName, spellRank = GetSpellName( sID, BOOKTYPE_SPELL )
	
	if not SpellHasRange(sID, BOOKTYPE_SPELL) then
		return "Passive"
	end
	
	if IsPassiveSpell(sID, BOOKTYPE_SPELL) then
		return "Passive"
	end
	
--~ 	if core.mouseTargeting[spellName] then
--~ 		return "Passive"
--~ 	end
	
	if IsHelpfulSpell(sID, BOOKTYPE_SPELL) then
--~ 		if core.channelSpells[spellName] then
--~ 			return "Beneficial-Channel"
--~ 		end
		return "Beneficial"
	end

--~ 	if core.channelSpells[spellName] then
--~ 		return "Harmful-Channel"
--~ 	end

	return "Harmful"
end

local string_find = string.find
local strsplit = strsplit
local tonumber = tonumber
local function ItemLinkToId(itemLink) -- Itemlink, returns the itemID
	local _, _, itemString = string_find(itemLink, "^|c%x+|H(.+)|h%[.+%]")
	if itemString then
		local _, itemId, _, _, _, _, _, _, _ = strsplit(":", itemString)
		return tonumber(itemId)
	end
	return nil
end

local GetItemInfo = GetItemInfo
local GetItemCooldown = GetItemCooldown
local GetMacroItem = GetMacroItem

------------------------------------------------------------------------------------------
function UpdateActionButton(self, x)														--
-- Our main OnUpdate function, here we check if we should show or dim a action button.	--
------------------------------------------------------------------------------------------
	local name = self:GetName()
	local icon = _G[name.."Icon"] or self:GetNormalTexture()
	
	local realButton = self
	
	if P.showAlt == true and IsAltKeyDown_() then
		self:SetAlpha(1)
		icon:SetVertexColor(1, 1, 1, nil, true)
		return
	end

	local targetID = self:GetAttribute("unit1") or self:GetAttribute("unit") or "target"

	if P.showNoTarget == true and not UnitExists_(targetID) then
		self:SetAlpha(1)
		icon:SetVertexColor(1, 1, 1, nil, true)
		return
	end
	
	local actionID = self.action
--~ 	if actionID == 2 then
--~ 		Debug("UpdateActionButton A", targetID, UnitExists_(targetID))
--~ 	end
	local hasTarget = true
	if actionID then
		local buttonType = self:GetAttribute("type")
		local actionType, spellID, subType = GetActionInfo_(actionID)
		local spellName
		local nTargetID
		
		if buttonType == "click" then
			realButton = self:GetAttribute("clickbutton") --The real button this button is clicking on.

			--[[
				Turns out I don't have access to frame:GetFrameRef(). 
				So I have to save headers by hooking SecureHandlerSetFrameRef. Meh
			]]
			
			local header = handerFrames[realButton] and handerFrames[realButton].refFrame --self:GetFrameRef("SA_headerFrame")
			if header then
				local macroText = header:GetAttribute("action"..actionID.."text")

				if macroText then

					
					spellName, nTargetID = SecureCmdOptionParse_(macroText)
					
					if not nTargetID then
						hasTarget = false
					end
					
--~ 					if actionID == 71 then
--~ 						Debug("UpdateActionButton A", spellName, nTargetID)
--~ 					end

					targetID = nTargetID or targetID
					
					if spellName and spellNames[spellName] then
						typeValue, subType = "spell", "spell"
						spellID = spellNames[spellName].sID--Changing spellID to a real spellID. currently it's a macroID.
					elseif not spellName then
						if P.showNoTarget == true then
							self:SetAlpha(1)
							icon:SetVertexColor(1, 1, 1, nil, true)
							return
						else
							self:SetAlpha(P.colours.unusable.a)
							icon:SetVertexColor(P.colours.unusable.r, P.colours.unusable.g, P.colours.unusable.b, nil, true)
							return
						end
					end
				end
			end
		elseif actionType == "macro" and P.dimMacros == true then
			
			if P.dimMacros == true then
				local nTargetID = GetMacroTarget(spellID) --Item's don't default to having a target. user needs to have [@target] in the /use macro.
				local item, itemLink = GetMacroItem(spellID)
				spellName = GetMacroSpell_(spellID)
	
				if (item or spellName) and not nTargetID then
					hasTarget = false
				end
	
				targetID = nTargetID or targetID
				if item then
					actionType = "item"
					spellID = ItemLinkToId(itemLink)
					
				elseif spellName and spellNames[spellName] then
					actionType, subType = "spell", "spell"
					spellID = spellNames[spellName].sID--Changing spellID to a real spellID. currently it's a macroID.
				elseif not spellName then
					if P.showNoTarget == true then
						self:SetAlpha(1)
						icon:SetVertexColor(1, 1, 1, nil, true)
						return
					else
						self:SetAlpha(P.colours.unusable.a)
						icon:SetVertexColor(P.colours.unusable.r, P.colours.unusable.g, P.colours.unusable.b, nil, true)
						return
					end
				end
			else
				self:SetAlpha(1)
				icon:SetVertexColor(1, 1, 1, nil, true)
				return
			end
		end

	--~ 	if actionID == 9 or actionID == 10 then
	--~ 		Debug("UpdateActionButton B", actionID, "hasTarget:"..tostring(hasTarget), "targetID:"..tostring(targetID), "Exists:"..tostring(UnitExists_(targetID)))
	--~ 	end

	--[[if hasTarget == true and not UnitExists_(targetID) then
			if P.showNoTarget == true then
				self:SetAlpha(1)
				icon:SetVertexColor(1, 1, 1, nil, true)
				return
			end
		end]]
	
		--Check if we have the mana for the action.
		local isUsable, notEnoughMana = IsUsableAction_(actionID)
		if P.dimUnuseableOntarget == true and not isUsable and not notEnoughMana then --again with unusable this time using IsUsableAction() which is affected when a spell is needed inorder to cast a spell, (judgment needing seal)
			self:SetAlpha(P.colours.unusable.a)
			icon:SetVertexColor(P.colours.unusable.r, P.colours.unusable.g, P.colours.unusable.b, nil, true)
			return
		end
		
		if P.dimNoMana == true and notEnoughMana then
			self:SetAlpha(P.colours.mana.a)
			icon:SetVertexColor(P.colours.mana.r, P.colours.mana.g, P.colours.mana.b, nil, true)
			return
		end
		
		
		

		
		
		
		
		if ActionHasRange_(actionID) then
			--[[
			if actionID == 88 then
				Debug("UpdateActionButton C", "spellID:"..tostring(spellID), "Range:"..tostring(IsActionInRange_(actionID,targetID)), "Usable:"..tostring(isUsable), "notEnoughMana:"..tostring(notEnoughMana))
--~ 				Debug("UpdateActionButton D", "Harmful:"..tostring(IsHarmfulSpell(spellID, BOOKTYPE_SPELL)), "Helpful:"..tostring(IsHelpfulSpell(spellID, BOOKTYPE_SPELL)), UnitReaction(targetID, "player"))
			end
			]]
			
--~ 			if P.dimUnuseableOntarget == true and IsActionInRange_(actionID,targetID) == nil and not isUsable and not notEnoughMana then --Before 
			if P.dimUnuseableOntarget == true and IsActionInRange_(actionID,targetID) == nil then 
			
				--Testing code that hides a spell if it's harm and target is friendly, or a help spell and target's hostile. There were problems...
--~ 				if actionType and actionType == "spell" and subType  == "spell" and spellID and spellID > 0 then
--~ 					if UnitExists(targetID) and spellID and ((IsHarmfulSpell(spellID, BOOKTYPE_SPELL) and UnitReaction(targetID, "player") >= 5) or (IsHelpfulSpell(spellID, BOOKTYPE_SPELL) and UnitReaction(targetID, "player") <= 4)) then
--~ 						self:SetAlpha(P.colours.unusable.a)
--~ 						icon:SetVertexColor(P.colours.unusable.r, P.colours.unusable.g, P.colours.unusable.b, nil, true)
--~ 						return
--~ 					end
--~ 				end
				
				if not isUsable and not notEnoughMana then
					self:SetAlpha(P.colours.unusable.a)
					icon:SetVertexColor(P.colours.unusable.r, P.colours.unusable.g, P.colours.unusable.b, nil, true)
					return
				end
			end
			if P.dimOutOfRange == true and IsActionInRange_(actionID,targetID) == 0 then
				self:SetAlpha(P.colours.range.a)
				icon:SetVertexColor(P.colours.range.r, P.colours.range.g, P.colours.range.b, nil, true)
				return
			end
		end
		
		--Check if the spell is on cooldown or already exists on target.
		if (actionType == "spell" and subType == "spell" and spellID and spellID > 0) then
			local spellName = spellName or GetSpellName_( spellID, BOOKTYPE_SPELL )
			
--~ 			if x == true then
--~ 				Debug("x 1", spellName, GetSpellCooldown_(spellName))
--~ 				Debug("x 2", spellName, GetActionCooldown_(actionID))
--~ 				
--~ 			end
			
			if P.dimCooldown == true then
				local start, duration, enabled = GetSpellCooldown_(spellName)
				if start and start > 0 then --and ( start > 0 and duration > 0) then
					if start ~= GetGCD() then
--~ 						local wait = start + duration - GetTime_()
--~ 						if wait > 1 then--If there's less then 1 second remaining in the cooldown, show the action. This gives user a second warning to deside if they'll start mashing it.
							self:SetAlpha(P.colours.cooldown.a)
							icon:SetVertexColor(P.colours.cooldown.r, P.colours.cooldown.g, P.colours.cooldown.b, nil, true)
							return
--~ 						end
					end
				end
			end

			if P.dimSpellExists == true and UnitExists_(targetID) then
				if P.se[spellName] == true then
					if IsBuffOn(spellName, targetID) then
						self:SetAlpha(P.colours.exists.a)
						icon:SetVertexColor(P.colours.exists.r, P.colours.exists.g, P.colours.exists.b, nil, true)
						return
					end
				end
	
			end
		elseif actionType == "item" and spellID and spellID > 0 then
			local spellName = spellName or GetItemInfo( spellID )
		
		
			
			if P.dimCooldown == true then
				local start, duration, enabled = GetItemCooldown(spellID)
				if start and start > 0 then --and ( start > 0 and duration > 0) then
					if start ~= GetGCD() then
--~ 						local wait = start + duration - GetTime_()
--~ 						if wait > 1 then--If there's less then 1 second remaining in the cooldown, show the action. This gives user a second warning to deside if they'll start mashing it.
							self:SetAlpha(P.colours.cooldown.a)
							icon:SetVertexColor(P.colours.cooldown.r, P.colours.cooldown.g, P.colours.cooldown.b, nil, true)
							return
--~ 						end
					end
				end
			end
		end
	end


		
	icon:SetVertexColor(1, 1, 1, nil, true)
	self:SetAlpha(1)
end


function test()--	/script DA.test()
	local targetID = "target"
	print("test", UnitName(targetID), "Enemy:"..tostring(UnitIsEnemy_("player", targetID)), "Friend:"..tostring(UnitIsFriend("player", targetID)) )
end

function coolTest()--	/run DA.coolTest()
	local button = GetMouseFocus()
	local buttonCooldown = getglobal(button:GetName().."Cooldown");
	local buttonCooldownText = getglobal(button:GetName().."TextCooldown");
	Debug("coolTest", buttonCooldown, buttonCooldownText)
end
local GetActionCooldown_ = GetActionCooldown

--------------------------------------------------------------------------
function GetGCD()														--
-- Get the global cooldown from a spell that normally has no cooldown.	--
--------------------------------------------------------------------------
	local start = GetSpellCooldown_(gcdName) --, duration,  enable
--~ 	if enable ==  1 and start and duration > 0 and  duration <= 1.5 then
		return start or 0
--~ 	end
--~ 	return 0
end

--------------------------------------------------
function IsBuffOn(spellName, unitID)			--	/script DA.IsBuffOn("Lifebloom", "target")
-- Check if a spell is on a unitID.				--
-- If the unitID's friendly we check buffs.		--
-- If the unitID's hostile we check debuffs.	--
--------------------------------------------------
	local name, _, _, count, _, _, _, unitCaster = UnitDebuff_(unitID, spellName)
	if name then
		if unitCaster and unitCaster == "player" then
			if spellNames[spellName].canStack == 0 or count >= P.sc[spellName] then
				return true
			end
		end
	end
	name, _, _, count, _, _, _, unitCaster = UnitBuff_(unitID, spellName)
	if name then
		if unitCaster and unitCaster == "player" then
			if spellNames[spellName].canStack == 0 or count >= P.sc[spellName] then
				return true
			end
		end
	end
	return nil
	
--~ 	local name, unitCaster, count
--~ 	if UnitIsEnemy_("player", unitID) then --in duels, friendly's appear as enemies. but they also still appear as friendly (UnitIsFriend). =/
--~ 		for i = 1, 40 do
--~ 			name, _, _, count, _, _, _, unitCaster = UnitDebuff_(unitID, i)
--~ 			if not name then break end
--~ 			if name == spellName then
--~ 				if unitCaster and unitCaster == "player" then
--~ 					if spellNames[spellName].canStack == 0 or count >= P.sc[spellName] then
--~ 						return true
--~ 					end
--~ 				end
--~ 			end
--~ 		end
--~ 	else
--~ 		for i = 1, 40 do
--~ 			name, _, _, count, _, _, _, unitCaster = UnitBuff_(unitID, i)
--~ 			if not name then break end
--~ 			if name == spellName then
--~ 				if unitCaster and unitCaster == "player" then
--~ 					if spellNames[spellName].canStack == 0 or count >= P.sc[spellName] then
--~ 						return true
--~ 					end
--~ 				end
--~ 			end
--~ 		end
--~ 	end
--~ 	return nil
end

--~ function IsBuffOn2(spellName, unitID)
--~ 	local name, unitCaster
--~ 	
--~ 	if UnitIsFriend("player", unitID) then 
--~ 		for i = 1, 40 do
--~ 			name, _, _, _, _, _, _, unitCaster = UnitBuff(unitID, i)
--~ 			if not name then break end
--~ 			if name == spellName then
--~ 				if unitCaster and unitCaster == "player" then
--~ 					return true
--~ 				end
--~ 			end
--~ 		end
--~ 	else--if UnitIsEnemy_("player",unitID) then
--~ 		for i = 1, 40 do
--~ 			name, _, _, _, _, _, _, unitCaster = UnitDebuff(unitID, i)
--~ 			if not name then break end
--~ 			if name == spellName then
--~ 				if unitCaster and unitCaster == "player" then
--~ 					return true
--~ 				end
--~ 			end
--~ 		end
--~ 	end
--~ 	return nil
--~ end


------------------------------
function Debug(from, ...)	--	/script DA.Debug("hey","bye")
-- simple print function.	--
------------------------------
	local tbl  = {...}
	local msg = tostring(tbl[1])
	for i=2,table_getn(tbl) do 
		msg = msg..strWhiteBar..tostring(tbl[i])
	end
	print(strDebugFrom:format(from).." "..msg)
end

------------------------------------------------------------------------------------------------------
function GetSpellDetails(spellName, spellRank)														--
-- Check a spell's Description to see if spell is castable on a target and if it has a cooldown.	--
------------------------------------------------------------------------------------------------------
	if ( not myTooltip:IsShown() ) then
		myTooltip:SetOwner(UIParent, "ANCHOR_NONE")
	end
	local link = GetSpellLink_(spellName, spellRank)
	if not link then
		return false
	end
	
	local _, _, realid = link:find("Hspell:(%d+)")
	
	myTooltip:SetHyperlink("spell:"..realid)
	myTooltip:Show()
	--
	
	local otherSpell = false
	local canStack	= 0
	local lines = myTooltip:NumLines()
	if lines > 0 then
		local qText = (_G["DA_ToolTipTextLeft"..lines]:GetText() or "")
		if SpellHasRange_(spellName) then
			for tText in pairs(targetSpells) do 
				if qText:find(L["stack"]:lower()) or qText:find(L["applied"]:lower()) then
					for times in qText:gmatch(L["up to (.+) times"]) do
						canStack = tonumber(times or 0)
						break
					end
				end
				
				if (qText:find(L["over"]:lower()) or qText:find(L["every"]:lower()) or qText:find(L["sec"]:lower()) or qText:find(L["min"]:lower())) and qText:find(tText) then
					otherSpell = true
				end
			end
		end
	end
	
--~ 	if isTargetSpell == 1 and otherSpell ~= true then
--~ 		Debug("GetSpellDetails 1", spellName, isTargetSpell, otherSpell)
--~ 	elseif not isTargetSpell and otherSpell ~= false then
--~ 		Debug("GetSpellDetails 2", spellName, isTargetSpell, otherSpell)
--~ 	end

	return otherSpell, canStack
end

------------------------------------------------------------------
function AddStackOptions() 										--
-- Add options of user has a spell that can stack on a target.	--
------------------------------------------------------------------
	local spells = {}
	for sN, data in pairs(spellNames) do 
		if data.canStack > 0 then
			table_insert(spells, sN)
		end
	end
	if table.getn(spells) > 0 then
		local dialog = LibStub("AceConfigDialog-3.0")
		if stackOpts == false then
			stackOpts = dialog:AddToBlizOptions(title.."SC", L["Stack Count"], "DA "..version)
		end
		
		table_sort(spells, function(a,b) 
			if(a and b) then 
				return a < b
			end 
		end)
		
		defaultSettings.profile.sc = defaultSettings.profile.sc or {}--stack count
		P.sc = P.sc or {}
		
		for opt in pairs(StackCountOptionsTable.args) do 
			if opt ~= "what" then
				StackCountOptionsTable.args[opt] = nil
			end
		end
		
		local index = 2
		local spellName
		for i=1, table.getn(spells) do 
			spellName = spells[i]
	
			defaultSettings.profile.sc[spellName] = spellNames[spellName].canStack
			if P.sc[spellName] == nil then
				P.sc[spellName] = spellNames[spellName].canStack
			end
			StackCountOptionsTable.args[spellName] = {
				type 		= "range",	 order		= index,
				name		= spellName,
				desc 		= L.spellStackDesc:format(spellName),
				min			= 1,
				max			= spellNames[spellName].canStack,
				step		= 1,
				set = function(info,val) 
					P.sc[info[1]] = val
				end,
				get = function(info) return P.sc[info[1]] end
			}

			index = index + 1
		end
		
	end
end

------------------------------------------------------------------
function AddSpellExistOptions()									--	/script DA.AddSpellExistOptions()
-- Add options to Spell Exists panel for every spell user has.	--
------------------------------------------------------------------
	local spells = {}
	for sN in pairs(spellNames) do 
		table_insert(spells, sN)
	end
	table_sort(spells, function(a,b) 
		if(a and b) then 
			return a < b
		end 
	end)

	defaultSettings.profile.se = defaultSettings.profile.se or {}
	
	P = P or {}
	P.se = P.se or {}

	for opt in pairs(StackCountOptionsTable.args) do 
		if opt ~= "what" then
			StackCountOptionsTable.args[opt] = nil
		end
	end
	
	local index = 2
	local spellName
	for i=1, table.getn(spells) do 
		spellName = spells[i]

		defaultSettings.profile.se[spellName] = spellNames[spellName].targetSpell
		if P.se[spellName] == nil then
			P.se[spellName] = spellNames[spellName].targetSpell
		end
		
		SpellExistOptionsTable.args[spellName] = {
			type = "toggle",	order	= index,
		
			name = spellName,
			desc = L.checkSpellExistsTarget:format(spellName),

			set = function(info,val) 
				P.se[info[1]] = val
			end,
			get = function(info) return P.se[info[1]] end
		}
		
		index = index + 1
	end
	
end

--------------------------------------------------
function AddDominosOptions()					--	/script DA.AddDominosOptions()
-- Add options for Dominos' action bar buttons.	--
--------------------------------------------------

	--Disable blizzard bar options, no need to confuse user w/ too many opts.
	for opt in pairs(BarOptionsTable.args.defaultBars.args) do 
		BarOptionsTable.args.defaultBars.args[opt].disabled = true
	end
	
	BarOptionsTable.args.DominosBars = {
		name = L["Dominos' Bars"],
		type = "group",
		order = 3,
		args={}
	}
	for i=1, table.getn(dominosBars) do 
		BarOptionsTable.args.DominosBars.args["dBar"..i] = {
			type = "toggle",	order	= i,
			name = L["Bar %d"]:format(i),
			desc = L["Dim bar %d"]:format(i),
			set = function(info,val) 
				P.dominos["bar"..i] = val
				
				if val == true then
					HookActionButtons()
				else
					UnhookBar(info[2])
				end
			end,
			get = function(info) return P.dominos["bar"..i] end
		}
	end
end

----------------------------------------------------------------------------------
function AddBT4Options()														--
-- User has Bartender4 running, lets add options to choose which bars to hook.	--
----------------------------------------------------------------------------------

	--Disable blizzard bar options, no need to confuse user w/ too many opts.
	for opt in pairs(BarOptionsTable.args.defaultBars.args) do 
		BarOptionsTable.args.defaultBars.args[opt].disabled = true
	end
	
	BarOptionsTable.args.BT4Bars = {
		name = L["Bartender Bars"],
		type = "group",
		order = 2,
		args={}
	}
	
	BarOptionsTable.args.BT4Bars.args.barsBT4Bar1 = {
		type = "toggle",	order	= 1,
	
		name = L["Bar %d"]:format(1),
		desc = L.workOnBT4Bar:format(1),
	
		set = function(info,val) 
			P.barsBT4Bar1 = val
			if val == true then
				HookActionButtons()
			else
				UnhookBar("BT4Bar1")
			end

		end,
		get = function(info) return P.barsBT4Bar1 end
	}

	BarOptionsTable.args.BT4Bars.args.barsBT4Bar2 = {
		type = "toggle",	order	= 2,
	
		name = L["Bar %d"]:format(2),
		desc = L.workOnBT4Bar:format(2),
	
		set = function(info,val) 
			P.barsBT4Bar2 = val
			if val == true then
				HookActionButtons()
			else
				UnhookBar("BT4Bar2")
			end
		end,
		get = function(info) return P.barsBT4Bar2 end
	}
	
	BarOptionsTable.args.BT4Bars.args.barsBT4Bar3 = {
		type = "toggle",	order	= 3,
	
		name = L["Bar %d"]:format(3),
		desc = L.workOnBT4Bar:format(3),
	
		set = function(info,val) 
			P.barsBT4Bar3 = val
			if val == true then
				HookActionButtons()
			else
				UnhookBar("BT4Bar3")
			end
		end,
		get = function(info) return P.barsBT4Bar3 end
	}
	BarOptionsTable.args.BT4Bars.args.barsBT4Bar4 = {
		type = "toggle",	order	= 4,
	
		name = L["Bar %d"]:format(4),
		desc = L.workOnBT4Bar:format(4),
	
		set = function(info,val) 
			P.barsBT4Bar4 = val
			if val == true then
				HookActionButtons()
			else
				UnhookBar("BT4Bar4")
			end
		end,
		get = function(info) return P.barsBT4Bar4 end
	}
	BarOptionsTable.args.BT4Bars.args.barsBT4Bar5 = {
		type = "toggle",	order	= 5,
	
		name = L["Bar %d"]:format(5),
		desc = L.workOnBT4Bar:format(5),
	
		set = function(info,val) 
			P.barsBT4Bar5 = val
			if val == true then
				HookActionButtons()
			else
				UnhookBar("BT4Bar5")
			end
		end,
		get = function(info) return P.barsBT4Bar5 end
	}
	BarOptionsTable.args.BT4Bars.args.barsBT4Bar6 = {
		type = "toggle",	order	= 6,
	
		name = L["Bar %d"]:format(6),
		desc = L.workOnBT4Bar:format(6),
	
		set = function(info,val) 
			P.barsBT4Bar6 = val
			if val == true then
				HookActionButtons()
			else
				UnhookBar("BT4Bar6")
			end
		end,
		get = function(info) return P.barsBT4Bar6 end
	}
	BarOptionsTable.args.BT4Bars.args.barsBT4Bar7 = {
		type = "toggle",	order	= 7,
	
		name = L["Bar %d"]:format(7),
		desc = L.workOnBT4Bar:format(7),
	
		set = function(info,val) 
			P.barsBT4Bar7 = val
			if val == true then
				HookActionButtons()
			else
				UnhookBar("BT4Bar7")
			end
		end,
		get = function(info) return P.barsBT4Bar7 end
	}
	BarOptionsTable.args.BT4Bars.args.barsBT4Bar8 = {
		type = "toggle",	order	= 8,
	
		name = L["Bar %d"]:format(8),
		desc = L.workOnBT4Bar:format(8),
	
		set = function(info,val) 
			P.barsBT4Bar8 = val
			if val == true then
				HookActionButtons()
			else
				UnhookBar("BT4Bar8")
			end		end,
		get = function(info) return P.barsBT4Bar8 end
	}
	BarOptionsTable.args.BT4Bars.args.barsBT4Bar9 = {
		type = "toggle",	order	= 9,
	
		name = L["Bar %d"]:format(9),
		desc = L.workOnBT4Bar:format(9),
	
		set = function(info,val) 
			P.barsBT4Bar9 = val
			if val == true then
				HookActionButtons()
			else
				UnhookBar("BT4Bar9")
			end
		end,
		get = function(info) return P.barsBT4Bar9 end
	}
	BarOptionsTable.args.BT4Bars.args.barsBT4Bar10 = {
		type = "toggle",	order	= 10,
	
		name = L["Bar %d"]:format(10),
		desc = L.workOnBT4Bar:format(10),
	
		set = function(info,val) 
			P.barsBT4Bar10 = val
			if val == true then
				HookActionButtons()
			else
				UnhookBar("BT4Bar10")
			end
		end,
		get = function(info) return P.barsBT4Bar10 end
	}
end

--------------------------
-- GUI Options Table.	--
--------------------------

StackCountOptionsTable = {
	name = L["Stack Count"],
	type = "group",
	childGroups = "tab",
	args = {},
}

StackCountOptionsTable.args.what = {
	type = "description",
	name = L.StackPanelDesc,
	width = "full",
	order = 1,
}

CoreOptionsTable = {
	name = title,
	type = "group",
	childGroups = "tab",

	args = {
		core={
			name = L["Core"],
			type = "group",
			order = 1,
			args={}
		},
	},
}

CoreOptionsTable.args.core.args.enable = {
	type = "toggle",	order	= 1,
	name	= L["Enable"],
	desc	= L["Enables / Disables the addon"],
	set = function(info,val) 
		if val == true then
			core:Enable()
		else
			core:Disable()
		end
	end,
	get = function(info) return core:IsEnabled() end
}

CoreOptionsTable.args.core.args.updateFrequency = {
	type 		= "range",	 order		= 2,
	name 		= L["Update Frequency"],
	desc 		= L["Delay between each action update."],
	min			= 0.1,
	max			= 1,
	step		= 0.05,
	set = function(info,val) 
		P.updateFrequency = val
	end,
	get = function(info) return P.updateFrequency end
}

--~ CoreOptionsTable.args.core.args.dimAlpha = {
--~ 	type 		= "range",	 order		= 3,
--~ 	name 		= L["Dim Opacity"],
--~ 	desc 		= L["How see through you want actions to become."],
--~ 	min			= 0.0,
--~ 	max			= 1, -- 10%
--~ 	step		= 0.05,
--~ 	isPercent	= true,
--~ 	set = function(info,val) 
--~ 		P.dimAlpha = val
--~ 	end,
--~ 	get = function(info) return P.dimAlpha end
--~ }


CoreOptionsTable.args.core.args.showAlt = {
	type = "toggle",	order	= 4,

	name = L["Show Alt-Keypress"],
	desc = L["Show all actions when pressing Alt."],

	set = function(info,val) 
		P.showAlt = val
	end,
	get = function(info) return P.showAlt end
}

CoreOptionsTable.args.core.args.showNoTarget = {
	type = "toggle",	order	= 5,

	name = L["Show No Target"],
	desc = L["Show all actions when you have no target."],

	set = function(info,val) 
		P.showNoTarget = val
	end,
	get = function(info) return P.showNoTarget end
}

CoreOptionsTable.args.core.args.dimCombatOnly = {
	type = "toggle",	order	= 6,

	name = L["Only In Combat"],
	desc = L["Dim actions only in combat."],

	set = function(info,val) 
		P.dimCombatOnly = val
		
		if val == false then--enable when out combat, hook actions.
			HookActionButtons()
		elseif val == true and not InCombatLockdown_() then--enable only in combat and we're not in combat right now.
			UnhookAllBars()
		end
	end,
	get = function(info) return P.dimCombatOnly end
}

CoreOptionsTable.args.core.args.dimNoMana = {
	type = "toggle",	order	= 7,

	name = L["Dim No Mana"],
	desc = L["Dim actions you don't have the mana/energy/rage for."],

	set = function(info,val) 
		P.dimNoMana = val
		core:Disable()--restart addon to redo hooks.
		core:Enable()
	end,
	get = function(info) return P.dimNoMana end
}

CoreOptionsTable.args.core.args.dimUnuseableOntarget = {
	type = "toggle",	order	= 8,

	name = L["Dim Unusable"],
	desc = L["Dim action if it's unusable on target (heals on hostile target)."],

	set = function(info,val) 
		P.dimUnuseableOntarget = val
		core:Disable()--restart addon to redo hooks.
		core:Enable()
	end,
	get = function(info) return P.dimUnuseableOntarget end
}

CoreOptionsTable.args.core.args.dimOutOfRange = {
	type = "toggle",	order	= 9,

	name = L["Dim out of range"],
	desc = L["Dim actions that are out of range of your target."],

	set = function(info,val) 
		P.dimOutOfRange = val
		core:Disable()--restart addon to redo hooks.
		core:Enable()
	end,
	get = function(info) return P.dimOutOfRange end
}



CoreOptionsTable.args.core.args.dimSpellExists = {
	type = "toggle",	order	= 10,

	name = L["Dim Spell Exists"],
	desc = L["Dim actions if spell exists on target."],

	set = function(info,val) 
		P.dimSpellExists = val
		
		if val == true then
			AddSpellExistOptions()
		else
			for opt in pairs(SpellExistOptionsTable.args) do 
				SpellExistOptionsTable.args[opt] = nil
			end
		end
		core:Disable()--restart addon to redo hooks.
		core:Enable()
	end,
	get = function(info) return P.dimSpellExists end
}


CoreOptionsTable.args.core.args.dimCooldown = {
	type = "toggle",	order	= 12,

	name = L["Dim Cooldown"],
	desc = L["Dim spells on cooldown."],

	set = function(info,val) 
		P.dimCooldown = val
		core:Disable()--restart addon to redo hooks.
		core:Enable()
	end,
	get = function(info) return P.dimCooldown end
}


CoreOptionsTable.args.core.args.dimMacros = {
	type = "toggle",	order	= 13,

	name = L["Dim Macros"],
	desc = L.dimMacrosDesc,

	set = function(info,val) 
		P.dimMacros = val
		core:Disable()--restart addon to redo hooks.
		core:Enable()
	end,
	get = function(info) return P.dimMacros end
}

--Bars
-- GUI settings
BarOptionsTable = {
	name = title,
	type = "group",
	childGroups = "tab",

	args = {
		defaultBars={
			name = L["Blizzard Bars"],
			type = "group",
			order = 1,
			args={}
		},
	},
}

--~ CoreOptionsTable.args.core.args.showNoTarget = {
--~ 	type = "toggle",	order	= 5,

--~ 	name = L["Show No Target"],
--~ 	desc = L["Show all actions when you have no target."],

--~ 	set = function(info,val) 
--~ 		P.showNoTarget = val
--~ 	end,
--~ 	get = function(info) return P.showNoTarget end
--~ }

--defaultSettings.profile.colours.range			= {r=1,g=0,b=0,a=.5}
ColourOptionsTable = {
	name = title,
	type = "group",
	childGroups = "tab",

	args = {
		what = {
			type = "description",
			name = L.colourDesc,
			width = "full",
			order = 1,
		},
	
		blockOtherColours = {
			type = "toggle",	order	= 2,
			name = L["Block other colours"],
			desc = L["Block other addons from colouring buttons."],
			
			set = function(info,val) 
				P.blockOtherColours = val
				core:Disable()--restart addon to redo hooks.
				core:Enable()
			end,
			get = function(info) return P.blockOtherColours end
		},
	
		range = {
			name = L["Range"],	order	= 10,
			desc = L["Target is out of range of action"],
			type = "color",
			hasAlpha	= true,
			set = function(info,r,g,b,a) 
				P.colours.range.r = r
				P.colours.range.g = g
				P.colours.range.b = b
				P.colours.range.a = a
			end,
			get = function(info) return P.colours.range.r, P.colours.range.g, P.colours.range.b, P.colours.range.a end
		},
	
		unusable = {
			name = L["Unusable"],	order	= 11,
			desc = L["Action not unsable (ex. heals on enemy)"],
			type = "color",
			hasAlpha	= true,
			set = function(info,r,g,b,a) 
				P.colours.unusable.r = r
				P.colours.unusable.g = g
				P.colours.unusable.b = b
				P.colours.unusable.a = a
			end,
			get = function(info) return P.colours.unusable.r, P.colours.unusable.g, P.colours.unusable.b, P.colours.unusable.a end
		},
	
		mana = {
			name = "Mana",	order	= 12,
			desc = "Not enough mana/range/energy/runic power to cast spell",
			type = "color",
			hasAlpha	= true,
			set = function(info,r,g,b,a) 
				P.colours.mana.r = r
				P.colours.mana.g = g
				P.colours.mana.b = b
				P.colours.mana.a = a
			end,
			get = function(info) return P.colours.mana.r, P.colours.mana.g, P.colours.mana.b, P.colours.mana.a end
		},
		
		cooldown = {
			name = L["Coolodwn"],	order	= 13,
			desc = L["Spell is on cooldown"],
			type = "color",
			hasAlpha	= true,
			set = function(info,r,g,b,a) 
				P.colours.cooldown.r = r
				P.colours.cooldown.g = g
				P.colours.cooldown.b = b
				P.colours.cooldown.a = a
			end,
			get = function(info) return P.colours.cooldown.r, P.colours.cooldown.g, P.colours.cooldown.b, P.colours.cooldown.a end
		},
		
		exists = {
			name = L["Exists"],	order	= 14,
			desc = L["Spell already exists on target"],
			type = "color",
			hasAlpha	= true,
			set = function(info,r,g,b,a) 
				P.colours.exists.r = r
				P.colours.exists.g = g
				P.colours.exists.b = b
				P.colours.exists.a = a
			end,
			get = function(info) return P.colours.exists.r, P.colours.exists.g, P.colours.exists.b, P.colours.exists.a end
		},
	},
}



BarOptionsTable.args.defaultBars.args.barsBar1 = {
	type = "toggle",	order	= 1,

	name = L["Action Bar"],
	desc = L["Work on the default action bar."],

	set = function(info,val) 
		P.barsBar1 = val
		if val == true then
			HookActionButtons()
		else
			UnhookBar("Bar1")
		end
	end,
	get = function(info) return P.barsBar1 end
}
BarOptionsTable.args.defaultBars.args.barsBonusBar1 = {
	type = "toggle",	order	= 2,

	name = L["Bonus Bar"],
	desc = L["Work on the default bonus bar. (used when stealthing)"],

	set = function(info,val) 
		P.barsBonusBar1 = val
		if val == true then
			HookActionButtons()
		else
			UnhookBar("BonusBar1")
		end
	end,
	get = function(info) return P.barsBonusBar1 end
}


BarOptionsTable.args.defaultBars.args.barsMultiBarBottomLeft = {
	type = "toggle",	order	= 2,

	name = L["Multi Bar Bottom Left"],
	desc = L["Bars on your bottom left (above your main action bar)"],

	set = function(info,val) 
		P.barsMultiBarBottomLeft = val
		if val == true then
			HookActionButtons()
		else
			UnhookBar("MultiBarBottomLeft")
		end
	end,
	get = function(info) return P.barsMultiBarBottomLeft end
}

BarOptionsTable.args.defaultBars.args.barsMultiBarBottomRight = {
	type = "toggle",	order	= 3,

	name = L["Multi Bar Bottom Right"],
	desc = L["Bars on your bottom right (above your bags)"],

	set = function(info,val) 
		P.barsMultiBarBottomRight = val
		if val == true then
			HookActionButtons()
		else
			UnhookBar("MultiBarBottomRight")
		end
	end,
	get = function(info) return P.barsMultiBarBottomRight end
}



BarOptionsTable.args.defaultBars.args.barsMultiBarRight = {
	type = "toggle",	order	= 4,

	name = L["Right Bar"],
	desc = L["Bar on the right side of your screen."],

	set = function(info,val) 
		P.barsMultiBarRight = val
		if val == true then
			HookActionButtons()
		else
			UnhookBar("MultiBarRight")
		end
	end,
	get = function(info) return P.barsMultiBarRight end
}

BarOptionsTable.args.defaultBars.args.barsMultiBarLeft = {
	type = "toggle",	order	= 5,

	name = L["Right Bar 2"],
	desc = L["2nd bar on the right side of your screen."],

	set = function(info,val) 
		P.barsMultiBarLeft = val
		if val == true then
			HookActionButtons()
		else
			UnhookBar("MultiBarLeft")
		end
	end,
	get = function(info) return P.barsMultiBarLeft end
}

SpellExistOptionsTable = {
	name = L["Spell Exists"],
	type = "group",
	childGroups = "tab",

	args = {},
}

SpellExistOptionsTable.args.what = {
	type = "description",
	name = L.spellExistsPannelDesc,
	width = "full",
	order = 1,
}
