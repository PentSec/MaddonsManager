local L = LibStub("AceLocale-3.0"):NewLocale("Dimmed Actions", "zhCN")
if not L then return end
L["2nd bar on the right side of your screen."] = "屏幕右侧的第二行动作条。"
L["Action Bar"] = "动作条"
L["Action not unsable (ex. heals on enemy)"] = "无法使用的动作（如，对敌方进行治疗）"
L["applied"] = [=[应用
可应用20次。]=]
L["Bar %d"] = "动作条%d"
L["Bar on the right side of your screen."] = "屏幕右侧的第二行动作条。"
L["Bars"] = "动作条"
L["Bars on your bottom left (above your main action bar)"] = "左下动作条（位于主动作条上方）"
L["Bars on your bottom right (above your bags)"] = "右下动作条（位于背包栏上方）"
L["Bartender Bars"] = [=[Bartender动作条
Bartender是另一款动作条插件。]=]
L["Blizzard Bars"] = "暴雪动作条"
L["Block other addons from colouring buttons."] = "阻止其他插件对按钮着色。"
L["Block other colours"] = "阻止其他颜色"
L["Bonus Bar"] = "额外动作条"
L["cannotFindMacroSpell"] = [=[cannotFindMacroSpell
[Dimmed Actions]无法找到动作条上的%s，宏'%s'不会变暗。]=]
L["checkSpellExistsTarget"] = [=[checkSpellExistsTarget
检查%s是否存在于目标上]=]
L["Colours"] = "颜色"
L["cooldown"] = [=[冷却
法术说明中所见的冷却计时]=]
L["Coolodwn"] = "冷却"
L["Core"] = [=[核心
主设置页面。]=]
L["Cure Poison"] = "解毒"
L["Delay between each action update."] = "每次动作更新时的延迟"
L["Dim action if it's unusable on target (heals on hostile target)."] = "如对目标不可用则启用Dim（对敌方目标进行治疗）。"
L["Dim actions if spell exists on target."] = "如法术存在于目标身上则起动Dim"
L["Dim actions only in combat."] = "仅在战斗中启用Dim"
L["Dim actions that are out of range of your target."] = "当目标超出范围时启用Dim"
L["Dim actions you don't have the mana/energy/rage for."] = "角色无足够法力/能量/怒气时启用Dim。"
L["Dim bar %d"] = "Dim动作条%d"
L["Dim Cooldown"] = "Dim冷却"
L["Dim Macros"] = "Dim宏"
L["dimMacrosDesc"] = [=[dimMacrosDesc
同样是Dim宏。可能无法用于复杂的宏命令。]=]
L["Dim No Mana"] = "Dim法力耗尽"
L["Dim Opacity"] = "Dim不透明度"
L["Dim out of range"] = "Dim超出范围"
L["Dim Spell Exists"] = "Dim法术存在"
L["Dim spells on cooldown."] = "Dim冷却中的技能"
L["Dim Unusable"] = "无法使用Dim"
L["Dominos' Bars"] = "Dominos动作条"
L["Enable"] = "启用"
L["Enables / Disables the addon"] = "启用/禁用插件"
L["enemy target"] = [=[敌方目标
插件会在法术说明中进行查找]=]
L["every"] = [=[每
法术说明：对敌人每3秒造成一次伤害]=]
L["Exists"] = "存在"
L["friendly party"] = "友方队伍"
L["friendly target"] = [=[友方目标
治疗友方目标...]=]
L["Healing Targets Target"] = "治疗目标的目标"
L["healingTargetsTargetDesc"] = [=[healingTargetsTargetDesc
对于治疗法术，如果你的目标是敌人，则检查治疗法术是否存在于目标的目标身上。
（当你使用目标的目标宏时很有用）]=]
L["How see through you want actions to become."] = "你所期望的动作条透明度。"
L["min"] = "min"
L["Multi Bar Bottom Left"] = "左下方多动作条"
L["Multi Bar Bottom Right"] = "右下方多动作条"
L["Only In Combat"] = "仅在战斗中"
L["over"] = [=[于
...于21秒内造成150点伤害]=]
L["Purge"] = "净化"
L["Purify"] = "清洁术"
L["Range"] = "范围"
L["Right Bar"] = "右侧动作条"
L["Right Bar 2"] = "右侧动作条2"
L["sec"] = [=[秒
...于21秒内造成150点伤害]=]
L["Shoot"] = "射击"
L["Show all actions when pressing Alt."] = "按住Alt时显示所有动作"
L["Show all actions when you have no target."] = "无目标时显示所有动作"
L["Show Alt-Keypress"] = "显示Alt按键"
L["Show No Target"] = "不显示目标"
L["Spell already exists on target"] = "已存在于目标身上的法术"
L["Spell Exists"] = "已有法术"
L["spellExistsPannelDesc"] = [=[spellExistsPannelDesc
我们会检查这些法术是否存在于你的目标身上。你可以选择更多需要检查的法术。]=]
L["Spell is on cooldown"] = "法术正在冷却中"
L["spellStackDesc"] = [=[StackPanelDesc
目标身上%s应叠加到多少层才应引起注意。]=]
L["stack"] = [=[叠加
自法术说明：该效果最多可叠加3层]=]
L["Stack Count"] = "叠加计数"
L["StackPanelDesc"] = [=[StackPanelDesc
目标身上增益/减益效果叠加到一定次数时才应引起注意。]=]
L["Target is out of range of action"] = "目标超出范围"
L["Test"] = "测试"
L["the enemy"] = [=[敌方
自法术说明：灼烧敌人...]=]
L["the target"] = [=[目标
自法术说明：对目标造成伤害。]=]
L["Throw"] = [=[投掷
法术名称。]=]
L["Unusable"] = "无法使用"
L["Update Frequency"] = "更新频率"
L["up to (.+) times"] = "最多（.+）层"
L["workOnBT4Bar"] = [=[workOnBT4Bar
可用于Bartender动作条%d]=]
L["Work on the default action bar."] = "可用于默认动作条。"
L["Work on the default bonus bar. (used when stealthing)"] = "可用于默认的额外动作条。（潜行时使用）"
