﻿local L = LibStub("AceLocale-3.0"):NewLocale("Dimmed Actions", "zhTW")
if not L then return end
L["2nd bar on the right side of your screen."] = "螢幕右側的第二行動作條。"
L["Action Bar"] = "動作條"
L["Action not unsable (ex. heals on enemy)"] = "無法使用的動作（例如:對敵方進行治療）"
L["applied"] = [=[應用
可應用20次。]=]
L["Bar %d"] = "條 %d"
L["Bar on the right side of your screen."] = "螢幕右側的第二行動作條。"
L["Bars"] = "動作條"
L["Bars on your bottom left (above your main action bar)"] = "左下動作條(位於主動作條上方)"
L["Bars on your bottom right (above your bags)"] = "右下動作條(位於背包欄上方)"
L["Bartender Bars"] = [=[Bartender動作條
Bartender是另一款動作條插件。]=]
L["Blizzard Bars"] = "暴風雪動作條"
L["Block other addons from colouring buttons."] = "阻止其他插件對按鈕著色。"
L["Block other colours"] = "阻止其他顏色"
L["Bonus Bar"] = "額外動作條"
L["cannotFindMacroSpell"] = [=[cannotFindMacroSpell
[Dimmed Actions]無法找到動作條上的%s，巨集'%s'不會變暗。]=]
L["checkSpellExistsTarget"] = [=[checkSpellExistsTarget
檢查%s是否存在於目標上]=]
L["Colours"] = "顏色"
L["cooldown"] = [=[冷卻
法術說明中所見的冷卻計時]=]
L["Coolodwn"] = "冷卻"
L["Core"] = "核心"
L["Cure Poison"] = "解毒"
L["Delay between each action update."] = "每次動作更新時的延遲"
L["Dim action if it's unusable on target (heals on hostile target)."] = "如對目標不可用則啟用Dim(對敵方目標進行治療)。"
L["Dim actions if spell exists on target."] = "如法術存在於目標身上則起動Dim"
L["Dim actions only in combat."] = "僅在戰鬥中啟用Dim"
L["Dim actions that are out of range of your target."] = "當目標超出範圍時啟用Dim"
L["Dim actions you don't have the mana/energy/rage for."] = "角色無足夠法力/能量/怒氣時啟用Dim。"
L["Dim bar %d"] = "Dim動作條%d"
L["Dim Cooldown"] = "Dim冷卻"
L["Dim Macros"] = "Dim巨集"
L["dimMacrosDesc"] = [=[dimMacrosDesc
同樣是Dim宏。可能無法用於複雜的巨集命令。]=]
L["Dim No Mana"] = "Dim法力耗盡"
L["Dim Opacity"] = "Dim不透明度"
L["Dim out of range"] = "Dim超出範圍"
L["Dim Spell Exists"] = "Dim法術存在"
L["Dim spells on cooldown."] = "Dim冷卻中的技能"
L["Dim Unusable"] = "無法使用Dim"
L["Dominos' Bars"] = "Dominos動作條"
L["Enable"] = "啟用"
L["Enables / Disables the addon"] = "啟用/禁用插件"
L["enemy target"] = "敵方目標"
L["every"] = [=[每
法術說明：對敵人每3秒造成一次傷害]=]
L["Exists"] = "存在"
L["friendly party"] = "友方隊員"
L["friendly target"] = "友方目標"
L["Healing Targets Target"] = "治療目標的目標"
L["healingTargetsTargetDesc"] = [=[healingTargetsTargetDesc
對於治療法術，如果你的目標是敵人，則檢查治療法術是否存在於目標的目標身上。
（當你使用目標的目標巨集時很有用）]=]
L["How see through you want actions to become."] = "你所期望的動作條透明度。"
L["min"] = "min"
L["Multi Bar Bottom Left"] = "左下方多動作條"
L["Multi Bar Bottom Right"] = "右下方多動作條"
L["Only In Combat"] = "僅在戰鬥中"
L["over"] = [=[於
...於21秒內造成150點傷害]=]
L["Purge"] = "淨化"
L["Purify"] = "清潔術"
L["Range"] = "範圍"
L["Right Bar"] = "右側動作條"
L["Right Bar 2"] = "右側動作條2"
L["sec"] = [=[秒
...於21秒內造成150點傷害]=]
L["Shoot"] = "射擊"
L["Show all actions when pressing Alt."] = "按住Alt時顯示所有動作"
L["Show all actions when you have no target."] = "無目標時顯示所有動作"
L["Show Alt-Keypress"] = "顯示Alt按鍵"
L["Show No Target"] = "不顯示目標"
L["Spell already exists on target"] = "已存在於目標身上的法術"
L["Spell Exists"] = "已有法術"
L["spellExistsPannelDesc"] = [=[spellExistsPannelDesc
我們會檢查這些法術是否存在於你的目標身上。你可以選擇更多需要檢查的法術。]=]
L["Spell is on cooldown"] = "法術正在冷卻中"
L["spellStackDesc"] = [=[StackPanelDesc
目標身上%s應疊加到多少層才應引起注意。]=]
L["stack"] = [=[疊加
自法術說明：該效果最多可疊加3層]=]
L["Stack Count"] = "疊加計數"
L["StackPanelDesc"] = [=[StackPanelDesc
目標身上增益/減益效果疊加到一定次數時才應引起注意。]=]
L["Target is out of range of action"] = "目標超出範圍"
L["Test"] = "測試"
L["the enemy"] = "敵人"
L["the target"] = "目標"
L["Throw"] = [=[投擲
法術名稱。]=]
L["Unusable"] = "無法使用"
L["Update Frequency"] = "更新頻率"
L["up to (.+) times"] = "最多(.+) 層"
L["workOnBT4Bar"] = [=[workOnBT4Bar
可用於Bartender動作條%d]=]
L["Work on the default action bar."] = "可用於默認動作條。"
L["Work on the default bonus bar. (used when stealthing)"] = "可用於默認的額外動作條。(潛行時使用)"
