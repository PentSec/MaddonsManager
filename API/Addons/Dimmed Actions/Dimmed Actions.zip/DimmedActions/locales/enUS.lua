local L = LibStub("AceLocale-3.0"):NewLocale("Dimmed Actions", "enUS", true)

L["Test"] = true

--targe spell text from descriptions.
L["the target"] = true
L["the enemy"] = true
L["enemy target"] = true
L["friendly target"] = true
L["friendly party"] = true

--Healing Spells
L["Cure Poison"] = true--*
L["Purify"] = true--*

L["Bars"] = true
L["Spell Exists"] = true

L["Blizzard Bars"] = true
L["Bartender Bars"] = true


L["Action Bar"] = true
L["Bonus Bar"] = true
L["Multi Bar Bottom Left"] = true
L["Multi Bar Bottom Right"] = true
L["Right Bar"] = true
L["Right Bar 2"] = true

L["Dominos' Bars"] = true

L["Bar %d"] = true
L["Dim bar %d"] = true

L.workOnBT4Bar = "Work on Bartender bar %d"
L["Stack Count"] = true

L["Enable"] = true
L["Update Frequency"] = true
L["Delay between each action update."] = true
L["Dim Opacity"] = true
L["How see through you want actions to become."] = true
L["Show Alt-Keypress"] = true
L["Show all actions when pressing Alt."] = true
L["Show No Target"] = true
L["Show all actions when you have no target."] = true
L["Only In Combat"] = true
L["Dim actions only in combat."] = true
L["Dim No Mana"] = true
L["Dim actions you don't have the mana/energy/rage for."] = true
L["Dim out of range"] = true
L["Dim actions that are out of range of your target."] = true
L["Dim Spell Exists"] = true
L["Dim actions if spell exists on target."] = true
L["Healing Targets Target"] = true
L.healingTargetsTargetDesc = "For healing spells, If your target is hostile, check if healing spell exists on target's target.\n(This works best with a healing macro that targets your target's target)"
L["Dim Macros"] = true
L.dimMacrosDesc = "Dim macros too. This may not work for really complicated macros."
L["Dim Cooldown"] = true
L["Dim spells on cooldown."] = true
L["Work on the default action bar."] = true
L["Work on the default bonus bar. (used when stealthing)"] = true
L["Bars on your bottom left (above your main action bar)"] = true
L["Bars on your bottom right (above your bags)"] = true
L["Bar on the right side of your screen."] = true
L["2nd bar on the right side of your screen."] = true
L["stack"] = true
L["applied"] = true
L["up to (.+) times"] = true
L["over"] = true
L["every"] = true
L["sec"] = true
L["min"] = true
L["Core"] = true
L["Shoot"] = true
L["Throw"] = true
L["Purge"] = true


L.spellStackDesc = "How many times %s should stack before considering it existing on your target."
L.StackPanelDesc = "How many times a buff/debuff should stack before considering it existing on your target."


L["Enables / Disables the addon"] = true

L.cannotFindMacroSpell = "[Dimmed Actions] Cannot find %s on bars, macro '%s' won't be dimmed."
L.checkSpellExistsTarget = "Check if %s exists on target."

L.spellExistsPannelDesc = "We check if these spells exist on your target. Select any extras you want to check for."

L.colourDesc = "Here you choose the colour and opacity of your action buttons."

L["Dim Unusable"] = true
L["Dim action if it's unusable on target (heals on hostile target)."] = true;

L["Colours"] = true
L["Range"] = true
L["Block other colours"] = true
L["Block other addons from colouring buttons."] = true
L["Target is out of range of action"] = true
L["Unusable"] = true
L["Action not unsable (ex. heals on enemy)"] = true
L["Coolodwn"] = true
L["Spell is on cooldown"] = true
L["Exists"] = true
L["Spell already exists on target"] = true
--~ L[""] = true
--~ L[""] = true


