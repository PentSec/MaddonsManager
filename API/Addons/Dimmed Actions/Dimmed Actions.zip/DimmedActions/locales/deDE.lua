local L = LibStub("AceLocale-3.0"):NewLocale("Dimmed Actions", "deDE")
if not L then return end
L["2nd bar on the right side of your screen."] = "2te Leiste auf der rechten Seite deines Bildschirms."
L["Action Bar"] = "Aktionsleiste"
L["Action not unsable (ex. heals on enemy)"] = "Aktion nicht anwendbar (z.B. Heilungen auf Gegnern)"
L["applied"] = [=[angewendet
Kann bis zu 20 Mal angewendet werden.]=]
L["Bar %d"] = "Leiste %d"
L["Bar on the right side of your screen."] = "Leiste auf der rechten Seite deines Bildschirms."
L["Bars"] = "Leisten"
L["Bars on your bottom left (above your main action bar)"] = "Leisten unten links (über der Haupt-Aktionsleiste)"
L["Bars on your bottom right (above your bags)"] = "Leisten unten rechts (über deinen Taschen)"
L["Bartender Bars"] = [=[Bartender-Leisten
Bartender ist ein weiteres AddOn mit Aktionsleisten.]=]
L["Blizzard Bars"] = "Blizzard-Leisten"
L["Block other addons from colouring buttons."] = "Verhindere andere AddOns, Schaltflächen einzufärben."
L["Block other colours"] = "Sperre andere Farben"
L["Bonus Bar"] = "Bonus-Leiste"
L["cannotFindMacroSpell"] = "[Dimmed Actions]  Kann %s nicht in den Leisten finden, Macro '%s' wird nicht abgedunkelt."
L["checkSpellExistsTarget"] = "Prüfe, ob das Ziel mit %s belegt ist."
L["Colours"] = "Farben"
L["cooldown"] = "Abklingzeit"
L["Coolodwn"] = "Abklingzeit"
L["Core"] = [=[Kernstück
Seite für Haupteinstellungen]=]
L["Cure Poison"] = "Vergiftung heilen"
L["Delay between each action update."] = "Verzögerung zwischen jeder Aktualisierung der Aktionen."
L["Dim action if it's unusable on target (heals on hostile target)."] = "Aktion verdunkeln, wenn diese auf das Ziel nicht anwendbar ist (Heilungen bei feindlichen Zielen)."
L["Dim actions if spell exists on target."] = "Aktionen verdunkeln, wenn Ziel bereits mit diesem Zauber belegt ist."
L["Dim actions only in combat."] = "Akionen nur im Kampf abdunkeln."
L["Dim actions that are out of range of your target."] = "Aktionen, die ausserhalb der Reichweite des Ziels sind, abdunkeln."
L["Dim actions you don't have the mana/energy/rage for."] = "Verdunkle Aktionen, für die du nicht ausreichend Mana/Energie/Wut hast."
L["Dim bar %d"] = "Verdunkle Leiste %d"
L["Dim Cooldown"] = "Abklingende Aktionen verdunkeln."
L["Dim Macros"] = "Makros verdunkeln"
L["dimMacrosDesc"] = "Verdunkle auch Makros. Dies funktioniert eventuell nicht bei wirklich komplexen Makros. "
L["Dim No Mana"] = "Verdunkle \"Kein Mana\""
L["Dim Opacity"] = "Verdunkelungs-Deckkraft"
L["Dim out of range"] = "\"Außerhalb der Reichweite\" abdunkeln."
L["Dim Spell Exists"] = "Verdunkle \"Zauber bereits vorhanden\""
L["Dim spells on cooldown."] = "Zauber, die noch abklingen, abdunkeln."
L["Dim Unusable"] = "Verdunkelung nicht nutzbar"
L["Dominos' Bars"] = "Dominos-Leisten"
L["Enable"] = "Aktivieren"
L["Enables / Disables the addon"] = "Aktiviert / Deaktiviert das Addon"
L["enemy target"] = "Feindliches Ziel"
L["every"] = [=[alle
Zauber-Beschreibung: alle 3 Sek. Schaden bei einem Gegner]=]
L["Exists"] = "Vorhanden"
L["friendly party"] = [=[Verbündete Gruppe
Heilt bis zu 5 verbündete Gruppen- oder Schlachtzugsmitglieder]=]
L["friendly target"] = "Verbündetes Ziel"
L["Healing Targets Target"] = "Ziel des Ziels wird geheilt"
L["healingTargetsTargetDesc"] = [=[Für Heilzauber: falls dein Ziel feindlich ist, überprüfe ob ein Heilzauber auf dem Ziel des Ziels vorhanden ist.
(Dies funktioniert am besten mit einem Heil-Makro, welches das Ziel deines Ziels anvisiert.)]=]
L["How see through you want actions to become."] = "Wie durchsichtig du die Aktionen werden lassen möchtest."
L["min"] = "Min."
L["Multi Bar Bottom Left"] = "Multiple Leiste unten links"
L["Multi Bar Bottom Right"] = "Multiple Leiste unten rechts"
L["Only In Combat"] = "Nur während des Kampfes"
L["over"] = [=[über
... verursacht 150 Schaden über 21 Sek...]=]
L["Purge"] = "Reinigen"
L["Purify"] = "Läutern"
L["Range"] = "Reichweite"
L["Right Bar"] = "Rechte Leiste"
L["Right Bar 2"] = "Rechte Leiste 2"
L["sec"] = "Sek."
L["Shoot"] = "Schießen"
L["Show all actions when pressing Alt."] = "Alle Aktionen bei gedrückter ALT-Taste anzeigen."
L["Show all actions when you have no target."] = "Alle Aktionen anzeigen, wenn du kein Ziel anvisierst."
L["Show Alt-Keypress"] = "Bei gedrückter ALT-Taste anzeigen"
L["Show No Target"] = "\"Kein Ziel\" anzeigen"
L["Spell already exists on target"] = "Zauber auf Ziel bereits vorhanden."
L["Spell Exists"] = "Zauber vorhanden"
L["spellExistsPannelDesc"] = "Es wird geprüft ob dein Ziel mit diesen Zaubern belegt ist. Wähle weitere Dinge, die du zusätzlich überprüfen möchtest."
L["Spell is on cooldown"] = "Zauber klingt noch ab"
L["spellStackDesc"] = "Wie oft %s gestapelt sein soll, ehe dies beim Ziel als vorhanden erachtet wird."
L["stack"] = "Stapel"
L["Stack Count"] = "Anzahl der Stapel"
L["StackPanelDesc"] = "Wie oft ein Stärkungs- oder Schwächungszauber gestapelt sein soll, ehe er beim Ziel als vorhanden erachtet wird."
L["Target is out of range of action"] = "Ziel ist außerhalb der Reichweite für diese Aktion"
L["Test"] = "Test"
L["the enemy"] = [=[den Feind
Von Zauber-Berschreibung: Verbrennt den Feind für ...]=]
L["the target"] = "das Ziel"
L["Throw"] = "Werfen"
L["Unusable"] = "Nicht anwendbar"
L["Update Frequency"] = "Aktualisierungsfrequenz"
L["up to (.+) times"] = "bis zu (.+) Mal"
L["workOnBT4Bar"] = "Funktioniert auf Bartender-Leiste %d"
L["Work on the default action bar."] = "Funktioniert bei der Standard-Aktionsleiste"
L["Work on the default bonus bar. (used when stealthing)"] = "Funktioniert bei der Standard-Bonus-Leiste (wird bei Verstohlenheit benutzt)."
