local L = LibStub("AceLocale-3.0"):NewLocale("Dimmed Actions", "ruRU")
if not L then return end
L["2nd bar on the right side of your screen."] = "2-я полоса на правой стороне вашего экрана"
L["Action Bar"] = "Панель Действий"
L["Bar %d"] = "Панель %d"
L["Bar on the right side of your screen."] = "Полоса на правой стороне вашего экрана"
L["enemy target"] = "аддон будет искать это в описании заклинания"
L["friendly party"] = "Лечит до 5-ти дружественных членов партии или рейда"
L["friendly target"] = "Лечит дружественную цель на..."
L["Test"] = "Тест"
L["the enemy"] = "Из описания заклинания: Жжёт врага на..."
L["the target"] = "Из описания заклинания: Наносит повреждение цели."
