Thanks to Camalus @ WoWI for the Gloss Orb icons!
