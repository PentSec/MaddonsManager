if( GetLocale() ~= "frFR" ) then
	return
end

AfflictedLocals = setmetatable({

}, {__index = AfflictedLocals})