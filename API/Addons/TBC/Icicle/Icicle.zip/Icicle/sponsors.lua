Icicle_sponsors = {
	["A"] = "Official Developer of Icicle 3.3.5a",
	["B"] = "Official Sponsor of Icicle 3.3.5a",
	["C"] = "Official Contributer of Icicle 3.3.5a",
--devs
	--Warsong
	["Trollolloll"] = { ["Realm"] = "Warsong (Pure PvP)", ["Type"] = "A" },
	--Sargeras
	["Lockmepls"] = { ["Realm"] = "Sargeras x20", ["Type"] = "A" },
	["Trollollollo"] = { ["Realm"] = "Sargeras x20", ["Type"] = "A" },
	["Trollololool"] = { ["Realm"] = "Sargeras x20", ["Type"] = "A" },
	["Troolololol"] = { ["Realm"] = "Sargeras x20", ["Type"] = "A" },
	["Ammonia"] = { ["Realm"] = "Sargeras x20", ["Type"] = "A" },
	["Trolollolol"] = { ["Realm"] = "Sargeras x20", ["Type"] = "A" },
	["Krystalz"] = { ["Realm"] = "Neltharion x12", ["Type"] = "C" }
	}
