
dbDefaults = {
	profile = {
textfont = "Interface\\AddOns\\Icicle\\FreeUniversal-Regular.ttf",
fontSize = ceil(22 - 22  / 2),
all = false,
arena = true,
battleground = true,
field = true,
iconsizer = 22,
YOffsetter = 15,
XOffsetter = 0,
fontsize = 10,
showTooltips = true

	},
}