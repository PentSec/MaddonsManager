FOM_Foods = {
	[FOM_DIET_FUNGUS] = {
		27676,	-- Strange Spores
		24539,	-- Marsh Lichen		
		27859,	-- Zangar Caps		
		4607,	-- Delicious Cave Mold		
		8948,	-- Dried King Bolete		
		4604,	-- Forest Mushroom Cap		
		4608,	-- Raw Black Truffle		
		4605,	-- Red-speckled Mushroom		
		3448,	-- Senggin Root		
		4606,	-- Spongy Morel		
	},					
	[FOM_DIET_FISH] = {
		2674,	-- Crawler Meat
		27515,	-- Huge Spotted Feltail
		27516,	-- Enormous Barbed Gill Trout
		33823,	-- Bloodfin Catfish
		33867,	-- Broiled Bloodfin
		33824,	-- Crescent-Tail Skullfish
		33825,	-- Skullfish Soup
		5527,	-- Goblin Deviled Clams
		6316,	-- Loch Frenzy Delight
		12238,	-- Darkshore Grouper
		13759,	-- Raw Nightfin Snapper
		16766,	-- Undermine Clam Chowder
		21071,	-- Raw Sagefish
		21552,	-- Striped Yellowtail
		21153,	-- Raw Greater Sagefish
		27665,	-- Poached Bluefish		
		27437,	-- Icefin Bluefish		
		27667,	-- Spicy Crawdad
		27439,	-- Furious Crawdad
		27438,	-- Golden Darter
		27435,	-- Figluster's Mudfish
		27664,	-- Grilled Mudfish
		27663,	-- Blackened Sporefish
		27429,	-- Zangarian Sporefish
		27662,	-- Feltail Delight
		27425,	-- Spotted Feltail
		27422,	-- Barbed Gill Trout
		27661,	-- Blackened Trout
		30155,	-- Clam Bar
		24477,	-- Jaggal Clam Meat
		27858,	-- Sunspring Carp
		29452,	-- Zangar Trout
		13889,	-- Raw Whitescale Salmon		
		19996,	-- Harvest Fish
		13933,  -- Lobster Stew
		13888,  -- Darkclaw Lobster
		13935,	-- Baked Salmon		
		13546,	-- Bloodbelly Fish		
		6290,	-- Brilliant Smallfish		
		4593,	-- Bristle Whisker Catfish		
		5503,	-- Clam Meat		
		16971,	-- Clamlette Surprise		
		2682,	-- Cooked Crab Claw		
		13927,	-- Cooked Glossy Mightfish		
		2675,	-- Crawler Claw		
		13930,	-- Filet of Redgill		
		5476,	-- Fillet of Frenzy		
		4655,	-- Giant Clam Meat		
		6038,	-- Giant Clam Scorcho		
		13928,	-- Grilled Squid		
		13929,	-- Hot Smoked Bass		
		13893,	-- Large Raw Mightfish		
		4592,	-- Longjaw Mud Snapper		
		8364,	-- Mithril Head Trout		
		13932,	-- Poached Sunscale Salmon		
		5095,	-- Rainbow Fin Albacore		
		6291,	-- Raw Brilliant Smallfish		
		6308,	-- Raw Bristle Whisker Catfish		
		13754,	-- Raw Glossy Mightfish		
		6317,	-- Raw Loch Frenzy		
		6289,	-- Raw Longjaw Mud Snapper		
		8365,	-- Raw Mithril Head Trout		
		6361,	-- Raw Rainbow Fin Albacore		
		13758,	-- Raw Redgill		
		6362,	-- Raw Rockscale Cod		
		6303,	-- Raw Slitherskin Mackerel		
		8959,	-- Raw Spinefin Halibut		
		4603,	-- Raw Spotted Yellowtail		
		13756,	-- Raw Summer Bass		
		13760,	-- Raw Sunscale Salmon		
		4594,	-- Rockscale Cod		
		787,	-- Slitherskin Mackerel		
		5468,	-- Soft Frenzy Flesh		
		15924,	-- Soft-shelled Clam Meat		
		12216,	-- Spiced Chili Crab		
		8957,	-- Spinefin Halibut		
		6887,	-- Spotted Yellowtail		
		5504,	-- Tangy Clam Meat		
		12206,	-- Tender Crab Meat		
		13755,	-- Winter Squid		
		7974,	-- Zesty Clam Meat		
		33048,	-- Stewed Trout		
		33052,	-- Hot Buttered Trout		
		33053,	-- Fisherman's Feast		
	},					
	[FOM_DIET_MEAT] = {
		723,	-- Goretusk Liver
		21024,	-- Chimaerok Tenderloin
		31670,	-- Raptor Ribs
		31671,	-- Serpent Flesh
		35562,	-- Bear Flank
		33872,	-- Spicy Hot Talbuk
		34410,	-- Honeyed Holiday Ham
		729,	-- Stringy Vulture Meat
		1080,	-- Tough Condor Meat
		2886,	-- Crag Boar Rib
		7097,	-- Leg Meat
		19304,	-- Spiced Beef Jerky
		19305,	-- Pickled Kodo Foot
		19306,	-- Crunchy Frog
		19223,	-- Darkmoon Dog
		20424,	-- Sandworm Meat
		20074,	-- Heavy Crocolisk Stew
		21023,	-- Dirge's Kickin' Chimaerok Chops
		23495,	-- Springpaw Appetizer
		27668,	-- Lynx Meat
		27635,	-- Lynx Steak
		27669,	-- Bat Flesh
		27636,	-- Bat Bites
		22644,	-- Crunchy Spider Leg
		22645,	-- Crunchy Spider Surprise
		24105,	-- Roasted Moongraze Tenderloin
		23676,	-- Moongraze Stag Tenderloin
		29292,	-- Helboar Bacon
		27677,	-- Chunk o' Basilisk
		27678,	-- Clefthoof Meat
		27658,	-- Roasted Clefthoof
		27659,	-- Warp Burger
		27651,	-- Buzzard Bites
		27674,	-- Ravager Flesh
		27681,	-- Warped Flesh
		27671,	-- Buzzard Meat
		27660,	-- Talbuk Steak
		27682,	-- Talbuk Venison
		27657,	-- Blackened Basilisk
		27854,	-- Smoked Talbuk Venison
		29451,	-- Clefthoof Ribs
		21235,	-- Winter Veil Roast
		19995,	-- Harvest Boar				
		4457,	-- Barbecued Buzzard Wing		
		3173,	-- Bear Meat		
		2888,	-- Beer Basted Boar Ribs		
		3730,	-- Big Bear Meat		
		3726,	-- Big Bear Steak		
		3220,	-- Blood Sausage		
		2677,	-- Boar Ribs		
		3404,	-- Buzzard Wing		
		12213,	-- Carrion Surprise		
		2679,	-- Charred Wolf Meat		
		769,	-- Chunk of Boar Meat		
		2673,	-- Coyote Meat		
		2684,	-- Coyote Steak		
		1081,	-- Crisp Spider Meat		
		12224,	-- Crispy Bat Wing		
		5479,	-- Crispy Lizard Tail		
		2924,	-- Crocolisk Meat		
		3662,	-- Crocolisk Steak		
		4599,	-- Cured Ham Steak		
		17119,	-- Deeprun Rat Kabob		
		5478,	-- Dig Rat Stew		
		5051,	-- Dig Rat		
		12217,	-- Dragonbreath Chili		
		2687,	-- Dry Pork Ribs		
		9681,	-- Grilled King Crawler Legs		
		2287,	-- Haunch of Meat		
		12204,	-- Heavy Kodo Meat		
		3727,	-- Hot Lion Chops		
		13851,	-- Hot Wolf Ribs		
		12212,	-- Jungle Stew		
		5472,	-- Kaldorei Spider Kabob		
		5467,	-- Kodo Meat		
		5480,	-- Lean Venison		
		1015,	-- Lean Wolf Flank		
		12209,	-- Lean Wolf Steak		
		3731,	-- Lion Meat		
		12223,	-- Meaty Bat Wing		
		3770,	-- Mutton Chop		
		12037,	-- Mystery Meat		
		4739,	-- Plainstrider Meat		
		12184,	-- Raptor Flesh		
		12203,	-- Red Wolf Meat		
		12210,	-- Roast Raptor		
		2681,	-- Roasted Boar Meat		
		5474,	-- Roasted Kodo Meat		
		8952,	-- Roasted Quail		
		1017,	-- Seasoned Wolf Kabob		
		5465,	-- Small Spider Leg		
		6890,	-- Smoked Bear Meat		
		3729,	-- Soothing Turtle Bisque		
		2680,	-- Spiced Wolf Meat		
		17222,	-- Spider Sausage		
		5471,	-- Stag Meat		
		5469,	-- Strider Meat		
		5477,	-- Strider Stew		
		2672,	-- Stringy Wolf Meat		
		2685,	-- Succulent Pork Ribs		
		3728,	-- Tasty Lion Steak		
		3667,	-- Tender Crocolisk Meat		
		12208,	-- Tender Wolf Meat		
		18045,	-- Tender Wolf Steak		
		5470,	-- Thunder Lizard Tail		
		12202,	-- Tiger Meat		
		117,	-- Tough Jerky		
		3712,	-- Turtle Meat		
		12205,	-- White Spider Meat		
		3771,	-- Wild Hog Shank		
		35563,	-- Charred Bear Kabobs
		35565,	-- Juicy Bear Burger
	},					
	[FOM_DIET_BREAD] = {
		34062,	-- Conjured Manna Biscuit
		1113,	-- Conjured Bread		
		5349,	-- Conjured Muffin		
		1487,	-- Conjured Pumpernickel		
		1114,	-- Conjured Rye		
		8075,	-- Conjured Sourdough		
		8076,	-- Conjured Sweet Roll	
		22895,	-- Conjured Cinnamon Roll
		22019,	-- Conjured Croissant
		
		33924,	-- Delicious Chocolate Cake
		23160,	-- Friendship Bread
		30817,	-- Spice Bread
		29394,	-- Lyribread
		28486,	-- Moser's Magnificent Muffin		
		27855,	-- Mag'har Grainbread
		29449,	-- Bladespire Bagel
		19696,	-- Harvest Bread	
		21254,	-- Winter Veil Cookie
		2683,	-- Crab Cake		
		4541,	-- Freshly Baked Bread		
		17197,	-- Gingerbread Cookie		
		3666,	-- Gooey Spider Cake		
		8950,	-- Homemade Cherry Pie		
		4542,	-- Moist Cornbread		
		4544,	-- Mulgore Spice Bread		
		4601,	-- Soft Banana Bread		
		4540,	-- Tough Hunk of Bread		
		16169,	-- Wild Ricecake		
	},					
	[FOM_DIET_CHEESE] = {
		3665,	-- Curiously Tasty Omelet
		12218,	-- Monster Omelet
		17406,	-- Holiday Cheesewheel
		30458,	-- Stromgarde Muenster
		29448,	-- Mag'har Mild Cheese	        
		27857,	-- Garadar Sharp		
		8932,	-- Alterac Swiss		
		414,	-- Dalaran Sharp		
		2070,	-- Darnassian Bleu		
		422,	-- Dwarven Mild		
		3927,	-- Fine Aged Cheddar	        
		1707,	-- Stormwind Brie		
	},					
	[FOM_DIET_FRUIT] = {
		28112,	-- Underspore Pod
		4656,	-- Small Pumpkin
		21030,	-- Darnassus Kimchi Pie
		21031,	-- Cabbage Kimchi
		21033,	-- Radish Kimchi
		29393,	-- Diamond Berries
		27856,	-- Skethyl Berries
		29450,	-- Telaari Grapes
		19994,	-- Harvest Fruit			
		8953,	-- Deep Fried Plantains		
		4539,	-- Goldenbark Apple		
		16168,	-- Heaven Peach		
		4602,	-- Moon Harvest Pumpkin		
		4536,	-- Shiny Red Apple		
		4538,	-- Snapvine Watermelon		
		4537,	-- Tel'Abim Banana		
		11950,	-- Windblossom Berries		
		24072,	-- Sand Pear Pie		
	},					
};						

FOM_CookingFoods = {
	[  729]	= 1,	-- Stringy Vulture Meat
	[  769]	= 1,	-- Chunk of Boar Meat
	[ 1015]	= 1,	-- Lean Wolf Flank
	[ 1080]	= 1,	-- Tough Condor Meat
	[ 1081]	= 1,	-- Crisp Spider Meat
	[ 2672]	= 1,	-- Stringy Wolf Meat
	[ 2673]	= 1,	-- Coyote Meat
	[ 2675]	= 1,	-- Crawler Claw
	[ 2677]	= 1,	-- Boar Ribs
	[ 2886]	= 1,	-- Crag Boar Rib
	[ 2924]	= 1,	-- Crocolisk Meat
	[ 3173]	= 1,	-- Bear Meat
	[ 3404]	= 1,	-- Buzzard Wing
	[ 3667]	= 1,	-- Tender Crocolisk Meat
	[ 3712]	= 1,	-- Turtle Meat
	[ 3730]	= 1,	-- Big Bear Meat
	[ 3731]	= 1,	-- Lion Meat
	[ 4603]	= 1,	-- Raw Spotted Yellowtail
	[ 4655]	= 1,	-- Giant Clam Meat
	[ 5051]	= 1,	-- Dig Rat
	[ 5465]	= 1,	-- Small Spider Leg
	[ 5467]	= 1,	-- Kodo Meat
	[ 5468]	= 1,	-- Soft Frenzy Flesh
	[ 5469]	= 1,	-- Strider Meat
	[ 5470]	= 1,	-- Thunder Lizard Tail
	[ 5471]	= 1,	-- Stag Meat
	[ 5503]	= 1,	-- Clam Meat
	[ 5504]	= 1,	-- Tangy Clam Meat
	[ 6289]	= 1,	-- Raw Longjaw Mud Snapper
	[ 6291]	= 1,	-- Raw Brilliant Smallfish
	[ 6303]	= 1,	-- Raw Slitherskin Mackerel
	[ 6308]	= 1,	-- Raw Bristle Whisker Catfish
	[ 6317]	= 1,	-- Raw Loch Frenzy
	[ 6361]	= 1,	-- Raw Rainbow Fin Albacore
	[ 6362]	= 1,	-- Raw Rockscale Cod
	[ 7974]	= 1,	-- Zesty Clam Meat
	[ 8365]	= 1,	-- Raw Mithril Head Trout
	[12037]	= 1,	-- Mystery Meat
	[12184]	= 1,	-- Raptor Flesh
	[12202]	= 1,	-- Tiger Meat
	[12203]	= 1,	-- Red Wolf Meat
	[12204]	= 1,	-- Heavy Kodo Meat
	[12205]	= 1,	-- White Spider Meat
	[12206]	= 1,	-- Tender Crab Meat
	[12208]	= 1,	-- Tender Wolf Meat
	[12223]	= 1,	-- Meaty Bat Wing
	[13754]	= 1,	-- Raw Glossy Mightfish
	[13755]	= 1,	-- Winter Squid
	[13756]	= 1,	-- Raw Summer Bass
	[13757]	= 1,	-- Lightning Eel
	[13758]	= 1,	-- Raw Redgill
	[13759]	= 1,	-- Raw Nightfin Snapper
	[13760]	= 1,	-- Raw Sunscale Salmon
	[13888]	= 1,	-- Darkclaw Lobster
	[13889]	= 1,	-- Raw Whitescale Salmon
	[13893]	= 1,	-- Large Raw Mightfish
	[20424]	= 1,	-- Sandworm Meat
	[21024]	= 1,	-- Chimaerok Tenderloin
	[21071]	= 1,	-- Raw Sagefish
	[21153]	= 1,	-- Raw Greater Sagefish
	[22644]	= 1,	-- Crunchy Spider Leg
	[23676]	= 1,	-- Moongraze Stag Tenderloin
	[24477]	= 1,	-- Jaggal Clam Meat
	[27422]	= 1,	-- Barbed Gill Trout
	[27425]	= 1,	-- Spotted Feltail
	[27429]	= 1,	-- Zangarian Sporefish
	[27435]	= 1,	-- Figluster's Mudfish
	[27437]	= 1,	-- Icefin Bluefish
	[27438]	= 1,	-- Golden Darter
	[27439]	= 1,	-- Furious Crawdad
	[27515]	= 1,	-- Huge Spotted Feltail
	[27516]	= 1,	-- Enormous Barbed Gill Trout
	[27668]	= 1,	-- Lynx Meat
	[27669]	= 1,	-- Bat Flesh
	[27671]	= 1,	-- Buzzard Meat
	[27674]	= 1,	-- Ravager Flesh
	[27677]	= 1,	-- Chunk o' Basilisk
	[27678]	= 1,	-- Clefthoof Meat
	[27681]	= 1,	-- Warped Flesh
	[27682]	= 1,	-- Talbuk Venison
	[31670]	= 1,	-- Raptor Ribs
	[31671]	= 1,	-- Serpent Flesh
	[33823]	= 1,	-- Bloodfin Catfish
	[33824]	= 1,	-- Crescent-Tail Skullfish
	[35562]	= 1,	-- Bear Flank

-- Used in cooking, but not a pet food
--	[  730]	= 1,	-- Murloc Eye
--	[  731]	= 1,	-- Goretusk Snout
--	[ 1468]	= 1,	-- Murloc Fin
--	[ 2251]	= 1,	-- Gooey Spider Leg
--	[ 3172]	= 1,	-- Boar Intestines
--	[ 3174]	= 1,	-- Spider Ichor
--	[ 3685]	= 1,	-- Raptor Egg
--	[ 4402]	= 1,	-- Small Flame Sac
--	[ 5466]	= 1,	-- Scorpid Stinger
--	[ 6522]	= 1,	-- Deviate Fish
--	[ 6889]	= 1,	-- Small Egg
--	[12207]	= 1,	-- Giant Egg
--	[18255]	= 1,	-- Runn Tum Tuber
};

