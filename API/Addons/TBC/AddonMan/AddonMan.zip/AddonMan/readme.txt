ADDONMAN README 1.1

Changlog
08/10/2008 - Version 1.1 Changes
   - Addon Man now automatically detects addons and allows enabling and 
      disabling of them without extra work from the addon's developer, 
      and also gives a message if the addon isn't loadable for some reason
      (i.e. the interface version is out of date).
   - Addon developers can still register options with Addon Man, but this
      does require a simple function call for each option.
   - Fixed frame level bugs ugh.
   - Created GameFontBlueSmall. I mention this only because it isn't
      specific to Addon Man - I just created a new global GameFontXSmall
   - Changed a lot of XML names to be more Addon Man specific.
08/07/2008 - initial release

INSTALLATION:

- Copy the AddonMan folder into your WoW\Interface\Addons\ directory. Enjoy.

- Ask developers of your favorite AddOns to make use of the Addon Man's option functionality. Its easy!

- Questions or comments?? tmiller169@hotmail.com



NOTES FOR ADDON DEVELOPERS:

Any AddOn can make use of Addon Man's option switching functionality. It is pretty easy and only requires one function call per option.

The function definition:

   AddonMan_RegisterOption(addon, text, isTitle, isEnabled, toggleFunc)
   
   -- addon - (string) name of the addon this option applies to. MUST match the name of the addon
   -- text - (string) text of the option
   -- isTitle - (boolean) whether or not this option is a title, and has no checkbox. useful for grouping similar options.
   -- isEnabled - (boolean) whether or not this option should start out enabled
   -- toggleFunc - (function) the function to call when this option is switched
   
So for example, if I have a loot filtering AddOn that I want to register a few options with, I would put this code in my initalization function:

   AddonMan_RegisterOption("QuickSkin", "Keeps", true, false, nil)
   AddonMan_RegisterOption("QuickSkin", "Meat", false, true, QuickSkin_AddonManagerHandler)
   AddonMan_RegisterOption("QuickSkin", "Common", false, true, QuickSkin_AddonManagerHandler)
   AddonMan_RegisterOption("QuickSkin", "Quest Items", false, false, QuickSkin_AddonManagerHandler)

The toggle function with be sent the following arguments:

   -- text - (string) the text of the option that was clicked
   -- isEnabled - (boolean) whether or not the option is now enabled

Now I write this function to handle option toggling:

   function QuickSkin_AddonManagerHandler(text, isEnabled)
      ManagerOptions[text] = isEnabled
   
      if (isEnabled == true) then
         ChatFrame1:AddMessage("QuickSkin now keeping "..text)
      else
         ChatFrame1:AddMessage("QuickSkin now destroying "..text)
      end
   end
   
If you have any problems, questions, comments, suggestions, please email me at tmiller169@hotmail.com