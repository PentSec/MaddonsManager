AddonMan_Localization = {}

-- base english strings
ADDONMAN_LOCALIZATION_TITLE = "\< Addon Man"
ADDONMAN_LOCALIZATION_ACTIVE = "Active Addons"
ADDONMAN_LOCALIZATION_OPTIONS = "Options"

-- add further localizations like so

if ( GetLocale() == "frFR" ) then
   -- french localized from an internet translator
   -- who knows if this is right so please correct me
   ADDONMAN_LOCALIZATION_TITLE = "\< Addon Homme"
   ADDONMAN_LOCALIZATION_ACTIVE = "Actif Addons"
   ADDONMAN_LOCALIZATION_OPTIONS = "Options"
end