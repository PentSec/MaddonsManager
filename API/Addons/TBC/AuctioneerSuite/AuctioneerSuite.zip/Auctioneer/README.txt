Auctioneer	5.0.0 (BillyGoat)
$Id: README.txt 656 2005-12-26 22:09:20Z mentalpower $
-------------------------------
FROM: http://auctioneeraddon.com/

