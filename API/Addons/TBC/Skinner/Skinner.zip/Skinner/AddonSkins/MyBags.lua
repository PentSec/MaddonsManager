
function Skinner:MyBags()

	self:applySkin(MyBankFrame)
	self:applySkin(MyInventoryFrame)

end
