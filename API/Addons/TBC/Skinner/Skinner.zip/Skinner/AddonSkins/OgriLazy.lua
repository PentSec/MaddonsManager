
function Skinner:OgriLazy()

	self:applySkin(Relic_View)

end
