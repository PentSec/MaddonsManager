
function Skinner:Postal()

	self:moveObject(PostalSelectOpenButton, "-", 20, "+", 10)
	self:moveObject(PostalSelectReturnButton, "-", 20, "+", 10)
	self:moveObject(PostalOpenAllButton, nil, nil, "+", 12)

end
