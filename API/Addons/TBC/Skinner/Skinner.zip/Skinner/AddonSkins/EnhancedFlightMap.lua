
function Skinner:EnhancedFlightMap()

	self:applySkin(EFM_ConfigScreen)
	self:applySkin(EFM_ConfigScreen_Panel_TimerOptions)
	self:applySkin(EFM_ConfigScreen_Panel_DisplayOptions)
	self:applySkin(EFM_ConfigScreenPanel2)

	self:applySkin(EFM_MapWindow)

end
