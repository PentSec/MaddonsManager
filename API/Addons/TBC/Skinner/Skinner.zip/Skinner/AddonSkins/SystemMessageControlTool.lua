
function Skinner:SystemMessageControlTool()

	self:keepFontStrings(SystemMessageControlToolFrame)
	self:applySkin(SystemMessageControlToolFrame, true)

	self:keepFontStrings(SystemMessageControlToolPredefinedColorsFrame)
	self:applySkin(SystemMessageControlToolPredefinedColorsFrame)

	self:keepFontStrings(SystemMessageControlToolChatWindowsFrame)
	self:applySkin(SystemMessageControlToolChatWindowsFrame)

	self:keepFontStrings(SystemMessageControlToolProfileFrame)
	self:applySkin(SystemMessageControlToolProfileFrame)

end
