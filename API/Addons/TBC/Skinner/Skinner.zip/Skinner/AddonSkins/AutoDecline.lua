
function Skinner:AutoDecline()

	self:keepFontStrings(AD_TogglesBorder)
	self:applySkin(AD_TogglesBorder, true)
	self:keepFontStrings(ADOptionsFrame)
	self:applySkin(ADOptionsFrame, true)

end
