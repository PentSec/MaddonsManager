
function Skinner:MonkeyQuest()

	self:applySkin(MonkeyQuestFrame)

end
