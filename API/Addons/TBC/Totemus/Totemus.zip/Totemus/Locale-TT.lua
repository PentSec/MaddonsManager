
TT_DISEASE_CLEANSING = "Disease Cleansing";
TT_EARTHBIND = "Earthbind";
TT_FIRE_NOVA = "Fire Nova";
TT_FIRE_RESISTANCE = "Fire Resistance";
TT_FIRE_RESISTANCE_AMEL = "Fire Resistance";
TT_FROST_RESISTANCE = "Frost Resistance";
TT_FROST_RESISTANCE_AMEL = "Frost Resistance";
TT_FLAMETONGUE = "Flametongue";
TT_GRACE_OF_AIR = "Grace of Air";
TT_GRACE_OF_AIR_AMEL = "Grace of Air";
TT_GROUNDING = "Grounding";
TT_GROUNDING_AMEL = "Grounding Totem Effect";
TT_HEALING_STREAM = "Healing Stream";
TT_HEALING_STREAM_AMEL = "Healing Stream";
TT_MAGMA = "Magma";
TT_ENAMORED_WATER_SPIRIT = "Enamored Water";
TT_ANCIENT_MANA_SPRING = "Ancient Mana Spring";
TT_ANCIENT_MANA_SPRING_AMEL = "Ancient Mana Spring";
TT_MANA_SPRING = "Mana Spring";
TT_MANA_SPRING_AMEL = "Mana Spring";
TT_MANA_TIDE = "Mana Tide";
TT_NATURE_RESISTANCE = "Nature Resistance";
TT_NATURE_RESISTANCE_AMEL = "Nature Resistance";
TT_POISON_CLEANSING = "Poison Cleansing";
TT_SEARING = "Searing";
TT_SENTRY = "Sentry";
TT_STONECLAW = "Stoneclaw";
TT_STONESKIN = "Stoneskin";
TT_STONESKIN_AMEL = "Stoneskin";
TT_STRENGTH_OF_EARTH = "Strength of Earth";
TT_STRENGTH_OF_EARTH_AMEL = "Strength of Earth";
TT_TREMOR = "Tremor";
TT_TRANQUIL_AIR = "Tranquil Air";
TT_TRANQUIL_AIR_AMEL = "Tranquil Air";
TT_WINDFURY = "Windfury";
TT_WINDWALL = "Windwall";
TT_WINDWALL_AMEL = "Windwall";
TT_WRATH = "of Wrath";
TT_WRATH_AMEL = "Totem of Wrath";
TT_FIREELEM = "Fire Elemental";
TT_EARTHELEM = "Earth Elemental";
TT_WRATHAIR = "Wrath of Air";
TT_WRATHAIR_AMEL = "Wrath of Air Totem";

TT_EARTH = "Earth";
TT_AIR = "Air";
TT_WATER = "Water";
TT_FIRE = "Fire";

TT_SHAMAN = "Shaman";

TT_VERTICAL = "vertical";
TT_HORIZONTAL = "horizontal";
TT_BOX = "box";
TT_LEFT = "left";
TT_RIGHT = "right";
TT_TOP = "top";
TT_BOTTOM = "bottom";
TT_ON = "on";
TT_OFF = "off";
TT_BUFF = "buff";
TT_FIXED = "fixed";
TT_ELEMENT = "element";
TT_STICKY = "sticky";
TT_BLIZZARD = "blizzard";
TT_CT = "ct";
TT_SHOW = "show";
TT_HIDE = "hide";
TT_LOCK = "lock";
TT_UNLOCK = "unlock";
TT_ARRANGE = "arrange";
TT_ALIGN = "align";
TT_WARN = "warn";
TT_NOTIFY = "notify";
TT_STYLE = "style";
TT_TIME = "time";
TT_ORDER = "order";
TT_MSG = "msg";
TT_MSG_TT = "tt"
TT_MSG_SCT = "sct"

TT_USAGE = "Usage:";

-- define our possible options for each setting
TT_OPTION = {};
TT_OPTION[TT_ARRANGE] = {};
TT_OPTION[TT_ARRANGE][TT_VERTICAL] = TT_VERTICAL;
TT_OPTION[TT_ARRANGE]["vert"] = TT_VERTICAL;
TT_OPTION[TT_ARRANGE]["v"] = TT_VERTICAL;
TT_OPTION[TT_ARRANGE][TT_HORIZONTAL] = TT_HORIZONTAL;
TT_OPTION[TT_ARRANGE]["hor"] = TT_HORIZONTAL;
TT_OPTION[TT_ARRANGE]["h"] = TT_HORIZONTAL;
TT_OPTION[TT_ARRANGE][TT_BOX] = TT_BOX;
TT_OPTION[TT_ALIGN] = {};
TT_OPTION[TT_ALIGN][TT_LEFT] = TT_LEFT;
TT_OPTION[TT_ALIGN][TT_BOTTOM] = TT_LEFT;
TT_OPTION[TT_ALIGN][TT_RIGHT] = TT_RIGHT;
TT_OPTION[TT_ALIGN][TT_TOP] = TT_RIGHT;
TT_OPTION[TT_WARN] = {};
TT_OPTION[TT_WARN][TT_ON] = TT_ON;
TT_OPTION[TT_WARN][TT_OFF] = TT_OFF;
TT_OPTION[TT_NOTIFY] = {};
TT_OPTION[TT_NOTIFY][TT_ON] = TT_ON;
TT_OPTION[TT_NOTIFY][TT_OFF] = TT_OFF;
TT_OPTION[TT_STYLE] = {};
TT_OPTION[TT_STYLE][TT_BUFF] = TT_BUFF;
TT_OPTION[TT_STYLE][TT_FIXED] = TT_FIXED;
TT_OPTION[TT_STYLE][TT_ELEMENT] = TT_ELEMENT;
TT_OPTION[TT_STYLE][TT_STICKY] = TT_STICKY;
TT_OPTION[TT_TIME] = {};
TT_OPTION[TT_TIME][TT_BLIZZARD] = TT_BLIZZARD;
TT_OPTION[TT_TIME][TT_CT] = TT_CT;
TT_OPTION[TT_MSG] = {};
TT_OPTION[TT_MSG][TT_MSG_TT] = TT_MSG_TT;
TT_OPTION[TT_MSG][TT_MSG_SCT] = TT_MSG_SCT;

TT_SETTING = {};
TT_SETTING[TT_ARRANGE] = "[TT] Arrangement: %s";
TT_SETTING[TT_ALIGN] = "[TT] Alignment: %s";
TT_SETTING[TT_WARN] = "[TT] Warnings: %s";
TT_SETTING[TT_NOTIFY] = "[TT] Notifications: %s";
TT_SETTING[TT_STYLE] =  "[TT] Icon Style: %s";
TT_SETTING[TT_TIME] = "[TT] Time Format: %s";
TT_SETTING[TT_ORDER] = "[TT] Totem Order: %s";
TT_SETTING[TT_MSG] = "[TT] Messages displayed by %s.";

TT_DESTROYED = "is Destroyed";
TT_WARNING = "is Expiring.";

TT_LOADED = "TotemTimers Addon Loaded";

-- Important Stuff
TT_CAST_REGEX1 = "You cast (.+) Totem%.";
TT_CAST_REGEX2 = "You cast Totem (.+)%.";
TT_DEATH_REGEX = "(.+) Totem (.+) is destroyed.";
TT_DAMAGE_REGEX = { 
	"hits (.+) Totem (.+) for",
	"crits (.+) Totem (.+) for",
	"on (.+) Totem (.+) and",
	"on (.+) Totem (.+) for",
};

TT_TOTEM_REGEX = "(.+) Totem";
--TT_TRINKET_REGEX = "(.+) Staff"
TT_TRINKET_REGEX = "Water Spirit";
TT_RANK_REGEX = "Rank (%d+)";
TT_ELEMENT_REGEX = "Tools: (.+) Totem";

TT_NAME_STRING = "%s Totem";
TT_NAME_LEVEL_STRING = "%s Totem %d";
TT_TOTEMIC_CALL = "You gain .* Mana from Totemic Call%."


TOTEMUS_SHIELD_LIGHT = "Lightning Shield";
TOTEMUS_SHIELD_WATER = "Water Shield";
TOTEMUS_SHIELD_EARTH = "Earth Shield";

-- bindings
BINDING_HEADER_TOTEMUSHEADER = "Totemus";
BINDING_NAME_TOTEMUSFEU1 = "Last Fire Totem 1";
BINDING_NAME_TOTEMUSFEU2 = "Last Fire Totem 2";
BINDING_NAME_TOTEMUSTERRE1 = "Last Earth Totem 1";
BINDING_NAME_TOTEMUSTERRE2 = "Last Earth Totem 2";
BINDING_NAME_TOTEMUSAIR1 = "Last Air Totem 1";
BINDING_NAME_TOTEMUSAIR2 = "Last Air Totem 2";
BINDING_NAME_TOTEMUSEAU1 = "Last Water Totem 1";
BINDING_NAME_TOTEMUSEAU2 = "Last Water Totem 2";