------------------------------------------------------------------------------------------------------
-- Totemus - French translation
--
-- Translated by: Poolpy
--
-- Maintainer: Poolpy & Yorgl
--
-- Based on Ideas by:
--   Venantes by Zirah (http://www.wowinterface.com/downloads/info6155-Venantes.html)
--   Necrosis LdC by Lomig and Nyx (http://necrosis.larmes-cenarius.net)
--   Original Necrosis Idea : Infernal (http://www.revolvus.com/games/interface/necrosis/)
------------------------------------------------------------------------------------------------------

local L = AceLibrary('AceLocale-2.2'):new('Totemus')

L:RegisterTranslations('frFR', function() return {
  ['WELCOME'] = 'Totemus: /totemus ou /totem pour les options.',
  ['SLASH_COMMANDS'] = { '/totemus', '/totem' },
  ['TOGGLE_CONFIG'] = 'Panneau de congiguration',
  ['TOGGLE_MINIMAP'] = 'Afficher l\'icone de la minimap',
  ['CLICK_TOGGLE_CONFIG'] = 'Cliquez pour ouvrir le panneau des options!',
  ['ERROR_LOAD'] = 'Erreur de chargement',
  ['NONE'] = 'None',
  
  -- identifiers
  ['IDENT_ZONE_AQ'] = 'Ahn\'Qiraj',

  -- labels
  ['ANKH'] = 'Ankh',

  --cooldown 
  ['COOLDOWN_REMAINING'] = 'Cooldown restant',
  ['BUTTON_COOLDOWN_HOUR'] = 'h',
  ['BUTTON_COOLDOWN_MINUTES'] = 'm',
  ['TOOLTIP_COOLDOWN_HOUR'] = 'h',
  ['TOOLTIP_COOLDOWN_MINUTES'] = 'min',
  ['TOOLTIP_COOLDOWN_SECONDS'] = 's',
  
  -- user messages
  ['MSG_INCOMBAT'] = 'Vous etes en combat',
  ['MSG_FULLMANA'] = 'Vous etes full mana',
  ['MSG_FULLHEALTH'] = 'Vous etes full vie',
  
  --tooltips
  ['TOOLTIP_LEFTCLICK'] = 'Clic Gauche',
  ['TOOLTIP_RIGHTCLICK'] = 'Clic Droit',
  ['TOOLTIP_MIDDLECLICK'] = 'Clic Milieu',
  ['TOOLTIP_DRINKFOOD'] = 'Boisson/Nourriture',
  ['TOOLTIP_CD_REINC'] = 'Cooldown de R\195\169incarnation',
  ['TOOLTIP_POTION'] = 'Potions',
  ['DRINKFOOD'] = 'Boire & Manger',
  
  ['TAB_SPHERE'] = 'Sphere',
  ['TAB_BUTTONS'] = 'Boutons',
  ['TAB_MESSAGES'] = 'Messages',
  ['TAB_TIMERS'] = 'Timers',
  ['TAB_INVENTORY'] = 'Inventaire',
  ['TAB_DEBUG'] = 'Debug',
  -- options messages tab
  ['MESSAGES_LANGUAGE'] = 'Langue',
  ['MESSAGES_ONSCREEN'] = 'Afficher les messages sur l\'\195\169cran',
  ['MESSAGES_TEXTURE_DEBUG'] = 'Montrer les textures manquantes',
  ['MESSAGES_TOOLTIPS'] = 'Voir les bulles d aide',
  ['MESSAGES_TOOLTIPS_DEFAULTPOS'] = 'Voir la bulle d\'aide \195\160 la position par d\195\169faut',
  ['MESSAGES_RAID'] = 'Voir uniquement les messages raid',
  ['MESSAGES_RANDOM'] = 'Messages Al\195\169atoires',
  ['MESSAGES_RANDOM_ANCESTRAL_SPIRIT'] = 'Esprit Ancestral',
  ['MESSAGES_RANDOM_MOUNT'] = 'Monture',
  -- options button tab
  ['SHOW_BUTTONS'] = 'Voir les buttons',
  ['BUTTON_DRINK_FOOD'] = 'Boissons et nourriture',
  ['BUTTON_CD_REINC'] = 'Cooldown de R\195\169incarnation',
  ['BUTTON_POTION'] = 'Potions de Vie et Mana',
  ['BUTTON_MOUNT'] = 'Monture',
  ['BUTTON_AIRMENU'] = 'Totems d\'Air',
  ['BUTTON_EAUMENU'] = 'Totems d\'Eau',
  ['BUTTON_FEUMENU'] = 'Totems de Feu',
  ['BUTTON_TERREMENU'] = 'Totems de Terre',
  ['BUTTON_BUFFMENU'] = 'Buffs d\'Arme',
  ['BUTTON_ACTION_ONE'] = '1 er Bouton',
  ['BUTTON_ACTION_TWO'] = '2 nd Bouton',
  ['BUTTON_LOCK_LAST'] = 'Bloquer le dernier totem',
  -- options timers tab
  ['TIMERS_SHOW'] = 'Afficher TotemusTimers',
  ['TIMERS_LOCK'] = 'Bloquer la position de TotemusTimers',
  ['TIMERS_ARRANGE'] = 'Arrangement des ic\195\180nes',
  ['TIMERS_ALIGN'] = 'Alignement des ic\195\180nes',
  ['TIMERS_WARN'] = 'Activer les messages d\'alertes',
  ['TIMERS_NOTIFY'] = 'Activer les notifications',
  ['TIMERS_STYLE'] = 'Changer le style',
  ['TIMERS_TIME'] = 'Activer le format du temps de Blizzard',
  ['TIMERS_ORDER'] = 'Changer l\'ordre des totems',
  -- options graphics tab
  ['LOCK_SPHERE'] = 'Bloque la position de la sphere',
  ['LOCK_BUTTONS'] = 'Bloque la position des boutons',
  ['SPHERE_ROTATION'] = 'Tourne les boutons',
  ['SPHERE_SCALE'] = 'Taille de la sphere',
  ['BUTTON_SCALE'] = 'Taille des boutons',
  ['SPHERE_CIRCLE'] = 'Cercle de la sphere',
  ['CIRCLE_TRANSPARENCY'] = 'Transparence',
  ['SPHERE_TEXT'] = 'Texte sur la sphere',
  ['MENU_KEEPOPEN'] = 'Garder les menus ouverts',
  ['HIDE_MINIMAP'] = 'Cacher le bouton de la minimap',
  -- status info titles
  ['STATUS_MANA'] = 'Mana',
  ['STATUS_HEALTH'] = 'Vie',
  ['STATUS_XP'] = 'Experience',
  ['STATUS_DRINK_FOOD'] = 'Boissons/Nourriture',
  ['STATUS_CD_REINC'] = 'Cooldown de R\195\169incarnation',
  ['STATUS_SHIELD'] = 'Charges de Bouclier',
  ['STATUS_SHIELDREINC'] = 'Bouclier/R\195\169incarnation',
  -- slot names
  ['SLOT_Trinket0Slot'] = 'Trinket 1';
  ['SLOT_Trinket1Slot'] = 'Trinket 2';
  -- debug
  ['DEBUG_ITEMDROP'] = 'Glissez un objet dans la case';
  ['DEBUG_TEXTURES'] = 'Textures manquantes';
} end)
