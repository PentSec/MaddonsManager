﻿------------------------------------------------------------------------------------------------------
-- Venantes - German translations
--
-- Translated by: Poolpy
--
-- Maintainer: Poolpy
--
-- Based on Ideas by:
--   Venantes by Zirah (http://www.wowinterface.com/downloads/info6155-Venantes.html)
--   Necrosis LdC by Lomig and Nyx (http://necrosis.larmes-cenarius.net)
--   Original Necrosis Idea : Infernal (http://www.revolvus.com/games/interface/necrosis/)
------------------------------------------------------------------------------------------------------

local L = AceLibrary('AceLocale-2.2'):new('Totemus')

L:RegisterTranslations('deDE', function() return {
  ['WELCOME'] = 'Totemus: /totemus or /totem for options.',
  ['SLASH_COMMANDS'] = { '/totemus', '/totem' },
  ['TOGGLE_CONFIG'] = 'Konfigurationsdialog anzeigen/verbergen',
  ['TOGGLE_MINIMAP'] = 'Minimap Icon ein-/ausblenden',
  ['CLICK_TOGGLE_CONFIG'] = 'Anklicken um den Konfigurationsdialog anzuzeigen/zu verbergen!',
  ['ERROR_LOAD'] = 'Ladefehler',
  ['NONE'] = 'Nichts',

  -- identifiers
  ['IDENT_ZONE_AQ'] = 'Ahn\'Qiraj',

  -- labels
  ['ANKH'] = 'Ankh',
  
  -- cooldowns
  ['COOLDOWN_REMAINING'] = 'Abklingzeit verbleibend',
  ['BUTTON_COOLDOWN_HOUR'] = 'h',
  ['BUTTON_COOLDOWN_MINUTES'] = 'm',
  ['TOOLTIP_COOLDOWN_HOUR'] = 'h',
  ['TOOLTIP_COOLDOWN_MINUTES'] = 'min',
  ['TOOLTIP_COOLDOWN_SECONDS'] = 's',
  
  -- user messages
  ['MSG_INCOMBAT'] = 'Im Kampf nicht möglich',
  ['MSG_FULLMANA'] = 'Du hast volles Mana',
  ['MSG_FULLHEALTH'] = 'Du hast volles Leben',
  
  -- tooltips
  ['TOOLTIP_LEFTCLICK'] = 'Linksklick',
  ['TOOLTIP_RIGHTCLICK'] = 'Rechtsklick',
  ['TOOLTIP_MIDDLECLICK'] = 'Mittelklick',
  ['TOOLTIP_DRINKFOOD'] = 'Trinken/Essen',
  ['TOOLTIP_CD_REINC'] = 'Reincarnation Cooldown',
  ['TOOLTIP_POTION'] = 'Tränke',
  ['DRINKFOOD'] = 'Trinken & Essen',
  
  -- option tabs
  ['TAB_SPHERE'] = 'Sphäre',
  ['TAB_BUTTONS'] = 'Knöpfe',
  ['TAB_MESSAGES'] = 'Nachrichten',
  ['TAB_TIMERS'] = 'Timer',
  ['TAB_INVENTORY'] = 'Inventar',
  ['TAB_DEBUG'] = 'Fehlersuche',
  -- tooltips
  ['MESSAGES_TOOLTIPS'] = 'Tooltips anzeigen',  
  ['MESSAGES_TOOLTIPS_DEFAULTPOS'] = 'Tooltips an der Standardposition anzeigen',
  -- options messages tab
  ['MESSAGES_LANGUAGE'] = 'Nachrichtensprache',
  ['MESSAGES_ONSCREEN'] = 'Totemus-Nachrichten auf dem Bildschirm anzeigen',
  ['MESSAGES_TEXTURE_DEBUG'] = 'Fehlende Texturen melden',
  ['MESSAGES_RAID'] = 'Nur kurze Raidnachrichten anzeigen',
  ['MESSAGES_RANDOM'] = 'Zufällige Nachrichten',
  ['MESSAGES_RANDOM_ANCESTRAL_SPIRIT'] = 'Ancestral Spirit',
  ['MESSAGES_RANDOM_MOUNT'] = 'Reittier rufen',
  -- options button tab
  ['SHOW_BUTTONS'] = 'Knöpfe anzeigen',
  ['BUTTON_DRINK_FOOD'] = 'Essen und Trinken',
  ['BUTTON_CD_REINC'] = 'Reincarnation Cooldown',
  ['BUTTON_POTION'] = 'Heil-/Manatrank',
  ['BUTTON_MOUNT'] = 'Reittier',
  ['BUTTON_AIRMENU'] = 'Luft-Menü',
  ['BUTTON_EAUMENU'] = 'Wasser-Menü',
  ['BUTTON_FEUMENU'] = 'Feuer-Menü',
  ['BUTTON_TERREMENU'] = 'Erde-Menü',
  ['BUTTON_BUFFMENU'] = 'Weapon Buffs',
  ['BUTTON_ACTION_ONE'] = 'Erster Aktionsknopf',
  ['BUTTON_ACTION_TWO'] = 'Zweiter Aktionsknopf',
  ['BUTTON_LOCK_LAST'] = 'Block last totem',
  -- options timers tab
  ['TIMERS_SHOW'] = 'Zeige TotemusTimers',
  ['TIMERS_LOCK'] = 'Sperre TotemusTimers Position',
  ['TIMERS_ARRANGE'] = ' Icon Anordnung',
  ['TIMERS_ALIGN'] = 'Icon Ausrichtung',
  ['TIMERS_WARN'] = 'Warnungen bei Verschwinden an/aus',
  ['TIMERS_NOTIFY'] = 'Nachrichten bei Zerst\195\182rung an/aus',
  ['TIMERS_STYLE'] = 'Setze TotemusTimers Stil',
  ['TIMERS_TIME'] = 'Setze Zeitformat',
  ['TIMERS_ORDER'] = 'Setze Totem Reihenfolge',
  -- options graphics tab
  ['LOCK_SPHERE'] = 'Sphäre sperren',
  ['LOCK_BUTTONS'] = 'Knöpfe an Sphäre ausrichten',
  ['SPHERE_ROTATION'] = 'Knöpfe rotieren',
  ['SPHERE_SCALE'] = 'Sphäre skalieren',
  ['BUTTON_SCALE'] = 'Knöpfe skalieren',
  ['SPHERE_CIRCLE'] = 'Kreisanzeige',
  ['CIRCLE_TRANSPARENCY'] = 'Kreistransparenz',
  ['SPHERE_TEXT'] = 'Sphärentexte',
  ['MENU_KEEPOPEN'] = 'Menüs geöffnet lassen',
  ['HIDE_MINIMAP'] = 'Hide minimap button',
  -- status info titles
  ['STATUS_MANA'] = 'Mana',
  ['STATUS_HEALTH'] = 'Leben',
  ['STATUS_XP'] = 'Erfahrung',
  ['STATUS_DRINK_FOOD'] = 'Trinken/Essen',
  ['STATUS_CD_REINC'] = 'Reincarnation Cooldown',
  ['STATUS_SHIELD'] = 'Shield Count',
  ['STATUS_SHIELDREINC'] = 'Shield/Reincarnation',
  -- slot names
  ['SLOT_Trinket0Slot'] = 'Trinket 1';
  ['SLOT_Trinket1Slot'] = 'Trinket 2';
  -- debug
  ['DEBUG_ITEMDROP'] = 'Ziehe einen Gegenstand in die Box';
  ['DEBUG_TEXTURES'] = 'Fehlende Texturen';
} end)
