-- TotemData This information must be included to work properly.
TotemData = {};

TotemData[TT_DISEASE_CLEANSING] = {};
TotemData[TT_DISEASE_CLEANSING].icon = "Spell_Nature_DiseaseCleansingTotem";
TotemData[TT_DISEASE_CLEANSING].duration = 120;
TotemData[TT_DISEASE_CLEANSING].hits = 5;
TotemData[TT_DISEASE_CLEANSING].element = TT_WATER;
TotemData[TT_DISEASE_CLEANSING].buff = 0;

TotemData[TT_EARTHBIND] = {};
TotemData[TT_EARTHBIND].icon = "Spell_Nature_StrengthOfEarthTotem02";
TotemData[TT_EARTHBIND].duration = 45; 
TotemData[TT_EARTHBIND].hits = 5;
TotemData[TT_EARTHBIND].element = TT_EARTH;
TotemData[TT_EARTHBIND].buff = 0;

TotemData[TT_FIRE_NOVA] = {};
TotemData[TT_FIRE_NOVA].icon = "Spell_Fire_SealOfFire";
TotemData[TT_FIRE_NOVA].duration = 5;
TotemData[TT_FIRE_NOVA].hits = 5;
TotemData[TT_FIRE_NOVA].element = TT_FIRE;
TotemData[TT_FIRE_NOVA].buff = 0;

TotemData[TT_FIRE_RESISTANCE] = {};
TotemData[TT_FIRE_RESISTANCE].icon = "Spell_FireResistanceTotem_01"; 
TotemData[TT_FIRE_RESISTANCE].duration = 120;
TotemData[TT_FIRE_RESISTANCE].hits = 5;
TotemData[TT_FIRE_RESISTANCE].element = TT_WATER;
TotemData[TT_FIRE_RESISTANCE].buff = 1;
TotemData[TT_FIRE_RESISTANCE].amel = TT_FIRE_RESISTANCE_AMEL;

TotemData[TT_FLAMETONGUE] = {};
TotemData[TT_FLAMETONGUE].icon = "Spell_Nature_GuardianWard";
TotemData[TT_FLAMETONGUE].duration = 120;
TotemData[TT_FLAMETONGUE].hits = 5;
TotemData[TT_FLAMETONGUE].element = TT_FIRE;
TotemData[TT_FLAMETONGUE].buff = 0;

TotemData[TT_FROST_RESISTANCE] = {};
TotemData[TT_FROST_RESISTANCE].icon = "Spell_FrostResistanceTotem_01"; 
TotemData[TT_FROST_RESISTANCE].duration = 120;
TotemData[TT_FROST_RESISTANCE].hits = 5;
TotemData[TT_FROST_RESISTANCE].element = TT_FIRE;
TotemData[TT_FROST_RESISTANCE].buff = 1;
TotemData[TT_FROST_RESISTANCE].amel = TT_FROST_RESISTANCE_AMEL;

TotemData[TT_GRACE_OF_AIR] = {};
TotemData[TT_GRACE_OF_AIR].icon = "Spell_Nature_InvisibilityTotem";
TotemData[TT_GRACE_OF_AIR].hits = 5;
TotemData[TT_GRACE_OF_AIR].duration = 120;
TotemData[TT_GRACE_OF_AIR].element = TT_AIR;
TotemData[TT_GRACE_OF_AIR].buff = 1;
TotemData[TT_GRACE_OF_AIR].amel = TT_GRACE_OF_AIR_AMEL;

TotemData[TT_GROUNDING] = {};
TotemData[TT_GROUNDING].icon = "Spell_Nature_GroundingTotem";
TotemData[TT_GROUNDING].duration = 45;
TotemData[TT_GROUNDING].hits = 5;
TotemData[TT_GROUNDING].element = TT_AIR;
TotemData[TT_GROUNDING].buff = 1;
TotemData[TT_GROUNDING].amel = TT_GROUNDING_AMEL;

TotemData[TT_HEALING_STREAM] = {} ;
TotemData[TT_HEALING_STREAM].icon = "INV_Spear_04";
TotemData[TT_HEALING_STREAM].duration = 120;
TotemData[TT_HEALING_STREAM].hits = 5;
TotemData[TT_HEALING_STREAM].element = TT_WATER;
TotemData[TT_HEALING_STREAM].buff = 1;
TotemData[TT_HEALING_STREAM].amel = TT_HEALING_STREAM_AMEL;

TotemData[TT_MAGMA] = {};
TotemData[TT_MAGMA].icon = "Spell_Fire_SelfDestruct";
TotemData[TT_MAGMA].duration = 20;
TotemData[TT_MAGMA].hits = 5;
TotemData[TT_MAGMA].element = TT_FIRE;
TotemData[TT_MAGMA].buff = 0;

TotemData[TT_MANA_SPRING] = {};
TotemData[TT_MANA_SPRING].icon = "Spell_Nature_ManaRegenTotem";
TotemData[TT_MANA_SPRING].duration = 120;
TotemData[TT_MANA_SPRING].hits = 5;
TotemData[TT_MANA_SPRING].element = TT_WATER;
TotemData[TT_MANA_SPRING].buff = 1;
TotemData[TT_MANA_SPRING].amel = TT_MANA_SPRING_AMEL;

TotemData[TT_MANA_TIDE] = {};
TotemData[TT_MANA_TIDE].icon = "Spell_Frost_SummonWaterElemental";
TotemData[TT_MANA_TIDE].duration = 12;
TotemData[TT_MANA_TIDE].hits = 5;
TotemData[TT_MANA_TIDE].element = TT_WATER;
TotemData[TT_MANA_TIDE].buff = 0;

TotemData[TT_ANCIENT_MANA_SPRING] = {};
TotemData[TT_ANCIENT_MANA_SPRING].icon = "INV_Wand_01";
TotemData[TT_ANCIENT_MANA_SPRING].duration = 24;
TotemData[TT_ANCIENT_MANA_SPRING].hits = 5;
TotemData[TT_ANCIENT_MANA_SPRING].element = TT_WATER;
TotemData[TT_ANCIENT_MANA_SPRING].buff = 1;
TotemData[TT_ANCIENT_MANA_SPRING].amel = TT_ANCIENT_MANA_SPRING_AMEL;

TotemData[TT_NATURE_RESISTANCE] = {};
TotemData[TT_NATURE_RESISTANCE].icon = "Spell_Nature_NatureResistanceTotem";
TotemData[TT_NATURE_RESISTANCE].duration = 120;
TotemData[TT_NATURE_RESISTANCE].hits = 5;
TotemData[TT_NATURE_RESISTANCE].element = TT_AIR;
TotemData[TT_NATURE_RESISTANCE].buff = 1;
TotemData[TT_NATURE_RESISTANCE].amel = TT_NATURE_RESISTANCE_AMEL;

TotemData[TT_POISON_CLEANSING] = {};
TotemData[TT_POISON_CLEANSING].icon = "Spell_Nature_PoisonCleansingTotem";
TotemData[TT_POISON_CLEANSING].duration = 120;
TotemData[TT_POISON_CLEANSING].hits = 5;
TotemData[TT_POISON_CLEANSING].element = TT_WATER;
TotemData[TT_POISON_CLEANSING].buff = 0;

TotemData[TT_SEARING] = {};
TotemData[TT_SEARING].icon = "Spell_Fire_SearingTotem";
TotemData[TT_SEARING].hits = 5;
TotemData[TT_SEARING][1] = { };
TotemData[TT_SEARING][1].duration = 30;
TotemData[TT_SEARING][2] = { };
TotemData[TT_SEARING][2].duration = 35;
TotemData[TT_SEARING][3] = { };
TotemData[TT_SEARING][3].duration = 40;
TotemData[TT_SEARING][4] = { };
TotemData[TT_SEARING][4].duration = 45;
TotemData[TT_SEARING][5] = { };
TotemData[TT_SEARING][5].duration = 50;
TotemData[TT_SEARING][6] = { };
TotemData[TT_SEARING][6].duration = 55;
TotemData[TT_SEARING][7] = { };
TotemData[TT_SEARING][7].duration = 60;
TotemData[TT_SEARING].element = TT_FIRE;
TotemData[TT_SEARING].buff = 0;

TotemData[TT_SENTRY] = {};
TotemData[TT_SENTRY].icon = "Spell_Nature_RemoveCurse";
TotemData[TT_SENTRY].duration = 300;
TotemData[TT_SENTRY].hits = 5;
TotemData[TT_SENTRY].element = TT_AIR;
TotemData[TT_SENTRY].buff = 0;

TotemData[TT_STONECLAW] = {};
TotemData[TT_STONECLAW].icon = "Spell_Nature_StoneClawTotem";
TotemData[TT_STONECLAW].duration = 15;
TotemData[TT_STONECLAW][1] = { };
TotemData[TT_STONECLAW][1].hits = 236;
TotemData[TT_STONECLAW][2] = { };
TotemData[TT_STONECLAW][2].hits = 306;
TotemData[TT_STONECLAW][3] = { };
TotemData[TT_STONECLAW][3].hits = 346;
TotemData[TT_STONECLAW][4] = { };
TotemData[TT_STONECLAW][4].hits = 376;
TotemData[TT_STONECLAW][5] = { };
TotemData[TT_STONECLAW][5].hits = 456;
TotemData[TT_STONECLAW][6] = { };
TotemData[TT_STONECLAW][6].hits = 516;
TotemData[TT_STONECLAW][7] = {}
TotemData[TT_STONECLAW][7].hits = 1324;
TotemData[TT_STONECLAW].element = TT_EARTH;
TotemData[TT_STONECLAW].buff = 0;

TotemData[TT_STONESKIN] = {};
TotemData[TT_STONESKIN].icon = "Spell_Nature_StoneSkinTotem";
TotemData[TT_STONESKIN].hits = 5;
TotemData[TT_STONESKIN].duration = 120;
TotemData[TT_STONESKIN].element = TT_EARTH;
TotemData[TT_STONESKIN].buff = 0;
TotemData[TT_STONESKIN].amel = TT_STONESKIN_AMEL;

TotemData[TT_STRENGTH_OF_EARTH] = {};
TotemData[TT_STRENGTH_OF_EARTH].icon = "Spell_Nature_EarthBindTotem";
TotemData[TT_STRENGTH_OF_EARTH].hits = 5;
TotemData[TT_STRENGTH_OF_EARTH].duration = 120;
TotemData[TT_STRENGTH_OF_EARTH].element = TT_EARTH;
TotemData[TT_STRENGTH_OF_EARTH].buff = 1;
TotemData[TT_STRENGTH_OF_EARTH].amel = TT_STRENGTH_OF_EARTH_AMEL;

TotemData[TT_TREMOR] = {};
TotemData[TT_TREMOR].icon = "Spell_Nature_TremorTotem";
TotemData[TT_TREMOR].duration = 120;
TotemData[TT_TREMOR].hits = 5;
TotemData[TT_TREMOR].element = TT_EARTH;
TotemData[TT_TREMOR].buff = 0;

TotemData[TT_TRANQUIL_AIR] = {};
TotemData[TT_TRANQUIL_AIR].icon = "Spell_Nature_Brilliance";
TotemData[TT_TRANQUIL_AIR].duration = 120;
TotemData[TT_TRANQUIL_AIR].hits = 5;
TotemData[TT_TRANQUIL_AIR].element = TT_AIR;
TotemData[TT_TRANQUIL_AIR].buff = 0;
TotemData[TT_TRANQUIL_AIR].amel = TT_TRANQUIL_AIR_AMEL;

TotemData[TT_WINDFURY] = {};
TotemData[TT_WINDFURY].icon = "Spell_Nature_Windfury";
TotemData[TT_WINDFURY].duration = 120;
TotemData[TT_WINDFURY].hits = 5;
TotemData[TT_WINDFURY].element = TT_AIR;
TotemData[TT_WINDFURY].buff = 0;

TotemData[TT_WINDWALL] = {};
TotemData[TT_WINDWALL].icon = "Spell_Nature_EarthBind";
TotemData[TT_WINDWALL].duration = 120;
TotemData[TT_WINDWALL].hits = 5;
TotemData[TT_WINDWALL].element = TT_AIR;
TotemData[TT_WINDWALL].buff = 1;
TotemData[TT_WINDWALL].amel = TT_WINDWALL_AMEL;

TotemData[TT_WRATH] = {};
TotemData[TT_WRATH].icon = "Spell_Fire_TotemOfWrath";
TotemData[TT_WRATH].duration = 120;
TotemData[TT_WRATH].hits = 5;
TotemData[TT_WRATH].element = TT_FIRE;
TotemData[TT_WRATH].buff = 1;
TotemData[TT_WRATH].amel = TT_WRATH_AMEL;

TotemData[TT_FIREELEM] = {};
TotemData[TT_FIREELEM].icon = "Spell_Fire_Elemental_Totem";
TotemData[TT_FIREELEM].duration = 120;
TotemData[TT_FIREELEM].hits = 5;
TotemData[TT_FIREELEM].element = TT_FIRE;
TotemData[TT_FIREELEM].buff = 0;

TotemData[TT_EARTHELEM] = {};
TotemData[TT_EARTHELEM].icon = "Spell_Nature_EarthElemental_Totem";
TotemData[TT_EARTHELEM].duration = 120;
TotemData[TT_EARTHELEM].hits = 5;
TotemData[TT_EARTHELEM].element = TT_EARTH;
TotemData[TT_EARTHELEM].buff = 0;

TotemData[TT_WRATHAIR] = {};
TotemData[TT_WRATHAIR].icon = "Spell_Nature_SlowingTotem";
TotemData[TT_WRATHAIR].duration = 120;
TotemData[TT_WRATHAIR].hits = 5;
TotemData[TT_WRATHAIR].element = TT_AIR;
TotemData[TT_WRATHAIR].buff = 1;
TotemData[TT_WRATHAIR].amel = TT_WRATHAIR_AMEL;

TT_EMPTY_ICON = "Spell_Totem_WardOfDraining";
