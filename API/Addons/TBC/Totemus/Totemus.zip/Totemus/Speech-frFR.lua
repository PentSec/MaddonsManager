------------------------------------------------------------------------------------------------------
-- Totemus - French speeches
--
-- Translated by: Poolpy
--
-- Maintainer: Poolpy
--
-- Based on Ideas by:
--   Venantes by Zirah (http://www.wowinterface.com/downloads/info6155-Venantes.html)
--   Necrosis LdC by Lomig and Nyx (http://necrosis.larmes-cenarius.net)
--   Original Necrosis Idea : Infernal (http://www.revolvus.com/games/interface/necrosis/)
------------------------------------------------------------------------------------------------------

TOTEMUS_RANDOM_MESSAGES_frFR = {
    ['RAID'] = {
        ['SHAMAN_ANCESTRAL_SPIRIT'] = 'Je ram\195\169ne \195\160 la vie <target>',
    },
    ['SHAMAN_ANCESTRAL_SPIRIT'] = {
        "L'esprit et le corps ne feront plus qu'un <target>! Encore une fois....",
        "Ce n'est pas le moment de se reposer <target>! Au boulot f\195\169n\195\169ant !",
        "Faites que ce jour soit connu en tant que le jour o\195\185 <target> est mort au combat!",
    },
    ['MOUNT'] = {
        "Les instructions disaient juste d'ajouter de l'eau et... OUAH un <mount>!",
        "Si ce n'\195\169tait pas pour mon <mount>, je marcherais.",
        "J'aimerais attendre \195\160 c\195\180t\195\169, mais mon <mount> a besoin d'exercice.",
        "Ok <mount>, je suis pr\195\170t \195\160 galoper!",
        "Vous devriez voir mon autre monture... mais elle est au magasin pour r\195\169paration.",
        "En avant mon fid\195\169le <mount>! Yehaaaaa !",
        "Hey! Quelque chose est sorti de mon derri\195\168re!",
   },
} 