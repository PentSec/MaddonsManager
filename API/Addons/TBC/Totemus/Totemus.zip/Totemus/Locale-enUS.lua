------------------------------------------------------------------------------------------------------
-- Totemus - English translation
--
-- Translated by: Poolpy
--
-- Maintainer: Poolpy
--
-- Based on Ideas by:
--   Venantes by Zirah (http://www.wowinterface.com/downloads/info6155-Venantes.html)
--   Necrosis LdC by Lomig and Nyx (http://necrosis.larmes-cenarius.net)
--   Original Necrosis Idea : Infernal (http://www.revolvus.com/games/interface/necrosis/)
------------------------------------------------------------------------------------------------------

local L = AceLibrary('AceLocale-2.2'):new('Totemus')

L:RegisterTranslations('enUS', function() return {
  ['WELCOME'] = 'Totemus: /totemus or /totem for options.',
  ['SLASH_COMMANDS'] = { '/totemus', '/totem' },
  ['TOGGLE_CONFIG'] = 'Toggle the config panel',
  ['TOGGLE_MINIMAP'] = 'Toggle minimap icon',
  ['CLICK_TOGGLE_CONFIG'] = 'Click to toggle the config dialog!',
  ['ERROR_LOAD'] = 'Loading Error',
  ['NONE'] = 'None',

  -- identifiers
  ['IDENT_ZONE_AQ'] = 'Ahn\'Qiraj',

  -- labels
  ['ANKH'] = 'Ankh',
  
  --cooldown 
  ['COOLDOWN_REMAINING'] = 'Cooldown remaining',
  ['BUTTON_COOLDOWN_HOUR'] = 'h',
  ['BUTTON_COOLDOWN_MINUTES'] = 'm',
  ['TOOLTIP_COOLDOWN_HOUR'] = 'h',
  ['TOOLTIP_COOLDOWN_MINUTES'] = 'min',
  ['TOOLTIP_COOLDOWN_SECONDS'] = 's',
  
  -- user messages
  ['MSG_INCOMBAT'] = 'You\'re in combat',
  ['MSG_FULLMANA'] = 'You have full mana',
  ['MSG_FULLHEALTH'] = 'You have full health',
  
  --tooltips
  ['TOOLTIP_LEFTCLICK'] = 'Left Click',
  ['TOOLTIP_RIGHTCLICK'] = 'Right Click',
  ['TOOLTIP_MIDDLECLICK'] = 'Middle Click',
  ['TOOLTIP_DRINKFOOD'] = 'Drink/Food',
  ['TOOLTIP_CD_REINC'] = 'Reincarnation Cooldown',
  ['TOOLTIP_POTION'] = 'Potions',
  ['DRINKFOOD'] = 'Drink & Food',
  
  ['TAB_SPHERE'] = 'Sphere',
  ['TAB_BUTTONS'] = 'Buttons',
  ['TAB_MESSAGES'] = 'Messages',
  ['TAB_TIMERS'] = 'Timers',
  ['TAB_INVENTORY'] = 'Inventory',
  ['TAB_DEBUG'] = 'Debug',
  -- tooltips
  ['MESSAGES_TOOLTIPS'] = 'Show tooltips',
  ['MESSAGES_TOOLTIPS_DEFAULTPOS'] = 'Show tooltips at default position',
  -- options messages tab
  ['MESSAGES_LANGUAGE'] = 'Message language',
  ['MESSAGES_ONSCREEN'] = 'Show Totemus messages on screen',
  ['MESSAGES_TEXTURE_DEBUG'] = 'Show missing texture messages',
  ['MESSAGES_RAID'] = 'Show only short raid messages',
  ['MESSAGES_RANDOM'] = 'Random messages',
  ['MESSAGES_RANDOM_ANCESTRAL_SPIRIT'] = 'Ancestral Spirit',
  ['MESSAGES_RANDOM_MOUNT'] = 'Summon Mount',
  -- options button tab
  ['SHOW_BUTTONS'] = 'Show buttons',
  ['BUTTON_DRINK_FOOD'] = 'Drink and food',
  ['BUTTON_CD_REINC'] = 'Reincarnation Cooldown',
  ['BUTTON_POTION'] = 'Heal and mana potion',
  ['BUTTON_MOUNT'] = 'Mount',
  ['BUTTON_AIRMENU'] = 'Air menu',
  ['BUTTON_EAUMENU'] = 'Water menu',
  ['BUTTON_FEUMENU'] = 'Fire menu',
  ['BUTTON_TERREMENU'] = 'Earth menu',
  ['BUTTON_BUFFMENU'] = 'Weapon Buffs',
  ['BUTTON_ACTION_ONE'] = 'First Action Button',
  ['BUTTON_ACTION_TWO'] = 'Second Action Button',
  ['BUTTON_LOCK_LAST'] = 'Block last totem',
  -- options timers tab
  ['TIMERS_SHOW'] = 'Show TotemusTimers',
  ['TIMERS_LOCK'] = 'Lock TotemusTimers Position',
  ['TIMERS_ARRANGE'] = 'Icon Arrangement',
  ['TIMERS_ALIGN'] = 'Icon Alignment',
  ['TIMERS_WARN'] = 'Turn Expiration Warnings On/Off',
  ['TIMERS_NOTIFY'] = 'Turn Notifications On/Off',
  ['TIMERS_STYLE'] = 'Set TotemusTimers Style',
  ['TIMERS_TIME'] = 'Set Time Format',
  ['TIMERS_ORDER'] = 'Set Totem Ordering',
  -- options graphics tab
  ['LOCK_SPHERE'] = 'Lock sphere',
  ['LOCK_BUTTONS'] = 'Lock buttons to sphere',
  ['SPHERE_ROTATION'] = 'Rotate buttons',
  ['SPHERE_SCALE'] = 'Scale sphere',
  ['BUTTON_SCALE'] = 'Scale buttons',
  ['SPHERE_CIRCLE'] = 'Sphere circle',
  ['CIRCLE_TRANSPARENCY'] = 'Circle transparency',
  ['SPHERE_TEXT'] = 'Sphere text',
  ['MENU_KEEPOPEN'] = 'Keep menus open',
  ['HIDE_MINIMAP'] = 'Hide minimap button',
  -- status info titles
  ['STATUS_MANA'] = 'Mana',
  ['STATUS_HEALTH'] = 'Health',
  ['STATUS_XP'] = 'Experience',
  ['STATUS_DRINK_FOOD'] = 'Drink/Food',
  ['STATUS_CD_REINC'] = 'Reincarnation Cooldown',
  ['STATUS_SHIELD'] = 'Shield Count',
  ['STATUS_SHIELDREINC'] = 'Shield/Reincarnation',
  -- slot names
  ['SLOT_Trinket0Slot'] = 'Trinket 1';
  ['SLOT_Trinket1Slot'] = 'Trinket 2';
  -- debug
  ['DEBUG_ITEMDROP'] = 'Drag an item to the box';
  ['DEBUG_TEXTURES'] = 'Missing textures';
} end)
