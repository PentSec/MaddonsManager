if( GetLocale() == "deDE" ) then
-- Much Thanks to Oliver Becker for These.
-- Thanks to Danemo for help with the trinket translations 2.14.2006

TT_DISEASE_CLEANSING = "der Krankheitsreinigung";
TT_EARTHBIND = "der Erdbindung";
TT_FIRE_NOVA = "der Feuernova";
TT_FIRE_RESISTANCE = "des Feuerwiderstands";
TT_FIRE_RESISTANCE_AMEL = "Feuerwiderstands";
TT_FLAMETONGUE = "der Flammenzunge";
TT_FROST_RESISTANCE = "des Frostwiderstands";
TT_FROST_RESISTANCE_AMEL = "Frostwiderstands";
TT_GRACE_OF_AIR = "der luftgleichen Anmut";
TT_GRACE_OF_AIR_AMEL = "Luftgleichen Anmut";
TT_GROUNDING = "der Erdung";
TT_GROUNDING_AMEL = "Totem der Erdung";
TT_HEALING_STREAM = "des heilenden Flusses";
TT_HEALING_STREAM_AMEL = "Heilstrom";
TT_MAGMA = "des gl\195\188henden Magmas";
TT_ENAMORED_WATER_SPIRIT = "Entz\195\188ckter";
TT_ANCIENT_MANA_SPRING = "Uraltes Totem der Manaquelle";
TT_ANCIENT_MANA_SPRING_AMEL = "Manaquell";
TT_MANA_SPRING = "der Manaquelle";
TT_MANA_SPRING_AMEL = "Manaquell";
TT_MANA_TIDE = "der Manaflut";
TT_NATURE_RESISTANCE = "des Naturwiderstands";
TT_NATURE_RESISTANCE_AMEL = "Naturwiderstands";
TT_POISON_CLEANSING = "der Giftreinigung";
TT_SEARING = "der Verbrennung";
TT_SENTRY = "des Wachens";
TT_STONECLAW = "der Steinklaue";
TT_STONESKIN = "der Steinhaut";
TT_STONESKIN_AMEL = "Steinhaut";
TT_STRENGTH_OF_EARTH = "der Erdst\195\164rke";
TT_STRENGTH_OF_EARTH_AMEL = "St\195\164rke der Erde";
TT_TREMOR = "des Erdsto\195\159es";
TT_TRANQUIL_AIR = "der beruhigenden Winde";
TT_TRANQUIL_AIR_AMEL = "Beruhigenden Winde";
TT_WINDFURY = "des Windzorns";
TT_WINDWALL = "der Windmauer";
TT_WINDWALL_AMEL = "Windmauer";
TT_WRATH = "des Ingrimms";
TT_WRATH_AMEL = "Totem des Ingrimms";
TT_FIREELEM = "des Feuerelementars";
TT_EARTHELEM = "des Erdelementars";
TT_WRATHAIR = "des st\195\188rmischen Zorns";
TT_WRATHAIR_AMEL = "Totem des st\195\188rmischen Zorns";

TT_EARTH = "Erd";
TT_AIR = "Luft";
TT_WATER = "Wasser";
TT_FIRE = "Feuer";

TT_SHAMAN = "Schamane";

-- Here we do an aliasing.  Anytime we parse a chat message we see if we 
-- need to update the alias.  Simple search and replace.
TT_ALIAS = {};
TT_ALIAS[1] = { string = TT_NATURE_RESISTANCE, alias = "des Naturwiderstandes" };

TT_VERTICAL = "vertikal";
TT_HORIZONTAL = "horizontal";
TT_BOX = "box";
TT_LEFT = "links";
TT_RIGHT = "rechts";
TT_TOP = "oben";
TT_BOTTOM = "unten";
TT_ON = "an";
TT_OFF = "aus";
TT_BUFF = "buff";
TT_FIXED = "fixed";
TT_ELEMENT = "elemente";
TT_STICKY = "sticky";
TT_BLIZZARD = "blizzard";
TT_CT = "ct";
TT_SHOW = "zeigen";
TT_HIDE = "verstecken";
TT_LOCK = "sperren";
TT_UNLOCK = "entsperren";
TT_ARRANGE = "anordnung";
TT_ALIGN = "ausrichtung";
TT_WARN = "warnung";
TT_NOTIFY = "nachricht";
TT_STYLE = "stil";
TT_TIME = "zeit";
TT_ORDER = "reihenfolge";
TT_MSG = "msg";
TT_MSG_TT = "tt"
TT_MSG_SCT = "sct"

TT_USAGE = "Benutzung:";

-- define our possible options for each setting
TT_OPTION = {};
TT_OPTION[TT_ARRANGE] = {};
TT_OPTION[TT_ARRANGE][TT_VERTICAL] = TT_VERTICAL;
TT_OPTION[TT_ARRANGE]["vert"] = TT_VERTICAL;
TT_OPTION[TT_ARRANGE]["v"] = TT_VERTICAL;
TT_OPTION[TT_ARRANGE][TT_HORIZONTAL] = TT_HORIZONTAL;
TT_OPTION[TT_ARRANGE]["hor"] = TT_HORIZONTAL;
TT_OPTION[TT_ARRANGE]["h"] = TT_HORIZONTAL;
TT_OPTION[TT_ARRANGE][TT_BOX] = TT_BOX;
TT_OPTION[TT_ALIGN] = {};
TT_OPTION[TT_ALIGN][TT_LEFT] = TT_LEFT;
TT_OPTION[TT_ALIGN][TT_BOTTOM] = TT_LEFT;
TT_OPTION[TT_ALIGN][TT_RIGHT] = TT_RIGHT;
TT_OPTION[TT_ALIGN][TT_TOP] = TT_RIGHT;
TT_OPTION[TT_WARN] = {};
TT_OPTION[TT_WARN][TT_ON] = TT_ON;
TT_OPTION[TT_WARN][TT_OFF] = TT_OFF;
TT_OPTION[TT_NOTIFY] = {};
TT_OPTION[TT_NOTIFY][TT_ON] = TT_ON;
TT_OPTION[TT_NOTIFY][TT_OFF] = TT_OFF;
TT_OPTION[TT_STYLE] = {};
TT_OPTION[TT_STYLE][TT_BUFF] = TT_BUFF;
TT_OPTION[TT_STYLE][TT_FIXED] = TT_FIXED;
TT_OPTION[TT_STYLE][TT_ELEMENT] = TT_ELEMENT;
TT_OPTION[TT_STYLE][TT_STICKY] = TT_STICKY;
TT_OPTION[TT_TIME] = {};
TT_OPTION[TT_TIME][TT_BLIZZARD] = TT_BLIZZARD;
TT_OPTION[TT_TIME][TT_CT] = TT_CT;
TT_OPTION[TT_MSG] = {};
TT_OPTION[TT_MSG][TT_MSG_TT] = TT_MSG_TT;
TT_OPTION[TT_MSG][TT_MSG_SCT] = TT_MSG_SCT;

TT_SETTING = {};
TT_SETTING[TT_ARRANGE] = "[TT] Ausrichtung: %s";
TT_SETTING[TT_ALIGN] = "[TT] Anordnung: %s";
TT_SETTING[TT_WARN] = "[TT] Warnungen: %s";
TT_SETTING[TT_NOTIFY] = "[TT] Nachrichten: %s";
TT_SETTING[TT_STYLE] =  "[TT] Stil: %s";
TT_SETTING[TT_TIME] = "[TT] Zeitformat: %s";
TT_SETTING[TT_ORDER] = "[TT] Totem Order: %s";
TT_SETTING[TT_MSG] = "[TT] Messages displayed by %s.";

TT_DESTROYED = "ist zerst\195\182rt!";
TT_WARNING = "verschwindet bald!";

TT_LOADED = "TotemTimers Addon geladen";

-- Important Stuff
TT_CAST_REGEX1 = "Ihr wirkt Totem (.+)%.";
TT_CAST_REGEX2 = "Ihr wirkt Totem (.+)%.";

TT_DEATH_REGEX = "Totem (.+) (.+) ist zerst\195\182rt.";
TT_DAMAGE_REGEX = { 
	"trifft Totem (.+) (.+) kritisch f\195\188r",
	"trifft Totem (.+) (.+) f\195\188r",
	"auf Totem (.+) (.+) f\195\188r",
};

TT_TOTEM_REGEX = "Totem (.+)";
TT_TRINKET_REGEX ="Wassergeist";
TT_RANK_REGEX = "Rang (%d+)";
TT_ELEMENT_REGEX = "Werkzeuge: (.+)%totem";

TT_NAME_STRING = "Totem %s";
TT_NAME_LEVEL_STRING = "Totem %s %s";
TT_TOTEMIC_CALL = "Ihr bekommt .* Mana durch Ruf der Totems%."

TOTEMUS_SHIELD_LIGHT = "Blitzschlagschild";
TOTEMUS_SHIELD_WATER = "Wasserschild";
TOTEMUS_SHIELD_EARTH = "Erdschild";


-- bindings
BINDING_HEADER_TOTEMUSHEADER = "Totemus";
BINDING_NAME_TOTEMUSFEU1 = "Last Fire Totem 1";
BINDING_NAME_TOTEMUSFEU2 = "Last Fire Totem 2";
BINDING_NAME_TOTEMUSTERRE1 = "Last Earth Totem 1";
BINDING_NAME_TOTEMUSTERRE2 = "Last Earth Totem 2";
BINDING_NAME_TOTEMUSAIR1 = "Last Air Totem 1";
BINDING_NAME_TOTEMUSAIR2 = "Last Air Totem 2";
BINDING_NAME_TOTEMUSEAU1 = "Last Water Totem 1";
BINDING_NAME_TOTEMUSEAU2 = "Last Water Totem 2";

end
