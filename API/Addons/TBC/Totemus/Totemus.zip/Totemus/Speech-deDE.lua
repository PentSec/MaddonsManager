﻿------------------------------------------------------------------------------------------------------
-- Totemus - German speeches
--
-- Translated by: Poolpy
--
-- Maintainer: Poolpy
--
-- Based on Ideas by:
--   Venantes by Zirah (http://www.wowinterface.com/downloads/info6155-Venantes.html)
--   Necrosis LdC by Lomig and Nyx (http://necrosis.larmes-cenarius.net)
--   Original Necrosis Idea : Infernal (http://www.revolvus.com/games/interface/necrosis/)
------------------------------------------------------------------------------------------------------

TOTEMUS_RANDOM_MESSAGES_deDE = {
    ['RAID'] = {
        ['SHAMAN_ANCESTRAL_SPIRIT'] = 'I bring back to the life <target>',
    },
    ['SHAMAN_ANCESTRAL_SPIRIT'] = {
        "The spirit and the body will do only one >><target><<! One more time....",
        "It is not the moment to rest >><target><<! Go to work lazy boy !",
        "Let this day be known as the day >><target><< is died in the fight !",
    },
    ['MOUNT'] = {
        "Wenn's nicht f\195\188r den <mount> gewesen w\195\164re, h\195\164tte ich nie das Jahr an der Uni verbracht.",
        "Die Anweisungen lauteten, einfach Wasser hinzugeben und.... WHOA ein <mount>!",
    },
};
