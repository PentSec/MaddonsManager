------------------------------------------------------------------------------------------------------
-- Totemus - English speeches
--
-- Translated by: Poolpy
--
-- Maintainer: Poolpy
--
-- Based on Ideas by:
--   Venantes by Zirah (http://www.wowinterface.com/downloads/info6155-Venantes.html)
--   Necrosis LdC by Lomig and Nyx (http://necrosis.larmes-cenarius.net)
--   Original Necrosis Idea : Infernal (http://www.revolvus.com/games/interface/necrosis/)
------------------------------------------------------------------------------------------------------

TOTEMUS_RANDOM_MESSAGES_enUS = {
    ['RAID'] = {
        ['SHAMAN_ANCESTRAL_SPIRIT'] = 'I bring back to the life <target>',
    },
    ['SHAMAN_ANCESTRAL_SPIRIT'] = {
        "The spirit and the body will do only one >><target><<! One more time....",
        "It is not the moment to rest >><target><<! Go to work lazy boy !",
        "Let this day be known as the day >><target><< is died in the fight !",
    },
    ['MOUNT'] = {
        "If it wasn't for my <mount>, I wouldn't have spent that year in college.",
        "The directions said to just add water and... WHOA a <mount>!",
        "If it wasn't for my <mount>, I'd be walking.",
        "I'd love to hang around, but my <mount> needs exercise.",
        "Alright <mount>, I'm ready to ride!",
        "Fasten your seat belts, it's going to be a bouncy ride.",
        "Hi-ho <mount>...Away!!!",
        "You should see my other mount... but it's in the shop getting fixed.",
        "Shotgun!",
        "Hm, somethings growing out of my butt!",
        "Ah, now for some good old fashioned <mount> riding.",
        "Does this look like a <mount> to you? Oh, I guess it really is. Nevermind.",
        "Ok, mounting my <mount> now. Wait... that didn't come out right.",
    },
}