WIM has been updated as of v1.4.1 to be localizable.


If you wish to help translate, please send your
updated "localization.{language}.lua" files to:

johnlangone@gmail.com

Please be sure to include your name/handle (and server if you want),
so I can add you to the credits. Your help is much appreciated.

---------
  NOTES
---------

The file "localization.lua" is the default english translation.
It contains all of the definitions that need translating.
I have provided a change log on the bottom of this file in order
to make it easier between updates to identify which definitions
might have been added. (The definition list is quite large and
can be difficult to spot changes.)

If you have any questions, please feel free to send an email my way.

You may also visit http://www.wimaddon.com for more information.
