local MAJOR_VERSION ="AlarAddon-3.0"
local MINOR_VERSION = tonumber(string.sub("$Revision: 325 $", 12, -3))
local function pp(msg) -- Minimal output function
    if (not ALARDEVELOPMENTPC) then return end
    DEFAULT_CHAT_FRAME:AddMessage("|c0000ff00pp->|r" .. tostring(msg),1,0.5,0.2)
end
pp("Loading " .. MAJOR_VERSION .. " " .. MINOR_VERSION)
if (not LibStub) then
    pp("Couldn't find LibStub. Please reinstall " .. MAJOR_VERSION )
end
-- I hate having to do the same thing a lot of times... so here is my stub
-- It calls LibStub and returns an addon with all available ace3 embeddable
-- components mixed in
local stub=LibStub:NewLibrary(MAJOR_VERSION,MINOR_VERSION)
if (not stub ) then return end
function AlarLittlePrintUtility(...) -- Minimal output function
    if (not ALARDEVELOPMENTPC) then return end
    msg=''
	for i=1, select("#", ...) do
		msg = msg .. tostring( select( i, ...) ) .." "
	end    
    DEFAULT_CHAT_FRAME:AddMessage("|c0000ff00pp->|r" .. tostring(msg),1,0.5,0.2)
end
local pp=AlarLittlePrintUtility
function stub:new(name,...)
    local mixins={}
    for i,k in  LibStub:IterateLibraries() do
        if (i:match("Ace%w*-3%.0") and k.Embed) then
            table.insert(mixins,i)
        end
    end
    table.insert(mixins,"AlarCore-3.0")
    for i=1,select('#',...) do
        table.insert(mixins,(select(i,...)))
    end
    return LibStub("AceAddon-3.0"):NewAddon(name,unpack(mixins))
end
