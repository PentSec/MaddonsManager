local MAJOR_VERSION = "AlarWidgets-3.0"
local MINOR_VERSION = tonumber(string.sub("$Revision: 325 $", 12, -3))
local pp=AlarLittlePrintUtility or function() return end
pp("Loading " .. MAJOR_VERSION .. " " .. MINOR_VERSION)
if (not LibStub) then
    pp("Couldn't find LibStub. Please reinstall " .. MAJOR_VERSION )
end
local lib,old=LibStub:NewLibrary(MAJOR_VERSION,MINOR_VERSION)
if (not lib) then
    pp("Already loaded a new version of" .. MAJOR_VERSION)
    return -- Already loaded
end
if (old) then
    pp(format("Upgrading %s from %s to %s",MAJOR_VERSION,old,MINOR_VERSION))
end
lib.widgets=lib.widgets or {}
local AceGUI = LibStub("AceGUI-3.0")
lib.AceGUI=AceGUI
local WidgetVersion=MINOR_VERSION-65432
function lib:IterateWidgets() return pairs(self.widgets) end
----------------
-- Main Frame --
----------------
--[[
It would be nice if it was possible to derive from "standard" widgets
instead of redoing all the stuff but.... they dont think so.
Now, define some common methods
]]
-- called to set an external table to store status in
do
local proto={}
function proto:SetStatusTable(status)
	assert(type(status) == "table")
	pp(self.type,status,status.position)
	self.status = status
	self:ApplyStatus()
end
function proto:Show()
	self.frame:Show()
end

function proto:Acquire()
	self.frame:SetParent(UIParent)
	self.frame:SetFrameStrata("FULLSCREEN_DIALOG")
	self:ApplyStatus()
end

function proto:Release()
	self.status = nil
	for k in pairs(self.localstatus) do
		self.localstatus[k] = nil
	end
end

function proto:SetLocked(lock)
	local status = self.status or self.localstatus
	local old=status.locked
	status.locked=lock
	self:Lock()
	return old
end
function proto:GetLocked()
	local status = self.status or self.localstatus
	return status.locked
end
function lib.InjectStandardMethods(target)
    for k,v in pairs(proto) do
        target[k]=v
    end
end
end
function lib:CreatePanel()
    AceGUI:Create('AlarPanel')
end
function lib:CreateConfig()
    AceGUI:Create('AlarConfig')
end
function lib:CreateMiniMap()
    AceGUI:Create('AlarMinimapButton')
end
function lib:CreateCastButton()
    AceGUI:Create('AlarCastButton')
end
    