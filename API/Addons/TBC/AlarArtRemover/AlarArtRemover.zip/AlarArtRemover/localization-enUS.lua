AMO:Locale("enUS",{
["Hide gryphon"]=true,
["Hide pet bar"]=true,
["Hide lagmeter"]=true,
["Hide main bar"]=true,
["If checked, hides gryphon art"]=true,
["If checked, hides main bar art"]=true,
["If checked, hides lagmeter art"]=true,
["If checked, hides pet bar art"]=true
}
)
