Rock("LibRockLocale-1.0"):GetTranslationNamespace("Chinchilla"):AddTranslations("deDE", function() return {
	
} end)