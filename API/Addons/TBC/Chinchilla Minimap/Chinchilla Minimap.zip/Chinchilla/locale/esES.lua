Rock("LibRockLocale-1.0"):GetTranslationNamespace("Chinchilla"):AddTranslations("esES", function() return {
	
} end)