﻿
if (GetLocale() == "esES") then	
--clases
	DBM_MAGE		= "Mago";
	DBM_PRIEST		= "Sacerdote";
	DBM_PALADIN		= "Paladin";
	DBM_DRUID		= "Druida";
	DBM_WARLOCK		= "Brujo";
	DBM_ROGUE		= "Rogue";
	DBM_HUNTER		= "Cazador";
	DBM_WARRIOR		= "Guerrero";
	DBM_SHAMAN		= "Chaman";
--Zonas
	DBM_NAXX			= "Naxxramas";
	DBM_AQ40			= "Ahn'Qiraj";
	DBM_BWL			= "Blackwing Lair";
	DBM_MC				= "Molten Core";
	DBM_AQ20			= "Ruins of Ahn'Qiraj";
	DBM_ZG 			= "Zul'Gurub";
	DBM_ONYXIAS_LAIR	= "Onyxia's Lair";
	DBM_DUSKWOOD		= "Duskwood";
	DBM_ASHENVALE		= "Ashenvale";
	DBM_FERALAS		= "Feralas";
	DBM_HINTERLANDS	= "The Hinterlands";
	DBM_BLASTED_LANDS	= "Blasted Lands";
	DBM_AZSHARA		= "Azshara";
	DBM_HELLFIRE	= "Hellfire Peninsula";
	DBM_SHADOWMOON	= "Shadowmoon Valley";

	DBM_BLACK_MORASS	= "The Black Morass";

	DBM_BATTLEGROUND	= "Campo de Batalla";
	DBM_BATTLEGROUNDS	= "Campos de Batalla";
	DBM_ARATHI			= "Cuenca de Arathi";
	DBM_WARSONG		= "Garganta Grito de Guerra";
	DBM_ALTERAC		= "Valle de Alterac";
	DBM_EYEOFTHESTORM = "Ojo de la Tormenta";
--spells/buffs
	DBM_CHARGE			= "Carga";
	DBM_FERALCHARGE		= "Carga Feral";
	DBM_BLOODRAGE			= "Pacto de Sangre";
	DBM_REDEMPTION 		= "Redención del Espíritu";
	DBM_FEIGNDEATH			= "Feign Death";
	DBM_MINDCONTROL		= "Control Mental";

end
