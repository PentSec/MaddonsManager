ArcHUD 2.1
-------------

This addon adds a combat HUD to your UI, showing player/target/pet hp and mana/rage/whatever as rings centered on your screen. It uses the StatRings code originally made by Iriel but later modified by Antiarc. It also shows a small target frame with textual hp/mana as well as a 3D target model for other players.

It has support for FlightMap destination timers and also have a casting bar with spell text and timer. If the casting bar is enabled it will hide the default Blizzard casting bar.

ArcHud uses MobHealth2/MobInfo-2 for mob health display.

Based on Tivoli's beta Nurfed HUD which used the StatRings modification by Antiarc.

Some of the features implemented in ArcHUD was first implemented in other addons, credits goes out to Moog for his modification of NurfedHUD called Moog_Hud as well as to Repent for creating eCastingBar where I got the FlightMap support code from.

Once installed you can access ArcHUD options by typing /archud or /ah in the chat window.

Written by Saleel/Nenie of Argent Dawn.

