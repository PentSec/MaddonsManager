-- General purpose runtime-only properties.
local playerIsInCombat = false;

-- Runtime-only properties for player aggro.
local playerRuntimeInfo = {
    ["hasAggroStored"] = false,
    ["originalAggroEnemyGuid"] = nil,
    ["originalAggroEnemyIsTargetingMe"] = false,
    ["fadeStartTime"] = nil,
    ["includeEnemyNameInAggroText"] = false,
    ["aggroGainSoundFile"] = "Sound\\Doodad\\BellTollHorde.wav";
};

-- Runtime-only properties for pet aggro.
local petRuntimeInfo = {
    ["hasAggroStored"] = false,
    ["originalAggroEnemyGuid"] = nil,
    ["originalAggroEnemyIsTargetingMe"] = false,
    ["fadeStartTime"] = nil,
    ["includeEnemyNameInAggroText"] = false,
    ["aggroGainSoundFile"] = "Sound\\interface\\RaidWarning.wav";
};

-- Helper function for determining whether the given value is true or not. If the given value is nil this returns false.
function AggroNotifier_ForceBoolean(forceBoolean)
    if (forceBoolean == nil) then
        return false;
    elseif (forceBoolean == 1 or forceBoolean == "1" or string.lower(tostring(forceBoolean)) == "true") then
        return true;
    end
    
    return false;
end

-- Function for handling events that AggroNotifier cares about.
function AggroNotifier_GeneralEventHandler()
    if (event == "ADDON_LOADED" and arg1 == "AggroNotifier") then
        -- Set up a bidirectional link between the aggro text objects and the runtime variable arrays they are associated with.
        AggroNotifier_AggroText.runtimeInfo = playerRuntimeInfo;
        playerRuntimeInfo.aggroTextObject = AggroNotifier_AggroText;
        AggroNotifier_AggroTextPet.runtimeInfo = petRuntimeInfo;
        petRuntimeInfo.aggroTextObject = AggroNotifier_AggroTextPet;
        
        -- Load all our config stuff.
        AggroNotifier_LoadConfig();
    elseif (event=="PLAYER_REGEN_DISABLED") then
        -- The player just went into combat.
        playerIsInCombat = true;
    elseif (event=="PLAYER_REGEN_ENABLED") then
        -- The player has dropped out of combat.
        playerIsInCombat = false;
        -- The player definitely no longer has aggro, so we can clear out the original aggro enemy variables for both player and pet.
        playerRuntimeInfo.originalAggroEnemyGuid = nil;
        playerRuntimeInfo.originalAggroEnemyIsTargetingMe = false;
        petRuntimeInfo.originalAggroEnemyGuid = nil;
        petRuntimeInfo.originalAggroEnemyIsTargetingMe = false;
        
        if (playerRuntimeInfo.hasAggroStored) then
            playerRuntimeInfo.hasAggroStored = false;
            -- The player previously had aggro before combat ended though, so pop the aggro text back up 
            -- (now that we're out of combat there will be no aggro and the text will pop up the "all clear" green).
            AggroNotifier_ShowAggroText(AggroNotifier_AggroText);
        end
        
        if (petRuntimeInfo.hasAggroStored) then
            petRuntimeInfo.hasAggroStored = false;
            -- The pet previously had aggro before combat ended though, so pop the aggro text back up 
            -- (now that we're out of combat there will be no aggro and the text will pop up the "all clear" green).
            AggroNotifier_ShowAggroText(AggroNotifier_AggroTextPet);
        end
    end
end

-- Sets the aggro text font height for the given aggro text object. 
function AggroNotifier_SetAggroFontHeight(aggroTextObject, height)
    if (height <= 28) then
        -- If the height is 28 or below we can directly set the font size. This provides clear text.
        aggroTextObject:SetFont(GameFontNormal:GetFont(), height, "OUTLINE, THICKOUTLINE");
    else
        -- If the height is above 28 then we have to scale it using SetTextHeight(...). This provides blocky text, but at least it will be the desired size.
        local amountAboveNormalMaxHeight = height - 28;
        height = height + (amountAboveNormalMaxHeight * 2);
        aggroTextObject:SetFont(GameFontNormal:GetFont(), 28, "OUTLINE, THICKOUTLINE");
        aggroTextObject:SetTextHeight(height);
    end
end

-- Updates all the aggro text object behavior variables from the saved config values.
function AggroNotifier_UpdateAggroTextObjectsBehaviorVariablesFromConfig()
    -- Set a few runtime variables on the aggro text objects to be the current values of the config file.
    AggroNotifier_AggroText.runtimeInfo.includePvpTagInEnemyName = AggroNotifier_Config.desiredIncludePvpTagInEnemyName;
    AggroNotifier_AggroTextPet.runtimeInfo.includePvpTagInEnemyName = AggroNotifier_Config.desiredIncludePvpTagInEnemyNamePet;
    AggroNotifier_AggroText.runtimeInfo.desiredAggroText = AggroNotifier_Config.desiredAggroText;
    AggroNotifier_AggroTextPet.runtimeInfo.desiredAggroText = AggroNotifier_Config.desiredAggroTextPet;
    AggroNotifier_AggroText.runtimeInfo.genericAggroText = AggroNotifier_Config.desiredGenericAggroText;
    AggroNotifier_AggroTextPet.runtimeInfo.genericAggroText = AggroNotifier_Config.desiredGenericAggroTextPet;
    AggroNotifier_AggroText.runtimeInfo.fadeTimeMilliseconds = AggroNotifier_Config.desiredFadeTimeMilliseconds;
    AggroNotifier_AggroTextPet.runtimeInfo.fadeTimeMilliseconds = AggroNotifier_Config.desiredFadeTimeMillisecondsPet;
    AggroNotifier_AggroText.runtimeInfo.gainAggroColor = AggroNotifier_Config.gainAggroColor;
    AggroNotifier_AggroTextPet.runtimeInfo.gainAggroColor = AggroNotifier_Config.gainAggroColorPet;
    AggroNotifier_AggroText.runtimeInfo.loseAggroColor = AggroNotifier_Config.loseAggroColor;
    AggroNotifier_AggroTextPet.runtimeInfo.loseAggroColor = AggroNotifier_Config.loseAggroColorPet;
    AggroNotifier_AggroText.runtimeInfo.preventFadeoutOnAggroGain = AggroNotifier_Config.preventFadeoutOnAggroGain;
    AggroNotifier_AggroTextPet.runtimeInfo.preventFadeoutOnAggroGain = AggroNotifier_Config.preventFadeoutOnAggroGainPet;
    AggroNotifier_AggroText.runtimeInfo.playSoundOnAggroGain = AggroNotifier_Config.playSoundOnAggroGain;
    AggroNotifier_AggroTextPet.runtimeInfo.playSoundOnAggroGain = AggroNotifier_Config.playSoundOnAggroGainPet;
end

-- Helper function for calling AggroNotifier_InitializeAggroText(aggroTextObject, desiredAggroTextFontSize, desiredAggroText) on all the aggro text objects (Player and Pet).
function AggroNotifier_InitializeAllAggroText()
    AggroNotifier_InitializeAggroText(AggroNotifier_AggroText, AggroNotifier_Config.desiredAggroTextFontSize, AggroNotifier_Config.desiredAggroText);
    AggroNotifier_InitializeAggroText(AggroNotifier_AggroTextPet, AggroNotifier_Config.desiredAggroTextFontSizePet, AggroNotifier_Config.desiredAggroTextPet);
end

-- Initializes the given aggro text object with the given font size and aggro text. 
-- This function does some extra checking to set the runtime value for whether the enemy name should be included in the aggro text.
function AggroNotifier_InitializeAggroText(aggroTextObject, desiredAggroTextFontSize, desiredAggroText)
    -- Set the font size.
    AggroNotifier_SetAggroFontHeight(aggroTextObject, desiredAggroTextFontSize);

    -- Set up the aggro text box with the user's desired aggro text, and figure out if we'll need to include the enemy name in the aggro text.
    AggroNotifier_SetAggroText(aggroTextObject, desiredAggroText, nil, nil);
    if (string.find(desiredAggroText, AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN)) then
        aggroTextObject.runtimeInfo.includeEnemyNameInAggroText = true;
    else
        aggroTextObject.runtimeInfo.includeEnemyNameInAggroText = false;
    end
end

-- Sets the given text on the given aggro text object. You can pass in an enemy name and whether the enemy is PvP if relevant.
-- If there's a problem with the text (such as an enemy name replacement token not being replaced with the enemy name), 
-- then the generic aggro text for the given aggro text object will be used.
function AggroNotifier_SetAggroText(aggroTextObject, newText, enemyName, enemyIsPvp)
    -- Make sure our aggro text object is up-to-date with the latest behavioral config values.
    AggroNotifier_UpdateAggroTextObjectsBehaviorVariablesFromConfig();
    
    -- If the enemy name was passed in then we'll try to replace any enemy-name-replacement-token with the passed in name.
    if (enemyName ~= nil) then
        if ((enemyIsPvp ~= nil) and enemyIsPvp and aggroTextObject.runtimeInfo.includePvpTagInEnemyName) then
            enemyName = AGGRO_NOTIFIER_PVP_ENEMY_NAME_TAG.." "..enemyName;
        end
        newText = string.gsub(newText, AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN, enemyName);
    end
    
    -- If for some reason the enemy name replacement token is still in the string we're supposed to set, 
    -- then something went wrong and we should use the generic aggro text instead.
    if (string.find(newText, AGGRO_NOTIFIER_ENEMY_NAME_REPLACEMENT_TOKEN)) then
        aggroTextObject:SetText(aggroTextObject.runtimeInfo.genericAggroText);
    else
        aggroTextObject:SetText(newText);
    end
end

-- Shows the aggro text, but does a little bit of checking to make sure we haven't lost the enemy (for enemy name inclusion in the aggro text).
-- If there's no longer any enemy then the generic aggro text for the given aggro text object will be used instead of the regular aggro text.
function AggroNotifier_ShowAggroText(aggroTextObject)
    -- Make sure our aggro text object is up-to-date with the latest behavioral config values.
    AggroNotifier_UpdateAggroTextObjectsBehaviorVariablesFromConfig();
    
    if ((not aggroTextObject.runtimeInfo.hasAggroStored) and aggroTextObject.runtimeInfo.includeEnemyNameInAggroText) then
        -- We do not having aggro, but the normal aggro text has an enemy name token in it. Since there's no longer
        -- an enemy to put in that token slot, we should just use the generic aggro text.
        AggroNotifier_SetAggroText(aggroTextObject, aggroTextObject.runtimeInfo.genericAggroText, nil, nil);
    end
    
    AggroNotifier_RefreshAggroText(aggroTextObject);
end

-- Simply resets the fade start time for the given aggro text object so that it will pop up on the screen again, and unhides the given aggro text object so it can be seen.
function AggroNotifier_RefreshAggroText(aggroTextObject)
    aggroTextObject.runtimeInfo.fadeStartTime = GetTime();
    aggroTextObject:Show();
end

-- Forcibly hides the given aggro text object, even if it was being shown or in the middle of a fade.
function AggroNotifier_HideAggroText(aggroTextObject)
    aggroTextObject.runtimeInfo.fadeStartTime = nil;
    aggroTextObject.runtimeInfo.temporaryColorOverride = nil;
    aggroTextObject:SetVertexColor(0.00, 0.00, 0.00, 0.00);
    aggroTextObject:Hide();
end

-- Helper function for determining whether the player is solo or in a party/raid.
function AggroNotifier_IsSolo()
    local numPartyMembers = GetNumPartyMembers();
    local numRaidMembers = GetNumRaidMembers();
    return ((numPartyMembers == 0) and (numRaidMembers == 0));
end

-- Update function for the player, to determine whether the player aggro text should be shown.
function AggroNotifier_UpdatePlayer(self, elapsed)
    AggroNotifier_UpdateSpecifiedUnit("player", AggroNotifier_AggroText, playerRuntimeInfo, AggroNotifier_Config.addonEnabled, AggroNotifier_Config.soloEnabledForMobs, 
            AggroNotifier_Config.soloEnabledForPvp, AggroNotifier_Config.desiredAlwaysSearchForAggro, AggroNotifier_Config.desiredExtraTargetSearchDepth, 
            AggroNotifier_Config.desiredRefreshAggroTextOnEveryNewAggro);
end

-- Update function for the pet, to determine whether the pet aggro text should be shown.
function AggroNotifier_UpdatePet(self, elapsed)
    AggroNotifier_UpdateSpecifiedUnit("pet", AggroNotifier_AggroTextPet, petRuntimeInfo, AggroNotifier_Config.addonEnabledPet, AggroNotifier_Config.soloEnabledForMobsPet, 
            AggroNotifier_Config.soloEnabledForPvpPet, AggroNotifier_Config.desiredAlwaysSearchForAggroPet, AggroNotifier_Config.desiredExtraTargetSearchDepthPet, 
            AggroNotifier_Config.desiredRefreshAggroTextOnEveryNewAggroPet);
end

-- Helper function for determining whether the specified unit's aggro text object should be shown.
function AggroNotifier_UpdateSpecifiedUnit(specifiedUnitId, aggroTextObject, runtimeInfo, addonEnabled, soloEnabledForMobs, soloEnabledForPvp, alwaysSearchForAggro, 
            extraTargetSearchDepth, refreshAggroTextOnEveryNewAggro)
            
    -- See if we should bail without doing anything (depending on the user's option choices).
    local bail = false;
    if (not addonEnabled) then
        bail = true;
    elseif (AggroNotifier_IsSolo() and (not soloEnabledForMobs) and (not soloEnabledForPvp)) then
        bail = true;
    end
    
    if (bail) then
        -- Call the aggro text handler, which will fade (or hide) the text appropriately, and then return early from this function.
        AggroNotifier_HandleTextFade(self, aggroTextObject);
        
        return;
    end

    -- We only want to worry about the aggro text at all (and incur the associated processing time) if we're in combat or the fader is still going.
    -- However the specified unit can choose to always search for aggro if they want.
    if (playerIsInCombat or (runtimeInfo.fadeStartTime ~= nil) or alwaysSearchForAggro) then
    
        -- Find out if we have aggro right now.
        local specifiedUnitHasAggroThisTick = AggroNotifier_SpecifiedUnitHasAggro(specifiedUnitId, runtimeInfo, aggroTextObject, 
                extraTargetSearchDepth, soloEnabledForPvp, soloEnabledForMobs, refreshAggroTextOnEveryNewAggro);
    
        -- If the aggro status has changed then we want to pop up the aggro text box with a brand new fade timer.
        if (specifiedUnitHasAggroThisTick ~= runtimeInfo.hasAggroStored) then
            runtimeInfo.hasAggroStored = specifiedUnitHasAggroThisTick;
            AggroNotifier_ShowAggroText(aggroTextObject);
            
            -- Play a sound if desired and appropriate.
            if (runtimeInfo.playSoundOnAggroGain and specifiedUnitHasAggroThisTick) then
                PlaySoundFile(runtimeInfo.aggroGainSoundFile);            
            end
        end
        
        -- Call the aggro text handler, which will fade (or hide) the text appropriately.
        AggroNotifier_HandleTextFade(self, aggroTextObject);
    end
end

-- The guts of AggroNotifier. This function determines whether the specified unit has aggro right now.
function AggroNotifier_SpecifiedUnitHasAggro(specifiedUnitId, runtimeInfo, aggroTextObject, desiredExtraTargetSearchDepth, soloEnabledForPvp, soloEnabledForMobs, shouldRefreshAggroTextOnEveryNewAggro)
    -- NOTE: In comments in this function, the specifiedUnitId variable passed into this function as an argument will always be referred to as the "specified unit".
    --[[ 
        There's no easy way to find out if any particular unit (player, pet, etc) has a hostile targeting him due to Blizzard's scripting restrictions. Therefore we have to do it the hard way:
        Generate a list of unit IDs that we need to check. These unit IDs will be all the targets of of all known friendlies.
        For each of these units, we see if it is hostile and targeting the specified unit. If any are hostile and targeting the specified unit then the specified unit has aggro.
    ]]
    local unitIdsToCheckArray = {};
    local arrayNextOpenIndex = 1;
    
    -- Add the static targets (the player's target, the player's focus target, the player's pet target, the mouseover unit, and the mouseover unit's target).
    unitIdsToCheckArray[arrayNextOpenIndex] = "focustarget";
    arrayNextOpenIndex = arrayNextOpenIndex + 1;
    unitIdsToCheckArray[arrayNextOpenIndex] = "playertarget";
    arrayNextOpenIndex = arrayNextOpenIndex + 1;
    unitIdsToCheckArray[arrayNextOpenIndex] = "pettarget";
    arrayNextOpenIndex = arrayNextOpenIndex + 1;
    unitIdsToCheckArray[arrayNextOpenIndex] = "mouseover";
    arrayNextOpenIndex = arrayNextOpenIndex + 1;
    unitIdsToCheckArray[arrayNextOpenIndex] = "mouseovertarget";
    arrayNextOpenIndex = arrayNextOpenIndex + 1;
    
    -- Add all party members' targets (including party members' pets).
    local numPartyMembers = GetNumPartyMembers();
    if (numPartyMembers > 0) then
        for i = 1, numPartyMembers do
            unitIdsToCheckArray[arrayNextOpenIndex] = "party"..i.."target";
            arrayNextOpenIndex = arrayNextOpenIndex + 1;
            unitIdsToCheckArray[arrayNextOpenIndex] = "partypet"..i.."target";
            arrayNextOpenIndex = arrayNextOpenIndex + 1;
        end
    end
    
    -- Add all raid members' targets (including raid members' pets).
    local numRaidMembers = GetNumRaidMembers();
    if (numRaidMembers > 0) then
        for i = 1, numRaidMembers do
            unitIdsToCheckArray[arrayNextOpenIndex] = "raid"..i.."target";
            arrayNextOpenIndex = arrayNextOpenIndex + 1;
            unitIdsToCheckArray[arrayNextOpenIndex] = "raidpet"..i.."target";
            arrayNextOpenIndex = arrayNextOpenIndex + 1;
        end
    end
    
    local isSolo = AggroNotifier_IsSolo();
    
    -- Now we want to dig through our list of friendly unit IDs and look at each one's target. 
    -- If the friendly unit's target is not friendly, is alive, and is targeting the specified unit, then the specified unit has aggro.
    local specifiedUnitHasAggroThisTick = false;
    local enemyUnitGuidOfThisTickAggro = nil;
    local originalAggroEnemyFoundThisTick = false;
    -- Addon users have the option of digging down multiple levels of "target of target of target" etc, 
    -- so run a loop depending on how many levels deep they want to go.
    local currentExtraTargetDepthLevel = 0;
    while ((not specifiedUnitHasAggroThisTick) and (currentExtraTargetDepthLevel <= desiredExtraTargetSearchDepth)) do
    
        -- At each target depth level we want to run through our entire list of possible enemy unit IDs.
        local indexToProcess = 1;
        while ((not specifiedUnitHasAggroThisTick) and (indexToProcess < arrayNextOpenIndex)) do
        
            -- Grab the potential enemy unit ID from our list.
            local enemyUnitId = unitIdsToCheckArray[indexToProcess];
            -- Add any extra target levels to the unit ID if necessary.
            for i = 1, currentExtraTargetDepthLevel do
                enemyUnitId = enemyUnitId.."target";
            end
            
            -- If the unit we're checking is *not* friendly to the specified unit then they may be aggro'd on the specified unit and we should check further.
            -- NOTE: We can't use the UnitIsEnemy(...) function because that returns false when the other unit is neutral, even if it's aggro'd on the specified unit.
            if (not UnitIsFriend(specifiedUnitId, enemyUnitId)) then
            
                -- Remember the enemy GUID for later in case we need it.
                local enemyGuid = UnitGUID(enemyUnitId);
                if (runtimeInfo.originalAggroEnemyGuid ~= nil and runtimeInfo.originalAggroEnemyGuid == enemyGuid) then
                    -- We found the original aggro enemy. See if it's still targeting the specified unit.
                    originalAggroEnemyFoundThisTick = true;
                    
                    if (UnitIsDeadOrGhost(enemyUnitId) or (not UnitIsUnit(enemyUnitId.."target", specifiedUnitId))) then
                        -- The original aggro enemy is dead or no longer targeting the specified unit. This info may be used later to indicate "all clear" for the specified unit.
                        runtimeInfo.originalAggroEnemyIsTargetingMe = false;
                    end
                end
                
                -- See if this enemy is alive and targeting the specified unit.
                if ((UnitIsUnit(enemyUnitId.."target", specifiedUnitId)) and (not UnitIsDeadOrGhost(enemyUnitId))) then
                    -- We may want to ignore this if we're solo and the function arguments want us to ignore it.
                    local enemyIsPvp = UnitPlayerControlled(enemyUnitId);
                    local enemyIsMob = (not enemyIsPvp);
                    local ignoreEnemy = false;
                    if (isSolo and enemyIsPvp and (not soloEnabledForPvp)) then
                        ignoreEnemy = true;
                    elseif (isSolo and enemyIsMob and (not soloEnabledForMobs)) then
                        ignoreEnemy = true;
                    end
                
                    if (not ignoreEnemy) then
                        -- The enemy is alive and targeting the specified unit, so the specified unit has aggro this tick. We should keep track of the enemy's GUID.
                        specifiedUnitHasAggroThisTick = true;
                        enemyUnitGuidOfThisTickAggro = enemyGuid;
                        -- If the specified unit desires, stuff the enemy name into the aggro text.
                        if (runtimeInfo.includeEnemyNameInAggroText) then
                            AggroNotifier_SetAggroText(aggroTextObject, aggroTextObject.runtimeInfo.desiredAggroText, UnitName(enemyUnitId), enemyIsPvp);
                        end
                    end
                 end
            end
            
            indexToProcess = indexToProcess + 1;
        end
        
        currentExtraTargetDepthLevel = currentExtraTargetDepthLevel + 1;
    end
    
    -- See if aggro refreshing is allowed. It's allowed if we had an original aggro enemy but that enemy wasn't found this tick, and the specified unit has aggro this tick.
    local aggroRefreshAllowedIfDesiredThisTick = false;
    if (runtimeInfo.originalAggroEnemyGuid ~= nil and (not originalAggroEnemyFoundThisTick) and specifiedUnitHasAggroThisTick) then
        aggroRefreshAllowedIfDesiredThisTick = true;
    end
    
    -- Make sure the aggro text refreshes if the specified unit desired it, it's allowed, and we have aggro this tick.
    if (shouldRefreshAggroTextOnEveryNewAggro and aggroRefreshAllowedIfDesiredThisTick and specifiedUnitHasAggroThisTick) then
        -- Set the original aggro enemy to be whatever we found this tick.
        runtimeInfo.originalAggroEnemyGuid = enemyUnitGuidOfThisTickAggro;
        runtimeInfo.originalAggroEnemyIsTargetingMe = true;
        -- Refresh the aggro text.
        AggroNotifier_RefreshAggroText(aggroTextObject);
    end
                
    -- See if we have an original aggro enemy.
    if (runtimeInfo.originalAggroEnemyGuid ~= nil) then
        --[[ 
            If we have an original aggro enemy and we haven't definitively identified that it has switched aggro to something else, then we should assume that the specified unit still has aggro
            and short circuit by returning true.
            NOTE: We have to make this assumption because Blizzard doesn't allow us to look up a unit by GUID, so if nobody's targeting the original aggro enemy it won't show up
                 as an enemy this tick, even though it might still be aggro'd on the specified unit. Therefore it's safer to assume the specified unit still has aggro than to give them a false
                 sense of security by giving the "all clear" when it may not be all clear.
        ]]
        if (runtimeInfo.originalAggroEnemyIsTargetingMe) then
            return true;
        else
            -- The original aggro enemy has definitely switched aggro to something else if we reach here. 
            -- Therefore if there's aggro this tick we should update the original aggro enemy variables to the new values we just found.
            -- Otherwise we're "all clear" and can clear the original aggro enemy variables entirely.
            if (specifiedUnitHasAggroThisTick) then
                runtimeInfo.originalAggroEnemyGuid = enemyUnitGuidOfThisTickAggro;
                runtimeInfo.originalAggroEnemyIsTargetingMe = true;
            else
                runtimeInfo.originalAggroEnemyGuid = nil;
                runtimeInfo.originalAggroEnemyIsTargetingMe = false;
            end
        end
    else
        -- There was no original aggro enemy when we checked for aggro at the start of this tick, but we might have found a new one!
        if (specifiedUnitHasAggroThisTick) then
            runtimeInfo.originalAggroEnemyGuid = enemyUnitGuidOfThisTickAggro;
            runtimeInfo.originalAggroEnemyIsTargetingMe = true;
        end
    end
    
    return specifiedUnitHasAggroThisTick;
end

-- This function sets the proper color and transparency values for the given aggro text object, based on how long it's been since the fade-time-start (thus allowing for text fade).
-- If it's been too long since the fade was started, then this function will hide the given aggro text object completely.
function AggroNotifier_HandleTextFade(self, aggroTextObject)
    -- If fadeStartTime is nil then there's nothing for us to do!
    if (aggroTextObject.runtimeInfo.fadeStartTime ~= nil) then
        -- Make sure our aggro text object is up-to-date with the latest behavioral config values.
        AggroNotifier_UpdateAggroTextObjectsBehaviorVariablesFromConfig();
    
        local hasAggroAndAlwaysOn = aggroTextObject.runtimeInfo.preventFadeoutOnAggroGain and aggroTextObject.runtimeInfo.hasAggroStored;
        
        -- Figure out how long it's been since we started the fadeout.
        local totalElapsedSinceFadeStartTimeMilliseconds = (GetTime() - aggroTextObject.runtimeInfo.fadeStartTime) * 1000;
        -- If the elapsed time since we started fadeout is shorter than the desired fadeout time, then we need to update the aggro text with a new fadeout value.
        -- We also continue here if we have aggro and the always-on option is true.
        if (hasAggroAndAlwaysOn or totalElapsedSinceFadeStartTimeMilliseconds < aggroTextObject.runtimeInfo.fadeTimeMilliseconds) then
            -- Figure out the alpha value the aggro text should be at so that it will be fully opaque at the start of the fadeout 
            -- and smoothly fade to fully transparent when the desired fadeout time has been reached.
            local alphaValue = totalElapsedSinceFadeStartTimeMilliseconds / aggroTextObject.runtimeInfo.fadeTimeMilliseconds;
            
            -- Update the aggro text to the new alpha value, and color it red if the unit has aggro and green if the unit does not have aggro.
            if (aggroTextObject.runtimeInfo.hasAggroStored) then
                local r, g, b, alphaFactor = unpack(aggroTextObject.runtimeInfo.gainAggroColor);
                if (aggroTextObject.runtimeInfo.temporaryColorOverride ~= nil) then
                    r, g, b, alphaFactor = unpack(aggroTextObject.runtimeInfo.temporaryColorOverride);
                end
                local newAlpha = (1.00 - alphaValue) * alphaFactor;
                
                -- Force the alpha value to be max allowed if we're always-on.
                if (hasAggroAndAlwaysOn) then
                    newAlpha = 1.00 * alphaFactor;
                end
                
                aggroTextObject:SetVertexColor(r, g, b, newAlpha);
            else
                local r, g, b, alphaFactor = unpack(aggroTextObject.runtimeInfo.loseAggroColor);
                if (aggroTextObject.runtimeInfo.temporaryColorOverride ~= nil) then
                    r, g, b, alphaFactor = unpack(aggroTextObject.runtimeInfo.temporaryColorOverride);
                end
                local newAlpha = (1.00 - alphaValue) * alphaFactor;
                aggroTextObject:SetVertexColor(r, g, b, newAlpha);
            end
        else
            -- We've gone past the desired fadeout time, so we need to nullify the fadeStartTime variable and hide the aggro text.
            AggroNotifier_HideAggroText(aggroTextObject);
        end
    end
end
    