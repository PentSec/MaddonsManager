-- Config storage property
AggroNotifier_Config = {};

-- Constants
local DRAGGER_FRAME_Y_OFFSET = -20;
local DRAGGER_FRAME_Y_OFFSET_PET = -50;

-- Config property defaults
local configDefaultDesiredFadeTimeMilliseconds = 2.50 * 1000;
local configDefaultDesiredExtraTargetSearchDepth = 0;
local configDefaultRefreshAggroTextOnEveryNewAggro = true;
local configDefaultAlwaysSearchForAggro = true;
local configDefaultIncludePvpTagInEnemyName = true;
local configDefaultAddonEnabled = true;
local configDefaultSoloEnabledForMobs = true;
local configDefaultSoloEnabledForPvp = true;
local configDefaultGainAggroColor = { 1.00, 0.00, 0.00, 1.00 };
local configDefaultLoseAggroColor = { 0.00, 1.00, 0.00, 1.00 };
local configDefaultGainAggroColorPet = { 1.00, 0.22, 0.00, 1.00 };
local configDefaultLoseAggroColorPet = { 0.00, 1.00, 0.29, 1.00 };
local configDefaultAggroTextLocationOffsets = { 0, DRAGGER_FRAME_Y_OFFSET, "CENTER", "CENTER" };
local configDefaultAggroTextLocationOffsetsPet = { 0, DRAGGER_FRAME_Y_OFFSET_PET, "CENTER", "CENTER" };
local configDefaultDesiredAggroTextFontSize = 28; -- 28 is the max font height allowed before you have to resort to SetTextHeight, which distorts the text.
local configDefaultDesiredAggroTextFontSizePet = 24;
local configDefaultPreventFadeoutOnAggroGain = false;
local configDefaultPlaySoundOnAggroGain = true;

-- Set up key/default pairings for our config properties. The first value in each subarray is the name of the config property in the config file (the key).
-- The second value is the desired default for that property.
local configDefaultsArray = {
        -- Set up the key/default pairings for normal config stuff. 
        {"desiredFadeTimeMilliseconds", configDefaultDesiredFadeTimeMilliseconds},
        {"desiredExtraTargetSearchDepth", configDefaultDesiredExtraTargetSearchDepth},
        {"desiredAggroText", AGGRO_NOTIFIER_NORMAL_AGGRO_TEXT},
        {"desiredGenericAggroText", AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT},
        {"desiredRefreshAggroTextOnEveryNewAggro", configDefaultRefreshAggroTextOnEveryNewAggro},
        {"desiredAlwaysSearchForAggro", configDefaultAlwaysSearchForAggro},
        {"desiredIncludePvpTagInEnemyName", configDefaultIncludePvpTagInEnemyName},
        {"addonEnabled", configDefaultAddonEnabled},
        {"soloEnabledForMobs", configDefaultSoloEnabledForMobs},
        {"soloEnabledForPvp", configDefaultSoloEnabledForPvp},
        {"gainAggroColor", configDefaultGainAggroColor},
        {"loseAggroColor", configDefaultLoseAggroColor},
        {"desiredAggroTextFontSize", configDefaultDesiredAggroTextFontSize},
        {"desiredAggroTextLocationOffsets", configDefaultAggroTextLocationOffsets},
        {"preventFadeoutOnAggroGain", configDefaultPreventFadeoutOnAggroGain},
        {"playSoundOnAggroGain", configDefaultPlaySoundOnAggroGain},
        -- Do the same for our pet config stuff.
        {"desiredFadeTimeMillisecondsPet", configDefaultDesiredFadeTimeMilliseconds},
        {"desiredExtraTargetSearchDepthPet", configDefaultDesiredExtraTargetSearchDepth},
        {"desiredAggroTextPet", AGGRO_NOTIFIER_NORMAL_PET_AGGRO_TEXT},
        {"desiredGenericAggroTextPet", AGGRO_NOTIFIER_GENERIC_PET_AGGRO_TEXT},
        {"desiredRefreshAggroTextOnEveryNewAggroPet", configDefaultRefreshAggroTextOnEveryNewAggro},
        {"desiredAlwaysSearchForAggroPet", configDefaultAlwaysSearchForAggro},
        {"desiredIncludePvpTagInEnemyNamePet", configDefaultIncludePvpTagInEnemyName},
        {"addonEnabledPet", configDefaultAddonEnabled},
        {"soloEnabledForMobsPet", configDefaultSoloEnabledForMobs},
        {"soloEnabledForPvpPet", configDefaultSoloEnabledForPvp},
        {"gainAggroColorPet", configDefaultGainAggroColorPet},
        {"loseAggroColorPet", configDefaultLoseAggroColorPet},
        {"desiredAggroTextFontSizePet", configDefaultDesiredAggroTextFontSizePet},
        {"desiredAggroTextLocationOffsetsPet", configDefaultAggroTextLocationOffsetsPet},
        {"preventFadeoutOnAggroGainPet", configDefaultPreventFadeoutOnAggroGain},
        {"playSoundOnAggroGainPet", configDefaultPlaySoundOnAggroGain}
    };

-- Script-built frame stuff
local maxAllowedFadeTimeMilliseconds = 10 * 1000;
local maxAllowedExtraTargetSearchDepth = 2;
local AggroNotifier_OptionsFrameContainer;
-- Script-built frame stuff for player
local AggroNotifier_OptionsSubFrameAppearance;
local AggroNotifier_OptionsSubFrameBehavior;
local AggroNotifier_OptionsGenericAggroTextEditBox;
local AggroNotifier_OptionsAggroTextEditBox;
local AggroNotifier_OptionsIncludePvpInEnemyNameCheckbox;
local AggroNotifier_OptionsFadeTimeSlider;
local AggroNotifier_OptionsExtraTargetSearchDepthSlider;
local AggroNotifier_OptionsRefreshAggroTextCheckbox;
local AggroNotifier_OptionsAlwaysSearchForAggroCheckbox;
local AggroNotifier_OptionsAddonEnabledCheckbox;
local AggroNotifier_OptionsSoloEnabledForMobsCheckbox;
local AggroNotifier_OptionsSoloEnabledForPvpCheckbox;
local AggroNotifier_OptionsGainAggroColorButton;
local AggroNotifier_OptionsLoseAggroColorButton;
local AggroNotifier_OptionsFontSizeSlider;
local AggroNotifier_OptionsResetAggroTextAnchorButton;
local AggroNotifier_OptionsShowAggroTextAnchorButton;
local AggroNotifier_OptionsPreventFadeoutCheckbox;
local AggroNotifier_OptionsPlaySoundCheckbox;
-- Script-built frame stuff for pet
local AggroNotifier_PetOptionsSubFrameAppearance;
local AggroNotifier_PetOptionsSubFrameBehavior;
local AggroNotifier_PetOptionsGenericAggroTextEditBox;
local AggroNotifier_PetOptionsAggroTextEditBox;
local AggroNotifier_PetOptionsIncludePvpInEnemyNameCheckbox;
local AggroNotifier_PetOptionsFadeTimeSlider;
local AggroNotifier_PetOptionsExtraTargetSearchDepthSlider;
local AggroNotifier_PetOptionsRefreshAggroTextCheckbox;
local AggroNotifier_PetOptionsAlwaysSearchForAggroCheckbox;
local AggroNotifier_PetOptionsAddonEnabledCheckbox;
local AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox;
local AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox;
local AggroNotifier_PetOptionsGainAggroColorButton;
local AggroNotifier_PetOptionsLoseAggroColorButton;
local AggroNotifier_PetOptionsFontSizeSlider;
local AggroNotifier_PetOptionsResetAggroTextAnchorButton;
local AggroNotifier_PetOptionsShowAggroTextAnchorButton;
local AggroNotifier_PetOptionsPreventFadeoutCheckbox;
local AggroNotifier_PetOptionsPlaySoundCheckbox;

-- Runtime-only properties - player
local allowAggroTextRefreshForFontSizeSlider = false;
local optionsFrameActive = false;
local appearanceOptionsSubFrameLoaded = false;
-- Runtime-only properties - pet
local allowPetAggroTextRefreshForFontSizeSlider = false;
local petOptionsFrameActive = false;
local petAppearanceOptionsSubFrameLoaded = false;


-- Initial load function, hooked by one of the OnLoad events in our frame XML file.
function AggroNotifier_Load()
    -- Register for a few events so that we can load the addon properly and keep track of whether the player's in combat or not.
    this:RegisterEvent("ADDON_LOADED");
    this:RegisterEvent("PLAYER_REGEN_DISABLED");
    this:RegisterEvent("PLAYER_REGEN_ENABLED");
end

-- Config loading function. Called when the addon is finished loading (via the ADDON_LOADED event), this is responsible for 
-- making sure the config file is loaded and initialized properly, then sets up various widgets that rely on the config file settings.
function AggroNotifier_LoadConfig()
    -- Load all the stored values from our config. Initialize config properties to defaults if they're not already saved.
    -- Do this by running through each key/default pair from our config defaults array and set the default if necessary.
    for i, configKeyDefaultPair in ipairs(configDefaultsArray) do
        local key = configKeyDefaultPair[1];
        local default = configKeyDefaultPair[2];
        
        if (AggroNotifier_Config[key] == nil) then
            AggroNotifier_Config[key] = default;
        end
    end
    
    -- Generate our options panes.
    AggroNotifier_GenerateOptionsFrame();
    
    -- Initialize the aggro text frame draggers now that the config file has been loaded.
    AggroNotifier_InitializeAggroFrameDraggers();
    
    -- Initialize the aggro text itself now that the config file has been loaded.
    AggroNotifier_InitializeAllAggroText();
    
    -- Setup our options frames and attach them to blizzard's addon-options frame.
    AggroNotifier_OptionsFrameContainer.name = AGGRO_NOTIFIER_ADDON_NAME; -- Set the title of our options container frame.
    AggroNotifier_OptionsFrameContainer.okay = AggroNotifier_UpdateOptionsFrame; -- Link the ok button to our options frame update function.
    AggroNotifier_OptionsFrameContainer.cancel = AggroNotifier_CancelOptionsFrame; -- Link the cancel button to our options frame cancel function.

    AggroNotifier_OptionsSubFrameAppearance.name = AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_APPEARANCE;
    AggroNotifier_OptionsSubFrameAppearance.parent = AGGRO_NOTIFIER_ADDON_NAME; -- By setting the parent variable this will show up as a subframe of our main options container.
    
    AggroNotifier_OptionsSubFrameBehavior.name = AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_BEHAVIOR;
    AggroNotifier_OptionsSubFrameBehavior.parent = AGGRO_NOTIFIER_ADDON_NAME;
    
    AggroNotifier_PetOptionsSubFrameAppearance.name = AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_APPEARANCE_PET;
    AggroNotifier_PetOptionsSubFrameAppearance.parent = AGGRO_NOTIFIER_ADDON_NAME;
    
    AggroNotifier_PetOptionsSubFrameBehavior.name = AGGRO_NOTIFIER_OPTIONS_FRAME_LABEL_BEHAVIOR_PET;
    AggroNotifier_PetOptionsSubFrameBehavior.parent = AGGRO_NOTIFIER_ADDON_NAME;
    
    InterfaceOptions_AddCategory(AggroNotifier_OptionsFrameContainer);
    InterfaceOptions_AddCategory(AggroNotifier_OptionsSubFrameAppearance);
    InterfaceOptions_AddCategory(AggroNotifier_OptionsSubFrameBehavior);
    InterfaceOptions_AddCategory(AggroNotifier_PetOptionsSubFrameAppearance);
    InterfaceOptions_AddCategory(AggroNotifier_PetOptionsSubFrameBehavior);
    
    DEFAULT_CHAT_FRAME:AddMessage("AggroNotifier Loaded");
end

-- Sets up the aggro text frame draggers for the first time.
function AggroNotifier_InitializeAggroFrameDraggers()
    -- Set a few properties on the frame draggers so the helper functions know what to do.
    AggroNotifier_AggroFrameDragger.isPet = false;
    AggroNotifier_AggroFrameDraggerPet.isPet = true;

    AggroNotifier_AggroFrameDragger.locationOffsetsConfigPropertyName = "desiredAggroTextLocationOffsets";
    AggroNotifier_AggroFrameDraggerPet.locationOffsetsConfigPropertyName = "desiredAggroTextLocationOffsetsPet";

    AggroNotifier_AggroFrame.textObject = AggroNotifier_AggroText;
    AggroNotifier_AggroFramePet.textObject = AggroNotifier_AggroTextPet;
    AggroNotifier_AggroFrameDragger.textFrame = AggroNotifier_AggroFrame;
    AggroNotifier_AggroFrameDraggerPet.textFrame = AggroNotifier_AggroFramePet;

    -- Initialize the regular and pet frame draggers.    
    AggroNotifier_InitializeDraggerFrameObject(AggroNotifier_AggroFrameDragger, AGGRO_NOTIFIER_DRAG_AGGRO_TEXT);
    AggroNotifier_InitializeDraggerFrameObject(AggroNotifier_AggroFrameDraggerPet, AGGRO_NOTIFIER_DRAG_AGGRO_TEXT_PET);
end

-- Helper function for AggroNotifier_InitializeAggroFrameDraggers() that initializes the specified frame dragger.
function AggroNotifier_InitializeDraggerFrameObject(draggerFrame, frameText)
    -- Setup the aggro frame dragger bits. Start with the frame dragger text.
    draggerFrame.text = draggerFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal");
    draggerFrame.text:SetText(frameText);
    draggerFrame.text:SetPoint("LEFT", 8, 0);
    
    -- Reset the frame dragger width based on the text width (with room left over for the button).  
    draggerFrame:SetWidth(draggerFrame.text:GetStringWidth() + 40);
    
    -- Setup the frame dragger close box.
    draggerFrame.closeButton = CreateFrame("Button", nil, draggerFrame, "UIPanelCloseButton");
    draggerFrame.closeButton:SetWidth(20);
    draggerFrame.closeButton:SetHeight(20);
    draggerFrame.closeButton:SetPoint("RIGHT", -2, 0);
    
    -- Set the dragging behavior.
    draggerFrame:SetMovable(true);
    draggerFrame:EnableMouse(true);
    draggerFrame:SetToplevel(true);
    draggerFrame:SetClampedToScreen(true);
    draggerFrame:SetScript("OnMouseDown",
       function() 
           this:StartMoving();
           this.isBeingDragged = true;
       end);
    draggerFrame:SetScript("OnMouseUp",
        function()
            this.isBeingDragged = false;
            this:StopMovingOrSizing();
            
            -- Set the new dragger location in the config file.
            local anchorPoint, relativeTo, relativePoint, xOffset, yOffset = this:GetPoint();
            AggroNotifier_SetAggroTextLocationConfigProperty(this, xOffset, yOffset, anchorPoint, relativePoint);

            -- Update the onscreen widgets based on the new location.            
            AggroNotifier_SetAggroFrameDraggerToDesiredLocation(this);
            AggroNotifier_SetAggroTextFrameToDraggerLocation(this);
            AggroNotifier_RefreshAggroText(this.textFrame.textObject);
        end);
    draggerFrame:SetScript("OnUpdate",
        function()
            if (AggroNotifier_ForceBoolean(this.isBeingDragged)) then
                AggroNotifier_SetAggroTextFrameToDraggerLocation(this);
                AggroNotifier_RefreshAggroText(this.textFrame.textObject);
            end
        end);
    
    -- Hide the frame dragger.
    draggerFrame:Hide();
    
    -- Initialize the aggro text frame and dragger location.
    AggroNotifier_SetAggroFrameDraggerToDesiredLocation(draggerFrame);
    AggroNotifier_SetAggroTextFrameToDraggerLocation(draggerFrame);
end

-- This creates and sets up the object widgets that go in the various options panes.
function AggroNotifier_GenerateOptionsFrame()
    -- Create the options container frame.
    AggroNotifier_OptionsFrameContainer = CreateFrame("Frame", "AggroNotifier_OptionsFrameContainer", UIParent);
    AggroNotifier_OptionsFrameContainer:SetWidth(400);
    AggroNotifier_OptionsFrameContainer:SetHeight(410);
    AggroNotifier_OptionsFrameContainer:SetFrameStrata("DIALOG");
    AggroNotifier_OptionsFrameContainer:SetScript("OnShow", AggroNotifier_PopulateOptionsFrame);
    
    -- Add title and help text to the container frame.
    local optionsContainerFrameTitle = AggroNotifier_OptionsFrameContainer:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
    optionsContainerFrameTitle:SetPoint("TOPLEFT", 16, -16);
    optionsContainerFrameTitle:SetText(AGGRO_NOTIFIER_OPTIONS_TITLE);
    
    local optionsContainerFrameHelp = AggroNotifier_OptionsFrameContainer:CreateFontString(nil, "ARTWORK", "GameFontNormal");
    optionsContainerFrameHelp:SetPoint("TOPLEFT", optionsContainerFrameTitle, "BOTTOMLEFT", 0, -20);
    optionsContainerFrameHelp:SetWidth(360);
    optionsContainerFrameHelp:SetJustifyH("LEFT");
    optionsContainerFrameHelp:SetText(AGGRO_NOTIFIER_OPTIONS_CONTAINER_FRAME_HELP);
    
    -- Call some helper functions to generate the options subframes.
    AggroNotifier_GenerateOptionsSubframeAppearancePlayer();
    AggroNotifier_GenerateOptionsSubframeBehaviorPlayer();
    AggroNotifier_GenerateOptionsSubframeAppearancePet();
    AggroNotifier_GenerateOptionsSubframeBehaviorPet();
end

-- Helper function for AggroNotifier_GenerateOptionsFrame() that generates the appearance (player) options subframe
function AggroNotifier_GenerateOptionsSubframeAppearancePlayer()
    -- Create the player appearance options subframe.
    AggroNotifier_OptionsSubFrameAppearance = CreateFrame("Frame", "AggroNotifier_OptionsSubFrameAppearance");
    AggroNotifier_OptionsSubFrameAppearance:SetScript("OnShow", 
        function()
            AggroNotifier_PopulateOptionsFrame();
            -- Due to some weird bug with the edit box, we need to force-set and force-insert the edit box text the first time this pane is explicitly loaded, otherwise the edit box will appear empty.
            if (not appearanceOptionsSubFrameLoaded) then
                appearanceOptionsSubFrameLoaded = true;
                AggroNotifier_OptionsAggroTextEditBox:SetText("");
                AggroNotifier_OptionsAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredAggroText));
                AggroNotifier_OptionsGenericAggroTextEditBox:SetText("");
                AggroNotifier_OptionsGenericAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredGenericAggroText));
            end
        end);
        
    -- Add the player appearance option subframe widgets.
    -- Appearance frame title
    local optionsSubFrameAppearanceTitle = AggroNotifier_OptionsSubFrameAppearance:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
    optionsSubFrameAppearanceTitle:SetPoint("TOPLEFT", 16, -16);
    optionsSubFrameAppearanceTitle:SetText(AGGRO_NOTIFIER_OPTIONS_TITLE_APPEARANCE);
    
    -- Desired aggro text box
    AggroNotifier_OptionsAggroTextEditBox = AggroNotifier_CreateTextEditBox(AggroNotifier_OptionsSubFrameAppearance, optionsSubFrameAppearanceTitle, 0, -10,
            AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_OPTION_TITLE, AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_OPTION_DESCRIPTION, "AggroNotifier_OptionsAggroTextEditBox", nil);
    
    -- Include PvP in enemy name checkbox
    AggroNotifier_OptionsIncludePvpInEnemyNameCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsAggroTextEditBox, 0, -3, 
            AGGRO_NOTIFIER_INCLUDE_PVP_TAG_OPTION_TEXT, "AggroNotifier_OptionsIncludePvpInEnemyNameCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_INCLUDE_PVP_IN_ENEMY_NAME);
    
    -- Generic aggro text box
    AggroNotifier_OptionsGenericAggroTextEditBox = AggroNotifier_CreateTextEditBox(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsIncludePvpInEnemyNameCheckbox, -5, -7,
            AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT_OPTION_TITLE, AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT_OPTION_DESCRIPTION, "AggroNotifier_OptionsGenericAggroTextEditBox", nil);
    
    -- Show Anchor button
    local showAnchorOnClickFunction = function()
               AggroNotifier_SetAggroFrameDraggerToDesiredLocation(AggroNotifier_AggroFrameDragger);
               AggroNotifier_SetAggroTextFrameToDraggerLocation(AggroNotifier_AggroFrameDragger);
               AggroNotifier_AggroFrameDragger:Show();
               AggroNotifier_RefreshAggroText(AggroNotifier_AggroText);
            end;
    AggroNotifier_OptionsShowAggroTextAnchorButton = AggroNotifier_CreateButton(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsGenericAggroTextEditBox, 0, -10, 
            AGGRO_NOTIFIER_SHOW_ANCHOR_BUTTON_OPTION_TEXT, showAnchorOnClickFunction, "AggroNotifier_OptionsShowAggroTextAnchorButton", nil);
    
    -- Reset Anchor button
    local resetAnchorOnClickFunction = function()
               AggroNotifier_SetAggroTextLocationConfigProperty(AggroNotifier_AggroFrameDragger, configDefaultAggroTextLocationOffsets[1], configDefaultAggroTextLocationOffsets[2], 
                    configDefaultAggroTextLocationOffsets[3], configDefaultAggroTextLocationOffsets[4]);
               AggroNotifier_SetAggroFrameDraggerToDesiredLocation(AggroNotifier_AggroFrameDragger);
               AggroNotifier_SetAggroTextFrameToDraggerLocation(AggroNotifier_AggroFrameDragger);
               AggroNotifier_RefreshAggroText(AggroNotifier_AggroText);
            end;
    AggroNotifier_OptionsResetAggroTextAnchorButton = AggroNotifier_CreateButton(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsShowAggroTextAnchorButton, 10, 0, 
            AGGRO_NOTIFIER_RESET_ANCHOR_BUTTON_OPTION_TEXT, resetAnchorOnClickFunction, "AggroNotifier_OptionsResetAggroTextAnchorButton", nil);
    AggroNotifier_OptionsResetAggroTextAnchorButton:SetPoint("TOPLEFT", AggroNotifier_OptionsShowAggroTextAnchorButton, "TOPRIGHT", 10, 0);                
    
    -- Fade time slider
    local fadeTimeSliderOnValueChangedFunction = function(self, value)
                local valueInSeconds = value / 1000.0;
                AggroNotifier_OptionsFadeTimeSliderText:SetText(AGGRO_NOTIFIER_FADE_TIME_OPTION_TEXT.." "..valueInSeconds);
            end;
    AggroNotifier_OptionsFadeTimeSlider = AggroNotifier_CreateSlider(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsShowAggroTextAnchorButton, 0, -20, 
            AGGRO_NOTIFIER_FADE_TIME_OPTION_TEXT, "0.0", "10.0", 0, maxAllowedFadeTimeMilliseconds, 100, fadeTimeSliderOnValueChangedFunction, "AggroNotifier_OptionsFadeTimeSlider", 
            AGGRO_NOTIFIER_PLAYER_TOOLTIP_AGGRO_TEXT_FADE_TIME);
        
    -- Gain Aggro color picker button
    AggroNotifier_OptionsGainAggroColorButton = AggroNotifier_CreateColorPickerButton(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsFadeTimeSlider, 
            0, -15, AGGRO_NOTIFIER_GAIN_AGGRO_COLOR_OPTION_TEXT, "AggroNotifier_OptionsGainAggroColorButton", AGGRO_NOTIFIER_PLAYER_TOOLTIP_GAIN_AGGRO_COLOR, AggroNotifier_AggroText);
    
    -- Lose Aggro color picker button
    AggroNotifier_OptionsLoseAggroColorButton = AggroNotifier_CreateColorPickerButton(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsGainAggroColorButton, 
            0, -10, AGGRO_NOTIFIER_LOSE_AGGRO_COLOR_OPTION_TEXT, "AggroNotifier_OptionsLoseAggroColorButton", AGGRO_NOTIFIER_PLAYER_TOOLTIP_LOSE_AGGRO_COLOR, AggroNotifier_AggroText);
    
    -- Desired font size
    local fontSizeSliderOnValueChangedFunction = function(self, value)
                AggroNotifier_OptionsFontSizeSliderText:SetText(AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_FONT_SIZE_OPTION_TITLE.." "..value);
                if (allowAggroTextRefreshForFontSizeSlider) then
                    AggroNotifier_SetAggroFontHeight(AggroNotifier_AggroText, value);
                    AggroNotifier_RefreshAggroText(AggroNotifier_AggroText);
                end
            end;
    AggroNotifier_OptionsFontSizeSlider = AggroNotifier_CreateSlider(AggroNotifier_OptionsSubFrameAppearance, AggroNotifier_OptionsLoseAggroColorButton, 0, -20, 
            AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_FONT_SIZE_OPTION_TITLE, "4", "60", 4, 60, 1, fontSizeSliderOnValueChangedFunction, "AggroNotifier_OptionsFontSizeSlider", 
            AGGRO_NOTIFIER_PLAYER_TOOLTIP_AGGRO_TEXT_FONT_SIZE);
end

-- Helper function for AggroNotifier_GenerateOptionsFrame() that generates the behavior (player) options subframe
function AggroNotifier_GenerateOptionsSubframeBehaviorPlayer()
    -- Create the player behavior options subframe.
    AggroNotifier_OptionsSubFrameBehavior = CreateFrame("Frame", "AggroNotifier_OptionsSubFrameBehavior");
    AggroNotifier_OptionsSubFrameBehavior:SetScript("OnShow", AggroNotifier_PopulateOptionsFrame);
    
    -- Add the player behavior option subframe widgets.
    -- Behavior frame title
    local optionsSubFrameBehaviorTitle = AggroNotifier_OptionsSubFrameBehavior:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
    optionsSubFrameBehaviorTitle:SetPoint("TOPLEFT", 16, -16);
    optionsSubFrameBehaviorTitle:SetText(AGGRO_NOTIFIER_OPTIONS_TITLE_BEHAVIOR);
    
    -- Enabled checkbox
    AggroNotifier_OptionsAddonEnabledCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, optionsSubFrameBehaviorTitle, 0, -10, 
            AGGRO_NOTIFIER_ADDON_ENABLED_OPTION_TEXT, "AggroNotifier_OptionsAddonEnabledCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_ENABLE_ADDON);
    AggroNotifier_OptionsAddonEnabledCheckbox:SetScript("OnClick", 
        function(self)
            local isChecked = AggroNotifier_ForceBoolean(AggroNotifier_OptionsAddonEnabledCheckbox:GetChecked());
            if (isChecked) then
                AggroNotifier_OptionsSoloEnabledForMobsCheckbox:Enable();
                AggroNotifier_OptionsSoloEnabledForPvpCheckbox:Enable();
            else
                AggroNotifier_OptionsSoloEnabledForMobsCheckbox:Disable();
                AggroNotifier_OptionsSoloEnabledForPvpCheckbox:Disable();
            end
        end);
    
    -- Enabled while soloing (mobs) checkbox
    AggroNotifier_OptionsSoloEnabledForMobsCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsAddonEnabledCheckbox, 20, 5, 
            AGGRO_NOTIFIER_ENABLED_SOLO_MOB_OPTION_TEXT, "AggroNotifier_OptionsSoloEnabledForMobsCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_ENABLE_PVE_WHILE_SOLO);
    
    -- Enabled while soloing (pvp) checkbox
    AggroNotifier_OptionsSoloEnabledForPvpCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsSoloEnabledForMobsCheckbox, 0, 5, 
            AGGRO_NOTIFIER_ENABLED_SOLO_PVP_OPTION_TEXT, "AggroNotifier_OptionsSoloEnabledForPvpCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_ENABLE_PVP_WHILE_SOLO);
    
    -- Reload aggro text on each new aggro checkbox
    AggroNotifier_OptionsRefreshAggroTextCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsSoloEnabledForPvpCheckbox, -20, 5, 
            AGGRO_NOTIFIER_REFRESH_AGGRO_TEXT_ON_EVERY_NEW_AGGRO_OPTION_TEXT, "AggroNotifier_OptionsRefreshAggroTextCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_REFRESH_AGGRO_TEXT_EVERY_NEW_AGGRO);
    
    -- Always search for aggro checkbox
    AggroNotifier_OptionsAlwaysSearchForAggroCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsRefreshAggroTextCheckbox, 0, 5, 
            AGGRO_NOTIFIER_ALWAYS_SEARCH_FOR_AGGRO_OPTION_TEXT, "AggroNotifier_OptionsAlwaysSearchForAggroCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_SEARCH_FOR_AGGRO_OUT_OF_COMBAT);
    
    -- Play sound on aggro gain checkbox
    AggroNotifier_OptionsPlaySoundCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsAlwaysSearchForAggroCheckbox, 0, 5, 
            AGGRO_NOTIFIER_PLAY_SOUND_ON_AGGRO_GAIN_OPTION_TEXT, "AggroNotifier_OptionsPlaySoundCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_PLAY_SOUND);
            
    -- Prevent notification fadeout on aggro gain checkbox
    AggroNotifier_OptionsPreventFadeoutCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsPlaySoundCheckbox, 0, 5, 
            AGGRO_NOTIFIER_PREVENT_FADEOUT_ON_AGGRO_GAIN_OPTION_TEXT, "AggroNotifier_OptionsPreventFadeoutCheckbox", AGGRO_NOTIFIER_PLAYER_TOOLTIP_PREVENT_FADEOUT);
            
    -- Extra target search depth slider
    local searchDepthSliderOnValueChangedFunction = function(self, value)
                AggroNotifier_OptionsExtraTargetSearchDepthSliderText:SetText(AGGRO_NOTIFIER_EXTRA_TARGET_SEARCH_DEPTH_OPTION_TEXT.." "..value);
            end;
    AggroNotifier_OptionsExtraTargetSearchDepthSlider = AggroNotifier_CreateSlider(AggroNotifier_OptionsSubFrameBehavior, AggroNotifier_OptionsPreventFadeoutCheckbox, 0, -25, 
            AGGRO_NOTIFIER_EXTRA_TARGET_SEARCH_DEPTH_OPTION_TEXT, "0", "2", 0, maxAllowedExtraTargetSearchDepth, 1, searchDepthSliderOnValueChangedFunction, 
            "AggroNotifier_OptionsExtraTargetSearchDepthSlider", AGGRO_NOTIFIER_PLAYER_TOOLTIP_TARGET_OF_TARGET_SEARCH_DEPTH);
    
end

-- Helper function for AggroNotifier_GenerateOptionsFrame() that generates the appearance (pet) options subframe
function AggroNotifier_GenerateOptionsSubframeAppearancePet()
    -- Create the pet appearance options subframe.
    AggroNotifier_PetOptionsSubFrameAppearance = CreateFrame("Frame", "AggroNotifier_PetOptionsSubFrameAppearance");
    AggroNotifier_PetOptionsSubFrameAppearance:SetScript("OnShow", 
        function()
            AggroNotifier_PopulateOptionsFrame();
            -- Due to some weird bug with the edit box, we need to force-set and force-insert the edit box text the first time this pane is explicitly loaded, otherwise the edit box will appear empty.
            if (not petAppearanceOptionsSubFrameLoaded) then
                petAppearanceOptionsSubFrameLoaded = true;
                AggroNotifier_PetOptionsAggroTextEditBox:SetText("");
                AggroNotifier_PetOptionsAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredAggroTextPet));
                AggroNotifier_PetOptionsGenericAggroTextEditBox:SetText("");
                AggroNotifier_PetOptionsGenericAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredGenericAggroTextPet));
            end
        end);
        
    -- Add the pet appearance option subframe widgets.
    -- Appearance frame title
    local optionsSubFrameAppearanceTitle = AggroNotifier_PetOptionsSubFrameAppearance:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
    optionsSubFrameAppearanceTitle:SetPoint("TOPLEFT", 16, -16);
    optionsSubFrameAppearanceTitle:SetText(AGGRO_NOTIFIER_OPTIONS_TITLE_APPEARANCE_PET);
    
    -- Desired aggro text box
    AggroNotifier_PetOptionsAggroTextEditBox = AggroNotifier_CreateTextEditBox(AggroNotifier_PetOptionsSubFrameAppearance, optionsSubFrameAppearanceTitle, 0, -10,
            AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_OPTION_TITLE_PET, AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_OPTION_DESCRIPTION_PET, "AggroNotifier_PetOptionsAggroTextEditBox", nil);
    
    -- Include PvP in enemy name checkbox
    AggroNotifier_PetOptionsIncludePvpInEnemyNameCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsAggroTextEditBox, 0, -3, 
            AGGRO_NOTIFIER_INCLUDE_PVP_TAG_OPTION_TEXT_PET, "AggroNotifier_PetOptionsIncludePvpInEnemyNameCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_INCLUDE_PVP_IN_ENEMY_NAME);
    
    -- Generic aggro text box
    AggroNotifier_PetOptionsGenericAggroTextEditBox = AggroNotifier_CreateTextEditBox(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsIncludePvpInEnemyNameCheckbox, -5, -7,
            AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT_OPTION_TITLE_PET, AGGRO_NOTIFIER_GENERIC_AGGRO_TEXT_OPTION_DESCRIPTION_PET, "AggroNotifier_PetOptionsGenericAggroTextEditBox", nil);
    
    -- Show Anchor button
    local showAnchorOnClickFunction = function()
               AggroNotifier_SetAggroFrameDraggerToDesiredLocation(AggroNotifier_AggroFrameDraggerPet);
               AggroNotifier_SetAggroTextFrameToDraggerLocation(AggroNotifier_AggroFrameDraggerPet);
               AggroNotifier_AggroFrameDraggerPet:Show();
               AggroNotifier_RefreshAggroText(AggroNotifier_AggroTextPet);
            end;
    AggroNotifier_PetOptionsShowAggroTextAnchorButton = AggroNotifier_CreateButton(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsGenericAggroTextEditBox, 0, -10, 
            AGGRO_NOTIFIER_SHOW_ANCHOR_BUTTON_OPTION_TEXT_PET, showAnchorOnClickFunction, "AggroNotifier_PetOptionsShowAggroTextAnchorButton", nil);
    
    -- Reset Anchor button
    local resetAnchorOnClickFunction = function()
               AggroNotifier_SetAggroTextLocationConfigProperty(AggroNotifier_AggroFrameDraggerPet, configDefaultAggroTextLocationOffsetsPet[1], configDefaultAggroTextLocationOffsetsPet[2], 
                    configDefaultAggroTextLocationOffsetsPet[3], configDefaultAggroTextLocationOffsetsPet[4]);
               AggroNotifier_SetAggroFrameDraggerToDesiredLocation(AggroNotifier_AggroFrameDraggerPet);
               AggroNotifier_SetAggroTextFrameToDraggerLocation(AggroNotifier_AggroFrameDraggerPet);
               AggroNotifier_RefreshAggroText(AggroNotifier_AggroTextPet);
            end;
    AggroNotifier_PetOptionsResetAggroTextAnchorButton = AggroNotifier_CreateButton(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsShowAggroTextAnchorButton, 10, 0, 
            AGGRO_NOTIFIER_RESET_ANCHOR_BUTTON_OPTION_TEXT_PET, resetAnchorOnClickFunction, "AggroNotifier_PetOptionsResetAggroTextAnchorButton", nil);
    AggroNotifier_PetOptionsResetAggroTextAnchorButton:SetPoint("TOPLEFT", AggroNotifier_PetOptionsShowAggroTextAnchorButton, "TOPRIGHT", 10, 0);                
    
    -- Fade time slider
    local fadeTimeSliderOnValueChangedFunction = function(self, value)
                local valueInSeconds = value / 1000.0;
                AggroNotifier_PetOptionsFadeTimeSliderText:SetText(AGGRO_NOTIFIER_FADE_TIME_OPTION_TEXT_PET.." "..valueInSeconds);
            end;
    AggroNotifier_PetOptionsFadeTimeSlider = AggroNotifier_CreateSlider(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsShowAggroTextAnchorButton, 0, -20, 
            AGGRO_NOTIFIER_FADE_TIME_OPTION_TEXT_PET, "0.0", "10.0", 0, maxAllowedFadeTimeMilliseconds, 100, fadeTimeSliderOnValueChangedFunction, "AggroNotifier_PetOptionsFadeTimeSlider", 
            AGGRO_NOTIFIER_PET_TOOLTIP_AGGRO_TEXT_FADE_TIME);
        
    -- Gain Aggro color picker button
    AggroNotifier_PetOptionsGainAggroColorButton = AggroNotifier_CreateColorPickerButton(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsFadeTimeSlider, 
            0, -15, AGGRO_NOTIFIER_GAIN_AGGRO_COLOR_OPTION_TEXT_PET, "AggroNotifier_PetOptionsGainAggroColorButton", AGGRO_NOTIFIER_PET_TOOLTIP_GAIN_AGGRO_COLOR, AggroNotifier_AggroTextPet);
    
    -- Lose Aggro color picker button
    AggroNotifier_PetOptionsLoseAggroColorButton = AggroNotifier_CreateColorPickerButton(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsGainAggroColorButton, 
            0, -10, AGGRO_NOTIFIER_LOSE_AGGRO_COLOR_OPTION_TEXT_PET, "AggroNotifier_PetOptionsLoseAggroColorButton", AGGRO_NOTIFIER_PET_TOOLTIP_LOSE_AGGRO_COLOR, AggroNotifier_AggroTextPet);
    
    -- Desired font size
    local fontSizeSliderOnValueChangedFunction = function(self, value)
                AggroNotifier_PetOptionsFontSizeSliderText:SetText(AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_FONT_SIZE_OPTION_TITLE_PET.." "..value);
                if (allowPetAggroTextRefreshForFontSizeSlider) then
                    AggroNotifier_SetAggroFontHeight(AggroNotifier_AggroTextPet, value);
                    AggroNotifier_RefreshAggroText(AggroNotifier_AggroTextPet);
                end
            end;
    AggroNotifier_PetOptionsFontSizeSlider = AggroNotifier_CreateSlider(AggroNotifier_PetOptionsSubFrameAppearance, AggroNotifier_PetOptionsLoseAggroColorButton, 0, -20, 
            AGGRO_NOTIFIER_DESIRED_AGGRO_TEXT_FONT_SIZE_OPTION_TITLE_PET, "4", "60", 4, 60, 1, fontSizeSliderOnValueChangedFunction, "AggroNotifier_PetOptionsFontSizeSlider", 
            AGGRO_NOTIFIER_PET_TOOLTIP_AGGRO_TEXT_FONT_SIZE);
end

-- Helper function for AggroNotifier_GenerateOptionsFrame() that generates the behavior (pet) options subframe
function AggroNotifier_GenerateOptionsSubframeBehaviorPet()
    -- Create the pet behavior options subframe.
    AggroNotifier_PetOptionsSubFrameBehavior = CreateFrame("Frame", "AggroNotifier_PetOptionsSubFrameBehavior");
    AggroNotifier_PetOptionsSubFrameBehavior:SetScript("OnShow", AggroNotifier_PopulateOptionsFrame);
    
    -- Add the pet behavior option subframe widgets.
    -- Behavior frame title
    local optionsSubFrameBehaviorTitle = AggroNotifier_PetOptionsSubFrameBehavior:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");
    optionsSubFrameBehaviorTitle:SetPoint("TOPLEFT", 16, -16);
    optionsSubFrameBehaviorTitle:SetText(AGGRO_NOTIFIER_OPTIONS_TITLE_BEHAVIOR_PET);
    
    -- Enabled checkbox
    AggroNotifier_PetOptionsAddonEnabledCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, optionsSubFrameBehaviorTitle, 0, -10, 
            AGGRO_NOTIFIER_ADDON_ENABLED_OPTION_TEXT_PET, "AggroNotifier_PetOptionsAddonEnabledCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_ENABLE_ADDON);
    AggroNotifier_PetOptionsAddonEnabledCheckbox:SetScript("OnClick", 
        function(self)
            local isChecked = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsAddonEnabledCheckbox:GetChecked());
            if (isChecked) then
                AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox:Enable();
                AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox:Enable();
            else
                AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox:Disable();
                AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox:Disable();
            end
        end);
    
    -- Enabled while soloing (mobs) checkbox
    AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsAddonEnabledCheckbox, 20, 5, 
            AGGRO_NOTIFIER_ENABLED_SOLO_MOB_OPTION_TEXT_PET, "AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_ENABLE_PVE_WHILE_SOLO);
    
    -- Enabled while soloing (pvp) checkbox
    AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox, 0, 5, 
            AGGRO_NOTIFIER_ENABLED_SOLO_PVP_OPTION_TEXT_PET, "AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_ENABLE_PVP_WHILE_SOLO);
    
    -- Reload aggro text on each new aggro checkbox
    AggroNotifier_PetOptionsRefreshAggroTextCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox, -20, 5, 
            AGGRO_NOTIFIER_REFRESH_AGGRO_TEXT_ON_EVERY_NEW_AGGRO_OPTION_TEXT_PET, "AggroNotifier_PetOptionsRefreshAggroTextCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_REFRESH_AGGRO_TEXT_EVERY_NEW_AGGRO);
    
    -- Always search for aggro checkbox
    AggroNotifier_PetOptionsAlwaysSearchForAggroCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsRefreshAggroTextCheckbox, 0, 5, 
            AGGRO_NOTIFIER_ALWAYS_SEARCH_FOR_AGGRO_OPTION_TEXT_PET, "AggroNotifier_PetOptionsAlwaysSearchForAggroCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_SEARCH_FOR_AGGRO_OUT_OF_COMBAT);
    
    -- Play sound on aggro gain checkbox
    AggroNotifier_PetOptionsPlaySoundCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsAlwaysSearchForAggroCheckbox, 0, 5, 
            AGGRO_NOTIFIER_PLAY_SOUND_ON_AGGRO_GAIN_OPTION_TEXT_PET, "AggroNotifier_PetOptionsPlaySoundCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_PLAY_SOUND);
            
    -- Prevent notification fadeout on aggro gain checkbox
    AggroNotifier_PetOptionsPreventFadeoutCheckbox = AggroNotifier_CreateCheckbox(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsPlaySoundCheckbox, 0, 5, 
            AGGRO_NOTIFIER_PREVENT_FADEOUT_ON_AGGRO_GAIN_OPTION_TEXT_PET, "AggroNotifier_PetOptionsPreventFadeoutCheckbox", AGGRO_NOTIFIER_PET_TOOLTIP_PREVENT_FADEOUT);
            
    -- Extra target search depth slider
    local searchDepthSliderOnValueChangedFunction = function(self, value)
                AggroNotifier_PetOptionsExtraTargetSearchDepthSliderText:SetText(AGGRO_NOTIFIER_EXTRA_TARGET_SEARCH_DEPTH_OPTION_TEXT_PET.." "..value);
            end;
    AggroNotifier_PetOptionsExtraTargetSearchDepthSlider = AggroNotifier_CreateSlider(AggroNotifier_PetOptionsSubFrameBehavior, AggroNotifier_PetOptionsPreventFadeoutCheckbox, 0, -25, 
            AGGRO_NOTIFIER_EXTRA_TARGET_SEARCH_DEPTH_OPTION_TEXT_PET, "0", "2", 0, maxAllowedExtraTargetSearchDepth, 1, searchDepthSliderOnValueChangedFunction, 
            "AggroNotifier_PetOptionsExtraTargetSearchDepthSlider", AGGRO_NOTIFIER_PET_TOOLTIP_TARGET_OF_TARGET_SEARCH_DEPTH);
end

-- Helper function that creates and returns a text edit box widget based on the given arguments.
function AggroNotifier_CreateTextEditBox(ownerFrame, relativeLocationObject, xOffset, yOffset, titleString, descriptionString, editBoxObjectName, tooltipTextString)
    local titleObject = ownerFrame:CreateFontString(nil, "ARTWORK", "GameFontNormal");
    titleObject:SetPoint("TOPLEFT", relativeLocationObject, "BOTTOMLEFT", xOffset, yOffset);
    titleObject:SetText(titleString);
    local descriptionObject = ownerFrame:CreateFontString(nil, "ARTWORK", "GameFontRedSmall");
    descriptionObject:SetTextColor(1.0, 1.0, 1.0);
    descriptionObject:SetPoint("TOPLEFT", titleObject, "BOTTOMLEFT", 0, -2);
    descriptionObject:SetWidth(360);
    descriptionObject:SetJustifyH("LEFT");
    descriptionObject:SetText(descriptionString);
    
    local editBoxObject = CreateFrame("EditBox", editBoxObjectName, ownerFrame, "InputBoxTemplate");
    editBoxObject:SetWidth(250);
    editBoxObject:SetHeight(16);
    editBoxObject:SetPoint("TOPLEFT", descriptionObject, "BOTTOMLEFT", 5, -7);
    editBoxObject:SetFontObject("GameFontWhite");
    editBoxObject:SetAutoFocus(false);
    
    if (tooltipTextString ~= nil) then
        AggroNotifier_AttachTooltip(editBoxObject, tooltipTextString);
    end
    
    return editBoxObject;
end

-- Helper function that creates and returns a checkbox widget based on the given arguments.
function AggroNotifier_CreateCheckbox(ownerFrame, relativeLocationObject, xOffset, yOffset, titleString, checkboxObjectName, tooltipTextString)
    local checkboxObject = CreateFrame("CheckButton", checkboxObjectName, ownerFrame, "OptionsCheckButtonTemplate");
    checkboxObject:SetPoint("TOPLEFT", relativeLocationObject, "BOTTOMLEFT", xOffset, yOffset);
    local checkboxTextObject = getglobal(checkboxObject:GetName().."Text");
    checkboxTextObject:SetFontObject("GameFontNormal");
    checkboxTextObject:SetText(titleString);
    if (tooltipTextString ~= nil) then
        AggroNotifier_AttachTooltip(checkboxObject, tooltipTextString);
    end
    return checkboxObject;
end

-- Helper function that creates and returns a button widget based on the given arguments.
function AggroNotifier_CreateButton(ownerFrame, relativeLocationObject, xOffset, yOffset, buttonTextString, onClickFunction, buttonObjectName, tooltipTextString)
    local buttonObject = CreateFrame("Button", buttonObjectName, ownerFrame, "UIPanelButtonTemplate");
    buttonObject:SetHeight(22);
    buttonObject:SetPoint("TOPLEFT", relativeLocationObject, "BOTTOMLEFT", xOffset, yOffset);
    buttonObject:SetText(buttonTextString);
    buttonObject:SetWidth(buttonObject:GetTextWidth() + 30);
    buttonObject:SetScript("OnClick", onClickFunction);
    
    if (tooltipTextString ~= nil) then
        AggroNotifier_AttachTooltip(buttonObject, tooltipTextString);
    end
    
    return buttonObject;
end

-- Helper function that creates and returns a slider widget based on the given arguments.
function AggroNotifier_CreateSlider(ownerFrame, relativeLocationObject, xOffset, yOffset, sliderTextString, minValueText, maxValueText, minValue, maxValue, stepValue, 
            onValueChangedFunction, sliderObjectName, tooltipTextString)
    local sliderObject = CreateFrame("Slider", sliderObjectName, ownerFrame, "InterfaceOptionsSliderTemplate");
    sliderObject:SetWidth(335);
    sliderObject:SetHeight(16);
    sliderObject:SetPoint("TOPLEFT", relativeLocationObject, "BOTTOMLEFT", xOffset, yOffset);
    local sliderTextObject = getglobal(sliderObject:GetName().."Text");
    sliderTextObject:SetFontObject("GameFontNormal");
    sliderTextObject:SetText(sliderTextString);
    local sliderLowObject = getglobal(sliderObject:GetName().."Low");
    sliderLowObject:SetText(minValueText);
    local sliderHighObject = getglobal(sliderObject:GetName().."High");
    sliderHighObject:SetText(maxValueText);
    sliderObject:SetMinMaxValues(minValue, maxValue);
    sliderObject:SetValueStep(stepValue);
    sliderObject:SetScript("OnValueChanged", onValueChangedFunction);
        
    if (tooltipTextString ~= nil) then
        AggroNotifier_AttachTooltip(sliderObject, tooltipTextString);
    end
        
    return sliderObject;
end

-- Helper function that creates and returns a color picker widget based on the given arguments.
function AggroNotifier_CreateColorPickerButton(ownerFrame, relativeLocationObject, xOffset, yOffset, colorPickerTitleString, colorPickerObjectName, tooltipTextString, refreshAggroTextObject)
    local colorPickerObject = CreateFrame("Button", colorPickerObjectName, ownerFrame);
    colorPickerObject:SetPoint("TOPLEFT", relativeLocationObject, "BOTTOMLEFT", xOffset, yOffset);
    
    colorPickerObject:SetWidth(20);
    colorPickerObject:SetHeight(20);

    colorPickerObject.texture = colorPickerObject:CreateTexture();
    colorPickerObject.texture:SetPoint("TOPLEFT", 0, 0);
    colorPickerObject.texture:SetPoint("BOTTOMRIGHT", 0, 0);
    colorPickerObject.texture:SetTexture("Interface\\ChatFrame\\ChatFrameColorSwatch");
    colorPickerObject:SetNormalTexture(colorPickerObject.texture);

    colorPickerObject.borderTop = colorPickerObject:CreateTexture(nil,"BACKGROUND");
    colorPickerObject.borderTop:SetPoint("TOPLEFT", 1, -1);
    colorPickerObject.borderTop:SetPoint("TOPRIGHT", -1, -1);
    colorPickerObject.borderTop:SetHeight(2);
    colorPickerObject.borderTop:SetTexture(1.00, 1.00, 1.00, 1.00);
    colorPickerObject.borderRight = colorPickerObject:CreateTexture(nil,"BACKGROUND");
    colorPickerObject.borderRight:SetPoint("TOPRIGHT", -1, -1);
    colorPickerObject.borderRight:SetPoint("BOTTOMRIGHT", -1, 1);
    colorPickerObject.borderRight:SetWidth(2);
    colorPickerObject.borderRight:SetTexture(1.00, 1.00, 1.00, 1.00);
    colorPickerObject.borderBottom = colorPickerObject:CreateTexture(nil,"BACKGROUND");
    colorPickerObject.borderBottom:SetPoint("BOTTOMLEFT", 1, 1);
    colorPickerObject.borderBottom:SetPoint("BOTTOMRIGHT", -1, 1);
    colorPickerObject.borderBottom:SetHeight(2);
    colorPickerObject.borderBottom:SetTexture(1.00, 1.00, 1.00, 1.00);
    colorPickerObject.borderLeft = colorPickerObject:CreateTexture(nil,"BACKGROUND");
    colorPickerObject.borderLeft:SetPoint("TOPLEFT", 1, -1);
    colorPickerObject.borderLeft:SetPoint("BOTTOMLEFT", 1, 1);
    colorPickerObject.borderLeft:SetWidth(2);
    colorPickerObject.borderLeft:SetTexture(1.00, 1.00, 1.00, 1.00);

    colorPickerObject.text = colorPickerObject:CreateFontString(nil,"ARTWORK","GameFontNormal");
    colorPickerObject.text:SetPoint("LEFT", colorPickerObject, "RIGHT", 5, 0);
    colorPickerObject.text:SetText(colorPickerTitleString);

    colorPickerObject.refreshAggroTextObject = refreshAggroTextObject;
    
    local colorPickerOnClickFunction = function(previousValue,...)
                local r, g, b, a;
                if (previousValue) then
                    -- The player hit cancel. Reset the button's color to its previous values.
                    r, g, b, a  = unpack(previousValue);
                else
                    -- The player hit ok. We want to update the button to the new color values from the color picker.
                    r, g, b = ColorPickerFrame:GetColorRGB();
                    a = (1 - OpacitySliderFrame:GetValue());
                end
            
                ColorPickerFrame.frame.texture:SetVertexColor(r, g, b, a);
                
                -- Refresh the aggro text object this color picker is associated with if applicable.
                if (ColorPickerFrame.frame.refreshAggroTextObject ~= nil) then
                     ColorPickerFrame.frame.refreshAggroTextObject.runtimeInfo.temporaryColorOverride = {r, g, b, a};
                     AggroNotifier_RefreshAggroText(ColorPickerFrame.frame.refreshAggroTextObject);
                end
            end
    
    colorPickerObject:SetScript("OnClick",
        function(self, button)
            local r, g, b, a = self.texture:GetVertexColor();
            
            ColorPickerFrame.frame = self;
            ColorPickerFrame.func = colorPickerOnClickFunction;
            ColorPickerFrame.cancelFunc = colorPickerOnClickFunction;
            ColorPickerFrame.opacityFunc = colorPickerOnClickFunction;
            ColorPickerFrame.hasOpacity = true;
            ColorPickerFrame.opacity = (1 - a);
            ColorPickerFrame.previousValues = { r, g, b, a };
        
            OpacitySliderFrame:SetValue(1 - a);
            ColorPickerFrame:SetColorRGB(r, g, b);
            ColorPickerFrame:Show();
        end);
    colorPickerObject:SetScript("OnEnter",
        function(self)
            self.borderTop:SetTexture(1.00, 0.82, 0.00, 1.00);
            self.borderRight:SetTexture(1.00, 0.82, 0.00, 1.00);
            self.borderBottom:SetTexture(1.00, 0.82, 0.00, 1.00);
            self.borderLeft:SetTexture(1.00, 0.82, 0.00, 1.00);
        end);
    colorPickerObject:SetScript("OnLeave",
        function(self)
            self.borderTop:SetTexture(1.00, 1.00, 1.00, 1.00);
            self.borderRight:SetTexture(1.00, 1.00, 1.00, 1.00);
            self.borderBottom:SetTexture(1.00, 1.00, 1.00, 1.00);
            self.borderLeft:SetTexture(1.00, 1.00, 1.00, 1.00);
        end);
    
    if (tooltipTextString ~= nil) then
        AggroNotifier_AttachTooltip(colorPickerObject, tooltipTextString);
    end
    
    return colorPickerObject;
end

-- Helper function that attaches the given tooltip text to the given owning widget object. The tooltip will be shown when the widget is moused over.
function AggroNotifier_AttachTooltip(owningObject, tooltipTextString)
    -- Set the tooltip text on the owning object so it can be accessed by the scripts.
    owningObject.tooltipText = tooltipTextString;
    -- Set scripts on the owning object to show/hide the tooltip as necessary.
    owningObject:SetScript("OnEnter",
        function()
            GameTooltip:SetOwner(owningObject, "ANCHOR_TOPLEFT");
            GameTooltip:SetText(this.tooltipText, 1, .82, 0, 1, true);
            GameTooltip:Show();
        end);
    owningObject:SetScript("OnLeave",
        function()
            GameTooltip:Hide();
        end);
end

-- This function is called when the options frame is shown. It loads all the options widgets with the current config property values.
function AggroNotifier_PopulateOptionsFrame()
    -- We don't want to reset the option values when we switch between option subpanes, so only set the values if we're just coming in for the first time.
    if (not optionsFrameActive) then
        optionsFrameActive = true;
        
        -- Set the options frames' widgets to have the current values stored in the config file.
        
        -- PLAYER OPTIONS
        -- Edit boxes are funky and sometimes need a little extra prodding to get populated correctly. We'll set it to blank and then insert the text we want.
        AggroNotifier_OptionsAggroTextEditBox:SetText("");
        AggroNotifier_OptionsAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredAggroText));
        AggroNotifier_OptionsGenericAggroTextEditBox:SetText("");
        AggroNotifier_OptionsGenericAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredGenericAggroText));
        AggroNotifier_OptionsIncludePvpInEnemyNameCheckbox:SetChecked(AggroNotifier_Config.desiredIncludePvpTagInEnemyName);
        AggroNotifier_OptionsFadeTimeSlider:SetValue(AggroNotifier_Config.desiredFadeTimeMilliseconds);
        local r, g, b, a = unpack(AggroNotifier_Config.gainAggroColor);
        AggroNotifier_OptionsGainAggroColorButton.texture:SetVertexColor(r, g, b, a);
        r, g, b, a = unpack(AggroNotifier_Config.loseAggroColor);
        AggroNotifier_OptionsLoseAggroColorButton.texture:SetVertexColor(r, g, b, a);
        -- Normally when the font size slider has its value set it is supposed to refresh the aggro text, but we don't want it to do that when we're initially 
        -- populating the value (only when a user is fiddling with it), hence the use of the allowAggroTextRefreshForFontSizeSlider variable.
        allowAggroTextRefreshForFontSizeSlider = false;
        AggroNotifier_OptionsFontSizeSlider:SetValue(AggroNotifier_Config.desiredAggroTextFontSize);
        allowAggroTextRefreshForFontSizeSlider = true;
        
        AggroNotifier_OptionsRefreshAggroTextCheckbox:SetChecked(AggroNotifier_Config.desiredRefreshAggroTextOnEveryNewAggro);
        AggroNotifier_OptionsAlwaysSearchForAggroCheckbox:SetChecked(AggroNotifier_Config.desiredAlwaysSearchForAggro);
        AggroNotifier_OptionsExtraTargetSearchDepthSlider:SetValue(AggroNotifier_Config.desiredExtraTargetSearchDepth);
        AggroNotifier_OptionsAddonEnabledCheckbox:SetChecked(AggroNotifier_Config.addonEnabled);
        AggroNotifier_OptionsSoloEnabledForMobsCheckbox:SetChecked(AggroNotifier_Config.soloEnabledForMobs);
        AggroNotifier_OptionsSoloEnabledForPvpCheckbox:SetChecked(AggroNotifier_Config.soloEnabledForPvp);
        AggroNotifier_OptionsPlaySoundCheckbox:SetChecked(AggroNotifier_Config.playSoundOnAggroGain);
        AggroNotifier_OptionsPreventFadeoutCheckbox:SetChecked(AggroNotifier_Config.preventFadeoutOnAggroGain);
        
        -- Enable or disable the solo options depending on whether the addon as a whole is enabled.
        if (AggroNotifier_Config.addonEnabled) then
            AggroNotifier_OptionsSoloEnabledForMobsCheckbox:Enable();
            AggroNotifier_OptionsSoloEnabledForPvpCheckbox:Enable();
        else
            AggroNotifier_OptionsSoloEnabledForMobsCheckbox:Disable();
            AggroNotifier_OptionsSoloEnabledForPvpCheckbox:Disable();
        end
        
        -- PET OPTIONS
        -- Edit boxes are funky and sometimes need a little extra prodding to get populated correctly. We'll set it to blank and then insert the text we want.
        AggroNotifier_PetOptionsAggroTextEditBox:SetText("");
        AggroNotifier_PetOptionsAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredAggroTextPet));
        AggroNotifier_PetOptionsGenericAggroTextEditBox:SetText("");
        AggroNotifier_PetOptionsGenericAggroTextEditBox:Insert(tostring(AggroNotifier_Config.desiredGenericAggroTextPet));
        AggroNotifier_PetOptionsIncludePvpInEnemyNameCheckbox:SetChecked(AggroNotifier_Config.desiredIncludePvpTagInEnemyNamePet);
        AggroNotifier_PetOptionsFadeTimeSlider:SetValue(AggroNotifier_Config.desiredFadeTimeMillisecondsPet);
        local r, g, b, a = unpack(AggroNotifier_Config.gainAggroColorPet);
        AggroNotifier_PetOptionsGainAggroColorButton.texture:SetVertexColor(r, g, b, a);
        r, g, b, a = unpack(AggroNotifier_Config.loseAggroColorPet);
        AggroNotifier_PetOptionsLoseAggroColorButton.texture:SetVertexColor(r, g, b, a);
        -- Normally when the font size slider has its value set it is supposed to refresh the aggro text, but we don't want it to do that when we're initially 
        -- populating the value (only when a user is fiddling with it), hence the use of the allowPetAggroTextRefreshForFontSizeSlider variable.
        allowPetAggroTextRefreshForFontSizeSlider = false;
        AggroNotifier_PetOptionsFontSizeSlider:SetValue(AggroNotifier_Config.desiredAggroTextFontSizePet);
        allowPetAggroTextRefreshForFontSizeSlider = true;
        
        AggroNotifier_PetOptionsRefreshAggroTextCheckbox:SetChecked(AggroNotifier_Config.desiredRefreshAggroTextOnEveryNewAggroPet);
        AggroNotifier_PetOptionsAlwaysSearchForAggroCheckbox:SetChecked(AggroNotifier_Config.desiredAlwaysSearchForAggroPet);
        AggroNotifier_PetOptionsExtraTargetSearchDepthSlider:SetValue(AggroNotifier_Config.desiredExtraTargetSearchDepthPet);
        AggroNotifier_PetOptionsAddonEnabledCheckbox:SetChecked(AggroNotifier_Config.addonEnabledPet);
        AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox:SetChecked(AggroNotifier_Config.soloEnabledForMobsPet);
        AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox:SetChecked(AggroNotifier_Config.soloEnabledForPvpPet);
        AggroNotifier_PetOptionsPlaySoundCheckbox:SetChecked(AggroNotifier_Config.playSoundOnAggroGainPet);
        AggroNotifier_PetOptionsPreventFadeoutCheckbox:SetChecked(AggroNotifier_Config.preventFadeoutOnAggroGainPet);
        
        -- Enable or disable the solo options depending on whether the addon as a whole is enabled.
        if (AggroNotifier_Config.addonEnabledPet) then
            AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox:Enable();
            AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox:Enable();
        else
            AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox:Disable();
            AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox:Disable();
        end
    end
end

-- This is called when a user is done editing options and clicks ok. This takes the values from the options frames' widgets and writes them to the config file so they will be stored properly.
function AggroNotifier_UpdateOptionsFrame()
    -- Update our stored values with the current options frame values.
    
    -- PLAYER OPTIONS
    AggroNotifier_Config.desiredAggroText = AggroNotifier_OptionsAggroTextEditBox:GetText();
    AggroNotifier_Config.desiredGenericAggroText = AggroNotifier_OptionsGenericAggroTextEditBox:GetText();
    AggroNotifier_Config.desiredFadeTimeMilliseconds = AggroNotifier_OptionsFadeTimeSlider:GetValue();
    AggroNotifier_Config.desiredIncludePvpTagInEnemyName = AggroNotifier_ForceBoolean(AggroNotifier_OptionsIncludePvpInEnemyNameCheckbox:GetChecked());
    local r, g, b, a = AggroNotifier_OptionsGainAggroColorButton.texture:GetVertexColor();
    AggroNotifier_Config.gainAggroColor = {r, g, b, a};
    r, g, b, a = AggroNotifier_OptionsLoseAggroColorButton.texture:GetVertexColor();
    AggroNotifier_Config.loseAggroColor = {r, g, b, a};
    AggroNotifier_Config.desiredAggroTextFontSize = AggroNotifier_OptionsFontSizeSlider:GetValue();
    
    AggroNotifier_Config.addonEnabled = AggroNotifier_ForceBoolean(AggroNotifier_OptionsAddonEnabledCheckbox:GetChecked());
    AggroNotifier_Config.soloEnabledForMobs = AggroNotifier_ForceBoolean(AggroNotifier_OptionsSoloEnabledForMobsCheckbox:GetChecked());
    AggroNotifier_Config.soloEnabledForPvp = AggroNotifier_ForceBoolean(AggroNotifier_OptionsSoloEnabledForPvpCheckbox:GetChecked());
    AggroNotifier_Config.desiredRefreshAggroTextOnEveryNewAggro = AggroNotifier_ForceBoolean(AggroNotifier_OptionsRefreshAggroTextCheckbox:GetChecked());
    AggroNotifier_Config.desiredAlwaysSearchForAggro = AggroNotifier_ForceBoolean(AggroNotifier_OptionsAlwaysSearchForAggroCheckbox:GetChecked());
    AggroNotifier_Config.desiredExtraTargetSearchDepth = AggroNotifier_OptionsExtraTargetSearchDepthSlider:GetValue();
    AggroNotifier_Config.playSoundOnAggroGain = AggroNotifier_ForceBoolean(AggroNotifier_OptionsPlaySoundCheckbox:GetChecked());
    AggroNotifier_Config.preventFadeoutOnAggroGain = AggroNotifier_ForceBoolean(AggroNotifier_OptionsPreventFadeoutCheckbox:GetChecked());
    
    -- PET OPTIONS
    AggroNotifier_Config.desiredAggroTextPet = AggroNotifier_PetOptionsAggroTextEditBox:GetText();
    AggroNotifier_Config.desiredGenericAggroTextPet = AggroNotifier_PetOptionsGenericAggroTextEditBox:GetText();
    AggroNotifier_Config.desiredFadeTimeMillisecondsPet = AggroNotifier_PetOptionsFadeTimeSlider:GetValue();
    AggroNotifier_Config.desiredIncludePvpTagInEnemyNamePet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsIncludePvpInEnemyNameCheckbox:GetChecked());
    local r, g, b, a = AggroNotifier_PetOptionsGainAggroColorButton.texture:GetVertexColor();
    AggroNotifier_Config.gainAggroColorPet = {r, g, b, a};
    r, g, b, a = AggroNotifier_PetOptionsLoseAggroColorButton.texture:GetVertexColor();
    AggroNotifier_Config.loseAggroColorPet = {r, g, b, a};
    AggroNotifier_Config.desiredAggroTextFontSizePet = AggroNotifier_PetOptionsFontSizeSlider:GetValue();

    AggroNotifier_Config.addonEnabledPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsAddonEnabledCheckbox:GetChecked());
    AggroNotifier_Config.soloEnabledForMobsPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsSoloEnabledForMobsCheckbox:GetChecked());
    AggroNotifier_Config.soloEnabledForPvpPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsSoloEnabledForPvpCheckbox:GetChecked());
    AggroNotifier_Config.desiredRefreshAggroTextOnEveryNewAggroPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsRefreshAggroTextCheckbox:GetChecked());
    AggroNotifier_Config.desiredAlwaysSearchForAggroPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsAlwaysSearchForAggroCheckbox:GetChecked());
    AggroNotifier_Config.desiredExtraTargetSearchDepthPet = AggroNotifier_PetOptionsExtraTargetSearchDepthSlider:GetValue();
    AggroNotifier_Config.playSoundOnAggroGainPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsPlaySoundCheckbox:GetChecked());
    AggroNotifier_Config.preventFadeoutOnAggroGainPet = AggroNotifier_ForceBoolean(AggroNotifier_PetOptionsPreventFadeoutCheckbox:GetChecked());
    
    -- We need to reinitialize the aggro text since desired text and/or appearance may have changed.
    AggroNotifier_InitializeAllAggroText();
        
    -- Set the "options frame is active" value to false since we're done with the options frame.
    optionsFrameActive = false;
end

-- This is called when a user is done editing options and clicks cancel. This simply marks us as being done with the options frame. 
-- We don't update any config file stored values since the user cancelled. The next time the options frames are loaded the widgets will be reset to whatever is stored in the config file.
function AggroNotifier_CancelOptionsFrame()
    -- Set the "options frame is active" value to false since we're done with the options frame.
    optionsFrameActive = false;
end

-- Sets the given aggro frame dragger to the location specified in its draggerFrame.locationOffsetsConfigPropertyName config property.
-- This is used to initialize the frame dragger to the location specified for it in the config file.
function AggroNotifier_SetAggroFrameDraggerToDesiredLocation(draggerFrame)
    local locationOffsetData = AggroNotifier_Config[draggerFrame.locationOffsetsConfigPropertyName];
    
    local xOffset = locationOffsetData[1];
    local yOffset = locationOffsetData[2];
    local anchorPoint = locationOffsetData[3];
    local relativeTo = locationOffsetData[4];
    draggerFrame:ClearAllPoints();
    draggerFrame:SetPoint(anchorPoint, UIParent, relativeTo, xOffset, yOffset);
end

-- Sets the aggro text frame associated with the given dragger frame to be at the same location as the dragger frame. This is used to link the text frame to the dragger frame so it appears
-- like the text frame is "attached" to the dragger frame.
function AggroNotifier_SetAggroTextFrameToDraggerLocation(draggerFrame)
    draggerFrame.textFrame:ClearAllPoints();
    draggerFrame.textFrame:SetPoint("CENTER", draggerFrame, "CENTER", 0, -DRAGGER_FRAME_Y_OFFSET);
end

-- Sets the config file data for aggro text associated with the given dragger frame to the specified argument values.
function AggroNotifier_SetAggroTextLocationConfigProperty(draggerFrame, xOffset, yOffset, anchorPoint, relativePoint)
    local configKey = draggerFrame.locationOffsetsConfigPropertyName;
    
    AggroNotifier_Config[configKey][1] = xOffset;
    AggroNotifier_Config[configKey][2] = yOffset;
    AggroNotifier_Config[configKey][3] = anchorPoint;
    AggroNotifier_Config[configKey][4] = relativePoint;
end
