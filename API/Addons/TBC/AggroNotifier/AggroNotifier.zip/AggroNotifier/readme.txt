-- OVERVIEW --
AggroNotifier is a simple and flexible visual and audio aggro notification system. Whenever AggroNotifier detects that you have gained aggro it will display customizable text on the screen so that you instantly know when badness is heading your way, and it will optionally play a sound. When AggroNotifier detects that you have lost all known aggro it will display the aggro text on the screen in a customizable "all clear" color so you know you're safe. It covers both the player (you) and your pet with independent settings for each. This is similar to - and was inspired by - the aggro notification functions of XPerl_RaidHelper and TitanAggro, but it is standalone and provides some customization options they don't have, and leaves out some things I didn't want.


-- INSTALLATION --
To install AggroNotifier simply move or copy the AggroNotifier folder into your World of Warcraft/Interface/AddOns folder.


-- SETTINGS --
AggroNotifier uses the new standard location Blizzard provides for addons to put their configuration screens. To customize AggroNotifier settings go to the main menu (usually by hitting the escape key), click the Interface button, click the AddOns tab, and expand the AggroNotifier tree. You'll see four pages of settings.

-- Player Appearance Settings --
The "Appearance (Player)" settings pane allows you to customize the appearance of the aggro notification text for when the player gains and loses aggro. You can set the aggro text to be whatever you want, optionally including a @enemy@ tag which will be replaced with the enemy's name when you are notified of aggro. You can choose to have @enemy@ optionally include a "(PvP)" tag when you gain aggro from an enemy player. You can also set the amount of time the aggro text will take to fade out, the colors of the gain aggro text and lose aggro text, and the font size of the aggro text. To move the aggro text to a different location on the screen, click the "Show Anchor" button and move it to the desired location. To reset the aggro text to the center of the screen click "Reset Anchor to Default".

-- Player Behavior Settings --
The "Behavior (Player)" settings pane allows you to customize the behavior of AggroNotifier in relation to the player's aggro notification text and sound. You can choose to disable aggro detection on the player in all situations, or you can fine tune it and disable aggro detection when soloing for PvE or PvP (or both). You can set how thorough AggroNotifier is when detecting aggro, and you can set it to try to detect aggro even when you're out of combat (which is useful for getting a visual notification when a PvP enemy is targeting you even when you're not in combat). You can force the aggro gain text to stay on the screen until you lose aggro rather than fading out immediately, and you can allow or prevent the aggro gain sound from playing.

-- Pet Appearance Settings --
The "Appearance (Pet)" settings pane is the same as the "Appearance (Player)" settings pane, except here you can set things up for pet aggro notification text appearance independently from the player aggro notification text appearance.

-- Pet Behavior Settings --
The "Behavior (Pet)" settings pane is the same as the "Behavior (Player)" settings pane, except here you can set things up for pet aggro notification behavior independently from the player aggro notification behavior.


-- FAQ --
Q1. How does the aggro detection work?
A1. Blizzard heavily restricts what addons are allowed to know. An addon can't just ask "what is targeting me right now", and you can't get targeting info on any arbitrary unit. Blizzard only gives you programming access to a few units: the player (you), the player's pet, the unit you're currently mousing over, your focus target, your party members, your party members' pets, your raid members, and your raid members' pets. For any of those units you have programmatic access to, you can look at their targets, and their target's target, etc, as many target-of-target levels you want. So to detect aggro we look at all the units you have programmatic access to, and look at those units' targets. If any of those units' targets are non-friendly and targeting you (the player), then you have aggro from those units. A similar process is used to detect pet aggro. AggroNotifier lets you specify how many target-of-target levels you want to search, however you'll only get aggro hits off deep searching when shallow searching wouldn't find the aggro in very rare circumstances.

Q2. So does that mean I might have aggro and AggroNotifier won't tell me?!?
A2. Yes. It's possible that there will be an enemy trying to beat you to a pulp that AggroNotifier does not have access to because none of the units AggroNotifier *does* have access to can reach the enemy via the target-of-target chain.

Q3. Well that sucks.
A3. Yep, but it's the best that can be done with the restrictions Blizzard places on addons. So you still have to keep your eyes peeled, but in a party or raid situation where there are only a few enemies and they are all being targeted by at least one party/raid member or pet, you will never have to worry about AggroNotifier missing that enemy coming for your head. Remember that AggroNotifier also has access to your focus target, so if you're worried about a particular enemy or boss, just make sure it is your focus target and AggroNotifier will always be able to reach it and look to see if it is aggro'd on you.

Q4. AggroNotifer told me about an aggro of a particular enemy, and then I switched targets to something else. The original enemy that AggroNotifier told me about died/switched aggro but I didn't get an "all clear" notification. What gives?
A4. The same restrictions Blizzard puts on addons explained in A1 come into play here. If the enemy that was aggro'd on you dies (or switches aggro) but it is not reachable by any of the units AggroNotifier knows about, then there's no way for AggroNotifier to know that you're no longer in danger. So it bets on the safe side and assumes that you still have aggro.

Q5. Well that sucks.
A5. Yep. Again, it's the best that can be done with the restrictions Blizzard places on addons. You'll get the "all clear" notification when you leave combat entirely, or if you mouseover the original enemy, or if you or a party/raid member selects the original enemy again and AggroNotifier sees that the original aggro enemy is no longer aggro'd on you. If you have the "Refresh Aggro Text Every New Aggro" option enabled in the behavior settings, AggroNotifier will tell you when it detects a *different* aggro coming your way if the original aggro enemy is no longer detectable, but that's the best that can be done.

Q6. Does AggroNotifier tell me of *every* enemy aggro'd on me?
A6. No. AggroNotifier is not meant to be a running tally of all enemies aggro'd on you, it's just meant to give you an instant notification of when you're in danger or out of danger so that you can use a threat dropping spell, run like hell, etc, and know whether it worked or not. Therefore after the first notification other enemies can aggro on you as well without further notifications. The bottom line is that you should consider yourself in danger until you see the "all clear" notification.

Q7. Are you going to be updating AggroNotifier with new features?
A7. This does what I want for now but I'd be happy to add a small feature or two, so if you want something let me know.

Q8. AggroNotifier needs feature X.
A8. See Q7 and A7 above. I may add a few features, but I might not depending on how much spare time I have. The AggroNotifier code is well commented and should be easy to extend, however. You're more than welcome to make modifications to it yourself if I'm not able to work on it.

Q9. Can I include AggroNotifier in a compilation?
A9. Sure! Just send me a quick email so I know where AggroNotifier is being used. morrigahn.tpk[at]gmail[dot]com.

Q10. I want to take over maintenance of AggroNotifier so that I can add a bunch of features, since you're not actively working on it as much as I'd like.
A10. Cool. I probably won't have any problem with this. Just email me at morrigahn.tpk[at]gmail[dot]com.