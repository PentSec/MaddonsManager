local spellIDs = TotemTimers_SpellIDs
