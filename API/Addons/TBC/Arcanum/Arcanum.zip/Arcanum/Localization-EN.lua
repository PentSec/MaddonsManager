﻿------------------------------------------------------------------------------------------------------
-- Arcanum

-- Addon pour Mage inspiré du célébre Necrosis
-- Gestion des buffs, des portails et Compteur de Composants

-- Remerciements aux auteurs de Necrosis

-- Auteur Lenny415

-- Serveur:
-- Uliss, Nausicaa, Solcarlus, Thémys on Medivh EU
------------------------------------------------------------------------------------------------------

function Arcanum_Localization_Dialog_En()
	function ArcanumLocalization()
		Arcanum_Localization_Speech_En();
	end
	-- Raccourcis claviers
	BINDING_HEADER_ARCANUM_BIND = "Arcanum";
    BINDING_NAME_ACTIVATE = "Activate/D\195\169activate Arcanum";
	BINDING_NAME_STEED = "Steed";
	BINDING_NAME_FROSTARMOR = "Ice Armor";
	BINDING_NAME_MAGEARMOR = "Mage Armor";
    BINDING_NAME_FIREARMOR = "Molten Armor";
	BINDING_NAME_ARCANEINTELLECT = "Arcane Intellect";
	BINDING_NAME_ARCANEBRILLIANCE = "Arcane Brilliance";
	BINDING_NAME_AMPLIFYMAGIC = "Amplify Magic";
	BINDING_NAME_DAMPENMAGIC = "Dampen Magic";
	BINDING_NAME_CONJUREFOOD = "Conjure Food";
	BINDING_NAME_USEFOODWATER = "Eating & Drinking";
	BINDING_NAME_USEFOOD = "Eating";
	BINDING_NAME_CONJUREWATER = "Conjure Water";
	BINDING_NAME_USEWATER = "Drinking";
	BINDING_NAME_CONJUREMANAGEM = "Conjure a mana Gem";
	BINDING_NAME_USEMANAGEM = "Using a mana gem";
	BINDING_NAME_EVOCATION = "Evocation";
	BINDING_NAME_TELEPORT1 = "Teleport 1";
	BINDING_NAME_TELEPORT2 = "Teleport 2";
	BINDING_NAME_TELEPORT3 = "Teleport 3";
    BINDING_NAME_TELEPORT4 = "Teleport 4";
	BINDING_NAME_TELEPORT5 = "Teleport 5";
	BINDING_NAME_TELEPORT6 = "Teleport 6";
	BINDING_NAME_PORTAL1 = "Portal 1";
	BINDING_NAME_PORTAL2 = "Portal 2";
	BINDING_NAME_PORTAL3 = "Portal 3";
    BINDING_NAME_PORTAL4 = "Portal 4";
	BINDING_NAME_PORTAL5 = "Portal 5";
	BINDING_NAME_PORTAL6 = "Portal 6";
	BINDING_NAME_PORTAL7 = "Portal 7";	
    BINDING_NAME_WARD1 = "Fire Ward";
	BINDING_NAME_WARD2 = "Frost Ward";
	
	
	ARCANUM_CONFIGURATION = {
		["Menu1"] = "Messages",
		["MessageMenu1"] = "Player :",
		["Tooltip0"] = "No Tooltip",
		["Tooltip1"] = "Partial Tooltips",
		["Tooltip2"] = "Full Tooltips",
		["ChatType"] = "Messages = System messages",
		["PortalMessage"] = "Show messages when summoning a portal",
        ["MountMessage"] = "Show messages when summoning a mount",
        ["ArcanumButtonDisplay"] = "Display inside the sphere :",
        ["InsideDisplay"] = "Display inside the sphere:",
        ["DisplayHearthStone"] = "HearthStone",
        ["DisplayManaGem"] = "ManaGem",
        ["DisplayEvocation"] = "Evocation",
        ["DisplayIceBlock"] = "IceBlock",
        ["DisplayColdSnap"] = "ColdSnap",
        ["DisplayIntell"] = "Intell.",
        ["DisplayArmor"] = "Armor",
        ["DisplayBandage"] = "Bandage",
        ["Bindings"] = "Bindings",
				
		["Menu2"] = "Misc.",
		["LevelBuff"] = "Buff the target depending on his level",
		["EvocationLimit"] = "Mana percentage Evocation can be casted",
        ["ConsumeFood"] = "Consume Water/Food starting by",
        ["ConsumeGems"] = "Consume Gems starting by",
        ["RandMount"] = "Summon a mount randomly",
        ["DeleteFood"] = "Delete conjured food",
		["DeleteWater"] = "Delete conjured water",
		["DeleteManaGem"] = "Delete conjured mana gems",
		
		["Menu3"] = "Reagent Auto buy",
		["ReagentSort"] = "Sort reagents in same bag",
		["ReagentBag"] = "Reagent bag",
		["ReagentBuy"] = "Auto buy reagents",
		["Reagent"] = "Reagent Maximum quantity in bags:",
		["Powder"] = "Arcane Powder",
		["Teleport"] = "Rune of Teleportation",
		["Portal"] = "Rune of Portals",
		
		["Menu4"] = "Graphical Settings",
		["Toggle"] = "Activate Arcanum",
        ["InterfaceVersion"] = "Arcanum with menus",
		["InterfaceVersion2"] = "Arcanum without menus",
		["Lock"] = "Lock Arcanum",
		["IconsLock"] = "Lock Arcanum Buttons",
		["ArcanumRotation"] = "Rotate Arcanum",
		["ArcanumSize"] = "Size of Arcanum",
        ["ButtonSize"] = "Size of buttons",
		
		["Menu5"] = "Buttons",
        ["Button"] = "Show button of:",
        ["Order"] = "Change buttons order:",
		["BuffButton"] = "buffs",
		["ArmorButton"] = "armors",
		["MagicButton"] = "magic",
		["PortalButton"] = "portals",
		["MountButton"] = "mount",
		["FoodButton"] = "food",
		["WaterButton"] = "water",
		["ManaGemButton"] = "mana gem",
        ["JobButton"] = "professions",
        ["WardButton"] = "wards",
        ["MinimapIcon"] = "Show minimap icon",
        ["ArcanumMinimapIconPos"] = "Minimap icon position:",
        
        ["Menu6"] = "Menus",
		["MenuPosition"] = "Menu Opening ways:",
		["BuffMenu"] = "Buffs:",
		["ArmorMenu"] = "Armors:",
		["MagicMenu"] = "Magic:",
		["PortalMenu"] = "Portals:",
        ["MountMenu"] = "Mounts:",
        ["JobMenu"] = "Professions:",
        ["WardMenu"] = "Wards:",
        ["MenuScale"] = "Menus size",
		["MenuPosition"] = "Menus position",
        
        ["Menu7"] = "Skins",
        ["HealthColor"] = "Health bar color",
        ["ManaColor"] = "Mana bar color",
        ["ButtonColor"] = "Mouseover buttons color",
        ["DisplayHealthMana"] = "Display Health/Mana bars",
	};
	
    ARCANUM_CLICK = {
        "Evocation",
        "Eating & Drinking",
        "Switch solo/group mode",
        "Configuration panel",
        "Mana gems",
        "Ice block",
        "Hearthstone",
        "Sheeping",
    };
    
    ARCANUM_INSIDE_DISPLAY = {
        "Health numeric",
        "Health %",
        "Mana numeric",
        "Mana %",
        "Evocation CD",
        "Nothing",
    };
    
    ARCANUM_MENU_POS = {
        "Right",
        "Left",
        "Up",
        "Down",
    };
    
    ARCANUM_CONSUME_FOOD = {
        "the left bag",
        "the right bag",
    };
    
    ARCANUM_CONSUME_GEMS = {
        "the highest one",
        "the lowest one",
    };

	ARCANUM_TOOLTIP_DATA = {
	["LastSpell"] = "Left click to cast",
    ["LastSpell2"] = "Middle click to cast";
        ["SpellTimer"] = {
			Label = "Spell Durations",
			Text = "Active Spells on the target",
			Right = "<white>Right Click for Hearthstone to "
        };
	};
	
    ARCANUM_BINDING = {
		["Current"] = " is currently bound to ",
		["Confirm"] = "Do you want to bind ",
		["To"] = " to ",
		["Yes"] = "Yes",
		["No"] = "No",
		["InCombat"] = "Sorry, you can't change key bindings while in combat.",
		["Binding"] = "Bindings",
		["Unbind"] = "Unbind",
		["Cancel"] = "Cancel",
		["Press"] = "Press a key to bind...\n\n",
		["Now"] = "Currently: ",
		["NotBound"] = "Not Bound",
	};
    
	ARCANUM_MESSAGE = {
	  	["Interface"] = {
	    	["InitOn"] = "<white>activated. /arcanum or /arca to show the Configuration window",
	    	["InitOff"] = "<white>deactivated. /arca",
			["DefaultConfig"] = "<lightYellow>Default configuration loaded.",
			["UserConfig"] = "<lightYellow>Configuration loaded."
		},
	  	["Tooltip"] = {
	   		["LeftClick"] = "Left Click: ",
			["MiddleClick"] = "Middle Click: ",
	    	["RightClick"] = "Right Click: ",
	 		["Cooldown"] = "Hearthstone available in ",
            ["Minimap"] = "Configuration panel",
	  	},
		["Error"] = {
	  		["NoHearthstone"] = "No Hearthstone has been found in inventory.",
      		["NoMount"] = "No mount has been found in inventory.",
		},
		["Autobuy"] = "Buying ",
	};
end

function Arcanum_Localization_Speech_En()
	ARCANUM_PORTAL_MESSAGES = {
		{"The <me> Airline Company wishes you an enjoyable trip to <city>."},
		
		{"Please click <me>'s portal and you will arrive at <city>."},
		
		{"Don't interrupt <me> now because <me2> is busy opening a portal to <city>."},
		
		{"<city> is opening in 10 seconds, have a nice journey."},
		
		{"Don't interrupt <me> now because <me2> is busy opening a portal to <city>."},
		};
    
    ARCANUM_MOUNT_MESSAGES = {
        {"My right foot is jealous of my left foot. When one advance, the other wants exceed it. And I as a fool, I walk!... and thee, my mount?"},

        {"The time is money. Are quickly to catch up"},
		
		{"Not off, I am tired"},
        };
	
	ARCANUM_RITUAL_MESSAGES = {
		{"Gaza saoulards! You want to the binouze and what grailler? So click on the portal!"},
		
		{"Y' has no pinard here! But there you can remedier! Click for a takeover by Gerard!" }, 
    };
end

if ( GetLocale() == "enUS" ) or ( GetLocale() == "enGB" ) then
	-- Table des sorts du mage
	ARCANUM_SPELL_TABLE = {
		["ID"] = {},
		["Rank"] = {},
		["Name"] = {
			"Frost Armor",										--1
			"Ice Armor",                      					--2
			"Mage Armor",                   					--3
			"Molten Armor",                                     --4
			"",
            "Dampen Magic",                  					--6
			"Amplify Magic",                        			--7
			"Conjure Food",                       				--8
			"Conjure Water",                        			--9
			"",
			"",
			"Arcane Intellect",			                		--12
			"Arcane Brilliance",	                        	--13
			"",
			"Teleport: Darnassus",								--15
			"Teleport: Ironforge",								--16
			"Teleport: Stormwind",         						--17
            "Teleport: Exodar",                                 --18
			"Teleport: Orgrimmar",								--19
			"Teleport: Thunder Bluff",							--20
			"Teleport: Undercity",         						--21
            "Teleport: Silvermoon",                             --22
			"Portal: Darnassus",								--23
			"Portal: Ironforge",					 			--24
			"Portal: Stormwind",								--25
            "Portal: Exodar",                                   --26
			"Portal: Orgrimmar",								--27
			"Portal: Thunder Bluff",					 		--28
			"Portal: Undercity",	           					--29
            "Portal: Silvermoon",                               --30
			"",
            "",
			"",
            "",
			"",
			"",
            "Ice Block",                                        --37
            "Cold Snap",                                        --38
            "Bandage",                                          --39
            "Teleport: Shattrath",                              --40
            "Portal: Shattrath",                                --41
            "Evocation",            							--42
			"Ritual of Refreshment",                            --43
            "Portal : Theramore",                               --44
            "Teleport : Theramore",                             --45
			"Portail : Stonard",                                --46
            "Teleport : Stonard",                               --47
			"Conjured Manna Biscuit",                           --48
			"Conjure Mana Agate",       						--49
			"Conjure Mana Jade",                   			 	--50		
			"Conjure Mana Citrine",                 			--51
			"Conjure Mana Ruby",				    			--52
            "Conjure Mana Emerald",                             --53
			"Polymorph",                                        --54
            "Polymorph : Pig",                                  --55
            "Polymorph : Turtle",                               --56
			"Fire Ward",                                        --57
            "Frost Ward"                                        --58
			},
		["Mana"] = {},
        ["Texture"] = {},
	};
    
    ARCANUM_PROFESSIONS = {
    ["ID"] = {},
    ["Name"] = {
	            "Alchemy", 
				"Blacksmithing", 
				"Cooking", 
				"Disenchant", 
				"Enchanting", 
				"Engineering", 
				"Find Herbs", 
				"Find Minerals", 
				"First Aid", 
				"Fishing", 
				"Jewelcrafting", 
				"Leatherworking", 
				"Prospecting", 
				"Smelting", 
				"Tailoring"
				},
    ["Texture"] = {},
    };
    
	ARCANUM_MANAGEM = {
	                   "Mana Agate", 
					   "Mana Jade", 
					   "Mana Citrine", 
					   "Mana Ruby", 
					   "Mana Emerald"
					   };
	
	ARCANUM_FOOD = {
	               "Conjured Muffin", 
				   "Conjured Bread", 
				   "Conjured Rye", 
				   "Conjured Pumpernickel",
	               "Conjured Sourdough", 
				   "Conjured Sweet Roll", 
				   "Conjured Cinnamon Roll", 
				   "Conjured Croissant",
				   "Conjured Manna Biscuit"
				   };
	
	ARCANUM_WATER = {
	                "Conjured Water", 
					"Conjured Fresh Water", 
					"Conjured Purified Water",
	                "Conjured Spring Water", 
					"Conjured Mineral Water", 
					"Conjured Sparkling Water", 
					"Conjured Crystal Water", 
					"Conjured Mountain Spring Water", 
					"Conjured Glacier Water",
					"Conjured Manna Biscuit"
					};
					
	ARCANUM_MANNE = {
                    "Conjured Manna Biscuit"	
                    };							
	
    ARCANUM_BANDAGE = "A bandage was applied recently";
    
    ARCANUM_TRANSLATION = {
		["Mounting"] = "Summoning",
        ["Hearth"] = "Hearthstone";
		["Cooldown"] = "Cooldown",
		["Rank"] = "Rank",
	};
    
	-- Table des items du Mage
	ARCANUM_ITEM = {
		["ArcanePowder"] = "Arcane Powder",
		["RuneOfTeleportation"] = "Rune of Teleportation",
		["RuneOfPortals"] = "Rune of Portals",
		["LightFeathers"] = "Light Feather",
		["Hearthstone"] = "Hearthstone",
		["QuirajiMount"] = "Quiraji Resonating Crystal",
	};
    
	-- Monture	
	MOUNT = {
	    {"Horn of the Black War Wolf", "Horn of the Brown Wolf", "Horn of the Red Wolf", "Horn of the Swift Brown Wolf", "Horn of the Timber Wolf"},
		{"Reins of the Striped Nightsaber", "Reins of the Black War Tiger"},
		{"Swift Zulian Tiger"},
		{"Gray Kodo", "Great Gray Kodo", "Great White Kodo"},
		{"Green Kodo", "Teal Kodo"},
		{"Black War Kodo", "Brown Kodo", "Great Brown Kodo"},
		{"Black Battlestrider", "Blue Mechanostrider", "Green Mechanostrider", "Icy Blue Mechanostrider Mod A", "Red Mechanostrider", "Swift Green Mechanostrider", "Swift White Mechanostrider", "Swift Yellow Mechanostrider", "Unpainted Mechanostrider", "White Mechanostrider Mod A"},
		{"Stormpike Battle Charger", "Black Ram", "Black War Ram", "Brown Ram", "Frost Ram", "Gray Ram", "Swift Brown Ram", "Swift Gray Ram", "Swift White Ram", "White Ram"},
		{"Black War Steed Bridle"},
		{"Reins of the Winterspring Frostsaber"},
		{"Whistle of the Black War Raptor", "Whistle of the Emerald Raptor", "Whistle of the Ivory Raptor", "Whistle of the Mottled Red Raptor", "Whistle of the Turquoise Raptor", "Whistle of the Violet Raptor", "Swift Olive Raptor", "Swift Orange Raptor", "Swift Blue Raptor", "Swift Razzashi Raptor"},
		{"Black Stallion Bridle", "Brown Horse Bridle", "Chestnut Mare Bridle", "Palomino Bridle", "Pinto Bridle", "Swift Brown Steed", "Swift Palomino", "Swift White Steed", "White Stallion Bridle"},
		{"Deathcharger's Reins", "Blue Skeletal Horse", "Brown Skeletal Horse", "Green Skeletal Warhorse", "Purple Skeletal Warhorse", "Red Skeletal Horse", "Red Skeletal Warhorse"},
		{"Horn of the Arctic Wolf", "Horn of the Dire Wolf", "Horn of the Swift Gray Wolf", "Horn of the Swift Timber Wolf"},
		{"Reins of the Frostsaber", "Reins of the Nightsaber", "Reins of the Spotted Frostsaber", "Reins of the Striped Frostsaber", "Reins of the Swift Frostsaber", "Reins of the Swift Mistsaber", "Reins of the Swift Stormsaber"},
		{"Horn of the Frostwolf Howler"},
        {"Black Hawkstrider", "Red Hawkstrider", "Blue Hawkstrider", "Purple Hawkstrider"},
        {"Swift Purple Hawkstrider", "Swift Pink Hawkstrider", "Swift Green Hawkstrider"},
        {"Brown Elekk", "Purple Elekk", "Gray Elekk", "Great Blue Elekk", "Great Green Elekk", "Great Purple Elekk"},
        {"Reins of the Dark War Talbuk", "Reins of the Silver War Talbuk", "Reins of the Cobalt War Talbuk", "Reins of the Tan War Talbuk", "Reins of the White War Talbuk"},
        {"Reins of the Dark Riding Talbuk", "Reins of the Tan Riding Talbuk", "Reins of the Silver Riding Talbuk", "Reins of the Cobalt Riding Talbuk", "Reins of the White Riding Talbuk"},
        {"Ebon Gryphon", "Golden Gryphon", "Snowy Gryphon", "Swift Blue Gryphon", "Swift Green Gryphon", "Swift Purple Gryphon", "Swift Red Gryphon"},
        {"Tawny Windrider", "Green Windrider", "Blue Windrider", "Swift Purple Windrider", "Swift Yellow Windrider", "Swift Red Windrider", "Swift Green Windrider"},
		{"Blue Riding Nether Ray", "Green Riding Nether Ray", "Red Riding Nether Ray", "Purple Riding Nether Ray", "Silver Riding Nether Ray"}, 
        {"Fiery Warhorse's Reins"},
        {"Reins of the Raven Lord"},
        {"Reins of the Veridian Netherwing Drake", "Reins of the Azure Netherwing Drake", "Reins of the Cobalt Netherwing Drake", "Reins of the Onyx Netherwing Drake", "Reins of the Violet Netherwing Drake", "Reins of the Purple Netherwing Drake"},
        {"Cenarion War Hippogryph"}	
	};  
    
    MOUNT_SPEED = "Increases speed by (%d+)%%.";

	MOUNT_PREFIX = {"Reins of the ", "Whistle of the ", "Horn of the ", "Bridle"};
		
	QIRAJ_MOUNT = {
		"Yellow Qiraji Resonating Crystal",
		"Red Qiraji Resonating Crystal",
	  	"Green Qiraji Resonating Crystal",
		"Blue Qiraji Resonating Crystal",
		"Black Qiraji Resonating Crystal"
	};

end