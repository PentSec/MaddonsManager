﻿ArcanumData = {};
ArcanumData.Version = "2.0b10";
ArcanumData.Author = "Nausicaa on Medivh FR";
ArcanumData.AppName = "Arcanum";
ArcanumData.Label = ArcanumData.AppName.." "..ArcanumData.Version.." by "..ArcanumData.Author;