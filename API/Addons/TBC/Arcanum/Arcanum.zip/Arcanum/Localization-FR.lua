------------------------------------------------------------------------------------------------------
-- Arcanum

-- Addon pour Mage inspiré du célébre Necrosis
-- Gestion des buffs, des portails et Compteur de Composants

-- Remerciements aux auteurs de Necrosis

-- Auteur Lenny415

-- Serveur:
-- Uliss, Nausicaa, Solcarlus, Thémys on Medivh EU
------------------------------------------------------------------------------------------------------

function Arcanum_Localization_Dialog_Fr()
	function ArcanumLocalization()
		Arcanum_Localization_Speech_Fr();
	end
	-- Raccourcis claviers
	BINDING_HEADER_ARCANUM_BIND = "Arcanum";
	BINDING_NAME_ACTIVATE = "Activer/D\195\169sactiver Arcanum";
	BINDING_NAME_STEED = "Monture";
	BINDING_NAME_FROSTARMOR = "Armure de glace";
	BINDING_NAME_MAGEARMOR = "Armure du mage";
	BINDING_NAME_FIREARMOR = "Armure de la fournaise";
	BINDING_NAME_ARCANEINTELLECT = "Intelligence des arcanes";
	BINDING_NAME_ARCANEBRILLIANCE = "Illumination des arcanes";
	BINDING_NAME_AMPLIFYMAGIC = "Amplification de la magie";
	BINDING_NAME_DAMPENMAGIC = "Att\195\169nuation de la magie";
	BINDING_NAME_CONJUREFOOD = "Invocation de nourriture";
	BINDING_NAME_USEFOODWATER = "Manger & boire";
	BINDING_NAME_USEFOOD = "Manger";
	BINDING_NAME_CONJUREWATER = "Invocation d'eau";
	BINDING_NAME_USEWATER = "Boire";
	BINDING_NAME_CONJUREMANAGEM = "Invocation d'une gemme de mana";
	BINDING_NAME_USEMANAGEM = "Utilisation d'une gemme de mana";
	BINDING_NAME_EVOCATION = "Evocation";
	BINDING_NAME_TELEPORT1 = "T\195\169l\195\169portation 1";
	BINDING_NAME_TELEPORT2 = "T\195\169l\195\169portation 2";
	BINDING_NAME_TELEPORT3 = "T\195\169l\195\169portation 3";
    BINDING_NAME_TELEPORT4 = "T\195\169l\195\169portation 4";
	BINDING_NAME_TELEPORT5 = "T\195\169l\195\169portation 5";
	BINDING_NAME_TELEPORT6 = "T\195\169l\195\169portation 6";
	BINDING_NAME_PORTAL1 = "Portail 1";
	BINDING_NAME_PORTAL2 = "Portail 2";
	BINDING_NAME_PORTAL3 = "Portail 3";
	BINDING_NAME_PORTAL4 = "Portail 4";
	BINDING_NAME_PORTAL5 = "Portail 5";
	BINDING_NAME_PORTAL6 = "Portail 6";
	BINDING_NAME_PORTAL7 = "Portail 7";	
    BINDING_NAME_WARD1 = "Gardien de feu";
	BINDING_NAME_WARD2 = "Gardien de givre";
    
	ARCANUM_CONFIGURATION = {
		["Menu1"] = "Messages",
		["MessageMenu1"] = "Joueur :",
		["Tooltip0"] = "Aucun Tooltip",
		["Tooltip1"] = "Tooltips partiels",
		["Tooltip2"] = "Tooltips complets",
		["ChatType"] = "Les messages = des messages syst\195\168mes",
		["PortalMessage"] = "Afficher les messages de l'invocation d'un portail",
        ["MountMessage"] = "Afficher les messages de l'invocation d'une monture",
        ["ArcanumButtonDisplay"] = "Affichage dans la sphère :",
        ["InsideDisplay"] = "Afficher dans la sphère :",
        ["DisplayHearthStone"] = "Pierre de foyer",
        ["DisplayManaGem"] = "Gemme de mana",
        ["DisplayEvocation"] = "Evocation",
        ["DisplayIceBlock"] = "Bloc de glace",
        ["DisplayColdSnap"] = "Morsure de glace",
        ["DisplayIntell"] = "Intell.",
        ["DisplayArmor"] = "Armure",
        ["DisplayBandage"] = "Bandage",
        ["Bindings"] = "Raccourcis clavier",
		
		["Menu2"] = "Divers",
		["LevelBuff"] = "Buffer la cible en fonction de son niveau",
        ["EvocationLimit"] = "Limite à partir de laquelle l'\195\169vocation peut être lanc\195\169",
        ["ConsumeFood"] = "Consommer eau/pain dans les sacs",
        ["ConsumeGems"] = "Consommer une gemme de mana",
        ["RandMount"] = "Invoquer une monture aléatoire",
		["DeleteFood"] = "Supprimer la nourriture invoqu\195\169e",
		["DeleteWater"] = "Supprimer l'eau invoqu\195\169e",
		["DeleteManaGem"] = "Supprimer les gemmes de mana",
		
		["Menu3"] = "Achat auto des composants",
		["ReagentSort"] = "Rangement des composants dans un même sac",
		["ReagentBag"] = "Sac des composants",
		["ReagentBuy"] = "Achat auto des composants",
		["Reagent"] = "Quantit\195\169 Maximum des composants dans le sac:",
		["Powder"] = "Poudre des arcanes",
		["Teleport"] = "Rune de t\195\169l\195\169portation",
		["Portal"] = "Rune des portails",
		
		["Menu4"] = "Graphique",
		["Toggle"] = "Afficher Arcanum",		
        ["InterfaceVersion"] = "Arcanum avec menus",
		["InterfaceVersion2"] = "Arcanum sans menus",
		["Lock"] = "Verrouiller Arcanum",
		["IconsLock"] = "Verouiller les boutons d'Arcanum sur la sph\195\169re",
		["ArcanumRotation"] = "Rotation d'Arcanum",
		["ArcanumSize"] = "Taille d'Arcanum",
        ["ButtonSize"] = "Taille des boutons",
		
		["Menu5"] = "Boutons",
        ["Button"] = "Afficher le bouton des :",
        ["Order"] = "Changer l'order des boutons:",
		["BuffButton"] = "buffs",
		["ArmorButton"] = "armures",
		["MagicButton"] = "magies",
		["PortalButton"] = "portails",
		["MountButton"] = "montures",
		["FoodButton"] = "nourritures",
		["WaterButton"] = "boissons",
		["ManaGemButton"] = "gemmes de mana",
        ["JobButton"] = "métiers",
        ["WardButton"] = "gardiens",
        ["MinimapIcon"] = "Afficher l'icone de la minimap",
        ["ArcanumMinimapIconPos"] = "Position de l'icone minimap:",
        
        ["Menu6"] = "Menus",
        ["MenuPosition"] = "Orientation des menus:",
		["BuffMenu"] = "Buffs:",
		["ArmorMenu"] = "Armures:",
		["MagicMenu"] = "Magies:",
		["PortalMenu"] = "Portails:",
        ["MountMenu"] = "Montures:",
        ["JobMenu"] = "Métiers:",
        ["WardMenu"] = "Gardiens:",
        ["MenuScale"] = "Taille des menus",
		["MenuPosition"] = "Position des menus",
        
        ["Menu7"] = "Thèmes",
        ["HealthColor"] = "Couleur de la barre de vie",
        ["ManaColor"] = "Couleur de la barre de mana",
        ["ButtonColor"] = "Couleur des boutons sélectionnés",
        ["DisplayHealthMana"] = "Afficher les barres de vie/mana",
	};
	
    ARCANUM_CLICK = {
        "Evocation",
        "Boire & Manger",
        "Changer de mode solo/groupe",
        "Panneau de configuration",
        "Gemmes de mana",
        "Bloc de glace",
        "Pierre de foyer",
        "Mouton",
    };
    
    ARCANUM_INSIDE_DISPLAY = {
        "Vie numérique",
        "Vie %",
        "Mana numérique",
        "Mana %",
        "CD Evocation",
        "Rien",
    };
    
    ARCANUM_MENU_POS = {
        "Droite",
        "Gauche",
        "Haut",
        "Bas",
    };
    
    ARCANUM_CONSUME_FOOD = {
    	"les plus à gauche",
        "les plus à droite",
    };
		    
    ARCANUM_CONSUME_GEMS = {
        "par la plus grande",
        "par la plus petite",
    };

	ARCANUM_TOOLTIP_DATA = {
        ["LastSpell"] = "Clic gauche pour lancer";
        ["LastSpell2"] = "Clic milieu pour lancer";
        ["SpellTimer"] = {
			Label = "Dur\195\169e des sorts",
			Text = "Sorts actifs sur la cible",
			Right = "<white>Clic Droit pour pierre de foyer vers ",
        };
	};

    ARCANUM_BINDING = {
		["Current"] = " est actuellement associ\195\169 \195\160 ",
		["Confirm"] = "Voulez-vous associer ",
		["To"] = " \195\160 ",
		["Yes"] = "Oui",
		["No"] = "Non",
		["InCombat"] = "D\195\169sol\195\169, vous ne pouvez pas changer les raccourcis claviers en combat.",
		["Binding"] = "Raccourcis",
		["Unbind"] = "Supprimer",
		["Cancel"] = "Annuler",
		["Press"] = "Appuyez sur la touche\n\n\195\160 associer...\n\n\n\n",
		["Now"] = "Actuellement : ",
		["NotBound"] = "Non affect\195\169e",
	};
    
	ARCANUM_MESSAGE = {
	  	["Interface"] = {
	    	["InitOn"] = "<white>activ\195\169. /arcanum ou /arca pour afficher la fen\195\170tre de configuration",
	    	["InitOff"] = "<white>d\195\169sactiv\195\169.",
	  		["DefaultConfig"] = "<lightYellow>Configuration par defaut charg\195\169e.",
			["UserConfig"] = "<lightYellow>Configuration charg\195\169e"
		},
	  	["Tooltip"] = {
	    	["LeftClick"] = "Clic Gauche: ";
			["MiddleClick"] = "Clic Milieu: ";
	    	["RightClick"] = "Clic Droit: ";
	 		["Cooldown"] = "Pierre de foyer disponible dans ";
            ["Minimap"] = "Panneau de configuration";
	  	},
		["Error"] = {
	  		["NoHearthstone"] = "Vous n'avez pas de pierre de foyer dans votre inventaire",
      		["NoMount"] = "Vous n'avez pas de monture dans votre inventaire",
		},
		["Autobuy"] = "Achat de ",
	};
end

function Arcanum_Localization_Speech_Fr()
	ARCANUM_PORTAL_MESSAGES = {
		{"Par la toute puissance des \195\169l\195\169ments! Reechani! Sentrosi! Vasi! Je vous invoque, ouvrez-moi une faille vers <city>.",},
		
        {"La compagnie <me> Airline vous souhaite un agr\195\169able voyage vers <city>." },
		
        {"Bon, c'\195\169tait quoi encore la formule pour ce portail... 'Razh masha en Al'doorh belis...' Zut, ça c'est pour <1>!",
			"Alors... ah oui! 'Keal ni Sora el'thiba...' Mais non, c'est pour <2> celle-ci!",
			"Allez, j'incante au hasard, mais je crois bien que ça c'est pour <city>.!"},
        
        {"Vers <city>, et au delà !"},

        {"ChaKraimedheliel WoooshÆnemaaakhazambalty '<city> !... Heuu quelqu'un aurait un bouchoir ? j'ai un rhube d'enfer !"},

        {"Un jour j'ai fait confiance à un pet, et je me suis chié dessus. Mais bon, heureusement je... hein ? Ah heeuu oui un portail... vers <city>."},

        {"N'oubliez pas le pourboire en sortant. Nous vous souhaitons de passer un agréable séjour à <city>."},

        {"Allez, je vous emmène à <city>, vers de nouvelles aventures !"},

        {"Deux yeux de chauve-souris, 5 cristaux des arcarnes et une pierre qui roule qui n'amasse pas mousse... Hop, et voilà ! Un beau portail pour <city>."},

        {"Vous n'auriez pas deux allumettes et une pile Alcagobline ? J'aimerais vous confectionner un portail vers <city>."},

        {"Allez, tirons-nous d'ici. Il est complètement nul cet endroit !"},

        {"La téléportation vers <city> peut provoquer les symptômes suivants: vomissements, maux de tête,picotements aux doigts de pieds gauches, et incontinence subite."},

        {"Veuillez prendre note que des sacs en papier sont disponibles en cas de vômissements. Deserrez votre ceinture et détendez vous, nous arrivons à <city>."},

        {"Ceci n'est pas un portail vers <city>."},

        {"On part pour <city>. Le dernier ferme la porte derrière lui s'il vous plait."},

        {"Nous vous souhaitons un bon séjour à <city>, la température au sol est de 19°C et il n'y a actuellement aucune précipitation de pivons sur la ville."},

        {"OK, à 3, nous concentrerons tous nos énergies en criant 'HOURAAA'. Si tout se passe comme prévu, un portail vers <city> devrait apparaître.Allez, 1.... 2.... 3 !! Pffff vous êtes nuls :"},

        {"Puisse la puissance de tous les Pivons venir en moi pour invoquer un portail vers <city>. Hein ?...Heuu non moi non plus je ne sais pas ce que c'est qu'un Pivon."},

        {"click click click'in on heaven's doooors <city>"},

        {"Je me trompe peut-être, mais il me semble que la dépressurisation inhérente à l'ouverture d'une porte en direction de <city> telle que celle que je vous prépare actuellement devrait être au moins aussi déflexible",
            "que la résultante des deux aspects névralgiques de la spaciosité latérale. Mais... vous allez où là ? Revenez !! *soupir."},

        {"Helo, je sui sélibatère. Com'vou le voyé je sui de bel apparansse. Je çui sossiable, simpatik é cultiver.",
        "Si je vous plé, passé par se portaï qui condui direktemant dant ma chanbre a <city>."},

        {"Ce matin, je me disais que l'infini, c'est quand même vachement long. Surtout vers la fin, en fait. Pas vrai ?",
            "Oh puis laisse tomber, t'es qu'un pivon !... C'est bon, je l'ouvre ce portail vers <city>."},

        {"Ouf ! Enfin une invocation de portail vers <city> sans commentaire idiot..."},

        {"Onyxia et Natt Paggle sont dans un bateau. Natt Paggle tombe à l'eau. Qui est-ce qu'il reste ? Personne, Onyxia coule...",
            "Non arrête ! Je ne voudrais pas maigrir en mangeant tes commentaires. <city>."},

        {"Pour effacer tous vos problèmes personnels, il vous suffit de supprimer les WTB et WTF de votre vie. Ca marche à coups sûrs.",
            "(C'est mon pote Emji qui m'a donné ce truc). Hop hop ! Portail vers <city> en cours"},

        {"J'espère que je ne vias pas encoer me mélagner lse pcinueax en pornoncnant ma fromlule migaque... RRrrraaaaahH ! <city>"},

        {"AVERTISSEMENT: Les substances halogènes contenues dans ce portail pour <city> peuvent éclairer votre esprit"},

        {"Derrière ce portail, des créatures aux corps parfaits n'attendent que vous pour vous offrir les plaisirs charnels les plus intenses.",
            "Dorénavant, vous vivrez dans la luxure totale. Heuu... ah non flûte, c'est seulement un portail vers <city>..."},

        {"Je pense qu'un égoïste, c'est quelqu'un qui ne pense pas à moi <city>."},

        {"N'entrez pas dans ce portail pour <city>! Dedans, un dandy vous dédie un dédain dantesque débile"},

        {"Saviez-vous que le mot patatrak vient du latin badabum ?... <city>."},

        {"Êtes-vous prêts à entrer dans la légende ? Non ?! Ca tombe bien, ça s'appelle un portail vers <city>."},

        {"Bonjour chers héros venus des contrées les plus lointaines des terres d'Azeroth, de Kalimdor, de Northrend, ou d'ailleurs.",
            "Ô vous qui avez bravé les pires dangers que ces terres ont connus depuis que ce monde est monde!",
            "Je vous demande une autorisation écrite de vos parents pour vous laisser prendre ce portail vers <city>"},

        {"Les incidents de téléportation sont extrêmement rares. La probabilité d'exploser est de 3.37%,",
            "d'avoir un membre quelconque arraché: 6.49%, de se transformer en troll: 12%, de devenir impuissant: 7.19%,",
            "d'avoir un mal de gorge: 0.019%. Pas de quoi paniquer, alors détendez vous et fumez votre derniè... heuu une cigarette."},

        {"Sortir un lapin de mon chapeau ? Découper des jolies filles souriantes en morceaux ? Faire disparaître des cartes ?",
            "Tu m'prends pour un magicien ou quo... heuu hein ? ah heuu oui oui, un portail vers <city>..."},

        {"VOUUUUS NE PASSSEREZZZZ PAAAAAAAAAAS !!!... Et là ? C'était assez crédible comme mage ? <city>."},

        {"Bon, rentrez ou sortez, mais restez pas plantés là ! On voit que c'est pas vous qui payez les factures <city>."},

        {"Si vous ne voulez pas qu'un monstre tentaculaire sorte de ce porta... Hey ! Mais qu'est-ce que j'raconte moi ?! Portail vers <city>"},

        {"Ica ntbel ievethene wstod ay ! Ic an'tclo semye yesand ma k eitgoaw ay ! <city> !"},

        {"Attention, un portail pour <city> se cache dans l'image, trouve-le... Gagné !"},

        {"Vous trouverez la sortie pour <city> sur votre gauche. J'espère que la visite vous aura plu et n'oubliez pas le guide en partant."},

        {"Le premier qui revient ici-même après avoir passé par ce portail vers <city> recevra 25 PO"},

        {"Donnez-moi une porte ! Donnez-moi de l'ail !....... PORTAIL !! (oui, je sors... par ce portail vers <city>)"},

        {"Tu connais l'effet tunnel ? Il suffit d'être projeté assez fort contre un obstacle pour passer à travers.",
            "Mets-toi là, je vais essayer de te projeter vers <city>, et peut-être même Darnassus si je prends assez d'élan !"},

        {"Lasciate ogni speranza, voi che intrate... (Traduction : Laissez-moi vos pièces d'or, vous qui entrez ici). <city>"},

        {"Tu sais ce que veut dire 'ubiquité' ? Non ? Et bien va vérifier à la bibliothèque <city>, s'pèce de noob."},

        {"I'm playing on a french version, but I just want to m'la peter sévère. So, I'm creating a portal to <city>"},

        {"Suite à un mouvement social d'une partie du personnel, ce portail ne desservira que la gare de <city>"},

        {"Si vous voulez un portail vers <city>, ouvrez une fenêtre"},
	};
    
    ARCANUM_MOUNT_MESSAGES = {
        {"Mon pied droit est jaloux de mon pied gauche. Quand l’un avance, l’autre veut le dépasser. Et moi, comme un imbécile, je marche !... et toi, ma monture?"},

        {"Le temps, c'est de l'argent. Courons vite pour le rattraper"},
		
		{"Pas a pied,je suis fatigué"},
    };
    ARCANUM_RITUAL_MESSAGES = {
		{"Bande de saoulards! Vous voulez d'la binouze et de quoi grailler? Alors cliquez sur ce portail et faites po chier!"},
		
		{"Ya pas d'pinard ici! Mais on peut y remedier! Cliquez donc pour une prise en charge par Gerard!" },
    };
end

if ( GetLocale() == "frFR" ) then
	-- Table des sorts du mage
	ARCANUM_SPELL_TABLE = {
		["ID"] = {},
		["Rank"] = {},
		["Name"] = {
			"Armure de givre",									--1
			"Armure de glace",                      			--2
			"Armure du mage",                   				--3
			"Armure de la fournaise",                           --4
			"",
            "Att\195\169nuation de la magie",                   --6
			"Amplification de la magie",                        --7
			"Invocation de nourriture",                       	--8
			"Invocation d'eau",                        			--9
			"",
			"",
			"Intelligence des arcanes",	                        --12
			"Illumination des arcanes",			                --13
			"",
			"T\195\169l\195\169portation : Darnassus",			--15
			"T\195\169l\195\169portation : Forgefer",			--16
			"T\195\169l\195\169portation : Hurlevent",          --17
            "T\195\169l\195\169portation : Exodar",             --18
			"T\195\169l\195\169portation : Orgrimmar",			--19
			"T\195\169l\195\169portation : les Pitons du Tonnerre",	--20
			"T\195\169l\195\169portation : Fossoyeuse",         --21
            "T\195\169l\195\169portation : Lune-d'argent",      --22
			"Portail : Darnassus",								--23
			"Portail : Forgefer",					 			--24
			"Portail : Hurlevent",								--25
            "Portail : Exodar",                                 --26
			"Portail : Orgrimmar",								--27
			"Portail : les Pitons du Tonnerre",				    --28
			"Portail : Fossoyeuse",            					--29
            "Portail : Lune-d'argent",                          --30
			"",
			"",
            "",
            "",
            "",
            "",			
            "Bloc de glace",                                    --37
            "Morsure de glace",                                 --38
            "Bandage",                                          --39
            "T\195\169l\195\169portation : Shattrath",          --40
            "Portail : Shattrath",                              --41
            "Evocation",                                        --42
            "Rituel des rafra\195\174chissements",              --43
            "Portail : Theramore",                              --44
            "T\195\169l\195\169portation : Theramore",          --45
			"Portail : Pierr\195\170che",                       --46
            "T\195\169l\195\169portation : Pierr\195\170che",   --47
			"Biscuit de manne invoqu\195\169",                  --48
			"Invocation d'une agate de mana",       			--49
			"Invocation d'une jade de mana",                    --50		
			"Invocation d'une citrine de mana",                 --51
			"Invocation d'un rubis de mana",				    --52
            "Invocation d'une \195\169meraude de mana",         --53
			"M\195\169tamorphose",                              --54
            "M\195\169tamorphose : cochon",                     --55
            "M\195\169tamorphose : tortue",                     --56
			"Gardien de feu",                                   --57
            "Gardien de givre"                                  --58
			},
		["Mana"] = {},
        ["Texture"] = {},
	};
    
    ARCANUM_PROFESSIONS = {
["ID"] = {},
["Name"] = {
               "Alchimie", 
			   "Couture", 
			   "Cuisine", 
			   "D\195\169couverte d'herbes", 
			   "D\195\169couverte de gisements", 
			   "D\195\169senchanter", 
			   "Secourisme", 
			   "Enchantement", 
			   "Fondre", 
			   "Forge", 
			   "Ing\195\169nierie", 
			   "Joaillerie", 
			   "Prospection", 
			   "P\195\170che", 
			   "Travail du cuir"
			   },
["Texture"] = {},
};


    
	ARCANUM_MANAGEM = {"Agate de mana", 
	                   "Jade de mana", 
					   "Citrine de mana", 
					   "Rubis de mana", 
					   "Emeraude de mana"
					   };
	
	ARCANUM_FOOD = {
					"Muffin invoqu\195\169", 
					"Pain invoqu\195\169", 
					"Pain de seigle invoqu\195\169", 
					"Pain noir invoqu\195\169",
					"Pain de route invoqu\195\169", 
					"Pain au lait invoqu\195\169", 
					"Roul\195\169s à la cannelle invoqu\195\169s", 
					"Croissant invoqu\195\169",
					"Biscuit de manne invoqu\195\169"
   					};
	
	 ARCANUM_WATER = {
					  "Eau invoqu\195\169e", 
					  "Eau fra\195\174che invoqu\195\169e", 
					  "Eau purifi\195\169e invoqu\195\169e",
					  "Eau de source invoqu\195\169e", 
					  "Eau min\195\169rale invoqu\195\169e", 
					  "Eau p\195\169tillante invoqu\195\169e", 
					  "Eau cristalline invoqu\195\169e", 
					  "Eau de source des montagnes invoqu\195\169e", 
					  "Eau des glaciers invoqu\195\169e",
					  "Biscuit de manne invoqu\195\169"
   					}; 
					
	ARCANUM_MANNE = {
                    "Biscuit de manne invoqu\195\169",	
                    };			
    
    ARCANUM_BANDAGE = "Un bandage a \195\169t\195\169 appliqu\195\169 r\195\169cemment";
    
    ARCANUM_TRANSLATION = {
		["Mounting"] = "Invocation d'un";
        ["Hearth"] = "Pierre de foyer";
		["Cooldown"] = "Temps";
		["Rank"] = "Rang";
	};
    
	-- Table des items du Mage
	ARCANUM_ITEM = {
		["ArcanePowder"] = "Poudre des arcanes",
		["RuneOfTeleportation"] = "Rune de t\195\169l\195\169portation",
		["RuneOfPortals"] = "Rune des portails",
		["LightFeathers"] = "Plume l\195\169g\195\168re",
		["Hearthstone"] = "Pierre de foyer",
		["QuirajiMount"] = "Cristal de r\195\169sonance qiraji",
	};
    
	-- Monture	
	MOUNT = {
	    {"Cor du loup brun rapide", "Cor du loup de guerre noir", "Corne du loup brun", "Corne du loup des bois", "Corne du loup rouge"},
        {"R\195\170nes de sabre-de-nuit ray\195\169", "R\195\170nes de tigre de guerre noir"},
        {"Tigre zulien rapide"},
        {"Grand kodo blanc", "Kodo gris", "Grand kodo gris"},
        {"Kodo vert", "Kodo bleu"},
        {"Kodo brun", "Kodo de guerre noir", "Grand kodo brun"},
        {"Trotteur de bataille noir", "M\195\169canotrotteur bleu clair Mod A", "M\195\169canotrotteur blanc Mod A", "M\195\169canotrotteur blanc rapide", "M\195\169canotrotteur bleu", "M\195\169canotrotteur brut", "M\195\169canotrotteur jaune rapide", "M\195\169canotrotteur rouge", "M\195\169canotrotteur vert", "M\195\169canotrotteur vert rapide"},
        {"Destrier de bataille foudrepique", "B\195\169lier de givre", "B\195\169lier noir", "B\195\169lier blanc", "B\195\169lier blanc rapide", "B\195\169lier brun", "B\195\169lier brun rapide", "B\195\169lier gris", "B\195\169lier gris rapide", "B\195\169lier de guerre noir"},
        {"Bride de palefroi de guerre noir"},
        {"Rênes de sabre-de-givre de Berceau-de-l'Hiver"},
        {"Raptor bleu rapide", "Raptor orange rapide", "Raptor vert olive rapide", "Sifflet de Raptor ivoire", "Sifflet de Raptor rouge tachet\195\169", "Sifflet de raptor turquoise", "Sifflet de raptor violet", "Sifflet de raptor \195\169meraude", "Sifflet du raptor de guerre noir", "Raptor razzashi rapide"},
        {"Bride d'\195\169talon blanc", "Bride d'\195\169talon noir", "Bride de Palomino", "Bride de pinto", "Bride de jument alezane", "Bride de cheval bai", "Palefroi bai rapide", "Palefroi blanc rapide", "Palomino rapide"},
        {"R\195\170nes de destrier de la mort", "Cheval de guerre squelette rouge", "Cheval de guerre squelette vert", "Cheval de guerre squelette violet", "Cheval squelette bai", "Cheval squelette bleu", "Cheval squelette rouge"},
        {"Cor du loup redoutable", "Cor du loup des bois rapide", "Cor du loup gris rapide", "Corne du loup arctique", "Corne du loup sauvage"},
        {"R\195\170nes de sabre-de-givre ray\195\169", "R\195\170nes de sabre-de-givre mouchet\195\169", "R\195\170nes de sabre-de-givre rapide", "R\195\170nes de sabre-de-brume rapide", "R\195\170nes de sabre-temp\195\170te rapide"},
        {"Cor du hurleur Loup-de-givre"},
        {"Faucon-p\195\169r\195\169grin noir", "Faucon-p\195\169r\195\169grin rouge", "Faucon-p\195\169r\195\169grin bleu" ,"Faucon-p\195\169r\195\169grin violet"},
        {"Faucon-p\195\169r\195\169grin violet rapide", "Faucon-p\195\169r\195\169grin rose rapide", "Faucon-p\195\169r\195\169grin vert rapide"},
        {"Elekk marron", "Elekk violet", "Elekk gris", "Grand elekk bleu", "Grand elekk vert", "Grand elekk violet"},
        {"R\195\170nes de talbuk de guerre sombre", "R\195\170nes de talbuk de guerre argent\195\169", "R\195\170nes de talbuk de guerre cobalt", "R\195\170nes de talbuk de guerre brun", "R\195\170nes de talbuk de guerre blanc"},
        {"R\195\170nes de talbuk de monte sombre", "R\195\170nes de talbuk de monte brun", "R\195\170nes de talbuk de monte argent\195\169", "R\195\170nes de talbuk de monte cobalt", "R\195\170nes de talbuk de monte blanc"},
        {"Griffon d'\195\169b\195\168ne", "Griffon dor\195\169", "Griffon neigeux", "Griffon bleu rapide", "Griffon vert rapide", "Griffon violet rapide", "Coursier du vent violet rapide"},
        {"Coursier de vent fauve", "Coursier de vent vert", "Coursier de vent bleu", "Coursier de vent violet rapide", "Coursier de vent jaune rapide", "Coursier de vent rouge rapide", "Coursier de vent vert rapide"},
        {"Raie du N\195\169ant bleue", "Raie du N\195\169ant verte", "Raie du N\195\169ant rouge", "Raie du N\195\169ant violette", "Raie du N\195\169ant argent\195\169e"}, 
        {"R\195\170nes de cheval de guerre embras\195\169"},
        {"R\195\170nes du seigneur corbeau"},
        {"R\195\170nes de drake de l'Aile-du-N\195\169ant viride", "R\195\170nes de drake de l'Aile-du-N\195\169ant rapide", "R\195\170nes de drake de l'Aile-du-N\195\169ant azur", "R\195\170nes de drake de l'Aile-du-N\195\169ant cobalt", "R\195\170nes de drake de l'Aile-du-N\195\169ant onyx", "R\195\170nes de drake de l'Aile-du-N\195\169ant violet", "R\195\170nes de drake de l'Aile-du-N\195\169ant pourpre"}, 
        {"Hippogriffe de guerre c\195\169narien"},
		};
    
    MOUNT_SPEED = "Augmente la vitesse de (%d+)%%.";
		
	MOUNT_PREFIX = {"R\195\170nes de ", "Sifflet du ", "Corne du ", "Cor du ", "Bride de ", "Bride d'"};
    
    QIRAJ_MOUNT = {"Cristal de r\195\169sonance qiraji jaune",
        "Cristal de r\195\169sonance qiraji rouge",
        "Cristal de r\195\169sonance qiraji vert",
        "Cristal de r\195\169sonance qiraji bleu",
        "Cristal de r\195\169sonance qiraji noir",
         };
end
