--[[

ARL-Inscription.lua

Inscription data for all of AckisRecipeList

$Date: 2008-08-02 04:09:56 -0400 (Sat, 02 Aug 2008) $
$Rev: 79642 $

]]--

local L			= LibStub("AceLocale-3.0"):GetLocale("Ackis Recipe List")

local addon = AckisRecipeList

function addon:InitInscription()

end
