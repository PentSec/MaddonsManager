function Broodje_CheckStats(isupdate)
if isupdate == 0 then
SpellBookFrame:Show();
end
usable, nomana = IsUsableSpell("Conjure Food");
usable2, nomana2 = IsUsableSpell("Conjure Water");
usable3, nomana3 = IsUsableSpell("Conjure Refreshment");
usable4, nomana4 = IsUsableSpell("Ritual of Refreshment");
usable5, nomana5 = IsUsableSpell("Conjure Mana Gem");
if isupdate == 0 then
SpellBookFrame:Hide();
end
if usable == 1 then
Frame1ButtonFoodBuff:Enable();
else
Frame1ButtonFoodBuff:Disable();
end
if usable2 == 1 then
Frame1ButtonDrinkBuff:Enable();
else
Frame1ButtonDrinkBuff:Disable();
end
if usable3 == 1 then
Frame1ButtonRefreshBuff:Enable();
else
Frame1ButtonRefreshBuff:Disable();
end
if usable4 == 1 then
Frame1ButtonTableBuff:Enable();
else
Frame1ButtonTableBuff:Disable();
end
if usable5 == 1 then
Frame1ButtonManaGemBuff:Enable();
else
Frame1ButtonManaGemBuff:Disable();
end
end









