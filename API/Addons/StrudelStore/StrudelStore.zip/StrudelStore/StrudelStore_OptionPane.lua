function Strudeloptionpanel_OnLoad(strudelpanel)
        createdownrankfooddropdown();
        createdownrankdrinkdropdown();
        createdownrankrefreshdropdown();
		
		Optietitel:SetFont("Fonts\\FRIZQT__.TTF", 18, "THICKOUTLINE");
		Optietitel:SetTextColor( 0,0.56,0.76,1 ) ;
		DownRankingFood:SetFont("Fonts\\FRIZQT__.TTF", 10, "THICKOUTLINE");
		DownRankingDrink:SetFont("Fonts\\FRIZQT__.TTF", 10, "THICKOUTLINE");
		DownRankingRefresh:SetFont("Fonts\\FRIZQT__.TTF", 10, "THICKOUTLINE");
		LayoutSettingSlider:ClearAllPoints()
		LayoutSettingSlider:SetPoint("CENTER", strudelpanel, "CENTER", -69, 80)
		LayoutSettingSlider:SetMinMaxValues(0.25, 1)
		LayoutSettingSlider:SetValue(SliderOpacity);
		StrudelMainFrame:SetAlpha(SliderOpacity);
		getglobal(LayoutSettingSlider:GetName() .. 'Low'):SetText('0.25');
		getglobal(LayoutSettingSlider:GetName() .. 'High'):SetText('1');
		getglobal(LayoutSettingSlider:GetName() .. 'Text'):SetText('Opacity');
		LayoutSettingSlider:Show();
		getglobal(StrudelStoreOptionFrameCheckButton:GetName() .. "Text"):SetText("Show on login");
		getglobal(StrudelStoreOptionFrameMinimapCheckButton:GetName() .. "Text"):SetText("Show minimap button");
		getglobal(StrudelStoreOptionFrameTab2CheckButton:GetName() .. "Text"):SetText("Show Portal Tab");
		getglobal(StrudelStoreOptionFrameTab3CheckButton:GetName() .. "Text"):SetText("Show Teleport Tab");
        strudelpanel.name = "StrudelStore " .. GetAddOnMetadata("StrudelStore", "Version");
        strudelpanel.okay = function (self) Broodje_OptionsOk(); end;
		strudelpanel.default = function (self) Broodje_SetDefaults(); end;
		strudelpanel.cancel = function (self) Broodje_CancelSettings(); end;
		
        -- Add the panel to the Interface Options
        --
        InterfaceOptions_AddCategory(strudelpanel);
    end
function Opacity_Update()
SliderOpacity = LayoutSettingSlider:GetValue();
StrudelMainFrame:SetAlpha(SliderOpacity);
end
function Tab_UpdateHide(tabnumber)
if tabnumber == 1 then
StrudelMainFrameTab1:Hide();
end
if tabnumber == 2 then
StrudelStoreOptionFrameTab2CheckButton:SetChecked(false);
StrudelMainFrameTab2:Hide();
end
if tabnumber == 3 then
StrudelStoreOptionFrameTab3CheckButton:SetChecked(false);
StrudelMainFrameTab3:Hide();
end
end
function Tab_UpdateShow(tabnumber)
if tabnumber == 1 then
StrudelMainFrameTab1:Show();
end
if tabnumber == 2 then
StrudelStoreOptionFrameTab2CheckButton:SetChecked(true);
StrudelMainFrameTab2:Show();
end
if tabnumber == 3 then
StrudelStoreOptionFrameTab3CheckButton:SetChecked(true);
StrudelMainFrameTab3:Show();
end
end
function createdownrankfooddropdown()
if not DropDownMenuFood then
   CreateFrame("Frame", "DropDownMenuFood", StrudelStoreOptionFrame, "UIDropDownMenuTemplate")
end

DropDownMenuFood:ClearAllPoints()
DropDownMenuFood:SetPoint("LEFT", 200, 30)
DropDownMenuFood:Show()

local items = {
   "Highest Available",
   "Rank 1 (Level required to eat: 1) ",
   "Rank 2 (Level required to eat: 5) ",
   "Rank 3 (Level required to eat: 15) ",
   "Rank 4 (Level required to eat: 25) ",
   "Rank 5 (Level required to eat: 35) ",
   "Rank 6 (Level required to eat: 45) ",
   "Rank 7 (Level required to eat: 55) ",
   "Rank 8 (Level required to eat: 65) "
}

local function OnClick(self)
   UIDropDownMenu_SetSelectedID(DropDownMenuFood, self:GetID())
   setFoodRank(self:GetID())
end


local function initialize(self, level)
   local info = UIDropDownMenu_CreateInfo()
   for k,v in pairs(items) do
      info = UIDropDownMenu_CreateInfo()
      info.text = v
      info.value = v
      info.func = OnClick
      UIDropDownMenu_AddButton(info, level)
   end
end


UIDropDownMenu_Initialize(DropDownMenuFood, initialize)
UIDropDownMenu_SetWidth(DropDownMenuFood, 100);
UIDropDownMenu_SetButtonWidth(DropDownMenuFood, 70)
UIDropDownMenu_SetSelectedID(DropDownMenuFood, 1)
UIDropDownMenu_JustifyText(DropDownMenuFood, "LEFT")
end

function createdownrankdrinkdropdown()
if not DropDownMenuDrink then
   CreateFrame("Frame", "DropDownMenuDrink", StrudelStoreOptionFrame, "UIDropDownMenuTemplate")
end

DropDownMenuDrink:ClearAllPoints()
DropDownMenuDrink:SetPoint("LEFT", 200, 0)
DropDownMenuDrink:Show()

local items = {
   "Highest Available",
   "Rank 1 (Level required to drink: 1)",
   "Rank 2 (Level required to drink: 5)",
   "Rank 3 (Level required to drink: 15)",
   "Rank 4 (Level required to drink: 25)",
   "Rank 5 (Level required to drink: 35)",
   "Rank 6 (Level required to drink: 45)",
   "Rank 7 (Level required to drink: 55)",
   "Rank 8 (Level required to drink: 60)",
   "Rank 9 (Level required to drink: 65)"
}

local function OnClick(self)
   UIDropDownMenu_SetSelectedID(DropDownMenuDrink, self:GetID())
   setDrinkRank(self:GetID())
end

local function initialize(self, level)
   local info = UIDropDownMenu_CreateInfo()
   for k,v in pairs(items) do
      info = UIDropDownMenu_CreateInfo()
      info.text = v
      info.value = v
      info.func = OnClick
      UIDropDownMenu_AddButton(info, level)
   end
end


UIDropDownMenu_Initialize(DropDownMenuDrink, initialize)
UIDropDownMenu_SetWidth(DropDownMenuDrink, 100);
UIDropDownMenu_SetButtonWidth(DropDownMenuDrink, 70)
UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 1)
UIDropDownMenu_JustifyText(DropDownMenuDrink, "LEFT")
end

function createdownrankrefreshdropdown()
if not DropDownMenuRefresh then
   CreateFrame("Frame", "DropDownMenuRefresh", StrudelStoreOptionFrame, "UIDropDownMenuTemplate")
end

DropDownMenuRefresh:ClearAllPoints()
DropDownMenuRefresh:SetPoint("LEFT", 200, -30)
DropDownMenuRefresh:Show()

local items = {
   "Highest Available",
   "Rank 1 (Level required to consume: 74)",
   "Rank 2 (Level required to consume: 80)",
}

local function OnClick(self)
   UIDropDownMenu_SetSelectedID(DropDownMenuRefresh, self:GetID())
   setRefreshRank(self:GetID())
end

local function initialize(self, level)
   local info = UIDropDownMenu_CreateInfo()
   for k,v in pairs(items) do
      info = UIDropDownMenu_CreateInfo()
      info.text = v
      info.value = v
      info.func = OnClick
      UIDropDownMenu_AddButton(info, level)
   end
end


UIDropDownMenu_Initialize(DropDownMenuRefresh, initialize)
UIDropDownMenu_SetWidth(DropDownMenuRefresh, 100);
UIDropDownMenu_SetButtonWidth(DropDownMenuRefresh, 70)
UIDropDownMenu_SetSelectedID(DropDownMenuRefresh, 1)
UIDropDownMenu_JustifyText(DropDownMenuRefresh, "LEFT")
end
function setFoodRank(idselector)
    
   if idselector == 1 then
   Frame1ButtonFoodBuff:SetAttribute("spell","Conjure Food")
   FoodRank = 1;
   end
   if idselector == 2 then
   if IsUsableSpell("Conjure Food(Rank 1)") == 1 then
   Frame1ButtonFoodBuff:SetAttribute("spell","Conjure Food(Rank 1)")
   FoodRank = 2;
   else
   UIDropDownMenu_SetSelectedID(DropDownMenuFood, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
   end
   if idselector == 3 then
   if IsUsableSpell("Conjure Food(Rank 2)") == 1 then
   Frame1ButtonFoodBuff:SetAttribute("spell","Conjure Food(Rank 2)")
   FoodRank = 3;
   else
   UIDropDownMenu_SetSelectedID(DropDownMenuFood, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
   end
   if idselector == 4 then
   if IsUsableSpell("Conjure Food(Rank 3)") == 1 then
   Frame1ButtonFoodBuff:SetAttribute("spell","Conjure Food(Rank 3)")
   FoodRank = 4;
   else
   UIDropDownMenu_SetSelectedID(DropDownMenuFood, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
   end
   if idselector == 5 then
   if IsUsableSpell("Conjure Food(Rank 4)") == 1 then
   Frame1ButtonFoodBuff:SetAttribute("spell","Conjure Food(Rank 4)")
   FoodRank = 5;
   else
   UIDropDownMenu_SetSelectedID(DropDownMenuFood, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
   end
   if idselector == 6 then
    if IsUsableSpell("Conjure Food(Rank 5)") == 1 then
   Frame1ButtonFoodBuff:SetAttribute("spell","Conjure Food(Rank 5)")
   FoodRank = 6;
   else
   UIDropDownMenu_SetSelectedID(DropDownMenuFood, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
   end
   if idselector == 7 then
   if IsUsableSpell("Conjure Food(Rank 6)") == 1 then
   Frame1ButtonFoodBuff:SetAttribute("spell","Conjure Food(Rank 6)")
   FoodRank = 7;
   else
   UIDropDownMenu_SetSelectedID(DropDownMenuFood, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
   end
   if idselector == 8 then
   if IsUsableSpell("Conjure Food(Rank 7)") == 1 then
   Frame1ButtonFoodBuff:SetAttribute("spell","Conjure Food(Rank 7)")
   FoodRank = 8;
    else
   UIDropDownMenu_SetSelectedID(DropDownMenuFood, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
   end
   if idselector == 9 then
   if IsUsableSpell("Conjure Food(Rank 8)") == 1 then
   Frame1ButtonFoodBuff:SetAttribute("spell","Conjure Food(Rank 8)")
   FoodRank = 9;
    else
   UIDropDownMenu_SetSelectedID(DropDownMenuFood, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
  end
  end
  
function setDrinkRank(idselector)
   if idselector == 1 then
   Frame1ButtonDrinkBuff:SetAttribute("spell","Conjure Water")
   DrinkRank = 1;
   end
   if idselector == 2 then
   if IsUsableSpell("Conjure Water(Rank 1)") == 1 then
   Frame1ButtonDrinkBuff:SetAttribute("spell","Conjure Water(Rank 1)")
   DrinkRank = 2;
   else
   print("[StrudelStore] You haven't learned this rank yet.");
   UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 1)
   end
   end
   if idselector == 3 then
   if IsUsableSpell("Conjure Water(Rank 2)") == 1 then
   Frame1ButtonDrinkBuff:SetAttribute("spell","Conjure Water(Rank 2)")
   DrinkRank = 3;
   else
   print("[StrudelStore] You haven't learned this rank yet.");
   UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 1)
   end
   end
   if idselector == 4 then
   if IsUsableSpell("Conjure Water(Rank 3)") == 1 then
   Frame1ButtonDrinkBuff:SetAttribute("spell","Conjure Water(Rank 3)")
   DrinkRank = 4;
   else
   UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
   end
   if idselector == 5 then
   if IsUsableSpell("Conjure Water(Rank 4)") == 1 then
   Frame1ButtonDrinkBuff:SetAttribute("spell","Conjure Water(Rank 4)")
   DrinkRank = 5;
   else
   UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
   end
   if idselector == 6 then
    if IsUsableSpell("Conjure Water(Rank 5)") == 1 then
   Frame1ButtonDrinkBuff:SetAttribute("spell","Conjure Water(Rank 5)")
   DrinkRank = 6;
   else
   UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
   end
   if idselector == 7 then
   if IsUsableSpell("Conjure Water(Rank 6)") == 1 then
   Frame1ButtonDrinkBuff:SetAttribute("spell","Conjure Water(Rank 6)")
   DrinkRank = 7;
   else
   UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
   end
   if idselector == 8 then
   if IsUsableSpell("Conjure Water(Rank 7)") == 1 then
   Frame1ButtonDrinkBuff:SetAttribute("spell","Conjure Water(Rank 7)")
   DrinkRank = 8;
    else
   UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
   end
   if idselector == 9 then
   if IsUsableSpell("Conjure Water(Rank 8)") == 1 then
   Frame1ButtonDrinkBuff:SetAttribute("spell","Conjure Water(Rank 8)")
   DrinkRank = 9;
    else
   UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
  end
  if idselector == 10 then
   if IsUsableSpell("Conjure Water(Rank 9)") == 1 then
   Frame1ButtonDrinkBuff:SetAttribute("spell","Conjure Water(Rank 9)")
   DrinkRank = 10;
    else
   UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 1)
   print("[StrudelStore] You haven't learned this rank yet.");
   end
  end
  end
  
  
  function setRefreshRank(idselector)
   if idselector == 1 then
   Frame1ButtonRefreshBuff:SetAttribute("spell","Conjure Refreshment")
   RefreshRank = 1;
   end
   if idselector == 2 then
   if IsUsableSpell("Conjure Refreshment(Rank 1)") == 1 then
   Frame1ButtonRefreshBuff:SetAttribute("spell","Conjure Refreshment(Rank 1)")
   RefreshRank = 2;
   else
   print("[StrudelStore] You haven't learned this rank yet.");
   UIDropDownMenu_SetSelectedID(DropDownMenuRefresh, 1)
   end
   end
   if idselector == 3 then
   if IsUsableSpell("Conjure Refreshment(Rank 2)") == 1 then
   Frame1ButtonRefreshBuff:SetAttribute("spell","Conjure Refreshment(Rank 2)")
   RefreshRank = 3;
   else
   print("[StrudelStore] You haven't learned this rank yet.");
   UIDropDownMenu_SetSelectedID(DropDownMenuRefresh, 1)
   end
   end
   end
   
function updateDropDownFood()
if FoodRank == 1 then
UIDropDownMenu_SetSelectedID(DropDownMenuFood, 1);
end
if FoodRank == 2 then
UIDropDownMenu_SetSelectedID(DropDownMenuFood, 2);
end
if FoodRank == 3 then
UIDropDownMenu_SetSelectedID(DropDownMenuFood, 3);
end
if FoodRank == 4 then
UIDropDownMenu_SetSelectedID(DropDownMenuFood, 4);
end
if FoodRank == 5 then
UIDropDownMenu_SetSelectedID(DropDownMenuFood, 5);
end
if FoodRank == 6 then
UIDropDownMenu_SetSelectedID(DropDownMenuFood, 6);
end
if FoodRank == 7 then
UIDropDownMenu_SetSelectedID(DropDownMenuFood, 7);
end
if FoodRank == 8 then
UIDropDownMenu_SetSelectedID(DropDownMenuFood, 8);
end
if FoodRank == 9 then
UIDropDownMenu_SetSelectedID(DropDownMenuFood, 9);
end
end

function updateDropDownDrink()
if DrinkRank == 1 then
UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 1); end
if DrinkRank == 2 then
UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 2); end
if DrinkRank == 3 then
UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 3); end
if DrinkRank == 4 then
UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 4); end
if DrinkRank == 5 then
UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 5); end
if DrinkRank == 6 then
UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 6); end
if DrinkRank == 7 then
UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 7); end
if DrinkRank == 8 then
UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 8); end
if DrinkRank == 9 then
UIDropDownMenu_SetSelectedID(DropDownMenuDrink, 9); end
end

function updateDropDownRefresh()
if RefreshRank == 1 then
UIDropDownMenu_SetSelectedID(DropDownMenuRefresh, 1);
 end
if RefreshRank == 2 then
UIDropDownMenu_SetSelectedID(DropDownMenuRefresh, 2); 
end
if RefreshRank == 3 then
UIDropDownMenu_SetSelectedID(DropDownMenuRefresh, 3);
end
end

	
	
