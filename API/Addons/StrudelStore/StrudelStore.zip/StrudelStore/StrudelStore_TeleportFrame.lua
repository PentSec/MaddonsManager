function Broodje_CheckTeleportFaction()
teleportcast1 = CreateFrame("Button", "Teleport1button", FrameTeleport,"OptionsButtonTemplate,SecureActionButtonTemplate");
teleportcast2 = CreateFrame("Button", "Teleport2button", FrameTeleport,"OptionsButtonTemplate,SecureActionButtonTemplate");
teleportcast3 = CreateFrame("Button", "Teleport3button", FrameTeleport,"OptionsButtonTemplate,SecureActionButtonTemplate");
teleportcast4 = CreateFrame("Button", "Teleport4button", FrameTeleport,"OptionsButtonTemplate,SecureActionButtonTemplate");
teleportcast5 = CreateFrame("Button", "Teleport5button", FrameTeleport,"OptionsButtonTemplate,SecureActionButtonTemplate");
teleportcast6 = CreateFrame("Button", "Teleport6button", FrameTeleport,"OptionsButtonTemplate,SecureActionButtonTemplate");
teleportcast7 = CreateFrame("Button", "Teleport7button", FrameTeleport,"OptionsButtonTemplate,SecureActionButtonTemplate");
teleportcast1:SetPoint("CENTER",FrameTeleport,"CENTER",0,60);
teleportcast1:SetAttribute("type", "spell");
teleportcast2:SetPoint("CENTER",FrameTeleport,"CENTER",0,40);
teleportcast2:SetAttribute("type", "spell");
teleportcast3:SetPoint("CENTER",FrameTeleport,"CENTER",0,20);
teleportcast3:SetAttribute("type", "spell");
teleportcast4:SetPoint("CENTER",FrameTeleport,"CENTER",0,0);
teleportcast4:SetAttribute("type", "spell");
teleportcast5:SetPoint("CENTER",FrameTeleport,"CENTER",0,-40);
teleportcast5:SetAttribute("type", "spell");
teleportcast6:SetPoint("CENTER",FrameTeleport,"CENTER",0,-60);
teleportcast6:SetAttribute("type", "spell");
teleportcast7:SetPoint("CENTER",FrameTeleport,"CENTER",0,-20);
teleportcast7:SetAttribute("type", "spell");
englishFaction, localizedFaction = UnitFactionGroup("player");
if englishFaction == "Alliance" then
teleportcast1:SetAttribute("spell","Teleport: Stormwind");
teleportcast1:SetText("Stormwind");
teleportcast2:SetAttribute("spell","Teleport: Ironforge");
teleportcast2:SetText("Ironforge");
teleportcast3:SetAttribute("spell","Teleport: Darnassus");
teleportcast3:SetText("Darnassus");
teleportcast4:SetAttribute("spell","Teleport: Exodar");
teleportcast4:SetText("Exodar");
teleportcast5:SetAttribute("spell","Teleport: Shattrath");
teleportcast5:SetText("Shattrath");
teleportcast6:SetAttribute("spell","Teleport: Dalaran");
teleportcast6:SetText("Dalaran");
teleportcast7:SetAttribute("spell","Teleport: Theramore");
teleportcast7:SetText("Theramore");
elseif englishFaction == "Horde" then
teleportcast1:SetAttribute("spell","Teleport: Orgrimmar");
teleportcast1:SetText("Orgrimmar");
teleportcast2:SetAttribute("spell","Teleport: Undercity");
teleportcast2:SetText("Undercity");
teleportcast3:SetAttribute("spell","Teleport: Thunder Bluff");
teleportcast3:SetText("Thunder Bluff");
teleportcast4:SetAttribute("spell","Teleport: Silvermoon");
teleportcast4:SetText("Silvermoon");
teleportcast5:SetAttribute("spell","Teleport: Shattrath");
teleportcast5:SetText("Shattrath");
teleportcast6:SetAttribute("spell","Teleport: Dalaran");
teleportcast6:SetText("Dalaran");
teleportcast7:SetAttribute("spell","Teleport: Stonard");
teleportcast7:SetText("Stonard");
end
end

function Teleport_availablecheck(isupdate)
englishFaction, localizedFaction = UnitFactionGroup("player");

if isupdate == 0 then
SpellBookFrame:Hide();
end
usable, nomana = IsUsableSpell("Teleport: Shattrath");
usable2, nomana2 = IsUsableSpell("Teleport: Dalaran");
if englishFaction == "Alliance" then
usable3, nomana3 = IsUsableSpell("Teleport: Stormwind");
usable4, nomana4 = IsUsableSpell("Teleport: Ironforge");
usable5, nomana5 = IsUsableSpell("Teleport: Darnassus");
usable6, nomana6 = IsUsableSpell("Teleport: Exodar");
usable7, nomana7 = IsUsableSpell("Teleport: Theramore");
elseif englishFaction == "Horde" then
usable3, nomana3 = IsUsableSpell("Teleport: Orgrimmar");
usable4, nomana4 = IsUsableSpell("Teleport: Undercity");
usable5, nomana5 = IsUsableSpell("Teleport: Thunder Bluff");
usable6, nomana6 = IsUsableSpell("Teleport: Silvermoon");
usable7, nomana7 = IsUsableSpell("Teleport: Stonard");
end
if isupdate == 0 then
SpellBookFrame:Hide();
end
if usable == 1 then
teleportcast5:Enable();
else
teleportcast5:Disable();
end
if usable2 == 1 then
teleportcast6:Enable();
else
teleportcast6:Disable();
end
if usable3 == 1 then
teleportcast1:Enable();
else
teleportcast1:Disable();
end
if usable4 == 1 then
teleportcast2:Enable();
else
teleportcast2:Disable();
end
if usable5 == 1 then
teleportcast3:Enable();
else
teleportcast3:Disable();
end
if usable6 == 1 then
teleportcast4:Enable();
else
teleportcast4:Disable();
end
if usable7 == 1 then
teleportcast7:Enable();
else
teleportcast7:Disable();
end
end