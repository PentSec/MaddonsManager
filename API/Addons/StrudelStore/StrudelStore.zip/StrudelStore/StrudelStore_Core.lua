﻿Broodje_Settings = {
	MinimapPos = 45	
	
}

	LoadOnStart = 1;
	LoadMinimapButton = 1;
	Layout = 1;
	SliderOpacity = 1;
	ShowTab1 = 1;
	ShowTab2 = 1;
	ShowTab3 = 1;
	FoodRank = 1;
	DrinkRank = 1;
	RefreshRank = 1;
	
function maakvoedsel()
SortWho(name);
end

function Broodje_MinimapButton_Reposition()
	Broodje_MinimapButton:SetPoint("TOPLEFT","Minimap","TOPLEFT",52-(80*cos(Broodje_Settings.MinimapPos)),(80*sin(Broodje_Settings.MinimapPos))-52)
end

-- Only while the button is dragged this is called every frame
function Broodje_MinimapButton_DraggingFrame_OnUpdate()

	local xpos,ypos = GetCursorPosition()
	local xmin,ymin = Minimap:GetLeft(), Minimap:GetBottom()

	xpos = xmin-xpos/UIParent:GetScale()+70 -- get coordinates as differences from the center of the minimap
	ypos = ypos/UIParent:GetScale()-ymin-70

	Broodje_Settings.MinimapPos = math.deg(math.atan2(ypos,xpos)) -- save the degrees we are relative to the minimap center
	Broodje_MinimapButton_Reposition() -- move the button
end

-- Put your code that you want on a minimap button click here.  arg1="LeftButton", "RightButton", etc
function Broodje_MinimapButton_OnClick()
	if StrudelMainFrame:IsVisible() == 1 then
	StrudelMainFrame:Hide();
	else 
	StrudelMainFrame:Show();
	Frame1:Show();
	FramePortal:Hide();
	FrameTeleport:Hide();
	end
end


function Broodje_StartupCheck()
if LoadOnStart == 1 then 
StrudelStoreOptionFrameCheckButton:SetChecked(true);
StrudelMainFrame:Show();
elseif LoadOnStart == 0 then
StrudelStoreOptionFrameCheckButton:SetChecked(false);
StrudelMainFrame:Hide();
end
if LoadMinimapButton == 1 then
StrudelStoreOptionFrameMinimapCheckButton:SetChecked(true);
Broodje_MinimapButton:Show();
elseif LoadMinimapButton == 0 then
StrudelStoreOptionFrameMinimapCheckButton:SetChecked(false);
Broodje_MinimapButton:Hide();
end
LayoutSettingSlider:SetValue(SliderOpacity);
StrudelMainFrame:SetAlpha(SliderOpacity);
end

function MinimapCheckHiddenButton()
if LoadMinimapButton == 1 then
StrudelStoreOptionFrameMinimapCheckButton:SetChecked(true);
Broodje_MinimapButton:Show();
elseif LoadMinimapButton == 0 then
StrudelStoreOptionFrameMinimapCheckButton:SetChecked(false);
Broodje_MinimapButton:Hide();
end
end

function Broodje_StartupCheck2()
if LoadOnStart == 1 then 
StrudelStoreOptionFrameCheckButton:SetChecked(true);
elseif LoadOnStart == 0 then
StrudelStoreOptionFrameCheckButton:SetChecked(false);
end
if LoadMinimapButton == 1 then
StrudelStoreOptionFrameMinimapCheckButton:SetChecked(true);
elseif LoadMinimapButton == 0 then
StrudelStoreOptionFrameMinimapCheckButton:SetChecked(false);
end
end

function Broodje_GetStartupSetting()
if StrudelStoreOptionFrameCheckButton:GetChecked() then
LoadOnStart = 1;
else
LoadOnStart = 0;
end
if StrudelStoreOptionFrameMinimapCheckButton:GetChecked() then
LoadMinimapButton = 1;
else
LoadMinimapButton = 0;
end
end

function Broodje_OptionsOk()
Broodje_GetStartupSetting(); 
MinimapCheckHiddenButton(); 
Check_TabFrame();
end

function Broodje_CancelSettings()
Broodje_StartupCheck2();
end

function Broodje_SetDefaults()
StrudelStoreOptionFrameCheckButton:SetChecked(true); 
LoadOnStart = 1;
LoadMinimapButton = 1;
Layout = 1;
SliderOpacity = 1;
ShowTab1 = 1
ShowTab2 = 1
ShowTab3 = 1
end
function StrudelRankLoading()
		setFoodRank(FoodRank);
	    setDrinkRank(DrinkRank);
		setRefreshRank(RefreshRank);
end
function OpenStrudelOptionPanel()
		InterfaceOptionsFrame_OpenToCategory("StrudelStore " .. GetAddOnMetadata("StrudelStore", "Version"));
		StrudelMainFrame:Hide();
end
SLASH_STRUDELSTORE1, SLASH_STRUDELSTORE2 = '/strudelstore', '/strudel';
function SlashCmdList.STRUDELSTORE(msg, editbox)
 if msg == 'show' then
  StrudelMainFrame:Show();
  Frame1:Show();
  FramePortal:Hide();
 elseif msg == 'hide' then
StrudelMainFrame:Hide();
 elseif msg == 'options' then
 OpenStrudelOptionPanel();
 else
 DEFAULT_CHAT_FRAME:AddMessage("Strudelstore " .. GetAddOnMetadata("StrudelStore", "Version"));
 DEFAULT_CHAT_FRAME:AddMessage("The following commands are available:");
 DEFAULT_CHAT_FRAME:AddMessage("Syntax:  /Strudelstore [command] or /Strudel [command]");
 DEFAULT_CHAT_FRAME:AddMessage("Options  --Shows the option pane");
 DEFAULT_CHAT_FRAME:AddMessage("Show  --Shows the main pane");
 DEFAULT_CHAT_FRAME:AddMessage("Hide  --Hides the main pane");
 end

end
function ChangeStrudelLayout(layout)
if layout == 0 then 
StrudelMainFrame:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", 
                                            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", 
                                            tile = true, tileSize = 16, edgeSize = 32, 
                                            insets = { left = 4, right = 4, top = 4, bottom = 4 }});
elseif layout == 1 then
StrudelMainFrame:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
                                            edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
                                            tile = true, tileSize = 16, edgeSize = 16, 
                                            insets = { left = 4, right = 4, top = 4, bottom = 4 }});
elseif layout == 2 then
StrudelMainFrame:SetBackdrop({bgFile = "Interface\\AddOns\\StrudelStore\\image\\parchment", 
                                            edgeFile = "Interface/DialogFrame/UI-DialogBox-Border"});
end
end
function StrudelCheckedTabs()
if ShowTab2 == 0 then
StrudelStoreOptionFrameTab2CheckButton:SetChecked(false);
end
if ShowTab3 == 0 then
StrudelStoreOptionFrameTab3CheckButton:SetChecked(false);
end
end


function Check_TabFrame()
isChecked = StrudelStoreOptionFrameTab2CheckButton:GetChecked()
isChecked2 = StrudelStoreOptionFrameTab3CheckButton:GetChecked()

if isChecked == 1 then
ShowTab2 = 1;
StrudelMainFrameTab2:Show();
end
if isChecked == nil then
StrudelMainFrameTab2:Hide();
ShowTab2 = 0;
end
if isChecked2 == 1 then
StrudelMainFrameTab3:Show();
ShowTab3 = 1;
end
if isChecked2 == nil then
StrudelMainFrameTab3:Hide();
ShowTab3 = 0;
end
end

