function Broodje_CheckPortalFaction()
portalcast1 = CreateFrame("Button", "Portal1button", FramePortal,"OptionsButtonTemplate,SecureActionButtonTemplate");
portalcast2 = CreateFrame("Button", "Portal2button", FramePortal,"OptionsButtonTemplate,SecureActionButtonTemplate");
portalcast3 = CreateFrame("Button", "Portal3button", FramePortal,"OptionsButtonTemplate,SecureActionButtonTemplate");
portalcast4 = CreateFrame("Button", "Portal4button", FramePortal,"OptionsButtonTemplate,SecureActionButtonTemplate");
portalcast5 = CreateFrame("Button", "Portal5button", FramePortal,"OptionsButtonTemplate,SecureActionButtonTemplate");
portalcast6 = CreateFrame("Button", "Portal6button", FramePortal,"OptionsButtonTemplate,SecureActionButtonTemplate");
portalcast7 = CreateFrame("Button", "Portal7button", FramePortal,"OptionsButtonTemplate,SecureActionButtonTemplate");
portalcast1:SetPoint("CENTER",FramePortal,"CENTER",0,60);
portalcast1:SetAttribute("type", "spell");
portalcast2:SetPoint("CENTER",FramePortal,"CENTER",0,40);
portalcast2:SetAttribute("type", "spell");
portalcast3:SetPoint("CENTER",FramePortal,"CENTER",0,20);
portalcast3:SetAttribute("type", "spell");
portalcast4:SetPoint("CENTER",FramePortal,"CENTER",0,0);
portalcast4:SetAttribute("type", "spell");
portalcast5:SetPoint("CENTER",FramePortal,"CENTER",0,-40);
portalcast5:SetAttribute("type", "spell");
portalcast6:SetPoint("CENTER",FramePortal,"CENTER",0,-60);
portalcast6:SetAttribute("type", "spell");
portalcast7:SetPoint("CENTER",FramePortal,"CENTER",0,-20);
portalcast7:SetAttribute("type", "spell");
englishFaction, localizedFaction = UnitFactionGroup("player");
if englishFaction == "Alliance" then
portalcast1:SetAttribute("spell","Portal: Stormwind");
portalcast1:SetText("Stormwind");
portalcast2:SetAttribute("spell","Portal: Ironforge");
portalcast2:SetText("Ironforge");
portalcast3:SetAttribute("spell","Portal: Darnassus");
portalcast3:SetText("Darnassus");
portalcast4:SetAttribute("spell","Portal: Exodar");
portalcast4:SetText("Exodar");
portalcast5:SetAttribute("spell","Portal: Shattrath");
portalcast5:SetText("Shattrath");
portalcast6:SetAttribute("spell","Portal: Dalaran");
portalcast6:SetText("Dalaran");
portalcast7:SetAttribute("spell","Portal: Theramore");
portalcast7:SetText("Theramore");
elseif englishFaction == "Horde" then
portalcast1:SetAttribute("spell","Portal: Orgrimmar");
portalcast1:SetText("Orgrimmar");
portalcast2:SetAttribute("spell","Portal: Undercity");
portalcast2:SetText("Undercity");
portalcast3:SetAttribute("spell","Portal: Thunder Bluff");
portalcast3:SetText("Thunder Bluff");
portalcast4:SetAttribute("spell","Portal: Silvermoon");
portalcast4:SetText("Silvermoon");
portalcast5:SetAttribute("spell","Portal: Shattrath");
portalcast5:SetText("Shattrath");
portalcast6:SetAttribute("spell","Portal: Dalaran");
portalcast6:SetText("Dalaran");
portalcast7:SetAttribute("spell","Portal: Stonard");
portalcast7:SetText("Stonard");
end
end

function Portal_availablecheck(isupdate)
englishFaction, localizedFaction = UnitFactionGroup("player");
if isupdate == 0 then
SpellBookFrame:Show();
end
local usable, nomana = IsUsableSpell("Portal: Shattrath");
local usable2, nomana2 = IsUsableSpell("Portal: Dalaran");
if englishFaction == "Alliance" then
usable3, nomana3 = IsUsableSpell("Portal: Stormwind");
usable4, nomana4 = IsUsableSpell("Portal: Ironforge");
usable5, nomana5 = IsUsableSpell("Portal: Darnassus");
usable6, nomana6 = IsUsableSpell("Portal: Exodar");
usable7, nomana7 = IsUsableSpell("Portal: Theramore");
elseif englishFaction == "Horde" then
usable3, nomana3 = IsUsableSpell("Portal: Orgrimmar");
usable4, nomana4 = IsUsableSpell("Portal: Undercity");
usable5, nomana5 = IsUsableSpell("Portal: Thunder Bluff");
usable6, nomana6 = IsUsableSpell("Portal: Silvermoon");
usable7, nomana7 = IsUsableSpell("Portal: Stonard");
end
if isupdate == 0 then
SpellBookFrame:Hide();
end
if usable == 1 then
portalcast5:Enable();
else
portalcast5:Disable();
end
if usable2 == 1 then
portalcast6:Enable();
else
portalcast6:Disable();
end
if usable3 == 1 then
portalcast1:Enable();
else
portalcast1:Disable();
end
if usable4 == 1 then
portalcast2:Enable();
else
portalcast2:Disable();
end
if usable5 == 1 then
portalcast3:Enable();
else
portalcast3:Disable();
end
if usable6 == 1 then
portalcast4:Enable();
else
portalcast4:Disable();
end
if usable7 == 1 then
portalcast7:Enable();
else
portalcast7:Disable();
end
end