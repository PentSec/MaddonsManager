--[=[
	Language Localization: xxXX
	Translated by: name <email address>
]=]

if GetLocale() ~= "xxXX" then return end
local L = JPackLocale

