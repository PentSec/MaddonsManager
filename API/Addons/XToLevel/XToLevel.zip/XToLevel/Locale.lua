-- Current locale
LOCALE_CLIENT = GetLocale()

-- Allowed locales
LOCALE_SUPPORTED = { 
	enUS = true,
	frFR = true,
	deDE = true,
	esES = true,
	ruRU = "XToLevel не смогло быть нагружено. Русский клиент не поддержан."
};

LOCALE_DISPLAY = { 
	enUS = true,
	frFR = true,
	deDE = true,
	esES = true
};

LOCALE = {  }

L = { }