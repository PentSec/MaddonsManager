-- Global variables
CLASSPORTRAITS_VERSION = "4.0";
CP_Title = "ClassPortraits";

OriginalUpdate_func = nil;

function ClassPortraits_OnLoad()
	-- Set up slash commands
	SlashCmdList["CLASSPORTRAITS"] = ClassPortraits_CmdHandler;
	SLASH_CLASSPORTRAITS1 = "/cp";

	-- Register for events	
	this:RegisterEvent("ADDON_LOADED");

	--set callBack function
	OriginalUpdate_func = UnitFramePortrait_Update;
	UnitFramePortrait_Update = ClassPortraits_Update;

end

function ClassPortraits_Update(frame)
	local unit = frame.unit;
	if(unit ~= nil) then
		local _, class = UnitClass(unit);

		if(UnitIsPlayer(unit) 
		and class ~= nil 
		and frame.portrait 
		and ClassPortraits_IsEnabled(unit)) then 
			SetPortraitToTexture(frame.portrait, "Interface\\AddOns\\ClassPortraits\\Portraits\\"..class);
		else
			OriginalUpdate_func(frame);
		end
	end
end

function ClassPortraits_IsEnabled(unit)
	if(unit == "focus-target") then
		return CP_Config.Enabled_Units["focustarget"];
	elseif(	string.find(unit, "party") ~= nil) then
		return CP_Config.Enabled_Units["party"];
	else
		return CP_Config.Enabled_Units[unit];
	end

end

function ClassPortraits_UpdateAll()
    ClassPortraits_Update(PlayerFrame);
        ClassPortraits_Update(TargetFrame);
        ClassPortraits_Update(PartyMemberFrame1);
        ClassPortraits_Update(PartyMemberFrame2);
        ClassPortraits_Update(PartyMemberFrame3);
        ClassPortraits_Update(PartyMemberFrame4);
        ClassPortraits_Update(FocusFrame);
        ClassPortraits_Update(TargetofTargetFrame);
        ClassPortraits_Update(TargetofFocusFrame);
end

function ClassPortraits_Loader()
	if (CP_Config == nil) then
		--First run
		ClassPortraits_Defaults();
	elseif(CP_Config.Version < "2.0") then
		-- old saved variables version
		-- reset to defaults
		ClassPortraits_Defaults();
	end
end

function ClassPortraits_Defaults()

	-- eliminate any potential for orphaned table keys
	CP_Config = nil;
	-- do garbage collection because Lua table pointers are awesome for creating memory leaks...
	collectgarbage("collect");

	CP_Config = {
		Version = CLASSPORTRAITS_VERSION,
		Enabled_Units = {
			player = true,
			target = true,
			party = true,
			focus = true,
			targettarget = true,
			focustarget = true
		},
	}
end


function ClassPortraits_CmdHandler(param)
	if(param == "") then
		print("ClassPortraits usage:");
		print("/cp <frame>");
		print("Framenames are: player, target, focus, targetoftarget, targetoffocus, party");
	elseif(param == "player" 
		or param == "target" 
		or param == "focus" 
		or param == "party") then

		ClassPortraits_ToggleUnit(param);
	elseif(param == "targetoftarget") then
		ClassPortraits_ToggleUnit("targettarget");
	elseif(param == "targetoffocus") then
		ClassPortraits_ToggleUnit("focustarget");
	else
		print("ClassPortraits: No such frame");
	end
end

function ClassPortraits_ToggleUnit(unit)
	local enabled = CP_Config.Enabled_Units[unit];
	
	 if(enabled) then
		CP_Config.Enabled_Units[unit] = false;
	 else
		CP_Config.Enabled_Units[unit] = true;
	 end

	ClassPortraits_UpdateAll();

end

function ClassPortraits_OnEvent(event)
	if(event == "ADDON_LOADED" and arg1 == CP_Title) then
		ClassPortraits_Loader();
	end
end