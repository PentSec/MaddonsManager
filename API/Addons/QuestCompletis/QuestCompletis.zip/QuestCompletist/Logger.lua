--[[

	Quest Completist - Logger.lua
	Written by: Alistair Maxwell
	Last Updated: 08/11/2010

--]]