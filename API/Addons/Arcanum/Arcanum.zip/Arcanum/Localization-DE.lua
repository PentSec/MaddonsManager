﻿------------------------------------------------------------------------------------------------------
-- Arcanum

-- Addon pour Mage inspiré du célébre Necrosis
-- Notes-deDE: Arcanum Handles the Mage Spells and Buff.

-- Remerciements aux auteurs de Necrosis

-- Auteur Lenny415 Repris par Erina

-- Serveur:
-- Vol'jin
------------------------------------------------------------------------------------------------------

function Arcanum_Localization_Dialog_De()
    function ArcanumLocalization()
        Arcanum_Localization_Speech_De();
    end
    -- Raccourcis claviers
    BINDING_HEADER_ARCANUM_BIND = "Arcanum";
    BINDING_NAME_ACTIVATE = "Aktiviere/Deaktiviere Arcanum";
    BINDING_NAME_STEED = "Reittier";
    BINDING_NAME_FROSTARMOR = "Eisr\195\188stung";
    BINDING_NAME_MAGEARMOR = "Magische R\195\188stung";
    BINDING_NAME_FIREARMOR = "Gl\195\188hende R\195\188stung";
    BINDING_NAME_ARCANEINTELLECT = "Arkane Intelligenz";
    BINDING_NAME_ARCANEBRILLIANCE = "Arkane Brillanz";
    BINDING_NAME_AMPLIFYMAGIC = "Magie verst\195\164rken";
    BINDING_NAME_DAMPENMAGIC = "Magie d\195\164\mpfen";
    BINDING_NAME_CONJUREFOOD = "Essen herbeizaubern";
    BINDING_NAME_USEFOODWATER = "Essen & Trinken";
    BINDING_NAME_USEFOOD = "Essen";
    BINDING_NAME_CONJUREWATER = "Wasser herbeizaubern";
    BINDING_NAME_USEWATER = "Trinken";
    BINDING_NAME_CONJUREMANAGEM = "Mana Edelstein herbeizaubern";
    BINDING_NAME_USEMANAGEM = "Mana Edelstein benutzen";
    BINDING_NAME_EVOCATION = "Hervorufung";
    BINDING_NAME_TELEPORT1 = "Teleportieren 1";
    BINDING_NAME_TELEPORT2 = "Teleportieren 2";
    BINDING_NAME_TELEPORT3 = "Teleportieren 3";
    BINDING_NAME_TELEPORT4 = "Teleportieren 4";
    BINDING_NAME_TELEPORT5 = "Teleportieren 5";
	BINDING_NAME_TELEPORT6 = "Teleportieren 6";
    BINDING_NAME_TELEPORT7 = "Teleportieren 7";
	BINDING_NAME_PORTAL1 = "Portal 1";
    BINDING_NAME_PORTAL2 = "Portal 2";
    BINDING_NAME_PORTAL3 = "Portal 3";
    BINDING_NAME_PORTAL4 = "Portal 4";
    BINDING_NAME_PORTAL5 = "Portal 5";
	BINDING_NAME_PORTAL6 = "Portal 6";
	BINDING_NAME_PORTAL7 = "Portal 7";	
	BINDING_NAME_PORTAL8 = "Portal 8";	
    BINDING_NAME_WARD1 = "Feuerzauberschutz";
    BINDING_NAME_WARD2 = "Frostzauberschutz";

    ARCANUM_CONFIGURATION = {
        ["Menu1"] = "Nachrichten",
        ["MessageMenu1"] = "Spieler :",
        ["Tooltip0"] = "Kein Tooltip",
        ["Tooltip1"] = "Unvollst\195\164ndige Tooltips",
        ["Tooltip2"] = "Vollst\195\164ndige Tooltips",
        ["ChatType"] = "Nachrichten = System Nachrichten",
        ["PortalMessage"] = "Nachrichten anzeigen, wenn du ein Portal zauberst.",
        ["MountMessage"] = "Nachrichten anzeigen, wenn du ein Reittier herbeirufst.",
        ["ArcanumButtonDisplay"] = "Innerhalb der Sph\195\164re zeigen :",
        ["InsideDisplay"] = "Innerhalb der Sph\195\164re zeigen:",
        ["DisplayHearthStone"] = "Gesundheitsstein",
        ["DisplayManaGem"] = "Mana Edelstein",
        ["DisplayEvocation"] = "Hervorrufung",
        ["DisplayIceBlock"] = "Eisblock",
        ["DisplayColdSnap"] = "K\195\164lteeinbruch",
        ["DisplayIntell"] = "Intelligenz",
        ["DisplayArmor"] = "R\195\188stung",
        ["DisplayBandage"] = "Verband",
        ["Bindings"] = "Bindings",

        ["Menu2"] = "Diverses",
        ["LevelBuff"] = "Ziel abh\195\164ngig von seinem Level Buffen",
        ["EvocationLimit"] = "Mana % ab wann Hervorrufung gezaubert werden kann",
        ["ConsumeFood"] = "Verzehre Wasser/Essen startend bei",
        ["ConsumeGems"] = "Verzehre Edelsteine startend bei",
        ["RandMount"] = "Rufe ein Reittier zuf\195\164llig herbei",
        ["DeleteFood"] = "Herbeigez. Essen entfernen",
        ["DeleteWater"] = "Herbeigez. Wasser entfernen",
        ["DeleteManaGem"] = "Manasteine l\195\182\schen",

        ["Menu3"] = "Auto Einkauf von Reagenzien",
        ["ReagentSort"] = "Reagenzien in eine Tasche einsortieren",
        ["ReagentBag"] = "Reagenzien-Tasche",
        ["ReagentBuy"] = "Automatischer Einkauf",
        ["Reagent"] = "Maximale Reagenzienanzahl in den Taschen:",
        ["Powder"] = "Arkanes Pulver",
        ["Teleport"] = "Rune der Teleportation",
        ["Portal"] = "Rune der Portale",

        ["Menu4"] = "Graphische Einstellungen",
        ["Toggle"] = "Arcanum aktivieren",
        ["InterfaceVersion"] = "Arcanum mit Men\195\188s",
        ["InterfaceVersion2"] = "Arcanum ohne Men\195\188s",
        ["Lock"] = "Arcanum fixieren",
        ["IconsLock"] = "Arcanum Symbole fixieren",
        ["ArcanumRotation"] = "Arcanum drehen",
        ["ArcanumSize"] = "Gr\195\182\195\159e von Arcanum",
        ["ButtonSize"] = "Gr\195\182\195\159e der Kn\195\182pfe",

        ["Menu5"] = "Kn\195\182pfe",
        ["Button"] = "Zeige den:",
        ["Order"] = "Ver\195\164ndere Knopfreihenfolge:",
        ["BuffButton"] = "Buffknopf",
        ["ArmorButton"] = "R\195\188stungsknopf",
        ["MagicButton"] = "Magieknopf",
        ["PortalButton"] = "Portalknopf",
        ["MountButton"] = "Reittierknopf",
        ["FoodButton"] = "Nahrungsknopf",
        ["WaterButton"] = "Wasserknopf",
        ["JobButton"] = "Berufknopf",
        ["WardButton"] = "Schutzzauberknopf",
        ["ManaGemButton"] = "Manasteinknopf",
        ["MinimapIcon"] = "Zeige Minikartensymbol",
        ["ArcanumMinimapIconPos"] = "Position des Minikartensymbols:",

        ["Menu6"] = "Men\195\188s",
        ["MenuPosition"] = "Men\195\188 \195\150ffnungsrichtung:",
        ["BuffMenu"] = "Buffs:",
        ["ArmorMenu"] = "R\195\188stungen:",
        ["MagicMenu"] = "Magie:",
        ["PortalMenu"] = "Portale:",
        ["MountMenu"] = "Reittiere:",
        ["JobMenu"] = "Berufe:",
        ["WardMenu"] = "Schutzzauber:",
        ["MenuScale"] = "Gr\195\182\195\159e der Men\195\188s",
        ["MenuPosition"] = "Position der Men\195\188s",

        ["Menu7"] = "Oberfl\195\164che Einstellungen",
        ["HealthColor"] = "Farbe des Gesundheitsbalken",
        ["ManaColor"] = "Farbe des Manabalkens",
        ["ButtonColor"] = "Mouseover Farbe der Kn\195\182pfe",
        ["DisplayHealthMana"] = "Zeige Gesundheit/Mana Balken",
    };

    ARCANUM_CLICK = {
                   "Hervorufung",
                   "Essen & Trinken",
                   "Wechsel zwischen Gruppen/Solomodus",
                   "Konfigurationsfenster",
                   "Manasteine",
                   "Eisblock",
                   "Ruhestein",
                   "Sheeping",
                   };

    ARCANUM_INSIDE_DISPLAY = {
                   "Gesundheit numerisch",
                   "Gesundheit %",
                   "Mana numerisch",
                   "Mana %",
                   "Hervorrufung CD",
                   "Nichts",
                   };

    ARCANUM_MENU_POS = {
                 "Rechts",
                 "Links",
                 "Oben",
                 "Unten",
               };

    ARCANUM_CONSUME_FOOD = {
                 "Der rechten Tasche",
                 "Der linken Tasche",
                 };

    ARCANUM_CONSUME_GEMS = {
                 "Dem H\195\182chsten",
                 "Dem Niedrigsten",
                 };

    ARCANUM_TOOLTIP_DATA = {
        ["LastSpell"] = "Linke Maustaste:",
        ["LastSpell2"] = "Mittlere Maustaste:";
        ["SpellTimer"] = {
                 Label = "Spruchdauer",
                 Text = "Aktive Spr\195\188che auf dem Ziel\n",
                 Right = "<white>Rechtsklick f\195\188r Ruhestein nach "
                };
                };

    ARCANUM_BINDING = {
		         ["Current"] = "Ist im Moment gebunden an ",
		         ["Confirm"] = "M\195\182chtest du eine neue Bindung der Taste ",
		         ["To"] = "An",
		         ["Yes"] = "Ja",
		         ["No"] = "Nein",
		         ["InCombat"] = "Es tut mir leid, du kannst Tastenk\195\188rzel nicht im Kampf binden..",
	           	 ["Binding"] = "Tastenk\195\188rzel",
		         ["Unbind"] = "Verbindung l\195\182sen",
		         ["Cancel"] = "Abbrechen",
		         ["Press"] = "Dr\195\188cke zu bindende Taste...\n\n",
		         ["Now"] = "Aktuell: ",
		         ["NotBound"] = "Nicht gebunden",
            	};
    
    ARCANUM_MESSAGE = {
        ["Interface"] = {
                 ["InitOn"] = "<white>aktiviert. /arcanum oder /arca um das Konfigurationsfenster zu \195\182ffnen",
                 ["InitOff"] = "<white>deaktiviert. /arca",
                 ["DefaultConfig"] = "<lightYellow>Standard-Einstellungen geladen.",
                 ["UserConfig"] = "<lightYellow>Einstellungen geladen.",
                 },
        ["Tooltip"] = {
                 ["LeftClick"] = "Linksklick: ",
                 ["MiddleClick"] = "Mittleklick: ",
                 ["RightClick"] = "Rechtsklick: ",
                 ["Cooldown"] = "Abklingzeit Ruhestein: ",
                 ["Minimap"] = "Konfigurationsfenster",
                 },
        ["Error"] = {
                 ["NoHearthstone"] = "Es befindet sich kein Ruhestein im Inventar.",
                 ["NoMount"] = "Es befindet sich kein Reittier im Inventar.",
                 },
        ["Autobuy"] = "Kaufe ",
                 };
end

function Arcanum_Localization_Speech_De()
    ARCANUM_PORTAL_MESSAGES = {
   		      {"Die <me> Fluglinie w\195\188nscht Ihnen eine angenehme Reise nach <city>"},
              
			  {"Die Gesellschaft < ich > Airline wünscht euch einen agr\195\169able reist gegen <city>."},
			  
			  {"Eines Tages habe ich Vertrauen in einen Furz gehabt, und ich scheiße oben ich. Aber gut, glücklicherweise ich... ja? Ah heeuu ja ein Portal... gegen <city>."},

              {"Der téléportation gegen < city > kann die nächsten Symptome: Erbrechen, Übel von tête,picotements an den Fingern von linken Füßen und plötzlicher Inkontinenz."},
              };
    ARCANUM_MOUNT_MESSAGES = {
         {"Zeit ist Geld. Darum lass uns schnell reiten, um es wieder reinzuholen."},
         {"Lasst uns langsam reiten und das Land genie\195\159en. Die G\195\164\ule wissen den Weg."},
         {"Hey, ich bin sp\195\164t drann! Ich hoffe ich finde ein Pferd, dass rennt wie ein ge\195\182\lter Blitz!"},
         };
	
	ARCANUM_RITUAL_MESSAGES = {
		{"Streifen von saoulards! Wollt ihr grailler vom binouze und was? Klickt dann auf diesem Portal und laßt po scheißen!"},
		
		{"Streifen von saoulards! Wollt ihr grailler vom binouze und was? Dann Ya nicht von Wein hier! Aber man kann es heilen! Klickt also verantwortlich für eine Eroberung durch Gerard!" },
        };
	
end

if ( GetLocale() == "deDE" ) then
    -- Table des sorts du mage
    ARCANUM_SPELL_TABLE = {
        ["ID"] = {},
        ["Rank"] = {},
        ["Name"] = {
            "Frostr\195\188stung",                          --1
            "Eisr\195\188stung",                            --2
            "Magische R\195\188stung",                      --3
            "Gl\195\188hende R\195\188stung",               --4
			"",
            "Magie d\195\164\mpfen",                        --6
            "Magie verst\195\164rken",                      --7
            "Essen herbeizaubern",                          --8
            "Wasser herbeizaubern",                         --9
            "",
			"",
			"Arkane Intelligenz",                           --12
            "Arkane Brillanz",                              --13
			"",
            "Teleportieren: Darnassus",                     --15
            "Teleportieren: Eisenschmiede",                 --16
            "Teleportieren: Sturmwind",                     --17
            "Teleportieren: Exodar",                        --18
            "Teleportieren: Orgrimmar",                     --19
            "Teleportieren: Donnerfels",                    --20
            "Teleportieren: Unterstadt",                    --21
            "Teleportieren: Silbermond",                    --22
            "Portal: Darnassus",                            --23
            "Portal: Eisenschmiede",                        --24
            "Portal: Sturmwind",                            --25
            "Portal: Exodar",                               --26
            "Portal: Orgrimmar",                            --27
            "Portal: Donnerfels",                           --28
            "Portal: Unterstadt",                           --29
            "Portal: Silbermond",                           --30
            "Teleportieren: Dalaran",							
            "Portal: Dalaran",                                                 
            "",                                                 
            "",
			"",
			"",
            "Eisblock",                                     --37
            "K\195\164lteeinbruch",                         --38
            "Verband",                                      --39
            "Teleportieren: Shattrath",             		--40
            "Portal: Shattrath",                            --41
            "Hervorrufung",                                 --42
			"Tischlein deck dich",                     	    --43
            "Teleportieren: Theramore",                     --44
			"Portal: Theramore",                            --45
            "Teleportieren: Portallehrer",                  --46
			"Portal: Portallehrer",                         --47
            "Herbeigezauberter Manakeks",                   --48
			"Manaedelstein herbeizaubern",                  --49
            "",                      						--50
            "",                        						--51
            "",                          					--52
            "",                        						--53
			"Verwandlung",                                  --54
            "Verwandlung : Schwein",                        --55
            "Verwandlung : Schildkr\195\182te",             --56
			"Feuerzauberschutz",                            --57
            "Frostzauberschutz",                            --58
			"Eisbarriere"                                   --59
        },
        ["Mana"] = {},
        ["Texture"] = {},
                       };

		Dest  = {"Darnassus", "Eisenschmiede", "Sturmwind", "Exodar", "Theramore", "Orgrimmar", "Donnerfels", "Unterstadt", "Silbermond", "Portallehrer", "Shattrath", "Dalaran"};
			
    ARCANUM_PROFESSIONS = {
        ["ID"] = {},
        ["Name"] = {
		    "Alchemie", 
			"Schmiedekunst", 
			"Kochkunst", 
			"Entzaubern", 
			"Verzauberkunst", 
			"Ingenieurskunst", 
			"Kräutersuche", 
			"Mineraliensuche", 
			"Erste Hilfe", 
			"Angeln", 
			"Juwelenschleifen", 
			"Lederverarbeitung", 
			"Sondieren", 
			"Verhüttung", 
			"Bergbau",
			"Inschriftenkunde",
			"Kürschnerei",
			"Kräutersammeln",
			"Schneiderei"
			},
        ["Texture"] = {},
        };

    ARCANUM_MANAGEM = {
	        "Manaachat", 
			"Manajadestein", 
			"Manacitrin", 
			"Manarubin", 
			"Manasmaragd",
			"Manasaphir"
			};

    ARCANUM_FOOD = {
	        "Herbeigezauberter Muffin", 
			"Herbeigezaubertes Brot", 
			"Herbeigezaubertes Roggenbrot", 
			"Herbeigezauberter Pumpernickel",
            "Herbeigezauberter Sauerteig", 
			"Herbeigezaubertes Milchbr\195\182tchen", 
			"Herbeigezauberte Zimtschnecke", 
			"Herbeigezaubertes Croissant",
			"Herbeigezauberter Manakeks",
			"Herbeigezauberter Manakuchen",
			"Herbeigezauberter Manastrudel"
			};

    ARCANUM_WATER = {
	        "Herbeigezaubertes Wasser", 
			"Herbeigezaubertes frisches Wasser", 
			"Herbeigezaubertes gel\195\164utertes Wasser",
            "Herbeigezaubertes Quellwasser", 
			"Herbeigezaubertes Mineralwasser", 
			"Herbeigezaubertes Sprudelwasser", 
			"Herbeigezaubertes Kristallwasser", 
			"Herbeigezaubertes Bergquellwasser", 
			"Herbeigezaubertes Eiswasser",
			"Herbeigezauberter Manakeks",
			"Herbeigezauberter Manakuchen",
			"Herbeigezauberter Manastrudel"
			};
	
    ARCANUM_MANNE = {
				["ID"] = {},
				["Name"] = {
                    "Herbeigezauberter Manakeks",
					"Herbeigezauberter Manakuchen",
					"Herbeigezauberter Manastrudel"	
				},	
				["Texture"] = {},	
				};				

    ARCANUM_BANDAGE = "K\195\188rzlich bandagiert";

    ARCANUM_TRANSLATION = {
        ["Mounting"] = "Beschw\195\182re",
        ["Hearth"] = "Ruhestein";
        ["Cooldown"] = "Abklingzeit",
        ["Rank"] = "Rang",
    };
    
    -- Table des items du Mage
    ARCANUM_ITEM = {
        ["ArcanePowder"] = "Arkanes Pulver",
        ["RuneOfTeleportation"] = "Rune der Teleportation",
        ["RuneOfPortals"] = "Rune der Portale",
        ["LightFeathers"] = "Leichte Feder",
        ["Hearthstone"] = "Ruhestein",
        ["QuirajiMount"] = "Qirajiresonanzkristall",
    };

    -- Monture
    MOUNT = {
        {"Horn des roten Wolfs", "Horn des Waldwolfs", "Horn des braunen Wolfs", "Horn des schnellen braunen Wolfs", "Horn des schwarzen Kriegswolfs"},
        {"Z\195\188gel des gestreiften Nachts\195\164blers", "Z\195\188gel des schwarzen Kriegstigers"},
        {"Schneller zulianischer Tiger"},
        {"Gro\195\159er wei\195\159er Kodo", "Grauer Kodo", "Gro\195\159er grauer Kodo"},
        {"Gr\195\188ner Kodo", "Graublauer Kodo"},
        {"Brauner Kodo", "Schwarzer Kriegskodo", "Gro\195\159er brauner Kodo"},
        {"Schwarzer Schlachtenschreiter", "Eisblauer Roboschreiter Mod. A", "Wei\195\159er Roboschreiter Mod. A", "Schneller wei\195\159er Roboschreiter", "Blauer Roboschreiter", "Unlackierter Roboschreiter", "Schneller gelber Roboschreiter", "Roter Roboschreiter", "Gr\195\188ner Roboschreiter", "Schneller gr\195\188ner Roboschreiter"},
        {"Streitwidder der Sturmlanzen", "Frostwidder", "Schwarzer Widder", "Wei\195\159er Widder", "Schneller wei\195\159er Widder", "Brauner Widder", "Schneller brauner Widder", "Grauer Widder", "Schneller grauer Widder", "Schwarzer Kriegswidder"},
        {"Schwarzes Schlachtrosszaumzeug"},
        {"Z\195\188gel des Winterquellfrosts\195\164blers"},
        {"Pfeife des schwarzen Kriegsraptors", "Pfeife des smaragdfarbenen Raptors", "Pfeife des elfenbeinfarbenen Raptors", "Pfeife des scheckigen roten Raptors", "Pfeife des t\195\188rkisfarbenen Raptors", "Pfeife des violetten Raptors", "Schneller olivfarbener Raptor", "Schneller orangener Raptor", "Schneller blauer Raptor", "Schneller Razzashiraptor"},
        {"Rappenzaumzeug", "Braunes Pferd", "Kastanienbraune Stute", "Palominozaumzeug", "Schecke", "Schimmelzaumzeug", "Schnelles Palomino", "Schneller Brauner", "Schnelles wei\195\159es Ross"},
        {"Z\195\188gel des Todesstreitrosses", "Gr\195\188nes Skelettschlachtross", "Purpurnes Skelettschlachtross", "Rotes Skelettschlachtross", "Braunes Skelettpferd", "Blaues Skelettpferd", "Rotes Skelettpferd"},
        {"Horn des Terrorwolfs", "Horn des schnellen Waldwolfs", "Horn des schnellen Grauwolfs", "Horn des arktischen Wolfs"},
        {"Z\195\188gel des Frosts\195\164blers", "Z\195\188gel des Nachts\195\164blers", "Z\195\188gel des gefleckten Frosts\195\164blers", "Z\195\188gel des gestreiften Frosts\195\164blers", "Z\195\188gel des schnellen Frosts\195\164bler", "Z\195\188gel des schnellen Schattens\195\164blers", "Z\195\188gel des schnellen Sturms\195\164blers"},
        {"Horn des Frostwolfheulers"},
        {"Schwarzer Falkenschreiter", "Roter Falkenschreiter", "Blauer Falkenschreiter" ,"Lila Falkenschreiter"},
        {"Schneller lila Falkenschreiter", "Schneller pinkfarbener Falkenschreiter", "Schneller gr\195\188ner Falkenschreiter"},
        {"Brauner Elekk", "Lila Elekk", "Grauer Elekk", "Gro\195\159er blauer Elekk", "Gro\195\159er gr\195\188ner Elekk", "Gro\195\159er lila Elekk"},
        {"Zügel des dunklen Kriegstalbuks", "Zügel des silbernen Kriegstalbuks", "Zügel des kobaltblauen Kriegstalbuks", "Zügel des braunen Kriegstalbuks", "Zügel des weißen Kriegstalbuks"},
        {"Rênes de talbuk de monte sombre", "Zügel des braunen Reittalbuks", "Zügel des silbernen Reittalbuks", "Zügel des kobaltblauen Reittalbuks", "Zügel des weißen Reittalbuks"},
        {"Schwarzer Greif", "Goldener Greif", "Wei\195\159er Greif", "Schneller blauer Greif", "Schneller gr\195\188ner Greif", "Schneller lila Greif", "Schneller roter Greif"},
        {"Gelbbrauner Windreiter", "Gr\195\188ner Windreiter", "Blauer Windreiter", "Schneller lila Windreiter", "Schneller gelber Windreiter", "Schneller roter Windreiter", "Schneller grüner Windreiter"},
        {"Blauer Reitnetherrochen", "Grüner Reitnetherrochen", "Roter Reitnetherrochen", "Lila Reitnetherrochen", "Silberner Reitnetherrochen"}, 
        {"Z\195\188gel des feurigen Schlachtrosses"},
        {"Z\195\188gel des Rabenfürsten"},
        {"Z\195\188gel des viridiangrünen Drachen der Netherschwingen", "Z\195\188gel des azurblauen Drachen der Netherschwingen", "Z\195\188gel des kobaltblauen Drachen der Netherschwingen", "Z\195\188gel des onyxfarbenen Drachen der Netherschwingen", "Z\195\188gel des lila Drachen der Netherschwingen", "Z\195\188gel des violetten Drachen der Netherschwingen"}, 
        {"Cenarischer Kriegshippogryph"},
		};

    MOUNT_SPEED = "Erh\195\182ht Tempo um (%d+)%%.";

    MOUNT_PREFIX = {"Z\195\188gel des ", "Pfeife des ", "Horn des "};

    QIRAJ_MOUNT = {
        "Gelber Qirajiresonanzkristall",
        "Roter Qirajiresonanzkristall",
        "Gr\195\188ner Qirajiresonanzkristall",
        "Blauer Qirajiresonanzkristall",
        "Schwarzer Qirajiresonanzkristall",
        };
	
	ARCANUM_MONTURE = {
	--Wowhead 293
	[1] = {	17460,	--"Bélier de givre"
		29467,	--"Bélier de guerre noir"
		17461,	--"Bélier noir"
		6898,	--"Bélier blanc"
		6899, 	--"Bélier brun"
		43899,	--"Bélier de la fête des Brasseurs"
		6777,	--"Bélier gris"
		6897,	--"Bélier bleu"
--Bride
		12353,	--"Bride d'étalon blanc"
		29468,	--"Bride de palefroi de guerre noir"
		18241,	--"Bride de palefroi de guerre noir"
		2411, 	--"Bride d'étalon noir"
		5656, 	--"Bride de cheval bai"
		471,	--"Palomino"
		472,	--"Pinto"
		2414, 	--"Bride de pinto"
--Chevaux		
		5656, 	--"Cheval bai"	
		6648, 	--"Jument alezane"
		8980,	--"Cheval squelette"
		17464,	--"Cheval squelette bai"
		17463,	--"Cheval squelette bleu"
		17462,	--"Cheval squelette rouge"
		64977,  --"Cheval squelette noir"
		48025,	--"Monture du Cavalier sans tête"--Varie selon la competence de monte.
--Elekk
		34406,	--"Elekk brun"
		35710,	--"Elekk gris"
		35711,	--"Elekk violet"
--Etalon
		16083,	--"Etalon blanc"	
		470,	--"Etalon noir"
--Faucon
		35020,	--"Faucon-pérégrin bleu"
		35022,	--"Faucon-pérégrin noir"
		37795,	--"Faucon-pérégrin rouge"
		35018,	--"Faucon-pérégrin violet"
--Grand ours
		58983,	--"Grand ours du Blizzard"--Varie selon la Competence de monte.
--Kodo
		64657,	--"Kodo blanc"
		18990,	--"Kodo brun"
		18989,	--"Kodo gris"
		18363,	--"Kodo de monte"
		50869,	--"Kodo de la fête des Brasseurs"
		49378,	--"Kodo de monte de la fête des Brasseurs"
--Léopard
		16058,	--"Léopard primal"	
--Loup
		581,    --"Loup blanc"
		6654,	--"Loup brun"
		580,	--"Loup des bois"
		459,	--"Loup gris"
		578,	--"Loup noir"
		6653,	--"Loup redoutable"
		579,	--"Loup rouge"
--Mécanotrotteur
		15781,	--"Mécanotrotteur acier"
		10979,	--"Mécanotrotteur bleu"
		33630,	--"Mécanotrotteur bleu"
		17454,	--"Mécanotrotteur non peint"
		10873,	--"Mécanotrotteur rouge"
		10456,	--"Mécanotrotteur rouge et bleu"
		15780,	--"Mécanotrotteur vert"
		17453,	--"Mécanotrotteur vert"
		17458,	--"Mécanotrotteur vert fluorescent"
		17455,	--"Mécanotrotteur violet"
--Raptor
		8395,	--"Raptor émeraude"
		10795,	--"Raptor ivoire"
		10798,	--"Raptor obsidienne"
		10796,	--"Raptor turquoise"
		10799,	--"Raptor violet"
--Sabre
		8394,	--"Sabre-de-givre rayé"
		10789,	--"Sabre-de-givre tacheté"
		66847,	--"Sabre-de-l'aube rayé"
		10793,	--"Sabre-de-nuit rayé"
--Tigre
		16060,	--"Tigre à dents de sabre doré"
		16059,	--"Tigre à dents de sabre fauve"
		42776,	--"Tigre spectral"
--Tortue	
		30174,	--"Tortue de monte"
		64731,  --"Tortue de mer"
--AQ
		26656,	--"Char d'assaut qiraji noir"
		25953,	--"Char d'assaut qiraji bleu "
		26055,	--"Char d'assaut qiraji jaune"
		26054,	--"Char d'assaut qiraji rouge"
		26056,	--"Char d'assaut qiraji vert"
--Bélier
		23240,	--"Bélier blanc rapide"
		23238,	--"Bélier brun rapide"
		50870,	--"Bélier de la fête des Brasseurs rapide"
		17460,	--"Bélier de givre"
		22720,	--"Bélier de guerre noir"
		23239,	--"Bélier gris rapide"
		17461,	--"Bélier noir"
		65643,  --"Bélier pourpre rapide"
		63636,	--"Bélier de Forgefer"
--Chevaux	
		67466,	--"Cheval de guerre de l'Aube d'argent"
		68187,  --"Cheval de guerre blanc de croisé"
		68188,  --"Cheval de guerre noir de croisé"
		63643,  --"Cheval de guerre réprouvé"
		65645,	--"Cheval de guerre squelette blanc"
		64656,	--"Cheval de guerre squelette bleu"
		66846,	--"Cheval de guerre squelette ocre"
		22722,	--"Cheval de guerre squelette rouge"
		17465,	--"Cheval de guerre squelette vert"
		23246,	--"Cheval de guerre squelette violet"
		16082,	--"Palomino"
		23227,	--"Palomino rapide"
--Destrier
		23510,	--"Destrier de bataille foudrepique"	
--Elekk
		48027,	--"Elekk de guerre noir"
		47037,	--"Elekk de guerre rapide"
		47037,	--"Elekk de l'exodar"
--Faucon	
		61996,	--"Faucon-dragon bleu"
		62048,	--"Faucon-dragon de monte noir"
		61997,	--"Faucon-dragon rouge"
		66088,	--"Faucon-dragon saccage-soleil"
		35028,	--"Faucon de guerre rapide"
		46628,	--"Faucon-pérégrin blanc rapide"
		33660,	--"Faucon-pérégrin rose rapide"
		63642,	--"Faucon-pérégrin de Lune-d'argent"
		65639,	--"Faucon-pérégrin rouge rapide"
		66091,	--"Faucon-pérégrin saccage-soleil"
		35025,	--"Faucon-pérégrin vert rapide"
		35027,	--"Faucon-pérégrin violet rapide"
--Grand Elekk
		35713,	--"Grand elekk bleu"
		34407,	--"Grand elekk d'élite"
		65637,	--"Grand elekk rouge"
		35712,	--"Grand elekk vert"
		35714,	--"Grand elekk violet"
		
--Grand Kodo
		23247,	--"Grand kodo blanc"
		23249,	--"Grand kodo brun"
		49379,	--"Grand kodo de la fête des Brasseurs"
		65641,	--"Grand kodo doré"
		23248,	--"Grand kodo gris"
--Grand Mamouth	
		59810,	--"Grand mammouth de guerre noir"
		59811,	--"Grand mammouth de guerre noir"
		61467,	--"Grand mammouth de guerre noir"
		61465,	--"Grand mammouth de guerre noir"
		60140,	--"Grand mammouth de caravane"
		60136,	--"Grand mammouth de caravane"
		59802,	--"Grand mammouth des glaces"3P
		59804,	--"Grand mammouth des glaces"3P
		61469,	--"Grand mammouth des glaces"2P
		61470,	--"Grand mammouth des glaces"2P
--Hurleur
		23509,	--"Hurleur Loup-de-givre"	
--Karazhan
		36702,	--"Cheval de guerre flamboyant"
--Kodos
		18992,	--"Kodo bleu"
		22718,	--"Kodo de guerre noir"
		63641,	--"Kodo des pitons de tonnerre"
		18991,	--"Kodo vert"
--Loup
		16081,	--"Loup blanc"
		65646,	--"Loup bordeaux rapide"
		23250,	--"Loup brun rapide"
		63640,	--"Loup d'Orgrimmar"
		22724,	--"Loup de guerre noir"
		23251,	--"Loup des bois rapide"
		23252,	--"Loup gris rapide"
		68056,	--"Loup rapide de la Horde"
		16080,	--"Loup rouge"
--Mamouth
		59785,	--"Mammouth de guerre noir"
		59788,	--"Mammouth de guerre noir"
		61425,	--"Mammouth de voyage de la toundra"
		61447,	--"Mammouth de voyage de la toundra"
		59797,	--"Mammouth des glaces"
		59799,	--"Mammouth des glaces"
		59791,	--"Mammouth laineux"
		59793,	--"Mammouth laineux"
--Mécabécane (Horde)		
		55531,	--"Mécabécane"
--Mécabécane (Alliance)		
		60424,	--"Bécane de mekgénieur"		
--Mécanotrotteur
		15779,	--"Mécanotrotteur blanc modèle B"
		23223,	--"Mécanotrotteur blanc rapide"
		17459,	--"Mécanotrotteur bleu clair modèle A"
		63638,	--"Mécanotrotteur de gnomeregan"
		23222,	--"Mécanotrotteur jaune rapide"
		23225,	--"Mécanotrotteur vert rapide"
		22719,	--"Trotteur de bataille noir"
		65642,	--"Turbotrotteur"
--Naxxramas		
		29059,	--"Destrier de la mort de Naxxramas"		
--Ours
		54753,	--"Monture ours polaire blanc"
		43688,	--"Ours de guerre amani"
		51412,	--"Grand ours de combat"
		60114,	--"Ours brun cuirassé"
		60116,	--"Ours brun cuirassé"
		60118,	--"Ours noir de guerre"
		60119,	--"Ours noir de guerre"
		59573,	--"Ours polaire brun"
		59572,	--"Ours polaire noir"
--Palefroi
		23229,	--"Palefroi bai rapide"
		23228,	--"Palefroi blanc rapide"
		22717,	--"Palefroi de guerre noir"
		63232,	--"Palefroi de Hurlevent"
		65640,	--"Palefroi de gris rapide"
		66090,	--"Palefroi quel'dorei"
		68057,	--"Palefroi rapide de l'Alliance"
--Poulet
		65917,	--"Poulet magique"
		66122,	--"Poulet magique"
		66123,	--"Poulet magique"
		66124,	--"Poulet magique"	
--Raptor
		23241,	--"Raptor bleu rapide"
		16084,	--"Raptor chamaré rouge"
		22721,	--"Raptor de guerre noir"
		17450,	--"Raptor ivoire"
		23243,	--"Raptor orange rapide"
		24242,	--"Raptor razzashi rapide"
		63635,  --"Raptor sombrelance"
		23242,	--"Raptor vert olive rapide"
		65644,	--"Raptor violet rapide"
--Ravasaure
		64659,	--"Ravasaure peau-de-venin"	
--Sabre 
		16056,	--"Ancien sabre-de-givre" 
		23219,	--"Sabre-de-brume rapide"
		17229,	--"Sabre-de-givre de Berceau-de-l'Hiver"
		23221,	--"Sabre-de-givre rapide"
		23220,	--"Sabre-de-l'aube rapide"
		65638,	--"Sabre-de-lune rapide"
		63637,	--"Sabre-de-nuit darnassien"
		16055,	--"Sabre-de-nuit noir"
		23338,	--"Sabre-tempête rapide"
--Seigneur
		41252,	--"Seigneur corbeau"
--Stratholme
		17481,	--"Destrier de la mort de Vaillefendre"		
--Talbuk	,
		37898,	--"Talbuk de guerre argenté"
		34897,	--"Talbuk de guerre blanc"
		34899,	--"Talbuk de guerre brun"
		34896,	--"Talbuk de guerre cobalt"
		34790,	--"Talbuk de guerre sombre"
		39317,	--"Talbuk de monte argenté"
		39319,	--"Talbuk de monte blanc"
		39318,	--"Talbuk de monte brun"
		39315,	--"Talbuk de monte cobalt"
		39316,	--"Talbuk de monte sombre"
--Tigre	
		22723,	--"Tigre de guerre noir"
		42777,	--"Tigre spectral rapide"
		24252,	--"Tigre zulien rapide"
--Zhévra		
		48954,	--"Zhévra rapide"
		49322,	--"Zhévra rapide"
--Coursier		
		32244,	--"Coursier du vent bleu"
		32243,	--"Coursier du vent fauve"
		32245,	--"Coursier du vent vert"
--Fusée
		46197,	--"Fusée-de-néant X-51"
--Griffons	
		32239,	--"Griffon d'ébène"
		32235,	--"Griffon doré"
		32240,	--"Griffon neigeux"
--Machine volante
		44153,	--"Machine volante"
--Drake
		60025,	--"Drake albinos"
		59567,	--"Drake azur"
		59568,	--"Drake bleu"
		59650,	--"Drake noir"
		59570,	--"Drake rouge"
		59571,	--"Drake crépusculaire"
		59569,	--"Drake de bronze"
		41514,	--"Drake de l'Aile-du-Néant azur"
		41515,	--"Drake de l'Aile-du-Néant cobalt"
		41513,	--"Drake de l'Aile-du-Néant onyx"
		41518,	--"Drake de l'Aile-du-Néant pourpre"
		41516,	--"Drake de l'Aile-du-Néant violet"
		41517,	--"Drake de l'Aile-du-Néant viride"
		44744,	--"Drake de Néant impitoyable"
--Fusée		
		46199,	--"Fusée-de-néant X-51 X-TREME"
--Griffons
		32242,	--"Griffon bleu rapide"
		32289,	--"Griffon rouge rapide"
		32290,	--"Griffon vert rapide"
		32292,	--"Griffon violet rapide"
		61229,	--"Griffon neigeux cuirassé"
--Coursier
		61230,	--"Coursier du vent bleu caparaçonné"
		32296,	--"Coursier du vent jaune rapide"
		32246,	--"Coursier du vent rouge rapide"
		32295,	--"Coursier du vent vert rapide"
		32297,	--"Coursier du vent violet rapide"
--Hyppogriffe
		63844,	--"Hippogriffe d'Argent"
		43927,	--"Hippogriffe de guerre cénarien"
		66087,	--"Hippogriffe du Concordat argenté"
--Machine volante
		44151,	--"Machine volante à turbo-injection"
--Proto	
		59996,	--"Proto-drake bleu"
		59961,	--"Proto-drake rouge"
		61294,	--"Proto-drake vert"
		60021,	--"Proto-drake perdu dans le temps"
		60024,	--"Proto-drake pourpre"
--Raie
		39802,	--"Raie du Néant argentée"
		39803,	--"Raie du Néant bleue"
		39800,	--"Raie du Néant rouge"
		39798,	--"Raie du Néant verte"
		39801,	--"Raie du Néant violette"
--Tapis	
		61442,	--"Tapis en étoffe lunaire rapide"
		61446,	--"Tapis en feu-sorcier rapide"
		61444,	--"Tapis en tisse-ombre rapide"
		61451,	--"Tapis volant"
		61309,	--"Tapis volant magnifique"
--Wyrm
		51960,	--"Monture wyrm de givre"
		43810,	--"Wyrm de givre"
--L'oeil 310
		40192,	--"Cendres d'Al'ar"	
--Drake 310
		34092,	--"Drake du Néant impitoyable"
		36676,	--"Drake du Néant vengeur"		
		3363,	--"Drake du Néant"
		58615,	--"Drake du Néant brutal"
		37015,	--"Drake du Néant rapide"
		49193,	--"Drake du Néant vengeur"
--Phénix 310
		32345,	--"Monture Piou-piou le Phénix"
--Palefroi 310		
		59780,	--"Palefroi ailé de la Lame d'ébène"--Varie selon la competence de monte
--Proto 310
		63956,	--"Proto-drake enchaîné"	
		59976,	--"Proto-drake noir"
		60021,	--"Proto-drake Pestiféré"
		59976,	--"Proto-drake rouillée"	
--Tëte 310
		63769,	--"Tête de Mimiron"	
--Wyrm 310
		64927,	--"Wyrm de givre du gladiateur fatal"	
		65439,	--"Wyrm de givre du gladiateur furieux"
		67336,	--"Wyrm de givre du gladiateur implacable"
		},	
	["Name"] = {},
	["Icon"] = {},
	["ID"] = {},
};
	
end	

