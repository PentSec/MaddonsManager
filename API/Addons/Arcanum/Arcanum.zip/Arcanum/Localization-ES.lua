------------------------------------------------------------------------------------------------------
-- Arcanum

-- Addon pour Mage inspir� du c�l�bre Necrosis
-- Gestion des buffs, des portails et Compteur de Composants

-- Remerciements aux auteurs de Necrosis

-- Auteur Lenny415 Repris par Erina

-- Serveur:
-- Vol'Jin
------------------------------------------------------------------------------------------------------

function Arcanum_Localization_Dialog_Es()
	function ArcanumLocalization()
		Arcanum_Localization_Speech_Es();
	end
	-- Raccourcis claviers
	BINDING_HEADER_ARCANUM_BIND = "Arcanum";
	BINDING_NAME_ACTIVATE = "Activar / desactivar Arcanum";
	BINDING_NAME_STEED = "Montar";
	BINDING_NAME_FROSTARMOR = "Armadura de hielo";
	BINDING_NAME_MAGEARMOR = "Armadura de mago";
	BINDING_NAME_FIREARMOR = "Armadura de arrabio";
	BINDING_NAME_ARCANEINTELLECT = "Intelecto Arcano";
	BINDING_NAME_ARCANEBRILLIANCE = "Luminosidad Arcana";
	BINDING_NAME_AMPLIFYMAGIC = "Amplificar magia";
	BINDING_NAME_DAMPENMAGIC = "Atenuar magia";
	BINDING_NAME_CONJUREFOOD = "Crear comida";
	BINDING_NAME_USEFOODWATER = "Comer & Beber";
	BINDING_NAME_USEFOOD = "Comer";
	BINDING_NAME_CONJUREWATER = "Crear agua";
	BINDING_NAME_USEWATER = "Beber";
	BINDING_NAME_CONJUREMANAGEM = "Crear gema de man\195\161";
	BINDING_NAME_USEMANAGEM = "Usando una gema de man\195\161";
	BINDING_NAME_EVOCATION = "Evocaci\195\179n";
	BINDING_NAME_TELEPORT1 = "Teletransporte a 1";
	BINDING_NAME_TELEPORT2 = "Teletransporte a 2";
	BINDING_NAME_TELEPORT3 = "Teletransporte a 3";
    BINDING_NAME_TELEPORT4 = "Teletransporte a 4";
	BINDING_NAME_TELEPORT5 = "Teletransporte a 5";
	BINDING_NAME_TELEPORT6 = "Teletransporte a 6";
	BINDING_NAME_TELEPORT7 = "Teletransporte a 7";
	BINDING_NAME_PORTAL1 = "Portal 1";
	BINDING_NAME_PORTAL2 = "Portal 2";
	BINDING_NAME_PORTAL3 = "Portal 3";
	BINDING_NAME_PORTAL4 = "Portal 4";
	BINDING_NAME_PORTAL5 = "Portal 5";
	BINDING_NAME_PORTAL6 = "Portal 6";
	BINDING_NAME_PORTAL7 = "Portal 7";	
	BINDING_NAME_PORTAL8 = "Portal 8";	
    BINDING_NAME_WARD1 = "Resguardo contra el Fuego";
	BINDING_NAME_WARD2 = "Resguardo contra la Escarcha";
    
	ARCANUM_CONFIGURATION = {
		["Menu1"] = "Mensajes",
		["MessageMenu1"] = "Jugador :",
		["Tooltip0"] = "No Tooltip",
		["Tooltip1"] = "De ayuda parcial",
		["Tooltip2"] = "Completo de ayuda",
		["ChatType"] = "Les messages = des messages syst\195\168mes",
		["PortalMessage"] = "Mostrar los mensajes de la invocaci\195\179n de un portal",
        ["MountMessage"] = "Mostrar los mensajes de la invocaci\195\179n de un caballo",
        ["ArcanumButtonDisplay"] = "Ver en el campo :",
        ["InsideDisplay"] = "Mostrar en el campo :",
        ["DisplayHearthStone"] = "Piedra de hogar",
        ["DisplayManaGem"] = "Gema de man\195\161",
        ["DisplayEvocation"] = "Evocaci\195\179n",
        ["DisplayIceBlock"] = "Bloque de hielo",
        ["DisplayColdSnap"] = "Mordedura de Hielo",
        ["DisplayIntell"] = "Intelecto Arcano",
        ["DisplayArmor"] = "Armadura",
        ["DisplayBandage"] = "Venda",
        ["Bindings"] = "Teclado",
		
		["Menu2"] = "Varios",
		["LevelBuff"] = "Buffer de la meta en funci\195\179n de su nivel",
        ["EvocationLimit"] = "Por la Evocaci\195\179n que se puede lanzar",
        ["ConsumeFood"] = "El agua potable en las bolsas de pan",
        ["ConsumeGems"] = "El consumo de una gema de man\195\161",
        ["RandMount"] = "Invocaci\195\179n de un montaje aleatorio",
		["DeleteFood"] = "Eliminar los alimentos invocado",
		["DeleteWater"] = "Eliminar el agua utilizada",
		["DeleteManaGem"] = "Eliminar de man\195\161 gemas",
		
		["Menu3"] = "Comprar componentes de autom\195\179viles",
		["ReagentSort"] = "Componentes de almacenamiento dentro de una misma bolsa",
		["ReagentBag"] = "Bolsa de componentes",
		["ReagentBuy"] = "Comprar componentes de autom\195\179viles",
		["Reagent"] = "Cantidad m\195\161xima de los componentes en la bolsa:",
		["Powder"] = "Part�culas Arcanas",
		["Teleport"] = "Runa de teletransporte",
		["Portal"] = "Runa de portales",
		
		["Menu4"] = "Gr\195\161fico",
		["Toggle"] = "Mostrar Arcanum",		
        ["InterfaceVersion"] = "Arcanum men\195\186s",
		["InterfaceVersion2"] = "Arcanum sin men\195\186s",
		["Lock"] = "Bloquear Arcanum",
		["IconsLock"] = "Bloqueo de botones en el \195\161mbito Arcanum",
		["ArcanumRotation"] = "Arcanum de rotaci\195\179n",
		["ArcanumSize"] = "Tama\195\177o de Arcanum",
        ["ButtonSize"] = "Tama\195\177o de los botones",
		
		["Menu5"] = "Botones",
        ["Button"] = "Mostrar bot\195\179n :",
        ["Order"] = "Cambiar el orden de los botones:",
		["BuffButton"] = "Aficionados",
		["ArmorButton"] = "Armadura",
		["MagicButton"] = "Magia",
		["PortalButton"] = "Portales",
		["MountButton"] = "Soportes",
		["FoodButton"] = "Alimentos",
		["WaterButton"] = "Bebidas",
		["ManaGemButton"] = "Man\195\161 gemas",
        ["JobButton"] = "Comercio",
        ["WardButton"] = "Guardianes",
        ["MinimapIcon"] = "Mostrar icono en el minimapa",
        ["ArcanumMinimapIconPos"] = "Posici\195\179n de la minimapa icono:",
        
        ["Menu6"] = "Men\195\186s",
        ["MenuPosition"] = "Men\195\186 de orientaci\195\179n:",
		["BuffMenu"] = "Buffer",
		["ArmorMenu"] = "Armadura:",
		["MagicMenu"] = "Magia:",
		["PortalMenu"] = "Portales:",
        ["MountMenu"] = "Marcos:",
        ["JobMenu"] = "Comercio:",
        ["WardMenu"] = "Guardianes:",
        ["MenuScale"] = "Tama\195\177o de Men\195\186",
		["MenuPosition"] = "Men\195\186 de posici\195\179n",
        
        ["Menu7"] = "Temas",
        ["HealthColor"] = "El color de la barra de vida",
        ["ManaColor"] = "El color de la barra de man\195\161",
        ["ButtonColor"] = "Seleccionar Color",
        ["DisplayHealthMana"] = "Mostrar las barras de vida / man\195\161",
	};
	
    ARCANUM_CLICK = {
        "Evocaci\195\179n",
        "Comer y Beber",
        "Cambiar el modo de solista o grupo",
        "Panel de control",
        "Gema de man\195\161",
        "Bloque de hielo",
        "Piedra de hogar",
        "Polimorfia",
    };
    
    ARCANUM_INSIDE_DISPLAY = {
        "Vida digital",
        "Vida %",
        "Man\195\161 digitales",
        "Man\195\161 %",
        "Evocaci\195\179n de CD",
        "Nada",
    };
    
    ARCANUM_MENU_POS = {
		"Derecho",
        "Izquierda",
        "Arriba",
        "Abajo",
    };
    
    ARCANUM_CONSUME_FOOD = {
    	"La izquierda",
        "M\195\161s derecho",
    };
		    
    ARCANUM_CONSUME_GEMS = {
        "Los mayores",
        "El m\195\161s peque\195\177o",
    };

	ARCANUM_TOOLTIP_DATA = {
        ["LastSpell"] = "Haz clic para empezar",
        ["LastSpell2"] = "Haga clic aqui para iniciar el medio ambiente",
        ["SpellTimer"] = {
			Label = "Duraci\195\179n de los hechizos",
			Text = "Conjuros activa en el destino",
			Right = "<white>Haga clic derecho Piedra de hogar hacia",
        };
	};

    ARCANUM_BINDING = {
		["Current"] = "Est\195\161 asociado ",
		["Confirm"] = "Est\195\161 usted asociado ",
		["To"] = "A",
		["Yes"] = "S�",
		["No"] = "No",
		["InCombat"] = "Lo sentimos, no puedes cambiar los m\195\169todos abreviados de teclado en combate.",
		["Binding"] = "Atajos",
		["Unbind"] = "Borrar",
		["Cancel"] = "Cancelar",
		["Press"] = "Pulse el bot\195\179n para asociar...\n\n\n\n",
		["Now"] = "En la actualidad : ",
		["NotBound"] = "No asignados",
	};
    
	ARCANUM_MESSAGE = {
	  	["Interface"] = {
	    	["InitOn"] = "<white>activado. / Arcanum o arca para mostrar la ventana de configuraci\195\179n",
	    	["InitOff"] = "<white>discapacitados.",
	  		["DefaultConfig"] = "<lightYellow>cargado la configuraci\195\179n por defecto.",
			["UserConfig"] = "<lightYellow>Configuraci�n cargado",
		},
	  	["Tooltip"] = {
	    	["LeftClick"] = "Haga clic en la izquierda: ",
			["MiddleClick"] = "Haga clic en Medio: ",
	    	["RightClick"] = "Click derecho: ",
	 		["Cooldown"] = "Piedra de hogar disponible dans ",
            ["Minimap"] = "Grupo",
	  	},
		["Error"] = {
	  		["NoHearthstone"] = "Usted no tiene Piedra de hogar en su inventario",
      		["NoMount"] = "Usted no tiene un montaje en su inventario",
		},
		["Autobuy"] = "Comprar",
	};
end

function Arcanum_Localization_Speech_Es()
	ARCANUM_PORTAL_MESSAGES = {
		( "<me> La compa\195\177�a a\195\169rea le desea un agradable viaje a <city>."),

		( "Por favor, haga clic <me> 's portal y se llega a <city>."),

		( "No interrumpa <me> ahora porque est\195\161 ocupado <me2> la apertura de un portal de <city>."),

		( "<city> abre en 10 segundos, tienen un agradable viaje."),

		( "No interrumpa <me> ahora porque est\195\161 ocupado <me2> la apertura de un portal de <city>."),
	};
    
    ARCANUM_MOUNT_MESSAGES = {
        ( "Mi pie derecho est\195\161 celoso de mi pie izquierdo. Cuando uno delante y el otro quiere superar. Y yo como un tonto, estoy caminando ... y usted, mi montura?"),

        ( "El tiempo es dinero. Corre r\195\161pido para ponerse al d�a"),

		( "No es un pie, estoy cansado"),
    };
    ARCANUM_RITUAL_MESSAGES = {
		( "Grupo saoulards! Quieres la binouze lo Grailler y, a continuaci\195\179n, haga clic en este portal y hacer po mierda!"),

		( "Ya no Pinard aqu�! Pero usted puede poner remedio! Haga clic en, por lo tanto, para que se haga cargo de Gerard!" ),
    };
end


if ( GetLocale() == "esES" ) then
	-- Table des sorts du mage
	ARCANUM_SPELL_TABLE = {
		["ID"] = {},
		["Rank"] = {},
		["Name"] = {
			"Armadura de Escarcha",						--1
			"Armadura de hielo",                    	--2
			"Armadura de mago",                   		--3
			"Armadura de arrabio",                  	--4
			"",
            "Atenuar magia",                   			--6
			"Amplificar magia",                     	--7
			"Crear comida",                       		--8
			"Crear agua",                        		--9
			"",
			"",
			"Intelecto Arcano",	                    	--12
			"Luminosidad Arcana",			        	--13
			"",
			"Teletransporte a: Darnassus",				--15
			"Teletransporte a: Forjaz",					--16
			"Teletransporte a: Ventormenta a",     		--17
            "Teletransporte a: El Exodar",        	 	--18
			"Teletransporte a: Orgrimmar",				--19
			"Teletransporte a: Cima del Trueno",		--20
			"Teletransporte a: Entra\195\177as",    	--21
            "Teletransporte a: Lunargenta",      		--22
			"Portal: Darnassus",						--23
			"Portal: Forjaz",					 		--24
			"Portal: Ventormenta",						--25
            "Portal: El Exodar",                    	--26
			"Portal: Orgrimmar",						--27
			"Portal: Cima del Trueno",					--28
			"Portal: Entra\195\177as",            		--29
            "Portal: Lunargenta",                   	--30
			"Teletransporte a: Dalaran",				--31
			"Portal: Dalaran",							--32
            "",
            "",
            "",
            "",			
            "Bloque de hielo",                      	--37
            "Mordedura de fr�o",                    	--38
            "Bandage",                              	--39
            "Teletransporte a: Shattrath",          	--40
            "Portal: Shattrath",                    	--41
            "Evocaci\195\179n",                     	--42
            "Ritual de refrigerio",              		--43
            "Teletransporte: Theramore",          		--44
			"Portal: Theramore",                    	--45
           	"Teletransporte a: Rocal",   				--46
			"Portal: Rocal",                       		--47
         	"Galleta de man\195\161 m\195\161gica", 	--48
			"Crear gema de man\195\161",       			--49
			"",                                     	--50		
			"",     									--51
			"",											--52
            "",      									--53
			"Polimorfia",                           	--54
            "Polimorfia: Cerda",                    	--55
            "Polimorfia Tortuga",                   	--56
			"Resguardo contra el Fuego",            	--57
            "Resguardo contra la Escarcha",         	--58
			"Barrera de hielo"                      	--59
			},
		["Mana"] = {},
        ["Texture"] = {},
	};
    
	Dest  = {"Darnassus", "Forjaz", "Ventormenta", "El Exodar", "Theramore", "Orgrimmar", "Cima del Trueno", "Entra\195\177as", "Lunargenta", "Rocal", "Shattrath", "Dalaran"};
	
    ARCANUM_PROFESSIONS = {
			["ID"] = {},
			["Name"] = {
               "Alquimia", 
			   "Sastrer�a", 
			   "Cocina", 
			   "Buscar hierbas", 
			   "Buscar minerales", 
			   "Desencantar", 
			   "Primeros auxilios", 
			   "Encantamiento", 
			   "Fundici�n", 
			   "Herrer�a", 
			   "Ingenier�a", 
			   "Joyer�a", 
			   "Prospectar", 
			   "Inscripci\195\179n",
			   "Pesca", 
			   "Desuello",
			   "Miner�a",
			   "Recolectar hierbas",
			   "Peleter�a"
			   },
				["Texture"] = {},
				};


    
	ARCANUM_MANAGEM = {
					   "�gata de man\195\161", 
	                   "Jade de man\195\161", 
					   "Citrino de man\195\161", 
					   "Rub� de man\195\161", 
					   "Esmeralda de man\195\161",
					   "Zafiro de man\195\161"
					   };
	
	ARCANUM_FOOD = {
					"Magdalena m\195\161gica", 
					"Pan m\195\161gico", 
					"Pan de centeno m\195\161gico", 
					"Pan integral de centeno m\195\161gico",
					"Pan de masa fermentada m\195\161gica", 
					"Bollo dulce m\195\161gico", 
					"Rollito de canela m\195\161gico", 
					"Cruas\195\161n m\195\161gico",
					"Galleta de man\195\161 m\195\161gica",
					"Tarta de man\195\161 m\195\161gica",
					"Strudel de man\195\161 m\195\161gico"
   					};
	
	 ARCANUM_WATER = {
					  "Agua m\195\161gica", 
					  "Agua dulce m\195\161gica", 
					  "Agua purificada m\195\161gica",
					  "Agua de manantial m\195\161gica", 
					  "Agua mineral m\195\161gica", 
					  "Agua con gas m\195\161gica 	", 
					  "Agua cristalina m\195\161gica", 
					  "Agua de manantial de monta�a m\195\161gica", 
					  "Agua de glaciar m\195\161gica",
					  "Galleta de man\195\161 m\195\161gica",
					  "Tarta de man\195\161 m\195\161gica",
					  "Strudel de man\195\161 m\195\161gico"
   					}; 
					
	ARCANUM_MANNE = {
                    "Galleta de man\195\161 m\195\161gica",
					"Tarta de man\195\161 m\195\161gica",
					"Strudel de man\195\161 m\195\161gico"
                    };			
    
    ARCANUM_BANDAGE = "Un bandage a \195\169t\195\169 appliqu\195\169 r\195\169cemment";
    
    ARCANUM_TRANSLATION = {
		["Mounting"] = "Invocaci�n de uno";
        ["Hearth"] = "Piedra de hogar";
		["Cooldown"] = "Hora";
		["Rank"] = "Fila";
	};
    
	-- Table des items du Mage
	ARCANUM_ITEM = {
		["ArcanePowder"] = "Part�culas Arcanas",
		["RuneOfTeleportation"] = "Runa de teletransporte",
		["RuneOfPortals"] = "Runa de portales",
		["LightFeathers"] = "Pluma ligera",
		["Hearthstone"] = "Piedra de hogar",
		["QuirajiMount"] = "Cristal de r\195\169sonance qiraji",
	};
	MOUNT = {
	
	    {"Cor du loup brun rapide", "Cor du loup de guerre noir", "Corne du loup brun", "Corne du loup des bois", "Corne du loup rouge"},
        {"R\195\170nes de sabre-de-nuit ray\195\169", "R\195\170nes de tigre de guerre noir"},
        {"Tigre zulien rapide"},
        {"Grand kodo blanc", "Kodo gris", "Grand kodo gris"},
        {"Kodo vert", "Kodo bleu"},
        {"Kodo brun", "Kodo de guerre noir", "Grand kodo brun"},
        {"Trotteur de bataille noir", "M\195\169canotrotteur bleu clair Mod A", "M\195\169canotrotteur blanc Mod A", "M\195\169canotrotteur blanc rapide", "M\195\169canotrotteur bleu", "M\195\169canotrotteur brut", "M\195\169canotrotteur jaune rapide", "M\195\169canotrotteur rouge", "M\195\169canotrotteur vert", "M\195\169canotrotteur vert rapide"},
        {"Destrier de bataille foudrepique", "B\195\169lier de givre", "B\195\169lier noir", "B\195\169lier blanc", "B\195\169lier blanc rapide", "B\195\169lier brun", "B\195\169lier brun rapide", "B\195\169lier gris", "B\195\169lier gris rapide", "B\195\169lier de guerre noir"},
        {"Bride de palefroi de guerre noir"},
        {"R�nes de sabre-de-givre de Berceau-de-l'Hiver"},
        {"Raptor bleu rapide", "Raptor orange rapide", "Raptor vert olive rapide", "Sifflet de Raptor ivoire", "Sifflet de Raptor rouge tachet\195\169", "Sifflet de raptor turquoise", "Sifflet de raptor violet", "Sifflet de raptor \195\169meraude", "Sifflet du raptor de guerre noir", "Raptor razzashi rapide"},
        {"Bride d'\195\169talon blanc", "Bride d'\195\169talon noir", "Bride de Palomino", "Bride de pinto", "Bride de jument alezane", "Bride de cheval bai", "Palefroi bai rapide", "Palefroi blanc rapide", "Palomino rapide"},
        {"R\195\170nes de destrier de la mort", "Cheval de guerre squelette rouge", "Cheval de guerre squelette vert", "Cheval de guerre squelette violet", "Cheval squelette bai", "Cheval squelette bleu", "Cheval squelette rouge"},
        {"Cor du loup redoutable", "Cor du loup des bois rapide", "Cor du loup gris rapide", "Corne du loup arctique", "Corne du loup sauvage"},
        {"R\195\170nes de sabre-de-givre ray\195\169", "R\195\170nes de sabre-de-givre mouchet\195\169", "R\195\170nes de sabre-de-givre rapide", "R\195\170nes de sabre-de-brume rapide", "R\195\170nes de sabre-temp\195\170te rapide"},
        {"Cor du hurleur Loup-de-givre"},
        {"Faucon-p\195\169r\195\169grin noir", "Faucon-p\195\169r\195\169grin rouge", "Faucon-p\195\169r\195\169grin bleu" ,"Faucon-p\195\169r\195\169grin violet"},
        {"Faucon-p\195\169r\195\169grin violet rapide", "Faucon-p\195\169r\195\169grin rose rapide", "Faucon-p\195\169r\195\169grin vert rapide"},
        {"Elekk marron", "Elekk violet", "Elekk gris", "Grand elekk bleu", "Grand elekk vert", "Grand elekk violet"},
        {"R\195\170nes de talbuk de guerre sombre", "R\195\170nes de talbuk de guerre argent\195\169", "R\195\170nes de talbuk de guerre cobalt", "R\195\170nes de talbuk de guerre brun", "R\195\170nes de talbuk de guerre blanc"},
        {"R\195\170nes de talbuk de monte sombre", "R\195\170nes de talbuk de monte brun", "R\195\170nes de talbuk de monte argent\195\169", "R\195\170nes de talbuk de monte cobalt", "R\195\170nes de talbuk de monte blanc"},
        {"Griffon d'\195\169b\195\168ne", "Griffon dor\195\169", "Griffon neigeux", "Griffon bleu rapide", "Griffon vert rapide", "Griffon violet rapide", "Coursier du vent violet rapide"},
        {"Coursier de vent fauve", "Coursier de vent vert", "Coursier de vent bleu", "Coursier de vent violet rapide", "Coursier de vent jaune rapide", "Coursier de vent rouge rapide", "Coursier de vent vert rapide"},
        {"Raie du N\195\169ant bleue", "Raie du N\195\169ant verte", "Raie du N\195\169ant rouge", "Raie du N\195\169ant violette", "Raie du N\195\169ant argent\195\169e"}, 
        {"R\195\170nes de cheval de guerre embras\195\169"},
        {"R\195\170nes du seigneur corbeau"},
        {"R\195\170nes de drake de l'Aile-du-N\195\169ant viride", "R\195\170nes de drake de l'Aile-du-N\195\169ant rapide", "R\195\170nes de drake de l'Aile-du-N\195\169ant azur", "R\195\170nes de drake de l'Aile-du-N\195\169ant cobalt", "R\195\170nes de drake de l'Aile-du-N\195\169ant onyx", "R\195\170nes de drake de l'Aile-du-N\195\169ant violet", "R\195\170nes de drake de l'Aile-du-N\195\169ant pourpre"}, 
        {"Hippogriffe de guerre c\195\169narien"},
	["Texture"] = {},
		};
    MOUNT_SPEED = "Augmente la vitesse de (%d+)%%.";
		
	MOUNT_PREFIX = {"R\195\170nes de ", "Sifflet du ", "Corne du ", "Cor du ", "Bride de ", "Bride d'"};
    
    QIRAJ_MOUNT = {"Cristal de r\195\169sonance qiraji jaune",
        "Cristal de r\195\169sonance qiraji rouge",
        "Cristal de r\195\169sonance qiraji vert",
        "Cristal de r\195\169sonance qiraji bleu",
        "Cristal de r\195\169sonance qiraji noir",
         };
    ARCANUM_MONTURE = {
	[1] = {	17460,	--"B�lier de givre"
		29467,	--"B�lier de guerre noir"
		17461,	--"B�lier noir"
		6898,	--"B�lier blanc"
		6899, 	--"B�lier brun"
		43899,	--"B�lier de la f�te des Brasseurs"
		6777,	--"B�lier gris"
		6897,	--"B�lier bleu"
--Chevaux		
		5656, 	--"Cheval bai"	
		6648, 	--"Jument alezane"
		8980,	--"Cheval squelette"
		17464,	--"Cheval squelette bai"
		17463,	--"Cheval squelette bleu"
		17462,	--"Cheval squelette rouge"
		48025,	--"Monture du Cavalier sans t�te"--Varie selon la competence de monte.
--Bride
		12353,	--"Bride d'�talon blanc"
		29468,	--"Bride de palefroi de guerre noir"
		18241,	--"Bride de palefroi de guerre noir"
		2411, 	--"Bride d'�talon noir"
		5656, 	--"Bride de cheval bai"
		471,	--"Palomino"
		472,	--"Pinto"
		2414, 	--"Bride de pinto"
--Elekk
		34406,	--"Elekk brun"
		35710,	--"Elekk gris"
		35711,	--"Elekk violet"
--Etalon
		16083,	--"Etalon blanc"	
		470,	--"Etalon noir"
--Faucon
		35020,	--"Faucon-p�r�grin bleu"
		35022,	--"Faucon-p�r�grin noir"
		37795,	--"Faucon-p�r�grin rouge"
		35018,	--"Faucon-p�r�grin violet"
--Grand ours
		58983,	--"Grand ours du Blizzard"--Varie selon la Competence de monte.
--Kodo
		18990,	--"Kodo brun"
		18989,	--"Kodo gris"
		18363,	--"Kodo de monte"
		50869,	--"Kodo de la f�te des Brasseurs"
		49378,	--"Kodo de la f�te des Brasseurs"
--Loup
		6654,	--"Loup brun"
		580,	--"Loup des bois"
		459,	--"Loup gris"
		578,	--"Loup noir"
		6653,	--"Loup redoutable"
--M�canotrotteur
		15781,	--"M�canotrotteur acier"
		10979,	--"M�canotrotteur bleu"
		33630,	--"M�canotrotteur bleu"
		17454,	--"M�canotrotteur brut"
		10873,	--"M�canotrotteur rouge"
		10456,	--"M�canotrotteur rouge et bleu"
		15780,	--"M�canotrotteur vert"
		17453,	--"M�canotrotteur vert"
		17458,	--"M�canotrotteur vert fluorescent"
		17455,	--"M�canotrotteur violet"
--Raptor
		8395,	--"Raptor �meraude"
		10795,	--"Raptor ivoire"
		10798,	--"Raptor obsidienne"
		10796,	--"Raptor turquoise"
		10799,	--"Raptor violet"
--Sabre
		8394,	--"Sabre-de-givre ray�"
		10789,	--"Sabre-de-givre tachet�"
		10793,	--"Sabre-de-nuit ray�"
--Tigre
		16060,	--"Tigre � dents de sabre dor�"
		16059,	--"Tigre � dents de sabre fauve"
		42776,	--"Tigre spectral"
--Tortue	
		30174,	--"Tortue de monte"
--AQ
		26656,	--"Char d'assaut qiraji noir"
		25953,	--"Char d'assaut qiraji bleu "
		26055,	--"Char d'assaut qiraji jaune"
		26054,	--"Char d'assaut qiraji rouge"
		26056,	--"Char d'assaut qiraji vert"
--B�lier
		23240,	--"B�lier blanc rapide"
		23238,	--"B�lier brun rapide"
		43900,	--"B�lier de la f�te des Brasseurs rapide"
		17460,	--"B�lier de givre"
		22720,	--"B�lier de guerre noir"
		23239,	--"B�lier gris rapide"
		17461,	--"B�lier noir"
--Chevaux		
		22722,	--"Cheval de guerre squelette rouge"
		17465,	--"Cheval de guerre squelette vert"
		23246,	--"Cheval de guerre squelette violet"
		16082,	--"Palomino"
		23227,	--"Palomino rapide"
--Destrier
		23510,	--"Destrier de bataille foudrepique"	
--Elekk
		48027,	--"Elekk de guerre noir"
		47037,	--"Elekk de guerre rapide"
--Faucon	
		35028,	--"Faucon de guerre rapide"
		46628,	--"Faucon-p�r�grin blanc rapide"
		33660,	--"Faucon-p�r�grin rose rapide"
		35025,	--"Faucon-p�r�grin vert rapide"
		35027,	--"Faucon-p�r�grin violet rapide"
--Grand Elekk
		35713,	--"Grand elekk bleu"
		35712,	--"Grand elekk vert"
		35714,	--"Grand elekk violet"
		34407,	--"Grand elekk d'�lite"
--Grand Kodo
		23247,	--"Grand kodo blanc"
		23249,	--"Grand kodo brun"
		23248,	--"Grand kodo gris"
		49379,	--"Grand kodo de la f�te des Brasseurs"
--Grand Mamouth	
		59810,	--"Grand mammouth de guerre noir"
		59811,	--"Grand mammouth de guerre noir"
		61467,	--"Grand mammouth de guerre noir"
		61465,	--"Grand mammouth de guerre noir"
		60140,	--"Grand mammouth de caravane"
		60136,	--"Grand mammouth de caravane"
		59802,	--"Grand mammouth des glaces"
		59804,	--"Grand mammouth des glaces"
--Hurleur
		23509,	--"Hurleur Loup-de-givre"	
--Karazhan
		36702,	--"Cheval de guerre flamboyant"
--Kodos
		18992,	--"Kodo bleu"
		22718,	--"Kodo de guerre noir"
		18991,	--"Kodo vert"
--Loup
		16081,	--"Loup blanc"
		23250,	--"Loup brun rapide"
		22724,	--"Loup de guerre noir"
		23251,	--"Loup des bois rapide"
		23252,	--"Loup gris rapide"
		16080,	--"Loup rouge"
--Mamouth
		59785,	--"Mammouth de guerre noir"
		59788,	--"Mammouth de guerre noir"
		61425,	--"Mammouth de voyage de la toundra"
		61447,	--"Mammouth de voyage de la toundra"
		59797,	--"Mammouth des glaces"
		59799,	--"Mammouth des glaces"
		59791,	--"Mammouth laineux"
		59793,	--"Mammouth laineux"
--M�cab�cane (horde)		
		55531,	--"M�cab�cane"
--M�canotrotteur
		15779,	--"M�canotrotteur blanc mod�le B"
		23223,	--"M�canotrotteur blanc rapide"
		17459,	--"M�canotrotteur bleu clair mod�le A"
		23222,	--"M�canotrotteur jaune rapide"
		23225,	--"M�canotrotteur vert rapide"
		22719,	--"Trotteur de bataille noir"
--Ours
		54753,	--"Monture ours polaire blanc"
		43688,	--"Ours de guerre amani"
		51412,	--"Gros ours de combat"
		60114,	--"Ours brun cuirass�"
		60116,	--"Ours brun cuirass�"
		60118,	--"Ours noir de guerre"
		60119,	--"Ours noir de guerre"
		59573,	--"Ours polaire brun"
		59572,	--"Ours polaire noir"
--Palefroi
		23229,	--"Palefroi bai rapide"
		23228,	--"Palefroi blanc rapide"
		22717,	--"Palefroi de guerre noir"
--Raptor
		23241,	--"Raptor bleu rapide"
		23243,	--"Raptor orange rapide"
		24242,	--"Raptor razzashi rapide"
		23242,	--"Raptor vert olive rapide"
		16084,	--"Raptor chamar� rouge"
		22721,	--"Raptor de guerre noir"
		17450,	--"Raptor ivoire"
--Sabre 
		16056,	--"Ancien R�nes de sabre" 
		23219,	--"Sabre-de-brume rapide"
		17229,	--"Sabre-de-givre de Berceau-de-l'Hiver"
		23221,	--"Sabre-de-givre rapide"
		23220,	--"Sabre-de-l'aube rapide"
		16055,	--"Sabre-de-nuit noir"
		23338,	--"Sabre-temp�te rapide"
--Seigneur
		41252,	--"Seigneur corbeau"
--Naxxramas		
		29059,	--"Destrier de la mort de Naxxramas"	
--Stratholme
		17481,	--"R�nes de destrier de la mort"		
--Talbuk	,
		37898,	--"Talbuk de guerre argent�"
		34897,	--"Talbuk de guerre blanc"
		34899,	--"Talbuk de guerre brun"
		34896,	--"Talbuk de guerre cobalt"
		34790,	--"Talbuk de guerre sombre"
		39317,	--"Talbuk de monte argent�"
		39319,	--"Talbuk de monte blanc"
		39318,	--"Talbuk de monte brun"
		39315,	--"Talbuk de monte cobalt"
		39316,	--"Talbuk de monte sombre"
--Tigre	
		22723,	--"Tigre de guerre noir"
		42777,	--"Tigre spectral rapide"
		24252,	--"Tigre zulien rapide"
--Zh�vra		
		48954,	--"Zh�vra rapide"
		49322,	--"Zh�vra rapide"
--Coursier		
		32244,	--"Coursier du vent bleu"
		32243,	--"Coursier du vent fauve"
		32245,	--"Coursier du vent vert"
--Fus�e
		46197,	--"Fus�e-de-n�ant X-51"
--Griffons	
		32239,	--"Griffon d'�b�ne"
		32235,	--"Griffon dor�"
		32240,	--"Griffon neigeux"
--Machine volante
		44153,	--"Machine volante"
--Hyppogriffe
		43927,	--"Hippogriffe de guerre c�narien"
--Drake
		60025,	--"Drake albino"
		59567,	--"Drake azur"
		59568,	--"Drake bleu"
		59650,	--"Drake noir"
		59570,	--"Drake rouge"
		59571,	--"Drake cr�pusculaire"
		59569,	--"Drake de bronze"
		41514,	--"Drake de l'Aile-du-N�ant azur"
		41515,	--"Drake de l'Aile-du-N�ant cobalt"
		41513,	--"Drake de l'Aile-du-N�ant onyx"
		41518,	--"Drake de l'Aile-du-N�ant pourpre"
		41516,	--"Drake de l'Aile-du-N�ant violet"
		41517,	--"Drake de l'Aile-du-N�ant viride"
		44744,	--"Drake de N�ant impitoyable"
--Fus�e		
		46199,	--"Fus�e-de-n�ant X-51 X-TREME"
--Griffons
		32242,	--"Griffon bleu rapide"
		32289,	--"Griffon rouge rapide"
		32290,	--"Griffon vert rapide"
		32292,	--"Griffon violet rapide"
		61229,	--"Griffon neigeux cuirass�"
		
		
--Coursier
		61230,	--"Coursier du vent bleu capara�onn�"
		32296,	--"Coursier du vent jaune rapide"
		32246,	--"Coursier du vent rouge rapide"
		32295,	--"Coursier du vent vert rapide"
		32297,	--"Coursier du vent violet rapide"
--Machine volante
		44151,	--"Machine volante � turbo-injection"
--Proto	
		59996,	--"Proto-drake bleu"
		59976,	--"Proto-drake noir"
		60002,	--"Proto-drake perdu dans le temps"
		59961,	--"Proto-drake rouge"
		61294,	--"Proto-drake vert"
--Raie
		39802,	--"Raie du N�ant argent�e"
		39803,	--"Raie du N�ant bleue"
		39800,	--"Raie du N�ant rouge"
		39798,	--"Raie du N�ant verte"
		39801,	--"Raie du N�ant violette"
--Tapis	
		61442,	--"Tapis en �toffe lunaire rapide"
		61446,	--"Tapis en feu-sorcier rapide"
		61444,	--"Tapis en tisse-ombre rapide"
		61451,	--"Tapis volant"
		61309,	--"Tapis volant magnifique"
--Wyrm
		51960,	--"Monture wyrm de givre"
		43810,	--"Wyrm de givre"
--L'oeil
		40192,	--"Cendres d'Al'ar"	
--Drake
		34092,	--"Drake du N�ant impitoyable"
		36676,	--"Drake du N�ant vengeur"		
		3363,	--"Drake du N�ant"
		58615,	--"Drake du N�ant brutal"
		37015,	--"Drake du N�ant rapide"
		49193,	--"Drake du N�ant vengeur"
--Ph�nix
		32345,	--"Monture Piou-piou le Ph�nix"
--Palefroi		
		59780,	--"Palefroi ail� de la Lame d'�b�ne"--Varie selon la competence de monte
--Proto
		60021,	--"Proto-drake perdu dans le temps"
		60024,	--"Proto-drake pourpre"
		},
	["Name"] = {},
	["Icon"] = {},
	["ID"] = {},
	};
	
end
