﻿-------------------------------------------------------------------------------------------------------
-- Arcanum

-- Addon pour Mage inspiré du célébre Necrosis
-- Gestion des buffs, des portails et Compteur de Composants

-- Remerciements aux auteurs de Necrosis

-- Auteur Lenny415 repris par Erina

-- Serveur:
-- Vol'Jin
------------------------------------------------------------------------------------------------------


ArcanumData = {};
ArcanumData.Version = "3.3.0";
ArcanumData.Author = "Erina Vol'Jin FR";
ArcanumData.AppName = "Arcanum";
ArcanumData.Label = ArcanumData.AppName.." "..ArcanumData.Version.." by "..ArcanumData.Author;