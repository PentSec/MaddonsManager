﻿------------------------------------------------------------------------------------------------------
-- Arcanum

-- Addon pour Mage inspiré du célébre Necrosis
-- Notes: Arcanum Handles the Mage Spells and Buff.

-- Remerciements aux auteurs de Necrosis

-- Auteur Lenny415 Repris par Erina

-- Serveur:
-- Vol'Jin
------------------------------------------------------------------------------------------------------

function Arcanum_Localization_Dialog_En()
	function ArcanumLocalization()
		Arcanum_Localization_Speech_En();
	end
	-- Raccourcis claviers
	BINDING_HEADER_ARCANUM_BIND = "Arcanum";
    BINDING_NAME_ACTIVATE = "Activate/D\195\169activate Arcanum";
	BINDING_NAME_STEED = "Steed";
	BINDING_NAME_FROSTARMOR = "Ice Armor";
	BINDING_NAME_MAGEARMOR = "Mage Armor";
    BINDING_NAME_FIREARMOR = "Molten Armor";
	BINDING_NAME_ARCANEINTELLECT = "Arcane Intellect";
	BINDING_NAME_ARCANEBRILLIANCE = "Arcane Brilliance";
	BINDING_NAME_AMPLIFYMAGIC = "Amplify Magic";
	BINDING_NAME_DAMPENMAGIC = "Dampen Magic";
	BINDING_NAME_CONJUREFOOD = "Conjure Food";
	BINDING_NAME_USEFOODWATER = "Eating & Drinking";
	BINDING_NAME_USEFOOD = "Eating";
	BINDING_NAME_CONJUREWATER = "Conjure Water";
	BINDING_NAME_USEWATER = "Drinking";
	BINDING_NAME_CONJUREMANAGEM = "Conjure a mana Gem";
	BINDING_NAME_USEMANAGEM = "Using a mana gem";
	BINDING_NAME_EVOCATION = "Evocation";
	BINDING_NAME_TELEPORT1 = "Teleport 1";
	BINDING_NAME_TELEPORT2 = "Teleport 2";
	BINDING_NAME_TELEPORT3 = "Teleport 3";
    BINDING_NAME_TELEPORT4 = "Teleport 4";
	BINDING_NAME_TELEPORT5 = "Teleport 5";
	BINDING_NAME_TELEPORT6 = "Teleport 6";
	BINDING_NAME_TELEPORT7 = "Teleport 7";
	BINDING_NAME_PORTAL1 = "Portal 1";
	BINDING_NAME_PORTAL2 = "Portal 2";
	BINDING_NAME_PORTAL3 = "Portal 3";
    BINDING_NAME_PORTAL4 = "Portal 4";
	BINDING_NAME_PORTAL5 = "Portal 5";
	BINDING_NAME_PORTAL6 = "Portal 6";
	BINDING_NAME_PORTAL7 = "Portal 7";	
	BINDING_NAME_PORTAL8 = "Portal 8";	
    BINDING_NAME_WARD1 = "Fire Ward";
	BINDING_NAME_WARD2 = "Frost Ward";
	
	
	ARCANUM_CONFIGURATION = {
		["Menu1"] = "Messages",
		["MessageMenu1"] = "Player :",
		["Tooltip0"] = "No Tooltip",
		["Tooltip1"] = "Partial Tooltips",
		["Tooltip2"] = "Full Tooltips",
		["ChatType"] = "Messages = System messages",
		["PortalMessage"] = "Show messages when summoning a portal",
        ["MountMessage"] = "Show messages when summoning a mount",
        ["ArcanumButtonDisplay"] = "Display inside the sphere :",
        ["InsideDisplay"] = "Display inside the sphere:",
        ["DisplayHearthStone"] = "HearthStone",
        ["DisplayManaGem"] = "ManaGem",
        ["DisplayEvocation"] = "Evocation",
        ["DisplayIceBlock"] = "IceBlock",
        ["DisplayColdSnap"] = "ColdSnap",
        ["DisplayIntell"] = "Intell",
        ["DisplayArmor"] = "Armor",
        ["DisplayBandage"] = "Bandage",
        ["Bindings"] = "Bindings",
				
		["Menu2"] = "Misc.",
		["LevelBuff"] = "Buff the target depending on his level",
		["EvocationLimit"] = "Mana percentage Evocation can be casted",
        ["ConsumeFood"] = "Consume Water/Food starting by",
        ["ConsumeGems"] = "Consume Gems starting by",
        ["RandMount"] = "Summon a mount randomly",
        ["DeleteFood"] = "Delete conjured food",
		["DeleteWater"] = "Delete conjured water",
		["DeleteManaGem"] = "Delete conjured mana gems",
		
		["Menu3"] = "Reagent Auto buy",
		["ReagentSort"] = "Sort reagents in same bag",
		["ReagentBag"] = "Reagent bag",
		["ReagentBuy"] = "Auto buy reagents",
		["Reagent"] = "Reagent Maximum quantity in bags:",
		["Powder"] = "Arcane Powder",
		["Teleport"] = "Rune of Teleportation",
		["Portal"] = "Rune of Portals",
		
		["Menu4"] = "Graphical Settings",
		["Toggle"] = "Activate Arcanum",
        ["InterfaceVersion"] = "Arcanum with menus",
		["InterfaceVersion2"] = "Arcanum without menus",
		["Lock"] = "Lock Arcanum",
		["IconsLock"] = "Lock Arcanum Buttons",
		["ArcanumRotation"] = "Rotate Arcanum",
		["ArcanumSize"] = "Size of Arcanum",
        ["ButtonSize"] = "Size of buttons",
		
		["Menu5"] = "Buttons",
        ["Button"] = "Show button of:",
        ["Order"] = "Change buttons order:",
		["BuffButton"] = "Buffs",
		["ArmorButton"] = "Armors",
		["MagicButton"] = "Magic",
		["PortalButton"] = "Portals",
		["MountButton"] = "Mount",
		["FoodButton"] = "Food",
		["WaterButton"] = "Water",
		["ManaGemButton"] = "Mana gem",
        ["JobButton"] = "Professions",
        ["WardButton"] = "Wards",
        ["MinimapIcon"] = "Show minimap icon",
        ["ArcanumMinimapIconPos"] = "Minimap icon position:",
        
        ["Menu6"] = "Menus",
		["MenuPosition"] = "Menu Opening ways:",
		["BuffMenu"] = "Buffs:",
		["ArmorMenu"] = "Armors:",
		["MagicMenu"] = "Magic:",
		["PortalMenu"] = "Portals:",
        ["MountMenu"] = "Mounts:",
        ["JobMenu"] = "Professions:",
        ["WardMenu"] = "Wards:",
        ["MenuScale"] = "Menus size",
		["MenuPosition"] = "Menus position",
        
        ["Menu7"] = "Skins",
        ["HealthColor"] = "Health bar color",
        ["ManaColor"] = "Mana bar color",
        ["ButtonColor"] = "Mouseover buttons color",
        ["DisplayHealthMana"] = "Display Health/Mana bars",
	};
	
    ARCANUM_CLICK = {
        "Evocation",
        "Eating & Drinking",
        "Switch solo/group mode",
        "Configuration panel",
        "Mana gems",
        "Ice block",
        "Hearthstone",
        "Sheeping",
    };
    
    ARCANUM_INSIDE_DISPLAY = {
        "Health numeric",
        "Health %",
        "Mana numeric",
        "Mana %",
        "Evocation CD",
        "Nothing",
    };
    
    ARCANUM_MENU_POS = {
        "Right",
        "Left",
        "Up",
        "Down",
    };
    
    ARCANUM_CONSUME_FOOD = {
        "The left bag",
        "The right bag",
    };
    
    ARCANUM_CONSUME_GEMS = {
        "The highest one",
        "The lowest one",
    };

	ARCANUM_TOOLTIP_DATA = {
	["LastSpell"] = "Left click to cast",
    ["LastSpell2"] = "Middle click to cast",
        ["SpellTimer"] = {
			Label = "Spell Durations",
			Text = "Active Spells on the target",
			Right = "<white>Right Click for Hearthstone to "
        };
	};
	
    ARCANUM_BINDING = {
		["Current"] = "Is currently bound to ",
		["Confirm"] = "Do you want to bind ",
		["To"] = "To",
		["Yes"] = "Yes",
		["No"] = "No",
		["InCombat"] = "Sorry, you can't change key bindings while in combat.",
		["Binding"] = "Bindings",
		["Unbind"] = "Unbind",
		["Cancel"] = "Cancel",
		["Press"] = "Press a key to bind...\n\n",
		["Now"] = "Currently: ",
		["NotBound"] = "Not Bound",
	};
    
	ARCANUM_MESSAGE = {
	  	["Interface"] = {
	    	["InitOn"] = "<white>activated. /arcanum or /arca to show the Configuration window",
	    	["InitOff"] = "<white>deactivated. /arca",
			["DefaultConfig"] = "<lightYellow>Default configuration loaded.",
			["UserConfig"] = "<lightYellow>Configuration loaded."
		},
	  	["Tooltip"] = {
	   		["LeftClick"] = "Left Click: ",
			["MiddleClick"] = "Middle Click: ",
	    	["RightClick"] = "Right Click: ",
	 		["Cooldown"] = "Hearthstone available in ",
            ["Minimap"] = "Configuration panel",
	  	},
		["Error"] = {
	  		["NoHearthstone"] = "No Hearthstone has been found in inventory.",
      		["NoMount"] = "No mount has been found in inventory.",
		},
		["Autobuy"] = "Buying ",
	};
end

function Arcanum_Localization_Speech_En()
	ARCANUM_PORTAL_MESSAGES = {
		{"The <me> Airline Company wishes you an enjoyable trip to <city>."},
		
		{"Please click <me>'s portal and you will arrive at <city>."},
		
		{"Don't interrupt <me> now because <me2> is busy opening a portal to <city>."},
		
		{"<city> is opening in 10 seconds, have a nice journey."},
		
		{"Don't interrupt <me> now because <me2> is busy opening a portal to <city>."},
		};
    
    ARCANUM_MOUNT_MESSAGES = {
        {"My right foot is jealous of my left foot. When one advance, the other wants exceed it. And I as a fool, I walk!... and thee, my mount?"},

        {"The time is money. Are quickly to catch up"},
		
		{"Not off, I am tired"},
        };
	
	ARCANUM_RITUAL_MESSAGES = {
		{"Gaza saoulards! You want to the binouze and what grailler? So click on the portal!"},
		
		{"Y' has no pinard here! But there you can remedier! Click for a takeover by Gerard!" }, 
    };
end

if ( GetLocale() == "enUS" ) or ( GetLocale() == "enGB" ) then
	-- Table des sorts du mage
	ARCANUM_SPELL_TABLE = {
		["ID"] = {},
		["Rank"] = {},
		["Name"] = {
			"Frost Armor",										--1
			"Ice Armor",                      					--2
			"Mage Armor",                   					--3
			"Molten Armor",                                     --4
			"",
            "Dampen Magic",                  					--6
			"Amplify Magic",                        			--7
			"Conjure Food",                       				--8
			"Conjure Water",                        			--9
			"",
			"",
			"Arcane Intellect",			                		--12
			"Arcane Brilliance",	                        	--13
			"",
			"Teleport: Darnassus",								--15
			"Teleport: Ironforge",								--16
			"Teleport: Stormwind",         						--17
            "Teleport: Exodar",                                	--18
			"Teleport: Orgrimmar",								--19
			"Teleport: Thunder Bluff",							--20
			"Teleport: Undercity",         						--21
            "Teleport: Silvermoon",                            	--22
			"Portal: Darnassus",								--23
			"Portal: Ironforge",					 			--24
			"Portal: Stormwind",								--25
            "Portal: Exodar",                                  	--26
			"Portal: Orgrimmar",								--27
			"Portal: Thunder Bluff",					 		--28
			"Portal: Undercity",	           					--29
            "Portal: Silvermoon",                              	--30
			"Teleport: Dalaran",
            "Portal: Dalaran",
			"",
            "",
			"",
			"",
            "Ice Block",                                        --37
            "Cold Snap",                                        --38
            "Bandage",                                          --39
            "Teleport: Shattrath",                              --40
            "Portal: Shattrath",                                --41
            "Evocation",            							--42
			"Ritual of Refreshment",                            --43
            "Teleport: Theramore",								--44
			"Portal: Theramore",                                --45
            "Teleport: Stonard",                            	--46
			"Portal: Stonard",                                  --47
            "Conjured Manna Biscuit",                           --48
			"Conjure Mana Gem",  	     						--49
			"",					                   			 	--50		
			"",                 								--51
			"",				    								--52
            "",                             					--53
			"Polymorph",                                        --54
            "Polymorph : Pig",                                  --55
            "Polymorph : Turtle",                               --56
			"Fire Ward",                                        --57
            "Frost Ward",                                       --58
			"Ice Barrier"                                       --59
			},
		["Mana"] = {},
        ["Texture"] = {},
	};
    
	Dest  = {"Darnassus", "Ironforge", "Stormwind", "Exodar", "Theramore", "Orgrimmar", "Thunder Bluff", "Undercity", "Silvermoon", "Stonard", "Shattrath", "Dalaran"};
	
    ARCANUM_PROFESSIONS = {
    ["ID"] = {},
    ["Name"] = {
	            "Alchemy", 
				"Blacksmithing", 
				"Enchanting", 
				"Engineering", 
				"Find Herbs", 
				"Find Minerals", 
				"Herb Gathering", 
				"Inscription", 
				"Jewelcrafting", 
				"Leatherworking", 
				"Mining", 
				"Skinning", 
				"Smelting", 
				"Tailoring", 
				"Disenchant",
				"Prospecting",
				"Cooking",
				"First Aid",
				"Fishing"
				},
    ["Texture"] = {},
    };
    
	ARCANUM_MANAGEM = {
	                   "Mana Agate", 
					   "Mana Jade", 
					   "Mana Citrine", 
					   "Mana Ruby", 
					   "Mana Emerald",
					   "Mana Sapphire"
					   };
	
	ARCANUM_FOOD = {
	               "Conjured Muffin", 
				   "Conjured Bread", 
				   "Conjured Rye", 
				   "Conjured Pumpernickel",
	               "Conjured Sourdough", 
				   "Conjured Sweet Roll", 
				   "Conjured Cinnamon Roll", 
				   "Conjured Croissant",
				   "Conjured Manna Biscuit",
				   "Conjured Mana Pie",
				   "Conjured Mana Strudel"
				   };
	
	ARCANUM_WATER = {
	                "Conjured Water", 
					"Conjured Fresh Water", 
					"Conjured Purified Water",
	                "Conjured Spring Water", 
					"Conjured Mineral Water", 
					"Conjured Sparkling Water", 
					"Conjured Crystal Water", 
					"Conjured Mountain Spring Water", 
					"Conjured Glacier Water",
					"Conjured Manna Biscuit",
					"Conjured Mana Pie",
					"Conjured Mana Strudel"
					};
					
	ARCANUM_MANNE = {
				["ID"] = {},
				["Name"] = {
                    "Conjured Manna Biscuit",
					"Conjured Mana Pie",
					"Conjured Mana Strudel"
				},	
				["Texture"] = {},
                };							
	
    ARCANUM_BANDAGE = "A bandage was applied recently";
    
    ARCANUM_TRANSLATION = {
		["Mounting"] = "Summoning",
        ["Hearth"] = "Hearthstone";
		["Cooldown"] = "Cooldown",
		["Rank"] = "Rank",
	};
    
	-- Table des items du Mage
	ARCANUM_ITEM = {
		["ArcanePowder"] = "Arcane Powder",
		["RuneOfTeleportation"] = "Rune of Teleportation",
		["RuneOfPortals"] = "Rune of Portals",
		["LightFeathers"] = "Light Feather",
		["Hearthstone"] = "Hearthstone",
		["QuirajiMount"] = "Quiraji Resonating Crystal",
	};
    
	-- Monture	
	MOUNT = {
	    {"Horn of the Black War Wolf", "Horn of the Brown Wolf", "Horn of the Red Wolf", "Horn of the Swift Brown Wolf", "Horn of the Timber Wolf"},
		{"Reins of the Striped Nightsaber", "Reins of the Black War Tiger"},
		{"Swift Zulian Tiger"},
		{"Gray Kodo", "Great Gray Kodo", "Great White Kodo"},
		{"Green Kodo", "Teal Kodo"},
		{"Black War Kodo", "Brown Kodo", "Great Brown Kodo"},
		{"Black Battlestrider", "Blue Mechanostrider", "Green Mechanostrider", "Icy Blue Mechanostrider Mod A", "Red Mechanostrider", "Swift Green Mechanostrider", "Swift White Mechanostrider", "Swift Yellow Mechanostrider", "Unpainted Mechanostrider", "White Mechanostrider Mod A"},
		{"Stormpike Battle Charger", "Black Ram", "Black War Ram", "Brown Ram", "Frost Ram", "Gray Ram", "Swift Brown Ram", "Swift Gray Ram", "Swift White Ram", "White Ram"},
		{"Black War Steed Bridle"},
		{"Reins of the Winterspring Frostsaber"},
		{"Whistle of the Black War Raptor", "Whistle of the Emerald Raptor", "Whistle of the Ivory Raptor", "Whistle of the Mottled Red Raptor", "Whistle of the Turquoise Raptor", "Whistle of the Violet Raptor", "Swift Olive Raptor", "Swift Orange Raptor", "Swift Blue Raptor", "Swift Razzashi Raptor"},
		{"Black Stallion Bridle", "Brown Horse Bridle", "Chestnut Mare Bridle", "Palomino Bridle", "Pinto Bridle", "Swift Brown Steed", "Swift Palomino", "Swift White Steed", "White Stallion Bridle"},
		{"Deathcharger's Reins", "Blue Skeletal Horse", "Brown Skeletal Horse", "Green Skeletal Warhorse", "Purple Skeletal Warhorse", "Red Skeletal Horse", "Red Skeletal Warhorse"},
		{"Horn of the Arctic Wolf", "Horn of the Dire Wolf", "Horn of the Swift Gray Wolf", "Horn of the Swift Timber Wolf"},
		{"Reins of the Frostsaber", "Reins of the Nightsaber", "Reins of the Spotted Frostsaber", "Reins of the Striped Frostsaber", "Reins of the Swift Frostsaber", "Reins of the Swift Mistsaber", "Reins of the Swift Stormsaber"},
		{"Horn of the Frostwolf Howler"},
        {"Black Hawkstrider", "Red Hawkstrider", "Blue Hawkstrider", "Purple Hawkstrider"},
        {"Swift Purple Hawkstrider", "Swift Pink Hawkstrider", "Swift Green Hawkstrider"},
        {"Brown Elekk", "Purple Elekk", "Gray Elekk", "Great Blue Elekk", "Great Green Elekk", "Great Purple Elekk"},
        {"Reins of the Dark War Talbuk", "Reins of the Silver War Talbuk", "Reins of the Cobalt War Talbuk", "Reins of the Tan War Talbuk", "Reins of the White War Talbuk"},
        {"Reins of the Dark Riding Talbuk", "Reins of the Tan Riding Talbuk", "Reins of the Silver Riding Talbuk", "Reins of the Cobalt Riding Talbuk", "Reins of the White Riding Talbuk"},
        {"Ebon Gryphon", "Golden Gryphon", "Snowy Gryphon", "Swift Blue Gryphon", "Swift Green Gryphon", "Swift Purple Gryphon", "Swift Red Gryphon"},
        {"Tawny Windrider", "Green Windrider", "Blue Windrider", "Swift Purple Windrider", "Swift Yellow Windrider", "Swift Red Windrider", "Swift Green Windrider"},
		{"Blue Riding Nether Ray", "Green Riding Nether Ray", "Red Riding Nether Ray", "Purple Riding Nether Ray", "Silver Riding Nether Ray"}, 
        {"Fiery Warhorse's Reins"},
        {"Reins of the Raven Lord"},
        {"Reins of the Veridian Netherwing Drake", "Reins of the Azure Netherwing Drake", "Reins of the Cobalt Netherwing Drake", "Reins of the Onyx Netherwing Drake", "Reins of the Violet Netherwing Drake", "Reins of the Purple Netherwing Drake"},
        {"Cenarion War Hippogryph"}	
	};  
    
    MOUNT_SPEED = "Increases speed by (%d+)%%.";

	MOUNT_PREFIX = {"Reins of the ", "Whistle of the ", "Horn of the ", "Bridle"};
		
	QIRAJ_MOUNT = {
		"Yellow Qiraji Resonating Crystal",
		"Red Qiraji Resonating Crystal",
	  	"Green Qiraji Resonating Crystal",
		"Blue Qiraji Resonating Crystal",
		"Black Qiraji Resonating Crystal"
	};
	
	ARCANUM_MONTURE = {
	--Wowhead 293
	[1] = {	17460,	--"Bélier de givre"
		29467,	--"Bélier de guerre noir"
		17461,	--"Bélier noir"
		6898,	--"Bélier blanc"
		6899, 	--"Bélier brun"
		43899,	--"Bélier de la fête des Brasseurs"
		6777,	--"Bélier gris"
		6897,	--"Bélier bleu"
--Bride
		12353,	--"Bride d'étalon blanc"
		29468,	--"Bride de palefroi de guerre noir"
		18241,	--"Bride de palefroi de guerre noir"
		2411, 	--"Bride d'étalon noir"
		5656, 	--"Bride de cheval bai"
		471,	--"Palomino"
		472,	--"Pinto"
		2414, 	--"Bride de pinto"
--Chevaux		
		5656, 	--"Cheval bai"	
		6648, 	--"Jument alezane"
		8980,	--"Cheval squelette"
		17464,	--"Cheval squelette bai"
		17463,	--"Cheval squelette bleu"
		17462,	--"Cheval squelette rouge"
		64977,  --"Cheval squelette noir"
		48025,	--"Monture du Cavalier sans tête"--Varie selon la competence de monte.
--Elekk
		34406,	--"Elekk brun"
		35710,	--"Elekk gris"
		35711,	--"Elekk violet"
--Etalon
		16083,	--"Etalon blanc"	
		470,	--"Etalon noir"
--Faucon
		35020,	--"Faucon-pérégrin bleu"
		35022,	--"Faucon-pérégrin noir"
		37795,	--"Faucon-pérégrin rouge"
		35018,	--"Faucon-pérégrin violet"
--Grand ours
		58983,	--"Grand ours du Blizzard"--Varie selon la Competence de monte.
--Kodo
		64657,	--"Kodo blanc"
		18990,	--"Kodo brun"
		18989,	--"Kodo gris"
		18363,	--"Kodo de monte"
		50869,	--"Kodo de la fête des Brasseurs"
		49378,	--"Kodo de monte de la fête des Brasseurs"
--Léopard
		16058,	--"Léopard primal"	
--Loup
		581,    --"Loup blanc"
		6654,	--"Loup brun"
		580,	--"Loup des bois"
		459,	--"Loup gris"
		578,	--"Loup noir"
		6653,	--"Loup redoutable"
		579,	--"Loup rouge"
--Mécanotrotteur
		15781,	--"Mécanotrotteur acier"
		10979,	--"Mécanotrotteur bleu"
		33630,	--"Mécanotrotteur bleu"
		17454,	--"Mécanotrotteur non peint"
		10873,	--"Mécanotrotteur rouge"
		10456,	--"Mécanotrotteur rouge et bleu"
		15780,	--"Mécanotrotteur vert"
		17453,	--"Mécanotrotteur vert"
		17458,	--"Mécanotrotteur vert fluorescent"
		17455,	--"Mécanotrotteur violet"
--Raptor
		8395,	--"Raptor émeraude"
		10795,	--"Raptor ivoire"
		10798,	--"Raptor obsidienne"
		10796,	--"Raptor turquoise"
		10799,	--"Raptor violet"
--Sabre
		8394,	--"Sabre-de-givre rayé"
		10789,	--"Sabre-de-givre tacheté"
		66847,	--"Sabre-de-l'aube rayé"
		10793,	--"Sabre-de-nuit rayé"
--Tigre
		16060,	--"Tigre à dents de sabre doré"
		16059,	--"Tigre à dents de sabre fauve"
		42776,	--"Tigre spectral"
--Tortue	
		30174,	--"Tortue de monte"
		64731,  --"Tortue de mer"
--AQ
		26656,	--"Char d'assaut qiraji noir"
		25953,	--"Char d'assaut qiraji bleu "
		26055,	--"Char d'assaut qiraji jaune"
		26054,	--"Char d'assaut qiraji rouge"
		26056,	--"Char d'assaut qiraji vert"
--Bélier
		23240,	--"Bélier blanc rapide"
		23238,	--"Bélier brun rapide"
		50870,	--"Bélier de la fête des Brasseurs rapide"
		17460,	--"Bélier de givre"
		22720,	--"Bélier de guerre noir"
		23239,	--"Bélier gris rapide"
		17461,	--"Bélier noir"
		65643,  --"Bélier pourpre rapide"
		63636,	--"Bélier de Forgefer"
--Chevaux	
		67466,	--"Cheval de guerre de l'Aube d'argent"
		68187,  --"Cheval de guerre blanc de croisé"
		68188,  --"Cheval de guerre noir de croisé"
		63643,  --"Cheval de guerre réprouvé"
		65645,	--"Cheval de guerre squelette blanc"
		64656,	--"Cheval de guerre squelette bleu"
		66846,	--"Cheval de guerre squelette ocre"
		22722,	--"Cheval de guerre squelette rouge"
		17465,	--"Cheval de guerre squelette vert"
		23246,	--"Cheval de guerre squelette violet"
		16082,	--"Palomino"
		23227,	--"Palomino rapide"
--Destrier
		23510,	--"Destrier de bataille foudrepique"	
--Elekk
		48027,	--"Elekk de guerre noir"
		47037,	--"Elekk de guerre rapide"
		47037,	--"Elekk de l'exodar"
--Faucon	
		61996,	--"Faucon-dragon bleu"
		62048,	--"Faucon-dragon de monte noir"
		61997,	--"Faucon-dragon rouge"
		66088,	--"Faucon-dragon saccage-soleil"
		35028,	--"Faucon de guerre rapide"
		46628,	--"Faucon-pérégrin blanc rapide"
		33660,	--"Faucon-pérégrin rose rapide"
		63642,	--"Faucon-pérégrin de Lune-d'argent"
		65639,	--"Faucon-pérégrin rouge rapide"
		66091,	--"Faucon-pérégrin saccage-soleil"
		35025,	--"Faucon-pérégrin vert rapide"
		35027,	--"Faucon-pérégrin violet rapide"
--Grand Elekk
		35713,	--"Grand elekk bleu"
		34407,	--"Grand elekk d'élite"
		65637,	--"Grand elekk rouge"
		35712,	--"Grand elekk vert"
		35714,	--"Grand elekk violet"
		
--Grand Kodo
		23247,	--"Grand kodo blanc"
		23249,	--"Grand kodo brun"
		49379,	--"Grand kodo de la fête des Brasseurs"
		65641,	--"Grand kodo doré"
		23248,	--"Grand kodo gris"
--Grand Mamouth	
		59810,	--"Grand mammouth de guerre noir"
		59811,	--"Grand mammouth de guerre noir"
		61467,	--"Grand mammouth de guerre noir"
		61465,	--"Grand mammouth de guerre noir"
		60140,	--"Grand mammouth de caravane"
		60136,	--"Grand mammouth de caravane"
		59802,	--"Grand mammouth des glaces"3P
		59804,	--"Grand mammouth des glaces"3P
		61469,	--"Grand mammouth des glaces"2P
		61470,	--"Grand mammouth des glaces"2P
--Hurleur
		23509,	--"Hurleur Loup-de-givre"	
--Karazhan
		36702,	--"Cheval de guerre flamboyant"
--Kodos
		18992,	--"Kodo bleu"
		22718,	--"Kodo de guerre noir"
		63641,	--"Kodo des pitons de tonnerre"
		18991,	--"Kodo vert"
--Loup
		16081,	--"Loup blanc"
		65646,	--"Loup bordeaux rapide"
		23250,	--"Loup brun rapide"
		63640,	--"Loup d'Orgrimmar"
		22724,	--"Loup de guerre noir"
		23251,	--"Loup des bois rapide"
		23252,	--"Loup gris rapide"
		68056,	--"Loup rapide de la Horde"
		16080,	--"Loup rouge"
--Mamouth
		59785,	--"Mammouth de guerre noir"
		59788,	--"Mammouth de guerre noir"
		61425,	--"Mammouth de voyage de la toundra"
		61447,	--"Mammouth de voyage de la toundra"
		59797,	--"Mammouth des glaces"
		59799,	--"Mammouth des glaces"
		59791,	--"Mammouth laineux"
		59793,	--"Mammouth laineux"
--Mécabécane (Horde)		
		55531,	--"Mécabécane"
--Mécabécane (Alliance)		
		60424,	--"Bécane de mekgénieur"		
--Mécanotrotteur
		15779,	--"Mécanotrotteur blanc modèle B"
		23223,	--"Mécanotrotteur blanc rapide"
		17459,	--"Mécanotrotteur bleu clair modèle A"
		63638,	--"Mécanotrotteur de gnomeregan"
		23222,	--"Mécanotrotteur jaune rapide"
		23225,	--"Mécanotrotteur vert rapide"
		22719,	--"Trotteur de bataille noir"
		65642,	--"Turbotrotteur"
--Naxxramas		
		29059,	--"Destrier de la mort de Naxxramas"		
--Ours
		54753,	--"Monture ours polaire blanc"
		43688,	--"Ours de guerre amani"
		51412,	--"Grand ours de combat"
		60114,	--"Ours brun cuirassé"
		60116,	--"Ours brun cuirassé"
		60118,	--"Ours noir de guerre"
		60119,	--"Ours noir de guerre"
		59573,	--"Ours polaire brun"
		59572,	--"Ours polaire noir"
--Palefroi
		23229,	--"Palefroi bai rapide"
		23228,	--"Palefroi blanc rapide"
		22717,	--"Palefroi de guerre noir"
		63232,	--"Palefroi de Hurlevent"
		65640,	--"Palefroi de gris rapide"
		66090,	--"Palefroi quel'dorei"
		68057,	--"Palefroi rapide de l'Alliance"
--Poulet
		65917,	--"Poulet magique"
		66122,	--"Poulet magique"
		66123,	--"Poulet magique"
		66124,	--"Poulet magique"	
--Raptor
		23241,	--"Raptor bleu rapide"
		16084,	--"Raptor chamaré rouge"
		22721,	--"Raptor de guerre noir"
		17450,	--"Raptor ivoire"
		23243,	--"Raptor orange rapide"
		24242,	--"Raptor razzashi rapide"
		63635,  --"Raptor sombrelance"
		23242,	--"Raptor vert olive rapide"
		65644,	--"Raptor violet rapide"
--Ravasaure
		64659,	--"Ravasaure peau-de-venin"	
--Sabre 
		16056,	--"Ancien sabre-de-givre" 
		23219,	--"Sabre-de-brume rapide"
		17229,	--"Sabre-de-givre de Berceau-de-l'Hiver"
		23221,	--"Sabre-de-givre rapide"
		23220,	--"Sabre-de-l'aube rapide"
		65638,	--"Sabre-de-lune rapide"
		63637,	--"Sabre-de-nuit darnassien"
		16055,	--"Sabre-de-nuit noir"
		23338,	--"Sabre-tempête rapide"
--Seigneur
		41252,	--"Seigneur corbeau"
--Stratholme
		17481,	--"Destrier de la mort de Vaillefendre"		
--Talbuk	,
		37898,	--"Talbuk de guerre argenté"
		34897,	--"Talbuk de guerre blanc"
		34899,	--"Talbuk de guerre brun"
		34896,	--"Talbuk de guerre cobalt"
		34790,	--"Talbuk de guerre sombre"
		39317,	--"Talbuk de monte argenté"
		39319,	--"Talbuk de monte blanc"
		39318,	--"Talbuk de monte brun"
		39315,	--"Talbuk de monte cobalt"
		39316,	--"Talbuk de monte sombre"
--Tigre	
		22723,	--"Tigre de guerre noir"
		42777,	--"Tigre spectral rapide"
		24252,	--"Tigre zulien rapide"
--Zhévra		
		48954,	--"Zhévra rapide"
		49322,	--"Zhévra rapide"
--Coursier		
		32244,	--"Coursier du vent bleu"
		32243,	--"Coursier du vent fauve"
		32245,	--"Coursier du vent vert"
--Fusée
		46197,	--"Fusée-de-néant X-51"
--Griffons	
		32239,	--"Griffon d'ébène"
		32235,	--"Griffon doré"
		32240,	--"Griffon neigeux"
--Machine volante
		44153,	--"Machine volante"
--Drake
		60025,	--"Drake albinos"
		59567,	--"Drake azur"
		59568,	--"Drake bleu"
		59650,	--"Drake noir"
		59570,	--"Drake rouge"
		59571,	--"Drake crépusculaire"
		59569,	--"Drake de bronze"
		41514,	--"Drake de l'Aile-du-Néant azur"
		41515,	--"Drake de l'Aile-du-Néant cobalt"
		41513,	--"Drake de l'Aile-du-Néant onyx"
		41518,	--"Drake de l'Aile-du-Néant pourpre"
		41516,	--"Drake de l'Aile-du-Néant violet"
		41517,	--"Drake de l'Aile-du-Néant viride"
		44744,	--"Drake de Néant impitoyable"
--Fusée		
		46199,	--"Fusée-de-néant X-51 X-TREME"
--Griffons
		32242,	--"Griffon bleu rapide"
		32289,	--"Griffon rouge rapide"
		32290,	--"Griffon vert rapide"
		32292,	--"Griffon violet rapide"
		61229,	--"Griffon neigeux cuirassé"
--Coursier
		61230,	--"Coursier du vent bleu caparaçonné"
		32296,	--"Coursier du vent jaune rapide"
		32246,	--"Coursier du vent rouge rapide"
		32295,	--"Coursier du vent vert rapide"
		32297,	--"Coursier du vent violet rapide"
--Hyppogriffe
		63844,	--"Hippogriffe d'Argent"
		43927,	--"Hippogriffe de guerre cénarien"
		66087,	--"Hippogriffe du Concordat argenté"
--Machine volante
		44151,	--"Machine volante à turbo-injection"
--Proto	
		59996,	--"Proto-drake bleu"
		59961,	--"Proto-drake rouge"
		61294,	--"Proto-drake vert"
		60021,	--"Proto-drake perdu dans le temps"
		60024,	--"Proto-drake pourpre"
--Raie
		39802,	--"Raie du Néant argentée"
		39803,	--"Raie du Néant bleue"
		39800,	--"Raie du Néant rouge"
		39798,	--"Raie du Néant verte"
		39801,	--"Raie du Néant violette"
--Tapis	
		61442,	--"Tapis en étoffe lunaire rapide"
		61446,	--"Tapis en feu-sorcier rapide"
		61444,	--"Tapis en tisse-ombre rapide"
		61451,	--"Tapis volant"
		61309,	--"Tapis volant magnifique"
--Wyrm
		51960,	--"Monture wyrm de givre"
		43810,	--"Wyrm de givre"
--L'oeil 310
		40192,	--"Cendres d'Al'ar"	
--Drake 310
		34092,	--"Drake du Néant impitoyable"
		36676,	--"Drake du Néant vengeur"		
		3363,	--"Drake du Néant"
		58615,	--"Drake du Néant brutal"
		37015,	--"Drake du Néant rapide"
		49193,	--"Drake du Néant vengeur"
--Phénix 310
		32345,	--"Monture Piou-piou le Phénix"
--Palefroi 310		
		59780,	--"Palefroi ailé de la Lame d'ébène"--Varie selon la competence de monte
--Proto 310
		63956,	--"Proto-drake enchaîné"	
		59976,	--"Proto-drake noir"
		60021,	--"Proto-drake Pestiféré"
		59976,	--"Proto-drake rouillée"	
--Tëte 310
		63769,	--"Tête de Mimiron"	
--Wyrm 310
		64927,	--"Wyrm de givre du gladiateur fatal"	
		65439,	--"Wyrm de givre du gladiateur furieux"
		67336,	--"Wyrm de givre du gladiateur implacable"
		},	
	["Name"] = {},
	["Icon"] = {},
	["ID"] = {},
};
	
end
