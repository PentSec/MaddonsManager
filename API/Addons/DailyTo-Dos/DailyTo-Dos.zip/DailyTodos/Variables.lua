﻿defaults = {
	global = {
		character = {},
		completedQuests = {},
    	acceptedQuests = {},
	},
	profile = {
  		showMinimapIcon = true,
  		-- Tracking window prefs --
  		showTrackingFrame = true,
  		--lockTrackingFrame = false,
  		showRep = false,
  		announceQuestCompletion = true,
  		announceMethod = 1,
  		filterProfQuests = true,
  		
            TrackingFramePos = {
  			[1] = 0,
  			[2] = 0,
  			[3] = "CENTER",
  			},
        
  		trackFactionsExpanded = {},
  		----------------------------
    	dailyheroic = false,
    	friendly = 1,
    	enemy = 2,
    	factionsTracking = {},
    	dontTrack = {},
    	acceptedQuests = {},
    	completedQuests = {},
    	acceptedQuests = {},
		hideInactiveQuests = false,
    	lastOpenDate = nil,
    	minimapIcon = { -- minimap icon position and visibility
			hide = false,
			minimapPos = 220,
			radius = 80,
		},
	}
}