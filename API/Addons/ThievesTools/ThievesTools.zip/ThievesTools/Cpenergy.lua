local L = TT_locale;
local modName = "ThievesTools";
local _ 
local _G = getfenv(0);
local select = _G.select;
local wipe = _G.wipe;
local t_sort = _G.table.sort;
local t_insert = _G.table.insert;
local tonum = _G.tonumber;
local tostr = _G.tostring
local strbyte = _G.string.byte
local strsub = _G.string.sub
local pairs	= _G.pairs

local ThievesTools;
if not ThievesTools then ThievesTools = _G.ThievesTools end;
if not ThievesTools.combopoints then ThievesTools.combopoints = {} end;



function ThievesTools:InitCombosEnergy()
	
	local cpframe = ThievesTools.frames.cpframe
	local cptexture = ThievesTools.frames.cptexture
	local cpshine = ThievesTools.frames.cpshine
	local cpoptions = ThievesTools.ap.cpoptions
	local combopoints = ThievesTools.combopoints
	local frames = ThievesTools.frames
	
	for i = 1,5 do
		combopoints[i] = {}
		combopoints[i].shown = false
		cptexture[i]:SetTexture(cpoptions.combotex)
		cptexture[i]:SetHeight(cpoptions.height)
		cptexture[i]:SetWidth(cpoptions.height)
		local posx = 0
		if i == 1 then posx = (0 - ((2 * cpoptions.spacing) + (2 * cpoptions.height))) end
		if i == 2 then posx = (0 - (cpoptions.spacing + cpoptions.height)) end
		if i == 4 then posx = ((cpoptions.spacing + cpoptions.height)) end
		if i == 5 then posx = (((2 * cpoptions.spacing) + (2 * cpoptions.height))) end
		if (cpoptions.combolarge5 == true) and i == 5 then
			posx = (((2 * cpoptions.spacing) + (2.2 * cpoptions.height)))
			cptexture[i]:SetHeight(1.4 * cpoptions.height)
			cptexture[i]:SetWidth(1.4 * cpoptions.height)
		end
		cptexture[i]:SetPoint("CENTER", cpframe, "CENTER", posx, 0 - cpoptions.height)
		cptexture[i]:SetVertexColor(1, 0, 0, 1)
		cptexture[i]:SetAlpha(1)
	end
	
	if cpoptions.energyattach == true then
		if cpoptions.energymeterbar == false then
			frames.energyframe:SetPoint("CENTER", frames.cpframe, "CENTER", ( (0 - 5 - (frames.energyicon:GetWidth() / 2)) + (0 - ((3 * self.ap.cpoptions.spacing) + (2 * self.ap.cpoptions.height)))), 0 - self.ap.cpoptions.height)
		end
	else
		if cpoptions.energymeterbar == false then
			frames.energyframe:SetPoint("CENTER", frames.energyhandle, "CENTER", 0, 0 - frames.energyicon:GetHeight() )
		end
	end
end

function ThievesTools:UpdateCombos()
	if (self.combos ~= self.lastcombos) then
		local cptexture = ThievesTools.frames.cptexture
		local cpshine = ThievesTools.frames.cpshine
		local cpoptions = ThievesTools.ap.cpoptions
		local combopoints = ThievesTools.combopoints
		for i = 1,5 do
			if i <= self.combos then 
				cptexture[i]:Show()
				if not combopoints[i].shown == true then 
					combopoints[i].fading = true
					combopoints[i].fadein = true
					combopoints[i].fadestart = self.thetime
				end
				combopoints[i].shown = true 
				--AzMsg(i)
			else
				if not combopoints[i].shown == false then
					combopoints[i].fading = true
					combopoints[i].fadeout = true
					combopoints[i].fadestart = self.thetime
				end
				combopoints[i].shown = false
			end
		end
	end
	self.lastcombos = self.combos
end

function ThievesTools:ComboFading()
	local cptexture = ThievesTools.frames.cptexture
	local cpshine = ThievesTools.frames.cpshine
	local cpoptions = ThievesTools.ap.cpoptions
	local combopoints = ThievesTools.combopoints
	for i = 1,5 do
		if combopoints[i].fading then
			local fadepercent = (self.thetime - combopoints[i].fadestart) / cpoptions.fadetime
			if combopoints[i].fadein == true then
				cptexture[i]:SetAlpha(fadepercent)
			elseif combopoints[i].fadeout == true then
				cptexture[i]:SetAlpha(1- fadepercent)
			end
			if fadepercent > 1 then 
				combopoints[i].fading = false
				if combopoints[i].fadein == true then
					combopoints[i].fadein = false
					combopoints[i].sparkshow = true
					combopoints[i].sparktime = self.thetime
					cptexture[i]:SetAlpha(1)
				elseif combopoints[i].fadeout == true then
					combopoints[i].fadeout = false
					cptexture[i]:SetAlpha(0)
					cptexture[i]:Hide()
				end
			end
		--nasty fix for stuck combos
		elseif (i > self.combos) then
			if cptexture[i]:IsShown() then cptexture[i]:Hide() end
		end
		
		
		if combopoints[i].sparkshow then
			local fadepercent = (self.thetime - combopoints[i].sparktime) / 0.2
			local thealpha = fadepercent
			if fadepercent > 1 then thealpha = 2 - fadepercent end
			cpshine[i]:SetAlpha(thealpha);
			if ((self.thetime - combopoints[i].sparktime) > 0.4) then 
			combopoints[i].sparkshow = false 
			cpshine[i]:SetAlpha(0)
			end
		end
	end
end

function ThievesTools:EnergyVisible()
	local frames = ThievesTools.frames
	local curnrg = ThievesTools.curnrg
	local maxnrg = ThievesTools.maxnrg
	if maxnrg > 150 or (UnitIsDeadOrGhost("player") or ((self.InCombat == false) and ((curnrg == maxnrg) or (curnrg == 0)))) then
		if frames.energyicon:IsShown() then frames.energyicon:Hide() end
		if frames.energytext:IsShown() then frames.energytext:Hide() end
	else
		if not frames.energyicon:IsShown() then frames.energyicon:Show() end
		if not frames.energytext:IsShown() then frames.energytext:Show() end
	end
end

function ThievesTools:EnergyUpdate()
	
	ThievesTools.curnrg = UnitPower(self.CEtoken)
	if ThievesTools.curnrg ~= self.lastnrg then
		local frames = ThievesTools.frames
		local cpoptions = ThievesTools.ap.cpoptions
		local curnrg = ThievesTools.curnrg
		local maxnrg = ThievesTools.maxnrg
		local red, green, blue, percent = 0, 0, 0, 0
		if curnrg == maxnrg then
			red = cpoptions.color_r
			green = cpoptions.color_g
			blue = cpoptions.color_b
		elseif curnrg >= cpoptions.energyleft1 then
			red = cpoptions.color_r
			green = cpoptions.color_g
			blue = cpoptions.color_b
			-- percent = (curnrg - cpoptions.energyleft1) / (maxnrg - cpoptions.energyleft1)
			-- red = cpoptions.color_r + ((cpoptions.color1_r - cpoptions.color_r) * percent)
			-- green = cpoptions.color_g + ((cpoptions.color1_g - cpoptions.color_g) * percent)
			-- blue = cpoptions.color_b + ((cpoptions.color1_b - cpoptions.color_b) * percent)
		elseif curnrg >= cpoptions.energyleft2 then
			red = cpoptions.color1_r
			green = cpoptions.color1_g
			blue = cpoptions.color1_b
			-- percent = (curnrg - cpoptions.energyleft2) / (cpoptions.energyleft1 - cpoptions.energyleft2)
			-- red = cpoptions.color1_r + ((cpoptions.color2_r - cpoptions.color1_r) * percent)
			-- green = cpoptions.color1_g + ((cpoptions.color2_g - cpoptions.color1_g) * percent)
			-- blue = cpoptions.color1_b + ((cpoptions.color2_b - cpoptions.color1_b) * percent)
		elseif curnrg >= cpoptions.energyleft3 then
			red = cpoptions.color2_r
			green = cpoptions.color2_g
			blue = cpoptions.color2_b
			-- percent = (curnrg - cpoptions.energyleft3) / (cpoptions.energyleft2 - cpoptions.energyleft3)
			-- red = cpoptions.color2_r + ((cpoptions.color3_r - cpoptions.color2_r) * percent)
			-- green = cpoptions.color2_g + ((cpoptions.color3_g - cpoptions.color2_g) * percent)
			-- blue = cpoptions.color2_b + ((cpoptions.color3_b - cpoptions.color2_b) * percent)
		elseif curnrg < cpoptions.energyleft3 then
			red = cpoptions.color3_r
			green = cpoptions.color3_g
			blue = cpoptions.color3_b
		end
		
		
		if cpoptions.energymeterbar == false then
			frames.energytext:SetText(curnrg)
			if red > 0 or green > 0 or blue > 0 then
				frames.energyicon:SetVertexColor(red, green, blue, 1);
			end
		end
	end
	self.lastnrg = curnrg
end

function ThievesTools:GetCombosEnergyToken()
	-- slow update speed check calls this to get the token we're checking energy/combos for, player or vehicle
	if UnitHasVehicleUI("player") then 
		self.CEtoken = "vehicle" 
	else
		self.CEtoken = "player" 
	end
end

