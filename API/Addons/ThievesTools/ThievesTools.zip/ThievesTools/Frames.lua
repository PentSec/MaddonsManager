local L = TT_locale;
local modName = "ThievesTools";
local _ ;
local _G = getfenv(0);
local select = _G.select;

local ThievesTools;
if not ThievesTools then ThievesTools = _G.ThievesTools end;
if not ThievesTools.frames.bargroups then ThievesTools.frames.bargroups = {} end;
if not ThievesTools.frames.bars then ThievesTools.frames.bars = {} end;
if not ThievesTools.frames.cptexture then ThievesTools.frames.cptexture = {} end;
if not ThievesTools.frames.cpshine then ThievesTools.frames.cpshine = {} end;
if not ThievesTools.fadeInfo then ThievesTools.fadeInfo = {} end;
ThievesTools.frames.backDrop = { bgFile = L.mainbgFile, edgeFile = L.mainedgeFile, tile = 1, tileSize = 16, edgeSize = 16, insets = { left = 3, right = 3, top = 3, bottom = 3 } };
ThievesTools.frames.backDropBar = { bgFile = L.barbgfile, edgeFile = "none", tile = 1, tileSize = 16, edgeSize = 2};

function ThievesTools:FrameFader(frame, inorout, func)
	local fadeInfo = {}
	if inorout == "IN" then
		fadeInfo.mode = inorout;
		fadeInfo.timeToFade = self.ap.baroptions.fadeintime;
		fadeInfo.finishedFunc = func
		--fadeInfo.timeToFade = 0.5;
	elseif inorout == "OUT" then
		fadeInfo.mode = inorout;
		fadeInfo.timeToFade = self.ap.baroptions.fadeouttime;
		fadeInfo.finishedFunc = func
		--fadeInfo.timeToFade = 0.5;
	else
		return
	end
	UIFrameFade(frame, fadeInfo);
	fadeInfo = nil
end


---------------------------------------------------------------------------------
------------ statusbar factory function -----------------------------------------
---------------------------------------------------------------------------------
function ThievesTools:CreateStatusBar(index, own)
	
	local i = index
	local owner = own

	if not self.frames.bars[i] then
		self.frames.bars[i] = {};
		local bar = ThievesTools.frames.bars[i];
		bar.framebar = CreateFrame("Frame", nil, UIParent);
		bar.framebar:SetToplevel(1);
		bar.framebar:SetFrameStrata("MEDIUM");
		bar.framebar:EnableMouse(0);
		bar.framebar:SetBackdrop(ThievesTools.frames.backDropBar);
		bar.framebar:Hide();
		
		
		--debug
		-- bar.framebar:SetBackdropColor(0,0,0,1);
		-- bar.framebar:SetWidth(144);
		-- bar.framebar:SetHeight(17);
		-- bar.framebar:SetScale(1);
		-- bar.framebar:SetPoint('TOPLEFT', ThievesTools.frames.bargroups[1], 'BOTTOMLEFT', 0, 0); 
		
		
		bar.statusbar = CreateFrame("StatusBar", nil, bar.framebar);
		bar.statusbar:SetPoint("CENTER");
		bar.statusbar:SetFrameStrata("HIGH");
		bar.statusbar:Hide();
		
		bar.statusbar1 = CreateFrame("StatusBar", nil, bar.framebar);
		bar.statusbar1:SetPoint("CENTER");
		bar.statusbar1:SetFrameStrata("MEDIUM");
		bar.statusbar1:Hide();
		
		-- bar.statusbar:SetWidth(140); 
		-- bar.statusbar:SetHeight(15);
		-- bar.statusbar:SetStatusBarTexture(L.bartexfile); 
		-- bar.statusbar:SetMinMaxValues(0, 100); 
		-- bar.statusbar:SetStatusBarColor(1, 0, 1, 1); 
		-- bar.statusbar:SetValue(50);
		
		--buff text
		bar.text = bar.statusbar:CreateFontString(nil,"ARTWORK","GameFontNormal");
		--bar.text:SetAllPoints();
		bar.text:SetPoint("LEFT", bar.statusbar, "LEFT", 0, 1);
		bar.text:SetPoint("RIGHT",bar.statusbar, "RIGHT", 0, 1)
		bar.text:SetPoint("CENTER", bar.statusbar, "CENTER", 0, 1);
--you added the line below to test leaving a gap at the right
		bar.text:SetPoint("RIGHT", -18, 1)
		bar.text:SetPoint("LEFT", 2, 1);
		--bar.text:SetJustifyH("CENTER");
		bar.text:SetJustifyV("CENTER");
		bar.text:Hide();
		--stack text
		bar.text1 = bar.statusbar:CreateFontString(nil,"ARTWORK","GameFontNormal");
		bar.text1:SetPoint("LEFT", bar.statusbar, "LEFT", 0, 1);
		bar.text1:SetPoint("RIGHT",bar.statusbar, "RIGHT", 0, 1)
		bar.text1:SetPoint("CENTER", bar.statusbar, "CENTER", 0, 1);
		--bar.text1:SetJustifyH("LEFT");
		bar.text1:Hide();
		-- duration text
		bar.text2 = bar.statusbar:CreateFontString(nil,"ARTWORK","GameFontNormal");
		bar.text2:SetPoint("LEFT", bar.statusbar, "LEFT", 0, 1);
		bar.text2:SetPoint("RIGHT",bar.statusbar, "RIGHT", 0, 1)
		bar.text2:SetPoint("CENTER", bar.statusbar, "CENTER", 0, 1);	
		--bar.text2:SetJustifyH("LEFT");
		bar.text2:Hide();
		--icon text
		-- bar.text3 = bar.statusbar:CreateFontString(nil,"OVERLAY","GameFontNormal");
		-- bar.text3:SetAllPoints();	
		-- bar.text3:SetPoint("BOTTOMLEFT", 0, 3); --update this with x value = - barheight
		-- bar.text3:SetJustifyH("CENTER");
		-- bar.text3:Hide();
		
		bar.spark = bar.statusbar:CreateTexture(nil, "OVERLAY");
		bar.spark:SetTexture(L.barsparkfile);
		bar.spark:SetVertexColor(1, 1, 1, 0.75);
		bar.spark:SetBlendMode("ADD");
		bar.spark:Hide();
		
		bar.spark1 = bar.statusbar:CreateTexture(nil, "OVERLAY");
		bar.spark1:SetTexture(L.barsparkfile);
		bar.spark1:SetVertexColor(1, 1, 1, 0.75);
		bar.spark1:SetBlendMode("ADD");
		bar.spark1:Hide();
		
		--icon texture
		bar.icon = bar.framebar:CreateTexture(nil, "ARTWORK");
		bar.icon:SetVertexColor(1, 1, 1, 1);
		bar.icon:SetBlendMode("BLEND");
		bar.icon:SetPoint("RIGHT", bar.framebar, "LEFT", -2, 0)
		bar.icon:SetPoint("CENTER", bar.framebar, "CENTER", -2, 0)
		bar.icon:Hide();
		
		--raid icon
		bar.raidicon = bar.framebar:CreateTexture(nil, "ARTWORK");
		bar.raidicon:SetVertexColor(1, 1, 1, 1);
		bar.raidicon:SetBlendMode("BLEND");
		bar.raidicon:SetPoint("LEFT", bar.framebar, "RIGHT", 2, 0)
		bar.raidicon:SetPoint("CENTER", bar.framebar, "CENTER", 2, 0)
		bar.raidicon:Hide();
		
		--- newly created bar is unowned by any watch object unless created by one
		bar.owner = 0;
		if owner then bar.owner = owner end;
		--AzMsg("bar owned by - "..bar.owner);
		
		
		--return the bar index if bar created
		return i
	else
		--return 0 if we couldn't create it
		return 0
	end
	
end

---------------------------------------------------------------------------------
------------ create the bargroups, kicker, anything else enabled ----------------
---------------------------------------------------------------------------------

function ThievesTools:CreateEnabledFrames()
	--AzMsg("creating frames")

	local frames = self.frames;
	local ap = self.ap;
	local frames = self.frames;
	--create bargroup frames
	if not self.frames.bargroups then self.frames.bargroups = {} end;
	for i = 1,#ap.bargroups do
		if ap.bargroups[i].enabled == true then
			local framename = _G[modName.."bargroup"..i];
			local frames = self.frames;
			if not frames.bargroups[i] then
				frames.bargroups[i] = CreateFrame("Frame", framename, UIParent);
				frames.bargroups[i]:SetMovable(1);
				frames.bargroups[i]:SetToplevel(1);
				frames.bargroups[i]:SetFrameStrata("MEDIUM");
				frames.bargroups[i]:SetBackdrop(self.frames.backDropBar);
				frames.bargroups[i]:SetBackdropColor(0,0,0,1);
				frames.bargroups[i]:SetWidth(144);
				frames.bargroups[i]:SetHeight(17);
				frames.bargroups[i]:SetScale(1);
				if (ap.bargroups[i].posx == 0) and (ap.bargroups[i].posy == 0) then 
				frames.bargroups[i]:SetPoint('CENTER', (i * 50), (i * 50));
				else
				frames.bargroups[i]:SetPoint("BOTTOMLEFT", ap.bargroups[i].posx, ap.bargroups[i].posy);
				end
				frames.bargroups[i]:SetAlpha(1);
				
				frames.bargroups[i]:SetScript("OnMouseDown", function() frames.bargroups[i]:StartMoving(); end);
				frames.bargroups[i]:SetScript("OnMouseUp", function() 
					frames.bargroups[i]:StopMovingOrSizing();
					ap.bargroups[i].posx = frames.bargroups[i]:GetLeft();
					ap.bargroups[i].posy = frames.bargroups[i]:GetBottom();
				end);
				frames.bargroups[i].text = self.frames.bargroups[i]:CreateFontString("$parentText","OVERLAY","GameFontNormal");
				
			end
			--framename = _G[modName.."bargroup"..i.."text"]
			--local text = self.frames.bargroups[i]:CreateFontString("$parentText","OVERLAY","GameFontNormal");
				frames.bargroups[i].text:SetAllPoints();
				frames.bargroups[i].text:SetFont(self.ap.baroptions.font, self.ap.baroptions.fontsize, self.ap.baroptions.fontoutline)
				frames.bargroups[i].text:SetText(self.ap.bargroups[i].name);
				frames.bargroups[i].text:SetPoint("BOTTOMLEFT", 0, 2);
				frames.bargroups[i].text:SetJustifyH("CENTER");
			--AzMsg("setup bargroup " ..i);
			
		end
	end
	
	--create cp and energy frames
	if not frames.cphandle then
		frames.cphandle = CreateFrame("Frame", framename, UIParent);
		frames.cphandle:SetMovable(1);
		frames.cphandle:SetToplevel(1);
		frames.cphandle:SetFrameStrata("MEDIUM");
		frames.cphandle:SetBackdrop(self.frames.backDropBar);
		frames.cphandle:SetBackdropColor(0,0,0,1);
		frames.cphandle:SetWidth(144);
		frames.cphandle:SetHeight(17);
		frames.cphandle:SetScale(1);
		if (ap.cpoptions.posx == 0) and (ap.cpoptions.posy == 0) then 
		frames.cphandle:SetPoint('CENTER', 0, -50);
		else
		frames.cphandle:SetPoint("BOTTOMLEFT", ap.cpoptions.posx, ap.cpoptions.posy);
		end
		frames.cphandle:SetAlpha(1);
		
		frames.cphandle:SetScript("OnMouseDown", function() frames.cphandle:StartMoving(); end);
		frames.cphandle:SetScript("OnMouseUp", function() 
			frames.cphandle:StopMovingOrSizing();
			ap.cpoptions.posx = frames.cphandle:GetLeft();
			ap.cpoptions.posy = frames.cphandle:GetBottom();
		end);
		
		local text = self.frames.cphandle:CreateFontString("$parentText","OVERLAY","GameFontNormal");
		text:SetAllPoints();
		text:SetFont(self.ap.baroptions.font, self.ap.baroptions.fontsize, self.ap.baroptions.fontoutline)
		text:SetText(L.combopoints);
		text:SetPoint("BOTTOMLEFT", 0, 2);
		text:SetJustifyH("CENTER");
	end
	
	if not frames.cpframe then
		frames.cpframe = CreateFrame("Frame", framename, UIParent);
		frames.cpframe:SetPoint('CENTER', 0, 0);
		frames.cpframe:SetPoint("TOP", frames.cphandle, "BOTTOM", 0, 0)
		frames.cpframe:SetToplevel(1);
		frames.cpframe:SetHeight(1);
		frames.cpframe:SetWidth(1);
		frames.cpframe:SetFrameStrata("MEDIUM");
		frames.cpframe:EnableMouse(0);
		frames.cpframe:SetAlpha(1)
		frames.cpframe:Show()
	end
	
	if not frames.cptexture[1] then
		for i = 1,5 do
			frames.cptexture[i] = frames.cpframe:CreateTexture(nil, "ARTWORK");
			frames.cptexture[i]:SetBlendMode("BLEND");
			frames.cptexture[i]:Hide();
			frames.cpshine[i] = frames.cpframe:CreateTexture(nil, "OVERLAY");
			frames.cpshine[i]:SetVertexColor(1, 1, 1, 1);
			frames.cpshine[i]:SetBlendMode("ADD");
			frames.cpshine[i]:SetPoint("CENTER", frames.cptexture[i], "CENTER", 3, 4)
			frames.cpshine[i]:SetTexture(L.comboshine);
			frames.cpshine[i]:SetAlpha(0);
			frames.cpshine[i]:Show();	
		end
	end
	
	if not frames.energyhandle then
		frames.energyhandle = CreateFrame("Frame", framename, UIParent);
		frames.energyhandle:SetMovable(1);
		frames.energyhandle:SetToplevel(1);
		frames.energyhandle:SetFrameStrata("MEDIUM");
		frames.energyhandle:SetBackdrop(self.frames.backDropBar);
		frames.energyhandle:SetBackdropColor(0,0,0,1);
		frames.energyhandle:SetWidth(144);
		frames.energyhandle:SetHeight(17);
		frames.energyhandle:SetScale(1);
		frames.energyhandle:Hide();
		if (ap.cpoptions.energyposx == 0) and (ap.cpoptions.energyposy == 0) then 
		frames.energyhandle:SetPoint('CENTER', -150, -150);
		else
		frames.energyhandle:SetPoint("BOTTOMLEFT", ap.cpoptions.energyposx, ap.cpoptions.energyposy);
		end
		frames.energyhandle:SetAlpha(1);
		
		frames.energyhandle:SetScript("OnMouseDown", function() frames.energyhandle:StartMoving(); end);
		frames.energyhandle:SetScript("OnMouseUp", function() 
			frames.energyhandle:StopMovingOrSizing();
			ap.cpoptions.energyposx = frames.energyhandle:GetLeft();
			ap.cpoptions.energyposy = frames.energyhandle:GetBottom();
		end);
		
		local text = self.frames.energyhandle:CreateFontString("$parentText","OVERLAY","GameFontNormal");
		text:SetAllPoints();
		text:SetFont(self.ap.baroptions.font, self.ap.baroptions.fontsize, self.ap.baroptions.fontoutline)
		text:SetText(L.energymeter);
		text:SetPoint("BOTTOMLEFT", 0, 2);
		text:SetJustifyH("CENTER");
	end
	
	if not frames.energyframe then
		frames.energyframe = CreateFrame("Frame", framename, UIParent);
		frames.energyframe:SetPoint('CENTER', 0, 0);
		frames.energyframe:SetToplevel(1);
		frames.energyframe:SetHeight(1);
		frames.energyframe:SetWidth(1);
		frames.energyframe:SetFrameStrata("MEDIUM");
		frames.energyframe:EnableMouse(0);
		frames.energyframe:SetAlpha(1)
		frames.energyframe:Show()
		frames.energyicon = frames.energyframe:CreateTexture(nil, "OVERLAY");
		frames.energyicon:SetVertexColor(1, 0, 0, 1);
		frames.energyicon:SetBlendMode("BLEND");
		frames.energyicon:SetHeight(32);
		frames.energyicon:SetWidth(32);
		frames.energyicon:SetPoint("CENTER", frames.energyframe, "CENTER", 0, 0)
		frames.energyicon:SetTexture(L.energytex);
		frames.energyicon:SetAlpha(1);
		frames.energyicon:Show();
		frames.energytext = frames.energyframe:CreateFontString(nil,"OVERLAY","GameFontNormal");
		frames.energytext:SetPoint("CENTER", frames.energyicon, "CENTER", 1, 1);
		frames.energytext:SetFont(ap.cpoptions.font, ap.cpoptions.fontsize, "OUTLINE");
		frames.energytext:SetVertexColor(ap.cpoptions.font_r, ap.cpoptions.font_g, ap.cpoptions.font_b);
		--frames.energytext:SetText("0")
		
		
	end
	
	-- interrupt list handle
	if not frames.interrupthandle then
		frames.interrupthandle = CreateFrame("Frame", framename, UIParent);
		frames.interrupthandle:SetMovable(1);
		frames.interrupthandle:SetToplevel(1);
		frames.interrupthandle:SetFrameStrata("MEDIUM");
		frames.interrupthandle:SetBackdrop(self.frames.backDropBar);
		frames.interrupthandle:SetBackdropColor(0,0,0,1);
		frames.interrupthandle:SetWidth(144);
		frames.interrupthandle:SetHeight(17);
		frames.interrupthandle:SetScale(1);
		frames.interrupthandle:Hide();
		if (ap.kickeroptions.posx == 0) and (ap.kickeroptions.posy == 0) then 
		frames.interrupthandle:SetPoint('CENTER', -150, 150);
		else
		frames.interrupthandle:SetPoint("BOTTOMLEFT", ap.kickeroptions.posx, ap.kickeroptions.posy);
		end
		frames.interrupthandle:SetAlpha(1);
		
		frames.interrupthandle:SetScript("OnMouseDown", function() frames.interrupthandle:StartMoving(); end);
		frames.interrupthandle:SetScript("OnMouseUp", function() 
			frames.interrupthandle:StopMovingOrSizing();
			ap.kickeroptions.posx = frames.interrupthandle:GetLeft();
			ap.kickeroptions.posy = frames.interrupthandle:GetBottom();
		end);
		
		local text = self.frames.interrupthandle:CreateFontString("$parentText","OVERLAY","GameFontNormal");
		text:SetAllPoints();
		text:SetFont(self.ap.baroptions.font, self.ap.baroptions.fontsize, self.ap.baroptions.fontoutline)
		text:SetText(L.interruptlist);
		text:SetPoint("BOTTOMLEFT", 0, 2);
		text:SetJustifyH("CENTER");
	end
	
	ThievesTools:FrameLocks(true)
end



function ThievesTools:FrameLocks(lock)
	local frames = self.frames;
	if lock == false then
		for i = 1,#self.ap.bargroups do --only unlock active bargroups, even if a frame was created for one that has been removed
			if frames.bargroups[i] then
				frames.bargroups[i]:Show();
				frames.bargroups[i]:EnableMouse(1);
			else
				break
			end
		end
		frames.cphandle:Show();
		frames.cphandle:EnableMouse(1);
		if not self.ap.cpoptions.energyattach then
			frames.energyhandle:Show();
			frames.energyhandle:EnableMouse(1);
		end
		frames.interrupthandle:Show();
		frames.interrupthandle:EnableMouse(1);
	else
		for i = 1,#frames.bargroups do
			if frames.bargroups[i] then
				frames.bargroups[i]:Hide();
				frames.bargroups[i]:EnableMouse(0);
			else
				break
			end
		end
		frames.cphandle:Hide();
		frames.cphandle:EnableMouse(0);
		if not self.ap.cpoptions.energyattach then
			frames.energyhandle:Hide();
			frames.energyhandle:EnableMouse(0);
		end
		frames.interrupthandle:Hide();
		frames.interrupthandle:EnableMouse(0);
	end
end

