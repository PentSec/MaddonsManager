local L = TT_locale;
local modName = "ThievesTools";
local _ ;
local _G = getfenv(0);
local select = _G.select;
local tonum = _G.tonumber;

local ThievesTools;
if not ThievesTools then ThievesTools = _G.ThievesTools end;
if not ThievesTools.events then ThievesTools.events = {} end;
if not ThievesTools.events.auras then ThievesTools.events.auras = {} end;



---------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------
-- A brief explanation of the functions in this file.
--
--ConfigEvents() is used to parse the aura names from each of the barconfigs/procconfigs in the active profile.  It parses these
--into a table self.events.auras along with the corresponding barconfig/procconfig index, and the shortname for a barconfig.
--
--ParseEvents() is called whenever the addon receives combat_log_event_unfiltered events, if the event is an aura, then it 
--walks the self.events.auras table to see if the aura is one we're tracking.  From there it compares the source/dest GUID to
--the rules set up in the corresponding barconfig/procconfig for that aura.  If there's a match, it then establishes if we're
--already showing a bar for that aura/source/dest combination (the havebar variable is the index of the buffbar), if there is
--a related bar, we update it for refresh/applied_dose events using GetAuraDurExp(), or destroy it for removed events.  If there 
--is no related bar for that aura/source/dest combo, we create a new bar, calling CreatBuffBar() in bars.lua if it's a barconfig
--aura.
--
--GetAuraDurExp() is a function to determine the aura duration, firstly by the determining the unitID of the destGUID and then 
--use that unitID (eg. "target", "raid17target" etc) to get the duration and count using the UnitAura() API call.
--
--UpdateCore() is the main onupdate function, called from the onupdate handler, it contains all things to be done onupdate.
--
--GetPlayerInfo() is called when the addon loads or spec/glyphs change, to parse the playerGUID, class, and any glyphs that
--affect the fixedsize bars in the rogue default profile.
-------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------  

function ThievesTools:ConfigEvents()
	
	local self = ThievesTools
	
	if self.ap then
	
		self.events.auras = {}
		

		-- first group of auras will always be the buffbars
		local i = 1 -- counter for walking the barconfigs
		local j = 1 -- counter for walking the auras list
		while self.ap.barconfigs[i] do -- count through the configured buffbars
			if self.ap.barconfigs[i].enabled then -- check the buffbar is enabled
				local buffnames = {} -- temporary table to store the buffname(s) to look for
				local shortnames = {} -- temp table for storing short names, assigning these to the auras as it's the easiest time to parse them from the barconfig
				local k = 1
				if strfind(self.ap.barconfigs[i].buffname, ",") then -- if there's a comma, we're looking at multiple buffs to track using the barconfig, delimited list
					buffnames = { strsplit(",", self.ap.barconfigs[i].buffname) } -- split the buff names into the table by the delimiter, comma
					shortnames =  { strsplit(",", self.ap.barconfigs[i].shortname) } --split the shortnames too, if these don't match number of buffnames, we'll catch it when trimming whitespace
					local l = 1 -- counter to cycle the buffnames table and trim whitespaces
					while buffnames[l] do --while there's a buffname at that index
						buffnames[l] = strtrim(buffnames[l]) -- trim it
						if shortnames[l] then -- check theres a shortname for this buffname, if there is then trim it, else set it to the buffname
							shortnames[l] = strtrim(shortnames[l])
						else
							shortnames[l] = buffnames[l]
						end
						l = l + 1 -- increase the counter for the next trim cycle
					end
		
				else -- no delimiter in the barconfig's buffname, must be single buff to track on this bar
					buffnames[k] = strtrim(self.ap.barconfigs[i].buffname)
					shortnames[k] = strtrim(self.ap.barconfigs[i].shortname)
				end
				while buffnames[k] do -- lets walk the buffname table we just populated, creating an aura table entry, for every buff in the list
					--debug
						--AzMsg(buffnames[k])
						--end debug
					if buffnames[k] == "" or buffnames[k] == " " then buffnames[k] = "invalid" end --catch empty aura names so we don't track every aura possible
					self.events.auras[j] = {} --create the table for this aura
					self.events.auras[j].name = buffnames[k] -- set it's name to the current buff name from the buffname table
					self.events.auras[j].shortname = shortnames[k] -- set the shortname for this aura to display on untargetted bargroup etc
					self.events.auras[j].buffbars = true -- this aura is related to a buffbar
					self.events.auras[j].config = i -- the buffbar uses this barconfig
					self.events.auras[j].spellid = tonum(buffnames[k]) 
					if not self.ap.barconfigs[i].periodspark == false then
						self.events.auras[j].periodic = true
					end
					k = k + 1 -- increase counter for the while loop to check next buffname in that table
					j =j + 1 -- we just created an aura, so increase counter for aura table (we don't want to overwrite the one we just made)
				end
			end
			i =i + 1
		end
		
		--debug code
		-- i = 1
		-- while self.events.auras[i] do
			-- AzMsg(self.events.auras[i].name)
			-- i = i + 1
		-- end
		--end debug code
	
	end
	
	

end

------------ function that receives all UNFILTERED events and checks if we're interested in the aura -----------------------------

function ThievesTools.ParseEvents(timestamp, eventType, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags, spellId, spellName, spellSchool, auraType, count, ...)
	
	-- lazy coder changes self to the thievestools object
	local self = ThievesTools
	
	if (eventType == "SPELL_AURA_APPLIED")  or (eventType == "SPELL_AURA_REMOVED") or (eventType == "SPELL_AURA_REFRESH") or (eventType == "SPELL_PERIODIC_DAMAGE") or (eventType == "SPELL_PERIODIC_HEAL") or (eventType == "SPELL_PERIODIC_ENERGIZE") or (eventType == "SPELL_AURA_APPLIED_DOSE") or (eventType == "SPELL_AURA_REMOVED_DOSE") or  (eventType == "TT_TARGET_CHANGE") then
		
		--local spellId, spellName, spellSchool, auraType, count = select(9, ...)
	
		if not spellName then AzMsg(eventType) return end 
		
		
		local i = 1
		while self.events.auras[i] do -- walk the list of auras we're tracking
			--AzMsg(spellName)
			--AzMsg(spellId)
			if (spellId == self.events.auras[i].spellid) or strfind(spellName, self.events.auras[i].name) then -- if an aura matches
				-- check the event for the buffbars
				--AzMsg("aura matches "..spellName)
				if self.events.auras[i].buffbars == true then --only do the following for auras related to a buffbar
					--AzMsg("aura is a buffbar")
					local config = self.ap.barconfigs[self.events.auras[i].config]
					local fromGUID = false
					--AzMsg("config.from = "..config.from)
					--AzMsg("playerGUID = "..self.playerGUID)
					if config.from == "player" then 
						fromGUID = self.playerGUID
						--fake pet tracking for DK dancing rune using Rune Weapon's GUID
						if self.fakepet then
							if srcGUID == self.fakepet then
								fromGUID = true
							end
						end
					elseif config.from == "target" then fromGUID = self.targetGUID
					elseif config.from == "friendly" then
						if UnitIsFriend("player", srcName) then fromGUID = true end;
					elseif config.from == "any" then fromGUID = true -- set to a true value if any source GUID is valid
					elseif config.from == "grouped" then
						if UnitInParty(srcName) or UnitInRaid(srcName) or (srcGUID == self.playerGUID) then fromGUID = true end; -- set true if the source GUID is grouped/inraid/self
					elseif config.from == "focus" then fromGUID = UnitGUID("focus")
					elseif config.from == "pet" then fromGUID = UnitGUID("pet")
					elseif config.from == "vehicle" then fromGUID = UnitGUID("vehicle")
					elseif config.from == "named" then fromGUID = UnitGUID(config.fromname)
					end
					
					--remove the following line after 3.1 hits
					--if (eventType == "SPELL_AURA_REFRESH") or (eventType == "SPELL_AURA_APPLIED_DOSE") then fromGUID = true end;
					
					if (fromGUID == true) or (srcGUID == fromGUID) then
						--AzMsg("from matches")
						local toGUID = false
						if config.to == "player" then toGUID = self.playerGUID
						elseif config.to == "target" then toGUID = self.targetGUID
						elseif config.to == "friendly" then
							if UnitIsFriend("player", dstName) then toGUID = true end;
						elseif config.to == "any" then toGUID = true -- set to a true value if any dest GUID is valid
						elseif config.to == "grouped" then
						if UnitInParty(dstName) or UnitInRaid(dstName) or (dstGUID == self.playerGUID) then toGUID = true end; --set true if the dest GUID is grouped/inraid/self
						elseif config.to == "focus" then toGUID = UnitGUID("focus")
						elseif config.to == "pet" then toGUID = UnitGUID("pet")
						elseif config.to == "vehicle" then toGUID = UnitGUID("vehicle")
						elseif config.to == "named" then toGUID = UnitGUID(config.toname)
						end
						
						if (eventType == "SPELL_AURA_REMOVED")  then toGUID = true end; -- config.to might be set to target only, we want to pick up when auras drop from old targets tho
						--if (eventType == "SPELL_AURA_REMOVED") or (eventType == "SPELL_AURA_REFRESH") or (eventType == "SPELL_AURA_APPLIED_DOSE") then toGUID = true end; --not sure if needed for refresh/dose
						
						if (toGUID == true) or (dstGUID == toGUID) then
						--AzMsg("to matches")
							--AzMsg(spellName);
							
							-- if we got this far, pass the args on to see if we're already tracking
							-- this aura from this source on this target, or if we need to make a new bar
							-- for it.
							
							--temp fix for resto druid t8 4 piece
							if (spellId == 64801) then return end;
				
				
							-- check the existing bars
							local havebar = 0
							--if strfind(spellName, "Crippling") then AzMsg(timestamp..eventType..srcGUID..spellName, spellSchool, auraType, count) end
							--AzMsg("checking existing bars")
							havebar = self:CheckBuffBars(spellId, dstGUID, srcGUID)
							-- if we found a bar already for this aura/source/target combo, update it
							if not (havebar == 0) and (spellId == self.buffbars[havebar].spellID) then
								--little fix for stuck alpha value with aura refreshes on bars that're flashing low, this looks really ugly without local references
								self.frames.bars[self.buffbars[havebar].barframe].statusbar:SetAlpha(self.ap.barconfigs[self.buffbars[havebar].config].bar_alpha)
								--queue an update for this bar here
								if (eventType == "SPELL_PERIODIC_DAMAGE") or (eventType == "SPELL_PERIODIC_HEAL") or (eventType == "SPELL_PERIODIC_ENERGIZE") then
									self.buffbars[havebar].lasttick = self.thetime
									--AzMsg("tick tock")
								elseif (eventType == "SPELL_AURA_REFRESH") or (eventType == "SPELL_AURA_APPLIED_DOSE") or (eventType == "SPELL_AURA_REMOVED_DOSE") then
									--AzMsg("foundbar "..havebar)
									if ((eventType == "SPELL_AURA_APPLIED_DOSE") or (eventType == "SPELL_AURA_REMOVED_DOSE")) and count then
										--self.buffbars[havebar].stacks = self.buffbars[havebar].stacks + 1
										self.buffbars[havebar].stacks = count
									end
									if not self.buffbars[havebar].fixeddur then 
										self:GetAuraDurExp(self.buffbars[havebar], spellName)
									else
										self.buffbars[havebar].timestart = self.thetime
									end
									--fix for dancing rune refreshes
									if self.fakepet and (self.buffbars[havebar].sourceGUID == self.fakepet) and (self.buffbars[havebar].duration > 0) then self.buffbars[havebar].timestart = self.thetime end
									
								-- if the message was aura removed, kill the bar
								elseif (eventType == "SPELL_AURA_REMOVED") then
									--AzMsg("destroying "..havebar)
									if ((spellId == 59620) or (spellId == 28093)) and (self.buffbars[havebar].stacks > 1) then
										self.buffbars[havebar].stacks = 1
									else
										self.buffbars[havebar].fadedestroy = true
										self.buffbars[havebar].fading = "OUT"
										self.buffbars[havebar].fadestart = self.thetime
										self.buffbars[havebar].active = false
										if (self.buffbars[havebar].announce ~= "OFF") then
										if (self.buffbars[havebar].announcecrit == "EXPIRED") or (self.buffbars[havebar].announceexp == true) then self.buffbars[havebar].announcecrit = "EXPIRED"
										self:AnnounceAura(self.buffbars[havebar], self.ap.barconfigs[self.buffbars[havebar].config]) end
									end
									end
								elseif (eventType == "SPELL_AURA_APPLIED") and ((spellId == 59620) or (spellId == 28093)) then
									self.buffbars[havebar].stacks = 2
									self.buffbars[havebar].timestart = self.thetime
								end
							ThievesTools.bsort = true
							else
								--if there was no bar set up, lets create one
								if (eventType == "SPELL_AURA_APPLIED") or (eventType == "SPELL_AURA_REFRESH") or (eventType == "SPELL_AURA_APPLIED_DOSE") or (eventType == "SPELL_PERIODIC_DAMAGE") or (eventType == "SPELL_PERIODIC_HEAL") or (eventType == "SPELL_PERIODIC_ENERGIZE") or (eventType == "TT_TARGET_CHANGE") then
									self:CreateBuffBar(self.events.auras[i].config, self.events.auras[i].shortname, timestamp, eventType, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags, spellId, spellName, spellSchool, auraType, count)
								end
							end
							return --it matched an aura config, so lets exit here to avoid iterating through the full auras table
						end	
					end
				end
			end
			i = i + 1
		end
		
	--detect when dancing rune weapon ended
	if self.fakepet and (eventType == "SPELL_AURA_REMOVED") then
		if spellName == L.dancingruneweapon then
			self.fakepet = nil
		end
	end
	
	
	 -- if the event is unit_died then we better check if any of our bars have that dest GUID and destroy them
	elseif (eventType == "UNIT_DIED") then
		--AzMsg("unit died")
		for i = 1,self.ap.baroptions.barlimit do
			--AzMsg("checking bar "..i)
			if ThievesTools.buffbars[i] then
				--AzMsg("bar exists - "..i)
				if self.buffbars[i].destGUID == dstGUID then 
					self.buffbars[i].fadedestroy = true
					self.buffbars[i].fading = "OUT"
					self.buffbars[i].fadestart = self.thetime
					self.buffbars[i].active = false
					--AzMsg("Destroying bar related to "..dstGUID)
				end --use the config variable to check if a bar exists, it'll always be present
			end
		end
		
	
	-- fake pet detection for dk's dancing rune, so we can detect it's debuffs as belonging to the player.
	-- this is done by assigning the player's Rune Weapon GUID to self.fakepet when the rune weapon summon event fires.
	elseif (eventType == "SPELL_SUMMON") then
		if srcGUID == self.playerGUID then
			if dstName == L.dancingrune then
				self.fakepet = dstGUID
			end
		end
	end
	
end

function ThievesTools:GetUnitID(theGUID)
local token = false
	if not (theGUID == nil) then -- make sure we have a bar, not nil
		if UnitGUID("target") == theGUID then token = "target"
		--AzMsg("token is target")
		elseif UnitGUID("focus") == theGUID then token = "focus"
		elseif UnitGUID("player") == theGUID then token = "player"
		elseif UnitGUID("mouseover") == theGUID then token = "mouseover"
		else --else lets see if anyone in the party or raid has the dest GUID targetted or if it's them
			token = self:PartyTargetCheck(theGUID)
			if not token then token = self:RaidTargetCheck(theGUID) end;
		end
	
		return token
	end
end

--------- function to get the duration and expirationTime of an aura we're interested in ---------------

function ThievesTools:GetAuraDurExp(buffbar, spellName)

	local token = false
	if not (buffbar == nil) then -- make sure we have a bar, not nil
		token = self:GetUnitID(buffbar.destGUID)
		if token then
			local count, duration, expirationTime, caster, name
			name = true
			--AzMsg(token)
			for i = 1, 80 do
				if buffbar.auratype == "BUFF" then
				name, _, _, count, _, duration, expirationTime, caster, _ = UnitBuff(token, i)
				--AzMsg("buff")
				end
				if buffbar.auratype == "DEBUFF" then
				--AzMsg("aura debuff scanning")
				name, _, _, count, _, duration, expirationTime, caster, _ = UnitDebuff(token, i)
				--AzMsg("debuff")
				--AzMsg("duration is "..buffbar.duration)
				end
				if name == nil then break end;
				--AzMsg("name not nil")
				if name == spellName then
					--AzMsg("unitaura name match")
					--AzMsg(caster)
					
					local srcGUID = buffbar.sourceGUID
					
					--hack for fake pet dancing rune
					if self.fakepet then
						srcGUID = self.playerGUID 
					end
					
					--24/02/10 check for source = any added to support whacked LK necrotic plague having a nil source
					if ((caster) and (UnitGUID(caster) == srcGUID)) or ((caster == nil) and (self.ap.barconfigs[buffbar.config].from == "any")) then 
						--AzMsg("sourceGUID matches too, this IS the aura you're looking for")
						buffbar.duration = duration
						if (duration == 0) then buffbar.infinite = true end
						if self.ap.barconfigs[buffbar.config].fixeddur then
							self.ap.barconfigs[buffbar.config].fixeddurlength = duration
						end
						--AzMsg(duration)
						buffbar.timestart = expirationTime - duration
						buffbar.timeleft = buffbar.timestart + buffbar.duration - self.thetime --update the timeleft before the sortbuffbargroups()
						buffbar.stacks = count
						--if buffbar.stacks > 1 then buffbar.stackstring = "("..buffbar.stacks..")" else buffbar.stackstring = "" end;
						--we just updated a buffbar in some way, better sort the bars with the update
						--ThievesTools:SortBuffBarGroups()
						if not self.ap.barconfigs[buffbar.config].fullscan then break end;
					end
				end
				--AzMsg(i)
			end
		else
			--AzMsg("token was false, duration is "..buffbar.duration)
		end
	else
	AzMsg("buffbar was nil")
	end
end

function ThievesTools:PartyTargetCheck(theGUID)
	for i = 1, 4 do
		if (UnitGUID("party"..i)) then
			if (UnitGUID("party"..i) == theGUID) then return "party"..i end;
			if (UnitGUID("party"..i.."target")) and (UnitGUID("party"..i.."target") == theGUID) then return "party"..i.."target" end;
			if (UnitGUID("partypet"..i)) and (UnitGUID("partypet"..i) == theGUID) then return "partypet"..i end;
		else break
		end
	end
return false
end

function ThievesTools:RaidTargetCheck(theGUID)
	for i = 1, 40 do
		if (UnitGUID("raid"..i)) then
			if (UnitGUID("raid"..i) == theGUID) then return "raid"..i end;
			if (UnitGUID("raid"..i.."target")) and (UnitGUID("raid"..i.."target") == theGUID) then return "raid"..i.."target" end;
			if (UnitGUID("raidpet"..i)) and (UnitGUID("raidpet"..i) == theGUID) then return "raidpet"..i end;
		else break
		end
	end
return false
end

function ThievesTools:TargetChangeAuraCheck()

	--this function inspects new targets for auras and fakes a combatlog event for all auras found, that're then parsed normally
	-- to check if we should be displaying them.  This is basically to catch auras set to show for target only, that were placed 
	-- when the unit wasn't the player's target.  Now the unit is the player's target, we want to display auras that match an
	--aura config.
	
	--AzMsg("change aura check")

	if UnitGUID("target") then

		local spellName, rank, icon, count, auraType, duration, expirationTime, unitCaster, isStealable, shouldConsolidate, spellId, srcName, srcFlags, srcGUID, dstName, dstFlags, dstGUID, spellSchool, eventType, timestamp
		eventType = "TT_TARGET_CHANGE" 
		timestamp = self.thetime
		dstGUID = UnitGUID("target")
		dstName = UnitName("target")
		for i = 1, 80 do
			spellName, rank, icon, count, auraType, duration, expirationTime, unitCaster, isStealable, shouldConsolidate, spellId = UnitBuff("target", i)
			if (spellName == nil) then break end
			if UnitExists(unitCaster) then
				srcGUID = UnitGUID(unitCaster)
				srcName = UnitName(unitCaster)
			else
				srcGUID = "0x0000000000000000"
				srcName = "nil"
			end--AzMsg(spellName)
			ThievesTools.ParseEvents(timestamp, eventType, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags, spellId, spellName, spellSchool, auraType, count)
			
		end
		
		for i = 1, 80 do
			spellName, rank, icon, count, auraType, duration, expirationTime, unitCaster, isStealable, shouldConsolidate, spellId = UnitDebuff("target", i)
			if (spellName == nil) then break end
			if UnitExists(unitCaster) then
				srcGUID = UnitGUID(unitCaster)
				srcName = UnitName(unitCaster)
			else
				srcGUID = "0x0000000000000000"
				srcName = "nil"
			end
			ThievesTools.ParseEvents(timestamp, eventType, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags, spellId, spellName, spellSchool, auraType, count)
		end
	end
end

-----------------------------------------------------------------------
------------------ all things onupdate --------------------------------
-----------------------------------------------------------------------

function ThievesTools:UpdateCore()

	--keycheck for bar group movement
		--self:BarGroupKeyCheck()
		
		
		self.thetime = GetTime(); --update the time to something locally accessible
		
		if (self.startwatching == true) then 
			--slow update checks
			if (self.thetime - self.lasttime1s > 1) then
				self.maxnrg = UnitPowerMax(self.CEtoken)
				self:EnergyVisible()
				self:GetCombosEnergyToken()
				self.lasttime1s = self.thetime
				self:MissingAuras()
			end
			
			if (self.thetime - self.lasttime > 0.04) then --global update speed (hey update this to the one set in the profile, dummy!)
				self.combos = GetComboPoints(self.CEtoken) -- get combo points every update, not so efficient, consider using onevent for combo gains?
				self:UpdateCombos() --update the combos display
				ThievesTools:ComboFading() --update any combo fading
				ThievesTools:EnergyUpdate() --update energy meter
				self.targetGUID = UnitGUID("target") -- check the current target every update
				if self.targetGUID ~= self.lastGUID then
					self.lastGUID = self.targetGUID --so we can detect target changes
					ThievesTools:TargetChangeAuraCheck()
				end
				if self.activebuffbars > 0 then --if there's no active buffbars, don't bother trying to update them
					if not self.updatingbuffbars then self:UpdateBuffBars() end;
				end
				self.lasttime = self.thetime --update the time we last did an update cycle
				
				--self:LKprofanity()
			end
		end
end


function ThievesTools:LKprofanity()
	if not self.lkguid and (UnitName("target") == "The Lich King") then
		self.lkguid = UnitGUID("target")
	end
	
	if self.lkguid then
		local token = self:GetUnitID(self.lkguid)
		if token and UnitExists(token.."target") then
			local bphase = false
			for i = 1, 80 do
				name, _, _, count, _, duration, expirationTime, caster, _ = UnitDebuff(token, i)
				if name == nil then break end
				if strfind(name, "Frost Fever") then 
					bphase = true
					break 
				end
			end
				
			local lktarget = UnitName(token.."target")
			if bphase and (lktarget ~= self.lklasttarget) then
				if strfind("Pawpurr Panfuria", lktarget) then
				--nothing
				else
					local strann = "Look out! Lich King is targetting: ".. strupper(lktarget)
					--AzMsg(strann)
					SendChatMessage(strann , "RAID");
					self.lklasttarget = lktarget
				end
			end
		end
	end

end

function ThievesTools:MissingAuras()

	if self.InCombat == true then

		local i = 1
		while self.ap.barconfigs[i] do 
			if (self.ap.barconfigs[i].checkmissing == true) then
				if (self.ap.barconfigs[i].to == "player") or (self.ap.barconfigs[i].to == "target") then
					local theGUID
					if (self.ap.barconfigs[i].to == "player") then theGUID = self.playerGUID else theGUID = self.targetGUID end
					local havebar = false
					for j = 0, #self.buffbars do
						if self.buffbars[j] and self.buffbars[j].destGUID then
							if (self.buffbars[j].destGUID == theGUID) then
								if self.buffbars[j].config == i then
	
									havebar = true
								end
								
							end
						end
					end
					if havebar == false then
						local eventType, timestamp, srcGUID, srcName, srcFlags, dstGUID, dstName
						srcGUID = 0
						srcName = "none"
						srcFlags = "0"
						eventType = "TT_MISSING" 
						timestamp = self.thetime
						dstGUID = theGUID
						if (self.ap.barconfigs[i].to == "player") then dstName = UnitName("player") else dstName = UnitName("target") end
							self:CreateBuffBar(i, self.ap.barconfigs[i].shortname, timestamp, eventType, srcGUID, srcName, srcFlags, dstGUID, dstName, "0", 0, self.ap.barconfigs[i].buffname)
					end
				end
			end
			i = i + 1
		end
	else
		for j = 0, #self.buffbars do
			if self.buffbars[j] and self.buffbars[j].destGUID and self.buffbars[j].missing then
				self.buffbars[j].fadedestroy = true
				self.buffbars[j].fading = "OUT"
				self.buffbars[j].fadestart = self.thetime
				self.buffbars[j].active = false		
			end
		end
		
	end
end
--------------------------------------------------------------------------
------------------- class/talent/glyph parsing ---------------------------
--------------------------------------------------------------------------

function ThievesTools:GetPlayerInfo()
	if self.ap then -- check a profile is loaded
		self.playerGUID = UnitGUID("player") -- get the player's GUID
		self.playerclass = UnitClass("player") -- get the player's class
		if (self.playerclass == "Rogue") then  -- if it's a rogue, lets check the rogue specific things
			--check for glyphs that affect fixedsize bars
			local sndglyph = false
			local rupglyph = false
			for i = 1, 6 do
				local _, _, glyphID =GetGlyphSocketInfo(i);
				if glyphID == 56810 then sndglyph = true end;
				if glyphID == 56801 then rupglyph = true end;
			end
			
			--test
			--if sndglyph == true then AzMsg("detected snd glyph") end;
			--if rupglyph == true then AzMsg("detected rupture glyph") end;
			
			--snd talent check
			local i = 1
			while self.ap.barconfigs[i] do  -- cycle the barconfigs looking for slice or rupture and adjust the fixedsize combopoint related values to match glyphs/talents
				if (self.ap.barconfigs[i].spellid == 6774) then
					local _,_,_,_,rank=GetTalentInfo(2,4)
					if rank == 1 then self.ap.barconfigs[i].combo_multi = 1.25 end;
					if rank == 2 then self.ap.barconfigs[i].combo_multi = 1.5 end;
					--AzMsg("snd talent points - "..rank);
					if (sndglyph == true) then
						self.ap.barconfigs[i].combo_base = 9
					else
						self.ap.barconfigs[i].combo_base = 6
					end
				elseif (self.ap.barconfigs[i].spellid == 48672) then
					if (rupglyph == true) then
						self.ap.barconfigs[i].combo_base = 10
					else
						self.ap.barconfigs[i].combo_base = 6
					end
				end
			i = i + 1
			end
		end
	end
end
