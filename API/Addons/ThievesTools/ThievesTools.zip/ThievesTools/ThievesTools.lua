--- global object
ThievesTools = {}
ThievesTools.frames = {}
--current version
ThievesTools.version = 0.24


local L = TT_locale;
local modName = "ThievesTools";
local _ ;
local _G = getfenv(0);
local select = _G.select
local ThievesTools = _G.ThievesTools



--------------------------------------------------------------------------------------------------------
--                                Global Chat Message Function (Rev 3)                                --
--------------------------------------------------------------------------------------------------------
if (not AZMSG_REV or AZMSG_REV < 3) then
	AZMSG_REV = 3;
	function AzMsg(text)
		DEFAULT_CHAT_FRAME:AddMessage(tostring(text):gsub("|1","|cffffff80"):gsub("|2","|cffffffff"),128/255,192/255,255/255);
	end
end

-----------------------------------------------------------------------------
---------------- event handling frame, event handler, onupdatehandler -------
-----------------------------------------------------------------------------



 function ThievesTools:updateHandler()
 
	--local copy of thievestools object
	--local ThievesTools = _G.ThievesTools;
	--call the main updater in parser.lua
	ThievesTools:UpdateCore();
	
end



function ThievesTools:CreateEventFrame()

	self.frames.eventframe = CreateFrame("FRAME", _G[modName.."Events"]);
	
	--register events
	self.frames.eventframe:RegisterEvent("VARIABLES_LOADED");
	self.frames.eventframe:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	self.frames.eventframe:RegisterEvent("PLAYER_ENTERING_WORLD");
	self.frames.eventframe:RegisterEvent("SPELLS_CHANGED");
	self.frames.eventframe:RegisterEvent("ADDON_LOADED");
	self.frames.eventframe:RegisterEvent("PLAYER_REGEN_DISABLED");
	self.frames.eventframe:RegisterEvent("PLAYER_REGEN_ENABLED");
	--self.frames.eventframe:RegisterEvent("UPDATE_INVENTORY_ALERTS");
	--self.frames.eventframe:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED");
	--self.frames.eventframe:RegisterEvent("UNIT_TARGET");
	

	
	--register onupdate handler
	self.frames.eventframe:SetScript("OnUpdate", self.updateHandler);
end	

function ThievesTools:InitProfile()
	ThievesTools:CreateEnabledFrames()
	ThievesTools:CreateBuffBarGroups()
	ThievesTools:ConfigEvents()
	ThievesTools:FrameLocks(true)
	ThievesTools:InitCombosEnergy()
	ThievesTools:GetPlayerInfo()
end

local function eventHandler(self,event,...)

	--combat log message parsing
	if (ThievesTools.startwatching) and (event == "COMBAT_LOG_EVENT_UNFILTERED") then
		-- old lines, keep these
		-- local timestamp, eventType, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags = select(1,...)
		-- ThievesTools.ParseEvents(timestamp, eventType, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags, ...)
		--	new lines
		local timestamp, eventType, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags, spellId, spellName, spellSchool, auraType, count  = select(1,...)
		ThievesTools.ParseEvents(timestamp, eventType, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags, spellId, spellName, spellSchool, auraType, count, ...)
	--combat status
	elseif event == "PLAYER_REGEN_DISABLED" then
		ThievesTools.InCombat = true
	elseif event == "PLAYER_REGEN_ENABLED" then
		ThievesTools.lkguid = false --hacked lk target support
		ThievesTools.InCombat = false
		--hack to reset fixeddurlength for auras when combat ends, in case of spec changes
		if TT_ap and TT_profiles[TT_ap].barconfigs[1] then
			for i = 1, #TT_profiles[TT_ap].barconfigs do
				if TT_profiles[TT_ap].barconfigs[i].fixeddur then
					TT_profiles[TT_ap].barconfigs[i].fixeddurlength = 0
				end
			end
		end	
		
		
	
	-- Variables Loaded
	elseif (event == "VARIABLES_LOADED") then
		
		if (TT_ap == 0) or (TT_ap == nil) or not TT_profiles[1].barconfigs[1] then
			ThievesTools:config_defaults();
			ThievesTools:LoadProfile();
		else
			ThievesTools:LoadProfile();
			ThievesTools:UpgradeProfiles(); -- added to check existing profile, adding new variables in new versions
		end
		ThievesTools.lasttime = 0
		ThievesTools.lasttime1s = 0
		ThievesTools.playerGUID = UnitGUID("player")
		ThievesTools.activebuffbars = 0
		ThievesTools.lastnrg = 0
		ThievesTools.InCombat = false
		ThievesTools.CEtoken = "player"
		ThievesTools:InitOptions()
		ThievesTools:InitProfile()
		ThievesTools.lklasttarget = "none"
		--init done
		ThievesTools.startwatching = true
		
	--make sure we get player info updated somehow, 3 attempts here	
	elseif event == "PLAYER_ENTERING_WORLD" then
		ThievesTools:GetPlayerInfo()
	elseif event == "SPELLS_CHANGED" then
		ThievesTools:GetPlayerInfo()
	elseif event == "ADDON_LOADED" then
		ThievesTools:GetPlayerInfo()	
	end
	
	
end
--create event handler frame and register it
ThievesTools:CreateEventFrame();
ThievesTools.frames.eventframe:SetScript("OnEvent", eventHandler);



-------------------------------------------------------------------------------
---------------- function to load selected profile into ThievesTools object ---
-------------------------------------------------------------------------------

function ThievesTools:LoadProfile()
	self.ap = TT_profiles[TT_ap];
end


-------------------------------------------------------------------------------
-----------------  slash command handling -------------------------------------
-------------------------------------------------------------------------------

function ThievesTools.command(cmd)
	if cmd == "" then
		UpdateAddOnMemoryUsage()
		AzMsg(format("----- |2%s|r |1%s|r ----- |1%.2f |2kb|r -----",modName,GetAddOnMetadata(modName,"Version"),GetAddOnMemoryUsage(modName)));
		 InterfaceOptionsFrame_OpenToCategory(ThievesTools.frames.mainoptions.panel);
	elseif cmd == "defaults" then
		ThievesTools:config_defaults();
		ThievesTools:LoadProfile();
		AzMsg("TT defaults reloaded")
	elseif cmd == "lock" then
		ThievesTools:FrameLocks(true)
	elseif cmd == "unlock" then
		ThievesTools:FrameLocks(false)
	end
end

_G["SLASH_"..modName.."1"] = "/ttools";
_G["SLASH_"..modName.."2"] = "/tht";
SlashCmdList[modName] = ThievesTools.command;

