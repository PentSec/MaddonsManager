local L = TT_locale;
local modName = "ThievesTools";
local _ 
local _G = getfenv(0);
local select = _G.select;
local wipe = _G.wipe;
local t_sort = _G.table.sort;
local t_insert = _G.table.insert;
local t_remove = _G.table.remove;
local tonum = _G.tonumber;
local tostr = _G.tostring
local strbyte = _G.string.byte
local strsub = _G.string.sub
local pairs	= _G.pairs

local ThievesTools;
if not ThievesTools then ThievesTools = _G.ThievesTools end;

---------------------------------------------------------------------------------------------------
---------------------------- misc helper functions ------------------------------------------------
---------------------------------------------------------------------------------------------------

--this function will copy a table instead of referencing it, including subtables

function ThievesTools:deepcopy(object)
    local lookup_table = {}
    local function _copy(object)
        if type(object) ~= "table" then
            return object
        elseif lookup_table[object] then
            return lookup_table[object]
        end
        local new_table = {}
        lookup_table[object] = new_table
        for index, value in pairs(object) do
            new_table[_copy(index)] = _copy(value)
        end
        return setmetatable(new_table, getmetatable(object))
    end
    return _copy(object)
end

function ThievesTools:round(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end

-- called whenever an editbox text changes to fix the scrolling issue (always far right otherwise, can't see editbox text)

local function FixEditboxScroll(EditBox)
	EditBox:SetCursorPosition(0);
	EditBox:ClearFocus();
end

-----------------------------------------------------------------------------------------------------
--------------  Option panels creation and registration ---------------------------------------------
-----------------------------------------------------------------------------------------------------

------------------ Main options panel -------------------------


ThievesTools.frames.mainoptions = {}
local mainoptions = ThievesTools.frames.mainoptions
mainoptions.panel = CreateFrame( "Frame", "TT_mainoptsPanel", UIParent );
mainoptions.panel.name = modName
InterfaceOptions_AddCategory(mainoptions.panel)

local splittercolor = {0.4,0.4,0.4,1}


mainoptions.t1 = mainoptions.panel:CreateFontString("$parentText1", "OVERLAY", "GameFontNormalLarge", nil, "LEFT", "TOP", "ARTWORK")
mainoptions.t1:SetPoint("TOPLEFT", 16, -16)
mainoptions.t1:SetText(modName.." v"..ThievesTools.version)

mainoptions.t2 = mainoptions.panel:CreateFontString("$parentText2", "OVERLAY", "GameFontNormal", nil, "LEFT", "TOP", "ARTWORK")
mainoptions.t2:SetPoint("TOPLEFT", mainoptions.t1, "BOTTOMLEFT", 0, -16)
mainoptions.t2:SetPoint("RIGHT", mainoptions.panel, "RIGHT", -16, 0)
mainoptions.t2:SetWidth(250)
mainoptions.t2:SetJustifyH("LEFT")
mainoptions.t2:SetVertexColor(1,1,1,1)
mainoptions.t2:SetText(L.mainopt_infotext)

mainoptions.t3 = mainoptions.panel:CreateFontString("$parentText3", "OVERLAY", "GameFontNormal", nil, "LEFT", "TOP", "ARTWORK")
mainoptions.t3:SetPoint("TOPLEFT",  mainoptions.t2, "BOTTOMLEFT", 0, -32 );
mainoptions.t3:SetText(L.mainopt_profilelabel);

mainoptions.ProfileDeleteButton = CreateFrame("Button", "ProfileDeleteButton", mainoptions.panel, "UIPanelButtonTemplate");
mainoptions.ProfileDeleteButton:SetPoint("TOPLEFT",  mainoptions.t3, "BOTTOMLEFT", 150, -10); 
mainoptions.ProfileDeleteButton:SetText(L.mainopt_delprof);
mainoptions.ProfileDeleteButton:SetHeight(25)
mainoptions.ProfileDeleteButton:SetWidth(100)
--ProfileDeleteButton:SetVertexColor(0.5, 0.5, 0.5, 1)

mainoptions.ProfileDropDownMenu = CreateFrame("Frame", "ProfileDropDownMenu", mainoptions.panel, "UIDropDownMenuTemplate");
ProfileDropDownMenu:SetPoint("TOPRIGHT", mainoptions.ProfileDeleteButton, "TOPLEFT", 10, 3);
UIDropDownMenu_SetWidth(mainoptions.ProfileDropDownMenu, 90)

mainoptions.t4 = mainoptions.panel:CreateFontString("$parentText4", "OVERLAY", "GameFontNormal", nil, "LEFT", "TOP", "ARTWORK")
mainoptions.t4:SetPoint("TOPLEFT",  mainoptions.t3, "BOTTOMLEFT", 0, -64);
mainoptions.t4:SetText(L.mainopt_copyproflabel);

mainoptions.ProfileCreateButton = CreateFrame("Button", "ProfileCreateButton", mainoptions.panel, "UIPanelButtonTemplate");
mainoptions.ProfileCreateButton:SetPoint("TOPLEFT",  mainoptions.t4, "BOTTOMLEFT", 150, -16); 
mainoptions.ProfileCreateButton:SetText(L.mainopt_createprof);
mainoptions.ProfileCreateButton:SetHeight(25)
mainoptions.ProfileCreateButton:SetWidth(100)

mainoptions.ProfileEditBox = CreateFrame ( "EditBox", "$parentEditBox1", mainoptions.panel, "InputBoxTemplate")
mainoptions.ProfileEditBox:SetPoint("RIGHT", mainoptions.ProfileCreateButton, "LEFT", -5, -2); 
mainoptions.ProfileEditBox:SetHeight(15)
mainoptions.ProfileEditBox:Show()
mainoptions.ProfileEditBox:SetWidth(100)
mainoptions.ProfileEditBox:SetAutoFocus(false)
mainoptions.ProfileEditBox:ClearFocus()
mainoptions.ProfileEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end)
mainoptions.ProfileEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end)
--ProfileEditBox:SetScript("OnEditFocusLost", function(self) FixEditboxScroll(self) end)


mainoptions.MoveFramesButton = CreateFrame("Button", "ProfileCreateButton", mainoptions.panel, "UIPanelButtonTemplate");
mainoptions.MoveFramesButton:SetPoint("TOPLEFT",  mainoptions.ProfileEditBox, "BOTTOMLEFT", 100, -96);
mainoptions.MoveFramesButton:SetText(L.mainopt_moveframes);
mainoptions.MoveFramesButton:SetHeight(25)
mainoptions.MoveFramesButton:SetWidth(100)

----------------- end main options panel ---------------------------------------------






----------------- bar options panel ---------------------------------------------------

ThievesTools.frames.baroptions = {}
ThievesTools.frames.baroptions.panel = CreateFrame( "Frame", "TT_baroptsPanel", UIParent );
ThievesTools.frames.baroptions.panel.name = L.auraopt_label
ThievesTools.frames.baroptions.panel.parent = modName
InterfaceOptions_AddCategory(ThievesTools.frames.baroptions.panel)

----------------- end bar options panel ------------------------------------------------






----------- bar configs panel  -------------------------------------------------------

ThievesTools.frames.barconfs = {}
local barconfs = ThievesTools.frames.barconfs
barconfs.panel = CreateFrame( "Frame", "TT_barconfsPanel", UIParent );
barconfs.panel.name = L.auraconf_label
barconfs.panel.parent = modName
barconfs.panel.okay = function (self) ThievesTools:ConfigEvents() ThievesTools:CreateEnabledFrames() ThievesTools:CreateBuffBarGroups() collectgarbage("collect") end
InterfaceOptions_AddCategory(barconfs.panel)

barconfs.bct1 = barconfs.panel:CreateFontString("$parentText1", "OVERLAY", "GameFontNormalLarge", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bct1:SetPoint("TOPLEFT", 16, -16)
barconfs.bct1:SetText(L.auraconf_label)

barconfs.bct2 = barconfs.panel:CreateFontString("$parentText2", "OVERLAY", "GameFontNormal", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bct2:SetPoint("TOPLEFT",  barconfs.bct1, "BOTTOMLEFT", 0, -16 );
barconfs.bct2:SetText(L.auraconf_activeconf);

barconfs.BarConfigDropDownMenu = CreateFrame("Frame", "BarConfigDropDownMenu", barconfs.panel, "UIDropDownMenuTemplate");
barconfs.BarConfigDropDownMenu:SetPoint("TOPLEFT", barconfs.bct2, "TOPLEFT", barconfs.bct2:GetWidth() +5, 6);
UIDropDownMenu_SetWidth(barconfs.BarConfigDropDownMenu, 90)

barconfs.BarConfigNewButton = CreateFrame("Button", "BarconfigNewButton", barconfs.panel, "UIPanelButtonTemplate");
barconfs.BarConfigNewButton:SetPoint("BOTTOM",  barconfs.bct2, "BOTTOM", 0, -5); 
barconfs.BarConfigNewButton:SetPoint("RIGHT",  barconfs.panel, "RIGHT", -16, 0);
barconfs.BarConfigNewButton:SetText(L.auraconf_newconf);
barconfs.BarConfigNewButton:SetHeight(25)
barconfs.BarConfigNewButton:SetWidth(100)

barconfs.BarConfigDeleteButton = CreateFrame("Button", "BarConfigDeleteButton", barconfs.panel, "UIPanelButtonTemplate");
barconfs.BarConfigDeleteButton:SetPoint("BOTTOM",  barconfs.BarConfigNewButton, "TOP", 0, 4); 
barconfs.BarConfigDeleteButton:SetPoint("RIGHT",  barconfs.panel, "RIGHT", -16, 0); 
barconfs.BarConfigDeleteButton:SetText(L.auraconf_delconf);
barconfs.BarConfigDeleteButton:SetHeight(25)
barconfs.BarConfigDeleteButton:SetWidth(100)


barconfs.BarConfigCloneButton = CreateFrame("Button", "BarconfigCloneButton", barconfs.panel, "UIPanelButtonTemplate");
barconfs.BarConfigCloneButton:SetPoint("TOP",  barconfs.BarConfigNewButton, "BOTTOM", 0, -4); 
barconfs.BarConfigCloneButton:SetPoint("RIGHT",  barconfs.panel, "RIGHT", -16, 0); 
barconfs.BarConfigCloneButton:SetText(L.auraconf_cloneconf);
barconfs.BarConfigCloneButton:SetHeight(25)
barconfs.BarConfigCloneButton:SetWidth(100)





----- barconfig sub-frame -----------------

barconfs.BarConfigFrame = CreateFrame("Frame", "BarconfigFrame", barconfs.panel, "OptionsBoxTemplate")
barconfs.BarConfigFrame:SetPoint("TOPLEFT", barconfs.panel, "TOPLEFT", 16, -100)
barconfs.BarConfigFrame:SetPoint("BOTTOMRIGHT", barconfs.panel, "BOTTOMRIGHT", -16, 16)


--hidden frame for positioning buttons and other items in the subframes
barconfs.tinycenterframe = CreateFrame("Frame", "tinycenterframe", barconfs.BarConfigFrame);
barconfs.tinycenterframe:SetPoint("TOP",  barconfs.BarConfigFrame, "TOP", 0, -12);
barconfs.tinycenterframe:SetPoint("CENTER",  barconfs.BarConfigFrame, "CENTER", 0, -16);
barconfs.tinycenterframe:SetHeight(1)
barconfs.tinycenterframe:SetWidth(1)
barconfs.tinycenterframe:Hide()

barconfs.aligncenterframe = CreateFrame("Frame", "aligncenterframe", barconfs.BarConfigFrame);
barconfs.aligncenterframe:SetPoint("TOP",  barconfs.BarConfigFrame, "TOP", 0, -12);
barconfs.aligncenterframe:SetPoint("CENTER",  barconfs.BarConfigFrame, "CENTER", 0, -16);
barconfs.aligncenterframe:SetHeight(25)
barconfs.aligncenterframe:SetWidth(80)
barconfs.aligncenterframe:Hide()




barconfs.BarConfigAuraButton = CreateFrame("Button", "BarconfigAuraButton", barconfs.BarConfigFrame, "UIPanelButtonGrayTemplate");
barconfs.BarConfigAuraButton:SetPoint("TOPLEFT",  barconfs.BarConfigFrame, "TOPLEFT", 16, -12); 
barconfs.BarConfigAuraButton:SetText(L.auraconf_aurasets);
barconfs.BarConfigAuraButton:SetHeight(25)
barconfs.BarConfigAuraButton:SetWidth(80)

barconfs.BarConfigExtrasButton = CreateFrame("Button", "BarconfigExtrasButton", barconfs.BarConfigFrame, "UIPanelButtonGrayTemplate");
barconfs.BarConfigExtrasButton:SetPoint("TOPRIGHT",  barconfs.BarConfigFrame, "TOPRIGHT", -16, -12); 
barconfs.BarConfigExtrasButton:SetText(L.auraconf_extrasets);
barconfs.BarConfigExtrasButton:SetHeight(25)
barconfs.BarConfigExtrasButton:SetWidth(80)


barconfs.leftcenterframe = CreateFrame("Frame", "leftcenterframe", barconfs.BarConfigFrame);
barconfs.leftcenterframe:SetPoint("TOP",  barconfs.BarConfigFrame, "TOP", 0, -12);
barconfs.leftcenterframe:SetPoint("LEFT",  barconfs.BarConfigAuraButton, "RIGHT", 0, -16);
barconfs.leftcenterframe:SetPoint("RIGHT",  barconfs.tinycenterframe, "LEFT", 0, -16);
barconfs.leftcenterframe:Hide()

barconfs.rightcenterframe = CreateFrame("Frame", "rightcenterframe", barconfs.BarConfigFrame);
barconfs.rightcenterframe:SetPoint("TOP",  barconfs.BarConfigFrame, "TOP", 0, -12);
barconfs.rightcenterframe:SetPoint("RIGHT",  barconfs.BarConfigExtrasButton, "LEFT", 0, -16);
barconfs.rightcenterframe:SetPoint("LEFT",  barconfs.tinycenterframe, "RIGHT", 0, -16);
barconfs.rightcenterframe:Hide()

barconfs.BarConfigBarButton = CreateFrame("Button", "BarconfigBarButton", barconfs.BarConfigFrame, "UIPanelButtonGrayTemplate");
barconfs.BarConfigBarButton:SetPoint("CENTER",  barconfs.leftcenterframe, "CENTER", 0, 0);
barconfs.BarConfigBarButton:SetPoint("TOP",  barconfs.leftcenterframe, "TOP", 0, 0);
barconfs.BarConfigBarButton:SetText(L.auraconf_barsets);
barconfs.BarConfigBarButton:SetHeight(25)
barconfs.BarConfigBarButton:SetWidth(80)

barconfs.BarConfigBar2Button = CreateFrame("Button", "BarconfigBar2Button", barconfs.BarConfigFrame, "UIPanelButtonGrayTemplate");
barconfs.BarConfigBar2Button:SetPoint("TOP",  barconfs.rightcenterframe, "TOP", 0, 0);
barconfs.BarConfigBar2Button:SetPoint("CENTER",  barconfs.rightcenterframe, "CENTER", 0, 0);
barconfs.BarConfigBar2Button:SetText(L.auraconf_barsets2);
barconfs.BarConfigBar2Button:SetHeight(25)
barconfs.BarConfigBar2Button:SetWidth(80)



------------barconfig aura settings frame ---------

--subframe tied to the Aura Settings button
barconfs.BarConfigAuraFrame = CreateFrame("Frame", "BarconfigFrame", barconfs.BarConfigFrame)
barconfs.BarConfigAuraFrame:SetPoint("TOPLEFT", barconfs.BarConfigFrame, "TOPLEFT", 0, -45)
barconfs.BarConfigAuraFrame:SetPoint("RIGHT", barconfs.BarConfigFrame, "RIGHT", 0, 0)
barconfs.BarConfigAuraFrame:SetPoint("BOTTOM", barconfs.BarConfigFrame, "BOTTOM", 0, 0)

--config name label
barconfs.bcat1 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText1", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat1:SetPoint("TOPLEFT", 16, -8)
barconfs.bcat1:SetText(L.auraconf_barnamelabel)

--config name editbox
barconfs.BarNameEditBox = CreateFrame ( "EditBox", "$parentEditBox1", barconfs.BarConfigAuraFrame, "InputBoxTemplate")
barconfs.BarNameEditBox:SetPoint("BOTTOMLEFT",  barconfs.bcat1, "BOTTOMRIGHT", 8, 0); 
barconfs.BarNameEditBox:SetHeight(12)
barconfs.BarNameEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.BarNameEditBox:Show()
barconfs.BarNameEditBox:SetWidth(100)
barconfs.BarNameEditBox:SetAutoFocus(false)
barconfs.BarNameEditBox:ClearFocus()

--config enable checkbox label
barconfs.bcat2 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText2", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat2:SetPoint("RIGHT",  barconfs.BarConfigAuraFrame, "RIGHT", -16, 0);
barconfs.bcat2:SetPoint("BOTTOM",  barconfs.bcat1, "BOTTOM", 0, 0);
barconfs.bcat2:SetText(L.auraconf_barenabled)

--config enable checkbox object
barconfs.BarEnabledCheck = CreateFrame("CheckButton","$parentCheckBox1", barconfs.BarConfigAuraFrame, "UICheckButtonTemplate")
barconfs.BarEnabledCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcat2, "BOTTOMLEFT", -1, -5); 
barconfs.BarEnabledCheck:SetHeight(20)
barconfs.BarEnabledCheck:SetWidth(20)

--aura name(s) editbox
barconfs.AuraNameEditBox = CreateFrame ( "EditBox", "$parentEditBox2", barconfs.BarConfigAuraFrame, "InputBoxTemplate")
barconfs.AuraNameEditBox:SetPoint("TOPLEFT",  barconfs.BarNameEditBox, "BOTTOMLEFT", 0, -16); 
barconfs.AuraNameEditBox:SetHeight(12)
barconfs.AuraNameEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.AuraNameEditBox:Show()
barconfs.AuraNameEditBox:SetWidth(100)
barconfs.AuraNameEditBox:SetAutoFocus(false)
barconfs.AuraNameEditBox:ClearFocus()

--aura name(s) editbox label
barconfs.bcat3 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText3", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat3:SetPoint("BOTTOMRIGHT", barconfs.AuraNameEditBox, "BOTTOMLEFT", -8, 0)
barconfs.bcat3:SetText(L.auraconf_auranames)

--auratype dropdown
barconfs.AuraTypeDropDownMenu = CreateFrame("Frame", "AuraTypeDropDownMenu", barconfs.BarConfigAuraFrame, "UIDropDownMenuTemplate");
barconfs.AuraTypeDropDownMenu:SetPoint("RIGHT",  barconfs.BarConfigAuraFrame, "RIGHT", 0, 0);
barconfs.AuraTypeDropDownMenu:SetPoint("BOTTOM",  barconfs.bcat3, "BOTTOM", 0, -20);
UIDropDownMenu_SetWidth(barconfs.AuraTypeDropDownMenu, 70)

--auratype dropdown label
barconfs.bcat4 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText4", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat4:SetPoint("BOTTOMLEFT", barconfs.AuraTypeDropDownMenu, "TOPLEFT", 18, 0)
barconfs.bcat4:SetText(L.auraconf_auratype)

--aura shortname(s) editbox
barconfs.ShortNameEditBox = CreateFrame ( "EditBox", "$parentEditBox3", barconfs.BarConfigAuraFrame, "InputBoxTemplate")
barconfs.ShortNameEditBox:SetPoint("TOPLEFT", barconfs.AuraNameEditBox, "BOTTOMLEFT", 0, -16)
barconfs.ShortNameEditBox:SetHeight(12)
barconfs.ShortNameEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.ShortNameEditBox:Show()
barconfs.ShortNameEditBox:SetWidth(100)
barconfs.ShortNameEditBox:SetAutoFocus(false)
barconfs.ShortNameEditBox:ClearFocus()

--aura shortname(s) editbox label
barconfs.bcat5 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText5", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat5:SetPoint("BOTTOMRIGHT", barconfs.ShortNameEditBox, "BOTTOMLEFT", -8, 0); 
barconfs.bcat5:SetText(L.auraconf_shortnames)

--aura priority editbox label
barconfs.bcat12 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText12", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat12:SetPoint("LEFT", barconfs.bcat4, "LEFT", 0, 0);
barconfs.bcat12:SetPoint("BOTTOM", barconfs.bcat5, "BOTTOM", 0, 0);
barconfs.bcat12:SetText(L.auraconf_rank)

--aura priority editbox 
barconfs.AuraRankEditBox = CreateFrame ( "EditBox", "$parentEditBox6", barconfs.BarConfigAuraFrame, "InputBoxTemplate")
barconfs.AuraRankEditBox:SetPoint("BOTTOMLEFT", barconfs.bcat12, "BOTTOMRIGHT", 8, -2)
barconfs.AuraRankEditBox:SetHeight(12)
barconfs.AuraRankEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.AuraRankEditBox:Show()
barconfs.AuraRankEditBox:SetWidth(35)
barconfs.AuraRankEditBox:SetNumeric(true)
barconfs.AuraRankEditBox:SetAutoFocus(false)
barconfs.AuraRankEditBox:ClearFocus()

-- aura names ends splitter
barconfs.bcabnamesplit = CreateFrame("Frame", "TTbcabnamesplit", barconfs.BarConfigAuraFrame)
barconfs.bcabnamesplit:SetPoint("TOP", barconfs.bcat5, "BOTTOM", 0, -26)
barconfs.bcabnamesplit:SetPoint("LEFT", barconfs.BarConfigAuraFrame, "LEFT", 32, 0)
barconfs.bcabnamesplit:SetPoint("RIGHT", barconfs.BarConfigAuraFrame, "RIGHT", -32, 0)
barconfs.bcabnamesplit:SetWidth(16)
barconfs.bcabnamesplit:SetHeight(1)
barconfs.bcabnamesplit:SetBackdrop({bgFile=L.mainbgFile, edgeFile="", tile = false, tileSize = 0, edgeSize = 0, insets = { left = 0, right = 0, top = 0, bottom = 0 }})
barconfs.bcabnamesplit:SetBackdropColor(0.4,0.4,0.4,1)


--aura fullscan checkbox label
barconfs.bcat10 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText10", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat10:SetPoint("LEFT", barconfs.BarConfigAuraFrame, "LEFT", 36, 0);
barconfs.bcat10:SetPoint("BOTTOM", barconfs.BarConfigAuraFrame, "BOTTOM", 0, 16);
barconfs.bcat10:SetText(L.auraconf_fullscan)

--aura fullscan checkbox
barconfs.FullscanEnabledCheck = CreateFrame("CheckButton","$parentCheckBox2", barconfs.BarConfigAuraFrame, "UICheckButtonTemplate")
barconfs.FullscanEnabledCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcat10, "BOTTOMLEFT", -1, -5); 
barconfs.FullscanEnabledCheck:SetHeight(20)
barconfs.FullscanEnabledCheck:SetWidth(20)

--aura fixed duration checkbox label
barconfs.bcat11 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText11", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat11:SetPoint("LEFT",  barconfs.aligncenterframe, "LEFT", 16, 0);
barconfs.bcat11:SetPoint("BOTTOM", barconfs.BarConfigAuraFrame, "BOTTOM", 0, 16);
barconfs.bcat11:SetText(L.auraconf_fixedduration)

--aura fullscan checkbox
barconfs.FixedDurCheck = CreateFrame("CheckButton","$parentCheckBox3", barconfs.BarConfigAuraFrame, "UICheckButtonTemplate")
barconfs.FixedDurCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcat11, "BOTTOMLEFT", -1, -5); 
barconfs.FixedDurCheck:SetHeight(20)
barconfs.FixedDurCheck:SetWidth(20)


--aura missing checkbox label
barconfs.bcat14 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText14", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat14:SetPoint("LEFT",  barconfs.bcat2, "LEFT", 0, 0);
barconfs.bcat14:SetPoint("BOTTOM", barconfs.BarConfigAuraFrame, "BOTTOM", 0, 16);
barconfs.bcat14:SetText(L.auraconf_showmissing)

--aura missing checkbox
barconfs.MissingCheck = CreateFrame("CheckButton","$parentCheckBox3", barconfs.BarConfigAuraFrame, "UICheckButtonTemplate")
barconfs.MissingCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcat14, "BOTTOMLEFT", -1, -5); 
barconfs.MissingCheck:SetHeight(20)
barconfs.MissingCheck:SetWidth(20)


--aura dest dropdown label
barconfs.bcat7 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText7", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat7:SetPoint("BOTTOM", barconfs.bcat10, "TOP", 0, 40);
barconfs.bcat7:SetPoint("LEFT", barconfs.BarConfigAuraFrame, "LEFT", 16, 0);
barconfs.bcat7:SetText(L.auraconf_showto)


--aura dest dropdown
barconfs.AuraToDropDownMenu = CreateFrame("Frame", "TTAuraToDropDownMenu", barconfs.BarConfigAuraFrame, "UIDropDownMenuTemplate");
barconfs.AuraToDropDownMenu:SetPoint("TOPLEFT", barconfs.bcat7, "BOTTOMLEFT", 0, 0);
UIDropDownMenu_SetWidth(barconfs.AuraToDropDownMenu, 70)


--aura source dropdown label
barconfs.bcat6 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText6", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat6:SetPoint("BOTTOM", barconfs.bcat7, "TOP", 0, 32);
barconfs.bcat6:SetPoint("LEFT", barconfs.BarConfigAuraFrame, "LEFT", 16, 0);
barconfs.bcat6:SetText(L.auraconf_showfrom)

--aura source dropdown 
barconfs.AuraFromDropDownMenu = CreateFrame("Frame", "TTAuraFromDropDownMenu", barconfs.BarConfigAuraFrame, "UIDropDownMenuTemplate");
barconfs.AuraFromDropDownMenu:SetPoint("TOPLEFT", barconfs.bcat6, "BOTTOMLEFT", 0, 0);
UIDropDownMenu_SetWidth(barconfs.AuraFromDropDownMenu, 70)


--aura named source editbox label
barconfs.bcat8 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText8", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat8:SetPoint("BOTTOMLEFT", barconfs.bcat6, "BOTTOMLEFT", 130, 0);
barconfs.bcat8:SetPoint("LEFT", barconfs.aligncenterframe, "LEFT", 0, 0);
barconfs.bcat8:SetText(L.auraconf_namedlabel)

--aura named source editbox 
barconfs.AuraFromNameEditBox = CreateFrame ( "EditBox", "$parentEditBox4", barconfs.BarConfigAuraFrame, "InputBoxTemplate")
barconfs.AuraFromNameEditBox:SetPoint("TOPLEFT", barconfs.bcat8, "BOTTOMLEFT", 20, -5)
barconfs.AuraFromNameEditBox:SetHeight(12)
barconfs.AuraFromNameEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.AuraFromNameEditBox:Show()
barconfs.AuraFromNameEditBox:SetWidth(100)
barconfs.AuraFromNameEditBox:SetAutoFocus(false)
barconfs.AuraFromNameEditBox:ClearFocus()

--aura named dest editbox label
barconfs.bcat9 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText9", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat9:SetPoint("LEFT", barconfs.aligncenterframe, "LEFT", 0, 0);
barconfs.bcat9:SetPoint("BOTTOMLEFT", barconfs.bcat7, "BOTTOMLEFT", 130, 0);
barconfs.bcat9:SetText(L.auraconf_namedlabel)

--aura named dest editbox 
barconfs.AuraToNameEditBox = CreateFrame ( "EditBox", "$parentEditBox5", barconfs.BarConfigAuraFrame, "InputBoxTemplate")
barconfs.AuraToNameEditBox:SetPoint("TOPLEFT", barconfs.bcat9, "BOTTOMLEFT", 20, -5)
barconfs.AuraToNameEditBox:SetHeight(12)
barconfs.AuraToNameEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.AuraToNameEditBox:Show()
barconfs.AuraToNameEditBox:SetWidth(100)
barconfs.AuraToNameEditBox:SetAutoFocus(false)
barconfs.AuraToNameEditBox:ClearFocus()

--aura has charges checkbox label
barconfs.bcat12 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText12", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat12:SetPoint("LEFT",  barconfs.bcat2, "LEFT", 0, 0);
barconfs.bcat12:SetPoint("BOTTOM", barconfs.bcat6, "BOTTOM", 0, 0);
barconfs.bcat12:SetText(L.auraconf_updatecharges)

--aura has charges checkbox
barconfs.ChargesCheck = CreateFrame("CheckButton","$parentCheckBox3", barconfs.BarConfigAuraFrame, "UICheckButtonTemplate")
barconfs.ChargesCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcat12, "BOTTOMLEFT", -1, -5); 
barconfs.ChargesCheck:SetHeight(20)
barconfs.ChargesCheck:SetWidth(20)

--aura has charges checkbox label
barconfs.bcat15 = barconfs.BarConfigAuraFrame:CreateFontString("$parentText12", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcat15:SetPoint("LEFT",  barconfs.bcat2, "LEFT", 0, 0);
barconfs.bcat15:SetPoint("BOTTOM", barconfs.bcat7, "BOTTOM", 0, 0);
barconfs.bcat15:SetText(L.auraconf_suppress)

--aura has charges checkbox
barconfs.SuppressCheck = CreateFrame("CheckButton","$parentCheckBox3", barconfs.BarConfigAuraFrame, "UICheckButtonTemplate")
barconfs.SuppressCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcat15, "BOTTOMLEFT", -1, -5); 
barconfs.SuppressCheck:SetHeight(20)
barconfs.SuppressCheck:SetWidth(20)


------------ end barconfig aura settings frame ---------

------------barconfig bar settings frame ---------

barconfs.BarConfigBarFrame = CreateFrame("Frame", "BarconfigBarFrame", barconfs.BarConfigFrame)
barconfs.BarConfigBarFrame:SetPoint("TOPLEFT", barconfs.BarConfigFrame, "TOPLEFT", 0, -45)
barconfs.BarConfigBarFrame:SetPoint("RIGHT", barconfs.BarConfigFrame, "RIGHT", 0, 0)
barconfs.BarConfigBarFrame:SetPoint("BOTTOM", barconfs.BarConfigFrame, "BOTTOM", 0, 0)
barconfs.BarConfigBarFrame:Hide()

--bar color picker label
barconfs.bcbt1 = barconfs.BarConfigBarFrame:CreateFontString("$parentText1", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt1:SetPoint("TOPLEFT", barconfs.BarConfigBarFrame, "TOPLEFT", 16, -8);
barconfs.bcbt1:SetText(L.auraconf_barcolor)

--bar color picker frame
barconfs.BarColorFrame = CreateFrame("Frame", "TTBarconfigBarColorFrame", barconfs.BarConfigBarFrame)
barconfs.BarColorFrame:SetPoint("CENTER", barconfs.bcbt1, "CENTER", 0, -3)
barconfs.BarColorFrame:SetPoint("LEFT", barconfs.bcbt1, "RIGHT", 5, 0)
barconfs.BarColorFrame:SetWidth(80)
barconfs.BarColorFrame:SetHeight(16)
barconfs.BarColorFrame:SetBackdrop({bgFile=L.mainbgFile, edgeFile="", tile = false, tileSize = 0, edgeSize = 0, insets = { left = 0, right = 0, top = 0, bottom = 0 }})
barconfs.BarColorFrame:SetBackdropColor(0,0,0,0.5)
barconfs.BarColorFrame:EnableMouse(1);

--bar color picker frame texture
barconfs.bartexture = barconfs.BarColorFrame:CreateTexture(nil, "ARTWORK");
barconfs.bartexture:SetPoint("TOPRIGHT")
barconfs.bartexture:SetWidth(80)
barconfs.bartexture:SetHeight(16)


--bar width editbox label
barconfs.bcbt2 = barconfs.BarConfigBarFrame:CreateFontString("$parentText2", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt2:SetPoint("BOTTOM", barconfs.bcbt1, "BOTTOM", 0, 0);
barconfs.bcbt2:SetPoint("LEFT", barconfs.BarColorFrame, "RIGHT", 10, 0);
barconfs.bcbt2:SetText(L.auraconf_width)

--bar width editbox
barconfs.BarWidthEditBox = CreateFrame ( "EditBox", "$parentEditBox1", barconfs.BarConfigBarFrame, "InputBoxTemplate")
barconfs.BarWidthEditBox:SetPoint("CENTER", barconfs.bcbt2, "CENTER", 0, 0)
barconfs.BarWidthEditBox:SetPoint("LEFT", barconfs.bcbt2, "RIGHT", 10, 0)
barconfs.BarWidthEditBox:SetHeight(12)
barconfs.BarWidthEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.BarWidthEditBox:Show()
barconfs.BarWidthEditBox:SetWidth(35)
barconfs.BarWidthEditBox:SetNumeric(true)
barconfs.BarWidthEditBox:SetAutoFocus(false)
barconfs.BarWidthEditBox:ClearFocus()

--bar height editbox label
barconfs.bcbt3 = barconfs.BarConfigBarFrame:CreateFontString("$parentText3", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt3:SetPoint("BOTTOM", barconfs.bcbt1, "BOTTOM", 0, 0);
barconfs.bcbt3:SetPoint("LEFT", barconfs.BarWidthEditBox, "RIGHT", 10, 0);
barconfs.bcbt3:SetText(L.auraconf_height)

--bar height editbox
barconfs.BarHeightEditBox = CreateFrame ( "EditBox", "$parentEditBox2", barconfs.BarConfigBarFrame, "InputBoxTemplate")
barconfs.BarHeightEditBox:SetPoint("CENTER", barconfs.bcbt3, "CENTER", 0, 0)
barconfs.BarHeightEditBox:SetPoint("LEFT", barconfs.bcbt3, "RIGHT", 10, 0)
barconfs.BarHeightEditBox:SetHeight(12)
barconfs.BarHeightEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.BarHeightEditBox:Show()
barconfs.BarHeightEditBox:SetWidth(35)
barconfs.BarHeightEditBox:SetNumeric(true)
barconfs.BarHeightEditBox:SetAutoFocus(false)
barconfs.BarHeightEditBox:ClearFocus()

--show spark checkbox label
barconfs.bcbt18 = barconfs.BarConfigBarFrame:CreateFontString("$parentText18", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt18:SetPoint("TOPLEFT", barconfs.bcbt1, "BOTTOMLEFT", 16, -18);
barconfs.bcbt18:SetText(L.auraconf_barspark)

--show spark checkbox
barconfs.BarSparkCheck = CreateFrame("CheckButton","$parentCheckBox5", barconfs.BarConfigBarFrame, "UICheckButtonTemplate")
barconfs.BarSparkCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcbt18, "BOTTOMLEFT", -1, -5); 
barconfs.BarSparkCheck:SetHeight(20)
barconfs.BarSparkCheck:SetWidth(20)

--show periodic spark checkbox label
barconfs.bcbt19 = barconfs.BarConfigBarFrame:CreateFontString("$parentText19", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt19:SetPoint("TOPLEFT", barconfs.bcbt18, "BOTTOMLEFT", 0, -12);
barconfs.bcbt19:SetText(L.auraconf_barperiodspark)

--show periodic spark checkbox
barconfs.BarPeriodSparkCheck = CreateFrame("CheckButton","$parentCheckBox6", barconfs.BarConfigBarFrame, "UICheckButtonTemplate")
barconfs.BarPeriodSparkCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcbt19, "BOTTOMLEFT", -1, -5); 
barconfs.BarPeriodSparkCheck:SetHeight(20)
barconfs.BarPeriodSparkCheck:SetWidth(20)

--Bar group dropdown label
barconfs.bcbt15 = barconfs.BarConfigBarFrame:CreateFontString("$parentText15", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt15:SetPoint("BOTTOM", barconfs.bcbt18, "BOTTOM", 0, 0);
barconfs.bcbt15:SetPoint("LEFT", barconfs.aligncenterframe, "LEFT", 0, 0);
barconfs.bcbt15:SetText(L.auraconf_bargroupdef)

--bar group dropdown
barconfs.DefBarGroupDropDownMenu = CreateFrame("Frame", "TTDefBarGroupDropDownMenu", barconfs.BarConfigBarFrame, "UIDropDownMenuTemplate");
barconfs.DefBarGroupDropDownMenu:SetPoint("TOPLEFT", barconfs.bcbt15, "BOTTOMLEFT", -18, 0);
UIDropDownMenu_SetWidth(barconfs.DefBarGroupDropDownMenu, 70)

--bar group pin checkbox label
barconfs.bcbt16 = barconfs.BarConfigBarFrame:CreateFontString("$parentText16", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt16:SetPoint("LEFT", barconfs.BarConfigExtrasButton, "LEFT", 16, 0);
barconfs.bcbt16:SetPoint("BOTTOM", barconfs.bcbt18, "BOTTOM", 0, 0);
barconfs.bcbt16:SetText(L.auraconf_bargrouppin)

--bar group pin checkbox
barconfs.PinBarGroupCheck = CreateFrame("CheckButton","$parentCheckBox3", barconfs.BarConfigBarFrame, "UICheckButtonTemplate")
barconfs.PinBarGroupCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcbt16, "BOTTOMLEFT", -1, -5); 
barconfs.PinBarGroupCheck:SetHeight(20)
barconfs.PinBarGroupCheck:SetWidth(20)

--bar group unpin self checkbox label
barconfs.bcbt17 = barconfs.BarConfigBarFrame:CreateFontString("$parentText17", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt17:SetPoint("TOPLEFT", barconfs.bcbt16, "BOTTOMLEFT", 0, -12);
barconfs.bcbt17:SetText(L.auraconf_bargroupownbuff)

--bar group unpin self checkbox
barconfs.PinOwnBarGroupCheck = CreateFrame("CheckButton","$parentCheckBox4", barconfs.BarConfigBarFrame, "UICheckButtonTemplate")
barconfs.PinOwnBarGroupCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcbt17, "BOTTOMLEFT", -1, -5); 
barconfs.PinOwnBarGroupCheck:SetHeight(20)
barconfs.PinOwnBarGroupCheck:SetWidth(20)

--bar option section end splitter frame
barconfs.bcbbaroptsplit = CreateFrame("Frame", "TTbcbalphasplit", barconfs.BarConfigBarFrame)
barconfs.bcbbaroptsplit:SetPoint("TOP", barconfs.bcbt19, "BOTTOM", 0, -18)
barconfs.bcbbaroptsplit:SetPoint("LEFT", barconfs.BarConfigBarFrame, "LEFT", 32, 0)
barconfs.bcbbaroptsplit:SetPoint("RIGHT", barconfs.BarConfigBarFrame, "RIGHT", -32, 0)
barconfs.bcbbaroptsplit:SetWidth(16)
barconfs.bcbbaroptsplit:SetHeight(1)
barconfs.bcbbaroptsplit:SetBackdrop({bgFile=L.mainbgFile, edgeFile="", tile = false, tileSize = 0, edgeSize = 0, insets = { left = 0, right = 0, top = 0, bottom = 0 }})
barconfs.bcbbaroptsplit:SetBackdropColor(0.4,0.4,0.4,1)


--font size label
barconfs.bcbt7 = barconfs.BarConfigBarFrame:CreateFontString("$parentText7", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt7:SetPoint("BOTTOMLEFT", barconfs.BarConfigBarFrame, "BOTTOMLEFT", 16, 16);
barconfs.bcbt7:SetText(L.auraconf_fontsize)

--font size editbox
barconfs.FontSizeEditBox = CreateFrame ( "EditBox", "$parentEditBox6", barconfs.BarConfigBarFrame, "InputBoxTemplate")
barconfs.FontSizeEditBox:SetPoint("CENTER", barconfs.bcbt7, "CENTER", 0, 0)
barconfs.FontSizeEditBox:SetPoint("LEFT", barconfs.bcbt7, "RIGHT", 10, 0)
barconfs.FontSizeEditBox:SetHeight(12)
barconfs.FontSizeEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.FontSizeEditBox:Show()
barconfs.FontSizeEditBox:SetWidth(25)
barconfs.FontSizeEditBox:SetNumeric(true)
barconfs.FontSizeEditBox:SetAutoFocus(false)
barconfs.FontSizeEditBox:ClearFocus()

--font colour label
barconfs.bcbt8 = barconfs.BarConfigBarFrame:CreateFontString("$parentText8", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt8:SetPoint("BOTTOM", barconfs.bcbt7, "BOTTOM", 0, 0);
barconfs.bcbt8:SetPoint("LEFT", barconfs.FontSizeEditBox, "RIGHT", 10, 0);
barconfs.bcbt8:SetText(L.auraconf_fontcolor)

--font color picker frame
barconfs.FontColorFrame = CreateFrame("Frame", "TTFontColorFrame", barconfs.BarConfigBarFrame)
barconfs.FontColorFrame:SetPoint("CENTER", barconfs.bcbt8, "CENTER", 0, -3)
barconfs.FontColorFrame:SetPoint("LEFT", barconfs.bcbt8, "RIGHT", 5, 0)
barconfs.FontColorFrame:SetWidth(16)
barconfs.FontColorFrame:SetHeight(16)
barconfs.FontColorFrame:SetBackdrop({bgFile=L.mainbgFile, edgeFile="", tile = false, tileSize = 0, edgeSize = 0, insets = { left = 0, right = 0, top = 0, bottom = 0 }})
barconfs.FontColorFrame:SetBackdropColor(1,1,1,1)
barconfs.FontColorFrame:EnableMouse(1);

--font dropshadow checkbox label
barconfs.bcbt9 = barconfs.BarConfigBarFrame:CreateFontString("$parentText9", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt9:SetPoint("LEFT", barconfs.FontColorFrame, "RIGHT", 30, 0);
barconfs.bcbt9:SetPoint("BOTTOM", barconfs.bcbt7, "BOTTOM", 0, 0);
barconfs.bcbt9:SetText(L.auraconf_fontdrop)

--font dropshadow checkbox
barconfs.FontDropCheck = CreateFrame("CheckButton","$parentCheckBox1", barconfs.BarConfigBarFrame, "UICheckButtonTemplate")
barconfs.FontDropCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcbt9, "BOTTOMLEFT", -1, -5); 
barconfs.FontDropCheck:SetHeight(20)
barconfs.FontDropCheck:SetWidth(20)

--font outline checkbox label
barconfs.bcbt10 = barconfs.BarConfigBarFrame:CreateFontString("$parentText10", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt10:SetPoint("LEFT", barconfs.bcbt9, "RIGHT", 30, 0);
barconfs.bcbt10:SetPoint("BOTTOM", barconfs.bcbt7, "BOTTOM", 0, 0);
barconfs.bcbt10:SetText(L.auraconf_fontout)

--font dropshadow checkbox
barconfs.FontOutCheck = CreateFrame("CheckButton","$parentCheckBox2", barconfs.BarConfigBarFrame, "UICheckButtonTemplate")
barconfs.FontOutCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcbt10, "BOTTOMLEFT", -1, -5); 
barconfs.FontOutCheck:SetHeight(20)
barconfs.FontOutCheck:SetWidth(20)


--Frame Alpha slider label
barconfs.bcbt4 = barconfs.BarConfigBarFrame:CreateFontString("$parentText4", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt4:SetPoint("TOPLEFT", barconfs.bcbt1, "BOTTOMLEFT", 0, -80);
barconfs.bcbt4:SetText(L.auraconf_framealpha)

--Frame alpha slider
barconfs.FrameAlphaSlider = CreateFrame('Slider', 'TTFrameAlphaSlider', barconfs.BarConfigBarFrame, 'OptionsSliderTemplate')
barconfs.FrameAlphaSlider:SetPoint("TOPLEFT", barconfs.bcbt4, "BOTTOMLEFT", 0, 0);
barconfs.FrameAlphaSlider:SetHeight(12)
barconfs.FrameAlphaSlider:SetWidth(80)
barconfs.FrameAlphaSlider:SetMinMaxValues(0,1)
barconfs.FrameAlphaSlider:SetValueStep(0.05)
barconfs.FrameAlphaSlider:SetFrameLevel(4)

--frame alpha editbox
barconfs.FrameAlphaEditBox = CreateFrame ( "EditBox", "$parentEditBox3", barconfs.BarConfigBarFrame, "InputBoxTemplate")
barconfs.FrameAlphaEditBox:SetPoint("CENTER", barconfs.FrameAlphaSlider, "CENTER", 0, 0)
barconfs.FrameAlphaEditBox:SetPoint("TOP", barconfs.FrameAlphaSlider, "BOTTOM", 0, 0)
barconfs.FrameAlphaEditBox:SetHeight(12)
barconfs.FrameAlphaEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.FrameAlphaEditBox:Show()
barconfs.FrameAlphaEditBox:SetWidth(25)
barconfs.FrameAlphaEditBox:SetFrameLevel(5)
barconfs.FrameAlphaEditBox:SetAutoFocus(false)
barconfs.FrameAlphaEditBox:ClearFocus()

--bar Alpha slider label
barconfs.bcbt5 = barconfs.BarConfigBarFrame:CreateFontString("$parentText5", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt5:SetPoint("BOTTOM", barconfs.bcbt4, "BOTTOM", 0, 0);
barconfs.bcbt5:SetPoint("LEFT", barconfs.aligncenterframe, "LEFT", 0, 0);
barconfs.bcbt5:SetText(L.auraconf_baralpha)

--bar alpha slider
barconfs.BarAlphaSlider = CreateFrame('Slider', 'TTBarAlphaSlider', barconfs.BarConfigBarFrame, 'OptionsSliderTemplate')
barconfs.BarAlphaSlider:SetPoint("TOPLEFT", barconfs.bcbt5, "BOTTOMLEFT", 0, 0);
barconfs.BarAlphaSlider:SetHeight(12)
barconfs.BarAlphaSlider:SetWidth(80)
barconfs.BarAlphaSlider:SetMinMaxValues(0,1)
barconfs.BarAlphaSlider:SetValueStep(0.05)
barconfs.BarAlphaSlider:SetFrameLevel(4)

--bar alpha editbox
barconfs.BarAlphaEditBox = CreateFrame ( "EditBox", "$parentEditBox4", barconfs.BarConfigBarFrame, "InputBoxTemplate")
barconfs.BarAlphaEditBox:SetPoint("CENTER", barconfs.BarAlphaSlider, "CENTER", 0, 0)
barconfs.BarAlphaEditBox:SetPoint("TOP", barconfs.BarAlphaSlider, "BOTTOM", 0, 0)
barconfs.BarAlphaEditBox:SetHeight(12)
barconfs.BarAlphaEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.BarAlphaEditBox:Show()
barconfs.BarAlphaEditBox:SetWidth(25)
barconfs.BarAlphaEditBox:SetFrameLevel(5)
barconfs.BarAlphaEditBox:SetAutoFocus(false)
barconfs.BarAlphaEditBox:ClearFocus()

--bg Alpha slider label
barconfs.bcbt6 = barconfs.BarConfigBarFrame:CreateFontString("$parentText6", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt6:SetPoint("BOTTOM", barconfs.bcbt4, "BOTTOM", 0, 0);
barconfs.bcbt6:SetPoint("LEFT", barconfs.BarConfigExtrasButton, "LEFT", 0, 0);
barconfs.bcbt6:SetText(L.auraconf_bgalpha)

--bg alpha slider
barconfs.BgAlphaSlider = CreateFrame('Slider', 'TTBgAlphaSlider', barconfs.BarConfigBarFrame, 'OptionsSliderTemplate')
barconfs.BgAlphaSlider:SetPoint("TOPLEFT", barconfs.bcbt6, "BOTTOMLEFT", 0, 0);
barconfs.BgAlphaSlider:SetHeight(12)
barconfs.BgAlphaSlider:SetWidth(80)
barconfs.BgAlphaSlider:SetMinMaxValues(0,1)
barconfs.BgAlphaSlider:SetValueStep(0.05)
barconfs.BgAlphaSlider:SetFrameLevel(4)

--bg alpha editbox
barconfs.BgAlphaEditBox = CreateFrame ( "EditBox", "$parentEditBox5", barconfs.BarConfigBarFrame, "InputBoxTemplate")
barconfs.BgAlphaEditBox:SetPoint("CENTER", barconfs.BgAlphaSlider, "CENTER", 0, 0)
barconfs.BgAlphaEditBox:SetPoint("TOP", barconfs.BgAlphaSlider, "BOTTOM", 0, 0)
barconfs.BgAlphaEditBox:SetHeight(12)
barconfs.BgAlphaEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.BgAlphaEditBox:Show()
barconfs.BgAlphaEditBox:SetWidth(25)
barconfs.BgAlphaEditBox:SetFrameLevel(5)
barconfs.BgAlphaEditBox:SetAutoFocus(false)
barconfs.BgAlphaEditBox:ClearFocus()

--alpha section end splitter frame
barconfs.bcbalphasplit = CreateFrame("Frame", "TTbcbalphasplit", barconfs.BarConfigBarFrame)
barconfs.bcbalphasplit:SetPoint("TOP", barconfs.bcbt4, "BOTTOM", 0, -37)
barconfs.bcbalphasplit:SetPoint("LEFT", barconfs.BarConfigBarFrame, "LEFT", 32, 0)
barconfs.bcbalphasplit:SetPoint("RIGHT", barconfs.BarConfigBarFrame, "RIGHT", -32, 0)
barconfs.bcbalphasplit:SetWidth(16)
barconfs.bcbalphasplit:SetHeight(1)
barconfs.bcbalphasplit:SetBackdrop({bgFile=L.mainbgFile, edgeFile="", tile = false, tileSize = 0, edgeSize = 0, insets = { left = 0, right = 0, top = 0, bottom = 0 }})
barconfs.bcbalphasplit:SetBackdropColor(0.4,0.4,0.4,1)



--buff text position label
barconfs.bcbt11 = barconfs.BarConfigBarFrame:CreateFontString("$parentText11", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt11:SetPoint("BOTTOMLEFT", barconfs.bcbt7, "TOPLEFT", 0, 40);
barconfs.bcbt11:SetText(L.auraconf_bufftextpos)


--buff text position dropdown
barconfs.BuffTextDropDownMenu = CreateFrame("Frame", "TTBuffTextDropDownMenu", barconfs.BarConfigBarFrame, "UIDropDownMenuTemplate");
barconfs.BuffTextDropDownMenu:SetPoint("TOPLEFT", barconfs.bcbt11, "BOTTOMLEFT", -18, 0);
UIDropDownMenu_SetWidth(barconfs.BuffTextDropDownMenu, 70)

--stack position label
barconfs.bcbt12 = barconfs.BarConfigBarFrame:CreateFontString("$parentText12", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt12:SetPoint("LEFT", barconfs.aligncenterframe, "LEFT", 0, 0);
barconfs.bcbt12:SetPoint("BOTTOM", barconfs.bcbt11, "BOTTOM", 0, 0);
barconfs.bcbt12:SetText(L.auraconf_stacktextpos)

--stack text position dropdown
barconfs.StackTextDropDownMenu = CreateFrame("Frame", "TTStackTextDropDownMenu", barconfs.BarConfigBarFrame, "UIDropDownMenuTemplate");
barconfs.StackTextDropDownMenu:SetPoint("TOPLEFT", barconfs.bcbt12, "BOTTOMLEFT", -18, 0);
UIDropDownMenu_SetWidth(barconfs.StackTextDropDownMenu, 70)

--time position label
barconfs.bcbt14 = barconfs.BarConfigBarFrame:CreateFontString("$parentText14", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcbt14:SetPoint("LEFT", barconfs.BarConfigExtrasButton, "LEFT", 0, 0);
barconfs.bcbt14:SetPoint("BOTTOM", barconfs.bcbt11, "BOTTOM", 0, 0);
barconfs.bcbt14:SetText(L.auraconf_timetextpos)

--time text position dropdown
barconfs.TimeTextDropDownMenu = CreateFrame("Frame", "TTTimeTextDropDownMenu", barconfs.BarConfigBarFrame, "UIDropDownMenuTemplate");
barconfs.TimeTextDropDownMenu:SetPoint("TOPLEFT", barconfs.bcbt14, "BOTTOMLEFT", -18, 0);
UIDropDownMenu_SetWidth(barconfs.TimeTextDropDownMenu, 70)

------------end barconfig bar settings frame ---------

------------barconfig bar settings 2 frame ---------

barconfs.BarConfigBar2Frame = CreateFrame("Frame", "BarconfigBar2Frame", barconfs.BarConfigFrame)
barconfs.BarConfigBar2Frame:SetPoint("TOPLEFT", barconfs.BarConfigFrame, "TOPLEFT", 0, -45)
barconfs.BarConfigBar2Frame:SetPoint("RIGHT", barconfs.BarConfigFrame, "RIGHT", 0, 0)
barconfs.BarConfigBar2Frame:SetPoint("BOTTOM", barconfs.BarConfigFrame, "BOTTOM", 0, 0)
barconfs.BarConfigBar2Frame:Hide()

--aura icon position label
barconfs.bcb2t2 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText1", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t2:SetPoint("TOPLEFT", barconfs.BarConfigBar2Frame, "TOPLEFT", 16, -10);
barconfs.bcb2t2:SetText(L.auraconf_auraicon)

--aura icon position dropdown
barconfs.AuraIconDropDownMenu = CreateFrame("Frame", "TTAuraIconDropDownMenu", barconfs.BarConfigBar2Frame, "UIDropDownMenuTemplate");
barconfs.AuraIconDropDownMenu:SetPoint("TOPLEFT", barconfs.bcb2t2, "BOTTOMLEFT", -18, 0);
UIDropDownMenu_SetWidth(barconfs.AuraIconDropDownMenu, 70)

--raid icon position label
barconfs.bcb2t4 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText4", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t4:SetPoint("LEFT", barconfs.aligncenterframe, "LEFT", 0, 0);
barconfs.bcb2t4:SetPoint("BOTTOM", barconfs.bcb2t2, "BOTTOM", 0, 0);
barconfs.bcb2t4:SetText(L.auraconf_raidicon)

--raid icon position dropdown
barconfs.RaidIconDropDownMenu = CreateFrame("Frame", "TTRaidIconDropDownMenu", barconfs.BarConfigBar2Frame, "UIDropDownMenuTemplate");
barconfs.RaidIconDropDownMenu:SetPoint("TOPLEFT", barconfs.bcb2t4, "BOTTOMLEFT", -18, 0);
UIDropDownMenu_SetWidth(barconfs.RaidIconDropDownMenu, 70)

--aura icon only label
barconfs.bcb2t3 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText3", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t3:SetPoint("LEFT", barconfs.BarConfigExtrasButton, "LEFT", 21, 0);
barconfs.bcb2t3:SetPoint("BOTTOM", barconfs.bcb2t2, "BOTTOM", 0, 0);
barconfs.bcb2t3:SetText(L.auraconf_icononly)

--aura icon only checkbox
barconfs.AuraIconOnlyCheck = CreateFrame("CheckButton","$parentCheckBox2", barconfs.BarConfigBar2Frame, "UICheckButtonTemplate")
barconfs.AuraIconOnlyCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcb2t3, "BOTTOMLEFT", -1, -5); 
barconfs.AuraIconOnlyCheck:SetHeight(20)
barconfs.AuraIconOnlyCheck:SetWidth(20)


--hide aura text label
barconfs.bcb2t1 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText1", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t1:SetPoint("LEFT", barconfs.BarConfigExtrasButton, "LEFT", 21, 0);
barconfs.bcb2t1:SetPoint("TOP", barconfs.bcb2t2, "BOTTOM", 0, -12);
barconfs.bcb2t1:SetText(L.auraconf_hidetext)

--hide aura text checkbox
barconfs.HideAuraTextCheck = CreateFrame("CheckButton","$parentCheckBox1", barconfs.BarConfigBar2Frame, "UICheckButtonTemplate")
barconfs.HideAuraTextCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcb2t1, "BOTTOMLEFT", -1, -5); 
barconfs.HideAuraTextCheck:SetHeight(20)
barconfs.HideAuraTextCheck:SetWidth(20)





--flash low label
barconfs.bcb2t5 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText5", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t5:SetPoint("TOPLEFT", barconfs.bcb2t2, "BOTTOMLEFT", 21, -37);
barconfs.bcb2t5:SetText(L.auraconf_flashlow)

--flash low checkbox
barconfs.FlashLowCheck = CreateFrame("CheckButton","$parentCheckBox3", barconfs.BarConfigBar2Frame, "UICheckButtonTemplate")
barconfs.FlashLowCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcb2t5, "BOTTOMLEFT", -1, -5); 
barconfs.FlashLowCheck:SetHeight(20)
barconfs.FlashLowCheck:SetWidth(20)

--flash low editbox
barconfs.FlashLowEditBox = CreateFrame ( "EditBox", "$parentEditBox1", barconfs.BarConfigBar2Frame, "InputBoxTemplate")
barconfs.FlashLowEditBox:SetPoint("CENTER", barconfs.bcb2t5, "CENTER", 0, 0)
barconfs.FlashLowEditBox:SetPoint("LEFT", barconfs.bcb2t5, "RIGHT", 10, 0)
barconfs.FlashLowEditBox:SetHeight(12)
barconfs.FlashLowEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.FlashLowEditBox:Show()
barconfs.FlashLowEditBox:SetWidth(25)
barconfs.FlashLowEditBox:SetNumeric(true)
barconfs.FlashLowEditBox:SetAutoFocus(false)
barconfs.FlashLowEditBox:ClearFocus()

--flash low label 2
barconfs.bcb2t6 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText6", "OVERLAY", "GameFontWhiteSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t6:SetPoint("BOTTOM", barconfs.bcb2t5, "BOTTOM", 0, 0);
barconfs.bcb2t6:SetPoint("LEFT", barconfs.FlashLowEditBox, "RIGHT", 5, 0)
barconfs.bcb2t6:SetText(L.auraconf_flashlow2)

--append source label
barconfs.bcb2t7 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText7", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t7:SetPoint("BOTTOM", barconfs.bcb2t5, "BOTTOM", 0, 0);
barconfs.bcb2t7:SetPoint("LEFT", barconfs.BarConfigExtrasButton, "LEFT", 21, 0)
barconfs.bcb2t7:SetText(L.auraconf_appendsource)

--append source checkbox
barconfs.AppendSourceCheck = CreateFrame("CheckButton","$parentCheckBox4", barconfs.BarConfigBar2Frame, "UICheckButtonTemplate")
barconfs.AppendSourceCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcb2t7, "BOTTOMLEFT", -1, -5); 
barconfs.AppendSourceCheck:SetHeight(20)
barconfs.AppendSourceCheck:SetWidth(20)

--icon section end splitter frame
barconfs.bcb2iconsplit = CreateFrame("Frame", "TTbceflashsplit", barconfs.BarConfigBar2Frame)
barconfs.bcb2iconsplit:SetPoint("TOP", barconfs.bcb2t5, "BOTTOM", 0, -17)
barconfs.bcb2iconsplit:SetPoint("LEFT", barconfs.BarConfigBar2Frame, "LEFT", 32, 0)
barconfs.bcb2iconsplit:SetPoint("RIGHT", barconfs.BarConfigBar2Frame, "RIGHT", -32, 0)
barconfs.bcb2iconsplit:SetWidth(16)
barconfs.bcb2iconsplit:SetHeight(1)
barconfs.bcb2iconsplit:SetBackdrop({bgFile=L.mainbgFile, edgeFile="", tile = false, tileSize = 0, edgeSize = 0, insets = { left = 0, right = 0, top = 0, bottom = 0 }})
barconfs.bcb2iconsplit:SetBackdropColor(0.4,0.4,0.4,1)


--fixed size label
barconfs.bcb2t8 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText8", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t8:SetPoint("TOPLEFT", barconfs.bcb2t5, "BOTTOMLEFT", 0, -40);
barconfs.bcb2t8:SetText(L.auraconf_fixedsize)

--fixed size checkbox
barconfs.FixedSizeCheck = CreateFrame("CheckButton","$parentCheckBox5", barconfs.BarConfigBar2Frame, "UICheckButtonTemplate")
barconfs.FixedSizeCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcb2t8, "BOTTOMLEFT", -1, -5); 
barconfs.FixedSizeCheck:SetHeight(20)
barconfs.FixedSizeCheck:SetWidth(20)

--fixed size editbox
barconfs.FixedSizeEditBox = CreateFrame ( "EditBox", "$parentEditBox2", barconfs.BarConfigBar2Frame, "InputBoxTemplate")
barconfs.FixedSizeEditBox:SetPoint("CENTER", barconfs.bcb2t8, "CENTER", 0, 0)
barconfs.FixedSizeEditBox:SetPoint("LEFT", barconfs.bcb2t8, "RIGHT", 10, 0)
barconfs.FixedSizeEditBox:SetHeight(12)
barconfs.FixedSizeEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.FixedSizeEditBox:Show()
barconfs.FixedSizeEditBox:SetWidth(25)
barconfs.FixedSizeEditBox:SetNumeric(true)
barconfs.FixedSizeEditBox:SetAutoFocus(false)
barconfs.FixedSizeEditBox:ClearFocus()

--fixed size label 2
barconfs.bcb2t9 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText9", "OVERLAY", "GameFontWhiteSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t9:SetPoint("BOTTOM", barconfs.bcb2t8, "BOTTOM", 0, 0);
barconfs.bcb2t9:SetPoint("LEFT", barconfs.FixedSizeEditBox, "RIGHT", 5, 0)
barconfs.bcb2t9:SetText(L.auraconf_fixedsize2)

--fixed size section end splitter frame
barconfs.bcb2fixedsplit = CreateFrame("Frame", "TTbcefixedsplit", barconfs.BarConfigBar2Frame)
barconfs.bcb2fixedsplit:SetPoint("TOP", barconfs.bcb2t8, "BOTTOM", 0, -17)
barconfs.bcb2fixedsplit:SetPoint("LEFT", barconfs.BarConfigBar2Frame, "LEFT", 32, 0)
barconfs.bcb2fixedsplit:SetPoint("RIGHT", barconfs.BarConfigBar2Frame, "RIGHT", -32, 0)
barconfs.bcb2fixedsplit:SetWidth(16)
barconfs.bcb2fixedsplit:SetHeight(1)
barconfs.bcb2fixedsplit:SetBackdrop({bgFile=L.mainbgFile, edgeFile="", tile = false, tileSize = 0, edgeSize = 0, insets = { left = 0, right = 0, top = 0, bottom = 0 }})
barconfs.bcb2fixedsplit:SetBackdropColor(0.4,0.4,0.4,1)

--second bar label
barconfs.bcb2t10 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText10", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t10:SetPoint("TOPLEFT", barconfs.bcb2t8, "BOTTOMLEFT", 0, -40);
barconfs.bcb2t10:SetText(L.auraconf_secondbar)

--second bar checkbox
barconfs.SecondBarCheck = CreateFrame("CheckButton","$parentCheckBox6", barconfs.BarConfigBar2Frame, "UICheckButtonTemplate")
barconfs.SecondBarCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcb2t10, "BOTTOMLEFT", -1, -5); 
barconfs.SecondBarCheck:SetHeight(20)
barconfs.SecondBarCheck:SetWidth(20)


--second bar Alpha slider label
barconfs.bcb2t11 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText11", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t11:SetPoint("BOTTOM", barconfs.bcb2t10, "BOTTOM", 0, 0);
barconfs.bcb2t11:SetPoint("LEFT", barconfs.BarConfigExtrasButton, "LEFT", 0, 0)
barconfs.bcb2t11:SetText(L.auraconf_bar2alpha)

--second bar alpha slider
barconfs.Bar2AlphaSlider = CreateFrame('Slider', 'TTBar2AlphaSlider', barconfs.BarConfigBar2Frame, 'OptionsSliderTemplate')
barconfs.Bar2AlphaSlider:SetPoint("TOPLEFT", barconfs.bcb2t11, "BOTTOMLEFT", 0, 0);
barconfs.Bar2AlphaSlider:SetHeight(12)
barconfs.Bar2AlphaSlider:SetWidth(80)
barconfs.Bar2AlphaSlider:SetMinMaxValues(0,1)
barconfs.Bar2AlphaSlider:SetValueStep(0.05)
barconfs.Bar2AlphaSlider:SetFrameLevel(4)

--second bar alpha editbox
barconfs.Bar2AlphaEditBox = CreateFrame ( "EditBox", "$parentEditBox3", barconfs.BarConfigBar2Frame, "InputBoxTemplate")
barconfs.Bar2AlphaEditBox:SetPoint("CENTER", barconfs.Bar2AlphaSlider, "CENTER", 0, 0)
barconfs.Bar2AlphaEditBox:SetPoint("TOP", barconfs.Bar2AlphaSlider, "BOTTOM", 0, 0)
barconfs.Bar2AlphaEditBox:SetHeight(12)
barconfs.Bar2AlphaEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.Bar2AlphaEditBox:Show()
barconfs.Bar2AlphaEditBox:SetWidth(25)
barconfs.Bar2AlphaEditBox:SetFrameLevel(5)
barconfs.Bar2AlphaEditBox:SetAutoFocus(false)
barconfs.Bar2AlphaEditBox:ClearFocus()

--second bar color picker label
barconfs.bcb2t12 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText12", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t12:SetPoint("TOPLEFT", barconfs.bcb2t10, "BOTTOMLEFT", -21, -12);
barconfs.bcb2t12:SetText(L.auraconf_bar2color)

--second bar color picker frame
barconfs.Bar2ColorFrame = CreateFrame("Frame", "TTBarconfigBar2ColorFrame", barconfs.BarConfigBar2Frame)
barconfs.Bar2ColorFrame:SetPoint("CENTER", barconfs.bcb2t12, "CENTER", 0, -3)
barconfs.Bar2ColorFrame:SetPoint("LEFT", barconfs.bcb2t12, "RIGHT", 5, 0)
barconfs.Bar2ColorFrame:SetWidth(80)
barconfs.Bar2ColorFrame:SetHeight(16)
barconfs.Bar2ColorFrame:SetBackdrop({bgFile=L.mainbgFile, edgeFile="", tile = false, tileSize = 0, edgeSize = 0, insets = { left = 0, right = 0, top = 0, bottom = 0 }})
barconfs.Bar2ColorFrame:SetBackdropColor(0,0,0,0.5)
barconfs.Bar2ColorFrame:EnableMouse(1);

--second bar color picker frame texture
barconfs.bar2texture = barconfs.Bar2ColorFrame:CreateTexture(nil, "ARTWORK");
barconfs.bar2texture:SetPoint("TOPRIGHT")
barconfs.bar2texture:SetWidth(80)
barconfs.bar2texture:SetHeight(16)

--base combo time editbox label
barconfs.bcb2t14 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText14", "OVERLAY", "GameFontWhiteSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t14:SetPoint("TOP", barconfs.bcb2t12, "BOTTOM", 0, -18);
barconfs.bcb2t14:SetPoint("LEFT", barconfs.bcb2t12, "LEFT", 0, 0)
barconfs.bcb2t14:SetText(L.auraconf_basecombo)

--base combo time editbox
barconfs.BaseComboEditBox = CreateFrame ( "EditBox", "$parentEditBox4", barconfs.BarConfigBar2Frame, "InputBoxTemplate")
barconfs.BaseComboEditBox:SetPoint("TOPLEFT", barconfs.bcb2t14, "BOTTOMLEFT", 0, -5)
barconfs.BaseComboEditBox:SetHeight(12)
barconfs.BaseComboEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.BaseComboEditBox:Show()
barconfs.BaseComboEditBox:SetWidth(70)
barconfs.BaseComboEditBox:SetNumeric(true)
barconfs.BaseComboEditBox:SetAutoFocus(false)
barconfs.BaseComboEditBox:ClearFocus()

--per combo time editbox label
barconfs.bcb2t15 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText15", "OVERLAY", "GameFontWhiteSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t15:SetPoint("BOTTOM", barconfs.bcb2t14, "BOTTOM", 0, 0);
barconfs.bcb2t15:SetPoint("LEFT", barconfs.aligncenterframe, "LEFT", 0, 0)
barconfs.bcb2t15:SetText(L.auraconf_percombo)

--per combo time editbox
barconfs.PerComboEditBox = CreateFrame ( "EditBox", "$parentEditBox5", barconfs.BarConfigBar2Frame, "InputBoxTemplate")
barconfs.PerComboEditBox:SetPoint("TOPLEFT", barconfs.bcb2t15, "BOTTOMLEFT", 0, -5)
barconfs.PerComboEditBox:SetHeight(12)
barconfs.PerComboEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.PerComboEditBox:Show()
barconfs.PerComboEditBox:SetWidth(70)
barconfs.PerComboEditBox:SetNumeric(true)
barconfs.PerComboEditBox:SetAutoFocus(false)
barconfs.PerComboEditBox:ClearFocus()

--multiplier combo time editbox label
barconfs.bcb2t16 = barconfs.BarConfigBar2Frame:CreateFontString("$parentText16", "OVERLAY", "GameFontWhiteSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcb2t16:SetPoint("BOTTOM", barconfs.bcb2t14, "BOTTOM", 0, 0);
barconfs.bcb2t16:SetPoint("LEFT", barconfs.BarConfigExtrasButton, "LEFT", 0, 0)
barconfs.bcb2t16:SetText(L.auraconf_multicombo)

--multiplier combo time editbox
barconfs.MultiComboEditBox = CreateFrame ( "EditBox", "$parentEditBox6", barconfs.BarConfigBar2Frame, "InputBoxTemplate")
barconfs.MultiComboEditBox:SetPoint("TOPLEFT", barconfs.bcb2t16, "BOTTOMLEFT", 0, -5)
barconfs.MultiComboEditBox:SetHeight(12)
barconfs.MultiComboEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.MultiComboEditBox:Show()
barconfs.MultiComboEditBox:SetWidth(70)
barconfs.MultiComboEditBox:SetAutoFocus(false)
barconfs.MultiComboEditBox:ClearFocus()


------------end barconfig bar settings 2 frame ---------

------------barconfig bar extras frame ---------

barconfs.BarConfigExtrasFrame = CreateFrame("Frame", "BarconfigExtrasFrame", barconfs.BarConfigFrame)
barconfs.BarConfigExtrasFrame:SetPoint("TOPLEFT", barconfs.BarConfigFrame, "TOPLEFT", 0, -45)
barconfs.BarConfigExtrasFrame:SetPoint("RIGHT", barconfs.BarConfigFrame, "RIGHT", 0, 0)
barconfs.BarConfigExtrasFrame:SetPoint("BOTTOM", barconfs.BarConfigFrame, "BOTTOM", 0, 0)
barconfs.BarConfigExtrasFrame:Hide()


--announce destination label
barconfs.bcet8 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText8", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet8:SetPoint("TOPLEFT", barconfs.BarConfigExtrasFrame, "TOPLEFT", 16, -10);
barconfs.bcet8:SetText(L.auraconf_announce)

--announce destination dropdown
barconfs.AnnounceDestDropDownMenu = CreateFrame("Frame", "TTAnnounceDestDropDownMenu", barconfs.BarConfigExtrasFrame, "UIDropDownMenuTemplate");
barconfs.AnnounceDestDropDownMenu:SetPoint("TOPLEFT", barconfs.bcet8, "BOTTOMLEFT", -18, 0);
UIDropDownMenu_SetWidth(barconfs.AnnounceDestDropDownMenu, 70)

--announce channel editbox label
barconfs.bcet9 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText9", "OVERLAY", "GameFontWhiteSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet9:SetPoint("BOTTOM", barconfs.bcet8, "BOTTOM", 0, 0);
barconfs.bcet9:SetPoint("LEFT", barconfs.aligncenterframe, "LEFT", 0, 0)
barconfs.bcet9:SetText(L.auraconf_channel)

--announce channel editbox
barconfs.AnnounceChanEditBox = CreateFrame ( "EditBox", "$parentEditBox2", barconfs.BarConfigExtrasFrame, "InputBoxTemplate")
barconfs.AnnounceChanEditBox:SetPoint("TOPLEFT", barconfs.bcet9, "BOTTOMLEFT", 0, -5)
barconfs.AnnounceChanEditBox:SetHeight(12)
barconfs.AnnounceChanEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.AnnounceChanEditBox:Show()
barconfs.AnnounceChanEditBox:SetWidth(90)
barconfs.AnnounceChanEditBox:SetAutoFocus(false)
barconfs.AnnounceChanEditBox:ClearFocus()

--announce nonself checkbox label
barconfs.bcet10 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText10", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet10:SetPoint("BOTTOM", barconfs.bcet8, "BOTTOM", 0, 0);
barconfs.bcet10:SetPoint("LEFT", barconfs.BarConfigExtrasButton, "LEFT", 21, 0)
barconfs.bcet10:SetText(L.auraconf_announcenonself)

--announce nonself checkbox
barconfs.AnnounceNonSelfCheck = CreateFrame("CheckButton","$parentCheckBox5", barconfs.BarConfigExtrasFrame, "UICheckButtonTemplate")
barconfs.AnnounceNonSelfCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcet10, "BOTTOMLEFT", -1, -5); 
barconfs.AnnounceNonSelfCheck:SetHeight(20)
barconfs.AnnounceNonSelfCheck:SetWidth(20)

--announce time/stacks label
barconfs.bcet27 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText27", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet27:SetPoint("TOPLEFT", barconfs.bcet8, "BOTTOMLEFT", 0, -35);
barconfs.bcet27:SetText(L.auraconf_announcetime)

--announce time/stacks dropdown
barconfs.AnnounceTimeDropDownMenu = CreateFrame("Frame", "TTAnnounceTimeDropDownMenu", barconfs.BarConfigExtrasFrame, "UIDropDownMenuTemplate");
barconfs.AnnounceTimeDropDownMenu:SetPoint("TOPLEFT", barconfs.bcet27, "BOTTOMLEFT", -18, 0);
UIDropDownMenu_SetWidth(barconfs.AnnounceTimeDropDownMenu, 70)

--announce time/stack editbox label
barconfs.bcet28 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText28", "OVERLAY", "GameFontWhiteSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet28:SetPoint("BOTTOM", barconfs.bcet27, "BOTTOM", 0, 0);
barconfs.bcet28:SetPoint("LEFT", barconfs.aligncenterframe, "LEFT", 0, 0)
barconfs.bcet28:SetText(L.auraconf_soundtimeleft)

--announce time/stack editbox
barconfs.AnnounceTimeEditBox = CreateFrame ( "EditBox", "$parentEditBox5", barconfs.BarConfigExtrasFrame, "InputBoxTemplate")
barconfs.AnnounceTimeEditBox:SetPoint("TOPLEFT", barconfs.bcet28, "BOTTOMLEFT", 0, -5)
barconfs.AnnounceTimeEditBox:SetHeight(12)
barconfs.AnnounceTimeEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.AnnounceTimeEditBox:Show()
barconfs.AnnounceTimeEditBox:SetWidth(70)
barconfs.AnnounceTimeEditBox:SetNumeric(true)
barconfs.AnnounceTimeEditBox:SetAutoFocus(false)
barconfs.AnnounceTimeEditBox:ClearFocus()

--announce every sec checkbox label
barconfs.bcet11 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText11", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet11:SetPoint("TOP", barconfs.bcet10, "BOTTOM", 0, -12);
barconfs.bcet11:SetPoint("LEFT", barconfs.BarConfigExtrasButton, "LEFT", 21, 0)
barconfs.bcet11:SetText(L.auraconf_announceevery)

--announce every second checkbox
barconfs.AnnounceEveryCheck = CreateFrame("CheckButton","$parentCheckBox6", barconfs.BarConfigExtrasFrame, "UICheckButtonTemplate")
barconfs.AnnounceEveryCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcet11, "BOTTOMLEFT", -1, -5);
barconfs.AnnounceEveryCheck:SetHeight(20)
barconfs.AnnounceEveryCheck:SetWidth(20)

--announce expire checkbox label
barconfs.bcet27 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText27", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet27:SetPoint("TOP", barconfs.bcet11, "BOTTOM", 0, -12);
barconfs.bcet27:SetPoint("LEFT", barconfs.BarConfigExtrasButton, "LEFT", 21, 0)
barconfs.bcet27:SetText(L.auraconf_announceexpire)

--announce expire checkbox
barconfs.AnnounceExpire = CreateFrame("CheckButton","$parentCheckBox6", barconfs.BarConfigExtrasFrame, "UICheckButtonTemplate")
barconfs.AnnounceExpire:SetPoint("BOTTOMRIGHT",  barconfs.bcet27, "BOTTOMLEFT", -1, -5);
barconfs.AnnounceExpire:SetHeight(20)
barconfs.AnnounceExpire:SetWidth(20)

--announce section end splitter frame
barconfs.bceannouncesplit = CreateFrame("Frame", "TTbceannouncesplit", barconfs.BarConfigExtrasFrame)
barconfs.bceannouncesplit:SetPoint("TOP", barconfs.bcet8, "BOTTOM", 0, -82) --42
barconfs.bceannouncesplit:SetPoint("LEFT", barconfs.BarConfigExtrasFrame, "LEFT", 32, 0)
barconfs.bceannouncesplit:SetPoint("RIGHT", barconfs.BarConfigExtrasFrame, "RIGHT", -32, 0)
barconfs.bceannouncesplit:SetWidth(16)
barconfs.bceannouncesplit:SetHeight(1)
barconfs.bceannouncesplit:SetBackdrop({bgFile=L.mainbgFile, edgeFile="", tile = false, tileSize = 0, edgeSize = 0, insets = { left = 0, right = 0, top = 0, bottom = 0 }})
barconfs.bceannouncesplit:SetBackdropColor(0.4,0.4,0.4,1)

--play sound dropdown label
barconfs.bcet12 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText12", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet12:SetPoint("TOPLEFT", barconfs.bcet8, "BOTTOMLEFT", 0, -90); --50
barconfs.bcet12:SetText(L.auraconf_playsound)

--play sound dropdown
barconfs.PlaySoundDropDownMenu = CreateFrame("Frame", "TTPlaySoundDropDownMenu", barconfs.BarConfigExtrasFrame, "UIDropDownMenuTemplate");
barconfs.PlaySoundDropDownMenu:SetPoint("TOPLEFT", barconfs.bcet12, "BOTTOMLEFT", -18, 0);
UIDropDownMenu_SetWidth(barconfs.PlaySoundDropDownMenu, 70)

--sound when dropdown label
barconfs.bcet14 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText14", "OVERLAY", "GameFontWhiteSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet14:SetPoint("BOTTOM", barconfs.bcet12, "BOTTOM", 0, 0);
barconfs.bcet14:SetPoint("LEFT", barconfs.aligncenterframe, "LEFT", 0, 0)
barconfs.bcet14:SetText(L.auraconf_soundcheck)

--sound when dropdown
barconfs.SoundWhenDropDownMenu = CreateFrame("Frame", "TTSoundWhenDropDownMenu", barconfs.BarConfigExtrasFrame, "UIDropDownMenuTemplate");
barconfs.SoundWhenDropDownMenu:SetPoint("TOPLEFT", barconfs.bcet14, "BOTTOMLEFT", -18, 0);
UIDropDownMenu_SetWidth(barconfs.SoundWhenDropDownMenu, 70)

--play sound time/stack editbox label
barconfs.bcet15 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText15", "OVERLAY", "GameFontWhiteSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet15:SetPoint("BOTTOM", barconfs.bcet12, "BOTTOM", 0, 0);
barconfs.bcet15:SetPoint("LEFT", barconfs.BarConfigExtrasButton, "LEFT", 0, 0)
barconfs.bcet15:SetText(L.auraconf_soundtimeleft)

--play sound time/stack editbox
barconfs.SoundTimeEditBox = CreateFrame ( "EditBox", "$parentEditBox3", barconfs.BarConfigExtrasFrame, "InputBoxTemplate")
barconfs.SoundTimeEditBox:SetPoint("TOPLEFT", barconfs.bcet15, "BOTTOMLEFT", 0, -5)
barconfs.SoundTimeEditBox:SetHeight(12)
barconfs.SoundTimeEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.SoundTimeEditBox:Show()
barconfs.SoundTimeEditBox:SetWidth(70)
barconfs.SoundTimeEditBox:SetNumeric(true)
barconfs.SoundTimeEditBox:SetAutoFocus(false)
barconfs.SoundTimeEditBox:ClearFocus()

--play sound every second checkbox label
barconfs.bcet20 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText20", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet20:SetPoint("TOPLEFT", barconfs.bcet12, "BOTTOMLEFT", 21, -40);
barconfs.bcet20:SetText(L.auraconf_soundeverysec)

--play sound every second checkbox
barconfs.SoundEverySecondCheck = CreateFrame("CheckButton","$parentCheckBox6", barconfs.BarConfigExtrasFrame, "UICheckButtonTemplate")
barconfs.SoundEverySecondCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcet20, "BOTTOMLEFT", -1, -5); 
barconfs.SoundEverySecondCheck:SetHeight(20)
barconfs.SoundEverySecondCheck:SetWidth(20)

--play sound every second checkbox label
barconfs.bcet22 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText22", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet22:SetPoint("BOTTOM", barconfs.bcet21, "BOTTOM", 0, -10);
barconfs.bcet22:SetPoint("LEFT", barconfs.aligncenterframe, "LEFT", 21, 0)
barconfs.bcet22:SetText(L.auraconf_detectnotpresent)

--play sound every second checkbox
barconfs.DetectNotPresentCheck = CreateFrame("CheckButton","$parentCheckBox7", barconfs.BarConfigExtrasFrame, "UICheckButtonTemplate")
barconfs.DetectNotPresentCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcet22, "BOTTOMLEFT", -1, -5); 
barconfs.DetectNotPresentCheck:SetHeight(20)
barconfs.DetectNotPresentCheck:SetWidth(20)

--play sound section end splitter frame
barconfs.bcesoundsplit = CreateFrame("Frame", "TTbcesoundsplit", barconfs.BarConfigExtrasFrame)
barconfs.bcesoundsplit:SetPoint("TOP", barconfs.bcet20, "BOTTOM", 0, -17)
barconfs.bcesoundsplit:SetPoint("LEFT", barconfs.BarConfigExtrasFrame, "LEFT", 32, 0)
barconfs.bcesoundsplit:SetPoint("RIGHT", barconfs.BarConfigExtrasFrame, "RIGHT", -32, 0)
barconfs.bcesoundsplit:SetWidth(16)
barconfs.bcesoundsplit:SetHeight(1)
barconfs.bcesoundsplit:SetBackdrop({bgFile=L.mainbgFile, edgeFile="", tile = false, tileSize = 0, edgeSize = 0, insets = { left = 0, right = 0, top = 0, bottom = 0 }})
barconfs.bcesoundsplit:SetBackdropColor(0.4,0.4,0.4,1)


-- track cooldown checkbox label
barconfs.bcet24 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText24", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet24:SetPoint("BOTTOM", barconfs.BarConfigExtrasFrame, "BOTTOM", 0, 50);
barconfs.bcet24:SetPoint("LEFT", barconfs.BarConfigExtrasFrame, "LEFT", 38, 0)
barconfs.bcet24:SetText(L.auraconf_trackcooldown)

--track cooldown check box
barconfs.CooldownCheck = CreateFrame("CheckButton","$parentCheckBox8", barconfs.BarConfigExtrasFrame, "UICheckButtonTemplate")
barconfs.CooldownCheck:SetPoint("BOTTOMRIGHT",  barconfs.bcet24, "BOTTOMLEFT", -1, -5); 
barconfs.CooldownCheck:SetHeight(20)
barconfs.CooldownCheck:SetWidth(20)

--cooldown bar group text label
barconfs.bcet25 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText25", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet25:SetPoint("BOTTOM", barconfs.bcet24, "BOTTOM", 0, 0);
barconfs.bcet25:SetPoint("LEFT", barconfs.aligncenterframe, "LEFT", 0, 0);
barconfs.bcet25:SetText(L.auraconf_bargroupcd)

-- cooldown bar group dropdown
barconfs.CDBarGroupDropDownMenu = CreateFrame("Frame", "TTCDBarGroupDropDownMenu", barconfs.BarConfigExtrasFrame, "UIDropDownMenuTemplate");
barconfs.CDBarGroupDropDownMenu:SetPoint("TOPLEFT", barconfs.bcet25, "BOTTOMLEFT", -18, 0);
UIDropDownMenu_SetWidth(barconfs.CDBarGroupDropDownMenu, 70)

--cooldown duration editbox label
barconfs.bcet26 = barconfs.BarConfigExtrasFrame:CreateFontString("$parentText26", "OVERLAY", "GameFontWhiteSmall", nil, "LEFT", "TOP", "ARTWORK")
barconfs.bcet26:SetPoint("BOTTOM", barconfs.bcet24, "BOTTOM", 0, 0);
barconfs.bcet26:SetPoint("LEFT", barconfs.BarConfigExtrasButton, "LEFT", 0, 0)
barconfs.bcet26:SetText(L.auraconf_durationcd)

--cooldown duration editbox
barconfs.CooldownEditBox = CreateFrame ( "EditBox", "$parentEditBox4", barconfs.BarConfigExtrasFrame, "InputBoxTemplate")
barconfs.CooldownEditBox:SetPoint("TOPLEFT", barconfs.bcet26, "BOTTOMLEFT", 0, -5)
barconfs.CooldownEditBox:SetHeight(12)
barconfs.CooldownEditBox:SetFontObject("GameFontWhiteSmall")
barconfs.CooldownEditBox:Show()
barconfs.CooldownEditBox:SetWidth(70)
barconfs.CooldownEditBox:SetNumeric(true)
barconfs.CooldownEditBox:SetAutoFocus(false)
barconfs.CooldownEditBox:ClearFocus()

----------------------------------------------------------------------------------------------
------------------ bar groups panel ----------------------------------------------------------
----------------------------------------------------------------------------------------------

ThievesTools.frames.bargroups = {}
local bargroups = ThievesTools.frames.bargroups
bargroups.panel = CreateFrame( "Frame", "TT_bargroupsPanel", UIParent );
bargroups.panel.name = L.bargroup_label
bargroups.panel.parent = modName
bargroups.panel.okay = function (self) ThievesTools:ConfigEvents() end
InterfaceOptions_AddCategory(bargroups.panel)

bargroups.bct1 = bargroups.panel:CreateFontString("$parentText1", "OVERLAY", "GameFontNormalLarge", nil, "LEFT", "TOP", "ARTWORK")
bargroups.bct1:SetPoint("TOPLEFT", 16, -16)
bargroups.bct1:SetText(L.bargroup_label)

bargroups.bct2 = bargroups.panel:CreateFontString("$parentText2", "OVERLAY", "GameFontNormal", nil, "LEFT", "TOP", "ARTWORK")
bargroups.bct2:SetPoint("TOPLEFT",  bargroups.bct1, "BOTTOMLEFT", 0, -16 );
bargroups.bct2:SetText(L.bargroup_activeconf);

bargroups.BarGroupDropDownMenu = CreateFrame("Frame", "BarGroupDropDownMenu", bargroups.panel, "UIDropDownMenuTemplate");
bargroups.BarGroupDropDownMenu:SetPoint("TOPLEFT", bargroups.bct2, "TOPLEFT", bargroups.bct2:GetWidth() +5, 6);
UIDropDownMenu_SetWidth(bargroups.BarGroupDropDownMenu, 90)

bargroups.BarGroupNewButton = CreateFrame("Button", "BarGroupNewButton", bargroups.panel, "UIPanelButtonTemplate");
bargroups.BarGroupNewButton:SetPoint("BOTTOM",  bargroups.bct2, "BOTTOM", 0, -5); 
bargroups.BarGroupNewButton:SetPoint("RIGHT",  bargroups.panel, "RIGHT", -16, 0);
bargroups.BarGroupNewButton:SetText(L.auraconf_newconf);
bargroups.BarGroupNewButton:SetHeight(25)
bargroups.BarGroupNewButton:SetWidth(100)

bargroups.BarGroupDeleteButton = CreateFrame("Button", "BarGroupDeleteButton", bargroups.panel, "UIPanelButtonTemplate");
bargroups.BarGroupDeleteButton:SetPoint("BOTTOM",  bargroups.BarGroupNewButton, "TOP", 0, 4); 
bargroups.BarGroupDeleteButton:SetPoint("RIGHT",  bargroups.panel, "RIGHT", -16, 0); 
bargroups.BarGroupDeleteButton:SetText(L.auraconf_delconf);
bargroups.BarGroupDeleteButton:SetHeight(25)
bargroups.BarGroupDeleteButton:SetWidth(100)

--config name label
bargroups.bgt1 = bargroups.panel:CreateFontString("$parentText1", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
bargroups.bgt1:SetPoint("TOPLEFT", 16, -100)
bargroups.bgt1:SetText(L.bargroup_groupname)

--config name editbox
bargroups.GroupNameEditBox = CreateFrame ( "EditBox", "$parentEditBox1", bargroups.panel, "InputBoxTemplate")
bargroups.GroupNameEditBox:SetPoint("BOTTOMLEFT",  bargroups.bgt1, "BOTTOMRIGHT", 8, 0); 
bargroups.GroupNameEditBox:SetHeight(12)
bargroups.GroupNameEditBox:SetFontObject("GameFontWhiteSmall")
bargroups.GroupNameEditBox:Show()
bargroups.GroupNameEditBox:SetWidth(100)
bargroups.GroupNameEditBox:SetAutoFocus(false)
bargroups.GroupNameEditBox:ClearFocus()

--bar group sortby dropdown label
bargroups.bgt2 = bargroups.panel:CreateFontString("$parentText2", "OVERLAY", "GameFontNormalSmall", nil, "LEFT", "TOP", "ARTWORK")
bargroups.bgt2:SetPoint("TOPLEFT",  bargroups.bgt1, "BOTTOMLEFT", 0, -20);
bargroups.bgt2:SetText(L.bargroup_sortby)

--br group sortby dropdown
bargroups.GroupSortDropDownMenu = CreateFrame("Frame", "GroupSortDropDownMenu", bargroups.panel, "UIDropDownMenuTemplate");
bargroups.GroupSortDropDownMenu:SetPoint("TOPLEFT", bargroups.bgt2, "BOTTOMLEFT", 0, -10)
UIDropDownMenu_SetWidth(bargroups.GroupSortDropDownMenu, 120)



----------------------------------------------------------------------------------------------
------------------- combo and energy panel ---------------------------------------------------
----------------------------------------------------------------------------------------------

ThievesTools.frames.cpopts = {}
local cpopts = ThievesTools.frames.cpopts
cpopts.panel = CreateFrame( "Frame", "TT_cpoptsPanel", UIParent );
cpopts.panel.name = L.cpopts_cpoptslabel
cpopts.panel.parent = modName
InterfaceOptions_AddCategory(cpopts.panel)

cpopts.ComboOptsComboButton = CreateFrame("Button", "TTComboOptsComboButton", cpopts.panel, "UIPanelButtonGrayTemplate");
cpopts.ComboOptsComboButton:SetPoint("TOPLEFT",  cpopts.panel, "TOPLEFT", 16, -12); 
cpopts.ComboOptsComboButton:SetText(L.cpopts_combosettings);
cpopts.ComboOptsComboButton:SetHeight(25)
cpopts.ComboOptsComboButton:SetWidth(100)

cpopts.ComboOptsEnergyButton = CreateFrame("Button", "TTComboOptsEnergyButton", cpopts.panel, "UIPanelButtonGrayTemplate");
cpopts.ComboOptsEnergyButton:SetPoint("TOPLEFT",  cpopts.panel, "TOPLEFT", 136, -12); 
cpopts.ComboOptsEnergyButton:SetText(L.cpopts_energysettings);
cpopts.ComboOptsEnergyButton:SetHeight(25)
cpopts.ComboOptsEnergyButton:SetWidth(100)

--- start combo frame

cpopts.ComboOptsComboFrame = CreateFrame("Frame", "TTComboOptsComboFrame", cpopts.panel)
cpopts.ComboOptsComboFrame:SetPoint("TOPLEFT", cpopts.panel, "TOPLEFT", 0, -45)
cpopts.ComboOptsComboFrame:SetPoint("RIGHT", cpopts.panel, "RIGHT", 0, 0)
cpopts.ComboOptsComboFrame:SetPoint("BOTTOM", cpopts.panel, "BOTTOM", 0, 0)

--- end combo frame

--- start energy frame
cpopts.ComboOptsEnergyFrame = CreateFrame("Frame", "TTComboOptsEnergyFrame", cpopts.panel)
cpopts.ComboOptsEnergyFrame:SetPoint("TOPLEFT", cpopts.panel, "TOPLEFT", 0, -45)
cpopts.ComboOptsEnergyFrame:SetPoint("RIGHT", cpopts.panel, "RIGHT", 0, 0)
cpopts.ComboOptsEnergyFrame:SetPoint("BOTTOM", cpopts.panel, "BOTTOM", 0, 0)

--- end energy frame

------------------------------------------------------------------------------------------------------
------------------  editbox and onclick functions --------------------------------------------------
------------------------------------------------------------------------------------------------------

--- main options
local function ProfileDropDownMenuItem_OnClick()
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ProfileEditBox:SetText(L.mainopt_copystring..UIDropDownMenu_GetText(mainoptions.ProfileDropDownMenu))
	FixEditboxScroll(mainoptions.ProfileEditBox)
end

local function ProfileDeleteButton_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(mainoptions.ProfileDropDownMenu)
	if #TT_profiles > 1 then
		t_remove(TT_profiles, index)
		if TT_ap > #TT_profiles then 
			TT_ap = #TT_profiles
			ThievesTools.ap = TT_profiles[TT_ap]
		end
	else
	end
		ThievesTools:InitOptions()
end

local function ProfileCreateButton_OnClick()
	local profname = mainoptions.ProfileEditBox:GetText()
	local bnametaken = false
	for i = 1, #TT_profiles do
		if TT_profiles[i] and TT_profiles[i].profilename then
			if TT_profiles[i].profilename == profname then bnametaken = true end;
		end
	end
	if (bnametaken == false) then
		local i = #TT_profiles + 1
		TT_profiles[i] = {}
		TT_profiles[i] = ThievesTools:deepcopy(TT_profiles[TT_ap])
		TT_profiles[i].profilename = profname
		TT_ap = i
		ThievesTools.ap = TT_profiles[TT_ap]
		ThievesTools:InitOptions()
	end
end

local function MoveFramesButton_OnClick()
	
	local function lockframes()
		ThievesTools:FrameLocks(true)
		InterfaceOptionsFrame_OpenToCategory(ThievesTools.frames.mainoptions.panel);
	end

	StaticPopupDialogs["TT_moveframes"] = {
		text = L.mainopt_moveinfo,
		button1 = L.mainopt_movedone,
		OnAccept = function()
		lockframes();
		end,
		timeout = 0,
		whileDead = 1,
		hideOnEscape = 1
	};
	
	InterfaceOptionsFrame_Show()
	ThievesTools:FrameLocks(false)
	StaticPopup_Show ("TT_moveframes");
end


---bar configs

local function BarConfigDropDownMenuItem_OnClick()
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools:InitBarConfigs()
end

local function BarConfigDeleteButton_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if #ThievesTools.ap.barconfigs > 1 then
		t_remove(ThievesTools.ap.barconfigs, index)
		local newindex = 1
		if (#ThievesTools.ap.barconfigs > 1) then newindex = index - 1 end;
		UIDropDownMenu_Initialize(barconfs.BarConfigDropDownMenu, BarConfigDropDownMenu_Initialise)
		UIDropDownMenu_SetSelectedValue(barconfs.BarConfigDropDownMenu, newindex);
	else
	end
		ThievesTools:InitBarConfigs()
end

local function BarConfigNewButton_OnClick()
	local index = #ThievesTools.ap.barconfigs
	index = index + 1
	ThievesTools.ap.barconfigs[index] = {}
	ThievesTools.ap.barconfigs[index] = ThievesTools:deepcopy(ThievesTools.ap.barconfigs[0])
	ThievesTools.ap.barconfigs[index].rank = #ThievesTools.ap.barconfigs
	UIDropDownMenu_Initialize(barconfs.BarConfigDropDownMenu, BarConfigDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.BarConfigDropDownMenu, index);
	ThievesTools:InitBarConfigs()
end

local function BarConfigCloneButton_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	local newindex = #ThievesTools.ap.barconfigs
	newindex = newindex + 1
	ThievesTools.ap.barconfigs[newindex] = {}
	ThievesTools.ap.barconfigs[newindex] = ThievesTools:deepcopy(ThievesTools.ap.barconfigs[index])
	ThievesTools.ap.barconfigs[newindex].barname = L.mainopt_copystring..ThievesTools.ap.barconfigs[newindex].barname
	ThievesTools.ap.barconfigs[newindex].rank = #ThievesTools.ap.barconfigs
	UIDropDownMenu_Initialize(barconfs.BarConfigDropDownMenu, BarConfigDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.BarConfigDropDownMenu, newindex);
	ThievesTools:InitBarConfigs()
end

local function BarConfigAuraButton_OnClick()
	barconfs.BarConfigAuraButton:LockHighlight()
	barconfs.BarConfigAuraFrame:Show()
	barconfs.BarConfigBarButton:UnlockHighlight()
	barconfs.BarConfigBarFrame:Hide()
	barconfs.BarConfigBar2Button:UnlockHighlight()
	barconfs.BarConfigBar2Frame:Hide()
	barconfs.BarConfigExtrasButton:UnlockHighlight()
	barconfs.BarConfigExtrasFrame:Hide()
end

local function BarConfigBarButton_OnClick()
	barconfs.BarConfigAuraButton:UnlockHighlight()
	barconfs.BarConfigAuraFrame:Hide()
	barconfs.BarConfigBarButton:LockHighlight()
	barconfs.BarConfigBarFrame:Show()
	barconfs.BarConfigBar2Button:UnlockHighlight()
	barconfs.BarConfigBar2Frame:Hide()
	barconfs.BarConfigExtrasButton:UnlockHighlight()
	barconfs.BarConfigExtrasFrame:Hide()
end

local function BarConfigBar2Button_OnClick()
	barconfs.BarConfigAuraButton:UnlockHighlight()
	barconfs.BarConfigAuraFrame:Hide()
	barconfs.BarConfigBarButton:UnlockHighlight()
	barconfs.BarConfigBarFrame:Hide()
	barconfs.BarConfigBar2Button:LockHighlight()
	barconfs.BarConfigBar2Frame:Show()
	barconfs.BarConfigExtrasButton:UnlockHighlight()
	barconfs.BarConfigExtrasFrame:Hide()
end

local function BarConfigExtrasButton_OnClick()
	barconfs.BarConfigAuraButton:UnlockHighlight()
	barconfs.BarConfigAuraFrame:Hide()
	barconfs.BarConfigBarButton:UnlockHighlight()
	barconfs.BarConfigBarFrame:Hide()
	barconfs.BarConfigBar2Button:UnlockHighlight()
	barconfs.BarConfigBar2Frame:Hide()
	barconfs.BarConfigExtrasButton:LockHighlight()
	barconfs.BarConfigExtrasFrame:Show()
end

local function BarNameEditBox_OnTextChange()
	--FixEditboxScroll(BarNameEditBox)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	ThievesTools.ap.barconfigs[index].barname = barconfs.BarNameEditBox:GetText()
	UIDropDownMenu_Initialize(barconfs.BarConfigDropDownMenu, BarConfigDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.BarConfigDropDownMenu, index)
	UIDropDownMenu_SetText(barconfs.BarConfigDropDownMenu, ThievesTools.ap.barconfigs[index].barname)
	--ThievesTools:InitBarConfigs()
end

local function BarEnabledCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].enabled = true
	else
		ThievesTools.ap.barconfigs[index].enabled = false
	end
end

local function AuraNameEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	ThievesTools.ap.barconfigs[index].buffname = barconfs.AuraNameEditBox:GetText()
end

local function ShortNameEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	ThievesTools.ap.barconfigs[index].shortname = barconfs.ShortNameEditBox:GetText()
end

local function AuraRankEditBox_OnEnterPressed()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.AuraRankEditBox:GetText() == "") then
		local newrank = tonum(barconfs.AuraRankEditBox:GetText())
		if (newrank > 0) and (newrank < 100) then
			ThievesTools:SetAuraRank(index, newrank)
		end
	end
	barconfs.AuraRankEditBox:SetText(ThievesTools.ap.barconfigs[index].rank)
end

local function AuraTypeDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.barconfigs[index].buff = this.value
end

local function AuraFromDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.barconfigs[index].from = this.value
	if this.value == "named" then 
		barconfs.bcat8:SetVertexColor(1,1,1)
		barconfs.AuraFromNameEditBox:SetTextColor(1,1,1)
	else
		barconfs.bcat8:SetVertexColor(0.5,0.5,0.5)
		barconfs.AuraFromNameEditBox:SetTextColor(0.5,0.5,0.5)
	end
end

local function AuraFromNameEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	ThievesTools.ap.barconfigs[index].fromname = barconfs.AuraFromNameEditBox:GetText()
end

local function AuraToDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.barconfigs[index].to = this.value
	if this.value == "named" then 
		barconfs.bcat9:SetVertexColor(1,1,1)
		barconfs.AuraToNameEditBox:SetTextColor(1,1,1)
	else
		barconfs.bcat9:SetVertexColor(0.5,0.5,0.5)
		barconfs.AuraToNameEditBox:SetTextColor(0.5,0.5,0.5)
	end
end

local function AuraToNameEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	ThievesTools.ap.barconfigs[index].toname = barconfs.AuraToNameEditBox:GetText()
end

local function  FullscanEnabledCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].fullscan = true
	else
		ThievesTools.ap.barconfigs[index].fullscan = false
	end
end

local function  FixedDurCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].fixeddur = true
	else
		ThievesTools.ap.barconfigs[index].fixeddur = false
	end
end

local function  ChargesCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].updatecharges = true
	else
		ThievesTools.ap.barconfigs[index].updatecharges = false
	end
end

local function  MissingCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].checkmissing = true
	else
		ThievesTools.ap.barconfigs[index].checkmissing = false
	end
end


local function  SuppressCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].suppress = true
	else
		ThievesTools.ap.barconfigs[index].suppress = false
	end
end

local function BarColorFrame_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	local barconfig = ThievesTools.ap.barconfigs[index]
	
	ColorPickerFrame:SetFrameStrata("TOOLTIP")
	ColorPickerFrame:SetPoint("TOPLEFT", barconfs.BarConfigFrame, "CENTER")
	ColorPickerFrame.hasOpacity = false
	
	local function MY_COLOR_FUNCTION()
	barconfig.color_r, barconfig.color_g, barconfig.color_b = ColorPickerFrame:GetColorRGB();
	barconfs.bartexture:SetVertexColor(barconfig.color_r, barconfig.color_g, barconfig.color_b, barconfig.bar_alpha) 
	end
	
	ColorPickerFrame.previousValues = {barconfig.color_r, barconfig.color_g, barconfig.color_b}
	local function MY_CANCEL_FUNCTION()
		barconfig.color_r = ColorPickerFrame.previousValues[1]
		barconfig.color_g = ColorPickerFrame.previousValues[2]
		barconfig.color_b = ColorPickerFrame.previousValues[3]
		barconfs.bartexture:SetVertexColor(barconfig.color_r, barconfig.color_g, barconfig.color_b, barconfig.bar_alpha) 
	end
	
	ColorPickerFrame.cancelFunc = MY_CANCEL_FUNCTION
	ColorPickerFrame.func = MY_COLOR_FUNCTION
	ColorPickerFrame:Show();
	ColorPickerFrame:SetColorRGB(barconfig.color_r, barconfig.color_g, barconfig.color_b);
end

local function BarWidthEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.BarWidthEditBox:GetText() == "") then 
		ThievesTools.ap.barconfigs[index].width = tonum(barconfs.BarWidthEditBox:GetText())
	else
		barconfs.BarWidthEditBox:SetText(ThievesTools.ap.barconfigs[index].width)
	end
end

local function BarHeightEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.BarHeightEditBox:GetText() == "") then 
		ThievesTools.ap.barconfigs[index].height = tonum(barconfs.BarHeightEditBox:GetText())
	else
		barconfs.BarHeightEditBox:SetText(ThievesTools.ap.barconfigs[index].height)
	end
end

local function FrameAlphaSlider_OnChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	ThievesTools.ap.barconfigs[index].alpha = ThievesTools:round(barconfs.FrameAlphaSlider:GetValue(), 2)
	barconfs.FrameAlphaEditBox:SetText(ThievesTools.ap.barconfigs[index].alpha)
end

local function FrameAlphaEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.FrameAlphaEditBox:GetText() == "") and (tonum(barconfs.FrameAlphaEditBox:GetText())) and (tonum(barconfs.FrameAlphaEditBox:GetText()) < 1.0001) and (tonum(barconfs.FrameAlphaEditBox:GetText()) > -0.0001) then 
		ThievesTools.ap.barconfigs[index].alpha = tonum(barconfs.FrameAlphaEditBox:GetText())
		barconfs.FrameAlphaSlider:SetValue(ThievesTools.ap.barconfigs[index].alpha)
	else
		barconfs.FrameAlphaEditBox:SetText(ThievesTools.ap.barconfigs[index].alpha)
	end
end

local function BarAlphaSlider_OnChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	ThievesTools.ap.barconfigs[index].bar_alpha = ThievesTools:round(barconfs.BarAlphaSlider:GetValue(), 2)
	barconfs.BarAlphaEditBox:SetText(ThievesTools.ap.barconfigs[index].bar_alpha)
end

local function BarAlphaEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.BarAlphaEditBox:GetText() == "") and (tonum(barconfs.BarAlphaEditBox:GetText())) and (tonum(barconfs.BarAlphaEditBox:GetText()) < 1.0001) and (tonum(barconfs.BarAlphaEditBox:GetText()) > -0.0001) then 
		ThievesTools.ap.barconfigs[index].bar_alpha = tonum(barconfs.BarAlphaEditBox:GetText())
		barconfs.BarAlphaSlider:SetValue(ThievesTools.ap.barconfigs[index].bar_alpha)
	else
		barconfs.BarAlphaEditBox:SetText(ThievesTools.ap.barconfigs[index].bar_alpha)
	end
end

local function BgAlphaSlider_OnChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	ThievesTools.ap.barconfigs[index].bg_alpha = ThievesTools:round(barconfs.BgAlphaSlider:GetValue(), 2)
	barconfs.BgAlphaEditBox:SetText(ThievesTools.ap.barconfigs[index].bg_alpha)
end

local function BgAlphaEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.BgAlphaEditBox:GetText() == "") and (tonum(barconfs.BgAlphaEditBox:GetText())) and (tonum(barconfs.BgAlphaEditBox:GetText()) < 1.0001) and (tonum(barconfs.BgAlphaEditBox:GetText()) > -0.0001) then 
		ThievesTools.ap.barconfigs[index].bg_alpha = tonum(barconfs.BgAlphaEditBox:GetText())
		barconfs.BgAlphaSlider:SetValue(ThievesTools.ap.barconfigs[index].bg_alpha)
	else
		barconfs.BgAlphaEditBox:SetText(ThievesTools.ap.barconfigs[index].bg_alpha)
	end
end

local function BarSparkCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].showspark = true
	else
		ThievesTools.ap.barconfigs[index].showspark = false
	end
end

local function BarPeriodSparkCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].periodspark = true
	else
		ThievesTools.ap.barconfigs[index].periodspark = false
	end
end

local function PinBarGroupCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].bargrouppin = true
	else
		ThievesTools.ap.barconfigs[index].bargrouppin = false
	end
end

local function PinOwnBarGroupCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].selfbuffpin = true
	else
		ThievesTools.ap.barconfigs[index].selfbuffpin = false
	end
end

local function DefBarGroupDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.barconfigs[index].bargroup = this.value
end



local function BuffTextDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.barconfigs[index].textbuffpos = this.value
end

local function StackTextDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.barconfigs[index].textstackpos = this.value
end

local function TimeTextDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.barconfigs[index].textdurationpos = this.value
end

local function FontSizeEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.FontSizeEditBox:GetText() == "") then 
		ThievesTools.ap.barconfigs[index].fontsize = tonum(barconfs.FontSizeEditBox:GetText())
	else
		barconfs.FontSizeEditBox:SetText(ThievesTools.ap.barconfigs[index].fontsize)
	end
end

local function FontColorFrame_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	local barconfig = ThievesTools.ap.barconfigs[index]
	
	ColorPickerFrame:SetFrameStrata("TOOLTIP")
	ColorPickerFrame:SetPoint("TOPLEFT", barconfs.BarConfigFrame, "CENTER")
	ColorPickerFrame.hasOpacity = false
	
	local function MY_COLOR_FUNCTION()
	barconfig.font_r, barconfig.font_g, barconfig.font_b = ColorPickerFrame:GetColorRGB();
	barconfs.FontColorFrame:SetBackdropColor(barconfig.font_r, barconfig.font_g, barconfig.font_b, barconfig.alpha) 
	end
	
	ColorPickerFrame.previousValues = {barconfig.font_r, barconfig.font_g, barconfig.font_b}
	local function MY_CANCEL_FUNCTION()
		barconfig.font_r = ColorPickerFrame.previousValues[1]
		barconfig.font_g = ColorPickerFrame.previousValues[2]
		barconfig.font_b = ColorPickerFrame.previousValues[3]
		barconfs.FontColorFrame:SetBackdropColor(barconfig.font_r, barconfig.font_g, barconfig.font_b, barconfig.alpha)  
	end
	
	ColorPickerFrame.cancelFunc = MY_CANCEL_FUNCTION
	ColorPickerFrame.func = MY_COLOR_FUNCTION
	ColorPickerFrame:Show();
	ColorPickerFrame:SetColorRGB(barconfig.font_r, barconfig.font_g, barconfig.font_b);
end

local function FontDropCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].fontdrop = true
	else
		ThievesTools.ap.barconfigs[index].fontdrop = false
	end
end

local function FontOutCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].fontoutline = true
	else
		ThievesTools.ap.barconfigs[index].fontoutline = false
	end
end

------- bar+ config functions

local function AuraIconDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.barconfigs[index].showicon = this.value
end

local function RaidIconDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.barconfigs[index].showraidicon = this.value
end

local function AuraIconOnlyCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].showicononly = true
	else
		ThievesTools.ap.barconfigs[index].showicononly = false
	end
end

local function HideAuraTextCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].textbuffhide = true
	else
		ThievesTools.ap.barconfigs[index].textbuffhide = false
	end
end

local function FlashLowCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].flashlow = true
	else
		ThievesTools.ap.barconfigs[index].flashlow = false
	end
end

local function FlashLowEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.FlashLowEditBox:GetText() == "") then 
		ThievesTools.ap.barconfigs[index].flashlowtime = tonum(barconfs.FlashLowEditBox:GetText())
	else
		barconfs.FlashLowEditBox:SetText(ThievesTools.ap.barconfigs[index].flashlowtime)
	end
end

local function AppendSourceCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].appendsource = true
	else
		ThievesTools.ap.barconfigs[index].appendsource = false
	end
end

local function FixedSizeCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].fixedsize = true
	else
		ThievesTools.ap.barconfigs[index].fixedsize = false
	end
end

local function FixedSizeEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.FixedSizeEditBox:GetText() == "") then 
		ThievesTools.ap.barconfigs[index].fixedsizevalue = tonum(barconfs.FixedSizeEditBox:GetText())
	else
		barconfs.FixedSizeEditBox:SetText(ThievesTools.ap.barconfigs[index].fixedsizevalue)
	end
end

local function SecondBarCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].secondbar = true
	else
		ThievesTools.ap.barconfigs[index].secondbar = false
	end
end

local function Bar2AlphaSlider_OnChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	ThievesTools.ap.barconfigs[index].bar2_alpha = ThievesTools:round(barconfs.Bar2AlphaSlider:GetValue(), 2)
	barconfs.Bar2AlphaEditBox:SetText(ThievesTools.ap.barconfigs[index].bar2_alpha)
end

local function Bar2AlphaEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.Bar2AlphaEditBox:GetText() == "") and (tonum(barconfs.Bar2AlphaEditBox:GetText())) and (tonum(barconfs.Bar2AlphaEditBox:GetText()) < 1.0001) and (tonum(barconfs.Bar2AlphaEditBox:GetText()) > -0.0001) then 
		ThievesTools.ap.barconfigs[index].bar2_alpha = tonum(barconfs.Bar2AlphaEditBox:GetText())
		barconfs.Bar2AlphaSlider:SetValue(ThievesTools.ap.barconfigs[index].bar2_alpha)
	else
		barconfs.Bar2AlphaEditBox:SetText(ThievesTools.ap.barconfigs[index].bar2_alpha)
	end
end

local function Bar2ColorFrame_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	local barconfig = ThievesTools.ap.barconfigs[index]
	
	ColorPickerFrame:SetFrameStrata("TOOLTIP")
	ColorPickerFrame:SetPoint("TOPLEFT", barconfs.BarConfigFrame, "CENTER")
	ColorPickerFrame.hasOpacity = false
	
	local function MY_COLOR_FUNCTION()
	barconfig.color1_r, barconfig.color1_g, barconfig.color1_b = ColorPickerFrame:GetColorRGB();
	barconfs.bar2texture:SetVertexColor(barconfig.color1_r, barconfig.color1_g, barconfig.color1_b, barconfig.bar2_alpha) 
	end
	
	ColorPickerFrame.previousValues = {barconfig.color1_r, barconfig.color1_g, barconfig.color1_b}
	local function MY_CANCEL_FUNCTION()
		barconfig.color1_r = ColorPickerFrame.previousValues[1]
		barconfig.color1_g = ColorPickerFrame.previousValues[2]
		barconfig.color1_b = ColorPickerFrame.previousValues[3]
		barconfs.bar2texture:SetVertexColor(barconfig.color1_r, barconfig.color1_g, barconfig.color1_b, barconfig.bar2_alpha) 
	end
	
	ColorPickerFrame.cancelFunc = MY_CANCEL_FUNCTION
	ColorPickerFrame.func = MY_COLOR_FUNCTION
	ColorPickerFrame:Show();
	ColorPickerFrame:SetColorRGB(barconfig.color1_r, barconfig.color1_g, barconfig.color1_b);
end

local function SecondBarFixedSize()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	local newfixedsize = (ThievesTools.ap.barconfigs[index].combo_base + (5 * ThievesTools.ap.barconfigs[index].combo_per)) * ThievesTools.ap.barconfigs[index].combo_multi
	ThievesTools.ap.barconfigs[index].fixedsizevalue = newfixedsize
	barconfs.FixedSizeEditBox:SetText(newfixedsize)
end

local function BaseComboEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.BaseComboEditBox:GetText() == "") then 
		ThievesTools.ap.barconfigs[index].combo_base = tonum(barconfs.BaseComboEditBox:GetText())
	else
		barconfs.BaseComboEditBox:SetText(ThievesTools.ap.barconfigs[index].combo_base)
	end
	SecondBarFixedSize()
end

local function PerComboEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.PerComboEditBox:GetText() == "") then 
		ThievesTools.ap.barconfigs[index].combo_per = tonum(barconfs.PerComboEditBox:GetText())
	else
		barconfs.PerComboEditBox:SetText(ThievesTools.ap.barconfigs[index].combo_per)
	end
	SecondBarFixedSize()
end

local function MultiComboEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.MultiComboEditBox:GetText() == "") and (tonum(barconfs.MultiComboEditBox:GetText()))then 
		ThievesTools.ap.barconfigs[index].combo_multi = tonum(barconfs.MultiComboEditBox:GetText())
	else
		barconfs.MultiComboEditBox:SetText(ThievesTools.ap.barconfigs[index].combo_multi)
	end
	SecondBarFixedSize()
end

------- bar extras config functions

local function AnnounceDestDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.barconfigs[index].announcetype = this.value
end

local function AnnounceChanEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	ThievesTools.ap.barconfigs[index].announcedest = barconfs.AnnounceChanEditBox:GetText()
end

local function AnnounceTimeDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.barconfigs[index].announcecriteria = this.value
	if this.value == "STACKS" then
		barconfs.bcet28:SetText(L.auraconf_soundstacksup)
	else
		barconfs.bcet28:SetText(L.auraconf_soundtimeleft)
	end
end

local function AnnounceTimeEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.AnnounceTimeEditBox:GetText() == "") and (tonum(barconfs.AnnounceTimeEditBox:GetText()))then 
		ThievesTools.ap.barconfigs[index].announcetimeleft = tonum(barconfs.AnnounceTimeEditBox:GetText())
	else
		barconfs.AnnounceTimeEditBox:SetText(ThievesTools.ap.barconfigs[index].announcetimeleft)
	end
end

local function AnnounceNonSelfCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].announcenonself = true
	else
		ThievesTools.ap.barconfigs[index].announcenonself = false
	end
end

local function AnnounceEveryCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].announceeverysec = true
	else
		ThievesTools.ap.barconfigs[index].announceeverysec = false
	end
end

local function AnnounceExpire_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].announceexp = true
	else
		ThievesTools.ap.barconfigs[index].announceexp = false
	end
end

local function PlaySoundDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.barconfigs[index].sound = this.value
end

local function SoundWhenDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.barconfigs[index].soundtype = this.value
	if this.value == "STACKS" then
		barconfs.bcet15:SetText(L.auraconf_soundstacksup)
	else
		barconfs.bcet15:SetText(L.auraconf_soundtimeleft)
	end
end

local function SoundTimeEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.SoundTimeEditBox:GetText() == "") and (tonum(barconfs.SoundTimeEditBox:GetText()))then 
		ThievesTools.ap.barconfigs[index].soundvalue = tonum(barconfs.SoundTimeEditBox:GetText())
	else
		barconfs.SoundTimeEditBox:SetText(ThievesTools.ap.barconfigs[index].soundvalue)
	end
end

local function SoundEverySecondCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].soundeverysec = true
	else
		ThievesTools.ap.barconfigs[index].soundeverysec = false
	end
end

local function CooldownCheck_MouseUp(self)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if self:GetChecked() then 
		ThievesTools.ap.barconfigs[index].icdbar = true
	else
		ThievesTools.ap.barconfigs[index].icdbar = false
	end
end

local function CDBarGroupDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.barconfigs[index].icdbargroup = this.value
end

local function CooldownEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	if not (barconfs.CooldownEditBox:GetText() == "") and (tonum(barconfs.CooldownEditBox:GetText()))then 
		ThievesTools.ap.barconfigs[index].icdlength = tonum(barconfs.CooldownEditBox:GetText())
	else
		barconfs.CooldownEditBox:SetText(ThievesTools.ap.barconfigs[index].icdlength)
	end
end


-- bar groups functions start

local function BarGroupDropDownMenuItem_OnClick()
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools:InitBarGroups()
end

local function BarGroupDeleteButton_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(bargroups.BarGroupDropDownMenu)
	local groupname = ThievesTools.ap.bargroups[index].name
	if index > 2 and #ThievesTools.ap.bargroups > 2 then
		t_remove(ThievesTools.ap.bargroups, index)
		local newindex = index - 1
		UIDropDownMenu_Initialize(bargroups.BarGroupDropDownMenu, BarGroupDropDownMenu_Initialise)
		UIDropDownMenu_SetSelectedValue(bargroups.BarGroupDropDownMenu, newindex);
		
		--check no aura configs were using the bar, if they were, kick them to untargetted for now
		local bmoved = false
		local movedthese = {}
		for i = 1, #ThievesTools.ap.barconfigs do
			if ThievesTools.ap.barconfigs[i].bargroup == index then
				ThievesTools.ap.barconfigs[i].bargroup = 2
				t_insert(movedthese, ThievesTools.ap.barconfigs[i].barname)
				bmoved = true
			end
			if ThievesTools.ap.barconfigs[i].icdbargroup == index then
				ThievesTools.ap.barconfigs[i].icdbargroup = 2
				t_insert(movedthese, ThievesTools.ap.barconfigs[i].barname .. " CD")
				bmoved = true
			end
		end
		if bmoved then
			AzMsg(modName..": ".. L.bargroup_movedauras1 .. " " ..groupname.. " " .. L.bargroup_movedauras2 .. " " .. ThievesTools.ap.bargroups[2].name .. " ".. L.auraconf_bargroupcd)
			for i = 1, #movedthese do
			AzMsg(modName..": ".. movedthese[i])
			end
		end
	ThievesTools:InitBarGroups()
	else
	AzMsg(modName..": ".. L.bargroup_nodelete)
	end
		ThievesTools:InitBarGroups()
end

local function BarGroupNewButton_OnClick()
	local index = #ThievesTools.ap.bargroups
	index = index + 1
	ThievesTools.ap.bargroups[index] = {}
	ThievesTools.ap.bargroups[index] = ThievesTools:deepcopy(ThievesTools.ap.bargroups[0])
	ThievesTools.ap.bargroups[index].name = L.bargroup_newgroup
	UIDropDownMenu_Initialize(bargroups.BarGroupDropDownMenu, BarGroupDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(bargroups.BarGroupDropDownMenu, index);
	ThievesTools:CreateEnabledFrames()
	ThievesTools:InitBarGroups()
end

local function GroupNameEditBox_OnTextChange()
	local index = UIDropDownMenu_GetSelectedValue(bargroups.BarGroupDropDownMenu)
	ThievesTools.ap.bargroups[index].name = bargroups.GroupNameEditBox:GetText()
	UIDropDownMenu_Initialize(bargroups.BarGroupDropDownMenu, BarGroupDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(bargroups.BarGroupDropDownMenu, index)
	UIDropDownMenu_SetText(bargroups.BarGroupDropDownMenu, ThievesTools.ap.bargroups[index].name)
	ThievesTools:CreateEnabledFrames()
end

local function GroupSortDropDownMenuItem_OnClick()
	local index = UIDropDownMenu_GetSelectedValue(bargroups.BarGroupDropDownMenu)
	UIDropDownMenu_SetSelectedValue(this.owner, this.value);
	ThievesTools.ap.bargroups[index].sortby = this.value
end


--- cpopts functions start

local function ComboOptsComboButton_OnClick()
	cpopts.ComboOptsComboButton:LockHighlight()
	cpopts.ComboOptsComboFrame:Show()
	cpopts.ComboOptsEnergyButton:UnlockHighlight()
	cpopts.ComboOptsEnergyFrame:Hide()
end

local function ComboOptsEnergyButton_OnClick()
	cpopts.ComboOptsComboButton:UnlockHighlight()
	cpopts.ComboOptsComboFrame:Hide()
	cpopts.ComboOptsEnergyButton:LockHighlight()
	cpopts.ComboOptsEnergyFrame:Show()
end

----------------------------------------------------------------------------------------------------
---------- dropdown/editbox/checkbox initialisation ------------------------------------------------
----------------------------------------------------------------------------------------------------



local function ProfileDropDownMenu_Initialise()
	 local level = 1 --drop down menus can have sub menus. The value of "level" determines the drop down sub menu tier.
	 
	 local profileinfo = UIDropDownMenu_CreateInfo();
	 
	for i = 1, #TT_profiles do
		 profileinfo.text = TT_profiles[i].profilename; --the text of the menu item
		 profileinfo.value = i; -- the value of the menu item. This can be a string also.
		 profileinfo.func = function() ProfileDropDownMenuItem_OnClick() end; --sets the function to execute when this item is clicked
		 profileinfo.owner = mainoptions.ProfileDropDownMenu; --binds the drop down menu as the parent of the menu item. This is very important for dynamic drop down menues.
		 profileinfo.checked = nil; --initially set the menu item to being unchecked with a yellow tick
		 profileinfo.icon = nil; --we can use this to set an icon for the drop down menu item to accompany the text
		 UIDropDownMenu_AddButton(profileinfo, level); --Adds the new button to the drop down menu specified in the UIDropDownMenu_Initialise function. In this case, it's MyDropDownMenu
	end
end


local function BarConfigDropDownMenu_Initialise()
	 local level = 1 
	 
	 local configinfo = UIDropDownMenu_CreateInfo();
	 
	for i = 1, #ThievesTools.ap.barconfigs do
		 configinfo.text = ThievesTools.ap.barconfigs[i].barname; 
		 configinfo.value = i; 
		 configinfo.func = function() BarConfigDropDownMenuItem_OnClick() end;
		 configinfo.owner = barconfs.BarConfigDropDownMenu; 
		 configinfo.checked = nil; 
		 configinfo.icon = nil; 
		 UIDropDownMenu_AddButton(configinfo, level);
	end
end

local function AuraTypeDropDownMenu_Initialise()
	 local level = 1 
	 
	 local auratypeinfo = UIDropDownMenu_CreateInfo();

	 auratypeinfo.text = L.auraconf_buff; 
	 auratypeinfo.value = "BUFF"; 
	 auratypeinfo.func = function() AuraTypeDropDownMenuItem_OnClick() end; 
	 auratypeinfo.owner = barconfs.AuraTypeDropDownMenu; 
	 auratypeinfo.checked = nil; 
	 auratypeinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auratypeinfo, level); 

	 auratypeinfo.text = L.auraconf_debuff; 
	 auratypeinfo.value = "DEBUFF"; 
	 auratypeinfo.func = function() AuraTypeDropDownMenuItem_OnClick() end; 
	 auratypeinfo.owner = barconfs.AuraTypeDropDownMenu; 
	 auratypeinfo.checked = nil; 
	 auratypeinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auratypeinfo, level); 
end

local function AuraFromDropDownMenu_Initialise()
	 local level = 1 
	 
	 local aurafrominfo = UIDropDownMenu_CreateInfo();

	 aurafrominfo.text = L.auraconf_player; 
	 aurafrominfo.value = "player"; 
	 aurafrominfo.func = function() AuraFromDropDownMenuItem_OnClick() end; 
	 aurafrominfo.owner = barconfs.AuraFromDropDownMenu; 
	 aurafrominfo.checked = nil; 
	 aurafrominfo.icon = nil; 
	 UIDropDownMenu_AddButton(aurafrominfo, level); 

	 aurafrominfo.text = L.auraconf_target; 
	 aurafrominfo.value = "target"; 
	 aurafrominfo.func = function() AuraFromDropDownMenuItem_OnClick() end; 
	 aurafrominfo.owner = barconfs.AuraFromDropDownMenu; 
	 aurafrominfo.checked = nil; 
	 aurafrominfo.icon = nil; 
	 UIDropDownMenu_AddButton(aurafrominfo, level);
	 
	 aurafrominfo.text = L.auraconf_focus; 
	 aurafrominfo.value = "focus";
	 aurafrominfo.func = function() AuraFromDropDownMenuItem_OnClick() end; 
	 aurafrominfo.owner = barconfs.AuraFromDropDownMenu; 
	 aurafrominfo.checked = nil; 
	 aurafrominfo.icon = nil; 
	 UIDropDownMenu_AddButton(aurafrominfo, level);
	 
	 aurafrominfo.text = L.auraconf_pet; 
	 aurafrominfo.value = "pet";
	 aurafrominfo.func = function() AuraFromDropDownMenuItem_OnClick() end; 
	 aurafrominfo.owner = barconfs.AuraFromDropDownMenu; 
	 aurafrominfo.checked = nil; 
	 aurafrominfo.icon = nil; 
	 UIDropDownMenu_AddButton(aurafrominfo, level);

	 aurafrominfo.text = L.auraconf_vehicle; 
	 aurafrominfo.value = "vehicle";
	 aurafrominfo.func = function() AuraFromDropDownMenuItem_OnClick() end; 
	 aurafrominfo.owner = barconfs.AuraFromDropDownMenu; 
	 aurafrominfo.checked = nil; 
	 aurafrominfo.icon = nil; 
	 UIDropDownMenu_AddButton(aurafrominfo, level); 
	 
	 aurafrominfo.text = L.auraconf_group; 
	 aurafrominfo.value = "grouped";
	 aurafrominfo.func = function() AuraFromDropDownMenuItem_OnClick() end; 
	 aurafrominfo.owner = barconfs.AuraFromDropDownMenu; 
	 aurafrominfo.checked = nil; 
	 aurafrominfo.icon = nil; 
	 UIDropDownMenu_AddButton(aurafrominfo, level); 
	 
	 aurafrominfo.text = L.auraconf_friendly; 
	 aurafrominfo.value = "friendly";
	 aurafrominfo.func = function() AuraFromDropDownMenuItem_OnClick() end; 
	 aurafrominfo.owner = barconfs.AuraFromDropDownMenu; 
	 aurafrominfo.checked = nil; 
	 aurafrominfo.icon = nil; 
	 UIDropDownMenu_AddButton(aurafrominfo, level); 
	 
	 aurafrominfo.text = L.auraconf_any; 
	 aurafrominfo.value = "any";
	 aurafrominfo.func = function() AuraFromDropDownMenuItem_OnClick() end; 
	 aurafrominfo.owner = barconfs.AuraFromDropDownMenu; 
	 aurafrominfo.checked = nil; 
	 aurafrominfo.icon = nil; 
	 UIDropDownMenu_AddButton(aurafrominfo, level);
	 
	 aurafrominfo.text = L.auraconf_named; 
	 aurafrominfo.value = "named";
	 aurafrominfo.func = function() AuraFromDropDownMenuItem_OnClick() end; 
	 aurafrominfo.owner = barconfs.AuraFromDropDownMenu; 
	 aurafrominfo.checked = nil; 
	 aurafrominfo.icon = nil; 
	 UIDropDownMenu_AddButton(aurafrominfo, level); 
end

local function AuraToDropDownMenu_Initialise()
	 local level = 1 
	 
	 local auratoinfo = UIDropDownMenu_CreateInfo();

	 auratoinfo.text = L.auraconf_player; 
	 auratoinfo.value = "player"; 
	 auratoinfo.func = function() AuraToDropDownMenuItem_OnClick() end; 
	 auratoinfo.owner = barconfs.AuraToDropDownMenu; 
	 auratoinfo.checked = nil; 
	 auratoinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auratoinfo, level); 

	 auratoinfo.text = L.auraconf_target; 
	 auratoinfo.value = "target";
	 auratoinfo.func = function() AuraToDropDownMenuItem_OnClick() end; 
	 auratoinfo.owner = barconfs.AuraToDropDownMenu; 
	 auratoinfo.checked = nil; 
	 auratoinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auratoinfo, level);
	 
	 auratoinfo.text = L.auraconf_focus; 
	 auratoinfo.value = "focus";
	 auratoinfo.func = function() AuraToDropDownMenuItem_OnClick() end; 
	 auratoinfo.owner = barconfs.AuraToDropDownMenu; 
	 auratoinfo.checked = nil; 
	 auratoinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auratoinfo, level);
	 
	 auratoinfo.text = L.auraconf_pet; 
	 auratoinfo.value = "pet";
	 auratoinfo.func = function() AuraToDropDownMenuItem_OnClick() end; 
	 auratoinfo.owner = barconfs.AuraToDropDownMenu; 
	 auratoinfo.checked = nil; 
	 auratoinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auratoinfo, level);

	 auratoinfo.text = L.auraconf_vehicle; 
	 auratoinfo.value = "vehicle";
	 auratoinfo.func = function() AuraToDropDownMenuItem_OnClick() end; 
	 auratoinfo.owner = barconfs.AuraToDropDownMenu; 
	 auratoinfo.checked = nil; 
	 auratoinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auratoinfo, level); 
	 
	 auratoinfo.text = L.auraconf_group; 
	 auratoinfo.value = "grouped";
	 auratoinfo.func = function() AuraToDropDownMenuItem_OnClick() end; 
	 auratoinfo.owner = barconfs.AuraToDropDownMenu; 
	 auratoinfo.checked = nil; 
	 auratoinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auratoinfo, level); 
	 
	 auratoinfo.text = L.auraconf_friendly; 
	 auratoinfo.value = "friendly";
	 auratoinfo.func = function() AuraToDropDownMenuItem_OnClick() end; 
	 auratoinfo.owner = barconfs.AuraToDropDownMenu; 
	 auratoinfo.checked = nil; 
	 auratoinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auratoinfo, level); 
	 
	 auratoinfo.text = L.auraconf_any; 
	 auratoinfo.value = "any";
	 auratoinfo.func = function() AuraToDropDownMenuItem_OnClick() end; 
	 auratoinfo.owner = barconfs.AuraToDropDownMenu; 
	 auratoinfo.checked = nil; 
	 auratoinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auratoinfo, level);
	 
	 auratoinfo.text = L.auraconf_named; 
	 auratoinfo.value = "named";
	 auratoinfo.func = function() AuraToDropDownMenuItem_OnClick() end; 
	 auratoinfo.owner = barconfs.AuraToDropDownMenu; 
	 auratoinfo.checked = nil; 
	 auratoinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auratoinfo, level); 
end



local function DefBarGroupDropDownMenu_Initialise()
	 local level = 1 
	 
	 local defbargroupinfo = UIDropDownMenu_CreateInfo();
	 
	for i = 1, #ThievesTools.ap.bargroups do
		 defbargroupinfo.text = ThievesTools.ap.bargroups[i].name; 
		 defbargroupinfo.value = i; 
		 defbargroupinfo.func = function() DefBarGroupDropDownMenuItem_OnClick() end;
		 defbargroupinfo.owner = barconfs.DefBarGroupDropDownMenu; 
		 defbargroupinfo.checked = nil; 
		 defbargroupinfo.icon = nil; 
		 UIDropDownMenu_AddButton(defbargroupinfo, level);
	end
end



local function BuffTextDropDownMenu_Initialise()
	 local level = 1 
	 
	 local bufftextinfo = UIDropDownMenu_CreateInfo();
	 
	 bufftextinfo.text = L.center; 
	 bufftextinfo.value = "CENTER"; 
	 bufftextinfo.func = function() BuffTextDropDownMenuItem_OnClick() end;
	 bufftextinfo.owner = barconfs.BuffTextDropDownMenu; 
	 bufftextinfo.checked = nil; 
	 bufftextinfo.icon = nil; 
	 UIDropDownMenu_AddButton(bufftextinfo, level);
	 
	 bufftextinfo.text = L.left; 
	 bufftextinfo.value = "LEFT"; 
	 bufftextinfo.func = function() BuffTextDropDownMenuItem_OnClick() end;
	 bufftextinfo.owner = barconfs.BuffTextDropDownMenu; 
	 bufftextinfo.checked = nil; 
	 bufftextinfo.icon = nil; 
	 UIDropDownMenu_AddButton(bufftextinfo, level);
	 
	 bufftextinfo.text = L.right; 
	 bufftextinfo.value = "RIGHT"; 
	 bufftextinfo.func = function() BuffTextDropDownMenuItem_OnClick() end;
	 bufftextinfo.owner = barconfs.BuffTextDropDownMenu; 
	 bufftextinfo.checked = nil; 
	 bufftextinfo.icon = nil; 
	 UIDropDownMenu_AddButton(bufftextinfo, level);
end

local function StackTextDropDownMenu_Initialise()
	 local level = 1 
	 
	 local bufftextinfo = UIDropDownMenu_CreateInfo();
	 
	 bufftextinfo.text = L.center; 
	 bufftextinfo.value = "CENTER"; 
	 bufftextinfo.func = function() StackTextDropDownMenuItem_OnClick() end;
	 bufftextinfo.owner = barconfs.StackTextDropDownMenu; 
	 bufftextinfo.checked = nil; 
	 bufftextinfo.icon = nil; 
	 UIDropDownMenu_AddButton(bufftextinfo, level);
	 
	 bufftextinfo.text = L.left; 
	 bufftextinfo.value = "LEFT"; 
	 bufftextinfo.func = function() StackTextDropDownMenuItem_OnClick() end;
	 bufftextinfo.owner = barconfs.StackTextDropDownMenu; 
	 bufftextinfo.checked = nil; 
	 bufftextinfo.icon = nil; 
	 UIDropDownMenu_AddButton(bufftextinfo, level);
	 
	 bufftextinfo.text = L.right; 
	 bufftextinfo.value = "RIGHT"; 
	 bufftextinfo.func = function() StackTextDropDownMenuItem_OnClick() end;
	 bufftextinfo.owner = barconfs.StackTextDropDownMenu; 
	 bufftextinfo.checked = nil; 
	 bufftextinfo.icon = nil; 
	 UIDropDownMenu_AddButton(bufftextinfo, level);
end

local function TimeTextDropDownMenu_Initialise()
	 local level = 1 
	 
	 local bufftextinfo = UIDropDownMenu_CreateInfo();
	 
	 bufftextinfo.text = L.center; 
	 bufftextinfo.value = "CENTER"; 
	 bufftextinfo.func = function() TimeTextDropDownMenuItem_OnClick() end;
	 bufftextinfo.owner = barconfs.TimeTextDropDownMenu; 
	 bufftextinfo.checked = nil; 
	 bufftextinfo.icon = nil; 
	 UIDropDownMenu_AddButton(bufftextinfo, level);
	 
	 bufftextinfo.text = L.left; 
	 bufftextinfo.value = "LEFT"; 
	 bufftextinfo.func = function() TimeTextDropDownMenuItem_OnClick() end;
	 bufftextinfo.owner = barconfs.TimeTextDropDownMenu; 
	 bufftextinfo.checked = nil; 
	 bufftextinfo.icon = nil; 
	 UIDropDownMenu_AddButton(bufftextinfo, level);
	 
	 bufftextinfo.text = L.right; 
	 bufftextinfo.value = "RIGHT"; 
	 bufftextinfo.func = function() TimeTextDropDownMenuItem_OnClick() end;
	 bufftextinfo.owner = barconfs.TimeTextDropDownMenu; 
	 bufftextinfo.checked = nil; 
	 bufftextinfo.icon = nil; 
	 UIDropDownMenu_AddButton(bufftextinfo, level);
end

local function AuraIconDropDownMenu_Initialise()
	 local level = 1 
	 
	 local auraiconinfo = UIDropDownMenu_CreateInfo();
	 
	 auraiconinfo.text = L.disabled; 
	 auraiconinfo.value = "OFF"; 
	 auraiconinfo.func = function() AuraIconDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AuraIconDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.left; 
	 auraiconinfo.value = "LEFT"; 
	 auraiconinfo.func = function() AuraIconDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AuraIconDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.right; 
	 auraiconinfo.value = "RIGHT"; 
	 auraiconinfo.func = function() AuraIconDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AuraIconDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
end

local function RaidIconDropDownMenu_Initialise()
	 local level = 1 
	 
	 local auraiconinfo = UIDropDownMenu_CreateInfo();
	 
	 auraiconinfo.text = L.disabled; 
	 auraiconinfo.value = "OFF"; 
	 auraiconinfo.func = function() RaidIconDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.RaidIconDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.left; 
	 auraiconinfo.value = "LEFT"; 
	 auraiconinfo.func = function() RaidIconDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.RaidIconDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.right; 
	 auraiconinfo.value = "RIGHT"; 
	 auraiconinfo.func = function() RaidIconDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.RaidIconDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
end

local function AnnounceDestDropDownMenu_Initialise()
	 local level = 1 
	 
	 local auraiconinfo = UIDropDownMenu_CreateInfo();
	 
	 auraiconinfo.text = L.disabled; 
	 auraiconinfo.value = "OFF"; 
	 auraiconinfo.func = function() AnnounceDestDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AnnounceDestDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.auraconf_player; 
	 auraiconinfo.value = "SELF"; 
	 auraiconinfo.func = function() AnnounceDestDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AnnounceDestDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.channel; 
	 auraiconinfo.value = "CHANNEL"; 
	 auraiconinfo.func = function() AnnounceDestDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AnnounceDestDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.auraconf_target; 
	 auraiconinfo.value = "TARGET"; 
	 auraiconinfo.func = function() AnnounceDestDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AnnounceDestDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.auraconf_whisper; 
	 auraiconinfo.value = "WHISPER"; 
	 auraiconinfo.func = function() AnnounceDestDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AnnounceDestDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.auraconf_announcegroup; 
	 auraiconinfo.value = "GROUP"; 
	 auraiconinfo.func = function() AnnounceDestDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AnnounceDestDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.auraconf_raid; 
	 auraiconinfo.value = "RAID"; 
	 auraiconinfo.func = function() AnnounceDestDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AnnounceDestDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.auraconf_officer; 
	 auraiconinfo.value = "OFFICER"; 
	 auraiconinfo.func = function() AnnounceDestDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AnnounceDestDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
end

local function AnnounceTimeDropDownMenu_Initialise()
	 local level = 1 
	 
	 local auraiconinfo = UIDropDownMenu_CreateInfo();
	 
	 auraiconinfo.text = L.auraconf_soundtime; 
	 auraiconinfo.value = "TIME"; 
	 auraiconinfo.func = function() AnnounceTimeDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AnnounceTimeDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.auraconf_soundstacks; 
	 auraiconinfo.value = "STACKS"; 
	 auraiconinfo.func = function() AnnounceTimeDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AnnounceTimeDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.auraconf_soundgain; 
	 auraiconinfo.value = "GAIN"; 
	 auraiconinfo.func = function() AnnounceTimeDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AnnounceTimeDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.auraconf_soundexpire; 
	 auraiconinfo.value = "EXPIRE"; 
	 auraiconinfo.func = function() AnnounceTimeDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.AnnounceTimeDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
end

local function PlaySoundDropDownMenu_Initialise()
	 local level = 1 
	 
	 local auraiconinfo = UIDropDownMenu_CreateInfo();
	 
	 auraiconinfo.text = L.disabled; 
	 auraiconinfo.value = "OFF"; 
	 auraiconinfo.func = function() PlaySoundDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.PlaySoundDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
end

local function SoundWhenDropDownMenu_Initialise()
	 local level = 1 
	 
	 local auraiconinfo = UIDropDownMenu_CreateInfo();
	 
	 auraiconinfo.text = L.auraconf_soundtime; 
	 auraiconinfo.value = "TIME"; 
	 auraiconinfo.func = function() SoundWhenDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.SoundWhenDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.auraconf_soundstacks; 
	 auraiconinfo.value = "STACKS"; 
	 auraiconinfo.func = function() SoundWhenDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.SoundWhenDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.auraconf_soundgain; 
	 auraiconinfo.value = "GAIN"; 
	 auraiconinfo.func = function() SoundWhenDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.SoundWhenDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.auraconf_soundexpire; 
	 auraiconinfo.value = "EXPIRE"; 
	 auraiconinfo.func = function() SoundWhenDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = barconfs.SoundWhenDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
end

local function CDBarGroupDropDownMenu_Initialise()
	 local level = 1 
	 
	 local defbargroupinfo = UIDropDownMenu_CreateInfo();
	 
	for i = 1, #ThievesTools.ap.bargroups do
		 defbargroupinfo.text = ThievesTools.ap.bargroups[i].name; 
		 defbargroupinfo.value = i; 
		 defbargroupinfo.func = function() CDBarGroupDropDownMenuItem_OnClick() end;
		 defbargroupinfo.owner = barconfs.CDBarGroupDropDownMenu; 
		 defbargroupinfo.checked = nil; 
		 defbargroupinfo.icon = nil; 
		 UIDropDownMenu_AddButton(defbargroupinfo, level);
	end
end


local function BarGroupDropDownMenu_Initialise()
	 local level = 1 
	 
	 local configinfo = UIDropDownMenu_CreateInfo();
	 
	for i = 1, #ThievesTools.ap.bargroups do
		 configinfo.text = ThievesTools.ap.bargroups[i].name; 
		 configinfo.value = i; 
		 configinfo.func = function() BarGroupDropDownMenuItem_OnClick() end;
		 configinfo.owner = bargroups.BarGroupDropDownMenu; 
		 configinfo.checked = nil; 
		 configinfo.icon = nil; 
		 UIDropDownMenu_AddButton(configinfo, level);
	end
end

local function GroupSortDropDownMenu_Initialise()
	 local level = 1 
	 
	 local auraiconinfo = UIDropDownMenu_CreateInfo();
	 
	 auraiconinfo.text = L.bargroup_sortrank; 
	 auraiconinfo.value = "rank"; 
	 auraiconinfo.func = function() GroupSortDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = bargroups.GroupSortDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.bargroup_sorttime; 
	 auraiconinfo.value = "time"; 
	 auraiconinfo.func = function() GroupSortDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = bargroups.GroupSortDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	 auraiconinfo.text = L.bargroup_sortdest; 
	 auraiconinfo.value = "dest"; 
	 auraiconinfo.func = function() GroupSortDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = bargroups.GroupSortDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
	  auraiconinfo.text = L.bargroup_sortsource; 
	 auraiconinfo.value = "src"; 
	 auraiconinfo.func = function() GroupSortDropDownMenuItem_OnClick() end;
	 auraiconinfo.owner = bargroups.GroupSortDropDownMenu; 
	 auraiconinfo.checked = nil; 
	 auraiconinfo.icon = nil; 
	 UIDropDownMenu_AddButton(auraiconinfo, level);
	 
end

------ end of dropdown inits ------

function ThievesTools:InitBarConfigs()
	UIDropDownMenu_Initialize(barconfs.BarConfigDropDownMenu, BarConfigDropDownMenu_Initialise)
	local index = UIDropDownMenu_GetSelectedValue(barconfs.BarConfigDropDownMenu)
	local barconfig = ThievesTools.ap.barconfigs[index]
	BarConfigAuraButton_OnClick()
	
	--barconfig aura panel
	barconfs.BarNameEditBox:SetText(barconfig.barname)
	FixEditboxScroll(barconfs.BarNameEditBox)
	barconfs.BarEnabledCheck:SetChecked(barconfig.enabled)
	barconfs.AuraNameEditBox:SetText(barconfig.buffname)
	FixEditboxScroll(barconfs.AuraNameEditBox)
	barconfs.ShortNameEditBox:SetText(barconfig.shortname)
	FixEditboxScroll(barconfs.ShortNameEditBox)
	barconfs.AuraRankEditBox:SetText(barconfig.rank)
	FixEditboxScroll(barconfs.AuraRankEditBox)
	UIDropDownMenu_Initialize(barconfs.AuraTypeDropDownMenu, AuraTypeDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.AuraTypeDropDownMenu, barconfig.buff)
	UIDropDownMenu_Initialize(barconfs.AuraFromDropDownMenu, AuraFromDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.AuraFromDropDownMenu, barconfig.from);
	if barconfig.from == "named" then 
		barconfs.bcat8:SetVertexColor(1,1,1)
		barconfs.AuraFromNameEditBox:SetTextColor(1,1,1)
	else
		barconfs.bcat8:SetVertexColor(0.5,0.5,0.5)
		barconfs.AuraFromNameEditBox:SetTextColor(0.5,0.5,0.5)
	end
	barconfs.AuraFromNameEditBox:SetText(barconfig.fromname)
	FixEditboxScroll(barconfs.AuraFromNameEditBox)
	UIDropDownMenu_Initialize(barconfs.AuraToDropDownMenu, AuraToDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.AuraToDropDownMenu, barconfig.to);
	if barconfig.to == "named" then 
		barconfs.bcat9:SetVertexColor(1,1,1)
		barconfs.AuraToNameEditBox:SetTextColor(1,1,1)
	else
		barconfs.bcat9:SetVertexColor(0.5,0.5,0.5)
		barconfs.AuraToNameEditBox:SetTextColor(0.5,0.5,0.5)
	end
	barconfs.AuraToNameEditBox:SetText(barconfig.toname)
	FixEditboxScroll(barconfs.AuraToNameEditBox)
	barconfs.FullscanEnabledCheck:SetChecked(barconfig.fullscan)
	barconfs.FixedDurCheck:SetChecked(barconfig.fixeddur)
	barconfs.ChargesCheck:SetChecked(barconfig.updatecharges)
	barconfs.MissingCheck:SetChecked(barconfig.checkmissing)
	barconfs.SuppressCheck:SetChecked(barconfig.suppress)
	
	--barconfig bar panel
	barconfs.bartexture:SetVertexColor(barconfig.color_r, barconfig.color_g, barconfig.color_b, barconfig.bar_alpha)
	barconfs.bartexture:SetTexture(ThievesTools.ap.baroptions.bartexture)
	barconfs.BarWidthEditBox:SetText(barconfig.width)
	FixEditboxScroll(barconfs.BarWidthEditBox)
	barconfs.BarHeightEditBox:SetText(barconfig.height)
	FixEditboxScroll(barconfs.BarHeightEditBox)
	barconfs.FrameAlphaSlider:SetValue(barconfig.alpha)
	barconfs.FrameAlphaEditBox:SetText(ThievesTools.ap.barconfigs[index].alpha)
	FixEditboxScroll(barconfs.FrameAlphaEditBox)
	barconfs.BarAlphaSlider:SetValue(barconfig.bar_alpha)
	barconfs.BarAlphaEditBox:SetText(ThievesTools.ap.barconfigs[index].bar_alpha)
	FixEditboxScroll(barconfs.BarAlphaEditBox)
	barconfs.BgAlphaSlider:SetValue(barconfig.bg_alpha)
	barconfs.BgAlphaEditBox:SetText(ThievesTools.ap.barconfigs[index].bg_alpha)
	FixEditboxScroll(barconfs.BgAlphaEditBox)
	barconfs.BarSparkCheck:SetChecked(barconfig.showspark)
	barconfs.BarPeriodSparkCheck:SetChecked(barconfig.periodspark)
	barconfs.PinBarGroupCheck:SetChecked(barconfig.bargrouppin)
	barconfs.PinOwnBarGroupCheck:SetChecked(barconfig.selfbuffpin)
	UIDropDownMenu_Initialize(barconfs.DefBarGroupDropDownMenu, DefBarGroupDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.DefBarGroupDropDownMenu, barconfig.bargroup)
	UIDropDownMenu_Initialize(barconfs.BuffTextDropDownMenu, BuffTextDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.BuffTextDropDownMenu, barconfig.textbuffpos)
	UIDropDownMenu_Initialize(barconfs.StackTextDropDownMenu, StackTextDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.StackTextDropDownMenu, barconfig.textstackpos)
	UIDropDownMenu_Initialize(barconfs.TimeTextDropDownMenu, TimeTextDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.TimeTextDropDownMenu, barconfig.textdurationpos)
	barconfs.FontSizeEditBox:SetText(ThievesTools.ap.barconfigs[index].fontsize)
	barconfs.FontColorFrame:SetBackdropColor(barconfig.font_r, barconfig.font_g, barconfig.font_b, barconfig.alpha)
	barconfs.FontDropCheck:SetChecked(barconfig.fontdrop)
	barconfs.FontOutCheck:SetChecked(barconfig.fontoutline)
	
	--barconfig bar+ panel
	UIDropDownMenu_Initialize(barconfs.AuraIconDropDownMenu, AuraIconDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.AuraIconDropDownMenu, barconfig.showicon)
	UIDropDownMenu_Initialize(barconfs.RaidIconDropDownMenu, RaidIconDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.RaidIconDropDownMenu, barconfig.showraidicon)
	barconfs.AuraIconOnlyCheck:SetChecked(barconfig.showicononly)
	barconfs.HideAuraTextCheck:SetChecked(barconfig.textbuffhide)
	barconfs.FlashLowCheck:SetChecked(barconfig.flashlow)
	barconfs.FlashLowEditBox:SetText(ThievesTools.ap.barconfigs[index].flashlowtime)
	FixEditboxScroll(barconfs.FlashLowEditBox)
	barconfs.AppendSourceCheck:SetChecked(barconfig.appendsource)
	barconfs.FixedSizeCheck:SetChecked(barconfig.fixedsize)
	barconfs.FixedSizeEditBox:SetText(ThievesTools.ap.barconfigs[index].fixedsizevalue)
	FixEditboxScroll(barconfs.FixedSizeEditBox)
	barconfs.SecondBarCheck:SetChecked(barconfig.secondbar)
	barconfs.Bar2AlphaSlider:SetValue(barconfig.bar2_alpha)
	barconfs.Bar2AlphaEditBox:SetText(ThievesTools.ap.barconfigs[index].bar2_alpha)
	FixEditboxScroll(barconfs.Bar2AlphaEditBox)
	barconfs.bar2texture:SetVertexColor(barconfig.color1_r, barconfig.color1_g, barconfig.color1_b, barconfig.bar2_alpha)
	barconfs.bar2texture:SetTexture(ThievesTools.ap.baroptions.bartexture)
	barconfs.BaseComboEditBox:SetText(ThievesTools.ap.barconfigs[index].combo_base)
	FixEditboxScroll(barconfs.BaseComboEditBox)
	barconfs.PerComboEditBox:SetText(ThievesTools.ap.barconfigs[index].combo_per)
	FixEditboxScroll(barconfs.PerComboEditBox)
	barconfs.MultiComboEditBox:SetText(ThievesTools.ap.barconfigs[index].combo_multi)
	FixEditboxScroll(barconfs.MultiComboEditBox)
	
	--barconfig extras panel
	UIDropDownMenu_Initialize(barconfs.AnnounceDestDropDownMenu, AnnounceDestDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.AnnounceDestDropDownMenu, barconfig.announcetype)
	UIDropDownMenu_Initialize(barconfs.AnnounceTimeDropDownMenu, AnnounceTimeDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.AnnounceTimeDropDownMenu, barconfig.announcecriteria)
	barconfs.AnnounceChanEditBox:SetText(ThievesTools.ap.barconfigs[index].announcedest)
	barconfs.AnnounceTimeEditBox:SetText(ThievesTools.ap.barconfigs[index].announcetimeleft)
	FixEditboxScroll(barconfs.AnnounceChanEditBox)
	barconfs.AnnounceNonSelfCheck:SetChecked(barconfig.announcenonself)
	barconfs.AnnounceEveryCheck:SetChecked(barconfig.announceeverysec)
	barconfs.AnnounceExpire:SetChecked(barconfig.announceexp)
	UIDropDownMenu_Initialize(barconfs.PlaySoundDropDownMenu, PlaySoundDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.PlaySoundDropDownMenu, barconfig.sound)
	UIDropDownMenu_Initialize(barconfs.SoundWhenDropDownMenu, SoundWhenDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.SoundWhenDropDownMenu, barconfig.soundtype)
	if barconfig.soundtype == "TIME" then
		barconfs.bcet15:SetText(L.auraconf_soundtimeleft)
	else
		barconfs.bcet15:SetText(L.auraconf_soundstacksup)
	end
	barconfs.SoundTimeEditBox:SetText(ThievesTools.ap.barconfigs[index].soundvalue)
	FixEditboxScroll(barconfs.SoundTimeEditBox)
	barconfs.SoundEverySecondCheck:SetChecked(barconfig.soundeverysec)
	barconfs.CooldownCheck:SetChecked(barconfig.icdbar)
	UIDropDownMenu_Initialize(barconfs.CDBarGroupDropDownMenu, CDBarGroupDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.CDBarGroupDropDownMenu, barconfig.icdbargroup)
	barconfs.CooldownEditBox:SetText(ThievesTools.ap.barconfigs[index].icdlength)
	FixEditboxScroll(barconfs.CooldownEditBox)
end

function ThievesTools:InitBarGroups()
	UIDropDownMenu_Initialize(bargroups.BarGroupDropDownMenu, BarGroupDropDownMenu_Initialise)
	local index = UIDropDownMenu_GetSelectedValue(bargroups.BarGroupDropDownMenu)
	local bargroup = ThievesTools.ap.bargroups[index]
	bargroups.GroupNameEditBox:SetText(bargroup.name)
	FixEditboxScroll(bargroups.GroupNameEditBox)
	UIDropDownMenu_Initialize(bargroups.GroupSortDropDownMenu, GroupSortDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(bargroups.GroupSortDropDownMenu, bargroup.sortby)
end


function ThievesTools:InitOptions()
	--mainopts panel
	UIDropDownMenu_Initialize(mainoptions.ProfileDropDownMenu, ProfileDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(mainoptions.ProfileDropDownMenu, TT_ap);
	mainoptions.ProfileDeleteButton:SetScript("OnClick",ProfileDeleteButton_OnClick)
	mainoptions.ProfileEditBox:SetText(L.mainopt_copystring..UIDropDownMenu_GetText(mainoptions.ProfileDropDownMenu))
	FixEditboxScroll(mainoptions.ProfileEditBox)
	mainoptions.ProfileCreateButton:SetScript("OnClick",ProfileCreateButton_OnClick)
	mainoptions.MoveFramesButton:SetScript("OnClick",MoveFramesButton_OnClick)
	--barconfig aura panel
	UIDropDownMenu_Initialize(barconfs.BarConfigDropDownMenu, BarConfigDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(barconfs.BarConfigDropDownMenu, 1);
	barconfs.BarConfigAuraButton:SetScript("OnClick",BarConfigAuraButton_OnClick)
	barconfs.BarConfigBarButton:SetScript("OnClick",BarConfigBarButton_OnClick)
	barconfs.BarConfigBar2Button:SetScript("OnClick",BarConfigBar2Button_OnClick)
	barconfs.BarConfigExtrasButton:SetScript("OnClick",BarConfigExtrasButton_OnClick)
	UIDropDownMenu_Initialize(barconfs.AuraTypeDropDownMenu, AuraTypeDropDownMenu_Initialise)
	UIDropDownMenu_Initialize(barconfs.AuraFromDropDownMenu, AuraFromDropDownMenu_Initialise)
	UIDropDownMenu_Initialize(barconfs.AuraToDropDownMenu, AuraToDropDownMenu_Initialise)
	barconfs.BarConfigDeleteButton:SetScript("OnClick",BarConfigDeleteButton_OnClick)
	barconfs.BarConfigNewButton:SetScript("OnClick",BarConfigNewButton_OnClick)
	barconfs.BarConfigCloneButton:SetScript("OnClick",BarConfigCloneButton_OnClick)
	barconfs.BarNameEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.BarNameEditBox:SetScript("OnEnterPressed",  function(self) FixEditboxScroll(self) end )
	barconfs.BarNameEditBox:SetScript("OnTextChanged", BarNameEditBox_OnTextChange )
	barconfs.BarEnabledCheck:SetScript("OnClick", function(self) BarEnabledCheck_MouseUp(self) end);
	barconfs.AuraNameEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.AuraNameEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.AuraNameEditBox:SetScript("OnTextChanged",  AuraNameEditBox_OnTextChange)
	barconfs.ShortNameEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.ShortNameEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
    barconfs.ShortNameEditBox:SetScript("OnTextChanged", ShortNameEditBox_OnTextChange )
	barconfs.AuraRankEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.AuraRankEditBox:SetScript("OnEnterPressed", function(self) AuraRankEditBox_OnEnterPressed() FixEditboxScroll(self) end )
	barconfs.AuraFromNameEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.AuraFromNameEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.AuraFromNameEditBox:SetScript("OnTextChanged", AuraFromNameEditBox_OnTextChange )
	barconfs.AuraToNameEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.AuraToNameEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.AuraToNameEditBox:SetScript("OnTextChanged", AuraToNameEditBox_OnTextChange )
	barconfs.FullscanEnabledCheck:SetScript("OnClick", function(self) FullscanEnabledCheck_MouseUp(self) end);
	barconfs.FixedDurCheck:SetScript("OnClick", function(self) FixedDurCheck_MouseUp(self) end);
	barconfs.ChargesCheck:SetScript("OnClick", function(self) ChargesCheck_MouseUp(self) end);
	barconfs.MissingCheck:SetScript("OnClick", function(self) MissingCheck_MouseUp(self) end);
	barconfs.SuppressCheck:SetScript("OnClick", function(self) SuppressCheck_MouseUp(self) end);
	ThievesTools:InitOptions2()
end

function ThievesTools:InitOptions2()
	--barconfig bar panel
	barconfs.BarColorFrame:SetScript("OnMouseUp",BarColorFrame_OnClick)
	barconfs.BarWidthEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.BarWidthEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.BarWidthEditBox:SetScript("OnTextChanged", BarWidthEditBox_OnTextChange )
	barconfs.BarHeightEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end)
	barconfs.BarHeightEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end)
	barconfs.BarHeightEditBox:SetScript("OnTextChanged", BarHeightEditBox_OnTextChange )
	barconfs.FrameAlphaSlider:SetScript("OnValueChanged", FrameAlphaSlider_OnChange)
	barconfs.FrameAlphaEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.FrameAlphaEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.FrameAlphaEditBox:SetScript("OnTextChanged", FrameAlphaEditBox_OnTextChange )
	barconfs.BarAlphaSlider:SetScript("OnValueChanged", BarAlphaSlider_OnChange)
	barconfs.BarAlphaEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.BarAlphaEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.BarAlphaEditBox:SetScript("OnTextChanged", BarAlphaEditBox_OnTextChange )
	barconfs.BgAlphaSlider:SetScript("OnValueChanged", BgAlphaSlider_OnChange)
	barconfs.BgAlphaEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.BgAlphaEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.BgAlphaEditBox:SetScript("OnTextChanged", BgAlphaEditBox_OnTextChange)
	barconfs.BarSparkCheck:SetScript("OnClick", function(self) BarSparkCheck_MouseUp(self) end);
	barconfs.BarPeriodSparkCheck:SetScript("OnClick", function(self) BarPeriodSparkCheck_MouseUp(self) end);
	barconfs.PinBarGroupCheck:SetScript("OnClick", function(self) PinBarGroupCheck_MouseUp(self) end);
	barconfs.PinOwnBarGroupCheck:SetScript("OnClick", function(self) PinOwnBarGroupCheck_MouseUp(self) end);
	UIDropDownMenu_Initialize(barconfs.DefBarGroupDropDownMenu, DefBarGroupDropDownMenu_Initialise)
	UIDropDownMenu_Initialize(barconfs.BuffTextDropDownMenu, BuffTextDropDownMenu_Initialise)
	UIDropDownMenu_Initialize(barconfs.StackTextDropDownMenu, StackTextDropDownMenu_Initialise)
	UIDropDownMenu_Initialize(barconfs.TimeTextDropDownMenu, TimeTextDropDownMenu_Initialise)
	barconfs.FontSizeEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.FontSizeEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.FontSizeEditBox:SetScript("OnTextChanged", FontSizeEditBox_OnTextChange)
	barconfs.FontColorFrame:SetScript("OnMouseUp",FontColorFrame_OnClick)
	barconfs.FontDropCheck:SetScript("OnClick", function(self) FontDropCheck_MouseUp(self) end);
	barconfs.FontOutCheck:SetScript("OnClick", function(self) FontOutCheck_MouseUp(self) end);
	
	ThievesTools:InitOptions3()
end
	
function ThievesTools:InitOptions3()
	--barconfig bar+ panel
	UIDropDownMenu_Initialize(barconfs.AuraIconDropDownMenu, AuraIconDropDownMenu_Initialise)
	UIDropDownMenu_Initialize(barconfs.RaidIconDropDownMenu, RaidIconDropDownMenu_Initialise)
	barconfs.AuraIconOnlyCheck:SetScript("OnClick", function(self) AuraIconOnlyCheck_MouseUp(self) end);
	barconfs.HideAuraTextCheck:SetScript("OnClick", function(self) HideAuraTextCheck_MouseUp(self) end);
	barconfs.FlashLowCheck:SetScript("OnClick", function(self) FlashLowCheck_MouseUp(self) end);
	barconfs.FlashLowEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.FlashLowEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.FlashLowEditBox:SetScript("OnTextChanged", FlashLowEditBox_OnTextChange )
	barconfs.AppendSourceCheck:SetScript("OnClick", function(self) AppendSourceCheck_MouseUp(self) end);
	barconfs.FixedSizeCheck:SetScript("OnClick", function(self) FixedSizeCheck_MouseUp(self) end);
	barconfs.FixedSizeEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.FixedSizeEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.FixedSizeEditBox:SetScript("OnTextChanged", FixedSizeEditBox_OnTextChange )
	barconfs.SecondBarCheck:SetScript("OnClick", function(self) SecondBarCheck_MouseUp(self) end);
	barconfs.Bar2AlphaSlider:SetScript("OnValueChanged", Bar2AlphaSlider_OnChange)
	barconfs.Bar2AlphaEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.Bar2AlphaEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.Bar2AlphaEditBox:SetScript("OnTextChanged", Bar2AlphaEditBox_OnTextChange )
	barconfs.Bar2ColorFrame:SetScript("OnMouseUp",Bar2ColorFrame_OnClick)
	barconfs.BaseComboEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.BaseComboEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.BaseComboEditBox:SetScript("OnTextChanged", BaseComboEditBox_OnTextChange )
	barconfs.PerComboEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.PerComboEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.PerComboEditBox:SetScript("OnTextChanged", PerComboEditBox_OnTextChange )
	barconfs.MultiComboEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.MultiComboEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.MultiComboEditBox:SetScript("OnTextChanged", MultiComboEditBox_OnTextChange )
	
	ThievesTools:InitOptions4()
end
	
function ThievesTools:InitOptions4()
	--barconfig extras panel
	UIDropDownMenu_Initialize(barconfs.AnnounceDestDropDownMenu, AnnounceDestDropDownMenu_Initialise)
	UIDropDownMenu_Initialize(barconfs.AnnounceTimeDropDownMenu, AnnounceTimeDropDownMenu_Initialise)
	barconfs.AnnounceChanEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.AnnounceChanEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.AnnounceChanEditBox:SetScript("OnTextChanged", AnnounceChanEditBox_OnTextChange )
	barconfs.AnnounceTimeEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.AnnounceTimeEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.AnnounceTimeEditBox:SetScript("OnTextChanged", AnnounceTimeEditBox_OnTextChange )
	barconfs.AnnounceNonSelfCheck:SetScript("OnClick", function(self) AnnounceNonSelfCheck_MouseUp(self) end);
	barconfs.AnnounceEveryCheck:SetScript("OnClick", function(self) AnnounceEveryCheck_MouseUp(self) end);
	barconfs.AnnounceExpire:SetScript("OnClick", function(self) AnnounceExpire_MouseUp(self) end);
	UIDropDownMenu_Initialize(barconfs.PlaySoundDropDownMenu, PlaySoundDropDownMenu_Initialise)
	UIDropDownMenu_Initialize(barconfs.SoundWhenDropDownMenu, SoundWhenDropDownMenu_Initialise)
	barconfs.SoundTimeEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.SoundTimeEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.SoundTimeEditBox:SetScript("OnTextChanged", SoundTimeEditBox_OnTextChange )
	barconfs.SoundEverySecondCheck:SetScript("OnClick", function(self) SoundEverySecondCheck_MouseUp(self) end);
	barconfs.CooldownCheck:SetScript("OnClick", function(self) CooldownCheck_MouseUp(self) end);
	UIDropDownMenu_Initialize(barconfs.CDBarGroupDropDownMenu, CDBarGroupDropDownMenu_Initialise);
	barconfs.CooldownEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	barconfs.CooldownEditBox:SetScript("OnEnterPressed", function(self) FixEditboxScroll(self) end )
	barconfs.CooldownEditBox:SetScript("OnTextChanged", CooldownEditBox_OnTextChange )
	ThievesTools:InitOptions5()
end

function ThievesTools:InitOptions5()
	-- bar groups panel
	UIDropDownMenu_Initialize(bargroups.BarGroupDropDownMenu, BarGroupDropDownMenu_Initialise)
	UIDropDownMenu_SetSelectedValue(bargroups.BarGroupDropDownMenu, 1);
	bargroups.BarGroupDeleteButton:SetScript("OnClick",BarGroupDeleteButton_OnClick)
	bargroups.BarGroupNewButton:SetScript("OnClick",BarGroupNewButton_OnClick)
	bargroups.GroupNameEditBox:SetScript("OnEscapePressed", function(self) FixEditboxScroll(self) end )
	bargroups.GroupNameEditBox:SetScript("OnEnterPressed",  function(self) FixEditboxScroll(self) end )
	bargroups.GroupNameEditBox:SetScript("OnTextChanged", GroupNameEditBox_OnTextChange )
	UIDropDownMenu_Initialize(bargroups.GroupSortDropDownMenu, GroupSortDropDownMenu_Initialise)
	ThievesTools:InitOptions6()
end


function ThievesTools:InitOptions6()
	--cpoptions panel
	cpopts.ComboOptsComboButton:SetScript("OnClick",ComboOptsComboButton_OnClick)
	cpopts.ComboOptsEnergyButton:SetScript("OnClick",ComboOptsEnergyButton_OnClick)
	ComboOptsComboButton_OnClick()
	
	ThievesTools:InitBarConfigs()
	ThievesTools:InitBarGroups()
end



