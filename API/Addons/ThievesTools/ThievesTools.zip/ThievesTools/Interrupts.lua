local L = TT_locale;
local modName = "ThievesTools";
local _ 
local _G = getfenv(0);
local select = _G.select;
local wipe = _G.wipe;
local t_sort = _G.table.sort;
local t_insert = _G.table.insert;
local tonum = _G.tonumber;
local tostr = _G.tostring
local strbyte = _G.string.byte
local strsub = _G.string.sub
local pairs	= _G.pairs

local ThievesTools;
if not ThievesTools then ThievesTools = _G.ThievesTools end;
if not ThievesTools.interrupts then ThievesTools.interrupts = {} end;

function ThievesTools:GetInterrupts()
	

end

function ThievesTools:AddInterrupt()
		local i = 200
		
end
