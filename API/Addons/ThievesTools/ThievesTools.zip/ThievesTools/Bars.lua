﻿local L = TT_locale;
local modName = "ThievesTools";
local _ 
local _G = getfenv(0);
local select = _G.select;
local wipe = _G.wipe;
local t_sort = _G.table.sort;
local t_insert = _G.table.insert;
local tonum = _G.tonumber;
local tostr = _G.tostring
local strbyte = _G.string.byte
local strsub = _G.string.sub
local pairs	= _G.pairs

local ThievesTools;
if not ThievesTools then ThievesTools = _G.ThievesTools end;

if not ThievesTools.buffbars then ThievesTools.buffbars = {} end;
if not ThievesTools.buffbargroups then ThievesTools.buffbargroups = {} end;




--testcode
--for i = 1,50 do
	--ThievesTools.buffbars[i] = {}
--end
--end testcode

function ThievesTools:CreateBuffBar(barconfigindex, shortname, timestamp, eventType, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags, spellId, spellName, spellSchool, auraType, count)

	--AzMsg(self.thetime)
	
	local i = 1
	-- raise the counter till we're on an empty bar index
	while self.buffbars[i] do
		if self.buffbars[i].destGUID then
			i = i + 1
		else
			break
		end
	end
	
	--kill any missing aura bar for this config 08/05/10
	for j = 0, #self.buffbars do
		if self.buffbars[j] and self.buffbars[j].destGUID and self.buffbars[j].missing and (self.buffbars[j].config == barconfigindex) then
		self.buffbars[j].fadedestroy = true
			self.buffbars[j].fading = "OUT"
			self.buffbars[j].fadestart = self.thetime
			self.buffbars[j].active = false		
		end
	end

	-- create a new bar at that index
	--AzMsg("Creating buffbar "..i)
	if not self.buffbars[i] then self.buffbars[i] = {} end;
	self.activebuffbars = self.activebuffbars + 1
	
	
	local buffbar = self.buffbars[i]
	buffbar.config = barconfigindex;
	buffbar.shortname = shortname
	buffbar.active = true --added this so we can set bars fading to destroy as non-active, prevents auras applied same time they were removed using the fade-to-destroy bar
	buffbar.barframe = 0;
	buffbar.barinit = false; -- do we need to load the barconfig to the barframe, true = already done for this bar
	buffbar.lastupdate = 0;
	buffbar.bargroup = self.ap.barconfigs[barconfigindex].bargroup; -- the default bargroup
	buffbar.curbargroup = self.ap.barconfigs[barconfigindex].bargroup; -- used to store the currently assigned bargroup
	buffbar.destbargroup = self.ap.barconfigs[barconfigindex].bargroup; -- used to store the destination bargroup
	buffbar.timeleft = 1
	buffbar.duration = self.ap.barconfigs[barconfigindex].fixeddurlength
	buffbar.lastdurtry = self.thetime -- last time we tried for a duration with self:GetAuraDurExp(buffbar, buffbar.spellname)
	buffbar.durstring = ""
	buffbar.curdurstring = " " --string to hold equivalent of GetText for duration
	
	buffbar.fixeddur = self.ap.barconfigs[barconfigindex].fixeddur
	buffbar.stacks = 1
	buffbar.curstacks = 1
	buffbar.stackstring = ""
	buffbar.expirationTime = 0
	buffbar.timestart = self.thetime
	buffbar.event = eventType
	buffbar.sourceGUID = srcGUID
	buffbar.sourcename = srcName
	buffbar.destGUID = dstGUID
	buffbar.destname = dstName
	buffbar.spellID = spellId
	buffbar.spellname = spellName
	buffbar.auratype = auraType
	buffbar.announce = self.ap.barconfigs[barconfigindex].announcetype
	buffbar.announcecrit = self.ap.barconfigs[barconfigindex].announcecriteria
	buffbar.announceexp = self.ap.barconfigs[barconfigindex].announceexp
	buffbar.lastannounce = 0
	buffbar.lastchargecheck = 0
	buffbar.lastraidiconcheck = 0
	buffbar.justsub1 = false
	buffbar.bsort = false
	--auratype fix for periodic event bar creation
	if (buffbar.auratype ~= "BUFF") and (buffbar.auratype ~= "DEBUFF") then buffbar.auratype = self.ap.barconfigs[buffbar.config].buff end;
	
	--missing aura support 08/05/10
	if eventType == "TT_MISSING" then
		buffbar.durstring = "!"
		if self.ap.barconfigs[barconfigindex].icon then buffbar.icon = self.ap.barconfigs[barconfigindex].icon end
		buffbar.missing = true
	else
		buffbar.missing = false
		buffbar.icon = nil
	end
	
	--supression support 10/05/10
	buffbar.suppress = self.ap.barconfigs[barconfigindex].suppress
	
	buffbar.firsttick = self.thetime
	buffbar.lasttick = self.thetime
	buffbar.maxsize = 0
	buffbar.fading = "IN" --default the bar to fading in upon creation
	buffbar.fadestart = self.thetime --default the fadestart time to bar creation, new bars fade in right?!
	buffbar.fadedestroy = false -- this gets set to true if we want to destroy the buffbar at 0 alpha
	buffbar.targetalpha = self.ap.barconfigs[barconfigindex].alpha --alpha to fade to, defaults to the barconfig value, may change upon bargroup assignment
	
	
	buffbar.name = buffbar.spellname
	if not buffbar.missing then 
		buffbar.name,_,buffbar.icon = GetSpellInfo(buffbar.spellID) 
		self.ap.barconfigs[barconfigindex].icon = buffbar.icon
	end
	buffbar.buffstring = buffbar.name
	buffbar.curbuffstring = " " --string to hold GetText equivalent for buff text
	-- 
	buffbar.rank = self.ap.barconfigs[buffbar.config].rank
	if srcName then buffbar.sortsrcname = tonum(tostr(strbyte(srcName, 1))..tostr(strbyte(srcName, 2))..tostr(strbyte(srcName, 3))) end
	if dstName then buffbar.sortdstname = tonum(tostr(strbyte(dstName, 1))..tostr(strbyte(dstName, 2))..tostr(strbyte(dstName, 3))) end
	buffbar.sortsrcGUID = tonum(strsub(tostr(srcGUID), -7), 16)
	buffbar.sortdstGUID = tonum(strsub(tostr(dstGUID), -7), 16)
	--AzMsg(buffbar.sortdstname)
	--AzMsg(buffbar.sortdstGUID)
	
	--fix for fixeddur bars being created on periodic damage/heal ticks at full duration, incorrectly
	if (eventType == "SPELL_PERIODIC_DAMAGE") or (eventType == "SPELL_PERIODIC_HEAL") or (eventType == "SPELL_PERIODIC_ENERGIZE") or (eventType == "TT_TARGET_CHANGE") then
		buffbar.duration = 0
	end
	
	--lets try to get a duration now, else queue the buffbar for a duration when next possible to detect
	
	--hacked ICD tracking 12/10/09
	if buffbar.destGUID == "0x123" then
		buffbar.duration = self.ap.barconfigs[barconfigindex].icdlength
		buffbar.bargroup = self.ap.barconfigs[barconfigindex].icdbargroup
		buffbar.curbargroup = self.ap.barconfigs[barconfigindex].icdbargroup
		buffbar.destbargroup = self.ap.barconfigs[barconfigindex].icdbargroup
		buffbar.name = buffbar.spellname .. " CD"
	else
		if buffbar.duration == 0 then self:GetAuraDurExp(buffbar, buffbar.spellname) end
	end
	
	
	-- local pointer to the barconfig for this aura
	local barconfig = self.ap.barconfigs[barconfigindex]
	-- local pointer to the visible bar frames for this aura, init to nil, we have to find/create an unowned one below
	local bar = nil
	
	--- barframe ownership and creation ----
	if buffbar.barframe == 0 then -- check if a statusbar barframe has been assigned yet
		
		--count through existing bars for an unowned one
		local j = 1
		while ThievesTools.frames.bars[j] do  
			--AzMsg("counting through bar " ..j)
			if self.frames.bars[j].owner == 0 then -- if we find an unowned one, take it
				self.frames.bars[j].owner = i; -- set bar frame owner to this buffbar
				buffbar.barframe = j; -- assign bar to this buffbar
				break
			else
			end
			j = j + 1
		end
		
		--if we couldn't find a bar to take ownership of, create a new one
		if buffbar.barframe == 0 then 
			j = 1
			local resultbar = 0
			while ThievesTools.frames.bars[j] do --set j to one more than existing bar frames
				j = j + 1
			end
			resultbar = self:CreateStatusBar(j, i); -- create the new bar
			--AzMsg("creating bar :"..j);
			if resultbar > 0 then  -- if the new bar was made successfully, assign to the buffbar
			--AzMsg("assigned resultbar :"..resultbar);
			buffbar.barframe = resultbar
			else
				--AzMsg("WUT! NO BAR?!") -- if we couldn't find an unowned, or create a new bar, spam chat panel
			end
		end
	end
	
	if buffbar.barframe > 0 then --now we should have a bar, so lets make a local shortcut to save typing out a lot
		bar = self.frames.bars[buffbar.barframe]
		--AzMsg(buffbar.barframe)
		--AzMsg(bar)
	end
	
	if buffbar.barinit == false then -- bar isn't initialised yet, lets load the barconfig into the barframe object's frames
		--frame first
		bar.framebar:SetWidth(barconfig.width);
		bar.framebar:SetHeight(barconfig.height + 1);
		bar.framebar:SetBackdropColor(0,0,0,barconfig.bg_alpha);
		bar.framebar:SetAlpha(barconfig.alpha);
		bar.framebar:SetAlpha(0);
		if buffbar.suppress and not buffbar.missing then
			bar.framebar:Hide();
		else
			bar.framebar:Show();
		end
		
		--statusbar
		bar.statusbar:SetWidth(barconfig.width - 4);
		bar.statusbar:SetHeight(barconfig.height - 2);
		bar.statusbar:SetStatusBarTexture(self.ap.baroptions.bartexture);
		bar.statusbar:SetStatusBarColor(barconfig.color_r, barconfig.color_g, barconfig.color_b, barconfig.bar_alpha);
		bar.statusbar:SetAlpha(barconfig.bar_alpha)
		bar.statusbar:Show();
		
		--set the statusbar min max from the barconfig
		buffbar.maxsize = (barconfig.combo_multi * (barconfig.combo_base + (5 * barconfig.combo_per)))
		if (barconfig.fixedsize == true) and buffbar.duration > 0 then
			bar.statusbar:SetMinMaxValues(0, buffbar.maxsize)
		else
			if buffbar.duration > 0 then
				bar.statusbar:SetMinMaxValues(0, buffbar.duration)
			else
				bar.statusbar:SetMinMaxValues(0, 1)
			end
		end
		
		if barconfig.secondbar == true then
			bar.statusbar1:SetWidth(barconfig.width - 4);
			bar.statusbar1:SetHeight(barconfig.height -2);
			bar.statusbar1:SetStatusBarTexture(self.ap.baroptions.bartexture);
			bar.statusbar1:SetStatusBarColor(barconfig.color1_r, barconfig.color1_g, barconfig.color1_b, barconfig.bar2_alpha) --barconfig.bar2_alpha
			bar.statusbar1:Show();
			bar.statusbar1:SetMinMaxValues(0, buffbar.maxsize);
		else
			bar.statusbar1:Hide();
		end
		
		
		--text config
		local fontflags = ""
		if barconfig.fontoutline == true then fontflags = "OUTLINE" end;
		
		if barconfig.fontdrop == true then
			bar.text:SetShadowColor(0,0,0)
			bar.text:SetShadowOffset(1, -1)
			bar.text1:SetShadowColor(0,0,0)
			bar.text1:SetShadowOffset(1, -1)
			bar.text2:SetShadowColor(0,0,0)
			bar.text2:SetShadowOffset(1, -1)
		end
		
		-- buff text
		bar.text:SetFont(barconfig.font, barconfig.fontsize, fontflags);
		bar.text:SetVertexColor(barconfig.font_r, barconfig.font_g, barconfig.font_b);
		bar.text:SetJustifyV(barconfig.textvertalign);
		bar.text:SetJustifyH(barconfig.textbuffpos);
		if (buffbar.destGUID == self.playerGUID) or (buffbar.destGUID == self.targetGUID) then
			bar.text:SetText(buffbar.buffstring)
		else
			bar.text:SetText(buffbar.shortname.." - "..buffbar.destname)
		end
		bar.text:Show();
		
		
		
		

		-- stack text
		bar.text1:SetFont(barconfig.font, barconfig.fontsize, fontflags);
		bar.text1:SetVertexColor(barconfig.font_r, barconfig.font_g, barconfig.font_b);
		bar.text1:SetJustifyV(barconfig.textvertalign);
		bar.text1:SetJustifyH(barconfig.textstackpos);
		if (barconfig.textstackpos == barconfig.textbuffpos) then
			bar.text1:SetText("");
		else
			bar.text1:SetText(buffbar.stackstring);
		end
		bar.text1:Show();
	
		-- duration text
		bar.text2:SetFont(barconfig.font, barconfig.fontsize, fontflags);
		bar.text2:SetVertexColor(barconfig.font_r, barconfig.font_g, barconfig.font_b);
		bar.text2:SetJustifyV(barconfig.textvertalign);
		bar.text2:SetJustifyH(barconfig.textdurationpos);
		if (barconfig.textdurationpos == barconfig.textstackpos) then
			bar.text2:SetText("");
		else
			bar.text2:SetText(buffbar.durstring);
		end
		bar.text2:Show();
		
		
		
		--spark config
		if barconfig.showspark == true then
			bar.spark:SetHeight(barconfig.height*2)
			bar.spark:SetWidth(barconfig.height*1.5)
			bar.spark:Show();
		else
			bar.spark:Hide();
		end
		if ((barconfig.showspark == true) and (barconfig.secondbar == true)) or (barconfig.periodspark ~= false) then
			bar.spark1:SetHeight(barconfig.height*3)
			bar.spark1:SetWidth(barconfig.height*1.5)
			bar.spark1:Show();
		else
			bar.spark1:Hide();
		end
		
		--icon config
		if (barconfig.showicon ~= "OFF") then
			bar.icon:SetWidth(barconfig.height -2); --2 px borders
			bar.icon:SetHeight(barconfig.height -2);
			if buffbar.icon then
				bar.icon:SetTexture(buffbar.icon);
				bar.icon:Show();
				if (barconfig.showicon == "LEFT") then
					bar.icon:ClearAllPoints()
					bar.icon:SetPoint("RIGHT", bar.framebar, "LEFT", -2, 0)
					bar.icon:SetPoint("CENTER", bar.framebar, "CENTER", -2, 0)
				elseif (barconfig.showicon == "RIGHT") then
					bar.icon:ClearAllPoints()
					bar.icon:SetPoint("LEFT", bar.framebar, "RIGHT", 2, 0)
					bar.icon:SetPoint("CENTER", bar.framebar, "CENTER", 2, 0)
				end
			end
		else
			bar.icon:Hide();
		end
		
		--raidicon config
		if (buffbar.showraidicon ~= "OFF") then
			bar.raidicon:SetWidth(barconfig.height -2); --2 px borders
			bar.raidicon:SetHeight(barconfig.height -2);
			bar.raidicon:Hide();
			if (barconfig.showraidicon == "LEFT") then
				if (barconfig.showicon == "LEFT") then
					bar.raidicon:ClearAllPoints()
					bar.raidicon:SetPoint("RIGHT", bar.icon, "LEFT", -2, 0)
					bar.raidicon:SetPoint("CENTER", bar.icon, "CENTER", 0, 0)
				elseif (barconfig.showicon == "RIGHT") or (barconfig.showicon == "OFF") then
					bar.raidicon:ClearAllPoints()
					bar.raidicon:SetPoint("RIGHT", bar.framebar, "LEFT", -2, 0)
					bar.raidicon:SetPoint("CENTER", bar.framebar, "CENTER", -2, 0)
				end
			elseif (barconfig.showraidicon == "RIGHT") then
				if (barconfig.showicon == "LEFT") or (barconfig.showicon == "OFF") then
					bar.raidicon:ClearAllPoints()
					bar.raidicon:SetPoint("LEFT", bar.framebar, "RIGHT", 2, 0)
					bar.raidicon:SetPoint("CENTER", bar.framebar, "CENTER", 2, 0)
				elseif (barconfig.showicon == "RIGHT") then
					bar.raidicon:ClearAllPoints()
					bar.raidicon:SetPoint("LEFT", bar.icon, "RIGHT", 2, 0)
					bar.raidicon:SetPoint("CENTER", bar.icon, "CENTER", 0, 0)
				end
			end
		end
		
		
		buffbar.barinit = true; -- config finished, set to true
		self:UpdateBuffBarGroup(buffbar, barconfig, true) --update the current bargroup for this new bar, before sorting the groups and getting it visible
		self:SortBuffBarGroups() -- all config'd, lets get the bar on it's correct bargroup
		
		--dirty hack to track ICDs 12/10/09
		if (self.ap.barconfigs[barconfigindex].icdbar) and (self.ap.barconfigs[barconfigindex].icdlength > 0) and (buffbar.destGUID ~= "0x123")  then
			self:CreateBuffBar(barconfigindex, buffbar.shortname.. " CD", timestamp, eventType, "0x123", srcName, srcFlags, "0x123", dstName, dstFlags, spellId, spellName, spellSchool, auraType, count)
		end
		--dirty hack to track KS CD 12/10/09
		
	end
	

end

function ThievesTools:DestroyBuffBar(index)
	--AzMsg("trying to destroy buffbar "..index)
	--if self.buffbars[i] then
		--if self.buffbars[i].destGUID then
			--AzMsg("destroy has found buffbar "..index)
			local bar = self.frames.bars[self.buffbars[index].barframe]
			--while bar.framebar:GetAlpha() > 0 do
			--end
			bar.owner = 0
			self.buffbars[index].destGUID = nil
			self.buffbars[index].barframe = 0;
			self.buffbars[index].infinite = nil
			self.buffbars[index].infiniteset = nil
			self.buffbars[index].duration = 0
			self.buffbars[index].suppress = false
			--wipe(self.buffbars[index])
			--self.buffbars[index] = nil
			self.activebuffbars = self.activebuffbars - 1
			--self:FrameFader(bar.framebar, "OUT")
			--AzMsg("fading frame on unit death")
		--end
	--end
end

function ThievesTools:CheckBuffBars(spellId, dstGUID, srcGUID)
	--for i = 1, self.ap.baroptions.barlimit do
	for i = 1, #self.buffbars do
		if self.buffbars[i] then
			if self.buffbars[i].destGUID and (self.buffbars[i].active == true) then --added active check, so we don't return i for bars fading-to-destroy
				if (self.buffbars[i].spellID == spellId) then -- does spell match?
					--AzMsg("spell matches")
					if (self.buffbars[i].destGUID == dstGUID) then --does destGUID match?
						--AzMsg("dest matches")
						if (self.buffbars[i].sourceGUID == srcGUID) then --after 3.1 remove the or eventType == from this
							--AzMsg("returning "..i)
							return i
						end
					end
				end
			end
		end
	end
	--AzMsg("returning 0")
	return 0
end

function ThievesTools:UpdateBuffBarGroup(buffbar, barconfig, init)

	if ((buffbar.destGUID == self.playerGUID) and (self.ap.barconfigs[buffbar.config].selfbuffpin == true)) or (self.ap.barconfigs[buffbar.config].bargrouppin == true) or (buffbar.destGUID == self.targetGUID) or buffbar.destGUID == "0x123" then
		buffbar.destbargroup = buffbar.bargroup
	else
		buffbar.destbargroup = 2
	end
	
	if init then buffbar.curbargroup = buffbar.destbargroup end; -- init var added so newly created bars are sent to their correct group without first fading out of the mainbar
	
	if not (buffbar.curbargroup == buffbar.destbargroup) then
		
	
	--AzMsg("trying to fadeout")
		if (buffbar.fading == false) then
			buffbar.fading = true
			buffbar.fading = "OUT"
			buffbar.fadestart = self.thetime	
		end
	end
	
end

function ThievesTools:UpdateBuffBars()
	self.updatingbuffbars = true
	--local bsort = false
	--for i = 1, self.ap.baroptions.barlimit do
	for i = 1, #self.buffbars do
		if self.buffbars[i] and self.buffbars[i].destGUID and (self.buffbars[i].barinit == true) then
			--AzMsg(#self.buffbars)
			local barconfig = self.ap.barconfigs[self.buffbars[i].config]
			local bar = self.frames.bars[self.buffbars[i].barframe]
			local buffbar = self.buffbars[i]
			
			------ bar fading stuff, custom fading because UIFrameFade makes too many new tables when switching targets, eating up memory till GC
			------ this fading code has a lot of repetition and needs tidying up, ugly mess
		
			if buffbar.fading then
				local fadepercent, endalpha, startalpha, curalpha
				if buffbar.fading == "IN" then
					endalpha = buffbar.targetalpha
					startalpha = 0.05
					if (self.ap.baroptions.fadeintime == 0) then 
						bar.framebar:SetAlpha(endalpha)
						buffbar.fading = false
						buffbar.curbargroup = buffbar.destbargroup
						ThievesTools.bsort = true
					else
						fadepercent = (self.thetime - buffbar.fadestart) / self.ap.baroptions.fadeintime
						curalpha = fadepercent * endalpha
					end
				else -- must be "OUT" mode
					endalpha = 0
					startalpha = buffbar.targetalpha
					if (self.ap.baroptions.fadeouttime == 0) then 
						bar.framebar:SetAlpha(endalpha)
						if (buffbar.fadedestroy == true) then 
							self:DestroyBuffBar(i)
						else
							buffbar.fading = false
						end
						buffbar.curbargroup = buffbar.destbargroup
						ThievesTools.bsort=true
					else
						fadepercent = (self.thetime - buffbar.fadestart) / self.ap.baroptions.fadeouttime
						curalpha = ( 1 - fadepercent) * startalpha
					end
				end
				if fadepercent then
					if fadepercent > 1 then -- if fadepercent is more than 1, fade is done, set the target alpha and cancel it, destroy bar if requested
						bar.framebar:SetAlpha(endalpha)
						if (buffbar.fadedestroy == true) then 
							self:DestroyBuffBar(i)
						else
							buffbar.fading = false
						end
						buffbar.curbargroup = buffbar.destbargroup
						ThievesTools.bsort = true
					else
						bar.framebar:SetAlpha(curalpha)
						--AzMsg(curalpha)
					end
				end
			end
			
			
			------fading code over, this is where bar/text/spark updates happen
	
			
			if (buffbar.active == true) then
				
				if buffbar.missing then
					bar.statusbar:SetValue(100)
					local thealpha = mod(self.thetime, 1)
					if thealpha < 0.5 then 
						thealpha = thealpha * 2
					else
						thealpha = 1 - (2 * (thealpha - 0.5))
					end
					bar.framebar:SetAlpha(thealpha)
					
					if barconfig.to == "target" then
						if (buffbar.destGUID ~= self.targetGUID) then
							buffbar.fadedestroy = true
							buffbar.fading = "OUT"
							buffbar.fadestart = self.thetime
							buffbar.active = false	
						end
					end
				else
			 
			
					--we shouldn't have any active bars stuck at 0 alpha, ugly hack for when you tab-target too fast
					if (bar.framebar:GetAlpha() == 0) then
						buffbar.fading = "IN"
						buffbar.fadestart = self.thetime
					end
					--------------------------------------------------------------------------------------------------------
					
					-- first thing on bar update, check the current target and decide which bargroup it's on
					self:UpdateBuffBarGroup(buffbar, barconfig)
					
					
					-------------------------------------------------------------------------------------------------------------
					
					-- if UnitAura has been run, we'll have a duration and can figure out the timeleft
					if buffbar.duration > 0 then
						buffbar.timeleft = buffbar.timestart + buffbar.duration - self.thetime
						if buffbar.timeleft < 0 then buffbar.timeleft = 0 end;
						if buffbar.timeleft > 1 then 
							buffbar.durstring = floor(buffbar.timeleft)
							if buffbar.justsub1 then
								bar.text2:SetPoint("LEFT", bar.statusbar, "LEFT", 0, 1);
								bar.text2:SetJustifyH(barconfig.textdurationpos);
								buffbar.justsub1 = false
							end
						else
							--buffbar.durstring = tonumber(string.format("%." .. (1) .. "f", buffbar.timeleft))
							buffbar.durstring = string.format("%.1f", buffbar.timeleft)
							if not buffbar.justsub1 then
								bar.text2:SetPoint("LEFT", bar.statusbar, "RIGHT", -16, 1);
								bar.text2:SetJustifyH("LEFT");
								buffbar.justsub1 = true
							end
						end
						-- if not fixed size bar, ie. slicendice, set max value of the bar to aura duration
						if (barconfig.fixedsize ~= true) then bar.statusbar:SetMinMaxValues(0, buffbar.duration) end;
						-- if this bar has a flashlow to alert when the bar is almost done, and we have a duration, lets make it flash below that value
						if barconfig.flashlow and (buffbar.timeleft < barconfig.flashlowtime) then
							local thealpha = mod(buffbar.timeleft, 1)
							if thealpha < 0.5 then
								thealpha = thealpha * 2
							else
								thealpha = 1 - (2 * (thealpha - 0.5))
							end 
							bar.statusbar:SetAlpha(mod(buffbar.timeleft, 1)) 
						end
					else
					 --lets try to get a unit token for duration
						if buffbar.infinite then
							if not buffbar.infiniteset then
							bar.statusbar:SetMinMaxValues(0, 1)
							bar.statusbar:SetValue(1)
							bar.statusbar:Show()
							buffbar.durstring = "∞"
							buffbar.infiniteset = true
							end
						else
							self:GetAuraDurExp(buffbar, buffbar.spellname)
						end
					end
					
					--charge check
					
					if barconfig.updatecharges then
						if ((self.thetime - buffbar.lastchargecheck) > 0.5) then
							buffbar.lastchargecheck = self.thetime
							self:GetAuraDurExp(buffbar, buffbar.spellname)
						end
					end
					
					-- raid icon check
					if (barconfig.showraidicon ~= "OFF") then
						if ((self.thetime - buffbar.lastraidiconcheck) > 0.5) then
							buffbar.lastraidiconcheck = self.thetime
							local token = self:GetUnitID(buffbar.destGUID)
							if token then 
								local raidicon = GetRaidTargetIndex(token)
								if raidicon then
									bar.raidicon:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_"..raidicon)
									bar.raidicon:Show()
								else
								bar.raidicon:Hide()
								end
							end
						end
					end
					
					--announce checks, now we have a timeleft
					if barconfig.announcetype ~= "OFF" then
						if (barconfig.announcecriteria == "GAIN") and (buffbar.lastannounce == 0) then
							buffbar.lastannounce = self.thetime
							self:AnnounceAura(buffbar, barconfig)
						elseif (barconfig.announcecriteria == "TIME") and (self.thetime - buffbar.lastannounce > 1) and buffbar.duration > 0 and (ceil(buffbar.timeleft) == barconfig.announcetimeleft) then
							buffbar.lastannounce = self.thetime
							self:AnnounceAura(buffbar, barconfig)
						elseif (barconfig.announcecriteria == "TIME") and (barconfig.announceeverysec) and (self.thetime - buffbar.lastannounce >= 1) and buffbar.duration > 0 and (buffbar.timeleft <= barconfig.announcetimeleft) then
							buffbar.lastannounce = self.thetime
							self:AnnounceAura(buffbar, barconfig)
						elseif (barconfig.announcecriteria == "STACKS") and (buffbar.stacks >= barconfig.announcetimeleft) and (buffbar.lastannounce == 0) then
							buffbar.lastannounce = self.thetime
							self:AnnounceAura(buffbar, barconfig)
						elseif (barconfig.announcecriteria == "STACKS") and (buffbar.stacks < barconfig.announcetimeleft) then --catch for stacks decreasing
							buffbar.lastannounce = 0
						end
					end
					
					--if icononly is true, we only need to update the duration text and we're done, else update bars/sparks/texts etc
					if (barconfig.showicononly == true) then
						bar.text2:SetText(buffbar.durstring)
					else
						-- set the statusbar value to current timeleft
						if not buffbar.infinite then bar.statusbar:SetValue(buffbar.timeleft) end
						
						
						-- second bar for current combos, spark positions
						if (barconfig.secondbar == true) then
							if barconfig.showspark == true then
								local sparkPosition 
								if (barconfig.fixedsize == true) then
									sparkPosition = (buffbar.timeleft/buffbar.maxsize) * bar.statusbar:GetWidth();
								else
									sparkPosition = (buffbar.timeleft/buffbar.duration) * bar.statusbar:GetWidth();
								end
								bar.spark1:SetPoint("CENTER", bar.statusbar, "LEFT", sparkPosition , 0);
							end
							if self.combos > 0 then
								local combogives = barconfig.combo_multi * (barconfig.combo_base + (self.combos * barconfig.combo_per))
								bar.statusbar1:SetValue(combogives)
								if not bar.statusbar1:IsVisible() then bar.statusbar1:Show() end;
								if (barconfig.periodspark == false) then
									if not bar.spark:IsVisible() then bar.spark:Show() end;
									local sparkPosition1 = (combogives/buffbar.maxsize) * bar.statusbar1:GetWidth();
									bar.spark:SetPoint("CENTER", bar.statusbar1, "LEFT", sparkPosition1 , 0);
								end
							else
								bar.statusbar1:Hide();
								if (barconfig.periodspark == false) then bar.spark:Hide(); end;
							end
						else -- if the secondbar is disabled, we still need to set the spark position, if enabled
							if barconfig.showspark == true then
								local sparkPosition 
								if (barconfig.fixedsize == true) then
									sparkPosition = (buffbar.timeleft/buffbar.maxsize) * bar.statusbar:GetWidth();
								else
									sparkPosition = (buffbar.timeleft/buffbar.duration) * bar.statusbar:GetWidth();
								end
								bar.spark:SetPoint("CENTER", bar.statusbar, "LEFT", sparkPosition , 0);
							end
						end
					
						
						--periodic damage ticker
						if (barconfig.periodspark ~= false) then
							if not (barconfig.tickertime == 0) then
								if not bar.spark1:IsVisible() then bar.spark1:Show() end;
								local sparktime = self.thetime - buffbar.lasttick
								if sparktime > barconfig.tickertime then sparktime = mod(sparktime, barconfig.tickertime) end;
								local sparkpercent = sparktime / barconfig.tickertime
								local sparkPosition1 = sparkpercent * bar.statusbar:GetWidth();
								bar.spark1:SetPoint("CENTER", bar.statusbar, "LEFT", sparkPosition1 , 0);
							else
								if buffbar.lasttick - buffbar.firsttick > 0.5 then
									barconfig.tickertime = self:round(buffbar.lasttick - buffbar.firsttick, 0)
								end
							end
						end
						
						--[[
						-- the text part, this might be big
						
						if self.ap.bargroups[buffbar.curbargroup].shortnames == true or (buffbar.spellname == "CD") then
							buffbar.buffstring = buffbar.shortname
						else
							buffbar.buffstring = buffbar.name
						end
						
						if barconfig.textbuffhide == true then
							if (buffbar.curbargroup == buffbar.bargroup) then buffbar.buffstring = "" end;
						end
						
						local stringoftext = "" -- temp string for joining name/stacks/timeleft when they share the same position
						
						if buffbar.stacks > 1 then buffbar.stackstring = "("..buffbar.stacks..")" else buffbar.stackstring = "" end
						
						-- if stacks and timeleft share position, join them, else set the set the timeleft to the timeleft fontstring (text2)
						if (buffbar.stacks > 1) and (barconfig.textdurationpos == barconfig.textstackpos) then
							stringoftext = buffbar.stackstring.." - "..buffbar.durstring
						else
							bar.text2:SetText(buffbar.durstring)
							stringoftext = buffbar.stackstring
						end
						
						
						-- if stacks and name share the same position, join them, else set the stacks to the stacks fontstring (text1), and the name to the name fonstring (text)
						if (buffbar.stacks > 1) then
							if (barconfig.textstackpos == barconfig.textbuffpos) then
								stringoftext = buffbar.buffstring.." "..stringoftext
								--AzMsg(stringoftext)
							else
								bar.text1:SetText(buffbar.stackstring)
							end
						else
							stringoftext = buffbar.buffstring.." "..stringoftext
						end
						
						--if duration and name share the same position
						if ((buffbar.stacks > 1) and (barconfig.textstackpos == barconfig.textbuffpos)) and (barconfig.textdurpos == barconfig.textbuffpos) then
							stringoftext = stringoftext.." - "..buffbar.durstring
							--bar.text:SetText(stringoftext)
						elseif (barconfig.textdurpos == barconfig.textbuffpos) then
							stringoftext = stringoftext.." - "..buffbar.durstring
							--bar.text:SetText(stringoftext)
						end
						
						if (barconfig.appendsource == true) and (buffbar.sourceGUID ~= self.playerGUID) then 
							stringoftext = stringoftext.." ["..buffbar.sourcename.."]"
						end
						
						--dirty hack for ICDs 12/10/09
						if (self.ap.bargroups[buffbar.curbargroup].appendtarget == true) and (buffbar.destGUID ~= "0x123") then
							stringoftext = stringoftext.." - "..buffbar.destname
						end
						
						bar.text:SetText(stringoftext)
						--]]
						if (buffbar.durstring ~= buffbar.curdurstring) then
							buffbar.curdurstring = buffbar.durstring
							bar.text2:SetText(buffbar.curdurstring)
						end
						
						if (buffbar.stacks ~= buffbar.curstacks) then
							buffbar.curstacks = buffbar.stacks
							ThievesTools.bsort = true
						end
					end
					
					--catch for bars that never got a duration or a unit_died event
					if (buffbar.timeleft <= 1) and not (buffbar.infinite) then
						if not (buffbar.duration == 0) then  --wait 1s for bars with durations that never got unit_died or aura_removed
							if (buffbar.timestart + buffbar.duration - self.thetime) < -1 then 
								self.buffbars[i].fadedestroy = true
								self.buffbars[i].fading = "OUT"
								self.buffbars[i].fadestart = self.thetime
								self.buffbars[i].active = false
								end
						else
							if (buffbar.timestart + buffbar.duration - self.thetime) < (0 - (self.ap.baroptions.nodurationwait)) then 
								self.buffbars[i].fadedestroy = true
								self.buffbars[i].fading = "OUT"
								self.buffbars[i].fadestart = self.thetime
								self.buffbars[i].active = false 
							end
						end
					end	
				end
			end
		--if buffbar.bsort == true then ThievesTools.bsort = true buffbar.bsort = false end
		end	
	end
	if ThievesTools.bsort == true then ThievesTools:SortBuffBarGroups() ThievesTools.bsort = false end;
	self.updatingbuffbars = false
end

function ThievesTools:CreateBuffBarGroups()

	for i = 1, #self.ap.bargroups do
		ThievesTools.buffbargroups[i] = {}
	end
end

function ThievesTools:SortBuffBarGroups()
	for i = 1, #self.buffbargroups do
		--wipe() creates a new table each time, evil thing, so we'll fake-wipe
		for j = 1, #self.buffbargroups[i] do
			self.buffbargroups[i][j] = nil
		end
		
		local k = 1
		for j = 1, #self.buffbars do
			if self.buffbars[j] and (self.buffbars[j].barframe ~= 0) then
				local bplaced = false
				if (self.buffbars[j].curbargroup == i) then
					if k == 1 then 
						self.buffbargroups[i][k] = j
						bplaced = true
					else
						for l = 1, #self.buffbargroups[i] do
							if (self.ap.bargroups[i].sortby == "rank") then
								if self.buffbars[j].rank < self.buffbars[self.buffbargroups[i][l]].rank then
									t_insert(self.buffbargroups[i], l, j)
									bplaced = true
									break
								end
							elseif (self.ap.bargroups[i].sortby == "time") then
								if self.buffbars[j].timeleft < self.buffbars[self.buffbargroups[i][l]].timeleft then
									t_insert(self.buffbargroups[i], l, j)
									bplaced = true
									break
								end
							elseif (self.ap.bargroups[i].sortby == "dest") then
								if self.buffbars[j].sortdstGUID < self.buffbars[self.buffbargroups[i][l]].sortdstGUID then
									t_insert(self.buffbargroups[i], l, j)
									bplaced = true
									break
								end
							else --only one left is src
								if self.buffbars[j].sortsrcGUID < self.buffbars[self.buffbargroups[i][l]].sortsrcGUID then
									t_insert(self.buffbargroups[i], l, j)
									bplaced = true
									break
								end
							end
						end
					end
					if not bplaced then t_insert(self.buffbargroups[i], k, j) end;
					k = k + 1
				end
			end
		end
		
		
		local posy = 0
		for index, v in pairs(self.buffbargroups[i]) do
			self.frames.bars[self.buffbars[v].barframe].framebar:SetScale(self.ap.bargroups[i].scale);
			if not self.buffbars[v].suppress or self.buffbars[v].missing then
				if self.ap.bargroups[i].growup == true then
					self.frames.bars[self.buffbars[v].barframe].framebar:SetPoint('BOTTOMLEFT', ThievesTools.frames.bargroups[i], 'TOPLEFT', 0, posy);
					posy = posy + self.frames.bars[self.buffbars[v].barframe].framebar:GetHeight();
				else
					self.frames.bars[self.buffbars[v].barframe].framebar:SetPoint('TOPLEFT', ThievesTools.frames.bargroups[i], 'BOTTOMLEFT', 0, posy);
					posy = posy - self.frames.bars[self.buffbars[v].barframe].framebar:GetHeight();
				end
			end
		end	
	end
	
	--moved buffname text to here, only update it when bars change group (stack changes handled onupdate)
	
	--AzMsg("txtlabels")
	for i = 1, #self.buffbars do
		local buffbar = self.buffbars[i]
		if (buffbar.active == true) then
				local barconfig = self.ap.barconfigs[self.buffbars[i].config]
				local bar = self.frames.bars[self.buffbars[i].barframe]
				
				if self.ap.bargroups[buffbar.curbargroup].shortnames == true or (buffbar.spellname == "CD") then
					buffbar.buffstring = buffbar.shortname
				else
					buffbar.buffstring = buffbar.name
				end
				
				if buffbar.stacks > 1 then buffbar.buffstring = buffbar.buffstring.." ("..buffbar.stacks..")" end
				
				--dirty hack for ICDs added 12/10/09, now checks for icd fake destguid
				if (self.ap.bargroups[buffbar.curbargroup].appendtarget == true) and (buffbar.destGUID ~= "0x123") then
					buffbar.buffstring = buffbar.buffstring.." - "..buffbar.destname
				end
				
				if (barconfig.appendsource == true) and (buffbar.sourceGUID ~= self.playerGUID) then 
					buffbar.buffstring = buffbar.buffstring.." ["..buffbar.sourcename.."]"
				end
				
				if (buffbar.buffstring ~= buffbar.curbuffstring) then
					buffbar.curbuffstring = buffbar.buffstring
					bar.text:SetText(buffbar.curbuffstring)
				end
		end
	end
	
end

function ThievesTools:SetAuraRank(index, newrank)


	local barconfigs = self.ap.barconfigs
	if newrank > #barconfigs then newrank = #barconfigs end
	local oldrank = barconfigs[index].rank --oldrank is to fix downranking by 1 failing due to >= keeping the aura ranked below, below
	barconfigs[index].rank = newrank
	
	--the following code is brutally ugly but it works and i'm tired, there's a much better way to sort a list of duplicate ranks into a sequential list
	--i'm sure.  SortbuffBarGroups() is quite elegant in comparison, but damned if i can read my own code from a year ago, at 1am.
	local ranklist = {}
	local i = 1
	while i < 99 do
		for j = 1, #barconfigs do
			if oldrank == newrank - 1 then
				if (barconfigs[j].rank <= newrank) and (barconfigs[j].rank == i) and not (j == index) then t_insert(ranklist, j) end
			else
				if (barconfigs[j].rank < newrank) and (barconfigs[j].rank == i) and not (j == index) then t_insert(ranklist, j) end
			end
		end
	i = i + 1
	end
	local i = 1
	while i < 99 do
		for j = 1, #barconfigs do
			if (barconfigs[j].rank == newrank) and (barconfigs[j].rank == i) and (j == index) then t_insert(ranklist, j) end
		end
	i = i + 1
	end
	local i = 1
	while i < 99 do
		for j = 1, #barconfigs do
			if oldrank == newrank - 1 then
				if (barconfigs[j].rank > newrank) and (barconfigs[j].rank == i) and not (j == index) then t_insert(ranklist, j) end
			else
				if (barconfigs[j].rank >= newrank) and (barconfigs[j].rank == i) and not (j == index) then t_insert(ranklist, j) end
			end
		end
	i = i + 1
	end
	
	for i = 1, #ranklist do
		for k = 1, #barconfigs do
			if k == ranklist[i] then 
				barconfigs[k].rank = i
				--AzMsg(i .. barconfigs[k].barname)
			end
		end
	end
	
end

function ThievesTools:GetStringRaidIcon(index)
	if index then
		if index == 1 then return "{star}"
		elseif index == 2 then return "{circle}"
		elseif index == 3 then return "{diamond}"
		elseif index == 4 then return "{triangle}"
		elseif index == 5 then return "{moon}"
		elseif index == 6 then return "{square}"
		elseif index == 7 then return "{cross}"
		elseif index == 8 then return "{skull}"
		else return ""
		end
	end
end

function ThievesTools:AnnounceAura(buffbar, barconfig)

	
	local strannounce
	local strsrc = buffbar.sourcename
	local strdst = buffbar.destname
	if strsrc == nil then strsrc = L.announce_none end
	if strdst == nil then strdst = L.announce_none end
	
	
	
	if barconfig.announcetype == "SELF" then
		strannounce = strsrc ..L.announce_apostrophe.." "..buffbar.spellname.." "..L.announce_on.." "..strdst..""..L.announce_comma
	else
		local iconsrc = ""
		local icondst = ""
		local token = self:GetUnitID(buffbar.sourceGUID)
		local index = nil
		if token then
			index = GetRaidTargetIndex(token);
		end
		if index then
			iconsrc = self:GetStringRaidIcon(index)
		end
		token = self:GetUnitID(buffbar.destGUID)
		index = nil
		if token then
			index = GetRaidTargetIndex(token);
		end
		if index then
			icondst = self:GetStringRaidIcon(index)
		end
		strannounce = iconsrc..strsrc ..L.announce_apostrophe.." "..buffbar.spellname.." "..L.announce_on.." "..icondst..strdst..""..L.announce_comma
	end
	
	if (buffbar.announcecrit == "GAIN") then
		strannounce = strannounce.." "..L.announce_gained
	end
	
	if (buffbar.announcecrit == "TIME") then
		strannounce = strannounce.." "..L.announce_remaining.." "..buffbar.durstring..L.announce_seconds
	end
	
	if (buffbar.announcecrit == "STACKS") then
		strannounce = strannounce.." "..L.announce_stacks.." "..buffbar.stacks
	end
	
	if (buffbar.announcecrit == "EXPIRED") then
		strannounce = strannounce.." "..L.announce_expired
	end
	
	if barconfig.announcetype == "SELF" then
		AzMsg(strannounce)
	elseif (barconfig.announcetype == "CHANNEL") and not ((barconfig.announcedest == "none") or (barconfig.announcedest == "")) then
		local index = GetChannelName(barconfig.announcedest)
		if (index == nil) then
			-- JoinChannelByName(barconfig.announcedest)
			-- index = GetChannelName(barconfig.announcedest)
		end
		if (index ~= nil) then
			SendChatMessage(strannounce , "CHANNEL", nil, index);
		end
	elseif (barconfig.announcetype == "TARGET") then
		if UnitIsFriendly(buffbar.destname) then
			SendChatMessage(strannounce , "WHISPER", nil, buffbar.destname);
		end
	elseif (barconfig.announcetype == "WHISPER") and not ((barconfig.announcedest == "none") or (barconfig.announcedest == "")) then
		if UnitExists(barconfig.announcedest) and UnitIsFriend("player", barconfig.announcedest) then
			SendChatMessage(strannounce , "WHISPER", nil, barconfig.announcedest);
		end
	elseif (barconfig.announcetype == "GROUP") then
		SendChatMessage(strannounce , "PARTY");
	elseif (barconfig.announcetype == "RAID") then
		SendChatMessage(strannounce , "RAID");
	elseif (barconfig.announcetype == "OFFICER") then
		SendChatMessage(strannounce , "OFFICER");
	end
end
	