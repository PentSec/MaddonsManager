local L = TT_locale;
local _ 
local _G = getfenv(0);
local ThievesTools 
if not ThievesTools then ThievesTools = _G.ThievesTools end

function ThievesTools:config_defaults()


	------------------------------------------------------------------------------------
	----------- create profile arrays, populate temp default config arrays ------
	------------------------------------------------------------------------------------

	local TT_mainoptions = {}
	local TT_barconfigs = {}
	local TT_baroptions = {}
	local TT_bargroups = {}
	local TT_cpoptions = {}
	local TT_kickeroptions = {}
	local TT_puoptions = {}
	local TT_puconfigs = {}
	local TT_pmoptions = {}
	local TT_pmconfigs = {}
	TT_profiles = {}
	TT_ap = 0


	---font and textures

	local thefont = L.barfontfile
	local bartex = L.bartexfile
	local thefontsize = 12
	local fontr = 1
	local fontg = 1
	local fontb = 1
	local fontout = false
	local thefontdrop = true

	--alphas
	local thealpha = 1
	local thebg_alpha = 0.5
	local thebar_alpha = 1
	local thebar2_alpha = 0.9

	--sizes and scales

	local thescale = 1
	local barwidth = 144  --not the bar, but bg frame size, -4 for actual status bar width
	local barheight = 17  --not the bar, but bg frame size, -2 for actual status bar height


	--- text positions

	local posbuff = "LEFT"
	local posdur = "RIGHT"
	local posstack = "LEFT"
	local posvert = "BOTTOM"


	TT_mainoptions = {
		updatespeed = 0, -- in ms, how often to inspect buffs, 0 = onupdate
		misc1 = 0,
		misc2 = 0,
		misc3 = 0,
		misc4 = 0,
		misc5 = 0,
		misc6 = 0,
		misc7 = 0,
		misc8 = 0,
		}
		
	TT_barconfigs = {}			


	TT_barconfigs[0] = {
		enabled = true,
		barname = L.buff_new,
		rank = 1,
		height = barheight,
		width = barwidth,
		font = thefont,
		fontsize = thefontsize,
		fontoutline = fontout,
		fontdrop = thefontdrop,
		font_r = fontr,
		font_g = fontg,
		font_b = fontb,
		--scale = thescale,
		alpha = thealpha,
		bg_alpha = thebg_alpha,
		bar_alpha = thebar_alpha,
		bar2_alpha = thebar2_alpha,
		buff = "BUFF",
		buffname = L.buff_new,
		fullscan = false, --flag to enable full scanning with unitaura() past the first caster+aura match, for buffs that refresh into new aura with new duration, like tricks
		updatecharges = false, --flag for updating an aura via unitaura() on a set interval, eg. to inspect remaining charges, which aren't exposed by combatlog events
		spellid = 0,
		shortname = L.new_short,
		fixedsize = false,
		fixedsizevalue = 0,
		flashlow = false,
		flashlowtime = 5,
		highlightedge = 0, -- number of stacks to highlight barframe edge at, eg. 5 for DP 
		color_r = 1,
		color_g = 1,
		color_b = 1,
		showspark = true,
		--secondbar stuff, shows what the current combos would add 
		secondbar = false,
		color1_r = 0.5,
		color1_g = 0.5,
		color1_b = 0.5,
		combo_base = 1, -- the base time
		combo_per = 1, -- time added per combo
		combo_multi = 1, -- multiplier for sum of above (eg. impr snd talent)
		periodspark = false,
		tickertime = 0,
		tickeroffset = 0,
		textbuffhide = false, -- hide the aura text when bar is on it's default bargroup
		textbuffpos = posbuff,
		textdurationpos = posdur,
		textstackpos = posstack,
		textvertalign = posvert,
		showicon = "LEFT",
		showicononly = false,
		showraidicon = "LEFT",
		hideofftarget = false, -- hide bar when off target
		--appendtarget = false,
		appendsource = false,
		selfbuffpin = true, --by default don't move aura on self to untargetted when not targetting self
		from = "player", -- only show when from target/focus/player/vehicle/namedplayer/grouped/any
		fromname = "none", -- name if from is named player
		to = "target", -- only show when to target/focus/player/vehicle/namedplayer/grouped/any
		toname = "none", -- name if to is named player
		bargroup = 1,
		bargrouppin = false,
		announcetype = "OFF", -- channel or whisper announce
		announcedest = "none", -- channel/player to spam with above
		announcenonself = true, -- only announce when not to self
		announcecriteria = "TIME", --criteria to announce, time, stacks, gain, or expire
		announcetimeleft = 0, --time left to announce the aura in seconds, 0 = expiration, -1 = application
		announceeverysec = false,
		announceexp = false, --also announce expiration if criteria ~= expire
		sound = "OFF",
		soundtype = "TIME",
		soundvalue = 0,
		soundeverysec = true,
		icdbar = false, --create a bar to track the cooldown/ICD
		icdbargroup = 2, --which group to show the cooldown on
		icdflash = false, --flash the cooldown bar at this value
		icdlength = 0, --length of the cooldown
		icdlengthdetect = false, --boolean, attempt icd estimation when unknown
		fixeddur = false, --bool, if once duration is found, it applies to all auras of this name
		fixeddurlength = 0, -- place to store the detected duration
		checkmissing = false, --if we want missing auras displayed as a bar
		suppress = false, -- track the aura, but suppress the bar from showing
		misc1 = 0,
		misc2 = 0,
		misc3 = 0,
		misc4 = 0,
	}

	TT_baroptions = {
		enabled = false,
		height = 0,
		width = 0,
		font = false,
		shortname = false,
		hideofftarget = false, -- hide all bars when off target, overrides per-bar option
		fontoutline = false,
		fontdrop = false,
		fontsize = 0,
		font_r = 0,
		font_g = 0,
		font_b = 0,
		textbuffpos = false,
		textdurationpos = false,
		textstackpos = false,
		textvertalign = false,
		bartexture = false,
		showspark = false,
		alpha = 0,
		bg_alpha = 0,
		showicon = 0,
		fadeintime = 0,
		fadeouttime = 0,
		animate = false, -- animate the bar moving to untargetted instead of fading
		barspacing = 0,
		bargroups = 0, -- number of enabled bargroups
		updatespeed = 0.04, -- how often to redraw bars in ms, 0 = every onupdate
		nodurationwait = 10, -- how long to wait to find a duration before killing a duration-less bar 
		barlimit = 0,
		misc1 = 0,
		misc2 = 0,
		}

	TT_bargroups = {}
	for i = 0,2 do
		TT_bargroups[i] = {
		name = L.bargroup_newgroup,
		scale = 1,
		shortnames = false,
		appendtarget = false,
		prefixsource = false,
		enabled = true,
		growup = false,
		alignright = false,
		sortby = "time",--options are time, dest-time, source-time, rank-time, dest-rank, source-rank
		subsortby = "dest",
		posx = 0, -- relative to TTf_main
		posy = 0,
		misc1 = 0,
		misc2 = 0,
		}
	end

	TT_cpoptions = {
		enabled = false,
		attached = false,
		alignby = false,
		posx = 0,
		posy = 0,
		scale = 0,
		height = 18,
		spacing = 12,
		fadetime = 0.2,
		combolarge5 = true,
		combobg = "none", -- in case ever add selectable combo backgrounds
		combotex = false, -- point texture
		comboshinetex = false, -- combo shine-on-new texture
		combocolor_r = 0,
		combocolor_g = 0,
		combocolor_b = 0,
		colorcombos = false,
		energymeter = false,
		energymeterbar = false, --show energy meter as a bar below the combos, instead of a circle
		energywidth = 30,
		energyheight = 17,
		energyattach = true,
		energyposx = 0,
		energyposy = 0,
		colormeter = false,
		metertext = false,
		font = false,
		fontoutline = false,
		fontdrop = true,
		fontsize = 0,
		font_r = 0,
		font_g = 0,
		font_b = 0,
		color_r = 0,
		color_g = 0,
		color_b = 0,
		energyleft1 = 0,
		color1_r = 0,
		color1_g = 0,
		color1_b = 0,
		energyleft2 = 0,
		color2_r = 0,
		color2_g = 0,
		color2_b = 0,
		energyleft3 = 0,
		color3_r = 0,
		color3_g = 0,
		color3_b = 0,
		misc1 = 0,
		misc2 = 0,
		}
		
	TT_kickeroptions = {
		enabled = false,
		font = false,
		fontsize = false,
		fontoutline = false,
		fontdrop = false,
		bartexture = false,
		font_r = 0,
		font_g = 0,
		font_b = 0,
		fontcolorbylcass = false,
		width = 0,
		height = 0,
		scale = 0,
		sortby = false,
		alpha = 0,
		posx = 0,
		posy = 0,
		targetlocked = false, --display in top statusbar when target is school/spell locked
		talentdiscovery = false, --inspect friendly interrupter talents for more accurate cooldown/lock times
		nontargetlocked = false, --parse combat log, show on untarget bar group when hostile is locked
		announce = false, -- false/own/all, for annoying people to use
		announcechannel = false, -- channel to spam interrupts in
		misc1 = 0,
		misc2 = 0,
		}
		
	TT_puoptions = {
		enabled = false,
		attached = false,
		alignby = false,
		scale = 0,
		font = false,
		fontsize = false,
		fontoutline = false,
		fontdrop = false,
		font_r = 0,
		font_g = 0,
		font_b = 0,
		layoutx = 0,
		layouty = 0,
		alpha = 0,
		posx = 0,
		posy = 0,
		misc1 = 0,
		misc2 = 0,
		}

	TT_puconfigs = {}
	for i = 1,1 do
		TT_puconfigs[i] = {
		enabled = false,
		font = false,
		fontsize = false,
		fontoutline = false,
		fontdrop = false,
		font_r = 0,
		font_g = 0,
		font_b = 0,
		buffname = false,
		bufficonfrom = false,
		bufficon = false,
		showtimeup = false,
		showtimedown = false,
		color_r = 0,
		color_g = 0,
		color_b = 0,
		timeleft1 = 0,
		color1_r = 0,
		color1_g = 0,
		color1_b = 0,
		timeleft2 = 0,
		color2_r = 0,
		color2_g = 0,
		color2_b = 0,
		timeleft1 = 0,
		color3_r = 0,
		color3_g = 0,
		color3_b = 0,
		misc1 = 0,
		misc2 = 0,
		}
	end

	TT_pmoptions = {
		enabled = false,
		perfight = false,
		font = false,
		fontsize = 0,
		font_r = 0,
		font_g = 0,
		font_b = 0,
		bartexture = false,
		scale = 0,
		width = 0,
		height = 0,
		alpha = 0,
		posx = 0,
		posy = 0,
		misc1 = 0,
		misc2 = 0,
		}
		
	TT_pmconfigs = {}
	for i = 1,1 do
		TT_pmconfigs[i] = {
		enabled = false,
		buffname = false,
		buffwho = false,
		misc1 = 0,
		misc2 = 0,
		misc3 = 0,
		misc4 = 0,
		}
	end


	for i =1,1 do
		TT_profiles[i] = {
		profilename = false,
		mainoptions = false,
		barconfigs = false,
		baroptions = false,
		bargroups = false,
		cpoptions = false,
		kickeroptions = false,
		puoptions = false,
		puconfigs = false,
		pmoptions = false,
		pmconfigs = false,
		}
	end

-----------------------------------------------------------------
-------------- common defaults ----------------------------------
-----------------------------------------------------------------


	
	
	---apply default main options
	
	TT_mainoptions.buffupdatespeed = 0
	TT_mainoptions.debuffupdatespeed = 0
	


	--- apply baroption defaults

	TT_baroptions.enabled = true
	TT_baroptions.width = barwidth
	TT_baroptions.height = barheight
	TT_baroptions.font = thefont
	TT_baroptions.shortname = false
	TT_baroptions.hideofftarget = false
	TT_baroptions.fontoutline = fontout
	TT_baroptions.fontdrop = thefontdrop
	TT_baroptions.fontsize = thefontsize
	TT_baroptions.font_r = fontr
	TT_baroptions.font_g = fontg
	TT_baroptions.font_b = fontb
	TT_baroptions.textbuffpos = posbuff
	TT_baroptions.textdurationpos = posdur
	TT_baroptions.textstackpos = posstack
	TT_baroptions.textvertalign = posvert
	TT_baroptions.alpha = thealpha
	TT_baroptions.bg_alpha = thebg_alpha
	TT_baroptions.showicon = true
	TT_baroptions.bartexture = bartex
	TT_baroptions.showspark = true
	TT_baroptions.bargroups = 2
	TT_baroptions.fadeintime = 0.2
	TT_baroptions.fadeouttime = 0.2
	TT_baroptions.updatespeed = 0.4
	TT_baroptions.barlimit = 50
	

	--apply combo point icon defaults

	TT_cpoptions.enabled = true
	TT_cpoptions.attached = "TOP"
	TT_cpoptions.alignby = "CENTER"
	TT_cpoptions.scale = scale
	TT_cpoptions.combotex = L.combotex1 
	TT_cpoptions.comboshinetex = L.comboshine 
	TT_cpoptions.colorcombos = true
	TT_cpoptions.energymeter = true
	TT_cpoptions.colormeter = true
	TT_cpoptions.metertext = true
	TT_cpoptions.font = thefont
	TT_cpoptions.fontoutline = fontout
	TT_cpoptions.fontdrop = fontdrop
	TT_cpoptions.fontsize = 10
	TT_cpoptions.font_r = fontr
	TT_cpoptions.font_g = fontg
	TT_cpoptions.font_b = fontb
	TT_cpoptions.color_r = 0
	TT_cpoptions.color_g = 0.8
	TT_cpoptions.color_b = 0
	TT_cpoptions.energyleft1 = 65
	TT_cpoptions.color1_r = 1
	TT_cpoptions.color1_g = 0.9
	TT_cpoptions.color1_b = 0
	TT_cpoptions.energyleft2 = 40
	TT_cpoptions.color2_r = 1
	TT_cpoptions.color2_g = 0.5
	TT_cpoptions.color2_b = 0
	TT_cpoptions.energyleft3 = 25
	TT_cpoptions.color3_r = 0.7
	TT_cpoptions.color3_g = 0
	TT_cpoptions.color3_b = 0

	--apply kicker defaults

	TT_kickeroptions.enabled = true
	TT_kickeroptions.font = font
	TT_kickeroptions.fontsize = fontsize
	TT_kickeroptions.fontdrop = fontdrop
	TT_kickeroptions.fontoutline = fontout
	TT_kickeroptions.bartexture = bartex
	TT_kickeroptions.font_r = fontr
	TT_kickeroptions.font_g = fontg
	TT_kickeroptions.font_b = fontb
	TT_kickeroptions.fontcolorbylcass = false
	TT_kickeroptions.width = barwidth
	TT_kickeroptions.height = barheight
	TT_kickeroptions.scale = scale
	TT_kickeroptions.sortby = "activity"
	TT_kickeroptions.alpha = alpha
	TT_kickeroptions.targetlocked = true
	TT_kickeroptions.talentdiscovery = true
	TT_kickeroptions.nontargetlocked = true

	-- apply proc-up defaults

	TT_puoptions.enabled = true
	TT_puoptions.attached = true
	TT_puoptions.alignby = "BOTTOM"
	TT_puoptions.scale = scale
	TT_puoptions.font = font
	TT_puoptions.fontsize = fontsize
	TT_puoptions.fontdrop = fontdrop
	TT_puoptions.fontoutline = fontout
	TT_puoptions.font_r = fontr
	TT_puoptions.font_g = fontg
	TT_puoptions.font_b = fontb
	TT_puoptions.layoutx = 5
	TT_puoptions.layouty = 1
	TT_puoptions.alpha = alpha
		
	-- apply common proc-up configs

	for i = 1,1 do
		TT_puconfigs[i].font = font
		TT_puconfigs[i].fontsize = fontsize
		TT_puconfigs[i].fontdrop = fontdrop
		TT_puconfigs[i].fontsize = fontsize
		TT_puconfigs[i].font_r = fontr
		TT_puconfigs[i].font_g = fontg
		TT_puconfigs[i].font_b = fontb
		TT_puconfigs[i].bufficonfrom = "trinket1"
		TT_puconfigs[i].showtimeup = true
		TT_puconfigs[i].showtimedown = true
		TT_puconfigs[i].color_r = 0
		TT_puconfigs[i].color_g = 1
		TT_puconfigs[i].color_b = 0
		TT_puconfigs[i].color1_r = 0.2
		TT_puconfigs[i].color1_g = 1
		TT_puconfigs[i].color1_b = 0
		TT_puconfigs[i].color2_r = 0.7
		TT_puconfigs[i].color2_g = 0.7
		TT_puconfigs[i].color2_b = 0
		TT_puconfigs[i].color3_r = 1
		TT_puconfigs[i].color3_g = 0
		TT_puconfigs[i].color3_b = 0	
	end

	-- apply proc meter defaults

	TT_pmoptions.enabled = true
	TT_pmoptions.perfight = true
	TT_pmoptions.font = font
	TT_pmoptions.fontsize = fontsize
	TT_pmoptions.fontdrop = fontdrop
	TT_pmoptions.fontsize = fontsize
	TT_pmoptions.font_r = fontr
	TT_pmoptions.font_g = fontg
	TT_pmoptions.font_b = fontb
	TT_pmoptions.scale = scale
	TT_pmoptions.width = barwidth
	TT_pmoptions.height = barheight
	TT_pmoptions.alpha = alpha

	----------------------------------------------------------------
	------------ buff specific defaults ----------------------------
	----------------------------------------------------------------
	local playerclass = UnitClass("player")
	if (playerclass == "Rogue") then
	
		for i = 1,13 do
			TT_barconfigs[i] = {}
			TT_barconfigs[i] = ThievesTools:deepcopy(TT_barconfigs[0])
			
			--snd
			if i == 1 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = L.buff_slice
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "BUFF"
				TT_barconfigs[i].buffname = L.buff_slice
				TT_barconfigs[i].spellid = 6774
				TT_barconfigs[i].shortname = L.slice_short
				TT_barconfigs[i].fixedsize = true
				TT_barconfigs[i].color_r = 0.5
				TT_barconfigs[i].color_g = 0.5
				TT_barconfigs[i].color_b = 1
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = true
				TT_barconfigs[i].combo_base = 6
				TT_barconfigs[i].combo_per = 3
				TT_barconfigs[i].combo_multi = 1
				TT_barconfigs[i].color1_r = 1
				TT_barconfigs[i].color1_g = 0.8
				TT_barconfigs[i].color1_b = 0
				TT_barconfigs[i].bar2_alpha = 0.5
				TT_barconfigs[i].to = "player"
			end
			--rupture
			if i == 2 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = L.debuff_rupture
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "DEBUFF"
				TT_barconfigs[i].buffname = L.debuff_rupture
				TT_barconfigs[i].spellid = 48672
				TT_barconfigs[i].shortname = L.rupture_short
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 1
				TT_barconfigs[i].color_g = 0.5
				TT_barconfigs[i].color_b = 0.5
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
				TT_barconfigs[i].combo_base = 6
				TT_barconfigs[i].combo_per = 2
				TT_barconfigs[i].combo_multi = 1
				TT_barconfigs[i].textdurationpos = "RIGHT"
				TT_barconfigs[i].textbuffpos = "LEFT"
			end
			-- deadly poison
			if i == 3 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = L.debuff_deadly
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "DEBUFF"
				TT_barconfigs[i].buffname = L.debuff_deadly
				TT_barconfigs[i].shortname = L.deadly_short
				TT_barconfigs[i].stackable = true
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 0.5
				TT_barconfigs[i].color_g = 1
				TT_barconfigs[i].color_b = 0.5
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
				TT_barconfigs[i].periodspark = true
				TT_barconfigs[i].tickertime = 3
				TT_barconfigs[i].tickeroffset = 0
			end
			-- wound poison
			if i == 4 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = L.debuff_wound
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "DEBUFF"
				TT_barconfigs[i].buffname = L.debuff_wound
				TT_barconfigs[i].shortname = L.wound_short
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 0
				TT_barconfigs[i].color_g = 0.6
				TT_barconfigs[i].color_b = 0
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
			end
			-- mind numbing poison
			if i == 5 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = L.debuff_mind
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "DEBUFF"
				TT_barconfigs[i].buffname = L.debuff_mind
				TT_barconfigs[i].shortname = L.mind_short
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 0.2
				TT_barconfigs[i].color_g = 0.8
				TT_barconfigs[i].color_b = 0.2
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
			end
			-- crippling poison
			if i == 6 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = L.debuff_crippling
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "DEBUFF"
				TT_barconfigs[i].buffname = L.debuff_crippling
				TT_barconfigs[i].shortname = L.crippling_short
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 0.3
				TT_barconfigs[i].color_g = 0.9
				TT_barconfigs[i].color_b = 0.3
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
			end
			-- expose/sunder
			if i == 7 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = L.debuff_expose
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "DEBUFF"
				TT_barconfigs[i].buffname = L.debuff_expose
				TT_barconfigs[i].spellid = 48669
				TT_barconfigs[i].shortname = L.expose_short
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 0.5
				TT_barconfigs[i].color_g = 0.5
				TT_barconfigs[i].color_b = 0.5
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
				TT_barconfigs[i].combo_base = 0
				TT_barconfigs[i].combo_per = 6
				TT_barconfigs[i].combo_multi = 1
				TT_barconfigs[i].from = "any"
			end
			-- hunger for blood
			if i == 8 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = L.buff_hunger
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "BUFF"
				TT_barconfigs[i].buffname = L.buff_hunger
				TT_barconfigs[i].shortname = L.hunger_short
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 0.5
				TT_barconfigs[i].color_g = 0
				TT_barconfigs[i].color_b = 0.5
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
				TT_barconfigs[i].flashlow = true
				TT_barconfigs[i].flashlowtime = 6
				TT_barconfigs[i].bargrouppin = false
				TT_barconfigs[i].to = "player"
			end
			-- sap
			if i == 9 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = L.debuff_sap
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "DEBUFF"
				TT_barconfigs[i].buffname = L.debuff_sap
				TT_barconfigs[i].shortname = L.sap_short
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 1
				TT_barconfigs[i].color_g = 1
				TT_barconfigs[i].color_b = 1
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
				TT_barconfigs[i].flashlow = true
				TT_barconfigs[i].flashlowtime = 10
			end
			-- blind
			if i == 10 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = L.debuff_blind
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "DEBUFF"
				TT_barconfigs[i].buffname = L.debuff_blind
				TT_barconfigs[i].shortname = L.blind_short
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 1
				TT_barconfigs[i].color_g = 1
				TT_barconfigs[i].color_b = 1
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
			end
			-- tricks any source to player (own tricks or received from others)
			if i == 11 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = L.buff_tricks
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "BUFF"
				TT_barconfigs[i].buffname = L.buff_tricks
				TT_barconfigs[i].shortname = L.tricks_short
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 1
				TT_barconfigs[i].color_g = 1
				TT_barconfigs[i].color_b = 1
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
				TT_barconfigs[i].tofrom = true
				TT_barconfigs[i].from = "any"
				TT_barconfigs[i].to = "player"
				TT_barconfigs[i].fullscan = true
			end
				-- kidney / cheap shot
			if i == 12 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = L.debuffs_shots
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "DEBUFF"
				TT_barconfigs[i].buffname = L.debuffs_shots
				TT_barconfigs[i].shortname = L.shots_short
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 1
				TT_barconfigs[i].color_g = 1
				TT_barconfigs[i].color_b = 1
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
			end
			
			--envenom
			if i == 13 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = L.buff_envenom
				TT_barconfigs[i].rank = 1
				TT_barconfigs[i].buff = "BUFF"
				TT_barconfigs[i].buffname = L.buff_envenom
				TT_barconfigs[i].shortname = L.buff_envenom
				TT_barconfigs[i].stackable = false
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 0
				TT_barconfigs[i].color_g = 0.25
				TT_barconfigs[i].color_b = 0
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
				TT_barconfigs[i].from = "player"
				TT_barconfigs[i].to = "player"
			end
		end
	
	elseif (playerclass == "Druid") then
		for i = 1,4 do
			TT_barconfigs[i] = {}
			TT_barconfigs[i] = ThievesTools:deepcopy(TT_barconfigs[0])
			-- tests for tarweh
			if i == 1 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = "Lifebloom"
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "BUFF"
				TT_barconfigs[i].buffname = "Lifebloom"
				TT_barconfigs[i].shortname = "Lifebloom"
				TT_barconfigs[i].stackable = true
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 0.5
				TT_barconfigs[i].color_g = 1
				TT_barconfigs[i].color_b = 0.5
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
				TT_barconfigs[i].periodspark = true
				TT_barconfigs[i].tickertime = 1
				TT_barconfigs[i].tickeroffset = 0
				TT_barconfigs[i].from = "player"
				TT_barconfigs[i].to = "any"
				TT_barconfigs[i].selfbuffpin = false
			end
			if i == 2 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = "Wild Growth"
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "BUFF"
				TT_barconfigs[i].buffname = "Wild Growth"
				TT_barconfigs[i].shortname = "W.Growth"
				TT_barconfigs[i].stackable = true
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 0.2
				TT_barconfigs[i].color_g = 0.8
				TT_barconfigs[i].color_b = 0.2
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
				TT_barconfigs[i].periodspark = true
				TT_barconfigs[i].tickertime = 1
				TT_barconfigs[i].tickeroffset = 0
				TT_barconfigs[i].from = "player"
				TT_barconfigs[i].to = "any"
				TT_barconfigs[i].selfbuffpin = false
			end
			if i == 3 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = "Rejuvenation"
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "BUFF"
				TT_barconfigs[i].buffname = "Rejuvenation"
				TT_barconfigs[i].shortname = "Rejuv"
				TT_barconfigs[i].stackable = true
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 1
				TT_barconfigs[i].color_g = 0
				TT_barconfigs[i].color_b = 1
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
				TT_barconfigs[i].periodspark = true
				TT_barconfigs[i].tickertime = 3
				TT_barconfigs[i].tickeroffset = 0
				TT_barconfigs[i].from = "player"
				TT_barconfigs[i].to = "any"
				TT_barconfigs[i].selfbuffpin = false
			end
			if i == 4 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = "Regrowth"
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "BUFF"
				TT_barconfigs[i].buffname = "Regrowth"
				TT_barconfigs[i].shortname = "Regrowth"
				TT_barconfigs[i].stackable = true
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 0
				TT_barconfigs[i].color_g = 0.6
				TT_barconfigs[i].color_b = 0
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
				TT_barconfigs[i].periodspark = true
				TT_barconfigs[i].tickertime = 3
				TT_barconfigs[i].tickeroffset = 0
				TT_barconfigs[i].from = "player"
				TT_barconfigs[i].to = "any"
				TT_barconfigs[i].selfbuffpin = false
			end
		end
		
	else
		for i = 1,1 do
			TT_barconfigs[i] = {}
			TT_barconfigs[i] = ThievesTools:deepcopy(TT_barconfigs[0])
			
			if i == 1 then
				TT_barconfigs[i].enabled = true
				TT_barconfigs[i].barname = L.debuff_sap
				TT_barconfigs[i].rank = i
				TT_barconfigs[i].buff = "DEBUFF"
				TT_barconfigs[i].buffname = L.debuff_sap
				TT_barconfigs[i].shortname = L.sap_short
				TT_barconfigs[i].fixedsize = false
				TT_barconfigs[i].color_r = 1
				TT_barconfigs[i].color_g = 1
				TT_barconfigs[i].color_b = 1
				TT_barconfigs[i].showspark = true
				TT_barconfigs[i].secondbar = false
				TT_barconfigs[i].flashlow = 10
			end
		end
		
	end
		--illy test stuff
		
		-- if i == 13 then
			-- TT_barconfigs[i].enabled = true
			-- TT_barconfigs[i].barname = "Vampiric Embrace"
			-- TT_barconfigs[i].rank = i
			-- TT_barconfigs[i].buff = "DEBUFF"
			-- TT_barconfigs[i].buffname = "Vampiric Embrace"
			-- TT_barconfigs[i].shortname = "Vampiric Embrace"
			-- TT_barconfigs[i].stackable = true
			-- TT_barconfigs[i].fixedsize = false
			-- TT_barconfigs[i].color_r = 0.5
			-- TT_barconfigs[i].color_g = 1
			-- TT_barconfigs[i].color_b = 0.5
			-- TT_barconfigs[i].showspark = true
			-- TT_barconfigs[i].secondbar = false
			-- TT_barconfigs[i].periodspark = true
			-- TT_barconfigs[i].tickertime = 1
			-- TT_barconfigs[i].tickeroffset = 0
			-- TT_barconfigs[i].from = "player"
			-- TT_barconfigs[i].to = "any"
			-- TT_barconfigs[i].selfbuffmove = true
		-- end
		-- if i == 14 then
			-- TT_barconfigs[i].enabled = true
			-- TT_barconfigs[i].barname = "Vampiric Touch"
			-- TT_barconfigs[i].rank = i
			-- TT_barconfigs[i].buff = "DEBUFF"
			-- TT_barconfigs[i].buffname = "Vampiric Touch"
			-- TT_barconfigs[i].shortname = "V.Touch"
			-- TT_barconfigs[i].stackable = true
			-- TT_barconfigs[i].fixedsize = false
			-- TT_barconfigs[i].color_r = 0.2
			-- TT_barconfigs[i].color_g = 0.8
			-- TT_barconfigs[i].color_b = 0.2
			-- TT_barconfigs[i].showspark = true
			-- TT_barconfigs[i].secondbar = false
			-- TT_barconfigs[i].periodspark = true
			-- TT_barconfigs[i].tickertime = 1
			-- TT_barconfigs[i].tickeroffset = 0
			-- TT_barconfigs[i].from = "player"
			-- TT_barconfigs[i].to = "any"
			-- TT_barconfigs[i].selfbuffmove = true
		-- end
		-- if i == 15 then
			-- TT_barconfigs[i].enabled = true
			-- TT_barconfigs[i].barname = "Shadow Words"
			-- TT_barconfigs[i].rank = i
			-- TT_barconfigs[i].buff = "DEBUFF"
			-- TT_barconfigs[i].buffname = "Shadow Word: Death, Shadow Word: Pain"
			-- TT_barconfigs[i].shortname = "SW:Death, SW:Pain"
			-- TT_barconfigs[i].stackable = true
			-- TT_barconfigs[i].fixedsize = false
			-- TT_barconfigs[i].color_r = 1
			-- TT_barconfigs[i].color_g = 0
			-- TT_barconfigs[i].color_b = 1
			-- TT_barconfigs[i].showspark = true
			-- TT_barconfigs[i].secondbar = false
			-- TT_barconfigs[i].periodspark = true
			-- TT_barconfigs[i].tickertime = 3
			-- TT_barconfigs[i].tickeroffset = 0
			-- TT_barconfigs[i].from = "player"
			-- TT_barconfigs[i].to = "any"
			-- TT_barconfigs[i].selfbuffmove = true
		-- end
		-- if i == 16 then
			-- TT_barconfigs[i].enabled = true
			-- TT_barconfigs[i].barname = "Devouring Plague"
			-- TT_barconfigs[i].rank = i
			-- TT_barconfigs[i].buff = "DEBUFF"
			-- TT_barconfigs[i].buffname = "Devouring Plague"
			-- TT_barconfigs[i].shortname = "D.Plague"
			-- TT_barconfigs[i].stackable = true
			-- TT_barconfigs[i].fixedsize = false
			-- TT_barconfigs[i].color_r = 0
			-- TT_barconfigs[i].color_g = 0.6
			-- TT_barconfigs[i].color_b = 0
			-- TT_barconfigs[i].showspark = true
			-- TT_barconfigs[i].secondbar = false
			-- TT_barconfigs[i].periodspark = true
			-- TT_barconfigs[i].tickertime = 3
			-- TT_barconfigs[i].tickeroffset = 0
			-- TT_barconfigs[i].from = "player"
			-- TT_barconfigs[i].to = "any"
			-- TT_barconfigs[i].selfbuffmove = true
		-- end


------------------------------------------------------------------------------
------------ bar group defaults ---------------------------------------------
------------------------------------------------------------------------------
	
	for i = 1,2 do
		if i == 1 then
			TT_bargroups[i].name = L.name_maingroup
			TT_bargroups[i].enabled = true
			TT_bargroups[i].sortby = "rank"
		end
		if i == 2 then
			TT_bargroups[i].name = L.name_untargetgroup
			TT_bargroups[i].enabled = true
			TT_bargroups[i].scale = 0.9
			TT_bargroups[i].shortnames = true
			TT_bargroups[i].sortby = "dest"
			TT_bargroups[i].subsortby = "time"
			TT_bargroups[i].appendtarget = true
		end
	end

-------------------------------------------------------------------------------
--------------  copy defaults to the first profile ----------------------------
-------------------------------------------------------------------------------
	
	TT_profiles[1].mainoptions = TT_mainoptions;
	TT_profiles[1].barconfigs = TT_barconfigs;
	TT_profiles[1].baroptions = TT_baroptions;
	TT_profiles[1].bargroups = TT_bargroups;
	TT_profiles[1].cpoptions = TT_cpoptions;
	TT_profiles[1].kickeroptions = TT_kickeroptions;
	TT_profiles[1].puoptions = TT_puoptions;
	TT_profiles[1].puconfigs = TT_puconfigs;
	TT_profiles[1].pmoptions = TT_pmoptions;
	TT_profiles[1].pmconfigs = TT_pmconfigs;
	
	-- name the default profile from the locale description
	TT_profiles[1].profilename = L.default
	
	--- set the default profile active
	TT_ap = 1;
	
	
	-- can we free some memory?
	
	-- TT_mainoptions = nil
	-- TT_barconfigs = nil
	-- TT_baroptions = nil
	-- TT_bargroups = nil
	-- TT_cpoptions = nil
	-- TT_kickeroptions = nil
	-- TT_puoptions = nil
	-- TT_puconfigs = nil
	-- TT_pmoptions = nil
	-- TT_pmconfigs = nil
	
	--announce defaults loaded completed to chatlog
	AzMsg(L.defaults_loaded)

end

function ThievesTools:UpgradeProfiles()
	
	for i = 1, #TT_profiles do
		for j = 0, #TT_profiles[i].barconfigs do
			if not TT_profiles[i].barconfigs[j].icdbar then
				TT_profiles[i].barconfigs[j].icdbar = false --create a bar to track the cooldown/ICD
				TT_profiles[i].barconfigs[j].icdbargroup = 2 --which group to show the cooldown on
				TT_profiles[i].barconfigs[j].icdflash = false --flash the cooldown bar at this value
				TT_profiles[i].barconfigs[j].icdlength = 0 --length of the cooldown
				TT_profiles[i].barconfigs[j].icdlengthdetect = false --boolean, attempt icd estimation when unknown
			end
			--v0.13 flashlow fix
			if TT_profiles[i].barconfigs[j].flashlow then 
				TT_profiles[i].barconfigs[j].flashlow = true
				TT_profiles[i].barconfigs[j].flashlowtime = 5
			end
				
			--v0.15 fixed duration aura config
			if not TT_profiles[i].barconfigs[j].fixeddur then
				TT_profiles[i].barconfigs[j].fixeddur = false
				TT_profiles[i].barconfigs[j].fixeddurlength = 0
			end
			
			--v0.18 defaults for bargroups
			if not TT_profiles[i].bargroups[0] then
				TT_profiles[i].bargroups[0] = {
					name = L.bargroup_newgroup,
					scale = 1,
					shortnames = false,
					appendtarget = false,
					prefixsource = false,
					enabled = true,
					growup = false,
					alignright = false,
					sortby = "time",--options are time, dest-time, source-time, rank-time, dest-rank, source-rank
					subsortby = "dest",
					posx = 0, -- relative to TTf_main
					posy = 0,
					misc1 = 0,
					misc2 = 0,
				}
			end
			
			
			--v0.19 announcement default changes, updatecharges option
			-- if (TT_profiles[i].barconfigs[j].announcetimeleft == false) or (TT_profiles[i].barconfigs[j].announcetimeleft == true) then
				-- TT_profiles[i].barconfigs[j].announcetimeleft = 0
			-- end
			-- if (TT_profiles[i].barconfigs[j].announceeverysec == nil) then
				-- TT_profiles[i].barconfigs[j].announceeverysec = false
				-- TT_profiles[i].barconfigs[j].announcecriteria = "TIME"
			-- end
			if (TT_profiles[i].barconfigs[j].updatecharges == nil) then
				TT_profiles[i].barconfigs[j].updatecharges = false
			end
			
			--v0.23
			if (TT_profiles[i].barconfigs[j].announceexp == nil) then
				TT_profiles[i].barconfigs[j].announceexp = false
			end
			if (TT_profiles[i].barconfigs[j].checkmissing == nil) then
				TT_profiles[i].barconfigs[j].checkmissing = false
			end
			
			--v0.24
			if (TT_profiles[i].barconfigs[j].suppress == nil) then
				TT_profiles[i].barconfigs[j].suppress = false
			end
		end
	end

end

---this function is to test profile creation, delete it eventually
function ThievesTools:copyprofiletest()

	TT_profiles[2].mainoptions = TT_profiles[1].mainoptions
	TT_profiles[2].barconfigs = TT_profiles[1].barconfigs
	TT_profiles[2].baroptions = TT_profiles[1].baroptions
	TT_profiles[2].bargroups = TT_profiles[1].bargroups
	TT_profiles[2].cpoptions = TT_profiles[1].cpoptions
	TT_profiles[2].kickeroptions = TT_profiles[1].kickeroptions
	TT_profiles[2].puoptions = TT_profiles[1].puoptions
	TT_profiles[2].puconfigs = TT_profiles[1].puconfigs
	TT_profiles[2].pmoptions = TT_profiles[1].pmoptions
	TT_profiles[2].pmconfigs = TT_profiles[1].pmconfigs
end


	