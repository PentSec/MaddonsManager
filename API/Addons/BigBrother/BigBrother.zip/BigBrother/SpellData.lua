local _, BigBrother = ...

-- All SpellIDs go here
local SpellData = {}

SpellData.flasks = {
	-- Burning Crusade
	42735, -- Flask of Chromatic Wonder
	-- WotLK
	53752, -- Lesser Flask of Toughness
	53755, -- Flask of the Frost Wyrm
	53758, -- Flask of Stoneblood
	53760, -- Flask of Endless Rage
	54212, -- Flask of Pure Mojo
	62380, -- Lesser Flask of Resistance
	67019, -- Flask of the North
}

SpellData.elixirsGuardian = {
	-- Burning Crusade
	28502, -- Major Armor
	28509, -- Greater Mana Regeneration
	28514, -- Empowerment
	39625, -- Elixir of Major Fortitude
	39626, -- Earthen Elixir
	39627, -- Elixir of Draenic Wisdom
	39628, -- Elixir of Ironskin
	-- WotLK
	53747, -- Elixir of Spirit
	60347, -- Elixir of Mighty Thoughts
	53764, -- Elixir of Mighty Mageblood
	53751, -- Elixir of Mighty Fortitude
	53763, -- Elixir of Protection
	60343, -- Elixir of Mighty Defense
}

SpellData.elixirsBattle = {
	-- Burning Crusade
	28490, -- Major Strength 
	28491, -- Healing Power 
	28493, -- Major Frost Power 
	28501, -- Major Firepower 
	28503, -- Major Shadow Power 
	33720, -- Onslaught Elixir 
	33721, -- Spellpower Elixir
	33726, -- Elixir of Mastery 
	38954, -- Fel Strength Elixir
	45373, -- Bloodberry 
	54452, -- Adept's Elixir 
	54494, -- Major Agility 
	-- WotLK
	53746, -- Wrath Elixir
	53749, -- Guru's Elixir
	53748, -- Elixir of Mighty Strength
	28497, -- Elixir of Mighty Agility
	60346, -- Elixir of Lightning Speed
	60344, -- Elixir of Expertise
	60341, -- Elixir of Deadly Strikes
	60345, -- Elixir of Armor Piercing
	60340, -- Elixir of Accuracy
}

SpellData.foods = {
	35272, -- Well Fed
	43763, -- Food
}

SpellData.crowdControl = {
	118,   -- Polymorph
	9484,  -- Shackle Undead
	2637,  -- Hibernate
	3355,  -- Freezing Trap Effect
	6770,  -- Sap
	20066, -- Repentance
	5782,  -- Fear
	2094,  -- Blind
	51514, -- Hex
}

SpellData.misdirect = {
	34477, --Misdirection
	57934, --Tricks of the Trade
}

SpellData.taunt = {
	355, --Warrior Taunt
	6795, --Druid Growl
	20736, --Hunter Distracting Shot
	51399, --Death Knight Death Grip
	56222, --Death Knight Dark Command
	62124, --Paladin Hand of Reckoning
}
SpellData.tauntAoE = {
	1161, --Warrior Challenging Shout
	5209, --Druid Challenging Roar
	31789, --Paladin Righteous Defense
}

--used with SPELL_MISS
SpellData.interrupts = {
	[47528] = true, -- Death Knight Mind Freeze
	[47476] = true, -- Death Knight Strangulate
	[5211] = true, -- Druid Bash
	--[19675] = true, -- Druid Feral Charge (Bear)
	--[34490] = true, -- Hunter Silencing Shot
	[2139] = true, -- Mage Counterspell
	--[853] = true, -- Paladin Hammer of Justice
	[15487] = true, -- Priest Silence
	[1766] = true, -- Rogue Kick
	[57994] = true, -- Shaman Wind Shock
	--[19244] = true, -- Warlock Spell Lock
	[72] = true, -- Warrior Shield Bash
	[6552] = true, -- Warrior Pummel
	--[25046] = true, -- Blood Elf Arcane Torrent
}

SpellData.combatRes = {
	[48477] = true, -- Druid Rebirth
}


BigBrother.SpellData = SpellData
