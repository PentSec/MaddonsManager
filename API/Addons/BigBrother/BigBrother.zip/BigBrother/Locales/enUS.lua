local L = LibStub("AceLocale-3.0"):NewLocale("BigBrother", "enUS", true)
--sed -n s/.*\(L\[.*\]\).*/\1/gp *.lua

-----------------------------
--Settings

L["Open settings."] = true


-----------------------------
--Checks

L["Quick Check"] = true
L["A quick report that shows who does not have flasks, elixirs or food."] = true

L["Checks"] = true

L["Set what is included in the Quick Check"] = true
L["Flasks/Elixirs"] = true
L["Include flasks and elixirs in checks"] = true
L["Food Buffs"] = true
L["Include food buffs in checks"] = true
L["Check on Ready Check"] = true
L["Quick Check in raid chat when starting a ready check"] = true

L["Checked Raid Groups"] = true
L["Set which raid groups are checked for buffs"] = true
L["Use Raid Difficulty"] = true
L["Use the currently selected raid difficulty to determine which groups to check"] = true
L["Group 1"] = true
L["Group 2"] = true
L["Group 3"] = true
L["Group 4"] = true
L["Group 5"] = true
L["Group 6"] = true
L["Group 7"] = true
L["Group 8"] = true

L["One Elixir"] = true
L["No Flask"] = true
L["Not Well Fed"] = true


-----------------------------
--Alerts

L["Alerts"] = true

L["Report"] = true
L["Set what is reported to chat"] = true
L["Crowd Control"] = true
L["Report when a player breaks a crowd control effect"] = true
L["Misdirect"] = true
L["Report who gains Misdirection"] = true
L["Taunt"] = true
L["Report taunts"] = true
L["Interrupts"] = true
L["Report interrupts"] = true
L["Combat Resurrection"] = true
L["Report battle resurrection casts"] = true

L["Output"] = true
L["Set where the alert output is sent"] = true
L["Self"] = true
L["Reports alerts to yourself"] = true
L["Group"] = true
L["Reports alerts to party or raid chat"] = true
L["Party"] = true
L["Reports alerts to party chat"] = true
L["Raid"] = true
L["Reports alerts to raid chat"] = true
L["Guild"] = true
L["Reports alerts to guild chat"] = true
L["Officer"] = true
L["Reports alerts to officer chat"] = true

L["Settings"] = true
L["Use Spell Links"] = true
L["Display spell names as clickable spell links"] = true
L["Group Only"] = true
L["Only report events from players in your party or raid group"] = true

L["%s on %s removed by %s"] = true
L["%s on %s removed by %s's %s"] = true
L["%s cast %s"] = true
L["%s cast %s on %s"] = true
L["%s cast %s on %s (%s)"] = true
L["%s interrupted %s's %s with %s"] = true


-----------------------------
--Buff Check

L["Buff Check"] = true
L["Pops up a window to check raid buffs (drag the bottom to resize)."] = true

L["Limit size"] = true
L["Limits the number of rows shown to the number of people in your group (minimum: %d, maximum: %d)"] = true
L["Show temporal buffs"] = true
L["Include short duration buffs, totems, and auras when checking buffs"] = true
 
L["Raid Buffs"] = true
L["Paladin Buffs"] = true
L["Consumables"] = true


-----------------------------
--LDB

L["|cffff8040Left Click|r to toggle the buff window"] = true
L["|cffff8040Right Click|r to open the options window"] = true
L["Hide minimap button"] = true
