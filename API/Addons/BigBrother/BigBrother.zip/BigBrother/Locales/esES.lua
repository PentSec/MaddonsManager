local L = LibStub("AceLocale-3.0"):NewLocale("BigBrother", "esES")
if not L then return end

--@localization(locale="esES", format="lua_additive_table")@
