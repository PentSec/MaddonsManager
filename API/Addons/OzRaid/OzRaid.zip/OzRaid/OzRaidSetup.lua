OZ_Windows	= {}
OZ_Config	= {}
OZ_Bars		= {}
OZ_Input	= {}
OZ_CustomBuffDesc = {}

local function gg(text)
	local ret = _G[text] --getglobal(text)
	if(not ret) then
		DEFAULT_CHAT_FRAME:AddMessage("|c00FF8800".."OzRaid: Failed to find: "..text);
	end
	return ret
end
local function print(text)
	DEFAULT_CHAT_FRAME:AddMessage("|c0033CCFF"..text);
end

OZ_MAX_BARS = 80
OZ_MAX_BUFFS = 6
OZ_MAX_DEBUFFS = 3
OZ_NWINDOWS	= 1
OZ_CURRENT_VERSION = 1.80

function OZ_AddWindow()
	local c
	OZ_NWINDOWS = OZ_NWINDOWS + 1
	OZ_SetupConfig(OZ_NWINDOWS)
	OZ_InitWindow(OZ_NWINDOWS)
	OZ_Config.nWindows = OZ_NWINDOWS;
end

function OZ_RemoveWindow(n)
	local h, frame, c
	h = OZ_Windows[OZ_NWINDOWS].frame:GetHeight()
	OZ_Windows[OZ_NWINDOWS].frame:Hide()

	if n<OZ_NWINDOWS then
		-- Copy the last window into the place of the one we are removing...
		OZ_Config[n] = OZ_Config[OZ_NWINDOWS]
		OZ_InitWindow(n)
	end

	-- Now delete the config for the last window
	OZ_Config[OZ_NWINDOWS] = nil
	OZ_NWINDOWS = OZ_NWINDOWS - 1
	OZ_Config.nWindows = OZ_NWINDOWS;
end

function OZ_GetWindowTop(frame,growup)
	local anchor,_,rel,ox,oy = frame:GetPoint(1)
	local w = frame:GetWidth()
	local h = frame:GetHeight()
	local hw = w * 0.5
	local hh = h * 0.5
	if anchor=="TOP" then
		ox = ox
		oy = oy
	elseif anchor=="TOPLEFT" then
		ox = ox+hw
		oy = oy
	elseif anchor=="TOPRIGHT" then
		ox = ox - hw
		oy = oy
	elseif anchor=="LEFT" then
		ox = ox + hw
		oy = oy + hh
	elseif anchor=="CENTER" then
		ox = ox
		oy = oy + hh
	elseif anchor=="RIGHT" then
		ox = ox - hw
		oy = oy + hh
	elseif anchor=="BOTTOMRIGHT" then
		ox = ox - hw
		oy = oy + h
	elseif anchor=="BOTTOMLEFT" then
		ox = ox + hw
		oy = oy + h
	elseif anchor=="BOTTOM" then
		ox = ox
		oy = oy + h
	else
		print("ERROR: Anchor point is not recognised: "..anchor);
	end
	if(growup) then
		return "BOTTOM",nil,rel,ox,oy - h
	end
	return "TOP",nil,rel,ox,oy
end

function OZ_DragStart()
    if this.moving then return end
    if IsAltKeyDown() or (not OZ_Config[ this:GetID() ].locked and not InCombatLockdown()) then
		this:StartMoving();
		this.moving = true;
	end
end

function OZ_DragStop()
	local i,_
	if (this.moving) then
		this:StopMovingOrSizing();
		this.moving = false;
	end
	-- Now record new position in config
	i = this:GetID()
	local c = OZ_Config[i]
	c.Anchor,_,c.Relative,c.ax,c.ay = OZ_GetWindowTop(this,c.growup)
	if not InCombatLockdown() then
		this:ClearAllPoints()
		this:SetPoint(c.Anchor,nil,c.Relative,c.ax,c.ay)
	end
end

function OZ_SetupWindowPointers(n)
	local name,frame,c;
	name = "OzRaid_Frame"..n
	frame = getglobal(name)
	c = OZ_Config[n]
	if( not frame ) then
		-- Dynamically create a new window
		frame = CreateFrame( "Frame", name, nil, "OZ_WindowTemplate" )
		frame.tNext = 0;
		frame:ClearAllPoints()
		frame:SetPoint(c.Anchor,nil,c.Relative,c.ax,c.ay)
		frame:SetID(n)

		OZ_Windows[n] = {
			-- Shortcuts to various UI elements
			frame		= frame,
			titleFrame	= gg(name.."Title"),
			name		= gg(name.."TitleName"),
			nameText	= gg(name.."TitleNameText"),
			background	= gg(name.."TitleBackground"),
			marker		= gg(name.."TableMarker"),

			close		= gg(name.."TitleClose"),
			options		= gg(name.."TitleOptions"),

			table		= gg(name.."Table"),
			n	= n,
		};
		if not OZ_Windows[n].bar then
			OZ_Windows[n].bar = {}
		end
	end
	OZ_Windows[n].config = c;
	if not OZ_Bars[n] then
		OZ_Bars[n]	= {
			nBars = 0,
			bar = {},
		};
	end
end

function OzDropDown_OnLoad()
	UIDropDownMenu_Initialize(this, OzDropDown_Initialize, "MENU");
end

local Oz_MenuUnit = nil
function OZ_showmenu()
--print("Menu up, this frame is: "..this:GetName())
	Oz_MenuUnit = this.unit;
	ToggleDropDownMenu(1, nil, OzDropDown, "cursor", 0, 0);
end

function OZDumpTable(src, indent, norecurse)
	indent = indent or 0;
	if indent>2 then return; end

	local root,ret,key,val;    
	root = "> ";
	for i=0,indent do
		root = root.." - ";
	end
	
	for key,val in pairs(src) do
		ret = root;
		local kType = type(key);
		if kType=="table" then
			ret = ret.."TABLE"
		elseif kType=="function" then
			ret = ret.."function()"
		elseif kType=="number" or kType=="string" then
			ret = ret..key
		else
			ret = ret.."<"..kType..">"
		end
		local vType = type(val)
		if(vType=="table") then
			print(ret.." = table:");
            if not norecurse then OZDumpTable(val, indent + 1) end
		elseif(vType=="boolean") then
			if val then
				print(ret.." = TRUE");
			else
				print(ret.." = FALSE");
			end
		elseif(vType=="function") then
				print(ret.." = function()");        
		elseif vType=="string" or vType=="number" then
			print(ret.." = "..val);
		else
			print(ret.."= <"..vType..">")
		end
	end
end

local info = UIDropDownMenu_CreateInfo();

function OzDropDown_Initialize(self,level)
	local menu;
	local name;
	local id = nil;
	local unit = "mouseover"
	level = level or 1;
	if(Oz_MenuUnit) then
		unit = Oz_MenuUnit
	end
	
	if(level == 1) or (UIDROPDOWNMENU_MENU_VALUE ~= "MT_SET") then
		if ( UnitIsUnit(unit, "player") ) then
			menu = "SELF";
			unit = "player"
		elseif ( UnitIsUnit(unit, "pet") ) then
			menu = "PET";
			unit = "pet"
		elseif ( UnitIsPlayer(unit) ) then
			id = UnitInRaid(unit);
			if ( id ) then
				menu = "RAID_PLAYER";
			elseif ( UnitInParty(unit) ) then
				menu = "PARTY";
			else
				menu = "PLAYER";
				unit = "player"
			end
		else
			menu = "RAID_TARGET_ICON";
			name = RAID_TARGET_ICON;
		end
		if ( menu ) then
	--print("Menu: "..menu..", Unit = "..unit)
			UnitPopup_ShowMenu(OzDropDown, menu, unit, UnitName(unit), id);
		end
		
		if (level == 1) and oRA and ( menu=="SELF" or menu=="RAID_PLAYER" or menu=="PARTY" ) then           
			info.hasArrow = false; -- creates submenu
			info.notCheckable = true;
			info.text = "Refresh MT list";
			info.value = "MT_REFRESH";
			info.func = function() oRA:TriggerEvent("oRA_JoinedRaid"); end
			UIDropDownMenu_AddButton(info, 1);
			
			if IsRaidOfficer() or IsRaidLeader() then
				info.hasArrow = true; -- creates submenu
				info.notCheckable = true;
				info.text = "Set MT (oRA)";
				info.value = "MT_SET";
				UIDropDownMenu_AddButton(info, 1);
			end
		end
		
	elseif( oRA ) then
		if not (oRA.modules.LeaderMT) and (IsRaidOfficer() or IsRaidLeader()) then
			oRA:TriggerEvent("oRA_JoinedRaid")
			oRA:TriggerEvent("oRA_PlayerPromoted")
		end
	   
		local name = UnitName(Oz_MenuUnit)
		if (oRA.modules.LeaderMT) then            
			for i = 1,10 do
				info.hasArrow = false; -- creates submenu
				info.notCheckable = false;
				if oRA.maintanktable[i] == name then
					info.text = "Remove MT "..i;
					info.checked = true;
					info.func = function() oRA.modules.LeaderMT:Remove(i); OZ_InputFunctions[8].always=-20; end
				else
					info.text = "Set as MT "..i;
					info.checked = false;
					info.func = function() oRA.modules.LeaderMT:Set(i,Oz_MenuUnit); OZ_InputFunctions[8].always=-20; end
				end
				info.value = "MT_SET_"..i;
				UIDropDownMenu_AddButton(info, 2);
			end
		end            
	end
end

function OZ_GetBar( window, x )
	if not window.bar[x] then
		local n = window.n
		local name = "OzRaid_Frame"..n.."TableRow"..x
		local bar

		if not ClickCastFrames then ClickCastFrames = {} end
		if not window.moveable then
			bar = CreateFrame( "Frame", name, window.table, "OZ_RowTemplate" )
		else
			bar = CreateFrame( "Frame", name, window.table, "OZ_RowTemplateINFO" )
		end
		
		local data = {
			frame		= bar,
			header		= gg(name.."Header"),
			headerText	= gg(name.."HeaderText"),
			barFrame	= gg(name.."BarFrame"),
			bar			= gg(name.."BarFrameBar"),
			incoming	= gg(name.."BarFrameBarInc"),
			glow		= gg(name.."BarFrameBarGlow"),
			icon		= gg(name.."BarFrameIcon"),
			iconTex		= gg(name.."BarFrameIconIcon"),
			iconNum		= gg(name.."BarFrameIconText"),
			icon2		= gg(name.."BarFrameIcon2"),
			icon2Tex	= gg(name.."BarFrameIcon2Icon"),
			icon2Num	= gg(name.."BarFrameIcon2Text"),
			name		= gg(name.."BarFrameName"),
			nameText	= gg(name.."BarFrameNameText"),
			value		= gg(name.."BarFrameValue"),
			valueText	= gg(name.."BarFrameValueText"),
			bValue		= gg(name.."BarFrameBigValue"),
			bValueN		= gg(name.."BarFrameBigValueHundreds"),
			bValueK		= gg(name.."BarFrameBigValueThousands"),
			buff		= { gg(name.."BarFrameBuff1"),
								gg(name.."BarFrameBuff2"),
								gg(name.."BarFrameBuff3"),
								gg(name.."BarFrameBuff4"),
								gg(name.."BarFrameBuff5"),
								gg(name.."BarFrameBuff6") },
			buffTex		= { gg(name.."BarFrameBuff1Icon"),
								gg(name.."BarFrameBuff2Icon"),
								gg(name.."BarFrameBuff3Icon"),
								gg(name.."BarFrameBuff4Icon"),
								gg(name.."BarFrameBuff5Icon"),
								gg(name.."BarFrameBuff6Icon") },
			buffCool	= { gg(name.."BarFrameBuff1Cooldown"),
								gg(name.."BarFrameBuff2Cooldown"),
								gg(name.."BarFrameBuff3Cooldown"),
								gg(name.."BarFrameBuff4Cooldown"),
								gg(name.."BarFrameBuff5Cooldown"),
								gg(name.."BarFrameBuff6Cooldown") },
			buffNum			= { gg(name.."BarFrameBuff1Text"),
								gg(name.."BarFrameBuff2Text"),
								gg(name.."BarFrameBuff3Text"),
								gg(name.."BarFrameBuff4Text"),
								gg(name.."BarFrameBuff5Text"),
								gg(name.."BarFrameBuff6Text") },
			buffVal		= {},
		};
		window.bar[x] = data
		data.icon:EnableMouse(false);
		data.icon2:EnableMouse(false);

		bar:SetID(x)
		if not window.moveable then
			SecureUnitButton_OnLoad( data.barFrame, "player", OZ_showmenu )
			data.barFrame:SetAttribute("type1", "target")
			ClickCastFrames[gg(name.."BarFrame")] = true
		end


		local config = OZ_Config[n]

		-- reset all the text sizes
		bw = config.textSize

		data.headerText:SetFont(STANDARD_TEXT_FONT,bw)
		local textEffect;
		if config.outlineNames then
			textEffect = "OUTLINE"
		end
		data.nameText:SetFont(STANDARD_TEXT_FONT,config.nameSize,textEffect)
		data.valueText:SetFont(STANDARD_TEXT_FONT,config.numSize,textEffect)
		data.bValueN:SetFont(STANDARD_TEXT_FONT,config.numSize*0.5,textEffect)
		data.bValueK:SetFont(STANDARD_TEXT_FONT,config.numSize,textEffect)
		data.bValN = nil
		data.bValK = nil

		OZ_FormatRow( n, x )

		if x == 1 then
			bar:SetPoint("TOP", window.table, "TOP")
		else
			bar:SetPoint("TOP", window.bar[x-1].frame, "BOTTOM")
		end
	end
	return window.bar[x]
end

function OZ_SetupConfig(n)
	OZ_Config[n] = {
		active = 1,
		width = 120,
		refresh = 0.2,
		ax = 350,
		ay = 0,
		Relative = "LEFT",
		Anchor = "TOP",

		maxBars = 40,
		minBars = 1,
		barHeight = 16,
		barGap = 0,

		titleHeight = 20,
		text = "OzRaid "..n,
		textSize = 10,
		topCol = {a=1,b=1,g=1,r=0},
		bottomCol = {a=1,b=0.6,g=0,r=0},
		buttonSize = 16,

		valueType = 2,
		numSize = 14,

		input = 1,
		
		sort1 = 3,sort2 = 0,sort3 = 0,
		heading = {3,0,0},

		colour = 2,
		barDebuffCol = 1,
		
		fadeAlpha = 0.4,        
		
		nameSize = 12,
		namePos = 4,
		outlineNames = 1,
		nameOnStatus = 1,
		classNames = 1,

		buffPos = 2,
		buffSize = 1,
		icon = 1,

--		buffsPlayer = {},
		--buffsMob = {},
		buff_combat = { {}, {}, {}, {} },
		buff_ooc = { {}, {}, {}, {} },		

		filter = {
			group = {1,1,1,1,1,1,1,1},
			injuredVal = 0.8,
			status = {
				inrange = 1,
				close = 1,
				curable = 1,
				buffed = 1,
				outofrange = 1,
				online = 1,
				notbuffed = 1,
				injured = 1,
				dead = 1,
				offline = 1,
				healthy = 1,
				notcurable = 1,
			},
			class = {
				DEATHKNIGHT = 1,
				HUNTER = 1,
				WARRIOR = 1,
				TARGET = 1,
				PALADIN = 1,
				MAGE = 1,
				PRIEST = 1,
				WARLOCK = 1,
				PET = 1,
				DRUID = 1,
				SHAMAN = 1,
				ROGUE = 1,
				HUNTERPET = 1,
			},
		},
	};
	-- Init buff arays with the class defaults
	local class,fileName = UnitClass("player")
--print("OzRaid: class="..class..", fName="..fileName);
	local i = 1
	for key,value in ipairs(OZ_BUFF_DEFAULT[fileName].Player) do
		local bName = value[3]
		if not string.find(bName,"Interface") then
			bName = "Interface\\Icons\\"..value[3]
		end
		OZ_Config[n].buff_combat[value[4]][bName] = { value[1], value[2], bName, value[4] }
		OZ_Config[n].buff_ooc[value[4]][bName] = { value[1], value[2], bName, value[4] }
	end

	for key,value in ipairs(OZ_BUFF_DEFAULT[fileName].Mob) do
		local bName = value[3]
		if not string.find(bName,"Interface") then
			bName = "Interface\\Icons\\"..value[3]
		end
		OZ_Config[n].buff_combat[value[4]][bName] = { value[1], value[2], bName, value[4] }
		OZ_Config[n].buff_ooc[value[4]][bName] = { value[1], value[2], bName, value[4] }
	end
end

function OZ_BuffFindType(texName, root)
	if not root then
		root = OZ_BUFF_TABLE
	end
	
	local k,v;
	if root.noLeaf then
		-- Not a leafy branch - recurse...
		for k,v in pairs(root) do
			if type(v) == "table" then
				local ret = OZ_BuffFindType(texName, v)
				if ret then 
					return ret
				end
			end
		end
	else
		for k,v in pairs(root) do
			if type(v) == "table" then
				if v[3] and type(v[3])=="string" then
					if texName == "Interface\\Icons\\"..v[3] or texName==v[3] then
						return v[4]
					end
				end
			end
		end
	end
	return nil
end

function OZ_ConvertBuffList(config,src)
local b
if not config then print("No config!"); return end
	if src then
		for k,v in pairs(src) do
			if type(k) == "string" then
				b = OZ_BuffFindType(k)
				if b then
					config.buff_combat[b][k] = {v[1],v[2],k,b};
					config.buff_ooc[b][k] = {v[1],v[2],k,b}
				end
			else -- Old style config
				b = OZ_BuffFindType(v[3])
				if b then
					config.buff_combat[b][v[3]] = {v[1],v[2],k,b}
					config.buff_ooc[b][v[3]] = {v[1],v[2],k,b}
				end
			end
		end
	end
end
function OZ_CountTableEntries(tab,dontSet)
--print("Counting...")
--OZDumpTable(tab,0,1)

    local k,v,i
    i = 0
    for k,v in pairs(tab) do
        i = i + 1
    end

    if tab.count then i = i - 1 end
--print("total = "..i)
    if not dontSet then tab.count = i end
    return i
end
function OZ_CountWatchedBuffs(n)
    OZ_CheckNewBuffs(n)
	local config = OZ_Config[n]
    OZ_CountTableEntries(config.buff_combat[1])
    OZ_CountTableEntries(config.buff_combat[2])
    OZ_CountTableEntries(config.buff_combat[3])
    OZ_CountTableEntries(config.buff_combat[4])
    OZ_CountTableEntries(config.buff_ooc[1])
    OZ_CountTableEntries(config.buff_ooc[2])
    OZ_CountTableEntries(config.buff_ooc[3])
    OZ_CountTableEntries(config.buff_ooc[4])
end
function OZ_CheckNewBuffs(n)
	local config = OZ_Config[n]
	if not config.buff_combat then
		config.buff_combat = {
			[1] = { -- Player HELP
			},
			[2] = { -- Mob HELP
			},
			[3] = { -- Player HARM
			},
			[4] = { -- Mob HARM
			},
		}
		config.buff_ooc = {
			[1] = { -- Player HELP
			},
			[2] = { -- Mob HELP
			},
			[3] = { -- Player HARM
			},
			[4] = { -- Mob HARM
			},
		}
		--config.buffs = nil --config.buff_ooc;
		OZ_ConvertBuffList(config,config.buffsPlayer)
		OZ_ConvertBuffList(config,config.buffsMob)
		--config.buffsPlayer = nil
		--config.buffsMob = nil
        OZ_CountWatchedBuffs(n)
	end
end


function OZ_SetupSortBuffer()
	OZ_Input	= {
		["nBars"] = 0,
		["bar"] = {},
	};

	for x = 1 , OZ_MAX_BARS do
		OZ_Input.bar[x]= {
			-- Position of data in the raid roster
			["roster"]		= 0,
			["target"]		= 0,

			-- Bar values (min,max,fraction)
			["max"]			= 1000,
			["current"]		= 500,
			["value"]		= 0.5,

			-- Buffs
			["buffs"]		= { {},{},{},{},{},{} },
			["debuffs"]		= nil,
		};
	end
end

function OZ_ConfigTitleBar(n)
	local window = OZ_GetWindowArray(n)
	local config = OZ_Config[n]
	
	if(config.hideTitle)then
		window.titleFrame:SetHeight(0.1)
		window.titleFrame:Hide()
	else
		window.titleFrame:SetHeight(config.titleHeight)
		window.titleFrame:Show()

		window.background:SetHeight(42)
		window.background:SetGradientAlpha("VERTICAL",
				config.bottomCol.r,
				config.bottomCol.g,
				config.bottomCol.b,
				config.bottomCol.a,
				config.topCol.r,
				config.topCol.g,
				config.topCol.b,
				config.topCol.a);

		local tw, th, bw;
		if(config.hideButtons)then
			tw = config.width - 6
			window.nameText:SetJustifyH("CENTER")
		else
			tw = config.width - (config.buttonSize*2) - 6
			window.nameText:SetJustifyH("LEFT")
		end
		th = config.titleHeight
		bw = config.buttonSize

		window.name:SetWidth(tw)
		window.name:SetHeight(th)

		window.nameText:SetText(config.text)
		window.nameText:SetWidth(tw)
		window.nameText:SetHeight(th)
		window.nameText:Show()
		
		window.close:SetWidth( bw )
		window.options:SetWidth( bw )
		window.close:SetHeight( bw)
		window.options:SetHeight( bw )

		if(config.hideButtons)then
			window.close:Hide()
			window.options:Hide()
		else
			window.close:Show()
			window.options:Show()
		end

	end

	if(config.hideBG)then
		window.frame:SetBackdrop(nil)
	else
		window.frame:SetBackdrop({	bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
											edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
											tile = true, tileSize = 16, edgeSize = 16, 
											insets = { left = 4, right = 4, top = 4, bottom = 4 }});
		window.frame:SetBackdropBorderColor(0.4, 0.4, 0.4)
		window.frame:SetBackdropColor(0.09, 0.09, 0.19)
	end
end

function OZ_InitDefaultConfig()
	OZ_Config = {}
	OZ_SetupConfig(1)

	OZ_Config.minimapAngle = 26
	OZ_Config.minimapDist  = 80
	OZ_Config.minimapShow  = 1

	OZ_Config.nWindows = 1
	OZ_NWINDOWS = 1
	OZ_Config.version = OZ_CURRENT_VERSION
	
end

function OzRaid_OnLoad()
	local i
	this:RegisterForDrag("LeftButton");
	OZ_SetupEvents()

	OZ_InitDefaultConfig()
	OZ_SetupRaidRoster()
	OZ_SetupSortBuffer()
	DEFAULT_CHAT_FRAME:AddMessage("|c0033CCFF".."OzRaid Loaded!");
end

function OzRaidLoadSavedVariables()
	OZ_SetupAfterLoad()
end

function OZ_InitWindow(n)
	local i,window

	OZ_SetupWindowPointers(n)
	window = OZ_Windows[n]

--	window.frame:RegisterForDrag("LeftButton") 
	window.frame:SetMovable(true)
	window.frame:SetUserPlaced(true)

	window.frame:SetWidth(OZ_Config[n].width)
	window.frame:SetHeight(60)
	window.frame.lastUpdate = 0

	window.marker:SetWidth( 60 )
	window.marker:SetHeight( 60 )

	OZ_ConfigTitleBar(n)

	OZ_SetFromConfig(n)
	-- reset all the text sizes
	OZ_CheckVisibility(n)
end

function OZ_SetFromConfig(n)
	local config = OZ_Config[n]
	-- reset all the text sizes
	bw = config.textSize
	local window = OZ_GetWindowArray(n)

	-- New - check if we are a moveable one or not...
	local status = config.filter.status
	local oldState = window.moveable
	if  (config.sort1==0 or config.sort1==3 or config.sort1==4) and
		(config.sort2==0 or config.sort2==3 or config.sort2==4) and
		(OZ_InputFunctions[config.input].combat) and
		status.healthy == 1 and
		status.injured == 1 and
		status.curable == 1 and
		status.notcurable == 1 and
		status.buffed == 1 and
		status.notbuffed == 1 and
		status.outofrange == 1 and
		status.dead == 1 and
		status.offline == 1 and
		status.online == 1 then
		-- Ok, this window has NO dynamic changes
		window.moveable = nil
	else
		-- Ok, we are a dynamically changing frame
		window.moveable = 1
	end
	-- We MUST check to see if we used to be protected
	if window.bar[1] and window.moveable ~= oldState then
		-- Ok, we have been initialised before, and so these bars are WRONG
		print("WARNING: "..config.text.." window needs to change security state. Please RELOAD UI!");
	end

	window.nameText:SetFont(STANDARD_TEXT_FONT,bw)
	local textEffect;
	if config.outlineNames then
		textEffect = "OUTLINE"
	end
	for i=1,config.maxBars do
		local bar = window.bar[i]
		if bar then
			bar.headerText:SetFont(STANDARD_TEXT_FONT,bw)
			bar.nameText:SetFont(STANDARD_TEXT_FONT,config.nameSize,textEffect)
			bar.valueText:SetFont(STANDARD_TEXT_FONT,config.numSize,textEffect)
			bar.bValueN:SetFont(STANDARD_TEXT_FONT,config.numSize*0.5,textEffect)
			bar.bValueK:SetFont(STANDARD_TEXT_FONT,config.numSize,textEffect)
			OZ_FormatRow(n,i)
		else
			break
		end
	end

	if not window.frame.moving then
		window.frame:ClearAllPoints()
		window.frame:SetPoint(config.Anchor,nil,config.Relative,config.ax,config.ay)
	end

	OZ_ConfigTitleBar(n)
	OZ_SetMinimapPos()
	OZ_SetBars(n)
	OZ_CheckVisibility(n)
end


local healSpells = {
	DRUID = "Healing Touch",
	SHAMAN = "Healing Wave",
	PRIEST = "Lesser Heal",
	PALADIN = "Holy Light",
	MAGE = "Remove Lesser Curse"
};

local cleanse = {
	DRUID = { Curse =1,Poison=1},
	SHAMAN = {Curse=1,Poison=1,Disease=1,Purge=1},
	PRIEST = {Disease=1,Magic=1,Purge=1},
	PALADIN = {Poison=1,Disease=1,Magic=1},
	MAGE = {Curse=1,Purge=1}
};
OzPlayerHealSpell = nil
OzPlayerCleanse = nil
OzHealComm = nil


function OZ_InternalBuffUpdate(dest,old,new)
	if dest then
		local t = dest[old]
		if t then
			dest[new] = dest[old]
			dest[new][3] = new
			dest[old] = nil
		end
	end
end
function OZ_UpdateBuffTexture( i,old, new )
	local t
	local config = OZ_Config[i]
	OZ_InternalBuffUpdate(config.buffsMob, old, new)
	OZ_InternalBuffUpdate(config.buffsPlayer, old, new)
	if not config.buff_ooc then config.buff_ooc = { {},{},{},{} }; end
	OZ_InternalBuffUpdate(config.buff_ooc[1], old, new)
	OZ_InternalBuffUpdate(config.buff_ooc[2], old, new)
	OZ_InternalBuffUpdate(config.buff_ooc[3], old, new)
	OZ_InternalBuffUpdate(config.buff_ooc[4], old, new)
	if not config.buff_combat then config.buff_combat = { {},{},{},{} }; end
	OZ_InternalBuffUpdate(config.buff_combat[1], old, new)
	OZ_InternalBuffUpdate(config.buff_combat[2], old, new)
	OZ_InternalBuffUpdate(config.buff_combat[3], old, new)
	OZ_InternalBuffUpdate(config.buff_combat[4], old, new)
end

function OZ_AddPresetWindow(preset1, preset2, x, y)
	local c,window

	OZ_PresetApply(preset1,preset2)
	c = OZ_Config[OZ_OptionsCurrentWindow]

	window = OZ_Windows[OZ_OptionsCurrentWindow]
	window.frame:ClearAllPoints()
	window.frame:SetPoint("TOPLEFT",nil,"TOPLEFT",x,y)
	c.Anchor,_,c.Relative,c.ax,c.ay = OZ_GetWindowTop(window.frame,c.growup)
	window.frame:ClearAllPoints()
	window.frame:SetPoint(c.Anchor,nil,c.Relative,c.ax,c.ay)
	
	c.hideEmpty = nil
	c.hideSolo = nil
	c.hideParty = nil
end
function OZ_InitNewConfig()
	-- Ok, we need to completely clear the old one & create a new set...
	OZ_InitDefaultConfig()
	OZ_OptionsCurrentWindow = 1
	OZ_LoadOptions()
	OZ_AddPresetWindow("Generic","Raid View (No pets)",200,-200)

	OZ_AddWindow()
	OZ_OptionsCurrentWindow = 2
	OZ_AddPresetWindow("Generic","Hunter/Lock pets",370,-200)

	if oRA then
		OZ_AddWindow()
		OZ_OptionsCurrentWindow = 3
		OZ_AddPresetWindow("Main Tanks (oRA)","Main Tanks",540,-200)
		OZ_AddWindow()
		OZ_OptionsCurrentWindow = 4
		OZ_AddPresetWindow("Main Tanks (oRA)","Main Tank Targets",710,-200)
	end
end

function OZ_SetupAfterLoad()

	local i,key,val
	-- Read the current players class
	key,val = UnitClass("player")
	if val then
		OzPlayerHealSpell = healSpells[val]
		OzPlayerCleanse = cleanse[val]
	end
	
	if LibStub then
		OzHealComm = LibStub:GetLibrary("LibHealComm-4.0",1);
--		print("LibHealComm-4 found");
	end
	
	local version = 0
	if(	OZ_Config.version ) then
		version = OZ_Config.version
	end
	if(OZ_Config.nWindows) then
		OZ_NWINDOWS = OZ_Config.nWindows
	else
		OZ_NWINDOWS = 1
	end
--version = 1
	-- Config updating has been cleaned!
	-- v1.63 is nearly a year old, so you really should have updated it by now!
	if(version < 1.63)then
		if(version > 0) then
			print("OzRaid WARNING: Very old config detected! Config is RESET!")
		else
			print("OzRaid - setting up a default configuration...")
		end
		OZ_InitNewConfig()
	end
	if version < 1.64 then
		if OZ_Config[1] then
			if OZ_Config[1].hideparty then
				OZ_Config.pFramesRaid = 2
				OZ_Config.pFramesParty = 2
			else
				OZ_Config.pFramesRaid = 1
				OZ_Config.pFramesParty = 1
			end
		end
	end
	if version < 1.67 then
		for i=1,OZ_Config.nWindows do
			if OZ_Config[i] then
				local c = OZ_Config[i]
				if not c.nameSize then
					c.nameSize = c.textSize
				end
				if not c.numSize then
					c.numSize = c.textSize
				end
				if not c.barGap then
					c.barGap = 0
				end
			end
		end		
	end
	if version < 1.70 then
		for i=1,OZ_Config.nWindows do
			if OZ_Config[i] then
				OZ_Config[i].filter.class.DEATHKNIGHTPET = 1
				OZ_Config[i].filter.class.HUNTERPET = 1
				OZ_Config[i].filter.class.MAGEPET = 1
				OZ_Config[i].filter.class.PRIESTPET = 1
				OZ_Config[i].filter.class.SHAMANPET = 1
				OZ_Config[i].filter.class.WARLOCKPET = 1
			end
		end
		print("OzRaid: Old Config detected - use '/oz reset' if stuff looks broken")
	end
	if version < 1.76 then
		for i=1,OZ_Config.nWindows do
			if OZ_Config[i] then
				OZ_UpdateBuffTexture( i,"Interface\\Icons\\Shadow_Cripple", "Interface\\Icons\\Spell_Shadow_Cripple" )
				OZ_UpdateBuffTexture( i,"Interface\\Icons\\Ability_Druid_Typhoon", "Interface\\Icons\\spell_nature_riptide" )
				OZ_UpdateBuffTexture( i,"Interface\\Icons\\Spell_Shadow_BlackPlague", "Interface\\Icons\\Spell_Shadow_DevouringPlague" )                
			end
			OZ_CheckNewBuffs(i) -- Update buffLists if required
		end
	end
	
	if version < 1.77 then
		-- 1.76 was internal alpha version
		for i=1,OZ_Config.nWindows do
			local c = OZ_Config[i]
			if c then
				if c.barDebuffCol then
					local class,fileName = UnitClass("player")
					local s = OZ_BUFF_DEFAULT[fileName].Player
					for key,val in pairs(s) do
						if val.t and val.col and val.key then
							-- 'val' is a debuff we can cure...
							c.buff_combat[3][val.key] = {val[1],val[2],val[3],val[4], t=val.t, col=val.col}
						end
					end
					
				end
			end
		end
	end
	OZ_Config.version = OZ_CURRENT_VERSION
	OZ_UpdateRoster()
	OZ_SetMinimapPos()
	OZ_Initialised = 1

	for i=1,OZ_NWINDOWS do
		if( not OZ_Config[i] or not OZ_Config[i].bottomCol )then
			print(" Config error! Resetting...")
			OZ_InitNewConfig()
			break;
		end
		OZ_CountWatchedBuffs(i)
	end
end

function OZ_GetWindowArray( n )
	if(not OZ_Windows[n])then
		OZ_InitWindow(n)
	end
	return OZ_Windows[n]
end