-- BUFF DATA
--
-- Data is as:
--  (priority) (text name) (game texture name) (0=Buff for a player, 1=BUFF on a MOB, 3= Debuff on a PLAYER, 4 = DEBUFF on a MOB)
--      BUFF on MoB is a dmg buff (i.e. a player put it tere) A DEBUFF on a mob is a BAD THING you want to see
-- i.e.: PW:S is a BUFF on a player. It leaves a DEBUFF on a player
--       Vipers sting is a BUFF when its on an enemy, but it is a DEBUFF on a friend
-- <class>
--		<Buff> Buffs that this class can do on other players
--		<Pet> Buff icons thepets can have (not used)
--		<Debuff> Debuffs this player can put on mobs
--		<Player> Default important icons for players
--					- Includes major buffs from this class
--		<Mob> Default important debuffs on mobs
--					- Includes this class's debuffs (highest priority)
--					- Important support buffs
--					- Crowd control debuffs
--		<Cure> What debuffs this class can cure
--[[ buffData[4] = buff type
			[1] = { -- Player HELP},
			[2] = { -- Mob HELP},
			[3] = { -- Player HARM},
			[4] = { -- Mob HARM},
]]--
local OZ_MiscDebuffColour = {r=1,g=0,b=1}
local OZ_BossDebuffColour = {r=1,g=1,b=1}

function OZ_SetSpellEntry( spellID, priority, btype, hasCol, col )
	local name, _, icon = GetSpellInfo(spellID)
	if not col then col = OZ_BossDebuffColour; end
	local ret = {priority,name,icon, btype, fDontHide=1};
	if hasCol then ret["col"] = col; end
	return ret 
end

local OZ_MiscDebuffColour = {r=1,g=0,b=1}

OZ_BUFF_TABLE = {
noLeaf = 1,

HUNTER = {
	noLeaf = 1,
	Buff = {
				{0,"Aspect of the Hawk","Spell_Nature_RavenForm", 1},
				{0,"Aspect of the Monkey", "Ability_Hunter_AspectOfTheMonkey", 1},
				{0,"Aspect of the Cheetah", "Ability_Mount_JungleTiger", 1},
				{0,"Aspect of the Pack", "Ability_Mount_WhiteTiger", 1},
				{0,"Aspect of the Beast", "Ability_Mount_PinkTiger", 1},
				{0,"Aspect of the Wild", "Spell_Nature_ProtectionformNature", 1},
				{0,"Aspect of the Viper", "Ability_Hunter_AspectoftheViper", 1},
				{0,"Rapid Fire", "Ability_Hunter_RunningShot", 1},
				{0,"Eyes of the Beast", "Ability_EyesOfTheOwl", 1},
				{0,"Deterrence", "Ability_Whirlwind", 1},
				{0,"Trueshot Aura", "Ability_TrueShot", 1},
				{1,"Misdirection", "Ability_Hunter_Misdirection", 1},
			},
	Pet = {
				{0,"Feed Pet", "Ability_Hunter_BeastTraining", 1},
				{0,"Mend Pet", "Ability_Hunter_MendPet", 1},
				{0,"Dash", "Ability_Druid_Dash", 1},
				{0,"Prowl", "Ability_Druid_SupriseAttack", 1},
				{0,"Acid Spit", "Spell_Nature_Acid_01", 2},
				{0,"Sting", "Spell_Nature_SlowPoison", 2},
			},
	Debuff = {
				{0,"Concussive Shot", "Spell_Frost_Stun", 2},
				{2,"Hunter's Mark", "Ability_Hunter_SniperShot", 2},
				{0,"Wing Clip", "Ability_Rogue_Trip", 2},
				{0,"Serpent Sting", "Ability_Hunter_Quickshot", 2},
				{0,"Scorpid Sting", "Ability_Hunter_CriticalShot", 2},
				{0,"Viper Sting", "Ability_Hunter_AimedShot", 2},
				{0,"Scatter Shot", "Ability_GolemStormBolt", 2},
				{0,"Flare", "Ability_GolemStormBolt", 2},
				{1,"Freezing Trap", "Spell_Frost_ChainsOfIce", 2},
				{1,"Frost Trap", "Spell_Frost_FreezingBreath", 2},
				{0,"Immolate Trap(?)", "Spell_Fire_FlameShock", 2},
				{0,"Explosive Trap", "Spell_Fire_SelfDestruct", 2},
				{1,"Misdirection", "Ability_Hunter_Misdirection", 2},
			},
	},


WARLOCK = {
		noLeaf = 1,
	Buff = {
				{0,"Demon Skin/Demon Armor","Spell_Shadow_RagingScream", 1},
				{0,"Fel Armor","Spell_Shadow_FelArmour", 1},
				{0,"Fire Shield","Spell_Fire_FireArmor", 1},
				{0,"Sacrifice","Spell_Shadow_SacrificialShield", 1},
				{1,"Unending Breath","Spell_Shadow_DemonBreath", 1},
				{0,"Eye of Kilrogg","Spell_Shadow_EvilEye", 1},
				{0,"Nightfall", "Spell_Shadow_Twilight", 1},
				{1,"Detect Lesser Invisibility", "Spell_Shadow_DetectLesserInvisibility", 1},
				{0,"Demonic Sacrifice", "Spell_Shadow_PsychicScream", 1},
				{0,"Shadow Ward", "Spell_Shadow_AntiShadow", 1},
				{0,"Master Demonologist", "Spell_Shadow_ShadowPact", 1},
				{1,"Detect Invisibility", "Spell_Shadow_DetectInvisibility", 1},
				{0,"Soul Link", "Spell_Shadow_GatherShadows", 1},
				{2,"Soulstone", "Spell_Shadow_SoulGem", 1},
				{0,"Summon Felsteed", "Spell_Nature_Swiftness", 1},
				{0,"Blood Pact", "Spell_Shadow_BloodBoil", 1},
				{0,"Paranoia", "Spell_Shadow_AuraOfDarkness", 1},
				{0,"Health Channel", "Spell_Shadow_LifeDrain", 1},
			},
	Pet = {
				{0,"Phase Shift", "Spell_Shadow_ImpPhaseShift", 1},
				{0,"Health Funnel", "Spell_Shadow_LifeDrain", 1},
				{0,"Consume Shadows", "Spell_Shadow_AntiShadow", 1},
				{0,"Lesser Invisibility", "Spell_Magic_LesserInvisibility", 1},
				{0,"Soul Link", "Spell_Shadow_GatherShadows", 1},
				{0,"Fel Intelligence","Spell_Shadow_Brainwash", 1},
			},
	Debuff = {
				{1,"Corruption", "Spell_Shadow_AbominationExplosion", 2},
				{1,"Immolate", "Spell_Fire_Immolation", 2},
				{0,"Siphon Life", "Spell_Shadow_Requiem", 2},
				{0,"Drain Life", "Spell_Shadow_LifeDrain02", 2},
				{0,"Drain Soul", "Spell_Shadow_Haunting", 2},
				{0,"Drain Mana", "Spell_Shadow_SiphonMana", 2},
				{1,"Curse of Agony", "Spell_Shadow_CurseOfSargeras", 2},
				{1,"Curse of Idiocy", "Spell_Shadow_MindRot", 2},
				{1,"Curse of Weakness", "Spell_Shadow_CurseOfMannoroth", 2},
				{2,"Curse of Shadow", "Spell_Shadow_CurseOfAchimonde", 2},
				{2,"Curse of the Elements", "Spell_Shadow_ChillTouch", 2},
				{1,"Curse of Doom", "Spell_Shadow_AuraOfDarkness", 2},
				{1,"Curse of Tongues", "Spell_Shadow_CurseOfTounges", 2},
				{1,"Curse of Recklessness", "Spell_Shadow_UnholyStrength", 2},
				{1,"Curse of Exhaustion", "Spell_Shadow_GrimWard", 2},
				{1,"Seed of Corruption", "Spell_Shadow_SeedOfDestruction", 2},
				{0,"Improved Shadow Bolt effect", "Spell_Shadow_ShadowBolt", 2},
				{1,"Fear", "Spell_Shadow_Possession", 2},
				{2,"Banish", "Spell_Shadow_Cripple", 2},
				{0,"Enslave Demon", "Spell_Shadow_EnslaveDemon", 2},
				{0,"Succubus Seduction", "Spell_Shadow_MindSteal", 2},
				{0,"Tainted Blood", "Spell_Shadow_LifeDrain", 2},
				{0,"Spell Lock", "Spell_Shadow_MindRot", 2},
				{0,"Howl of Terror", "Spell_Shadow_DeathScream", 2},
				{0,"Death Coil", "Spell_Shadow_DeathCoil", 2},
			},
	},

PRIEST = {
		noLeaf = 1,
	Buff = {
				{0,"Shadowform", "Spell_Shadow_Shadowform", 1},
				{2,"Shadow Protection", "Spell_Shadow_AntiShadow", 1},
				{2,"Prayer of Shadow Protection", "Spell_Holy_PrayerofShadowProtection", 1},
				{2,"Power Word: Fortitude", "Spell_Holy_WordFortitude", 1},
				{2,"Prayer of Fortitude", "Spell_Holy_PrayerOfFortitude", 1},
				{2,"Divine Spirit", "Spell_Holy_DivineSpirit", 1},
				{2,"Prayer of Spirit", "Spell_Holy_PrayerofSpirit", 1},
				{2,"Power Word: Shield", "Spell_Holy_PowerWordShield", 1},
				{2,"Renew", "Spell_Holy_Renew", 1},
				{1,"Mind Control", "Spell_Shadow_ShadowWordDominate", 1},
				{0,"Inner Fire", "Spell_Holy_InnerFire", 1},
				{0,"Inner Focus", "Spell_Frost_WindWalkOn", 1},
				{0,"Spirit Tap", "Spell_Shadow_Requiem", 1},
				{1,"Vampiric Embrace", "Spell_Shadow_UnsummonBuilding", 1},
				{0,"Fade", "Spell_Magic_LesserInvisibilty", 1},
				{2,"Fear Ward", "Spell_Holy_Excorcism", 1},
				{0,"Touch of Weakness", "Spell_Shadow_DeadofNight", 1},
				{0,"Shadowguard", "Spell_Nature_LightningShield", 1},
				{0,"Elune's grace", "Spell_Holy_ElunesGrace", 1},
				{0,"Feedback", "Spell_Shadow_RitualOfSacrifice", 1},
				{0,"Abolish Disease", "Spell_Nature_NullifyDisease", 1},
				{0,"Levitate", "Spell_Holy_LayOnHands", 1},
				{0,"Lightwell Renew", "Spell_Holy_SummonLightwell", 1},
				{2,"Power Infusion", "Spell_Holy_PowerInfusion", 1},
				{2,"Prayer of Mending", "Spell_Holy_PrayerOfMendingtga", 1},
				{1,"Grace", "Spell_Holy_HopeAndGrace", 1},
				{1,"Divine Aegis", "Spell_Holy_DevineAegis", 1},
				{1,"Inspiration", "INV_Shield_06", 1},
				{1,"Guardian Spirit","Spell_Holy_GuardianSpirit", 1},
			},
	Debuff = {
				{0,"Weakened Soul", "Spell_Holy_AshesToAshes", 3},
				{0,"Psychic Scream", "Spell_Shadow_PsychicScream", 2},
				{2,"Shackle Undead", "Spell_Nature_Slow", 2},
				{0,"Starfall", "Nature_Starfall", 2},
				{0,"Holy Fire", "Spell_Holy_SearingLight", 2},
				{0,"Shadow Word Pain", "Spell_Shadow_ShadowWordPain", 2},
				{0,"Hex of Weakness", "Spell_Shadow_FingerOfDeath", 2},
				{0,"Mind Soothe", "Spell_Holy_MindSooth", 2},
				{0,"Mind Flay", "Spell_Shadow_SiphonMana", 2},
				{0,"Devouring Plague", "Spell_Shadow_DevouringPlague", 2},
				{1,"Mind Vision", "Spell_Holy_MindVision", 2},
				{1,"Mind Control", "Spell_Shadow_ShadowWordDominate", 2},
			},
	},

PALADIN = {
		noLeaf = 1,
	Buff = {
				{0,"Divine Protection", "Spell_Holy_Restoration", 1},
				{0,"Divine Shield", "Spell_Holy_DivineIntervention", 1},
				{0,"Seal of Light", "Spell_Holy_HealingAura", 1},
				{0,"Seal of Wisdom", "Spell_Holy_RighteousnessAura", 1},
				{0,"Seal of the Crusader", "Spell_Holy_HolySmite", 1},
				{0,"Seal of Righteousness", "Ability_ThunderBolt", 1},
				{0,"Seal of Justice", "Spell_Holy_SealOfWrath", 1},
				{0,"Seal of Vengeance", "Spell_Holy_SealOfVengeance", 1},
				{0,"Seal of the Martyr", "Spell_Holy_SealOfBlood", 1},
				{2,"Blessing of Kings", "Spell_Magic_MageArmor", 1},
				{2,"Blessing of Might", "Spell_Holy_FistOfJustice", 1},
				{2,"Blessing of Wisdom", "Spell_Holy_SealOfWisdom", 1},
				{2,"Blessing of Salvation", "Spell_Holy_SealOfSalvation", 1},
				{2,"Blessing of Light", "Spell_Holy_PrayerOfHealing02", 1},
				{2,"Blessing of Freedom", "Spell_Holy_SealOfValor", 1},
				{2,"Blessing of Protection", "Spell_Holy_SealOfProtection", 1},
				{2,"Blessing of Sacrifice", "Spell_Holy_SealOfSacrifice", 1},
				{2,"Greater Blessing of Might", "Spell_Holy_GreaterBlessingofKings", 1},
				{2,"Greater Blessing of Wisdom", "Spell_Holy_GreaterBlessingofWisdom", 1},
				{2,"Greater Blessing of Salvation", "Spell_Holy_GreaterBlessingofSalvation", 1},
				{2,"Greater Blessing of Light", "Spell_Holy_GreaterBlessingofLight", 1},
				{2,"Greater Blessing of Sanctuary", "Spell_Holy_GreaterBlessingofSanctuary", 1},
				{2,"Greater Blessing of Kings", "Spell_Magic_GreaterBlessingofKings", 1},
				{0,"Devotion Aura", "Spell_Holy_DevotionAura", 1},
				{0,"Retribution Aura", "Spell_Holy_AuraOfLight", 1},
				{0,"Concentration Aura", "Spell_Holy_MindSooth", 1},
				{0,"Shadow Resistance Aura", "Spell_Shadow_SealOfKings", 1},
				{0,"Sanctity Aura", "Spell_Holy_MindVision", 1},
				{0,"Frost Resistance Aura", "Spell_Frost_WizardMark", 1},
				{0,"Fire Resistance Aura", "Spell_Fire_SealOfFire", 1},
				{0,"Eye for an Eye", "Spell_Holy_EyeforanEye", 1},
				{0,"Righteous Fury", "Spell_Holy_SealOfFury", 1},
				{0,"Consecration", "Spell_Holy_InnerFire", 1},
				{2,"Divine Intervention", "Spell_Nature_TimeStop", 1},
				{2,"Beacon of Light", "Ability_Paladin_BeaconofLight", 1},
                {1,"Sacred Shield (target)", "Ability_Paladin_GaurdedbytheLight", 1},
                {0,"Sacred Shield (self)", "Ability_Paladin_BlessedMending", 1},
			},
	Debuff = {
				{0,"Hammer of Justice", "Spell_Holy_SealOfMight", 2},
				{2,"Judgement of Justice", "Spell_Holy_SealOfWrath", 2},
				{2,"Judgement of the Crusader", "Spell_Holy_HolySmite", 2},
				{2,"Judgement of Light", "Spell_Holy_HealingAura", 2},
				{2,"Judgement of Wisdom", "Spell_Holy_RighteousnessAura", 2},
				{0,"Repentance", "Spell_Holy_PrayerOfHealing", 2},
				{0,"Consecration", "Spell_Holy_InnerFire", 2},
				{0,"Turn Undead", "Spell_Holy_TurnUndead", 2},
                {1,"Sacred Shield", "Spell_Paladin_GuardedbytheLight", 2},
			},
	},

MAGE = {
		noLeaf = 1,
	Buff = {
				{2,"Arcane Brilliance", "Spell_Holy_ArcaneIntellect", 1},
				{2,"Arcane Intellect", "Spell_Holy_MagicalSentry", 1},
				{2,"Dalaran Brilliance", "Achievement_Dungeon_TheVioletHold_Heroic", 1},
				{0,"Ice Armor", "Spell_Frost_FrostArmor02", 1},
				{0,"Mana Shield", "Spell_Shadow_DetectLesserInvisibility", 1},
				{0,"Fire Ward", "Spell_Fire_FireArmor", 1},
				{1,"Ice Block", "Spell_Frost_Frost", 1},
				{1,"Ice Barrier", "Spell_Ice_Lament", 1},
				{0,"Frost Ward", "Spell_Frost_FrostWard", 1},
				{0,"Mage Armor", "Spell_MageArmor", 1},
				{0,"Clearcasting", "Spell_Shadow_ManaBurn", 1},
				{0,"Presence of Mind", "Spell_Nature_EnchantArmor", 1},
				{0,"Combustion", "Spell_Fire_SealOfFire", 1},
				{2,"Dampen Magic", "Spell_Nature_AbolishMagic", 1},
				{2,"Amplify Magic", "Spell_Holy_FlashHeal", 1},
				{0,"Netherwind Focus", "Spell_Shadow_Teleport", 1},
				{0,"Ice Barrier", "Spell_Ice_Lament", 1},
				{0,"Combustion", "Spell_Fire_SealOfFire", 1},
				{0,"Molten Armor", "Ability_Mage_MoltenArmor", 1},
				{3,"Focus Magic", "Spell_Arcane_StudentOfMagic", 1},
			},
	Debuff = {
				{0,"Detect Magic", "Spell_Holy_Dizzy", 2},
				{2,"Polymorph", "Spell_Nature_Polymorph", 2},
				{2,"Polymorph: Turtle", "Ability_Hunter_Pet_Turtle", 2},
				{2,"Polymorph: Pig", "Spell_Magic_PolymorphPig", 2},
				{0,"Frostbolt", "Spell_Frost_FrostBolt02", 2},
				{2,"Frost Nova", "Spell_Frost_FrostNova", 2},
				{1,"Frostbite", "Spell_Frost_FrostArmor", 2},
				{2,"Scorch", "Spell_Fire_SoulBurn", 2},
				{2,"Winters Chill", "Spell_Frost_FrostBlast", 2},
				{0,"Chill Effect", "Spell_Frost_IceStorm", 2},
				{0,"Fireball", "Spell_Fire_FlameBolt", 2},
				{0,"Impact","Spell_Fire_MeteorStorm", 2},
				{0,"Flamestrike","Spell_Fire_SelfDestruct", 2},
				{0,"Pyroblast","Spell_Fire_Fireball02", 2},
				{1,"Counterspell","Spell_Frost_IceShock", 2},
				{0,"Cone of Cold", "Spell_Frost_Glacier", 2},
				{0,"Blast Wave", "Spell_Holy_Excorcism_02", 2},
				{0,"Arcane Blast (Debuff)", "Spell_Arcane_Blast",3},
			},
	},
DRUID = {
		noLeaf = 1,
	Buff = {
				{2,"Mark of the Wild", "Spell_Nature_Regeneration", 1},
				{2,"Gift of the Wild", "Spell_Nature_GiftoftheWild", 1},
				{2,"Rejuvenation", "Spell_Nature_Rejuvenation", 1},
				{0,"Nature's Grace", "Spell_Nature_NaturesBlessing", 1},
				{0,"Nature's Grasp", "Spell_Nature_NaturesWrath", 1},
				{1,"Thorns","Spell_Nature_Thorns", 1},
				{2,"Regrowth", "Spell_Nature_ResistNature", 1},
				{0,"Aquatic Form", "Ability_Druid_AquaticForm", 1},
				{0,"Bear Form", "Ability_Racial_BearForm", 1},
				{0,"Cat Form", "Ability_Druid_CatForm", 1},
				{0,"Travel Form", "Ability_Druid_TravelForm", 1},
				{0,"Moonkin Form", "Spell_Nature_ForceOfNature", 1},
				{0,"Enrage", "Ability_Druid_Enrage", 1},
				{0,"Prowl", "Ability_Ambush", 1},
				{0,"Tiger's Fury", "Ability_Mount_JungleTiger", 1},
				{0,"Dash", "Ability_Druid_Dash", 1},
				{2,"Abolish Poison", "Spell_Nature_NullifyPoison_02", 1},
				{0,"Frenzied Regeneration", "Ability_BullRush", 1},
				{0,"Moonkin Aura", "Spell_Nature_MoonGlow", 1},
				{0,"Barkskin Effect", "Spell_Nature_StoneClawTotem", 1},
				{0,"Leader of the Pack", "Spell_Nature_UnyeildingStamina", 1},
				{1,"Innervate", "Spell_Nature_Lightning", 1},
				{2,"Lifebloom", "INV_Misc_Herb_Felblossom",1},
				{2,"Wild growth", "Ability_Druid_Flourish",1},
				{0,"Tree of Life", "Ability_Druid_TreeofLife",1},
			},
	Debuff = {
				{0,"Demoralizing Roar", "Ability_Druid_DemoralizingRoar", 2},
				{0,"Bash", "Ability_Druid_Bash", 2},
				{0,"Rake", "Ability_Druid_Disembowel", 2},
				{0,"Moonfire", "Spell_Nature_StarFall", 2},
				{1,"Faerie Fire", "Spell_Nature_FaerieFire", 2},
				{0,"Insect Swarm", "Spell_Nature_InsectSwarm", 2},
				{2,"Entangling Roots", "Spell_Nature_StrangleVines", 2},
				{2,"Hibernate", "Spell_Nature_Sleep", 2}, 
				{0,"Soothe Animal", "Ability_Hunter_BeastSoothe", 2},
				{0,"Challenging Roar", "Ability_Druid_ChallangingRoar", 2},
				{0,"Pounce","Ability_Druid_SupriseAttack", 2},
				{1,"Cyclone","Spell_Nature_EarthBind", 2},
				{0,"Mangle","Ability_Druid_Mangle2",2},
				{0,"Earth and Moon","Ability_Druid_EarthandSky",2},
				{0,"Infected Wounds","Ability_Druid_InfectedWound",2},
			},
	},

ROGUE = {
		noLeaf = 1,
	Buff = {
				{0,"Sprint", "Ability_Rogue_Sprint", 1},
				{0,"Stealth", "Ability_Stealth", 1},
				{0,"Vanish", "Ability_Vanish", 1},
				{0,"Evasion", "Spell_Shadow_ShadowWard", 1},
				{0,"Slice n Dice", "Ability_Rogue_SliceDice", 1},
			},
	Debuff = {
				{0,"Gouge", "Ability_Gouge", 2},
				{0,"Garrote", "Ability_Rogue_Garrote", 2},
				{0,"Blind", "Spell_Shadow_MindSteal", 2},
				{0,"Rupture", "Ability_Rogue_Rupture", 2},
				{0,"Cheap Shot", "Ability_CheapShot", 2},
				{2,"Sap", "Ability_Sap", 2},
				{1,"Expose Armor", "Ability_Warrior_Riposte", 2},
				{1,"Kick", "Ability_Kick", 2},
				{1,"Distract", "Ability_Rogue_Distract", 2},
				{1,"Mind Numbing Poison", "Spell_Nature_NullifyDisease", 2},
				{1,"Hemorrhage", "Spell_Shadow_LifeDrain", 2},
				{1,"Kidney Shot", "Ability_Rogue_KidneyShot", 2},
				{1,"Deadly Poison", "Ability_Rogue_DualWeild", 2},
				{1,"Crippling Poison", "Ability_PoisonSting", 2},
			},
	},

WARRIOR = {
		noLeaf = 1,
	Buff = {
				{1,"Battle Shout", "Ability_Warrior_BattleShout", 1},
				{1,"Commanding Shout", "Ability_Warrior_RallyingCry", 1},
				{0,"Bloodrage", "Ability_Racial_BloodRage", 1},
				{1,"Defensive Stance", "Ability_Warrior_DefensiveStance", 1},
				{1,"Offensive Stance", "Ability_Warrior_OffensiveStance", 1},
				{1,"Beserker Stance", "Ability_Racial_Avatar", 1},
				{2,"Shield Wall", "Ability_Warrior_ShieldWall", 1},
				{2,"BeserkerRage", "Spell_Nature_AncestralGuardian", 1},
				{1,"Recklessness", "Ability_CriticalStrike", 1},
				{0,"Rampage", "Ability_Warrior_Rampage", 1},
			},
	Debuff = {
				{0,"Rend", "Ability_Gouge", 2},
				{2,"ThunderClap", "Spell_Nature_ThunderClap", 2},
				{1,"Charge", "Ability_Warrior_Charge", 2},
				{2,"Piercing Howl", "Spell_Shadow_DeathScream", 2},
				{0,"Hamstring", "Ability_ShockWave", 2},
				{1,"Demoralizing Shout", "Ability_Warrior_WarCry", 2},
				{2,"Sunder Armor", "Ability_Warrior_Sunder", 2},
				{1,"Shield Bash", "Ability_Warrior_ShieldBash", 2},
				{1,"Mocking Blow", "Ability_Warrior_PunishingBlow", 2},
				{2,"Taunt", "Spell_Nature_Reincarnation", 2},
				{2,"Disarm", "Ability_Warrior_Disarm", 2},
				{2,"Intimidating Shout", "Ability_GolemThunderClap", 2},
				{2,"Challenging Shout", "Ability_BullRush", 2},
				{1,"Intercept", "Ability_Rogue_Sprint", 2},
				{1,"Pummel","INV_Gauntlets_04", 2},
				{2,"Mortal Strike", "Ability_Warrior_SavageBlow", 2},
				{0,"Blood Frenzy", "Ability_Warrior_BloodFrenzy", 2},
				{0,"Trauma","Ability_Warrior_BloodNova", 2},
				{0,"Furious Attacks","Ability_Warrior_FuriousResolve", 2},
				
			},
	},

SHAMAN = {
		noLeaf = 1,
	Buff = {
				{0,"Lightning Shield", "Spell_Nature_LightningShield", 1},
				{0,"Ghost Wolf", "Spell_Nature_SpiritWolf", 1},
				{1,"Water Breathing", "Spell_Shadow_DemonBreath", 1},
				{1,"Bloodlust", "Spell_Nature_BloodLust", 1},
				{1,"Heroism", "Ability_Shaman_Heroism", 1},
				{1,"Water Shield","Ability_Shaman_WaterShield", 1},
				{1,"Earth Shield","Spell_Nature_SkinofEarth", 1},
				{1,"Riptide","spell_nature_riptide", 1},
				{1,"Earthliving","Spell_Shaman_GiftEarthmother", 1},
				{0,"Unleashed Rage","Spell_Nature_UnleashedRage", 1},
				{0,"Elemental Oath","Spell_Shaman_ElementalOath", 1},
				{1,"Ancestral Fortitude","Spell_Nature_UndyingStrength", 1},
			},
	Debuff = {
				{0,"Earth Shock", "Spell_Nature_EarthShock", 2},
				{0,"Frost Shock", "Spell_Frost_FrostShock", 2},
				{0,"Earthbind Totem", "Spell_Nature_StrengthOfEarthTotem02", 2},
			},
	},
	
DEATHKNIGHT = {
		 noLeaf = 1,
   Buff = {
				{0,"Icy Talons", "Spell_Deathknight_IcyTalons", 1},
				{0,"Unholy Blight", "Spell_Shadow_Contagion", 1},
				{0,"Horn of Winter", "Inv_Misc_Horn_02", 1},
				{0,"Abomination's Might", "Ability_Warrior_IntensifyRage", 1},
		   },
	Debuff = {
				{3,"Blood Plague", "Spell_DeathKnight_BloodPlague",2},
				{3,"Frost Fever", "Spell_DeathKnight_FrostFever",2},
				{2,"Chains of Ice", "Spell_Frost_ChainsOfIce",2},
				{1,"Ebon Plague", "Spell_Shadow_Nethercloak",2},
		   },
	},

["All Classes"] = {
		noLeaf = 1,
	["Item Buffs"] = {
				{0,"Argent Dawn Commission", "Spell_INV_Jewelry_Talisman_07", 1},
				{0,"Winterfall Firewater", "Spell_INV_Potion_92", 1},
				{0,"Zandalarian Hero Charm", "Spell_Lightning_LightningBolt01", 1},
				{0,"Fire Protection Potion", "Spell_Fire_FireArmor", 1},
				{0,"Forethought Talisman", "Spell_Nature_WispSplodeGreen", 1},
			},
	Consumables = {
				{3,"Well Fed","Spell_Misc_Food",1},
				{2,"Flask of the Frost Wyrm", "INV_Alchemy_EndlessFlask_04", 1},
				{2,"Flask of the Stoneblood", "INV_Alchemy_EndlessFlask_05", 1},
				{2,"Flask of the Pure Mojo", "INV_Alchemy_EndlessFlask_03", 1},
				{2,"Flask of the Endless Rage", "INV_Alchemy_EndlessFlask_06", 1},
				{2,"Lesser Flask of the Toughness", "INV_Alchemy_EndlessFlask_02", 1},
				
				{1,"Elixir of Mighty Thoughts", "INV_Potion_161", 1},
				{1,"Elixir of Mighty Strength", "INV_Potion_165", 1},
				{1,"Elixir of Mighty Mageblood", "INV_Potion_129", 1},
				{1,"Elixir of Mighty Fortitude", "INV_Potion_164", 1},
				{1,"Elixir of Mighty Defense", "INV_Alchemy_Potion_03", 1},
				{1,"Elixir of Mighty Agility", "INV_Potion_162", 1},
				{1,"Elixir of Lightning Speed", "INV_Alchemy_Potion_04", 1},
				{1,"Elixir of Expertise", "INV_Alchemy_Potion_01", 1},
				{1,"Elixir of Deadly Strikes", "INV_Alchemy_Potion_02", 1},
				{1,"Elixir of Armor Piercing", "INV_Alchemy_Potion_06", 1},
				{1,"Elixir of Accuracy", "INV_Potion_61", 1},
				{1,"Guru's Elixir", "INV_Potion_112", 1},
				{1,"Spellpower Elixir", "INV_Alchemy_Potion_05", 1},
				{1,"Wrath Elixir", "INV_Potion_114", 1},
				{1,"Bloodberry Elixir", "INV_Potion_111", 1},                
			},
	["Item Debuffs"] = {
				{0,"Recently Bandanged", "Misc_Bandage_08", 2},
				{1,"Dreamless Sleep*", "Spell_Nature_Sleep",3,key=GetSpellInfo(15822),fNoShow=1},
				{1,"Greater Dreamless Sleep*", "Spell_Nature_Sleep",3,key=GetSpellInfo(24360),fNoShow=1},
				{1,"Major Dreamless Sleep*", "Spell_Nature_Sleep",3,key=GetSpellInfo(28504),fNoShow=1},
			},
	["Player Debuffs"] = {
				{1,"Magic (Debuff)","*",3, key="Magic", t="Magic", col=DebuffTypeColor["Magic"]},
				{1,"Disease","*",3, key="Disease", t="Disease", col= DebuffTypeColor["Disease"]},
				{1,"Poison","*",3, key="Poison", t="Poison", col=DebuffTypeColor["Poison"]},
				{1,"Curse","*",3, key="Curse", t="Curse", col=DebuffTypeColor["Curse"]},
		},
	["Mob Buffs"] = {
				{1,"Magic (Mob Buff)","*",4, key="Magic", t="Magic", col=DebuffTypeColor["Magic"]},
		},
	},
["Raid Boss Debuffs"] = {
	["Ulduar"] = {
				OZ_SetSpellEntry(62056,1,3,1),								-- Stone Grip (Kologarn)
				OZ_SetSpellEntry(63018,1,3,1),								-- Light Bomb (XT-002 Deconstructor)
				OZ_SetSpellEntry(63024,1,3),								-- Gravity Bomb (XT-002 Deconstructor)
				OZ_SetSpellEntry(63346,1,3),								-- Frozen Eyebeam (Kologarn)
				OZ_SetSpellEntry(64771,1,3),								-- Fuse Armor (Ignis)
				OZ_SetSpellEntry(64473,9,4),								-- Strength of the Creator (Ignis)
				OZ_SetSpellEntry(64175,9,3,1),								-- Flash Freeze (Hodir)
				{1,"Fusion Punch","Ability_GolemThunderClap",3,fNoHide=1,col=OZ_BossDebuffColour},
				{1,"Armor Crunch","Ability_Warrior_ShieldBreak",3,fNoHide=1,col=OZ_BossDebuffColour},
				{1,"Slag Pot","INV_GAUNTLETS_66",3,fNoHide=1,col=OZ_BossDebuffColour},
				OZ_SetSpellEntry(63666,9,3,1),								-- Napalm (Mimiron)
				
				OZ_SetSpellEntry(62438,9,3,1),								-- Iron Roots (Freya)
				OZ_SetSpellEntry(62590,9,3,1),								-- Natures Fury (Freya)
				OZ_SetSpellEntry(64126,9,3,1),								-- Squeeze (Yogg Saron)
				OZ_SetSpellEntry(63803,9,3,1),								-- Brain Link (Yogg Saron)
				OZ_SetSpellEntry(63278,9,3,1),								-- Mark of the Faceless
				},
	["Colliseum"] = {
				OZ_SetSpellEntry(66331,9,3,1),								-- Impale (Colliseum)
				OZ_SetSpellEntry(66406,8,3,1,{r=0,g=1,b=1}),				-- Snobolled
				OZ_SetSpellEntry(67623,9,3,1),								-- Burning Bile (Colliseum)
				OZ_SetSpellEntry(67620,9,3,1),								-- Paralytic Poison (Colliseum)		
				OZ_SetSpellEntry(67651,9,3,1),								-- Arctic breath (Colliseum)
				
				OZ_SetSpellEntry(67049,9,3,1),								-- Incinerate Flesh (Colliseum)
				
				OZ_SetSpellEntry(66963,1,3,0),								-- Fel Fireball
				OZ_SetSpellEntry(68127,1,3,0),								-- Legion Flame				
				OZ_SetSpellEntry(67100,1,3,0),								-- Spinning Pain Spike
				
				},
	["Icecrown"] = {
				OZ_SetSpellEntry(69065,9,3,1),								-- Bone Spiked
				OZ_SetSpellEntry(72702,1,3,1,{r=0,g=1,b=1} ),				-- Cold Flame
				OZ_SetSpellEntry(71204,9,3,1),								-- Insignificance
				OZ_SetSpellEntry(71289,9,3,1),								-- Dominate Mind
				OZ_SetSpellEntry(72444,9,3,1),								-- Mark of the Fallen Champion
				OZ_SetSpellEntry(72447,9,3,1),								-- Rune of Blood
				},
	},

-- Crowd control spells
["Crowd Control"] = {
		noLeaf = 1,
	Debuff = {
				{2,"Polymorph", "Spell_Nature_Polymorph", 2},
				{2,"Polymorph: Turtle", "Ability_Hunter_Pet_Turtle", 2},
				{2,"Polymorph: Pig", "Spell_Magic_PolymorphPig", 2},
				{2,"Banish", "Spell_Shadow_Cripple", 2},
				{2,"Shackle Undead", "Spell_Nature_Slow", 2},
				{2,"Hibernate", "Spell_Nature_Sleep", 2}, 
				{2,"Succubus Seduction", "Spell_Shadow_MindSteal", 2},
				{2,"Sap", "Ability_Sap", 2},
		},
	},	
};

OZ_BUFF_DEFAULT = {

HUNTER = {
	-- Default 'interested in' buffs
	Player = {
				{0,"Aspect of the Hawk","Spell_Nature_RavenForm",1,not_combat=1},
				{0,"Aspect of the Monkey", "Ability_Hunter_AspectOfTheMonkey",1,not_combat=1},
				{0,"Aspect of the Cheetah", "Ability_Mount_JungleTiger",1,not_combat=1},
				{0,"Aspect of the Pack", "Ability_Mount_WhiteTiger",1,not_combat=1},
				{0,"Aspect of the Beast", "Ability_Mount_PinkTiger",1,not_combat=1},
				{0,"Aspect of the Wild", "Spell_Nature_ProtectionformNature",1,not_combat=1},
				{0,"Trueshot Aura", "Ability_TrueShot",1,not_combat=1},
				{1,"Misdirection", "Ability_Hunter_Misdirection",1},
			},
	Mob = {
				{3,"Hunter's Mark", "Ability_Hunter_SniperShot",2},
				{2,"Polymorph", "Spell_Nature_Polymorph",2},
				{2,"Polymorph: Turtle", "Ability_Hunter_Pet_Turtle",2},
				{2,"Polymorph: Pig", "Spell_Magic_PolymorphPig",2},
				{2,"Banish", "Spell_Shadow_Cripple",2},
				{2,"Shackle Undead", "Spell_Nature_Slow",2},
				{2,"Hibernate", "Spell_Nature_Sleep",2}, 
				{2,"Succubus Seduction", "Spell_Shadow_MindSteal",2},
				{2,"Sap", "Ability_Sap",2},
				{3,"Sunder Armor", "Ability_Warrior_Sunder",2},
				{1,"Misdirection", "Ability_Hunter_Misdirection",2},
			},
	},


WARLOCK = {
	-- Default 'interested in' buffs
	Player = {
				{1,"Unending Breath","Breathing Spell_Shadow_DemonBreath",1,not_combat=1},
				{1,"Detect Lesser Invisibility", "Spell_Shadow_DetectLesserInvisibility",1,not_combat=1},
				{1,"Detect Invisibility", "Spell_Shadow_DetectInvisibility",1,not_combat=1},
				{2,"Soulstone", "Spell_Shadow_SoulGem",1},
				{0,"Demon Skin/Demon Armor","Spell_Shadow_RagingScream",1,not_combat=1},
				{1,"Magic","*",3, key="Magic", t="Magic", col=DebuffTypeColor["Magic"]},
			},
	Mob = {
				{3,"Sunder Armor", "Ability_Warrior_Sunder",2},
				{2,"Hunter's Mark", "Ability_Hunter_SniperShot",2},
				{3,"Curse of Shadow", "Spell_Shadow_CurseOfAchimonde",2},
				{3,"Curse of the Elements", "Spell_Shadow_ChillTouch",2},
				{2,"Polymorph", "Spell_Nature_Polymorph",2},
				{2,"Polymorph: Turtle", "Ability_Hunter_Pet_Turtle",2},
				{2,"Polymorph: Pig", "Spell_Magic_PolymorphPig",2},
				{3,"Banish", "Spell_Shadow_Cripple",2},
				{2,"Shackle Undead", "Spell_Nature_Slow",2},
				{2,"Hibernate", "Spell_Nature_Sleep",2}, 
				{2,"Sap", "Ability_Sap",2},
				{3,"Succubus Seduction", "Spell_Shadow_MindSteal",2},
				{1,"Curse of Doom", "Spell_Shadow_AuraOfDarkness",2},
				{1,"Curse of Agony", "Spell_Shadow_CurseOfSargeras",2},
				{1,"Curse of Weakness", "Spell_Shadow_CurseOfMannoroth",2},
				{1,"Magic","*",3, key="Magic", t="Magic", col=DebuffTypeColor["Magic"]},
			},
	},

PRIEST = {
	-- Default 'interested in' buffs
	Player = {
				{3,"Shadow Protection", "Spell_Shadow_AntiShadow",1,not_combat=1},
				{3,"Prayer of Shadow Protection", "Spell_Holy_PrayerofShadowProtection",1,not_combat=1},
				{3,"Power Word: Fortitude", "Spell_Holy_WordFortitude",1,not_combat=1},
				{3,"Prayer Of Fortitude", "Spell_Holy_PrayerOfFortitude",1,not_combat=1},
				{3,"Divine Spirit", "Spell_Holy_DivineSpirit",1,not_combat=1},
				{3,"Prayer of Spirit", "Spell_Holy_PrayerofSpirit",1,not_combat=1},
				{3,"Power Word: Shield", "Spell_Holy_PowerWordShield",1},
				{3,"Renew", "Spell_Holy_Renew",1},
				{3,"Power Infusion", "Spell_Holy_PowerInfusion",1},
				{1,"Rejuvenation", "Spell_Nature_Rejuvenation",1},
				{1,"Regrowth", "Spell_Nature_ResistNature",1},
				{2,"Prayer of Mending", "Spell_Holy_PrayerOfMendingtga",1},
				{2,"Earth Shield","Spell_Nature_SkinofEarth",1},
				{2,"Wild growth", "Ability_Druid_Flourish",1},
				{1,"Riptide","spell_nature_riptide",1},
				{1,"Earthliving","Spell_Shaman_GiftEarthmother",1},
				{1,"Inspiration", "INV_Shield_06",1},
				{1,"Ancestral Fortitude","Spell_Nature_UndyingStrength",1},
				{2,"Glyph of Prayer of Healing","Spell_Holy_PrayerOfHealing02",1},
				{1,"Guardian Spirit","Spell_Holy_GuardianSpirit", 1},
				{4,"Weakened Soul", "Spell_Holy_AshesToAshes",3,fNoHide=1},
				{1,"Arcane Blast (Debuff)", "Spell_Arcane_Blast",3,fNoShow=1},
				
				{1,"Magic","*",3, key="Magic", t="Magic", col=DebuffTypeColor["Magic"]},
				{1,"Disease","*",3, key="Disease", t="Disease", col= DebuffTypeColor["Disease"]},
				OZ_SetSpellEntry(62056,1,3,1),								-- Stone Grip (Kologarn)
				OZ_SetSpellEntry(63018,1,3,1),								-- Light Bomb (XT-002 Deconstructor)
				OZ_SetSpellEntry(63024,1,3),								-- Gravity Bomb (XT-002 Deconstructor)
				{1,"Slag Pot","INV_GAUNTLETS_66",3,fNoHide=1,col=OZ_BossDebuffColour},
				{1,"Dreamless Sleep*", "Spell_Nature_Sleep",3,key=GetSpellInfo(15822),fNoShow=1},
				{1,"Greater Dreamless Sleep*", "Spell_Nature_Sleep",3,key=GetSpellInfo(24360),fNoShow=1},
				{1,"Major Dreamless Sleep*", "Spell_Nature_Sleep",3,key=GetSpellInfo(28504),fNoShow=1},
				{1,"Armor Crunch","Ability_Warrior_ShieldBreak",3,fNoHide=1,col=OZ_BossDebuffColour},
				OZ_SetSpellEntry(63666,9,3,1),								-- Napalm (Mimiron)
				OZ_SetSpellEntry(62438,9,3,1),								-- Iron Roots (Freya)
				OZ_SetSpellEntry(62590,9,3,1),								-- Natures Fury (Freya)
				OZ_SetSpellEntry(64126,9,3,1),								-- Squeeze (Yogg Saron)
				OZ_SetSpellEntry(63803,9,3,1),								-- Brain Link (Yogg Saron)
				OZ_SetSpellEntry(69065,9,3,1),								-- Bone Spiked
				OZ_SetSpellEntry(71204,9,3,1),								-- Insignificance
				OZ_SetSpellEntry(71289,9,3,1),								-- Dominate Mind
			},
	Mob = {
				{1,"Sunder Armor", "Ability_Warrior_Sunder",2},
				{3,"Hunter's Mark", "Ability_Hunter_SniperShot",2},
				{2,"Polymorph", "Spell_Nature_Polymorph",2},
				{2,"Polymorph: Turtle", "Ability_Hunter_Pet_Turtle",2},
				{2,"Polymorph: Pig", "Spell_Magic_PolymorphPig",2},
				{2,"Banish", "Spell_Shadow_Cripple",2},
				{2,"Shackle Undead", "Spell_Nature_Slow",2},
				{2,"Sap", "Ability_Sap",2},
				{2,"Hibernate", "Spell_Nature_Sleep",2}, 
				{2,"Succubus Seduction", "Spell_Shadow_MindSteal",2},
				{2,"Mind Control", "Spell_Shadow_ShadowWordDominate",2},
				
				{1,"Magic","*",3, key="Magic", t="Magic", col=DebuffTypeColor["Magic"]},
			},
	},

PALADIN = {
	-- Default 'interested in' buffs
	Player = {
				{2,"Blessing of Kings", "Spell_Magic_MageArmor",1,not_combat=1},
				{2,"Blessing of Might", "Spell_Holy_FistOfJustice",1,not_combat=1},
				{2,"Blessing of Wisdom", "Spell_Holy_SealOfWisdom",1,not_combat=1},
				{2,"Blessing of Salvation", "Spell_Holy_SealOfSalvation",1,not_combat=1},
				{2,"Blessing of Light", "Spell_Holy_PrayerOfHealing02",1,not_combat=1},
				{2,"Blessing of Freedom", "Spell_Holy_SealOfValor",1,not_combat=1},
				{2,"Blessing of Protection", "Spell_Holy_SealOfProtection",1,not_combat=1},
				{2,"Blessing of Sacrifice", "Spell_Holy_SealOfSacrifice",1,not_combat=1},
				{2,"Greater Blessing of Might", "Spell_Holy_GreaterBlessingofKings",1,not_combat=1},
				{2,"Greater Blessing of Wisdom", "Spell_Holy_GreaterBlessingofWisdom",1,not_combat=1},
				{2,"Greater Blessing of Salvation", "Spell_Holy_GreaterBlessingofSalvation",1,not_combat=1},
				{2,"Greater Blessing of Light", "Spell_Holy_GreaterBlessingofLight",1,not_combat=1},
				{2,"Greater Blessing of Sanctuary", "Spell_Holy_GreaterBlessingofSanctuary",1,not_combat=1},
				{2,"Greater Blessing of Kings", "Spell_Magic_GreaterBlessingofKings",1,not_combat=1},
				{2,"Divine Intervention", "Spell_Nature_TimeStop",1},
				{1,"Power Word: Shield", "Spell_Holy_PowerWordShield",1,not_ooc=1},
				{1,"Renew", "Spell_Holy_Renew",1},
				{1,"Rejuvenation", "Spell_Nature_Rejuvenation",1},
				{1,"Regrowth", "Spell_Nature_ResistNature",1},
				{2,"Earth Shield","Spell_Nature_SkinofEarth",1},
				{2,"Wild growth", "Ability_Druid_Flourish",1},
				{1,"Riptide","spell_nature_riptide",1},
				{1,"Earthliving","Spell_Shaman_GiftEarthmother",1},
				{1,"Inspiration", "INV_Shield_06",1,not_ooc=1},
				{1,"Ancestral Fortitude","Spell_Nature_UndyingStrength",1,not_ooc=1},
				{2,"Glyph of Prayer of Healing","Spell_Holy_PrayerOfHealing02",1},
				{2,"Beacon of Light", "Ability_Paladin_BeaconofLight", 1},
                {1,"Sacred Shield (target)", "Ability_Paladin_GaurdedbytheLight", 1},
				{1,"Poison","*",3, key="Poison", t="Poison", col=OZ_MiscDebuffColour},
				{1,"Disease","*",3, key="Disease", t="Disease", col=OZ_MiscDebuffColour},
				{1,"Magic","*",3, key="Magic", t="Magic", col=OZ_MiscDebuffColour},
				OZ_SetSpellEntry(63666,9,3,1),								-- Napalm (Mimiron)

				{1,"Arcane Blast (Debuff)", "Spell_Arcane_Blast",3,fNoShow=1},

				OZ_SetSpellEntry(62056,1,3,1),								-- Stone Grip (Kologarn)
				OZ_SetSpellEntry(63018,1,3,1),								-- Light Bomb (XT-002 Deconstructor)
				OZ_SetSpellEntry(63024,1,3),								-- Gravity Bomb (XT-002 Deconstructor)
				{1,"Armor Crunch","Ability_Warrior_ShieldBreak",3,fNoHide=1,col=OZ_BossDebuffColour},
				{1,"Slag Pot","INV_GAUNTLETS_66",3,fNoHide=1,col=OZ_BossDebuffColour},
				OZ_SetSpellEntry(62438,9,3,1),								-- Iron Roots (Freya)
				OZ_SetSpellEntry(62590,9,3,1),								-- Natures Fury (Freya)
				OZ_SetSpellEntry(64126,9,3,1),								-- Squeeze (Yogg Saron)
				OZ_SetSpellEntry(69065,9,3,1),								-- Bone Spiked
				OZ_SetSpellEntry(71204,9,3,1),								-- Insignificance
				OZ_SetSpellEntry(71289,9,3,1),								-- Dominate Mind
				OZ_SetSpellEntry(63803,9,3,1),								-- Brain Link (Yogg Saron)
				
				{1,"Dreamless Sleep*", "Spell_Nature_Sleep",3,key=GetSpellInfo(15822),fNoShow=1},
				{1,"Greater Dreamless Sleep*", "Spell_Nature_Sleep",3,key=GetSpellInfo(24360),fNoShow=1},
				{1,"Major Dreamless Sleep*", "Spell_Nature_Sleep",3,key=GetSpellInfo(28504),fNoShow=1},
			},
	Mob = {
				{3,"Sunder Armor", "Ability_Warrior_Sunder",2},
				{3,"Hunter's Mark", "Ability_Hunter_SniperShot",2},
				{2,"Judgement of Justice", "Spell_Holy_SealOfWrath",2},
				{2,"Judgement of the Crusader", "Spell_Holy_HolySmite",2},
				{3,"Judgement of Light", "Spell_Holy_HealingAura",2},
				{3,"Judgement of Wisdom", "Spell_Holy_RighteousnessAura",2},
				{2,"Polymorph", "Spell_Nature_Polymorph",2},
				{2,"Polymorph: Turtle", "Ability_Hunter_Pet_Turtle",2},
				{2,"Polymorph: Pig", "Spell_Magic_PolymorphPig",2},
				{2,"Banish", "Spell_Shadow_Cripple",2},
				{2,"Shackle Undead", "Spell_Nature_Slow",2},
				{2,"Hibernate", "Spell_Nature_Sleep",2}, 
				{2,"Sap", "Ability_Sap",2},
				{2,"Succubus Seduction", "Spell_Shadow_MindSteal",2},
			},
	},

MAGE = {
	-- Default 'interested in' buffs
	Player = {
				{2,"Arcane Brilliance", "Spell_Holy_ArcaneIntellect",1,not_combat=1},
				{2,"Arcane Intellect", "Spell_Holy_MagicalSentry",1,not_combat=1},
				{2,"Dalaran Brilliance", "Achievement_Dungeon_TheVioletHold_Heroic",1,not_combat=1},
				{2,"Dampen Magic", "Spell_Nature_AbolishMagic",1,not_combat=1},
				{2,"Amplify Magic", "Spell_Holy_FlashHeal",1,not_combat=1},
				{3,"Focus Magic", "Spell_Arcane_StudentOfMagic", 1,not_combat=1},
				{1,"Curse","*",3, key="Curse", t="Curse", col=DebuffTypeColor["Curse"]},
			},
	Mob = {
				{3,"Sunder Armor", "Ability_Warrior_Sunder",2},
				{3,"Hunter's Mark", "Ability_Hunter_SniperShot",2},
				{3,"Curse of the Elements", "Spell_Shadow_ChillTouch",2},
				{3,"Winters Chill", "Spell_Frost_FrostBlast",2},
				{2,"Polymorph", "Spell_Nature_Polymorph",2},
				{2,"Polymorph: Turtle", "Ability_Hunter_Pet_Turtle",2},
				{2,"Polymorph: Pig", "Spell_Magic_PolymorphPig",2},
				{2,"Banish", "Spell_Shadow_Cripple",2},
				{2,"Shackle Undead", "Spell_Nature_Slow",2},
				{2,"Hibernate", "Spell_Nature_Sleep",2}, 
				{2,"Sap", "Ability_Sap",2},
				{2,"Succubus Seduction", "Spell_Shadow_MindSteal",2},
			},
	},
DRUID = {
	-- Default 'interested in' buffs
	Player = {
				{2,"Mark of the Wild", "Spell_Nature_Regeneration",1,not_combat=1},
				{2,"Gift of the Wild", "Spell_Nature_GiftoftheWild", 1, not_combat=1},
				{2,"Rejuvenation", "Spell_Nature_Rejuvenation",1},
				{2,"Regrowth", "Spell_Nature_ResistNature",1},
				{1,"Power Word: Shield", "Spell_Holy_PowerWordShield",1,not_ooc=1},
				{1,"Renew", "Spell_Holy_Renew",1},
				{2,"Abolish Poison", "Spell_Nature_NullifyPoison_02",1},
				{1,"Thorns","Spell_Nature_Thorns",1,not_combat=1},
				{3,"Innervate", "Spell_Nature_Lightning",1},
				{2,"Lifebloom", "INV_Misc_Herb_Felblossom",1},
				{2,"Earth Shield","Spell_Nature_SkinofEarth",1},
				{2,"Wild growth", "Ability_Druid_Flourish",1},
				{1,"Riptide","spell_nature_riptide",1},
				{1,"Earthliving","Spell_Shaman_GiftEarthmother",1},
				{1,"Inspiration", "INV_Shield_06",1},
				{1,"Ancestral Fortitude","Spell_Nature_UndyingStrength",1,not_ooc=1},
				{2,"Glyph of Prayer of Healing","Spell_Holy_PrayerOfHealing02",1},
				{1,"Poison","*",3, key="Poison", t="Poison", col=DebuffTypeColor["Poison"]},
				{1,"Curse","*",3, key="Curse", t="Curse", col=DebuffTypeColor["Curse"]},
				OZ_SetSpellEntry(62056,1,3,1),								-- Stone Grip (Kologarn)
				OZ_SetSpellEntry(63018,1,3,1),								-- Light Bomb (XT-002 Deconstructor)
				OZ_SetSpellEntry(63024,1,3),								-- Gravity Bomb (XT-002 Deconstructor)
				OZ_SetSpellEntry(63666,9,3,1),								-- Napalm (Mimiron)
				{1,"Slag Pot","INV_GAUNTLETS_66",3,fNoHide=1,col=OZ_BossDebuffColour},
				{1,"Armor Crunch","Ability_Warrior_ShieldBreak",3,fNoHide=1,col=OZ_BossDebuffColour},
				OZ_SetSpellEntry(62438,9,3,1),								-- Iron Roots (Freya)
				OZ_SetSpellEntry(62590,9,3,1),								-- Natures Fury (Freya)
				OZ_SetSpellEntry(64126,9,3,1),								-- Squeeze (Yogg Saron)
				OZ_SetSpellEntry(63803,9,3,1),								-- Brain Link (Yogg Saron)
				OZ_SetSpellEntry(69065,9,3,1),								-- Bone Spiked
				OZ_SetSpellEntry(71204,9,3,1),								-- Insignificance
				OZ_SetSpellEntry(71289,9,3,1),								-- Dominate Mind
			},
	Mob = {
				{2,"Sunder Armor", "Ability_Warrior_Sunder",2},
				{2,"Hunter's Mark", "Ability_Hunter_SniperShot",2},
				{2,"Polymorph", "Spell_Nature_Polymorph",2},
				{2,"Polymorph: Turtle", "Ability_Hunter_Pet_Turtle",2},
				{2,"Polymorph: Pig", "Spell_Magic_PolymorphPig",2},
				{2,"Banish", "Spell_Shadow_Cripple",2},
				{2,"Shackle Undead", "Spell_Nature_Slow",2},
				{2,"Hibernate", "Spell_Nature_Sleep",2}, 
				{2,"Sap", "Ability_Sap",2},
				{2,"Succubus Seduction", "Spell_Shadow_MindSteal",2},
				{1,"Cyclone","Spell_Nature_EarthBind",2},
			},
	},

ROGUE = {
	-- Default 'interested in' buffs
	Player = {
			},
	Mob = {
				{3,"Sunder Armor", "Ability_Warrior_Sunder",2},
				{3,"Hunter's Mark", "Ability_Hunter_SniperShot",2},
				{2,"Polymorph", "Spell_Nature_Polymorph",2},
				{2,"Polymorph: Turtle", "Ability_Hunter_Pet_Turtle",2},
				{2,"Polymorph: Pig", "Spell_Magic_PolymorphPig",2},
				{2,"Banish", "Spell_Shadow_Cripple",2},
				{2,"Shackle Undead", "Spell_Nature_Slow",2},
				{2,"Hibernate", "Spell_Nature_Sleep",2}, 
				{2,"Succubus Seduction", "Spell_Shadow_MindSteal",2},
			},
	},

WARRIOR = {
	-- Default 'interested in' buffs
	Player = {
			},
	Mob = {
				{3,"Taunt", "Spell_Nature_Reincarnation",2},
				{3,"Sunder Armor", "Ability_Warrior_Sunder",2},
				{3,"ThunderClap", "Spell_Nature_ThunderClap",2},
				{3,"Piercing Howl", "Spell_Shadow_DeathScream",2},
				{2,"Hunter's Mark", "Ability_Hunter_SniperShot",2},
				{2,"Polymorph", "Spell_Nature_Polymorph",2},
				{2,"Polymorph: Turtle", "Ability_Hunter_Pet_Turtle",2},
				{2,"Polymorph: Pig", "Spell_Magic_PolymorphPig",2},
				{2,"Banish", "Spell_Shadow_Cripple",2},
				{2,"Shackle Undead", "Spell_Nature_Slow",2},
				{2,"Hibernate", "Spell_Nature_Sleep",2}, 
				{2,"Succubus Seduction", "Spell_Shadow_MindSteal",2},
				{2,"Sap", "Ability_Sap",2},
				{1,"Magic","*",3, key="Magic", t="Magic", col=DebuffTypeColor["Magic"]},
			},
	},

SHAMAN = {
	-- Default 'interested in' buffs
	Player = {
				{2,"Power Word: Shield", "Spell_Holy_PowerWordShield",1,not_ooc=1},
				{2,"Renew", "Spell_Holy_Renew",1},
				{2,"Rejuvenation", "Spell_Nature_Rejuvenation",1},
				{2,"Regrowth", "Spell_Nature_ResistNature",1},
				{4,"Earth Shield","Spell_Nature_SkinofEarth",1},
				{2,"Wild growth", "Ability_Druid_Flourish",1},
				{3,"Riptide","spell_nature_riptide",1},
				{3,"Earthliving","Spell_Shaman_GiftEarthmother",1},
				{1,"Inspiration", "INV_Shield_06",1},
				{1,"Ancestral Fortitude","Spell_Nature_UndyingStrength",1},
				{2,"Glyph of Prayer of Healing","Spell_Holy_PrayerOfHealing02",1},
				{1,"Poison","*",3, key="Poison", t="Poison", col=OZ_MiscDebuffColour},
				{1,"Disease","*",3, key="Disease", t="Disease", col= OZ_MiscDebuffColour},
				{1,"Curse","*",3, key="Curse", t="Curse", col=OZ_MiscDebuffColour},
				OZ_SetSpellEntry(62056,1,3,1),								-- Stone Grip (Kologarn)
				OZ_SetSpellEntry(63018,1,3,1),								-- Light Bomb (XT-002 Deconstructor)
				OZ_SetSpellEntry(63024,1,3),								-- Gravity Bomb (XT-002 Deconstructor)
				OZ_SetSpellEntry(63666,9,3,1),								-- Napalm (Mimiron)
				{1,"Slag Pot","INV_GAUNTLETS_66",3,fNoHide=1,col=OZ_BossDebuffColour},
				{1,"Armor Crunch","Ability_Warrior_ShieldBreak",3,fNoHide=1,col=OZ_BossDebuffColour},
				OZ_SetSpellEntry(62438,9,3,1),								-- Iron Roots (Freya)
				OZ_SetSpellEntry(62590,9,3,1),								-- Natures Fury (Freya)
				OZ_SetSpellEntry(64126,9,3,1),								-- Squeeze (Yogg Saron)
				OZ_SetSpellEntry(63803,9,3,1),								-- Brain Link (Yogg Saron)
				OZ_SetSpellEntry(69065,9,3,1),								-- Bone Spiked
				OZ_SetSpellEntry(71204,9,3,1),								-- Insignificance
				OZ_SetSpellEntry(71289,9,3,1),								-- Dominate Mind
			},
	Mob = {
				{2,"Hunter's Mark", "Ability_Hunter_SniperShot",2},
				{2,"Polymorph", "Spell_Nature_Polymorph",2},
				{2,"Polymorph: Turtle", "Ability_Hunter_Pet_Turtle",2},
				{2,"Polymorph: Pig", "Spell_Magic_PolymorphPig",2},
				{2,"Banish", "Spell_Shadow_Cripple",2},
				{2,"Shackle Undead", "Spell_Nature_Slow",2},
				{2,"Hibernate", "Spell_Nature_Sleep",2}, 
				{2,"Succubus Seduction", "Spell_Shadow_MindSteal",2},
				{1,"Magic","*",3, key="Magic", t="Magic", col=DebuffTypeColor["Magic"]},
			},
	},
	
DEATHKNIGHT = {
	Player = {
				{1,"Power Word: Shield", "Spell_Holy_PowerWordShield",1},
				{1,"Renew", "Spell_Holy_Renew",1},
				{1,"Rejuvenation", "Spell_Nature_Rejuvenation",1},
				{1,"Regrowth", "Spell_Nature_ResistNature",1},
				{2,"Earth Shield","Spell_Nature_SkinofEarth",1},
			},
	Mob = {
				{2,"Hunter's Mark", "Ability_Hunter_SniperShot",2},
				{2,"Polymorph", "Spell_Nature_Polymorph",2},
				{2,"Polymorph: Turtle", "Ability_Hunter_Pet_Turtle",2},
				{2,"Polymorph: Pig", "Spell_Magic_PolymorphPig",2},
				{2,"Banish", "Spell_Shadow_Cripple",2},
				{2,"Shackle Undead", "Spell_Nature_Slow",2},
				{2,"Hibernate", "Spell_Nature_Sleep",2}, 
				{2,"Succubus Seduction", "Spell_Shadow_MindSteal",2},
				{3,"Blood Plague", "Spell_DeathKnight_BloodPlague",2},
				{3,"Frost Fever", "Spell_DeathKnight_FrostFever",2},
				{2,"Chains of Ice", "Spell_Frost_ChainsOfIce",2},
			},
	},
};




