-- New method, have templates & modifiers
OZ_NIL = "NIL"

OZ_PRESET_TEMPLATES = {
    ["Common"] = {
        ["topCol"] = {["a"] = 0.5,["b"] = 1,["g"] = 1,["r"] = 0,},
        ["bottomCol"] = {["a"] = 0.5,["b"] = 0.6,["g"] = 0,["r"] = 0},
        ["maxBars"] = 40,
        ["barHeight"] = 20,
        ["titleHeight"] = 20,
        ["refresh"] = 0.1,
        ["barTexture"] = "Interface\\Addons\\OzRaid\\bar10",
        ["buttonSize"] = 16,
        ["classNames"] = 1,
        ["width"] = 150,
        ["textSize"] = 12,
        ["nameSize"] = 12,
        ["numSize"] = 12,
        ["barGap"] = 1,
        ["buffSize"] = 1,
        ["active"] = 1,
        ["minBars"] = 0,
		["fadeAlpha"] = 0.4,
		["nameStyle"] = 1,
    },
    ["Raid Overview"] = {
        ["sort1"] = 3,
        ["sort2"] = 0,
        ["sort3"] = 0,
        ["showDebuffIcon"] = 1,
        ["icon"] = 1,
        ["colour"] = 2,
        ["heading"] = { 3,0,0 },
        ["namePos"] = 4,
        ["barDebuffCol"] = 1,
        ["buffPos"] = 2,
        ["nameOnStatus"] = 1,
        ["valueType"] = 1,
        ["rangeFade"] = 1,
        ["showMana"] = 1,
        ["input"] = 1,
        ["tooltips"] = 1,
    },
    ["Raid (Healing)"] = {
        ["sort1"] = 3,
        ["sort2"] = 0,
        ["sort3"] = 0,
        ["showDebuffIcon"] = 1,
        ["icon"] = 1,
        ["colour"] = 2,
        ["heading"] = { 3,0,0 },
        ["namePos"] = 4,
        ["barDebuffCol"] = 1,
        ["buffPos"] = 2,
        ["nameOnStatus"] = 1,
        ["valueType"] = 3,
        ["rangeFade"] = 1,
        ["showMana"] = 1,
        ["input"] = 1,
        ["tooltips"] = 1,
		["bigVals"] = 1,
    },
    ["Mana by class"] = {
        ["sort1"] = 4,
        ["sort2"] = 0,
        ["sort3"] = 0,
        ["icon"] = 1,
        ["colour"] = 3,
        ["heading"] = {0,0,0},
        ["namePos"] = 1,
        ["hideGlow"] = 1,
        ["valuePos"] = 3,
        ["buffPos"] = 2,
        ["hideEmpty"] = 1,
        ["nameOnStatus"] = 1,
        ["valueType"] = 2,
        ["classNames"] = 1,
        ["hideIcon"] = 1,
        ["hideSolo"] = 1,
        ["input"] = 4,
    },
    ["Main Tanks"] = {    
        ["sort1"] = 0,
        ["sort2"] = 0,
        ["sort3"] = 0,
        ["icon"] = 1,
        ["colour"] = 2,
        ["heading"] = {0,0,0},
        ["namePos"] = 4,
        ["hideGlow"] = 1,
        ["outlineNames"] = 1,
        ["buffPos"] = 1,
        ["active"] = 1,
        ["hideEmpty"] = 1,
        ["nameOnStatus"] = 1,
        ["valueType"] = 1,
        ["rangeFade"] = "none",
        ["hideParty"] = 1,
        ["input"] = 8,
        ["classNames"] = 1,
        ["hideSolo"] = 1,
    },
    ["MT T T"] = {
        ["sort1"] = 0,
        ["sort2"] = 0,
        ["sort3"] = 0,
        ["colour"] = 2,
        ["heading"] = {0,0,0,},
        ["namePos"] = 4,
        ["hideGlow"] = 1,
        ["barDebuffCol"] = 1,
        ["buffPos"] = 1,
        ["hideEmpty"] = 1,
        ["valueType"] = 2,
        ["hideSolo"] = 1,
        ["classNames"] = 1,
        ["hideParty"] = 1,
        ["hideIcon"] = 1,
        ["input"] = 10,
        ["icon"] = 1,
    },
    ["MT Targets"] = {
        ["sort1"] = 0,
        ["sort2"] = 0,
        ["sort3"] = 0,
        ["hideSolo"] = 1,
        ["colour"] = 2,
        ["heading"] = {0,0,0},
        ["namePos"] = 1,
        ["hideGlow"] = 1,
        ["barDebuffCol"] = 1,
        ["valuePos"] = 3,
        ["buffPos"] = 3,
        ["hideEmpty"] = 1,
        ["nameOnStatus"] = 1,
        ["valueType"] = 2,
        ["icon"] = 1,
        ["hideParty"] = 1,
        ["buffSize"] = 1,
        ["input"] = 9,
    }, -- [7]
    ["No Buffs"] = {
 		buff_ooc = {
			{ -- 1, player buffs
   			},
			{ -- 2, mob debuffs
			},
			{ -- 3, player debuffs
			},
			{ -- 4, mob buffs
			},
	    },
		buff_combat = {
			{ -- 1, player buffs
   			},
			{ -- 2, mob debuffs
			},
			{ -- 3, player debuffs
			},
			{ -- 4, mob buffs
			},
	    },
   },
    ["Major Raid Buffs"] = {
        buff_ooc = {
			{ -- 1, player buffs
				["Interface\\Icons\\Spell_Shadow_AntiShadow"] = {2,"Shadow Protection","Interface\\Icons\\Spell_Shadow_AntiShadow",1},
				["Interface\\Icons\\Spell_Holy_WordFortitude"] = {1,"Power Word: Fortitude","Interface\\Icons\\Spell_Holy_WordFortitude",1},
				["Interface\\Icons\\Spell_Holy_MagicalSentry"] = {0,"Arcane Intellect","Interface\\Icons\\Spell_Holy_MagicalSentry",1},
				["Interface\\Icons\\Spell_Nature_GiftoftheWild"] = {3,"Gift of the Wild","Interface\\Icons\\Spell_Nature_GiftoftheWild",1},
				["Interface\\Icons\\Spell_Holy_PrayerofShadowProtection"] = {2,"Prayer of Shadow Protection","Interface\\Icons\\Spell_Holy_PrayerofShadowProtection",1},
				["Interface\\Icons\\Spell_Holy_ArcaneIntellect"] = {0,"Arcane Brilliance","Interface\\Icons\\Spell_Holy_ArcaneIntellect",1},
				["Interface\\Icons\\Spell_Holy_PrayerOfFortitude"] = {1,"Prayer of Fortitude","Interface\\Icons\\Spell_Holy_PrayerOfFortitude",1},
				["Interface\\Icons\\Spell_Nature_Regeneration"] = {3,"Mark of the Wild","Interface\\Icons\\Spell_Nature_Regeneration",1},
				["Interface\\Icons\\Spell_Holy_DivineSpirit"] = {2,"Divine Spirit", "Interface\\Icons\\Spell_Holy_DivineSpirit", 1},
				["Interface\\Icons\\Spell_Holy_PrayerofSpirit"] = {2,"Prayer of Spirit", "Interface\\Icons\\Spell_Holy_PrayerofSpirit", 1},
   			},
			{ -- 2, mob debuffs
			},
			{ -- 3, player debuffs
			},
			{ -- 4, mob buffs
			},
	    },
		buff_combat = {
			{ -- 1, player buffs
   			},
			{ -- 2, mob debuffs
			},
			{ -- 3, player debuffs
			},
			{ -- 4, mob buffs
			},
	    },
    },
    ["Class Default"] = { func = OZ_BuffsDefault },
	
    ["Mob Buffs"] = {
		buff_ooc = {
			{ -- 1, player buffs
   			},
			{ -- 2, mob debuffs
			},
			{ -- 3, player debuffs
			},
			{ -- 4, mob buffs
			},
	    },
		buff_combat = {
			{ -- 1, player buffs
   			},
			{ -- 2, mob debuffs
				["Interface\\Icons\\Spell_Shadow_ChillTouch"] = {3,"Curse of the Elements","Interface\\Icons\\Spell_Shadow_ChillTouch",2},
				["Interface\\Icons\\Spell_Magic_PolymorphPig"] = {2,"Polymorph: Pig","Interface\\Icons\\Spell_Magic_PolymorphPig",2},
				["Interface\\Icons\\Ability_Hunter_Pet_Turtle"] = {2,"Polymorph: Turtle","Interface\\Icons\\Ability_Hunter_Pet_Turtle",2},
				["Interface\\Icons\\Spell_Nature_Slow"] = {2,"Shackle Undead","Interface\\Icons\\Spell_Nature_Slow",2},
				["Interface\\Icons\\Spell_Frost_FrostBlast"] = {3,"Winters Chill","Interface\\Icons\\Spell_Frost_FrostBlast",2},
				["Interface\\Icons\\Spell_Holy_RighteousnessAura"] = {2,"Judgement of Wisdom","Interface\\Icons\\Spell_Holy_RighteousnessAura",2},
				["Interface\\Icons\\Ability_Sap"] = {2,"Sap","Interface\\Icons\\Ability_Sap",2},
				["Interface\\Icons\\Spell_Nature_Sleep"] = {2,"Hibernate","Interface\\Icons\\Spell_Nature_Sleep",2},
				["Interface\\Icons\\Spell_Nature_Polymorph"] = {2,"Polymorph","Interface\\Icons\\Spell_Nature_Polymorph",2},
				["Interface\\Icons\\Ability_Warrior_Sunder"] = {3,"Sunder Armor","Interface\\Icons\\Ability_Warrior_Sunder",2},
				["Interface\\Icons\\Spell_Shadow_Cripple"] = {2,"Banish","Interface\\Icons\\Spell_Shadow_Cripple",2},
				["Interface\\Icons\\Ability_Hunter_SniperShot"] = {3,"Hunter's Mark","Interface\\Icons\\Ability_Hunter_SniperShot",2},
				["Interface\\Icons\\Spell_Shadow_MindSteal"] = {2,"Mind Control","Interface\\Icons\\Spell_Shadow_MindSteal",2},
			},
			{ -- 3, player debuffs
			},
			{ -- 4, mob buffs
			},
	    },
    },
	["Consumables"] = {
		buff_ooc = {
			{ -- 1, player buffs
				Spell_Misc_Food = {3,"Well Fed","Spell_Misc_Food",1},
				INV_Alchemy_EndlessFlask_04 = {2,"Flask of the Frost Wyrm", "INV_Alchemy_EndlessFlask_04", 1},
				INV_Alchemy_EndlessFlask_05 = {2,"Flask of the Stoneblood", "INV_Alchemy_EndlessFlask_05", 1},
				INV_Alchemy_EndlessFlask_03 = {2,"Flask of the Pure Mojo", "INV_Alchemy_EndlessFlask_03", 1},
				INV_Alchemy_EndlessFlask_06 = {2,"Flask of the Endless Rage", "INV_Alchemy_EndlessFlask_06", 1},
				INV_Alchemy_EndlessFlask_02 = {2,"Lesser Flask of the Toughness", "INV_Alchemy_EndlessFlask_02", 1},
				
				INV_Potion_161 = {1,"Elixir of Mighty Thoughts", "INV_Potion_161", 1},
				INV_Potion_165 = {1,"Elixir of Mighty Strength", "INV_Potion_165", 1},
				INV_Potion_129 = {1,"Elixir of Mighty Mageblood", "INV_Potion_129", 1},
				INV_Potion_164 = {1,"Elixir of Mighty Fortitude", "INV_Potion_164", 1},
				INV_Alchemy_Potion_03 = {1,"Elixir of Mighty Defense", "INV_Alchemy_Potion_03", 1},
				INV_Potion_162 = {1,"Elixir of Mighty Agility", "INV_Potion_162", 1},
				INV_Alchemy_Potion_04 = {1,"Elixir of Lightning Speed", "INV_Alchemy_Potion_04", 1},
				INV_Alchemy_Potion_01 = {1,"Elixir of Expertise", "INV_Alchemy_Potion_01", 1},
				INV_Alchemy_Potion_02 = {1,"Elixir of Deadly Strikes", "INV_Alchemy_Potion_02", 1},
				INV_Alchemy_Potion_06 = {1,"Elixir of Armor Piercing", "INV_Alchemy_Potion_06", 1},
				INV_Potion_61 = {1,"Elixir of Accuracy", "INV_Potion_61", 1},
				INV_Potion_112 = {1,"Guru's Elixir", "INV_Potion_112", 1},
				INV_Alchemy_Potion_05 = {1,"Spellpower Elixir", "INV_Alchemy_Potion_05", 1},
				INV_Potion_114 = {1,"Wrath Elixir", "INV_Potion_114", 1},
				INV_Potion_111 = {1,"Bloodberry Elixir", "INV_Potion_111", 1},                
   			},
			{ -- 2, mob debuffs
			},
			{ -- 3, player debuffs
			},
			{ -- 4, mob buffs
			},
	    },
		buff_combat = {
			{ -- 1, player buffs
   			},
			{ -- 2, mob debuffs
			},
			{ -- 3, player debuffs
			},
			{ -- 4, mob buffs
			},
	    },
	},
--[[
    ["Mob Buffs"] = {
		buff_ooc = {
			{ -- 1, player buffs
   			},
			{ -- 2, mob debuffs
			},
			{ -- 3, player debuffs
			},
			{ -- 4, mob buffs
			},
	    },
		buff_combat = {
			{ -- 1, player buffs
   			},
			{ -- 2, mob debuffs
			},
			{ -- 3, player debuffs
			},
			{ -- 4, mob buffs
			},
	    },
	},
]]--
	
    ["All Filters"] = {
        ["filter"] =
        {
            ["status"] = {
                ["inrange"] = 1,
                ["close"] = 1,
                ["curable"] = 1,
                ["buffed"] = 1,
                ["outofrange"] = 1,
                ["online"] = 1,
                ["notbuffed"] = 1,
                ["injured"] = 1,
                ["dead"] = 1,
                ["offline"] = 1,
                ["healthy"] = 1,
                ["notcurable"] = 1,
            },
            ["class"] = {
                ["DEATHKNIGHT"] = 1,
                ["HUNTER"] = 1,
                ["WARRIOR"] = 1,
                ["TARGET"] = 1,
                ["PALADIN"] = 1,
                ["MAGE"] = 1,
                ["PRIEST"] = 1,
                ["ROGUE"] = 1,
                ["WARLOCK"] = 1,
                ["PET"] = 1,
                ["DRUID"] = 1,
                ["SHAMAN"] = 1,
                ["DEATHKNIGHTPET"] = OZ_NIL,   -- Ignore temporary pets
                ["HUNTERPET"] = 1,
                ["MAGEPET"] = OZ_NIL,
                ["PRIESTPET"] = OZ_NIL,
                ["SHAMANPET"] = OZ_NIL,
                ["WARLOCKPET"] = 1,
            },
            ["injuredVal"] = 1,
            ["group"] = {1,1,1,1,1,1,1,1},
        },
    },
	["ODD groups"] = {
		["filter"] = {
			["group"] = {1,OZ_NIL,1,OZ_NIL,1,OZ_NIL,1,OZ_NIL},
		}
	},
	["EVEN groups"] = {
		["filter"] = {
			["group"] = {OZ_NIL,1,OZ_NIL,1,OZ_NIL,1,OZ_NIL,1},
		}
	},
    ["Mana Users"] = {
        ["filter"] =
        {
            ["status"] = {
                ["inrange"] = 1,
                ["close"] = 1,
                ["curable"] = 1,
                ["buffed"] = 1,
                ["outofrange"] = 1,
                ["online"] = 1,
                ["notbuffed"] = 1,
                ["injured"] = 1,
                ["dead"] = 1,
                ["offline"] = 1,
                ["healthy"] = 1,
                ["notcurable"] = 1,
            },
            ["class"] = {
                ["HUNTER"] = 1,
                ["PALADIN"] = 1,
                ["MAGE"] = 1,
                ["PRIEST"] = 1,
                ["WARLOCK"] = 1,
                ["DRUID"] = 1,
                ["SHAMAN"] = 1,
            },
            ["injuredVal"] = 1,
            ["group"] = {1,1,1,1,1,1,1,1,1},
        },
    },
    ["No Pets"] = {
        ["filter"] =
        {
            ["class"] = {
                ["DEATHKNIGHT"] = 1,
                ["HUNTER"] = 1,
                ["WARRIOR"] = 1,
                ["TARGET"] = 1,
                ["PALADIN"] = 1,
                ["MAGE"] = 1,
                ["PRIEST"] = 1,
                ["ROGUE"] = 1,
                ["WARLOCK"] = 1,
                ["PET"] = OZ_NIL,
                ["DRUID"] = 1,
                ["SHAMAN"] = 1,
                ["DEATHKNIGHTPET"] = OZ_NIL,   -- Ignore temporary pets
                ["HUNTERPET"] = 1,
                ["MAGEPET"] = OZ_NIL,
                ["PRIESTPET"] = OZ_NIL,
                ["SHAMANPET"] = OZ_NIL,
                ["WARLOCKPET"] = 1,
            },
        },
    },
    ["Pets (Permanent)"] = {
        ["filter"] =
        {
            ["class"] = {
                ["DEATHKNIGHT"] = OZ_NIL,
                ["HUNTER"] = OZ_NIL,
                ["WARRIOR"] = OZ_NIL,
                ["TARGET"] = OZ_NIL,
                ["PALADIN"] = OZ_NIL,
                ["MAGE"] = OZ_NIL,
                ["PRIEST"] = OZ_NIL,
                ["ROGUE"] = OZ_NIL,
                ["WARLOCK"] = OZ_NIL,
                ["PET"] = 1,
                ["DRUID"] = OZ_NIL,
                ["SHAMAN"] = OZ_NIL,
                ["DEATHKNIGHTPET"] = OZ_NIL,   -- Ignore temporary pets
                ["HUNTERPET"] = 1,
                ["MAGEPET"] = OZ_NIL,
                ["PRIESTPET"] = OZ_NIL,
                ["SHAMANPET"] = OZ_NIL,
                ["WARLOCKPET"] = 1,
            },
        },
    },
};


OZ_PRESETS = {
	["Generic"] = {
		["Raid View (No pets)"] = {
            ["templates"] = {
                OZ_PRESET_TEMPLATES["Common"],
                OZ_PRESET_TEMPLATES["Raid Overview"],
				OZ_PRESET_TEMPLATES["Class Default"],
                OZ_PRESET_TEMPLATES["All Filters"],
                OZ_PRESET_TEMPLATES["No Pets"],
            },
            ["custom"] = {
                ["text"] = "Raid View",
            },
		},
		["2 Columns (ODD)"] = {
            ["templates"] = {
                OZ_PRESET_TEMPLATES["Common"],
                OZ_PRESET_TEMPLATES["Raid Overview"],
				OZ_PRESET_TEMPLATES["Class Default"],
                OZ_PRESET_TEMPLATES["All Filters"],
                OZ_PRESET_TEMPLATES["ODD groups"],
                OZ_PRESET_TEMPLATES["No Pets"],
            },
            ["custom"] = {
                ["text"] = "Raid 1,3,5,7",
            },
		},
		["2 Columns (EVEN)"] = {
            ["templates"] = {
                OZ_PRESET_TEMPLATES["Common"],
                OZ_PRESET_TEMPLATES["Raid Overview"],
				OZ_PRESET_TEMPLATES["Class Default"],
                OZ_PRESET_TEMPLATES["All Filters"],
                OZ_PRESET_TEMPLATES["EVEN groups"],
                OZ_PRESET_TEMPLATES["No Pets"],
            },
            ["custom"] = {
                ["text"] = "Raid 1,3,5,7",
            },
		},
		["Hunter/Lock pets"] = {
            ["templates"] = {
                OZ_PRESET_TEMPLATES["Common"],
                OZ_PRESET_TEMPLATES["Raid Overview"],
				OZ_PRESET_TEMPLATES["Class Default"],
                OZ_PRESET_TEMPLATES["All Filters"],
                OZ_PRESET_TEMPLATES["Pets (Permanent)"],
            },
            ["custom"] = {
                ["text"] = "Raid Pets",
            },
		},
	},
	["Raid Leading"] = {
		["Raid Leader View"] = {
            ["templates"] = {
                OZ_PRESET_TEMPLATES["Common"],
                OZ_PRESET_TEMPLATES["Raid Overview"],
                OZ_PRESET_TEMPLATES["Major Raid Buffs"],
				OZ_PRESET_TEMPLATES["Class Default"],
                OZ_PRESET_TEMPLATES["Consumables"],
                OZ_PRESET_TEMPLATES["All Filters"],
            },
            ["custom"] = {
                ["text"] = "Raid View",
            },
		},
		["Mana by class"] = {
            ["templates"] = {
                OZ_PRESET_TEMPLATES["Common"],
                OZ_PRESET_TEMPLATES["Mana by class"],
                OZ_PRESET_TEMPLATES["No Buffs"],
                OZ_PRESET_TEMPLATES["Mana Users"],
            },
            ["custom"] = {
                ["maxBars"] = 8,
                ["text"] = "Class Mana",
            },
        },
	},
	["Main Tanks (oRA)"] = {
		["Main Tanks"] = {
            ["templates"] = {
                OZ_PRESET_TEMPLATES["Common"],
                OZ_PRESET_TEMPLATES["Main Tanks"],
				OZ_PRESET_TEMPLATES["Class Default"],
                OZ_PRESET_TEMPLATES["All Filters"],
            },
            ["custom"] = {
                ["maxBars"] = 10,
                ["text"] = "Main Tanks",
                ["refresh"] = 0.2,
            },
		}, 
		["MT's T's Target"] = {
            ["templates"] = {
                OZ_PRESET_TEMPLATES["Common"],
                OZ_PRESET_TEMPLATES["MT T T"],
				OZ_PRESET_TEMPLATES["Class Default"],
                OZ_PRESET_TEMPLATES["All Filters"],
            },
            ["custom"] = {
                ["maxBars"] = 10,
                ["text"] = "MT T's T",
                ["refresh"] = 0.3,
            },
        },        
		["Main Tank Targets"] = {
            ["templates"] = {
                OZ_PRESET_TEMPLATES["Common"],
                OZ_PRESET_TEMPLATES["MT Targets"],
				OZ_PRESET_TEMPLATES["Class Default"],
                OZ_PRESET_TEMPLATES["All Filters"],
            },
            ["custom"] = {
                ["maxBars"] = 10,
                ["text"] = "MT Targets",
                ["refresh"] = 0.3,
            },
        },
	},
};
