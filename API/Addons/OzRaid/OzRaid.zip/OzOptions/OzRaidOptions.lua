local k,v,_

local function print(text)
	DEFAULT_CHAT_FRAME:AddMessage("|c0033CCFF"..text);
end

if GetAchievementInfo then
	function OZ_SetDropdownWidth(what,width,pad)
		UIDropDownMenu_SetWidth(what,width,pad)
	end
else
	function OZ_SetDropdownWidth(what,width)
		UIDropDownMenu_SetWidth(width,what)
	end
end

local function gg(text)
	local ret = getglobal(text)
	if(not ret) then
		DEFAULT_CHAT_FRAME:AddMessage("|c00FF8800".."OzRaid: Failed to find: "..text);
	end
	return ret
end



local LibStub = _G["LibStub"]
local media
if LibStub then
	media = LibStub:GetLibrary("LibSharedMedia-3.0")
	print("OzRaid Options: Found Shared Media")
end
OZ_BarTextures = {
					{"<none>",nil},
					{"Normal","Interface\\Addons\\OzRaid\\bar1"},
					{"Toplight","Interface\\Addons\\OzRaid\\bar2"},
					{"Glass","Interface\\Addons\\OzRaid\\bar3"},
					{"Textured Glass","Interface\\Addons\\OzRaid\\bar4"},
					{"Bubble Glass","Interface\\Addons\\OzRaid\\bar5"},
					{"Electro","Interface\\Addons\\OzRaid\\bar6"},
					{"Cross Texture","Interface\\Addons\\OzRaid\\bar7"},
					{"Ribbed","Interface\\Addons\\OzRaid\\bar8"},
					{"Narrow","Interface\\Addons\\OzRaid\\bar9"},
					{"Edged Fade","Interface\\Addons\\OzRaid\\bar10"},
					{"Edged Fade2","Interface\\Addons\\OzRaid\\bar11"},
					{"Lite Step","Interface\\Addons\\OzRaid\\LiteStep"},
					{"HealBot","Interface\\Addons\\OzRaid\\HealBot"},
				}
function OzAddBarTexture(name)
	if media then
		local t = media:Fetch("statusbar",name)
		if t then table.insert(OZ_BarTextures, {name,t} ) end
	end
end
OzAddBarTexture("Otravi")
OzAddBarTexture("Smooth")
OzAddBarTexture("Smudge")
OzAddBarTexture("Charcoal")
OzAddBarTexture("BantoBar")
OzAddBarTexture("Perl")
OzAddBarTexture("Striped")

OZ_OptionsCurrentWindow = 1

OZ_OptionsCheckboxes={
						{ widget="OzRaidOptionsPresetsIsActive", text="Enable/Show this window", get=function()return OZ_Config[OZ_OptionsCurrentWindow].active;end, set=function(i) OZ_Config[OZ_OptionsCurrentWindow].active=i;end },
						{ widget="OzRaidOptionsPresetsToolTips", text="Show Unit ToolTips (only if not in combat)", get=function()return OZ_Config[OZ_OptionsCurrentWindow].tooltips;end, set=function(i) OZ_Config[OZ_OptionsCurrentWindow].tooltips=i;end },
						{ widget="OzRaidOptionsPresetsLock",	 text="Lock Window Position (hold ALT to move them)\nNote: Windows auto-lock in combat", get=function()return OZ_Config[OZ_OptionsCurrentWindow].locked;end, set=function(i) OZ_Config[OZ_OptionsCurrentWindow].locked=i;end },
						{ widget="OzRaidOptionsPresetsMiniIcon", text="Minimap Icon", get=function()return OZ_Config.minimapShow;end, set=function(i) OZ_Config.minimapShow=i;end },
						{ widget="OzRaidOptionsPresetsRadio11", text="Show" },
						{ widget="OzRaidOptionsPresetsRadio12", text="Hide" },
						{ widget="OzRaidOptionsPresetsRadio13", text="Don't change" },
						{ widget="OzRaidOptionsPresetsRadio21", text="Show" },
						{ widget="OzRaidOptionsPresetsRadio22", text="Hide" },
						{ widget="OzRaidOptionsPresetsRadio23", text="Don't change" },

						{ widget="OzRaidOptionsInputsCheck1", text="Show Mini-Manabars (if they have mana)", get=function()return OZ_Config[OZ_OptionsCurrentWindow].showMana;end, set=function(i) OZ_Config[OZ_OptionsCurrentWindow].showMana=i;end },

						{ widget="OzRaidOptionsInputsCheckG1", text="Group 1", get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.group[1];end, set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.group[1]=i;end },
						{ widget="OzRaidOptionsInputsCheckG2", text="Group 2", get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.group[2];end, set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.group[2]=i;end },
						{ widget="OzRaidOptionsInputsCheckG3", text="Group 3", get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.group[3];end, set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.group[3]=i;end },
						{ widget="OzRaidOptionsInputsCheckG4", text="Group 4", get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.group[4];end, set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.group[4]=i;end },
						{ widget="OzRaidOptionsInputsCheckG5", text="Group 5", get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.group[5];end, set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.group[5]=i;end },
						{ widget="OzRaidOptionsInputsCheckG6", text="Group 6", get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.group[6];end, set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.group[6]=i;end },
						{ widget="OzRaidOptionsInputsCheckG7", text="Group 7", get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.group[7];end, set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.group[7]=i;end },
						{ widget="OzRaidOptionsInputsCheckG8", text="Group 8", get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.group[8];end, set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.group[8]=i;end },
						{ widget="OzRaidOptionsInputsCheckParty", text="Force Show", get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.group[9];end,
							set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.group[9]=i; if i and OZ_Config[OZ_OptionsCurrentWindow].filter.group[10] then OZ_Config[OZ_OptionsCurrentWindow].filter.group[10]=nil; OzRaidOptionsInputsCheckHidePartyButton:SetChecked(nil);  end; end },
						{ widget="OzRaidOptionsInputsCheckHideParty", text="Force Hide", get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.group[10];end,
							set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.group[10]=i; if i and OZ_Config[OZ_OptionsCurrentWindow].filter.group[9] then OZ_Config[OZ_OptionsCurrentWindow].filter.group[9]=nil;  OzRaidOptionsInputsCheckPartyButton:SetChecked(nil); end; end },

						{ widget="OzRaidOptionsInputsCheckDk",	text="D.Knight",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.DEATHKNIGHT;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.DEATHKNIGHT=i;end },
						{ widget="OzRaidOptionsInputsCheckDr",	text="Druid",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.DRUID;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.DRUID=i;end },
						{ widget="OzRaidOptionsInputsCheckHu", text="Hunter",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.HUNTER;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.HUNTER=i;end },
						{ widget="OzRaidOptionsInputsCheckMa", text="Mage",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.MAGE;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.MAGE=i;end },
						{ widget="OzRaidOptionsInputsCheckPr", text="Priest",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.PRIEST;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.PRIEST=i;end },
						{ widget="OzRaidOptionsInputsCheckPa", text="Paladin",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.PALADIN;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.PALADIN=i;end },
						{ widget="OzRaidOptionsInputsCheckRo", text="Rogue",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.ROGUE;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.ROGUE=i;end },
						{ widget="OzRaidOptionsInputsCheckSh", text="Shaman",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.SHAMAN;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.SHAMAN=i;end },
						{ widget="OzRaidOptionsInputsCheckWa", text="Warlock", get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.WARLOCK;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.WARLOCK=i;end },
						{ widget="OzRaidOptionsInputsCheckWr", text="Warrior", get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.WARRIOR;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.WARRIOR=i;end },
						{ widget="OzRaidOptionsInputsCheckPet", text="Pets",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.PET;	end,
																				set=function(i)
																				if i then
																					OzRaidOptionsInputsCheckPetDkButton:Enable();OzRaidOptionsInputsCheckPetDkButtonText:SetTextColor(1,0.8,0);
																					OzRaidOptionsInputsCheckPetHuButton:Enable();OzRaidOptionsInputsCheckPetHuButtonText:SetTextColor(1,0.8,0);
																					OzRaidOptionsInputsCheckPetMaButton:Enable();OzRaidOptionsInputsCheckPetMaButtonText:SetTextColor(1,0.8,0);
																					OzRaidOptionsInputsCheckPetPrButton:Enable();OzRaidOptionsInputsCheckPetPrButtonText:SetTextColor(1,0.8,0);
																					OzRaidOptionsInputsCheckPetShButton:Enable();OzRaidOptionsInputsCheckPetShButtonText:SetTextColor(1,0.8,0);
																					OzRaidOptionsInputsCheckPetWaButton:Enable();OzRaidOptionsInputsCheckPetWaButtonText:SetTextColor(1,0.8,0);
																				else
																					OzRaidOptionsInputsCheckPetDkButton:Disable();OzRaidOptionsInputsCheckPetDkButtonText:SetTextColor(0.6,0.6,0.6);
																					OzRaidOptionsInputsCheckPetHuButton:Disable();OzRaidOptionsInputsCheckPetHuButtonText:SetTextColor(0.6,0.6,0.6);
																					OzRaidOptionsInputsCheckPetMaButton:Disable();OzRaidOptionsInputsCheckPetMaButtonText:SetTextColor(0.6,0.6,0.6);
																					OzRaidOptionsInputsCheckPetPrButton:Disable();OzRaidOptionsInputsCheckPetPrButtonText:SetTextColor(0.6,0.6,0.6);
																					OzRaidOptionsInputsCheckPetShButton:Disable();OzRaidOptionsInputsCheckPetShButtonText:SetTextColor(0.6,0.6,0.6);
																					OzRaidOptionsInputsCheckPetWaButton:Disable();OzRaidOptionsInputsCheckPetWaButtonText:SetTextColor(0.6,0.6,0.6);
																				end
																				OZ_Config[OZ_OptionsCurrentWindow].filter.class.PET=i;
																				end },
						{ widget="OzRaidOptionsInputsCheckTarget", text="Target",		get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.TARGET;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.TARGET=i;end },

						{ widget="OzRaidOptionsInputsCheckPetDk",	text="Pet",   	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.DEATHKNIGHTPET;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.DEATHKNIGHTPET=i;end },
						{ widget="OzRaidOptionsInputsCheckPetHu",	text="Pet",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.HUNTERPET;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.HUNTERPET=i;end },
						{ widget="OzRaidOptionsInputsCheckPetMa",	text="Pet",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.MAGEPET;	    end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.MAGEPET=i;end },
						{ widget="OzRaidOptionsInputsCheckPetPr",	text="Pet",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.PRIESTPET;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.PRIESTPET=i;end },
						{ widget="OzRaidOptionsInputsCheckPetSh",	text="Pet",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.SHAMANPET;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.SHAMANPET=i;end },
						{ widget="OzRaidOptionsInputsCheckPetWa",	text="Pet",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.class.WARLOCKPET;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.class.WARLOCKPET=i;end },
						
						{ widget="OzRaidOptionsInputsCheck18", text="Healthy",		get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.status.healthy;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.status.healthy=i;end },
						{ widget="OzRaidOptionsInputsCheck19", text="Injured",		get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.status.injured;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.status.injured=i;end },
						{ widget="OzRaidOptionsInputsCheck20", text="Buffed",		get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.status.buffed;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.status.buffed=i;end },
						{ widget="OzRaidOptionsInputsCheck21", text="Not Buffed",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.status.notbuffed;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.status.notbuffed=i;end },
						{ widget="OzRaidOptionsInputsCheck22", text="Curable",		get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.status.curable;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.status.curable=i;end },
						{ widget="OzRaidOptionsInputsCheck23", text="Not Curable",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.status.notcurable;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.status.notcurable=i;end },
						{ widget="OzRaidOptionsInputsCheck24", text="<11 yards",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.status.close;end,		set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.status.close=i;end },
						{ widget="OzRaidOptionsInputsCheck25", text="11-30 yards",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.status.inrange;end,		set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.status.inrange=i;end },
						{ widget="OzRaidOptionsInputsCheck26", text=">30 yards",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.status.outofrange;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.status.outofrange=i;end },

						{ widget="OzRaidOptionsInputsCheck27", text="Dead",		get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.status.dead;end,			set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.status.dead=i;end },
						{ widget="OzRaidOptionsInputsCheck28", text="Offline",		get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.status.offline;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.status.offline=i;end },
						{ widget="OzRaidOptionsInputsCheck29", text="Online",		get=function()return OZ_Config[OZ_OptionsCurrentWindow].filter.status.online;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].filter.status.online=i;end },

						{ widget="OzRaidOptionsDisplayFadeName", text="Fade Name too", get=function()return OZ_Config[OZ_OptionsCurrentWindow].fadeName;end, set=function(i) OZ_Config[OZ_OptionsCurrentWindow].fadeName=i;end },

						{ widget="OzRaidOptionsSortsCheck1", text="Show Headings",},
						{ widget="OzRaidOptionsSortsCheck2", text="Show Headings",},
						{ widget="Oz_Check_HideAggro", text="Show 'Aggro' glowy icon",	get=function()return not OZ_Config[OZ_OptionsCurrentWindow].hideGlow;	end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].hideGlow= not i;end },

						{ widget="OzRaidOptionsDisplayCheck1", text="Left",},
						{ widget="OzRaidOptionsDisplayCheck2", text="On Bar",},
						{ widget="OzRaidOptionsDisplayCheck3", text="Right",},
						{ widget="OzRaidOptionsDisplayCheck4", text="Left",},
						{ widget="OzRaidOptionsDisplayCheck5", text="On Bar",},
						{ widget="OzRaidOptionsDisplayCheck6", text="Right",},
						{ widget="OzRaidOptionsDisplayCheck7", text="Big Icons",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].buffSize;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].buffSize=i;end },
						{ widget="OzRaidOptionsDisplayCheck8", text="Colour Name with Class Colour",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].classNames;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].classNames=i;end },
						{ widget="OzRaidOptionsDisplayCheck9", text="Add a black outline on names",		get=function()return OZ_Config[OZ_OptionsCurrentWindow].outlineNames;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].outlineNames=i;end },
						{ widget="Oz_Check_Fade", text="Fade on Range", get=function()return OZ_Config[OZ_OptionsCurrentWindow].rangeFade;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].rangeFade=i;end },
						{ widget="OzRaidOptionsDisplayCheck11", text="Off",},
						{ widget="OzRaidOptionsDisplayCheck12", text="Left",},
						{ widget="OzRaidOptionsDisplayCheck13", text="Centre",},
						{ widget="OzRaidOptionsDisplayCheck14", text="Right1",},
						{ widget="OzRaidOptionsDisplayCheck15", text="Right2",},
						{ widget="OzRaidOptionsDisplayCheck16", text="Value",},
						{ widget="OzRaidOptionsDisplayCheck17", text="Percent",},
						{ widget="OzRaidOptionsDisplayCheck18", text="Deficit",},
						{ widget="OzRaidOptionsDisplayCheck19", text="Red name if unit is dead",			get=function()return OZ_Config[OZ_OptionsCurrentWindow].nameOnStatus;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].nameOnStatus=i;end },
--						{ widget="OzRaidOptionsDisplayCheck20", text="Debuff Colour",		get=function()return OZ_Config[OZ_OptionsCurrentWindow].barDebuffCol;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].barDebuffCol=i;end },
						{ widget="OzRaidOptionsDisplayCheck21", text="Show Debuff as Icon",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].showDebuffIcon;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].showDebuffIcon=i;end },
						{ widget="OzRaidOptionsDisplayCheck22", text="Centre",},
						{ widget="OzRaidOptionsDisplayCheck23", text="Show Status Icon",	get=function()return not OZ_Config[OZ_OptionsCurrentWindow].hideIcon;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].hideIcon=not i;end },
--						{ widget="OzRaidOptionsDisplayCheck24", text="All Debuffs",			get=function()return OZ_Config[OZ_OptionsCurrentWindow].allDebuffs;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].allDebuffs=i;end },
						{ widget="OzRaidOptionsDisplayCheckBigVal", text="Use small font for last 3 digits",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].bigVals;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].bigVals=i;end },
	
						{ widget="OzRaidOptionsBuffsHideTimer", text="Hide Buff Timers",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].hideTimers;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].hideTimers=i;end },

						{ widget="OZOpt_HideTitle", text="Hide title bar",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].hideTitle;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].hideTitle=i;end },
						{ widget="OZOpt_HideBG", text="Hide Window Background",		get=function()return OZ_Config[OZ_OptionsCurrentWindow].hideBG;end,		set=function(i) OZ_Config[OZ_OptionsCurrentWindow].hideBG=i;end },
						{ widget="OZOpt_HideEmpty", text="Hide when empty",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].hideEmpty;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].hideEmpty=i;end },
						{ widget="OZOpt_HideSolo", text="Hide when solo",		get=function()return OZ_Config[OZ_OptionsCurrentWindow].hideSolo;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].hideSolo=i;end },
						{ widget="OZOpt_HideParty", text="Hide in party",		get=function()return OZ_Config[OZ_OptionsCurrentWindow].hideParty;end,	set=function(i) OZ_Config[OZ_OptionsCurrentWindow].hideParty=i;end },
						{ widget="OZOpt_HideButtons", text="Hide title bar buttons",	get=function()return OZ_Config[OZ_OptionsCurrentWindow].hideButtons;end,set=function(i) OZ_Config[OZ_OptionsCurrentWindow].hideButtons=i;end },
						{ widget="OZOpt_GrowUp", text="Grow Window Up (anchor at the bottom)",			get=function()return OZ_Config[OZ_OptionsCurrentWindow].growup;end,		set=function(i) OZ_Config[OZ_OptionsCurrentWindow].growup=i;end },
					};

OZ_SLIDERS = {
	{
		widget = "OzRaidOptionsPresetsMiniAngle",
		get = function()return OZ_Config.minimapAngle;end,
		set = function(i)OZ_Config.minimapAngle = i;end,
		text = "Minimap Ang. (%d):",
	},
	{
		widget = "OzRaidOptionsPresetsMiniDist",
		get = function()return OZ_Config.minimapDist;end,
		set = function(i)OZ_Config.minimapDist = i;end,
		text = "Minimap Dist. (%d):",
	},
	{
		widget = "OzRaidOptionsInputsSlider",
		get = function()return OZ_Config[OZ_OptionsCurrentWindow].filter.injuredVal;end,
		set = function(i)OZ_Config[OZ_OptionsCurrentWindow].filter.injuredVal = i;end,
		text = "Healthy/Injured Cutoff (%d%%):",
		textScale = 100,
	},
	{
		widget = "OzRaidOptionsDisplayFadeAlpha",
		get = function()return OZ_Config[OZ_OptionsCurrentWindow].fadeAlpha;end,
		set = function(i)OZ_Config[OZ_OptionsCurrentWindow].fadeAlpha = i;end,
		text = "Distance Fade Alpha (%d%%):",
		textScale = 100,
	},
	{
		widget = "OzRaidOptionsGeneralButtonSize",
		get = function()return OZ_Config[OZ_OptionsCurrentWindow].buttonSize;end,
		set = function(i)OZ_Config[OZ_OptionsCurrentWindow].buttonSize = i;end,
		text = "Icon Size (%d px):",
	},
	{
		widget = "OzRaidOptionsGeneralTitleSize",
		get = function()return OZ_Config[OZ_OptionsCurrentWindow].titleHeight;end,
		set = function(i)OZ_Config[OZ_OptionsCurrentWindow].titleHeight = i;end,
		text = "Title Height (%d px):",
	},
	{
		widget = "OzRaidOptionsGeneralBarWidth",
		get = function()return OZ_Config[OZ_OptionsCurrentWindow].width;end,
		set = function(i)OZ_Config[OZ_OptionsCurrentWindow].width = i;end,
		text = "Bar Width (%d px):",
	},
	{
		widget = "OzRaidOptionsGeneralBarHeight",
		get = function()return OZ_Config[OZ_OptionsCurrentWindow].barHeight;end,
		set = function(i)OZ_Config[OZ_OptionsCurrentWindow].barHeight = i;end,
		text = "Bar Height (%d px):",
	},
	{
		widget = "OzRaidOptionsGeneralTextSize",
		get = function()return OZ_Config[OZ_OptionsCurrentWindow].textSize;end,
		set = function(i)OZ_Config[OZ_OptionsCurrentWindow].textSize = i;end,
		text = "Heading Size (%d px):",
	},
	{
		widget = "OzRaidOptionsGeneralMinBars",
		get = function()return OZ_Config[OZ_OptionsCurrentWindow].minBars;end,
		set = function(i)OZ_Config[OZ_OptionsCurrentWindow].minBars = i;end,
		text = "Min. Bars (%d):",
	},
	{
		widget = "OzRaidOptionsGeneralMaxBars",
		get = function()return OZ_Config[OZ_OptionsCurrentWindow].maxBars;end,
		set = function(i)OZ_Config[OZ_OptionsCurrentWindow].maxBars = i;end,
		text = "Max. Bars (%d):",
	},
	{
		widget = "OzRaidOptionsGeneralRefresh",
		get = function()return OZ_Config[OZ_OptionsCurrentWindow].refresh;end,
		set = function(i)OZ_Config[OZ_OptionsCurrentWindow].refresh = i;end,
		text = "Refresh Rate (%1.1fs):",
	},
	{
		widget = "OzRaidOptionsGeneralNameSize",
		get = function()return OZ_Config[OZ_OptionsCurrentWindow].nameSize;end,
		set = function(i)OZ_Config[OZ_OptionsCurrentWindow].nameSize = i;end,
		text = "Name Size (%d):",
	},
	{
		widget = "OzRaidOptionsGeneralNumSize",
		get = function()return OZ_Config[OZ_OptionsCurrentWindow].numSize;end,
		set = function(i)OZ_Config[OZ_OptionsCurrentWindow].numSize = i;end,
		text = "Number Size (%d):",
	},
	{
		widget = "OzRaidOptionsGeneralSpacing",
		get = function()return OZ_Config[OZ_OptionsCurrentWindow].barGap;end,
		set = function(i)OZ_Config[OZ_OptionsCurrentWindow].barGap = i;end,
		text = "Bar Spacing (%d):",
	},
};

OZ_HEADINGS = {
	{widget = "OzRaidOptionsPresetsTitleHeadingText", text="Name this window:",},
	{widget = "OzRaidOptionsPresetsPresetText", text="Choose a preset to apply:",},
	{widget = "OzRaidOptionsPresetsPartyHeadingText", text="What do you want to do with Blizzards party frames?",},
	{widget = "OzRaidOptionsPresetsInPartyHeadingText", text="When in a Party:",},
	{widget = "OzRaidOptionsPresetsInRaidHeadingText", text="When in a Raid:",},
	
	{widget = "OzRaidOptionsInputsHeadingText", text="Select Input:",},

	{widget = "OzRaidOptionsInputsMyHeadingText", text="My Group:",},
	
	{widget = "OzRaidOptionsSortsHeading1Text", text="Select Sorts:",},
	{widget = "OzRaidOptionsDisplayHeading3Text", text="Choose Bar Colour scheme & Texture...",},
	{widget = "OzRaidOptionsDisplayHeading4Text", text="Name Format:",},

	{widget = "OzRaidOptionsDisplayCheck1HeadingText", text="Name position:",},
	{widget = "OzRaidOptionsDisplayCheck4HeadingText", text="Buff position:",},
	{widget = "OzRaidOptionsDisplayCheck11HeadingText", text="Number position:",},
	{widget = "OzRaidOptionsDisplayCheck16HeadingText", text="Number Type:",},
}

local function UglyScrollLeft()
  this:HighlightText(0,1);
  this:Insert(" "..strsub(this:GetText(),1,1));
  this:HighlightText(0,1);
  this:Insert("");
  this:SetScript("OnUpdate", nil);
end
 

local OZ_BuffAdvFrame
local OZBA_State
local OZBA_WATCHED_SIZE = 12
local OZBA_ROW_HEIGHT = 16
local OZBA_Flags = { "fNoMine","fOnlyMine","fDontHide","fNoShow" }
local OZBA_TYPES = { "Friend BUFF", "Foe DEBUFF", "Friend DEBUFF", "Foe BUFF"}
 
 
 function OZ_OptionsInit()
	OzRaidOptionsTitleString:SetText( string.format("OzRaid v%1.2f",OZ_CURRENT_VERSION) );

	PanelTemplates_SetNumTabs(OzRaidOptions, table.getn(OZ_OptionsPanes) );
	OzRaidOptions.selectedTab=1;
	PanelTemplates_UpdateTabs(OzRaidOptions);

	-- Setup Presets
	for k,v in ipairs(OZ_HEADINGS) do
		gg( v.widget):SetText( v.text )
	end

	local t
	for k,v in ipairs(OZ_OptionsCheckboxes) do
		gg( v.widget.."ButtonText" ):SetJustifyH("LEFT")
		gg( v.widget.."ButtonText" ):SetText( v.text )
		if not gg(v.widget.."Button"):GetScript("OnClick") then
			gg(v.widget.."Button"):SetScript("OnClick",OZ_OptionsSetConfigFromOptions);
		end
	end

	local widget, n
	for _,v in ipairs(OZ_SLIDERS) do
		local widget = gg(v.widget)
		if(widget)then
			gg(v.widget.."Low"):SetText(nil)
			gg(v.widget.."High"):SetText(nil)
			gg(v.widget):SetScript("OnValueChanged",OZ_OptionsSetConfigFromOptions);
		end
	end	
end

local OZ_CurrentWindowText = ""


function OZ_ReadSliders()
	local widget, n
	for _,v in ipairs(OZ_SLIDERS) do
		local widget = gg(v.widget)
		if(widget)then
			n = widget:GetValue()
			v.set(n)
			if(v.textScale)then
				n = n * v.textScale
			end
			gg(v.widget.."Text"):SetText( string.format( v.text, n ) )
		end
	end
end
function OZ_SetSliders()
	local widget, n
	for _,v in ipairs(OZ_SLIDERS) do
		local widget = gg(v.widget)
		if(widget)then
			widget:SetValue(v.get())
		end
	end
end


local OzOptionsInitialised = nil

function OZ_OptionsSetConfigFromOptions()

if not OzOptionsInitialised then return end

	local a,b,i
	local config = OZ_Config[OZ_OptionsCurrentWindow]
	local window = OZ_GetWindowArray(OZ_OptionsCurrentWindow)
	if(not config)then
		DEFAULT_CHAT_FRAME:AddMessage("|c0033CCFF".."Error - no config data for window "..OZ_OptionsCurrentWindow)	
		return
	end
	config.text = OzRaidOptionsPresetsTitleName:GetText();
	if(OZ_CurrentWindowText ~= config.text) then
		OZ_OptionsWindow:Hide()
		OZ_OptionsWindow:Show()
		OZ_CurrentWindowText = config.text
	end

	OZ_ReadSliders()

	-- Inputs
	a = UIDropDownMenu_GetSelectedValue(OZ_InputsCombo1)
	config.input = a

	-- Filters
	for key,value in ipairs(OZ_OptionsCheckboxes) do
		if(value.set) then
			value.set(gg(value.widget.."Button"):GetChecked())
		end
	end

	-- Sorts
	config.heading[1] = 0
	config.heading[2] = 0
	config.heading[3] = 0

	b = 1
	a = UIDropDownMenu_GetSelectedValue(OZ_SortCombo1)
	config.sort1 = a
	if( OzRaidOptionsSortsCheck1Button:GetChecked() )then
		config.heading[b] = a
		b = b + 1
	end
	a = UIDropDownMenu_GetSelectedValue(OZ_SortCombo2)
	config.sort2 = a
	if( OzRaidOptionsSortsCheck2Button:GetChecked() )then
		config.heading[b] = a
		b = b + 1
	end

	-- read Party frame settings
	if( OzRaidOptionsPresetsRadio11Button:GetChecked() ) then
		OZ_Config.pFramesParty = 1
	elseif( OzRaidOptionsPresetsRadio12Button:GetChecked() ) then
		OZ_Config.pFramesParty = 2
	elseif( OzRaidOptionsPresetsRadio13Button:GetChecked() ) then
		OZ_Config.pFramesParty = nil
	end
	if( OzRaidOptionsPresetsRadio21Button:GetChecked() ) then
		OZ_Config.pFramesRaid = 1
	elseif( OzRaidOptionsPresetsRadio22Button:GetChecked() ) then
		OZ_Config.pFramesRaid = 2
	elseif( OzRaidOptionsPresetsRadio23Button:GetChecked() ) then
		OZ_Config.pFramesRaid = nil
	end

	
	-- Setup headings functions
	if( OzRaidOptionsDisplayCheck1Button:GetChecked() )then
		config.namePos = 2
	elseif( OzRaidOptionsDisplayCheck2Button:GetChecked() )then
		config.namePos = 1
	elseif( OzRaidOptionsDisplayCheck3Button:GetChecked() )then
		config.namePos = 3
	else
		config.namePos = 4
	end

	-- Setup buff functions
	if( OzRaidOptionsDisplayCheck4Button:GetChecked() )then
		config.buffPos = 2
	elseif( OzRaidOptionsDisplayCheck5Button:GetChecked() )then
		config.buffPos = 1
	else
		config.buffPos = 3
	end

	-- Setup number functions
	if( OzRaidOptionsDisplayCheck11Button:GetChecked() )then
		config.valuePos = nil
	elseif( OzRaidOptionsDisplayCheck12Button:GetChecked() )then
		config.valuePos = 1
	elseif( OzRaidOptionsDisplayCheck13Button:GetChecked() )then
		config.valuePos = 2
	elseif( OzRaidOptionsDisplayCheck14Button:GetChecked() )then
		config.valuePos = 3
	else
		config.valuePos = 4
	end
	if( OzRaidOptionsDisplayCheck16Button:GetChecked() )then
		config.valueType = 1
	elseif( OzRaidOptionsDisplayCheck17Button:GetChecked() )then
		config.valueType = 2
	else
		config.valueType = 3
	end

	config.Anchor,_,config.Relative,config.ax,config.ay = OZ_GetWindowTop(window.frame,config.growup)

	OZ_SetFromConfig(OZ_OptionsCurrentWindow)
	-- Force an update
	OZ_EventRoster()
	OZ_Windows[OZ_OptionsCurrentWindow].frame.tNext = 0
	OzRaid_Update(OZ_OptionsCurrentWindow)
end


function OZ_OptionsSetOptionsFromConfig(n)
	local a,b
	local config = OZ_Config[n]
	OZ_OptionsCurrentWindow = n
	if(not config)then
		DEFAULT_CHAT_FRAME:AddMessage("|c0033CCFF".."Error - no config data for window "..OZ_OptionsCurrentWindow)	
		return
	end
	OzOptionsInitialised = nil

	OzRaidOptionsPresetsTitleName:SetText(config.text);
	OzRaidOptionsPresetsTitleName:SetScript("OnUpdate", UglyScrollLeft);

	-- Inputs
	UIDropDownMenu_SetSelectedValue(OZ_InputsCombo1, config.input)

	-- Filters
	for key,value in ipairs(OZ_OptionsCheckboxes) do
		if(value.get)then
			gg(value.widget.."Button"):SetChecked(value.get())
		end
	end
	
	-- Sorts
	UIDropDownMenu_SetSelectedValue(OZ_SortCombo1, config.sort1)
	b = 1
	if( config.heading[b] == config.sort1)then
		b = b + 1
		OzRaidOptionsSortsCheck1Button:SetChecked(1)
	else
		OzRaidOptionsSortsCheck1Button:SetChecked(nil)
	end

	UIDropDownMenu_SetSelectedValue(OZ_SortCombo2, config.sort2)
	if( config.heading[b] == config.sort2)then
		b = b + 1
		OzRaidOptionsSortsCheck2Button:SetChecked(1)
	else
		OzRaidOptionsSortsCheck2Button:SetChecked(nil)
	end
	
	local found
	for key,value in ipairs(OZ_BarTextures) do
		if(value[2] == config.barTexture)then
			UIDropDownMenu_SetSelectedValue(OZ_TextureCombo,key)
			found = 1
			break
		end
	end
	if(not found) then
		UIDropDownMenu_SetSelectedValue(OZ_TextureCombo,1)
	end

	-- read Party frame settings
	OzRaidOptionsPresetsRadio11Button:SetChecked(nil)
	OzRaidOptionsPresetsRadio12Button:SetChecked(nil)
	OzRaidOptionsPresetsRadio13Button:SetChecked(nil)
	if OZ_Config.pFramesParty == 1 then
		OzRaidOptionsPresetsRadio11Button:SetChecked(1)
	elseif OZ_Config.pFramesParty == 2 then
		OzRaidOptionsPresetsRadio12Button:SetChecked(1)
	else
		OzRaidOptionsPresetsRadio13Button:SetChecked(1)
	end

	OzRaidOptionsPresetsRadio21Button:SetChecked(nil)
	OzRaidOptionsPresetsRadio22Button:SetChecked(nil)
	OzRaidOptionsPresetsRadio23Button:SetChecked(nil)
	if OZ_Config.pFramesRaid == 1 then
		OzRaidOptionsPresetsRadio21Button:SetChecked(1)
	elseif OZ_Config.pFramesRaid == 2 then
		OzRaidOptionsPresetsRadio22Button:SetChecked(1)
	else
		OzRaidOptionsPresetsRadio23Button:SetChecked(1)
	end

	-- Setup headings functions
	OzRaidOptionsDisplayCheck1Button:SetChecked(nil)
	OzRaidOptionsDisplayCheck2Button:SetChecked(nil)
	OzRaidOptionsDisplayCheck3Button:SetChecked(nil)
	OzRaidOptionsDisplayCheck22Button:SetChecked(nil)
	if(config.namePos == 2)then
		OzRaidOptionsDisplayCheck1Button:SetChecked(1)
	elseif(config.namePos == 1)then
		OzRaidOptionsDisplayCheck2Button:SetChecked(1)
	elseif(config.namePos == 3)then
		OzRaidOptionsDisplayCheck3Button:SetChecked(1)
	else
		OzRaidOptionsDisplayCheck22Button:SetChecked(1)
	end

	-- Setup buff functions
	OzRaidOptionsDisplayCheck4Button:SetChecked(nil)
	OzRaidOptionsDisplayCheck5Button:SetChecked(nil)
	OzRaidOptionsDisplayCheck6Button:SetChecked(nil)
	if(config.buffPos == 2)then
		OzRaidOptionsDisplayCheck4Button:SetChecked(1)
	elseif(config.buffPos == 1)then
		OzRaidOptionsDisplayCheck5Button:SetChecked(1)
	else
		OzRaidOptionsDisplayCheck6Button:SetChecked(1)
	end
	
	if(config.valuePos)then
		Oz_RaidDisplayCheckClick( 11 + config.valuePos )
	else
		Oz_RaidDisplayCheckClick( 11 )
	end
	Oz_RaidDisplayCheckClick( 15 + config.valueType )

	-- General options
	OZ_SetSliders()

	OZ_SetMinimapPos()
	
	OzOptionsInitialised = 1
end

function OZ_OptionsReset()
	OZ_SetupConfig(OZ_OptionsCurrentWindow)
	OZ_OptionsSetOptionsFromConfig(OZ_OptionsCurrentWindow)
end


		




---------------------------------------------------------
--
--  PRESETS PANEL - DROPDOWN SETUP
--
---------------------------------------------------------
OZ_Presets1_Val = "GENERAL"
OZ_Presets2_Val = "Raid View"

function OZ_PresetsCombo1_OnLoad()
	UIDropDownMenu_Initialize(this, OZ_PresetsCombo1_Initialize); 
	OZ_SetDropdownWidth(this, 120,30)
	UIDropDownMenu_SetSelectedValue(this, OZ_Presets1_Val);
end

function OZ_PresetsCombo1_Initialize()
	OZ_Presets1_Val = nil
	for key,val in pairs(OZ_PRESETS) do
		if( not OZ_Presets1_Val )then
			OZ_Presets1_Val = key
		end
		UIDropDownMenu_AddButton{value = key , text = key, func = OZ_PresetsCombo1_Pressed}
	end
end 

function OZ_PresetsCombo1_Pressed() 
	UIDropDownMenu_SetSelectedValue(OZ_PresetsCombo1,this.value)
	OZ_Presets1_Val = this.value
	OZ_PresetsCombo2:Hide()
	OZ_PresetsCombo2:Show()
end 


function OZ_PresetsCombo2_OnLoad() 
	UIDropDownMenu_Initialize(this, OZ_PresetsCombo2_Initialize2); 
	OZ_SetDropdownWidth(this, 120,30)
	UIDropDownMenu_SetSelectedValue(this, OZ_Presets2_Val);
end

function OZ_PresetsCombo2_Initialize2() 
	OZ_Presets2_Val = nil
	for key,val in pairs(OZ_PRESETS[OZ_Presets1_Val]) do
		if( not OZ_Presets2_Val )then
			OZ_Presets2_Val = key
		end
		UIDropDownMenu_AddButton{value = key , text = key , func = OZ_PresetsCombo2_Pressed}
	end
end 

function OZ_PresetsCombo2_Pressed() 
	UIDropDownMenu_SetSelectedValue(OZ_PresetsCombo2,this.value)
	OZ_Presets2_Val = this.value
--DEFAULT_CHAT_FRAME:AddMessage("|c0033CCFF".."OzRaid: Table2="..OZ_Presets2_Val);
end

function OZ_DuplicateTable( src )
	local ret,key,val
	if not src then return nil; end
	ret = {}

	for key,val in pairs(src) do
		if(type(val)=="table") then
			ret[key] = OZ_DuplicateTable(val)
		else
			ret[key] = val
		end
	end
	return ret
end

function OZ_UpdateTable( src, dest )
	local key,val
	for key,val in pairs(src) do
		if(type(val)=="table") then
			if not dest[key] then
				dest[key] = {}
			end
			OZ_UpdateTable(val, dest[key])
		else
			if val == OZ_NIL then
				dest[key] = nil
			else
				dest[key] = val
			end
		end
	end
end


function OZ_PresetApply(val1, val2)
	local val1 = val1 or OZ_Presets1_Val
	local val2 = val2 or OZ_Presets2_Val
	-- copy current anchoring
	local c = OZ_Config[OZ_OptionsCurrentWindow]
	local a,r,x,y = c.Anchor, c.Relative, c.ax, c.ay
	local key,val
	-- Duplicate from preset
--	OZ_Config[OZ_OptionsCurrentWindow] = OZ_DuplicateTable( OZ_PRESETS[OZ_Presets1_Val][OZ_Presets2_Val] )
	OZ_Config[OZ_OptionsCurrentWindow] = {}
	for key,val in ipairs(OZ_PRESETS[val1][val2].templates) do
		if val.func then
			print("Applying default buff config")
			val.func()
		else		
			OZ_UpdateTable( val, OZ_Config[OZ_OptionsCurrentWindow] )
		end
	end
	OZ_UpdateTable( OZ_PRESETS[val1][val2].custom, OZ_Config[OZ_OptionsCurrentWindow] )

	-- reset positions
	OZ_Config[OZ_OptionsCurrentWindow].Anchor = a;
	OZ_Config[OZ_OptionsCurrentWindow].Relative = r;
	OZ_Config[OZ_OptionsCurrentWindow].ax = x;
	OZ_Config[OZ_OptionsCurrentWindow].ay = y;

--DEFAULT_CHAT_FRAME:AddMessage("|c0033CCFF".."Setting preset to: "..OZ_Presets1_Val.."-"..OZ_Presets2_Val);
--DEFAULT_CHAT_FRAME:AddMessage("|c0033CCFF".."name = "..OZ_Config[OZ_OptionsCurrentWindow].text);

	OZ_OptionsSetOptionsFromConfig(OZ_OptionsCurrentWindow);
	OZ_OptionsSetConfigFromOptions();
end

---------------------------------------------------------
--
--  OPTIONS SCREEN - TABS SET UP
--
---------------------------------------------------------
function OZ_HideOptions()
	OzRaidOptions:Hide()
end

OZ_OptionsPanes =	{
						"OzRaidOptionsPresets",
						"OzRaidOptionsInputs",
						"OzRaidOptionsSorts",
						"OzRaidOptionsDisplay",
						"OzRaidOptionsBuffs",
						"OzRaidOptionsGeneral",
						--"OzRaidOptionsFilters",
					};


function OZ_OptionsTabOnClick(tab)
	local n = tab:GetID()
	OzRaidOptions.selectedTab = n;
	PanelTemplates_UpdateTabs(OzRaidOptions);

	-- Now hide/show panes...
	local i
	for i,value in ipairs(OZ_OptionsPanes) do
		if( i == n ) then
--DEFAULT_CHAT_FRAME:AddMessage("|c0033CCFF".."OzRaid: Showing "..value);
			getglobal(value):Show()
		else
--DEFAULT_CHAT_FRAME:AddMessage("|c0033CCFF".."OzRaid: Hiding "..value);
			getglobal(value):Hide()
		end
	end
end

---------------------------------------------------------
--
--  SORT PANEL - DROPDOWN SETUP
--
---------------------------------------------------------
function OZ_SortCombo1_OnLoad() 
	UIDropDownMenu_Initialize(this, OZ_SortCombo1_Initialize); 
	OZ_SetDropdownWidth(this, 120,40)
	if(OZ_Initialised) then
		UIDropDownMenu_SetSelectedValue(this, OZ_Config[OZ_OptionsCurrentWindow].sort1);
	else
		UIDropDownMenu_SetSelectedValue(this, 1);
	end

--DEFAULT_CHAT_FRAME:AddMessage("|c0033CCFF".."OzRaid: Sort1 Initialised");
end

function OZ_SortCombo1_Initialize()
	UIDropDownMenu_AddButton({value = 0 , text = "<None>" , func = OZ_SortCombo1_Pressed})
	local i
	for i = 1,8 do
		if(OZ_SortFunctions[i]) then
			UIDropDownMenu_AddButton{value = i , text = OZ_SortFunctions[i].text , func = OZ_SortCombo1_Pressed}
		end
	end
end 

function OZ_SortCombo1_Pressed() 
	UIDropDownMenu_SetSelectedValue(OZ_SortCombo1,this.value)
	OZ_Config[OZ_OptionsCurrentWindow].sort1 = this.value

	OZ_SortCombo2:Enable()
	OZ_SortCombo2:Hide()
	OZ_SortCombo2:Show()
	OZ_OptionsSetConfigFromOptions()
end 


function OZ_SortCombo2_OnLoad() 
	UIDropDownMenu_Initialize(this, OZ_SortCombo2_Initialize2); 
	OZ_SetDropdownWidth(this, 120,40)

	if(OZ_Config[OZ_OptionsCurrentWindow]) then
		UIDropDownMenu_SetSelectedValue(this, OZ_Config[OZ_OptionsCurrentWindow].sort2);
	else
		UIDropDownMenu_SetSelectedValue(this, 0);
	end
--DEFAULT_CHAT_FRAME:AddMessage("|c0033CCFF".."OzRaid: Sort2 Initialised");
end

function OZ_SortCombo2_Initialize2()
	UIDropDownMenu_AddButton{value = 0 , text = "<None>" , func = OZ_SortCombo2_Pressed}
	local i
	for i = 1,8 do
		if(OZ_SortFunctions[i]) then
			UIDropDownMenu_AddButton{value = i , text = OZ_SortFunctions[i].text , func = OZ_SortCombo2_Pressed}
		end
	end
end 

function OZ_SortCombo2_Pressed() 
	UIDropDownMenu_SetSelectedValue(OZ_SortCombo2,this.value)
	OZ_Config[OZ_OptionsCurrentWindow].sort2 = this.value
--DEFAULT_CHAT_FRAME:AddMessage("|c0033CCFF".."OzRaid: Table2="..OZ_Sort2_Val);
	OZ_OptionsSetConfigFromOptions()
end 


function OZ_TextureCombo_OnLoad()
	UIDropDownMenu_Initialize(this, OZ_TextureCombo_Initialise);
	OZ_SetDropdownWidth(this, 160,30)

	local found
	if(OZ_Config[OZ_OptionsCurrentWindow]) then
		for key,value in ipairs(OZ_BarTextures) do
			if(value[2] == OZ_Config[OZ_OptionsCurrentWindow].barTexture)then
				UIDropDownMenu_SetSelectedValue(this,key)
				found = 1
				break
			end
		end
	end

	if(not found) then
		UIDropDownMenu_SetSelectedValue(this, 1);
	end
end

function OZ_TextureCombo_Initialise()
	local key,value
	local w = OZ_OptionsCurrentWindow
	for key,value in ipairs(OZ_BarTextures) do
		UIDropDownMenu_AddButton{value = key , text = value[1], func = OZ_TextureCombo_Pressed}
	end
end
function OZ_TextureCombo_Pressed()
	UIDropDownMenu_SetSelectedValue(OZ_TextureCombo,this.value)
	OZ_Config[OZ_OptionsCurrentWindow].barTexture = OZ_BarTextures[this.value][2]
	OZ_OptionsSetConfigFromOptions()
end



function OZ_NameCombo_OnLoad() 
	UIDropDownMenu_Initialize(this, OZ_NameCombo_Initialize); 
	OZ_SetDropdownWidth(this, 120,30)
	if(OZ_Initialised) then
		UIDropDownMenu_SetSelectedValue(this, OZ_Config[OZ_OptionsCurrentWindow].nameStyle);
	else
		UIDropDownMenu_SetSelectedValue(this, 1);
	end
end

function OZ_NameCombo_Initialize()
	local i,t
	for i,t in ipairs(OZ_NAME_FORMATS) do
		UIDropDownMenu_AddButton{value = i , text = t.name , func = OZ_NameCombo_Pressed}
	end
end 

function OZ_NameCombo_Pressed() 
	UIDropDownMenu_SetSelectedValue(OZ_NameCombo,this.value)
	OZ_Config[OZ_OptionsCurrentWindow].nameStyle = this.value

	OZ_NameCombo:Enable()
	OZ_NameCombo:Hide()
	OZ_NameCombo:Show()
	OZ_OptionsSetConfigFromOptions()
end 

---------------------------------------------------------
--
--  INPUTS PANEL - DROPDOWN SETUP
--
---------------------------------------------------------
function OZ_InputsCombo1_OnLoad() 
	UIDropDownMenu_Initialize(this, OZ_InputsCombo1_Initialize); 
	OZ_SetDropdownWidth(this, 200,30)
	if(OZ_Initialised) then
		UIDropDownMenu_SetSelectedValue(this, OZ_Config[OZ_OptionsCurrentWindow].input);
	else
		UIDropDownMenu_SetSelectedValue(this, 1);
	end
end

function OZ_InputsCombo1_Initialize()
	for key,value in ipairs(OZ_InputFunctions) do
		UIDropDownMenu_AddButton{value = key , text = value.text , func = OZ_InputsCombo1_Pressed}
	end
end 

function OZ_InputsCombo1_Pressed() 
	UIDropDownMenu_SetSelectedValue(OZ_InputsCombo1,this.value)
	OZ_Config[OZ_OptionsCurrentWindow].input = this.value
	OZ_OptionsSetConfigFromOptions()
end 

---------------------------------------------------------
--
--  DISPLAY PANEL - DROPDOWN SETUP
--
---------------------------------------------------------
function OZ_DisplayCombo1_OnLoad() 
	UIDropDownMenu_Initialize(this, OZ_DisplayCombo1_Initialize); 
	OZ_SetDropdownWidth(this, 160,30)
	if(OZ_Initialised) then
		UIDropDownMenu_SetSelectedValue(this, OZ_Config[OZ_OptionsCurrentWindow].colour);
	else
		UIDropDownMenu_SetSelectedValue(this, 1);
	end
end

function OZ_DisplayCombo1_Initialize()
	for key,value in ipairs(OZ_ColourFunctions) do
		UIDropDownMenu_AddButton{value = key , text = value.text , func = OZ_DisplayCombo1_Pressed}
	end
end 

function OZ_DisplayCombo1_Pressed() 
	UIDropDownMenu_SetSelectedValue(OZ_DisplayCombo1,this.value)
	OZ_Config[OZ_OptionsCurrentWindow].colour = this.value
	OZ_OptionsSetConfigFromOptions()
end 

function Oz_RaidDisplayCheckClick(id)
	if(id < 4)then
		OzRaidOptionsDisplayCheck1Button:SetChecked(nil)
		OzRaidOptionsDisplayCheck2Button:SetChecked(nil)
		OzRaidOptionsDisplayCheck3Button:SetChecked(nil)
		OzRaidOptionsDisplayCheck22Button:SetChecked(nil)
		if(id == 1)then
			OzRaidOptionsDisplayCheck1Button:SetChecked(1)
		elseif(id == 2)then
			OzRaidOptionsDisplayCheck2Button:SetChecked(1)
		elseif(id == 3)then
			OzRaidOptionsDisplayCheck3Button:SetChecked(1)
		else
			OzRaidOptionsDisplayCheck22Button:SetChecked(1)
		end
	elseif(id < 7)then
		OzRaidOptionsDisplayCheck4Button:SetChecked(nil)
		OzRaidOptionsDisplayCheck5Button:SetChecked(nil)
		OzRaidOptionsDisplayCheck6Button:SetChecked(nil)
		if(id == 4)then
			OzRaidOptionsDisplayCheck4Button:SetChecked(1)
		elseif(id == 5)then
			OzRaidOptionsDisplayCheck5Button:SetChecked(1)
		elseif(id == 6)then
			OzRaidOptionsDisplayCheck6Button:SetChecked(1)
		end
	elseif(id<16)then
		OzRaidOptionsDisplayCheck11Button:SetChecked(nil)
		OzRaidOptionsDisplayCheck12Button:SetChecked(nil)
		OzRaidOptionsDisplayCheck13Button:SetChecked(nil)
		OzRaidOptionsDisplayCheck14Button:SetChecked(nil)
		OzRaidOptionsDisplayCheck15Button:SetChecked(nil)
		if(id == 11)then
			OzRaidOptionsDisplayCheck11Button:SetChecked(1)
		elseif(id == 12)then
			OzRaidOptionsDisplayCheck12Button:SetChecked(1)
		elseif(id == 13)then
			OzRaidOptionsDisplayCheck13Button:SetChecked(1)
		elseif(id == 14)then
			OzRaidOptionsDisplayCheck14Button:SetChecked(1)
		elseif(id == 15)then
			OzRaidOptionsDisplayCheck15Button:SetChecked(1)
		end
	elseif(id<19)then
		OzRaidOptionsDisplayCheck16Button:SetChecked(nil)
		OzRaidOptionsDisplayCheck17Button:SetChecked(nil)
		OzRaidOptionsDisplayCheck18Button:SetChecked(nil)
		if(id == 16)then
			OzRaidOptionsDisplayCheck16Button:SetChecked(1)
		elseif(id == 17)then
			OzRaidOptionsDisplayCheck17Button:SetChecked(1)
		elseif(id == 18)then
			OzRaidOptionsDisplayCheck18Button:SetChecked(1)
		end
	elseif (id>=101) and (id<=103) then
		OzRaidOptionsPresetsRadio11Button:SetChecked(nil)
		OzRaidOptionsPresetsRadio12Button:SetChecked(nil)
		OzRaidOptionsPresetsRadio13Button:SetChecked(nil)
		if id == 101 then
			OzRaidOptionsPresetsRadio11Button:SetChecked(1)
		elseif id == 102 then
			OzRaidOptionsPresetsRadio12Button:SetChecked(1)
		else
			OzRaidOptionsPresetsRadio13Button:SetChecked(1)
		end
	elseif (id>=201) and (id<=203) then
		OzRaidOptionsPresetsRadio21Button:SetChecked(nil)
		OzRaidOptionsPresetsRadio22Button:SetChecked(nil)
		OzRaidOptionsPresetsRadio23Button:SetChecked(nil)
		if id == 201 then
			OzRaidOptionsPresetsRadio21Button:SetChecked(1)
		elseif id == 202 then
			OzRaidOptionsPresetsRadio22Button:SetChecked(1)
		else
			OzRaidOptionsPresetsRadio23Button:SetChecked(1)
		end
	end
	OZ_OptionsSetConfigFromOptions();
end

function OZ_OptionsWindow_OnLoad()
	UIDropDownMenu_Initialize(this, OZ_OptionsWindow_Initialize); 
	OZ_SetDropdownWidth(this,120,30)
	UIDropDownMenu_SetSelectedValue(this, OZ_OptionsCurrentWindow);
end

function OZ_OptionsWindow_Initialize()
	if(OZ_Initialised == 1)then
		local i
		for i=1,OZ_NWINDOWS do
			UIDropDownMenu_AddButton{value = i , text = OZ_Config[i].text , func = OZ_OptionsWindow_Pressed}
		end
	end
end 

function OZ_OptionsWindow_Pressed() 
	UIDropDownMenu_SetSelectedValue(OZ_OptionsWindow,this.value)

	OZ_OptionsSetOptionsFromConfig(this.value)
	OzRaidOptions:Hide()
	OzRaidOptions:Show()
	
	OZBA_RefreshFrame(true)
end 

function OZ_OptionsCentre()
	local window = OZ_Windows[OZ_OptionsCurrentWindow]
	window.frame:ClearAllPoints()
	window.frame:SetPoint("CENTER",nil)
	OZ_OptionsSetConfigFromOptions()
end

function OZ_AddWindowPressed()
	OZ_AddWindow()
	OZ_OptionsCurrentWindow = OZ_NWINDOWS
	UIDropDownMenu_SetSelectedValue(OZ_OptionsWindow,OZ_OptionsCurrentWindow)
	OZ_OptionsSetOptionsFromConfig(OZ_OptionsCurrentWindow)
end
function OZ_CopyWindowPressed()
	local source = OZ_OptionsCurrentWindow
	OZ_AddWindow()
	OZ_OptionsCurrentWindow = OZ_NWINDOWS
	
	OZ_Config[OZ_OptionsCurrentWindow] = {}
	local config = OZ_Config[OZ_OptionsCurrentWindow]
	OZ_UpdateTable( OZ_Config[source], config )
	
	config.text = "Copy of "..OZ_Config[source].text
print("OzOptions: Created duplicate: "..config.text)
	OZ_OptionsSetOptionsFromConfig(OZ_OptionsCurrentWindow)
	

--	UIDropDownMenu_SetSelectedValue(OZ_OptionsWindow,OZ_OptionsCurrentWindow)
	OZ_OptionsCentre()
end
function OZ_DeleteWindowPressed()
	if OZ_NWINDOWS>1 then
		OZ_RemoveWindow(OZ_OptionsCurrentWindow)
		OZ_OptionsCurrentWindow = 1
		UIDropDownMenu_SetSelectedValue(OZ_OptionsWindow,1)
		OZ_OptionsSetOptionsFromConfig(OZ_OptionsCurrentWindow)
	else
		OZ_Config[1].active = nil;
	end
end

--------------------------------------------------------------------------------
--- Functions for the scrolly window
--------------------------------------------------------------------------------
-- List format: {'text', depth, 'maxKey', 'texture name', 'priority', 'debuff', 'index'}
--					1		2		3			 4				5		  6			7
-- Headings have 'nil' for a texturename
OZ_BuffSelectList = {}

OZ_BuffSelectMaximised = {}


function OZ_BuildSelectList()
if true then return end
	local i = 1
	local key, key2, key3, key4, value, value2, value3, value4
	local config = OZ_Config[OZ_OptionsCurrentWindow]
	OZ_BuffSelectList = {}
	local maxKey
--DEFAULT_CHAT_FRAME:AddMessage( "Building list" )
	for key,value in pairs(OZ_BUFF_TABLE) do
		if( OZ_BuffSelectMaximised[key] )then
--DEFAULT_CHAT_FRAME:AddMessage( "- "..key )
			-- This category is expanded
			OZ_BuffSelectList[i] = {key, 0, key}
			i = i+1
			for key2,value2 in pairs(value) do
				if( OZ_BuffSelectMaximised[key..key2] )then
--DEFAULT_CHAT_FRAME:AddMessage( "  - "..key2 )
					OZ_BuffSelectList[i] = {key2, 1, key..key2}
					i = i+1
					for key3,value3 in pairs(value2) do
--DEFAULT_CHAT_FRAME:AddMessage( "      "..key3 )
						local priority = -1
						local index = nil
						
						local array
						local tex = value3[3]
						if not string.find(tex,"Interface") then
							tex = "Interface\\Icons\\"..value3[3]
						end

						ARRAY = CONFIG
						if value3[4] == 2 then
							array = config.buffsMob
						else
							array = config.buffsPlayer
						end
						local a = array[tex]
						if a then
							priority = a[1]
							index = 1
						end

						OZ_BuffSelectList[i] = {value3[2], 2, key..key2..i, tex, priority, value3[4], index}
						i = i+1
					end
				else
--DEFAULT_CHAT_FRAME:AddMessage( "  + "..key2 )
					OZ_BuffSelectList[i] = {key2, 1, key..key2}
					i = i+1
				end
			end
		else
--DEFAULT_CHAT_FRAME:AddMessage( "+ "..key )
			OZ_BuffSelectList[i] = {key, 0, key}
			i = i+1
		end
	end
end


OZ_BUFF_PRIORITYTEXT = {
		[-1]	= { col={0.4, 0.4, 0.4}, text="none" },
		[0]		= { col={1.0, 0.2, 0.2}, text="lowest" },
		[1]		= { col={0.8, 0.4, 0.1}, text="low" },
		[2]		= { col={0.6, 0.6, 0.0}, text="medium" },
		[3]		= { col={0.4, 0.8, 0.1}, text="high" },
		[4]		= { col={0.2, 1.0, 0.2}, text="highest" },
	};

function OZ_BuffSetPriority(i, p)
	
end

function OZ_BuffPanelClick()
	local index
	local name = this:GetName()
	-- Name will be 'OzRaidBuffsScrollEntry<n>Maximise'
	index = string.byte(name,23) - 48
--DEFAULT_CHAT_FRAME:AddMessage( "index = "..index )
	lineplusoffset = index + FauxScrollFrame_GetOffset(OzRaidBuffsScrollBar);
	local entry = OZ_BuffSelectList[lineplusoffset]

	local config = OZ_Config[OZ_OptionsCurrentWindow]
	local texture = entry[4]
	if texture then
		-- Clicked on a leaf node - inc priority
		local dest
		if(entry[6] == 2)then
			dest = config.buffsMob
		else
			dest = config.buffsPlayer
		end
		
		if dest[texture] then
			-- Known buff
			local a = dest[texture][1] + 1
			if a>4 then
				dest[texture] = nil
			else
				dest[texture][1] = a
			end
		else
			dest[texture] = {0,entry[1]}
		end
	elseif(OZ_BuffSelectMaximised[ entry[3] ])then
		OZ_BuffSelectMaximised[ entry[3] ] = nil
	else
		OZ_BuffSelectMaximised[ entry[3] ] = 1
	end

	OZ_BuildSelectList()
	OZ_BuffPanelUpdate()
end


function OZ_BuffPanelUpdate()
	local line;
	local lineplusoffset; -- an index into our data calculated from the scroll offset
	local barCount = 8

	local inputs = table.getn(OZ_BuffSelectList)
	if(inputs < barCount) then
		barCount = inputs
	end

	FauxScrollFrame_Update(OzRaidBuffsScrollBar,inputs,barCount,16);
	local offset = FauxScrollFrame_GetOffset(OzRaidBuffsScrollBar);
	for line=1,8 do
		lineplusoffset = line + offset;
		if (lineplusoffset <= inputs) then
			-- Setup this line
			local text
			local entry = gg("OzRaidBuffsScrollEntry"..line)
			local entryText = gg("OzRaidBuffsScrollEntry"..line.."Text")
			local entryMax = gg("OzRaidBuffsScrollEntry"..line.."Maximise")
			local entryPri = gg("OzRaidBuffsScrollEntry"..line.."Priority")

			-- Check for 'expanded' status
			local line = OZ_BuffSelectList[lineplusoffset]
			local indent = line[2]*16
			if OZ_BuffSelectMaximised[ line[3] ] then

				-- We are expanded!
				entryMax:SetNormalTexture("Interface\\Buttons\\UI-MinusButton-UP")
				entryMax:SetPushedTexture("Interface\\Buttons\\UI-MinusButton-DOWN")
				entryMax:SetPoint("LEFT",entry,"LEFT", indent, 0)
				entryMax:Show()

				entryText:SetPoint("LEFT",entry,"LEFT", 16+indent, 0)
				entryText:SetTextColor(1.0, 0.82, 0)

				entryPri:Hide()
			elseif(line[2] < 2)then
				entryMax:SetNormalTexture("Interface\\Buttons\\UI-PlusButton-UP")
				entryMax:SetPushedTexture("Interface\\Buttons\\UI-PlusButton-DOWN")
				entryMax:SetPoint("LEFT",entry,"LEFT", indent, 0)
				entryMax:Show()

				entryText:SetPoint("LEFT",entry,"LEFT", 16+indent, 0)
				entryText:SetTextColor(1.0, 0.82, 0)

				entryPri:Hide()
			else
				-- We are a 'leaf' entry
				entryMax:Hide()

				entryText:SetPoint("LEFT",entry,"LEFT", indent, 0)
				entryText:SetTextColor(1, 1, 1)

				entryPri:Show()
				entryPri:SetText( OZ_BUFF_PRIORITYTEXT[ line[5] ].text )
				entryPri:SetTextColor(	OZ_BUFF_PRIORITYTEXT[ line[5] ].col[1],
										OZ_BUFF_PRIORITYTEXT[ line[5] ].col[2],
										OZ_BUFF_PRIORITYTEXT[ line[5] ].col[3] )
			end
			entryText:SetText( line[1] )
		else
			gg("OzRaidBuffsScrollEntry"..line):Hide();
		end
	end
	OZ_OptionsSetConfigFromOptions();
end

function OZ_BuffsReset()
	OZ_Config[OZ_OptionsCurrentWindow].buff_combat = {{},{},{},{}}
	OZ_Config[OZ_OptionsCurrentWindow].buff_ooc = {{},{},{},{}}

	OZBA_RefreshFrame()
--	OZBA_BuildWatchedList()
--	OZBA_UpdateWatched(OZ_BuffAdvFrame.watched)
--	OZBA_SetWatched()

end

function OZ_BuffsDefault()
	OZ_BuffsReset()
	-- Init buff arays with the class defaults
	local class,fileName = UnitClass("player")
	local i = 1
	for key,value in ipairs(OZ_BUFF_DEFAULT[fileName].Player) do
		if type(value)=="table" then
			local bName = value[3]
			if not string.find(bName,"Interface") then
				bName = "Interface\\Icons\\"..bName
			end
			local dk = value.key or bName
			if not value.not_combat then
				OZ_Config[OZ_OptionsCurrentWindow].buff_combat[value[4]][dk] =
						{ value[1], value[2], bName, value[4],
						col = OZ_DuplicateTable( value.col ),
						fNoShow=value.fNoShow, fDontHide=value.fDontHide }
			end
			if not value.not_ooc then
				OZ_Config[OZ_OptionsCurrentWindow].buff_ooc[value[4]][dk] = 
						{ value[1], value[2], bName, value[4],
						col = OZ_DuplicateTable( value.col ),
						fNoShow=value.fNoShow, fDontHide=value.fDontHide }
			end
--print("Added "..value[2])
		end
	end

	for key,value in ipairs(OZ_BUFF_DEFAULT[fileName].Mob) do
		if type(value)=="table" then
			local bName = value[3]
			if not string.find(bName,"Interface") then
				bName = "Interface\\Icons\\"..bName
			end
			local dk = value.key or bName
			if not value.not_combat then
				OZ_Config[OZ_OptionsCurrentWindow].buff_combat[value[4]][dk] = 
						{ value[1], value[2], bName, value[4],
						col = OZ_DuplicateTable( value.col ),
						fNoShow=value.fNoShow, fDontHide=value.fDontHide }
			end
			if not value.not_ooc then
				OZ_Config[OZ_OptionsCurrentWindow].buff_ooc[value[4]][dk] = 
						{ value[1], value[2], bName, value[4],
						col = OZ_DuplicateTable( value.col ),
						fNoShow=value.fNoShow, fDontHide=value.fDontHide }
			end
--print("Added "..value[2])
		end
	end
--	OZBA_BuildWatchedList()
--	OZBA_UpdateWatched(OZ_BuffAdvFrame.watched)
--	OZBA_SetWatched()
	OZBA_RefreshFrame()
end



-- Buff-o-matic Configuralizer

function OZBA_FilterClick(self)
	local f = OZ_BuffAdvFrame.filters
	if f[self.index] then
		f[self.index] = nil
		self:UnlockHighlight()
	else
		f[self.index] = 1
		self:LockHighlight()
	end
	OZBA_RefreshFrame()
--	OZBA_BuildWatchedList()
--	OZBA_UpdateWatched(OZ_BuffAdvFrame.watched)
--	OZBA_SetWatched()
end
--[[

OZ_BuffAdvFrame = 
	buff_combat {,} -   Button frame & overall data
	buff_ooc {,}    -   OZBA_State = the current button/buff set to edit
			getSource() -   Function to retrieve the current config for this state
			list {,}    -   The row data built up (temporary, so cant store data here)
							Contains:
								indent = <spaces to indent = submenu depth
								either:
									[category = "string",
									  name = "BIGLONGNAME" ] -- if we are a submenu heading
								or:
									[src = {},          -- if we are an entry, src = buffList entry
									  dest = {}]         -- if we are watched, this contains the watchlist entry

			max {,}     -   list of expanded category names (append subcategory names)
							there is an entry here if the category is expanded
			scrollIndex -   offset for the scroll bar (top visible row is 'scrollIndex')
	watched {,}         -   frame for the scrollbar
			rows {,}    -   frames for each row of the scrollbar area
				data {,} = reference to the LIST entry (buff_combat/ooc -> list[n])
			
	filters {,} - show/hide categories in watched list
			These match [filter buttons].index

]]--
function OZ_BuffsAdvanced() -- Create the new buff settings frame
	if not OZ_BuffAdvFrame then
	----[[
		local f = CreateFrame("Frame",nil,gg("OzRaidOptionsBuffs"),"OzRaidBasicTemplate")
		f:SetWidth(400) -- Set these to whatever height/width is needed 
		f:SetHeight(390) -- for your Texture
		f:SetPoint("TOPLEFT",OzRaidOptionsBuffs,"TOPLEFT",10,-70)
--		f:EnableMouse(true)
--		f:SetMovable(true)
--		f:RegisterForDrag("LeftButton")
--		f:SetScript("OnDragStart",function(self) self:StartMoving() end)
--		f:SetScript("OnDragStop",function(self) self:StopMovingOrSizing() end)
	--]]
--		local f = gg("OzRaidOptionsBuffs")
		OZ_BuffAdvFrame = f
 
		f.filters = {1,1,1,1,1,1}
		
		local w,x,y,z;
		w = CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
		w:SetWidth(110)
		w:SetHeight(20)
		w:SetPoint("TOPRIGHT",f,"TOPRIGHT",-50,-10)
		w:SetText("Player HARM")
		w:SetScript("OnClick", OZBA_FilterClick )
		w:LockHighlight()
		w.index = 3

		x = CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
		x:SetWidth(110)
		x:SetHeight(20)
		x:SetPoint("RIGHT",w,"LEFT",0,0)
		x:SetText("Player HELP")
		x:SetScript("OnClick", OZBA_FilterClick )
		x:LockHighlight()
		x.index = 1

		y = CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
		y:SetWidth(110)
		y:SetHeight(20)
		y:SetPoint("TOP",w,"BOTTOM",0,0)
		y:SetText("Mob HARM")
		y:SetScript("OnClick", OZBA_FilterClick )
		y:LockHighlight()
		y.index = 4

		z = CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
		z:SetWidth(110)
		z:SetHeight(20)
		z:SetPoint("TOPRIGHT",w,"BOTTOMLEFT",0,0)
		z:SetText("Mob HELP")
		z:SetScript("OnClick", OZBA_FilterClick )
		z:LockHighlight()
		z.index = 2
		
		local u = CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
		u:SetWidth(110)
		u:SetHeight(20)
		u:SetPoint("RIGHT",x,"LEFT",0,0)
		u:SetText("Watched")
		u:SetScript("OnClick", OZBA_FilterClick )
		u:LockHighlight()
		u.index = 5
		local v = CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
		v:SetWidth(110)
		v:SetHeight(20)
		v:SetPoint("TOPRIGHT",x,"BOTTOMLEFT",0,0)
		v:SetText("Not Watched")
		v:SetScript("OnClick", OZBA_FilterClick )
		v:LockHighlight()
		v.index = 6

		--UIPanelButtonTemplate
		local b = CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
		b:SetWidth(120)
		b:SetHeight(20)
		b:SetPoint("TOPLEFT",f,"TOPLEFT",20,20)
		b:SetText("In Combat")
		b:SetScript("OnClick", OZBA_CheckState )
		b:LockHighlight()
		b.getSource = function() return OZ_Config[OZ_OptionsCurrentWindow].buff_combat end
		b.scrollIndex = 1
		b.list = {}
		b.max = {}
		
		f.buff_combat = b
		OZBA_State = b
		
		local c = CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
		c:SetWidth(120)
		c:SetHeight(20)
		c:SetPoint("TOPLEFT",b,"TOPRIGHT",0,0)
		c:SetText("Out of Combat")
		c:SetScript("OnClick", OZBA_CheckState )
		c.getSource = function() return OZ_Config[OZ_OptionsCurrentWindow].buff_ooc end
		c.scrollIndex = 1
		c.list = {}
		c.max = {}

		
		f.buff_ooc = c
		local e = CreateFrame("ScrollFrame","OZBA_Watched",f,"FauxScrollFrameTemplate")
		e:SetWidth(360)
		e:SetHeight(OZBA_WATCHED_SIZE*OZBA_ROW_HEIGHT + 10)
		e:SetPoint("TOPLEFT",f,"TOPLEFT",10,-50)
		e:SetBackdrop({	bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
											edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
											tile = true, tileSize = 16, edgeSize = 16, 
											insets = { left = 4, right = 4, top = 4, bottom = 4 }});        
		e:SetBackdropBorderColor(0.4, 0.4, 0.4)
		e:SetBackdropColor(0.09, 0.09, 0.19)
		e:SetScript("OnVerticalScroll", function(self,offset) FauxScrollFrame_OnVerticalScroll(self, offset, 20, OZBA_UpdateWatched) end )
		--OZBA_watchedScroll = e
		
		e.rows = {}
		f.watched = e      

		OZBA_BuildWatchedList()
		OZBA_UpdateWatched(OZ_BuffAdvFrame.watched)
		OZBA_SetWatched()
		f:Show()
		
	   local g = CreateFrame("Frame","OZBA_Watched",f)
		g:SetWidth(380)
		g:SetHeight(120)
		g:SetPoint("TOP",e,"BOTTOM",10,-5)
		g:SetBackdrop({	bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
											edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
											tile = true, tileSize = 16, edgeSize = 16, 
											insets = { left = 4, right = 4, top = 4, bottom = 4 }});        
		g:SetBackdropBorderColor(0.4, 0.4, 0.4)
		g:SetBackdropColor(0.09, 0.09, 0.19)
		f.detail = g
		f.cursor = nil
		
		g.heading = f:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		g.heading:SetWidth(360)
		g.heading:SetHeight(20)
		g.heading:SetPoint("TOPLEFT",e,"BOTTOMLEFT",0,-5)
		g.heading:SetText("Click a buff to edit!")
		
		g.icon = g:CreateTexture()
		g.icon:SetWidth(30)
		g.icon:SetHeight(30)
		g.icon:SetPoint("TOPLEFT",10,-10)
		
		g.name = CreateFrame("EditBox","OZBA Buff Name",g,"InputBoxTemplate")
		g.name:SetWidth(160)
		g.name:SetHeight(20)
		g.name:SetPoint("TOPLEFT",50,-20)
		g.name:ClearFocus()
		g.name:SetAutoFocus(nil)
		g.name:SetScript("OnEnterPressed",OZBA_NameChanged)
		g.name:SetScript("OnEditFocusLost",OZBA_NameReset)
		g.name:SetScript("OnEscapePressed",OZBA_NameReset)
		g.name.target = 2
	
		g.tex = CreateFrame("EditBox","OZBA Buff Texture",g,"InputBoxTemplate")
		g.tex:SetWidth(190)
		g.tex:SetHeight(20)
		g.tex:SetPoint("TOPLEFT",20,-45)
		g.tex:ClearFocus()
		g.tex:SetAutoFocus(nil)
		g.tex:SetScript("OnEnterPressed",OZBA_NameChanged)
		g.tex:SetScript("OnEditFocusLost",OZBA_NameReset)
		g.tex:SetScript("OnEscapePressed",OZBA_NameReset)
		g.tex:SetScript("OnShow",OZBA_NameReset)
		g.tex.target = 3
		
		g.mine = CreateFrame("CheckButton","OZBA HighlightMine",g,"OptionsCheckButtonTemplate")
		g.mine:SetWidth(20)
		g.mine:SetHeight(20)
		g.mine:SetPoint("TOPLEFT",g,"TOPLEFT",10,-70)
		g.mine:SetScript("OnClick",OZBA_HighlightClick)
		g.mine.text = g.mine:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		g.mine.text:SetWidth(120)
		g.mine.text:SetHeight(16)
		g.mine.text:SetPoint("LEFT",20,2)
		g.mine.text:SetText("Big if mine")
		g.mine.text:SetJustifyH("LEFT")
				
		g.mine2 = CreateFrame("CheckButton","OZBA OnlyShowMine",g,"OptionsCheckButtonTemplate")
		g.mine2:SetWidth(20)
		g.mine2:SetHeight(20)
		g.mine2:SetPoint("TOPLEFT",g,"TOPLEFT",140,-70)
		g.mine2:SetScript("OnClick",OZBA_HighlightClick2)
		g.mine2.text = g.mine2:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		g.mine2.text:SetWidth(120)
		g.mine2.text:SetHeight(16)
		g.mine2.text:SetPoint("LEFT",20,2)
		g.mine2.text:SetText("Only show mine")
		g.mine2.text:SetJustifyH("LEFT")

		g.noHide = CreateFrame("CheckButton","OZBA OnlyCurable",g,"OptionsCheckButtonTemplate")
		g.noHide:SetWidth(20)
		g.noHide:SetHeight(20)
		g.noHide:SetPoint("TOPLEFT",g,"TOPLEFT",10,-90)
		g.noHide:SetScript("OnClick",OZBA_noHideClick)
		g.noHide.text = g.noHide:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		g.noHide.text:SetWidth(120)
		g.noHide.text:SetHeight(16)
		g.noHide.text:SetPoint("LEFT",20,2)
		g.noHide.text:SetText("Hide if uncurable")
		g.noHide.text:SetJustifyH("LEFT")
		
		g.noShow = CreateFrame("CheckButton","OZBA Always Hide",g,"OptionsCheckButtonTemplate")
		g.noShow:SetWidth(20)
		g.noShow:SetHeight(20)
		g.noShow:SetPoint("TOPLEFT",g,"TOPLEFT",140,-90)
		g.noShow:SetScript("OnClick",OZBA_noShowClick)
		g.noShow.text = g.noShow:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		g.noShow.text:SetWidth(120)
		g.noShow.text:SetHeight(16)
		g.noShow.text:SetPoint("LEFT",20,2)
		g.noShow.text:SetText("Always Hide")
		g.noShow.text:SetJustifyH("LEFT")
		
		g.type = CreateFrame("Button","OZBA_BuffType",g,"UIDropDownMenuTemplate")
		OZBA_TypeCombo_OnLoad(g.type)
		g.type:SetPoint("LEFT",g.name,"RIGHT",5,0)
		
		g.hasColor = CreateFrame("CheckButton","OZBA Colour Bar",g,"OptionsCheckButtonTemplate")
		g.hasColor:SetWidth(20)
		g.hasColor:SetHeight(20)
		g.hasColor:SetPoint("TOPLEFT",g,"TOPLEFT",270,-50)
		g.hasColor:SetScript("OnClick",OZBA_hasColourClick)
		g.hasColor.text = g.hasColor:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		g.hasColor.text:SetWidth(100)
		g.hasColor.text:SetHeight(16)
		g.hasColor.text:SetPoint("LEFT",20,2)
		g.hasColor.text:SetText("Set Colour")
		g.hasColor.text:SetJustifyH("LEFT")
		
		g.pick = CreateFrame("Button",nil,g)
		g.pick:SetWidth(40)
		g.pick:SetHeight(20)
		g.pick:SetPoint("TOPLEFT",g,"TOPLEFT",220,-50)
		g.pick:SetBackdrop({	bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
											edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
											tile = true, tileSize = 16, edgeSize = 16, 
											insets = { left = 4, right = 4, top = 4, bottom = 4 }});        
		g.pick:SetBackdropBorderColor(0.4, 0.4, 0.4)
		g.pick:SetBackdropColor(0.09, 0.09, 0.19, 1)
		g.pick:SetScript("OnClick",OZBA_PickerClick)
		
		g:Hide()
	end
end

function OZBA_TypeCombo_OnLoad(this) 
	UIDropDownMenu_Initialize(this, OZBA_TypeCombo_Initialize)
	OZ_SetDropdownWidth(this, 120,30)
	if(OZ_Initialised) then
		UIDropDownMenu_SetSelectedValue(this, 1)
	else
		UIDropDownMenu_SetSelectedValue(this, 1)
	end
end
function OZBA_TypeCombo_Initialize()
	local i,t
	for i,t in ipairs(OZBA_TYPES) do
		UIDropDownMenu_AddButton( {value = i , text = t , func = OZBA_TypeCombo_Pressed} )
	end
	if OZ_BuffAdvFrame.cursor then
		UIDropDownMenu_SetSelectedValue(OZ_BuffAdvFrame.detail.type,OZ_BuffAdvFrame.cursor[4])
	end
end 
function OZBA_TypeCombo_Pressed() 
	UIDropDownMenu_SetSelectedValue(OZ_BuffAdvFrame.detail.type,this.value)
	OZ_BuffAdvFrame.cursor[4] = this.value
	OZ_OptionsSetConfigFromOptions()
end 

function OZBA_hasColourClick(this)
	if OZ_BuffAdvFrame.cursor.col then
		OZ_BuffAdvFrame.cursor._col = OZ_BuffAdvFrame.cursor.col
		OZ_BuffAdvFrame.cursor.col = nil
	else
		if OZ_BuffAdvFrame.cursor._col then
			OZ_BuffAdvFrame.cursor.col = OZ_BuffAdvFrame.cursor._col
			OZ_BuffAdvFrame.cursor._col = nil
		else
			OZ_BuffAdvFrame.cursor.col = {r=1,g=0,b=1}
		end
	end
	OZBA_SetColor()
end
function OZBA_SetColor()
	local col = OZ_BuffAdvFrame.cursor.col
	if col then
		OZ_BuffAdvFrame.detail.pick:SetBackdropColor(col.r,col.g,col.b,1)
	else
		OZ_BuffAdvFrame.detail.pick:SetBackdropColor(0,0,0,1)
	end
end
function OZBA_COLOR_FUNCTION()
	local R,G,B = ColorPickerFrame:GetColorRGB();
	local col = OZ_BuffAdvFrame.cursor.col
	if not col then
		OZ_BuffAdvFrame.cursor.col = {r=1,g=0,b=1}
		col = OZ_BuffAdvFrame.cursor.col
	end
	col.r = R
	col.g = G
	col.b = B
	OZBA_SetColor()
end
function OZBA_PickerClick(this)
	local col = OZ_BuffAdvFrame.cursor.col
	if not col then
		OZ_BuffAdvFrame.cursor.col = {r=1,g=0,b=1}
		col = OZ_BuffAdvFrame.cursor.col
	end
	ColorPickerFrame:Show();
	if col then 
		ColorPickerFrame:SetColorRGB(col.r,col.g,col.b)
	else
		
	end
	ColorPickerFrame.func = OZBA_COLOR_FUNCTION
end

function OZBA_noHideClick(this) -- DontHide = Show debuff even if we can't cure (only applies to debuffs, default = on)
	OZ_BuffAdvFrame.cursor.fDontHide = not this:GetChecked() -- text = Hide if Uncurable - INVERT!
end
function OZBA_noShowClick(this) -- Always hide this buff (used for highighting special debuffs you never want to see, i.e. grobbulus debuff)
	OZ_BuffAdvFrame.cursor.fNoShow = this:GetChecked() -- text = Always Hide - NORMAL
	OZBA_SetWatched() -- This flag changes the priority text
end
function OZBA_HighlightClick(this) -- NoMine = Dont highight my buffs any different to others -- MAKE THIS A WINDOW VAR NOT A BUFF OPTION!!!
	OZ_BuffAdvFrame.cursor.fNoMine = not this:GetChecked() -- text = HighlightMine - INVERT
end
function OZBA_HighlightClick2(this) -- Only show this buff if I cast it
	OZ_BuffAdvFrame.cursor.fOnlyMine = this:GetChecked() -- text = Only show mine - NORMAL
end
function OZBA_NameReset(this)
	local f = OZ_BuffAdvFrame
	local b = f.cursor
	if b[this.target] then
		this:SetText(b[this.target])
	else
		this:SetText("*")
	end
end
function OZBA_NameChanged(this)
	local f = OZ_BuffAdvFrame
	local b = f.cursor
	if b.isCustom then
		local t = this:GetText()
		if t and t~="*" then
			b[this.target] = this:GetText()
		else
			b[this.target] = nil
		end
	end
	this:ClearFocus()
end

function OZBA_CopyFlags(src, dest)
	for _,v in ipairs(OZBA_Flags) do dest[v] = src[v] end
end
function OZBA_ClearFlags(dest)
	for _,v in ipairs(OZBA_Flags) do dest[v] = nil end
end
--[[
Click the row = Set the detail panel
  if this rows data has a 'dest', then we are a watched buff.
	Any editing should then set this 'dest'
		After changing, the UI must reflect this dest
	BUT - if watched drops to nil, then we need to copy flags & settings back to src!

]]--
function OZBA_SetDetail(row)
	-- Fill in the detail panel with the data for the row passed in
	local f = OZ_BuffAdvFrame
	local g = f.detail
	if row and row.data then
		local data = row.data
		local flags = data.dest
		if not flags then
			-- Buff is not on our watched list, so use flags from the source array (use this as a cache)
			flags = data.src
		end
		f.cursor = flags
		g.heading:Hide()
		local tex = flags[3]
		if tex and not string.find(tex,"Interface\\") then
			tex = "Interface\\Icons\\"..tex
		end
		OZ_SetIconTexture(g.icon, tex)
		
		OZBA_NameReset(g.name)
		OZBA_NameReset(g.tex)
		
		if flags[4]<=2 then
			OZ_CheckBoxEnable(g.mine,not flags.fNoMine)
			OZ_CheckBoxEnable(g.mine2,flags.fOnlyMine)
			OZ_CheckBoxDisable(g.noHide)
			OZ_CheckBoxDisable(g.noShow)
		else
			OZ_CheckBoxEnable(g.noHide,not flags.fDontHide)
			OZ_CheckBoxEnable(g.noShow,flags.fNoShow)
			OZ_CheckBoxDisable(g.mine)
			OZ_CheckBoxDisable(g.mine2)
		end
		
		OZ_CheckBoxEnable(g.hasColor,flags.col)
		OZBA_SetColor()

		UIDropDownMenu_SetSelectedValue(g.type, flags[4])
		_G[g.type:GetName().."Text"]:SetText(OZBA_TYPES[flags[4]])
		g:Show()
	else
		g:Hide()
	end
		
end
function OZ_CheckBoxEnable(frame, val)
	frame:SetChecked(val)
	frame:Enable()
	frame.text:SetTextColor(1,0.82,0)
end
function OZ_CheckBoxDisable(frame)
	frame:SetChecked(nil)
	frame:Disable()
	frame.text:SetTextColor(0.6,0.6,0.6)
end

function OZBA_CountLeaves(t)
	local k,v
	local tot = 0
	local currBuffs = OZBA_State.getSource()
	for k,v in pairs(t) do
		if type(v) == "table" then
			if type(v[1]) ~= "number" then
				tot = tot + OZBA_CountLeaves(v)
			elseif OZ_BuffAdvFrame.filters[v[4]] then
				local tex = v[3]
				if v.key then -- Debuff class types or unknowns
					tex = v.key
				elseif tex then
					if not string.find(tex,"Interface\\") then
						tex = "Interface\\Icons\\"..tex
					end
				end
				if currBuffs[v[4]][tex] then -- Tracked buff
					if OZ_BuffAdvFrame.filters[5] then
						tot = tot + 1
					end
				else
					if OZ_BuffAdvFrame.filters[6] then
						tot = tot + 1
					end
				end
			end
		end
	end
	return tot
end
function OZBA_RecurseBuildLists(depth,current,cat)
	if not cat then cat = "OZBA_" end
	local f = OZBA_State
	local k,v
	local watched = OZBA_State.getSource()
	if not watched then print("No dest buffs!") end
	for k,v in pairs(current) do
		if type(v) == "table" then
			if type(v[1]) ~= "number" then
				-- We are a table of categories
				local nLeaves = OZBA_CountLeaves(v)
				if nLeaves > 0 then
					local cName = cat..k
					if nLeaves > 3 then
						-- Add our key as a category...
						table.insert(f.list, { indent=depth, category=k, name=cName })
						if f.max[cName] then
							OZBA_RecurseBuildLists(depth+1,v,cName)
						end
					else
						OZBA_RecurseBuildLists(depth,v,cName)
					end
				end
			else -- We are a buff description!
				if OZ_BuffAdvFrame.filters[v[4]] then -- check we are enabled on the UI
					local tex = v[3]
					if v.key then -- Debuff class types or unknowns
						tex = v.key
					elseif tex then
						if not string.find(tex,"Interface\\") then
							tex = "Interface\\Icons\\"..tex
						end
					end
					local w
					w = watched[v[4]][tex]
					if (w and OZ_BuffAdvFrame.filters[5]) or (not w and OZ_BuffAdvFrame.filters[6]) then
						table.insert(f.list, { indent=depth, src = v, dest = w, name=cat.."ZZ"..v[2]}) -- add a line to the output
					end
				end
			end
		end -- else we are just a flag (noLeaf for example)
	end
	-- f.list is the resultant table
	table.sort(f.list, function(a,b) return a.name<b.name end )
end

function OZBA_BuildWatchedList()
	OZBA_State.list = {} -- NASTY! THis leaks a BIG table, but hey - we're only the options so I dont care!
	OZBA_RecurseBuildLists(0,OZ_BUFF_TABLE)
	OZBA_RecurseBuildLists(0,OZBA_RecordBuffer)
end

function OZBA_CheckState(change)
	if change and change~= OZBA_State then
		OZBA_State:UnlockHighlight()
		change:LockHighlight()
		OZBA_State = change
--		OZBA_BuildWatchedList()
--		OZBA_UpdateWatched(OZ_BuffAdvFrame.watched)
	end
--	OZBA_SetWatched()
	OZBA_RefreshFrame(true)
end

function OZBA_RefreshFrame(clearDetail)
	OZBA_BuildWatchedList()
	OZBA_UpdateWatched(OZ_BuffAdvFrame.watched)
	OZBA_SetWatched()
	if clearDetail then	OZBA_SetDetail() end
end

function OZBA_GetWatched(n)
	local w = OZ_BuffAdvFrame.watched
	if not w.rows[n] then
		local a = CreateFrame("Button",nil,w,nil)
		a:SetWidth(350)
		a:SetHeight(OZBA_ROW_HEIGHT)
		a:SetPoint("TOPLEFT",5,(OZBA_ROW_HEIGHT-5) - n*OZBA_ROW_HEIGHT)
		a.target = 0
	   
		a.icon = a:CreateTexture()
		a.icon:SetWidth(16)
		a.icon:SetHeight(16)
		a.icon:SetPoint("LEFT",0,0)
		a.icon:SetTexture("Interface\\Icons\\Spell_Nature_Polymorph")
		a.icon:SetTexCoord(0.1,0.9,0.1,0.9)
		
		a.text = a:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		a.text:SetWidth(200)
		a.text:SetHeight(OZBA_ROW_HEIGHT)
		a.text:SetPoint("LEFT",a.icon,"RIGHT",5,0)
		a.text:SetText("Testing");
		a.text:SetJustifyH("LEFT");

		a:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight","ADD")
		a:SetScript("OnClick",OZBA_ClickRow )
		w.rows[n] = a

		a.plus = CreateFrame("Button",nil,a,"OZ_ButtonTemplate")
		a.plus:SetNormalTexture("Interface\\Buttons\\UI-PlusButton-UP")
		a.plus:SetPushedTexture("Interface\\Buttons\\UI-PlusButton-DOWN")
		a.plus:SetPoint("RIGHT",a,"RIGHT",-5,0)
		a.plus:SetScript("OnClick",OZBA_ClickPlus )
		a.plus:SetWidth(16)
		a.plus:SetHeight(16)

		a.prio = a:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		a.prio:SetWidth(60)
		a.prio:SetHeight(OZBA_ROW_HEIGHT)
		a.prio:SetPoint("RIGHT",a.plus,"LEFT",0,0)
		a.prio:SetText("Highest");

		a.minus = CreateFrame("Button",nil,a,"OZ_ButtonTemplate")
		a.minus:SetNormalTexture("Interface\\Buttons\\UI-MinusButton-UP")
		a.minus:SetPushedTexture("Interface\\Buttons\\UI-MinusButton-DOWN")
		a.minus:SetPoint("RIGHT",a.prio,"LEFT",-5,0)
		a.minus:SetScript("OnClick",OZBA_ClickMinus )
		a.minus:SetWidth(16)
		a.minus:SetHeight(16)

		
	end
	return w.rows[n]
end

function OZBA_ClickRow(self)
	if not self.data then
		OZBA_State.max[self.name] = not OZBA_State.max[self.name] -- Toggle maximized state
		
		OZBA_BuildWatchedList()
		OZBA_UpdateWatched(OZ_BuffAdvFrame.watched)
	else
		-- Update detail panel to show this...
		OZBA_SetDetail(self)
	end
	OZBA_SetWatched()
end

function OZBA_ClickPlus(self)
	local parent = self:GetParent()
	if parent.data then
		local data = parent.data
		if data.dest then
			local a = data.dest[1] + 1
			if a>10 then a = 10 end
			data.dest[1] = a
		else -- Not a watched buff...
			local pss = data.src
			local tex = pss[3] or pss.key or pss[2]
			if not string.find(tex,"Interface\\") then
				tex = "Interface\\Icons\\"..tex
			end
			local s = OZBA_State.getSource()
			local key = tex
			if pss.key then key = pss.key end   -- Custom key value (i.e. 'Magic','Poison', or Buff name)
			s[pss[4]][key] = {0, pss[2], tex, pss[4],
--                                fNoMine = pss.fNoMine,
								fOnlyMine = pss.fOnlyMine,
								fDontHide = pss.fDontHide,
								fNoShow = pss.fNoShow,
								col = pss.col
							}
			-- As we have added a watch, need to rebuild the src list so 
			data.dest = s[pss[4]][key]
            OZ_CountTableEntries(s[pss[4]])
		end
		OZBA_SetWatched()
		OZBA_ClickRow(parent)
	end
end
function OZBA_ClickMinus(self)
	local parent = self:GetParent()
	if parent.data then
		local data = parent.data
		if data.dest then
			local a = data.dest[1] - 1
			if a<0 then
				local pss = data.src
				local tex = pss[3] or pss.key or pss[2]
				if not string.find(tex,"Interface\\") then
					tex = "Interface\\Icons\\"..tex
				end
				local key = tex
				if pss.key then key = pss.key end   -- Custom key value (i.e. 'Magic','Poison', or Buff name)
				local s = OZBA_State.getSource()
				s[pss[4]][key] = nil
				data.dest = nil
                OZ_CountTableEntries(s[pss[4]])
			else
				data.dest[1] = a
			end
	   end
		OZBA_SetWatched()
		OZBA_ClickRow(parent)
	end
end
function OZBA_SetWatched()
	-- Set the rows of the watched window
	local watch = OZBA_State.getSource()
	local src = OZBA_State.list
	local i,dest
	local l = #(src)
	for i = 1,OZBA_WATCHED_SIZE do
		local a = OZBA_State.scrollIndex+i
		local row = src[a]          -- Entry from the full buffpicker list
		dest = OZBA_GetWatched(i)   -- The Frame object in the buffPicker scrolly bar window thing
		if row then
			if row.category then
				dest:UnlockHighlight()
				dest.icon:SetPoint("LEFT",20*row.indent,0)
				dest.icon:SetWidth(14)
				dest.icon:SetHeight(14)
				if OZBA_State.max[row.name] then
					dest.icon:SetTexture("Interface\\Buttons\\UI-MinusButton-UP")
				else
					dest.icon:SetTexture("Interface\\Buttons\\UI-PlusButton-UP")
				end
				dest.text:SetText(row.category)
				dest.minus:Hide()
				dest.prio:Hide()
				dest.plus:Hide()
				dest.data = nil
				dest.name = row.name
			else
				if OZ_BuffAdvFrame.cursor and (row.src==OZ_BuffAdvFrame.cursor or row.dest==OZ_BuffAdvFrame.cursor) then
					dest:LockHighlight()
				else
					dest:UnlockHighlight()
				end
				dest.icon:SetPoint("LEFT",15*row.indent,0)
				dest.icon:SetWidth(OZBA_ROW_HEIGHT)
				dest.icon:SetHeight(OZBA_ROW_HEIGHT)
				local tex = row.src[3]
				if tex and not string.find(tex,"Interface\\") then
					tex = "Interface\\Icons\\"..tex
				end
				OZ_SetIconTexture(dest.icon,tex)

				dest.text:SetText(row.src[2])
				dest.plus:Show()
				-- Find if this is watched...
				if row.dest then
					if row.dest.fNoShow then
						dest.prio:SetText( "Hidden!" )
					else
						dest.prio:SetText( row.dest[1] )
					end
				else
					dest.prio:SetText( "none" )
				end
				dest.prio:Show()
				dest.minus:Show()
				dest.data = row
			end
			dest:Hide()
			dest:Show()
		else
			dest:Hide()
		end
	end
end

function OZBA_UpdateWatched(self)
	local src = OZBA_State.list
	FauxScrollFrame_Update(self,#(src),OZBA_WATCHED_SIZE,20,nil,nil,nil,nil,nil,nil,true)
	OZBA_State.scrollIndex = FauxScrollFrame_GetOffset(self)
	
	OZBA_SetWatched()
end

function OZ_SetIconTexture(frame,texture)
	if not texture or not frame:SetTexture(texture) then
		frame:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
	end
end