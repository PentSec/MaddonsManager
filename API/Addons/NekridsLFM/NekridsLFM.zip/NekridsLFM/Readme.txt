=================
N�krid's LFM
=================

This addon gathers the information about what you're looking for to join your group and displays the final string in the specified channel.

Slash commands:
/nlfm on - displays the addon
/nlfm off - hides the addon

Always download the last version of the addon at:
http://wow.curse.com/downloads/wow-addons/details/nekrids-lfm.aspx


=================
Change Log
=================

v1.0 - 14-03-2010
First final and stable release

v0.2 - 11-03-2010
Fixed some attributes on the "Channel" field.

v0.1 - 10-03-2010
First Release