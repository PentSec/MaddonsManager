﻿-- Author      : Nékrid
-- Create Date : 3/8/2010 9:31:09 PM

SLASH_NLFM1 = "/nlfm";
SlashCmdList["NLFM"] = function(cmd) nlfm_cmd_handler(cmd) end

function nlfm_cmd_handler(cmd)
    if(cmd == "on") then
        mainframe:Show();
        DEFAULT_CHAT_FRAME:AddMessage("Nékrid's LFM Enabled.");
    elseif(cmd == "off") then
        mainframe:Hide();
        DEFAULT_CHAT_FRAME:AddMessage("Nékrid's LFM Disabled.");
    else
		DEFAULT_CHAT_FRAME:AddMessage("Nékrid's LFM info:\nUse '/nlfm on' to enable.\nUse '/nlfm off' to disable.");
    end
end

function mainframe_OnLoad()
	DEFAULT_CHAT_FRAME:AddMessage("Welcome to Nékrid's LFM.\nUse '/nlfm on' to enable.\nUse '/nlfm off' to disable.");
end

function b_hide_OnClick()
	mainframe:Hide();
	DEFAULT_CHAT_FRAME:AddMessage("Nékrid's LFM Disabled.");
end

function b_tanks_m_OnClick()
    if(n_tanks:GetNumber() > 0) then
        n_tanks:SetNumber(n_tanks:GetNumber()-1)
    end
end

function b_tanks_p_OnClick()
    if(n_tanks:GetNumber() < 99) then
        n_tanks:SetNumber(n_tanks:GetNumber()+1)
    end
end

function b_healers_m_OnClick()
    if(n_healers:GetNumber() > 0) then
        n_healers:SetNumber(n_healers:GetNumber()-1)
    end
end

function b_healers_p_OnClick()
    if(n_healers:GetNumber() < 99) then
        n_healers:SetNumber(n_healers:GetNumber()+1)
    end
end

function b_dps_m_OnClick()
    if(n_dps:GetNumber() > 0) then
        n_dps:SetNumber(n_dps:GetNumber()-1)
    end
end

function b_dps_p_OnClick()
    if(n_dps:GetNumber() < 99) then
        n_dps:SetNumber(n_dps:GetNumber()+1)
    end
end

function b_announce_OnClick()
	text = i_desc:GetText();
	
	if(i_desc:GetText() ~= "") then
		text = text .. ".";
	end
	
	if(n_tanks:GetNumber() > 0 or n_healers:GetNumber() > 0 or n_dps:GetNumber() > 0) then
		text = text .. " Need ";
		if(n_tanks:GetNumber() > 0) then
			text = text .. n_tanks:GetNumber() .. " tanks";
			if(i_tanks:GetText() ~= "") then
				text = text .. " (" .. i_tanks:GetText() .. ")";
			end
			if(n_healers:GetNumber() > 0 or n_dps:GetNumber() > 0) then
				text = text .. ", ";
			end
		end
		if(n_healers:GetNumber() > 0) then
			text = text .. n_healers:GetNumber() .. " healers";
			if(i_healers:GetText() ~= "") then
				text = text .. " (" .. i_healers:GetText() .. ")";
			end
			if(n_dps:GetNumber() > 0) then
				text = text .. ", ";
			end
		end
		if(n_dps:GetNumber() > 0) then
			text = text .. n_dps:GetNumber() .. " dps";
			if(i_dps:GetText() ~= "") then
				text = text .. " (" .. i_dps:GetText() .. ")";
			end
		end
		
		text = text .. ".";
		
	end
	
    if(text ~= "") then
	    text = text .. " ";
    end
	
	if(i_addtext:GetText() ~= "") then
		text = text .. i_addtext:GetText();
	end
	
	c_id, c_name = GetChannelName(n_channel:GetNumber());
	
	if(n_channel:GetNumber() > 0) then
		if(c_id > 0 and c_name ~= nil) then
            if(text ~= "") then
			    SendChatMessage(text , "CHANNEL", nil, c_id);
            else
                DEFAULT_CHAT_FRAME:AddMessage("Nékrid's LFM: There is nothing to announce!");
            end
		else
			DEFAULT_CHAT_FRAME:AddMessage("Nékrid's LFM: Specified channel doesn't exist!");
		end
	else
		DEFAULT_CHAT_FRAME:AddMessage("Nékrid's LFM: Please specify a channel number.");
	end

end